#ifndef CHAYAN_MAIN_H
#define CHAYAN_MAIN_H
#include <thread>
#include <dirent.h>
#include <map>
#include "vehicle_info.h"
#include "Log.h"
#include "Queue.h"
#include "large_vehicle_api.hpp"
#include "DownloadPic.h"
#include "nvml.h"
#include "ProcessPhoto.h"
#include "configfile.h"
#include "HttpClient.h"
#define RESULT_OK 0
#define RESULT_FAIL 1
#define MAX_LIMIT 30
//自测时需要定义
#define TESTANDROID
extern Queue service_queue;
void recordSendTime(const Vehicle_Info* pVehicle_info);
void putIntoWaitReplySoapQueue(Vehicle_Info*);
void putIntoReplySoapQueue();
extern zplx is_zplx_check;
extern std::map<std::string,long> send_vehicle_info;
extern vector<string> lsh_list;
typedef struct configurations
{
public:
    std::string city;
    int startTime;
    int endTime;
    int zplx;
    int andirod_wait_time;
    std::string soapIp;
    std::string remoteIp;
    bool is_master;
    std::string masterIP;
    std::vector <std::string> slaveIP;
    std::string photoFile;
    picture_code picCode;
    string soapurl;
    string soapnum;
    string soapovertime;
    string soapquery;
    string soapwrite;
    string soapxlh;
    string qsrq;
    int qsrqOffset;
    string zzrq;
    int zzrqOffset;
}configuration;

typedef  struct _RecvRenGongData
{
    std::string lsh;
    std::string zpzl;
    std::string jg;
    std::string sm;
}RecvRenGongData;

class service
{
public:
    service();
    ~ service();
    
    unsigned int inint_database();
    unsigned int start();
    unsigned int start_recv_soap_info();
    unsigned int start_distribute_info();
    unsigned int start_download_photo();
    unsigned int start_process_photo();
    unsigned int start_slave_reply_result();
    unsigned int start_reply_soap_result();
    unsigned int start_save_result();
    unsigned int start_sendto_android();
    unsigned int start_dump_database();
    unsigned int start_delete_file();
    void putIntoReplySoapQueue();
    bool isWorkTime();
    string get_ip();
    void lncysf();
private:
    bool         operateDatabase(const Vehicle_Info *);
    bool         operateDemoDatabase(const Vehicle_Info *);

private:
    string rectToString(cv::Rect rect);
    string boolToString(bool is_true);

    std::thread *recvSoapInfo;
    std::thread *downloadPhoto;
    std::thread *distributeInfo;
    std::thread *slaveReplyResult;
    std::thread *processPhotoBlock;
    std::thread *replySoapResult;
    std::thread *saveResult;
    std::thread *sendtoAndroid;
    std::thread *databaseBackup;
    std::thread *deleteExpireFile;
    std::thread *putIntoReplySoap;

};

#endif // CHAYAN_MAIN_H
