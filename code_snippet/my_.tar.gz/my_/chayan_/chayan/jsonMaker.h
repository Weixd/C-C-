#ifndef JSONMAKER_H
#define JSONMAKER_H
#include "json/json.h"
#include <iostream>
#include <fstream>
#include "configfile.h"
#include "chayan_main.h"
#include "Log.h"
#include "rapidjson/document.h"

extern configuration serviceConfigure;
//济南定制  查验员姓名对应身份证号码
extern std::map<std::string,std::string> cyyxx;
using namespace rapidjson;
using namespace std;
class jsonMaker
{
public:
    cfgzplx config;
    jsonMaker();
    bool readJson(char *filename);
    bool readJsonJiNan(char *filename);
    void makeJson();
    std::string GetCurrentTime(int time_count = 0);
};

#endif // JSONMAKER_H
