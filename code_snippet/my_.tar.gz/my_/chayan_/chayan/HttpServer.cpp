#include "HttpServer.h"
#include "Log.h"

#include <event2/keyvalq_struct.h>
#include <event2/buffer.h>
#include <event2/http_struct.h>

HTTP_Server::HTTP_Server(std::string IP, unsigned short int port)
{
    this->port = port;
    this->IP = IP;

    base = event_base_new();
    if (base == nullptr) {
        LOG_OUT(ERROR, "event_base_new() failed! \n");
        return;
    }

    http = evhttp_new(base);
    if (evhttp_bind_socket(http, this->IP.c_str(), this->port) != 0) {
        evhttp_free(http);
        event_base_free(base);
        base = nullptr;
        http = nullptr;
        LOG_OUT(ERROR, "evhttp_bind_socket() failed! \n");
    }
}

HTTP_Server::~HTTP_Server()
{
    if (http != nullptr)
    {
        evhttp_free(http);
    }

    if (base != nullptr)
    {
        event_base_free(base);
    }
}

void HTTP_Server::startListen(request_callback func)
{
    LOG_OUT(INFO, "HTTP server listening(%s:%d)...... \n", IP.c_str(), port);
    evhttp_set_gencb(http, func, this);   /* 绑定事件处理函数 */
    event_base_dispatch(base);  /* 启动事件循环 */
    evhttp_free(http);
}

std::string HTTP_Server::getRemoteHost(evhttp_request *req)
{

    if(req->remote_host != nullptr)
    {
        return std::string(req->remote_host);
    }
    else
    {
        return "";
    }

}

unsigned int HTTP_Server::getRemotePort(evhttp_request *req)
{

    return req->remote_port;
}

std::string HTTP_Server::getMethod(evhttp_request *req)
{
    std::string method = "";

    switch (evhttp_request_get_command(req))
    {
        case EVHTTP_REQ_GET:     method = "GET";break;
        case EVHTTP_REQ_POST:    method = "POST"; break;
        case EVHTTP_REQ_HEAD:    method = "HEAD"; break;
        case EVHTTP_REQ_PUT:     method = "PUT"; break;
        case EVHTTP_REQ_DELETE:  method = "DELETE"; break;
        case EVHTTP_REQ_OPTIONS: method = "OPTIONS"; break;
        case EVHTTP_REQ_TRACE:   method = "TRACE"; break;
        case EVHTTP_REQ_CONNECT: method = "CONNECT"; break;
        case EVHTTP_REQ_PATCH:   method = "PATCH"; break;
    }

    return method;
}

std::string HTTP_Server::getURI(evhttp_request *req)
{

    if(evhttp_request_get_uri(req) != nullptr)
    {
        return std::string(evhttp_uridecode(evhttp_request_get_uri(req), 0, NULL));
    }
    else
    {
        return "";
    }

}


std::vector<HTTP_Header> HTTP_Server::getHeaderList(evhttp_request *req)
{
    std::vector<HTTP_Header> HeaderList;
    struct evkeyvalq *headers;
    struct evkeyval *header;

    headers = evhttp_request_get_input_headers(req);
    for (header = headers->tqh_first; header; header = header->next.tqe_next)
    {
        HeaderList.push_back(HTTP_Header(header->key, header->value));
    }

    return HeaderList;
}


std::string HTTP_Server::getBody(evhttp_request *req)
{
    struct evbuffer *buf = evhttp_request_get_input_buffer(req);

    size_t len = evbuffer_get_length(buf);
    char *recv_data = new char[len+1];
    evbuffer_copyout(buf, recv_data, len);
    *(recv_data + len) = 0; /* 末尾补充终止符 */
    std::string body = recv_data;
    delete[] recv_data;
    recv_data = nullptr;

    return body;
}

void HTTP_Server::sendReply(evhttp_request *req, E_HTTP_CODE code, std::vector<HTTP_Header> HeaderList, std::string body)
{
    if (code == OK)
    {
        evbuffer *buf = evbuffer_new();
        if (buf == nullptr)
        {
            LOG_OUT(ERROR, "evbuffer_new() failed! \n");
            evhttp_send_error(req, HTTP_INTERNAL, nullptr);
            return;
        }

        if (!HeaderList.empty())
        {
            for (unsigned int i = 0; i < HeaderList.size(); i++)
            {
                evhttp_add_header(req->output_headers, HeaderList[i].key.c_str(), HeaderList[i].value.c_str());
            }
        }

        if (!body.empty())
        {
            evbuffer_add(buf, body.c_str(), strlen(body.c_str()));
        }

        evhttp_send_reply(req, code, "OK", buf);
        evbuffer_free(buf);
    }
    else
    {    /* 200以外的code，都按错误处理，使用标准HTTP错误信息，不额外附加header和body */
        evhttp_send_error(req, code, nullptr);
    }
}
