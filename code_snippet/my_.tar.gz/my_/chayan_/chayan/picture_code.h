#ifndef PICTURE_CODE_H
#define PICTURE_CODE_H
#include <iostream>
class picture_code
{
public:
    std::string zqf;
    std::string yhf;
    std::string cjh;
    std::string cxnb;
    std::string clmp;
    std::string ltgg;
    std::string aqd;
    std::string syrzp;
    std::string cyyzp;
    std::string gcfp;
    std::string sfz;
    std::string hbd;
    std::string jkpz;
    std::string jybg;
    std::string wszm;
    std::string hgz;
    std::string yzxzs;
    std::string fdjh;
    std::string ddccz; //电动车插座
};




#endif // PICTURE_CODE_H
