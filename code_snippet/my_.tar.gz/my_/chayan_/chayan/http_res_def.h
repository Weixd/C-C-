
/*URL define:
Query Post data:
http://116.236.215.22:9000/TmriOutAccess.asmx/writeObjectOut
content-type:application/x-www-form-urlencoded
xtlb=18&jkxlh=63F414CB10CA08494F237C90643083EB&jkid=18B01&xmlDoc=<?xml version="1.0" encoding="GBK"?>
<root><vehispara><jylsh>510116170329004510101</jylsh><jyjgbh>5100000144</jyjgbh><hpzl>02</hpzl><hphm>川S62050</hphm>
<clsbdh>LFMCFB0E863952266</clsbdh><syrxm>张三</syrxm><sjhm>1300000000</sjhm><sxrq>2017-01-01</sxrq><zzrq>2018-01-01</zzrq>
<cllx>卡车</cllx><syxz>自用</syxz><zbzl>3t</zbzl><kssj>2017-04-01</kssj><jssj>2017-04-01</jssj><fdjh>abc1234567</fdjh>
<clpp1>雪弗兰</clpp1><clxh>SEAT2.0</clxh><ccdjrq>2007-12-01</ccdjrq><ccrq>2007-02-01</ccrq><wgjcjyy>检验员</wgjcjyy>
<zpzs>5</zpzs><ckdbzplist></ckdbzplist>
<zplist><item><zpzl>0201</zpzl><zpurl>http://127.0.0.1:6606/pic/511701170322001790101_0201.jpg</zpurl></item>
<item><zpzl>0111</zpzl><zpurl>http://127.0.0.1/trffweb/web/work/checkbusiness/showimg.aspx?action=zp&id=385980572</zpurl></item>
<item><zpzl>0111</zpzl><zpurl>http://127.0.0.1/trffweb/web/work/RemoteInspection/getimgbyid.ashx?id=385980572</zpurl></item>
<item><zpzl>0113</zpzl><zpurl>http://127.0.0.1:80/cjh21175.jpg</zpurl></item>
<item><zpzl>0111</zpzl><zpurl>http://127.0.0.1:80/sjjD9A118_1.jpg</zpurl></item>
<item><zpzl>0157</zpzl><zpurl>http://127.0.0.1:80/aqdAFY426_3.JPG</zpurl></item></zplist><spzs>3</spzs>
<splist><item><spzl>H</spzl><dzzl>rtsp</dzzl><spurl>rtsp://admin:12345@118.112.188.39:554/Streaming/tracks/2801?starttime=20170329t153129z&endtime=20170329t153157z</spurl></item>
<item><spzl>B</spzl><dzzl>nvr</dzzl><spurl><sbip>设备IP:PORT</sbip><sbuser>设备用户</sbuser><sbmm>设备密码</sbmm><channel>通道号</channel><kssj>2017-04-01 09:22:33</kssj><jssj>2017-04-01 09:26:33</jssj></spurl></item>
<item><spzl>B</spzl><dzzl>nvr</dzzl><spurl><sbip>192.168.100.226:8000</sbip><sbuser>admin</sbuser><sbmm>hk123456</sbmm><channel>1</channel><kssj>2017-04-17 17:09:00</kssj><jssj>2017-04-17 17:10:00</jssj></spurl></item>
<item><spzl>DC</spzl><dzzl>http</dzzl><spurl>http://127.0.0.1:80/xxxx.mpeg4</spurl></item>
</splist><dbbhgs>2</dbbhgs><dbbhglist><item><zpzl>0201</zpzl><sm>仅用于测试</sm><jg>2</jg><zpid>234334554<zpid></item>
<item><zpzl>0111</zpzl><sm>仅用于测试</sm><jg>2</jg><zpid>111334559<zpid></item>
</dbbhglist></vehispara></root>
*/

#define JGSYS_SOAP_PROCOTOL               1  

#define REMOTE_VEHICLE_SYS_IP             "118.112.188.39"  //temp
#define REMOTE_VEHICLE_SYS_PORT           "6606"  
#define LOCAL_HTTPSERVER_IP               "0.0.0.0"
#define LOCAL_HTTPSERVER_PORT             "9001"

#define VHHICLE_ANALYSE_QUEST             1
#define DOWNLOAD_PHOTO_DATA               2
#define VHHICLE_ANALYSE_QUEST_RESULT      3
#define TO_REFUSE                         4
#define PHOTO_PROCESS_RESULT              5
#define REPLY_ANDROID                     6
#define WAIT_ANDROID_RESPONSE             7
#define GET_LSH_GONGWEI                   8
#define PORT                              "9001"
#define VHHICLE_DZJQXBD_TEXT              "InsurService.asmx"
#define DOWNLOAD_VIDEO_DATA               "PdaOutAccess.asmx"
#define VHHICLE_ANALYSE_QUEST_TEXT        "TmriOutAccess.asmx/writeObjectOut"
#define VIDEO_QUEST_TEXT				  "/TmriOutAccess.asmx/writeVideoOut"
#define DOWNLOAD_PHOTO_DATA_TXT           "/trffweb/web/work/CheckBusiness/showimg.aspx"

#define VEHICLE_JKXLH                     "63F414CB10CA08494F237C90643083EB"
#define VEHICLE_JKID                      "18B01"
#define VEHICLE_XTLB                      "18"
#define CLZL                              "K31,K32,K33,K34,K39,H31,H32"

#define POST_DATA_OK                       1
#define WRONG_JKXLH                        2
#define WRONG_JKID                         3
#define WRONG_XTLB                         4
#define WRONG_PATH                         5
#define ABNORMAL_KEY                       6
#define WRONG_XMLDATA                      7
#define WRONG_XMLDOC                       8
#define DEVICE_BUSY			               9
#define VIDEO_GET                          10
#define VIDEO_LOSS                         11

//#define LOCAL_PHOTOFILE_PATH            "d:\\Vehicle_Photo\\"
#define LOCAL_PHOTOFILE_PATH              "/home/public/Vehicle_Photo/"
#define LOCAL_VIDEOFILE_PATH              "/home/public/Vehicle_Video/"

// (default)
#define HTTP_CONTENT_TYPE_URL_ENCODED     "application/x-www-form-urlencoded"
// (use for files: picture, mp3, tar-file etc.)                                        
#define HTTP_CONTENT_TYPE_FORM_DATA       "multipart/form-data"
// (use for plain text)
#define HTTP_CONTENT_TYPE_TEXT_PLAIN      "text/plain"
// (use for plain xml)
#define HTTP_CONTENT_TYPE_TEXT_XML        "text/xml"

#define ZPZL_CHECK { "0111", "0112", "0113", "0157", "0201", "0202", "0203", "0204", "0205", "0265", "0321", "0322", "0348", "0352"}
//#define CLZL_CHECK { L"K31", L"K32", L"K33", L"K34", L"K39", L"H31", L"H32" }
