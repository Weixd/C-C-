#pragma once
#ifndef VEHICLE_INFO_H
#define VEHICLE_INFO_H
#include <iostream>
#include <vector>
#include <thread>
#include "TimeRecord.h"
#include "large_vehicle_api.hpp"
using namespace std;
#define ITEMCOUNT 80

//存储soap接收到的车辆基本信息
struct item_desc
{
    std::string name_desc;
    std::string name_tag;
    void* value;
};

class Photo 
{
public:
    unsigned int index;
    std::string type;
    std::string url;
    std::string path;
    std::string algorithm_process_time;
    bool isDownload;
    TimeRecord timeRecord;
    std::string result;	//照片处理结果
    std::vector<std::string> detail; //照片处理结果详细描述（多种原因的组合）
    std::thread *pD_thread;
};

class Vehicle_Info {
public:
    vector<item_desc> item_description;
    //车辆基本信息
    std::string lsh    = "无数据";
    std::string ywlx   = "无数据";
    std::string ywyy   = "无数据";
    std::string hpzl   = "无数据";
    std::string hphm   = "无数据";
    std::string clsbdh = "无数据";
    std::string syr    = "无数据";
    std::string sxrq   = "无数据";
    std::string zzrq   = "无数据";
    std::string cllx   = "无数据";
    std::string syxz   = "无数据";
    std::string zbzl   = "无数据";
    std::string fdjh   = "无数据";
    std::string clpp1  = "无数据";
    std::string clxh   = "无数据";
    std::string ccdjrq = "无数据";
    std::string ccrq   = "无数据";
    std::string kssj   = "无数据";
    std::string jssj   = "无数据";
    std::string zpzs   = "无数据";
    std::string spzs   = "无数据";
    std::string xszbh  = "无数据";
    std::string rlzl   = "无数据";
    std::string fzrq   = "无数据";
    std::string csys   = "无数据";
    std::string pl     = "无数据";
    std::string gl     = "无数据";
    std::string zxxs   = "无数据";
    std::string cwkc   = "无数据";
    std::string cwkk   = "无数据";
    std::string cwkg   = "无数据";
    std::string hxnbcd = "无数据";
    std::string hxnbkd = "无数据";
    std::string hxnbgd = "无数据";
    std::string gbthps = "无数据";
    std::string zs     = "无数据";
    std::string zj     = "无数据";
    std::string qlj    = "无数据";
    std::string hlj    = "无数据";
    std::string ltgg   = "无数据";
    std::string lts    = "无数据";
    std::string zzl    = "无数据";
    std::string hdzzl  = "无数据";
    std::string hdzk   = "无数据";
    std::string zqyzl  = "无数据";
    std::string qpzk   = "无数据";
    std::string hpzk   = "无数据";
    std::string clyt   = "无数据";
    std::string ytsx   = "无数据";
    std::string sfxny  = "无数据";
    std::string xnyzl  = "无数据";
    std::string clpp2  = "无数据";
    std::string gcjk   = "无数据";
    std::string zzg    = "无数据";
    std::string zzcmc  = "无数据";
    std::string djrq   = "无数据";
    std::string yxqz   = "无数据";
    std::string qzbfqz = "无数据";
    std::string fzjg   = "无数据";
    std::string glbm   = "无数据";
    std::string zt     = "无数据";
    std::string dybj   = "无数据";
    std::string fdjxh  = "无数据";
    std::string hbdbqk = "无数据";
    std::string jyhgbzbh="无数据";
    std::string xzqh   = "无数据";
    std::string zsxzqh = "无数据";
    std::string zzxzqh = "无数据";
    std::string cyqxh  = "无数据";
    std::string xh     = "无数据";
    std::string cyry   = "无数据";//查验员身份证号码
    std::string fdjrq  = "无数据";
    std::string fhgzrq = "无数据";
    std::string model = "无数据";
    std::string is_pass = "无数据";
    std::string resultReplyTime = "无数据";
    std::string resultReplyStatus = "无数据";
    std::string device_ip = "无数据";
    std::string gongwei_code = "无数据";
    std::string sqshsj = "无数据";
    std::vector<Photo> photo_list;

    bool isSendAndroid = false;


    Vehicle_Info()
    {
        item_desc _item_description[ITEMCOUNT] =
        {
            /*0*/{ "检验流水号", ("lsh"), &lsh},
            /*1*/{ "业务类型", ("ywlx"), &ywlx },
            /*2*/{ "业务原因", ("ywyy"), &ywyy },
            /*3*/{ "号牌种类", ("hpzl"), &hpzl },
            /*4*/{ "号牌号码", ("hphm"), &hphm },
            /*5*/{ "车辆识别代号", ("clsbdh"), &clsbdh },
            /*6*/{ "使用人", ("syr"), &syr },
            /*7*/{ "生效日期", ("sxrq"), &sxrq },
            /*8*/{ "终止日期", ("zzrq"), &zzrq },
            /*9*/{ "车辆类型", ("cllx"), &cllx },
            /*10*/{ "使用性质", ("syxz"), &syxz },
            /*11*/{ "整备质量", ("zbzl"), &zbzl },
            /*12*/
            /*13*/
            /*14*/{ "发动机/电动机号码", ("fdjh"), &fdjh },
            /*15*/{ "车辆品牌", ("clpp1"), &clpp1 },
            /*16*/{ "车辆型号", ("clxh"), &clxh },
            /*17*/{ "初次登记日期", ("ccdjrq"), &ccdjrq },
            /*18*/{ "出厂日期", ("ccrq"), &ccrq },
            /*19*/{ "检验开始时间", ("kssj"), &kssj },
            /*20*/{ "检验结束时间", ("jssj"), &jssj },
            /*21*/{ "需要对比照片总数", ("zpzs"), &zpzs },
            /*22*/{ "需要对比视频总数", ("spzs"), &spzs },
            /*23*/{ "行驶证编号", ("xszbh"), &xszbh },
            /*24*/{ "燃料种类", ("rlzl"), &rlzl },
            /*25*/{ "行驶证发证日期", ("fzrq"), &fzrq },
            /*26*/{"车身颜色", ("csys"), &csys },
            /*27*/{"排量", ("pl"), &pl },
            /*28*/{"功率", ("gl"), &gl },
            /*29*/{"转向形式", ("zxxs"), &zxxs },
            /*30*/{"车外廓长", ("cwkc"), &cwkc },
            /*31*/{"车外廓宽", ("cwkk"), &cwkk },
            /*32*/{"车外廓高", ("cwkg"), &cwkg },
            /*33*/{"货箱内部长度", ("hxnbcd"), &hxnbcd },
            /*34*/{"货箱内部宽度", ("hxnbkd"), &hxnbkd },
            /*35*/{"货箱内部高度", ("hxnbgd"), &hxnbgd },
            /*36*/{"钢板弹簧片数", ("gbthps"), &gbthps },
            /*37*/{"轴数", ("zs"), &zs },
            /*38*/{"轴距", ("zj"), &zj },
            /*39*/{"前轮距", ("qlj"), &qlj },
            /*40*/{"后轮距", ("hlj"), &hlj },
            /*41*/{"轮胎规格", ("ltgg"), &ltgg },
            /*42*/{"轮胎数", ("lts"), &lts },
            /*43*/{"总质量", ("zzl"), &zzl },
            /*44*/{"核定载质量", ("hdzzl"), &hdzzl },
            /*45*/{"核定载客", ("hdzk"), &hdzk },
            /*46*/{"准牵引质量", ("zqyzl"), &zqyzl },
            /*47*/{"驾驶室前排载客人数", ("qpzk"), &qpzk },
            /*48*/{"驾驶室后排载客人数", ("hpzk"), &hpzk },
            /*49*/{"车辆用途", ("clyt"), &clyt },
            /*50*/{"用途属性", ("ytsx"), &ytsx },
            /*51*/{"是否新能源汽车", ("sfxny"), &sfxny },
            /*52*/{"新能源种类", ("xnyzl"), &xnyzl },
            /*53*/{"英文品牌", ("clpp2"), &clpp2 },
            /*54*/{"国产/进口", ("gcjk"), &gcjk },
            /*55*/{"制造国", ("zzg"), &zzg },
            /*56*/{"制造厂名称", ("zzcmc"), &zzcmc },
            /*57*/{"最近定检日期", ("djrq"), &djrq },
            /*58*/{"检验有效期止", ("yxqz"), &yxqz },
            /*59*/{"强制报废期止", ("qzbfqz"), &qzbfqz },
            /*60*/{"发证机关", ("fzjg"), &fzjg },
            /*61*/{"管理部门", ("glbm"), &glbm },
            /*62*/{"机动车状态", ("zt"), &zt },
            /*63*/{"抵押标记", ("dybj"), &dybj },
            /*64*/{"发动机型号", ("fdjxh"), &fdjxh },
            /*65*/{"环保达标情况", ("hbdbqk"), &hbdbqk },
            /*66*/{"检验合格标志", ("jyhgbzbh"), &jyhgbzbh },
            /*67*/{"管理辖区", ("xzqh"), &xzqh },
            /*68*/{"住所地址行政区划", ("zsxzqh"), &zsxzqh },
            /*69*/{"联系地址行政区划", ("zzxzqh"), &zzxzqh },
            /*70*/{"查验区序号",("cyqxh"),&cyqxh },
            /*71*/{"机动车序号",("xh"),&xh },
            /*72*/{"查验员身份证明号码",("cyry"),&cyry },
            /*73*/{"发登记证书日期",("fdjrq"),&fdjrq },
            /*74*/{"发合格标志日期",("fhgzrq"),&fhgzrq },
            /*75*/{"外观表单标志",("model"),&model },
            /*76*/{"整车判定结果",("is_pass"),&is_pass },
            /*77*/{"结果写回时间",("resultReplyTime"),&resultReplyTime },
            /*78*/{"结果写回状态",("resultReplyStatus"),&resultReplyStatus },
            /*79*/{"设备IP",("device_ip"),&device_ip},
            /*80*/{"工位编号",("gongwei_code"),&gongwei_code },
            /*81*/{"申请审核时间",("sqshsj"),&sqshsj }
        };

        for(auto count = 0;count < ITEMCOUNT; count++)
        {
            item_description.push_back(_item_description[count]);
        }

    }
    ~Vehicle_Info()
    {
        item_description.clear();
        photo_list.clear();
    }
public:
    Cheliang_ImgOutMsg zuoqianfang;
    Cheliang_ImgOutMsg youhoufang;
    Chejiahao_ImgOutMsg chejiahao;
    Luntaiguige_ImgOutMsg luntaiguige;
    Fadongjihao_OutMsg fadongjihao;
    Mingpai_OutMsg mingpai;
};



#endif // VEHICLE_INFO_H
