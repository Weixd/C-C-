#ifndef CONFIGFILE_H
#define CONFIGFILE_H
#include <iostream>
#include <vector>
#include <map>
#define JINAN "3701"
#define SUZHOU "3205"
#define HANGZHOU "3301"
typedef struct cfgfadongjihao
{
    bool fadongjihao;
}fadongjihao;

typedef struct cfgzuoqianfang
{
    bool chepai;
    bool chebiao;
    bool sanjiaojia;
    bool gaizhuang;

}zuoqianfang;

typedef  struct cfgyouhoufang
{
    bool chepai;
    bool chebiao;
    bool sanjiaojia;
    bool gaizhuang;
}youhoufang;

typedef  struct cfgchejiahao
{
    bool chejiahao;

}chejiahao;

typedef  struct cfgcheliangmingpai
{
    bool lishimingpai;
    bool cheliangpinpai;
    bool cheliangxinghao;
    bool fadongjixinghao;
    bool zhizaoriqi;
    bool hedingzaike;
    bool chejiahao;
    bool gonglv;
    bool pailiang;
    bool zhizaoguo;
    bool zongzhiliang;
    bool zhizaochangmingcheng;

}cheliangmingpai;

typedef  struct cfgluntaiguige
{
    bool ltgg;
}luntaiguige;
typedef  struct cfgchexiangneibu
{
    bool gaizhuang;
}chexiangneibu;
typedef struct cfgdiandongchechazuo
{
    bool exist;
}diandongchechazuo;

typedef  struct cfganquandai
{
    bool exist;
}anquandai;

typedef  struct cfgchayanyuan
{
    bool same;
}chayanyuan;

typedef  struct chuchanghegezheng
{
    bool cheliangpinpai; //车辆品牌
    bool cheliangxinghao; //车辆型号
    bool chejiahao; //车架号
    bool fadongjixinghao; //发动机型号
    bool fadongjihao; //发动机号
    bool ranliaozhonglei; //燃料种类
    bool luntaiguige; //轮胎规格
    bool hedingzaike; //核定载客
    bool zhizaoriqi; //制造日期
    bool yinzhang;   //印章
}chuchanghegezheng;


typedef  struct cheliangyizhixing
{
    bool yinzhang;
    bool chejiahao;
}cheliangyizhixing;

typedef  struct gouzhishui
{
    bool chepai;
    bool chejiahao;                //is 'chejiahao' correct
    bool valid_data;              //Whether the date is within the validity period
    bool chechuanshui;
    bool zhengnian;               //Whether the date is one year
    bool wanshuizhengming;        //Whether the image is wanshuizhengming
}gouzhishui;

typedef  struct jianyanbaogao
{
    bool jianyanbaogao;     //is 'chepai' and 'chejiahao' correct
    bool qianming;          //if 'qianming' exist
    bool hongzhang;         //if 'hongzhang' exist
    bool jianyanjielun;     //if 'jianyanjielun' pass
    bool jianyan_info;      //if 'jianyaninfo' pass
    bool chepai;            //is 'chepai' correct
    bool chejiahao;         //is 'chejiahao' correct
    bool MA;                //if 'MA zhang' exist
    bool querenzhang;       //if 'cheliang weiyi querenzhang' exist	by gwx
    bool chepai_type;       //is 'chepai_type' correct
    bool jianyanriqi;
    bool CMA;
    bool cheliangtu;
}jianyanbaogao;

typedef  struct jinkoupingzheng
{
    bool yinzhang;     //is 'chepai' and 'chejiahao' correct
    bool chejiahao;          //if 'qianming' exist
}jinkoupingzheng;

typedef  struct huanbaoqingdan
{
    bool chejiahao; //车架号
    bool yinzhang; //印章
    bool xinnenyuanche; //新能源车是否备注
}huanbaoqingdan;

typedef  struct shenfenzheng
{
    bool front;
    bool back;
    bool valid;
    bool xingming;
}shenfenzheng;


typedef  struct gouchefapiao
{
    bool suoyouren; //所有人
    bool shenfenzhenghao; //身份证号
    bool hegezhenghao; //合格证号
    bool chejiahao; //车架号
    bool fadongjihao; //发动机号
    bool guoshuiyinzhang; //国税印章
    bool xiaoshoudanwei; //销售单位名称
}gouchefapiao;


typedef struct cfgzplx
{
    zuoqianfang m_zuoqianfang;
    youhoufang m_youhoufang;
    chejiahao m_chejiahao;
    cheliangmingpai m_cheliangmingpai;
    luntaiguige m_luntaiguige;
    chexiangneibu m_chexiangneibu;
    fadongjihao m_fadongjihao;
    diandongchechazuo m_diandongchechazuo;
    anquandai m_anquandai;
    chayanyuan m_chayanyuan;
    gouchefapiao m_gouchefapiao;
    shenfenzheng m_shenfenzheng;
    huanbaoqingdan m_huanbaoqingdan;
    jinkoupingzheng m_jinkoupingzheng;
    jianyanbaogao m_jianyanbaogao;
    gouzhishui m_gouzhishui;
    chuchanghegezheng m_chuchanghegezheng;
    cheliangyizhixing m_cheliangyizhixing;
}zplx;

//济南定制  工位编号对应安卓端ip androidIp[0]为是否发送检测结果至屏幕
extern std::vector<std::map<std::string,std::string>> androidIP;


#endif // CONFIGFILE_H
