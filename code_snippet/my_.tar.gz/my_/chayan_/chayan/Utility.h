#ifndef _UTILITY_
#define _UTILITY_

/*
Utility.cpp中定义了供全局使用的杂项功能函数。
例如：排序，特定字符转换，解码等其他部分共同需要使用的功能。
*/

#include <string>
#include <vector>

struct CurrentTime_t
{
    unsigned int second;
    unsigned int minute;
    unsigned int hour;
    unsigned int day;
    unsigned int month;
    unsigned int year;
};

std::string URLEncode(const std::string &sIn);
std::string URLDecode(const std::string &sIn);

/**
 * @brief 获得当前系统时间。
 * @param[out] time 传出当前系统时间的结构体变量
 * @return 时间字符串，格式为“YYYY-MM-DD hh24:mi:ss”
 */
std::string getCurrentTime(CurrentTime_t &time);

/**
 * @brief 获得当前用户下，文件系统剩余可用空间。
 * @param[in] path 路径
 * @return -1--执行失败
 *         >-1--执行成功，该数值就是剩余可用空间，单位GB
 * @note 如果不同的path都是挂载在一个磁盘上，那么返回值是相同的。
 *       例如：/和/opt都挂在/dev/sda2上，那么path传入/或/opt，得到的结果是一样的。
 */
long getFileSystemFreeSpace(const char *path);

/**
 * @brief 获得文件夹下所有文件名。
 * @param[in] path 路径
 * @param[out] list 文件名列表
 * @return true--成功
 *         false--失败
 * @note 返回的文件名列表已按ASCII表排序。
 *       包括隐藏文件。
 *       包括./和../这两个文件夹。
 *       不会递归查询子文件夹。
 */
bool getFolderContent(const char *path, std::vector<std::string> &list);

std::string getNowTime();
std::string getNowTimeLong();
double diffStringTimeNow(const std::string &time_string);
std::string getDangTianRiQi();

#endif	//	_UTILITY_
