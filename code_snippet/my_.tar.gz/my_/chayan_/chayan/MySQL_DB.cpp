#include "MySQL_DB.h"

bool MySQL_DB::initialize_MySQL_library()
{
    static bool init_flag = false;

    if (init_flag) {
        LOG_OUT(ERROR, "initialize_MySQL_library() has been called successfully, do not need to be call again! \n");
        return false;
    }

    if (!(init_flag = !mysql_library_init(0, NULL, NULL))) {
        LOG_OUT(ERROR, "initialize_MySQL_library() failed! \n");
    }

    return init_flag;
}

void MySQL_DB::terminate_MySQL_library()
{
    mysql_library_end();
}

bool MySQL_DB::connect(const char *host, unsigned int port, const char *user, const char *passwd, const char *db)
{
	if (host == NULL) {
        LOG_OUT(INFO, "Try to establish connection with localhost:%d@%s DataBase: %s \n", port, user, db);
	} else {
        LOG_OUT(INFO, "Try to establish connection with %s:%d@%s DataBase: %s \n", host, port, user, db);
	}

	if (mysql_thread_init() != 0) {
        LOG_OUT(ERROR, "mysql_thread_init() failed! \n");
		return false;
	}

	if (mysql_init(&mysql) == NULL) {
        LOG_OUT(ERROR, "mysql_init() failed! \n");
		return false;
	}

    /*
        指定本次连接的编码方式（取决于编译器对字符串的编码存储方式）
        Visual Studio:gbk
        gcc:utf8
    */
    if (mysql_options(&mysql, MYSQL_SET_CHARSET_NAME, "utf8") != 0) {
        LOG_OUT(ERROR, "mysql_options(MYSQL_SET_CHARSET_NAME) failed! \n");
		return false;
	}

	if (mysql_real_connect(&mysql, host, user, passwd, db, port, NULL, 0) == NULL) {
        LOG_OUT(ERROR, "mysql_real_connect() failed! \n");
        LOG_OUT(ERROR, "Reason: %s \n", mysql_error(&mysql));
		return false;
	}

    LOG_OUT(INFO, "Database connection is successful. \n");
	return true;
}

void MySQL_DB::disconnect()
{
	mysql_close(&mysql);
	mysql_thread_end();
	
    LOG_OUT(INFO, "Disconnected with the database. \n");
}

bool MySQL_DB::createTable(const char *name, const char *format)
{
	std::string sqlString = "CREATE TABLE IF NOT EXISTS";

	sqlString = sqlString + " " + name + " " + format;
	if (mysql_query(&mysql, sqlString.c_str()) != 0) {
        LOG_OUT(ERROR, "createTable() failed! \n");
        LOG_OUT(ERROR, "Reason: %s \n", mysql_error(&mysql));
        LOG_OUT(ERROR, "Statements: %s \n", sqlString.c_str());
		return false;
	}

	return true;
}

bool MySQL_DB::dropTable(const char *name)
{
	std::string sqlString = "DROP TABLE";

	sqlString = sqlString + " " + name;
	if (mysql_query(&mysql, sqlString.c_str()) != 0) {
        LOG_OUT(ERROR, "dropTable() failed! \n");
        LOG_OUT(ERROR, "Reason: %s \n", mysql_error(&mysql));
        LOG_OUT(ERROR, "Statements: %s \n", sqlString.c_str());
		return false;
	} 

	return true;
}

bool MySQL_DB::insert(const char *tableName, const char *valueFormat)
{
	std::string sqlString = "INSERT INTO";
	
	sqlString = sqlString + " " + tableName + " " + valueFormat;
	if (mysql_query(&mysql, sqlString.c_str()) != 0) {
        LOG_OUT(ERROR, "insert() failed! \n");
        LOG_OUT(ERROR, "Reason: %s \n", mysql_error(&mysql));
        LOG_OUT(ERROR, "Statements: %s \n", sqlString.c_str());
		return false;
	}

	return true;
}

unsigned long MySQL_DB::getLastID()
{
	if (mysql_query(&mysql, "SELECT LAST_INSERT_ID()") != 0) {
        LOG_OUT(ERROR, "getLastID() failed! \n");
        LOG_OUT(ERROR, "Reason: %s \n", mysql_error(&mysql));
		return 0;
	}

	MYSQL_RES *result = NULL;
	result = mysql_store_result(&mysql);
    if (result == NULL) {
        LOG_OUT(ERROR, "getLastID() failed! \n");
        LOG_OUT(ERROR, "Reason: mysql_store_result() failed! \n");
        return 0;
    }

	MYSQL_ROW row = NULL;
	row = mysql_fetch_row(result);
	if (row == NULL) {
        LOG_OUT(ERROR, "getLastID() failed! \n");
        LOG_OUT(ERROR, "Reason: mysql_fetch_row() failed! \n");
        mysql_free_result(result);
		return 0;
	}

	if (row[0] == NULL) {
        LOG_OUT(ERROR, "getLastID() failed! \n");
        LOG_OUT(ERROR, "Reason: no data! \n");
        mysql_free_result(result);
		return 0;
	}

	std::string tmp;
	tmp = row[0];
	unsigned long ret = std::stoul(tmp);
    mysql_free_result(result);
	return ret;
}

bool MySQL_DB::createDB(const char *name)
{
	std::string sqlString = "CREATE DATABASE IF NOT EXISTS ";
	sqlString += name;
	if (0 != mysql_query(&mysql, sqlString.c_str())) {
        LOG_OUT(ERROR, "createDB() failed! \n");
        LOG_OUT(ERROR, "Reason: %s \n", mysql_error(&mysql));
        LOG_OUT(ERROR, "Statements: %s \n", sqlString.c_str());
		return false;
	}

	return true;
}

bool MySQL_DB::selectDB(const char *name)
{
	if (mysql_select_db(&mysql, name) != 0) {
        LOG_OUT(ERROR, "selectDB() failed! \n");
        LOG_OUT(ERROR, "Reason: %s \n", mysql_error(&mysql));
		return false;
	}

	return true;
}

MYSQL_RES *MySQL_DB::getResult(const char *SqlStatement)
{
	if (mysql_query(&mysql, SqlStatement) != 0) {
        LOG_OUT(ERROR, "getResult() failed! \n");
        LOG_OUT(ERROR, "Reason: %s \n", mysql_error(&mysql));
        LOG_OUT(ERROR, "Statements: %s \n", SqlStatement);
		return NULL;
	} else {
		MYSQL_RES *result = NULL;
		result = mysql_store_result(&mysql);
		return result;
	}
}

void MySQL_DB::freeResult(MYSQL_RES *result) 
{
	mysql_free_result(result);
}

unsigned int MySQL_DB::getErrorNumber()
{
	return mysql_errno(&mysql);
}

bool MySQL_DB::update(const char *tableName, const char *valueFormat)
{
	std::string sqlString = "UPDATE";

	sqlString = sqlString + " " + tableName + " " + valueFormat;
	if (mysql_query(&mysql, sqlString.c_str()) != 0) {
        LOG_OUT(ERROR, "update() failed! \n");
        LOG_OUT(ERROR, "Reason: %s \n", mysql_error(&mysql));
        LOG_OUT(ERROR, "Statements: %s \n", sqlString.c_str());
		return false;
	}

	return true;
}

bool MySQL_DB::alterTable(const char *tableName, const char *format)
{
	std::string sqlString = "ALTER TABLE";

	sqlString = sqlString + " " + tableName + " " + format;
	if (mysql_query(&mysql, sqlString.c_str()) != 0) {
        LOG_OUT(ERROR, "alterTable() failed! \n");
        LOG_OUT(ERROR, "Reason: %s \n", mysql_error(&mysql));
        LOG_OUT(ERROR, "Statements: %s \n", sqlString.c_str());
		return false;
	}

	return true;
}
