#include "jsonMaker.h"

std::map<std::string,std::string> cyyxx;
jsonMaker::jsonMaker()
{

}

bool jsonMaker::readJson(char *filename)
{

    Json::Value jsonroot;
    Json::Reader reader;
    ifstream ifs(filename,ios::binary);
    if( !ifs.is_open() )
    {
        LOG_OUT(ERROR,"配置文件不存在,请重新配置配置文件:config.json !!!\n");
        makeJson();
        return false;
    }
    if(reader.parse(ifs, jsonroot)){
        serviceConfigure.city = jsonroot["01:city"].asString();
        serviceConfigure.qsrqOffset = jsonroot["02:开始时间"].asInt();
        serviceConfigure.zzrqOffset = jsonroot["03:结束时间"].asInt();
        serviceConfigure.qsrq = GetCurrentTime(serviceConfigure.qsrqOffset);
        serviceConfigure.zzrq = GetCurrentTime(serviceConfigure.zzrqOffset);
        serviceConfigure.zplx = jsonroot["04:照片类型"].asInt();
        serviceConfigure.startTime = jsonroot["05:工作开始时间"].asInt();
        serviceConfigure.endTime = jsonroot["06:工作结束时间"].asInt();
        serviceConfigure.soapIp = jsonroot["10:soapIP"].asString();
        serviceConfigure.remoteIp = jsonroot["11:remoteIP"].asString();
        serviceConfigure.soapurl = jsonroot["12:soapUri"].asString();
        serviceConfigure.soapovertime = jsonroot["13:soap超时时间"].asString();
        serviceConfigure.soapnum = jsonroot["14:soap流水号查询数量"].asString();
        serviceConfigure.soapxlh = jsonroot["15:soap序列号"].asString();
        serviceConfigure.soapquery = jsonroot["16:soap查询接口号"].asString();
        serviceConfigure.soapwrite = jsonroot["17:soap回复接口号"].asString();
        serviceConfigure.photoFile = jsonroot["18:图片存放位置"].asString();
        int slavenumber = jsonroot["19:主从机编号"].asInt();
        if(slavenumber == -1)
        {
            serviceConfigure.is_master = false;
            serviceConfigure.masterIP = jsonroot["20:配置"]["1:IP"].asString();
        }
        else if(slavenumber == 0)
        {
            serviceConfigure.is_master = true;
        }
        else
        {
            serviceConfigure.is_master = true;
            for(int i = slavenumber ;i > 0 ;i --)
            {
                string count = to_string(i);
                count += ":IP";
                string slaveip = jsonroot["20:配置"][count].asString();
                if(!slaveip.empty())
                {
                    serviceConfigure.slaveIP.push_back(slaveip);
                }
            }
        }
        config.m_zuoqianfang.chepai = (jsonroot["31:左前方照片"]["2:车牌号"].asInt() == 1) ? true:false;
        config.m_zuoqianfang.chebiao = (jsonroot["31:左前方照片"]["3:车辆品牌"].asInt() == 1) ? true:false;
        config.m_zuoqianfang.sanjiaojia = (jsonroot["31:左前方照片"]["4:三角架"].asInt() == 1) ? true:false;
        config.m_zuoqianfang.gaizhuang = (jsonroot["31:左前方照片"]["5:改装检测"].asInt() == 1) ? true:false;

        config.m_youhoufang.chepai = (jsonroot["32:右后方照片"]["2:车牌号"].asInt() == 1) ? true:false;
        config.m_youhoufang.chebiao = (jsonroot["32:右后方照片"]["3:车辆品牌"].asInt() == 1) ? true:false;
        config.m_youhoufang.sanjiaojia = (jsonroot["32:右后方照片"]["4:三角架"].asInt() == 1) ? true:false;
        config.m_youhoufang.gaizhuang = (jsonroot["32:右后方照片"]["5:改装检测"].asInt() == 1) ? true:false;

        config.m_chejiahao.chejiahao = (jsonroot["33:车架号照片"]["2:车架号"].asInt() == 1) ? true:false;

        config.m_cheliangmingpai.cheliangpinpai = (jsonroot["34:车辆铭牌照片"]["2:车辆品牌"].asInt() == 1) ? true:false;
        config.m_cheliangmingpai.cheliangxinghao = (jsonroot["34:车辆铭牌照片"]["3:车辆型号"].asInt() == 1) ? true:false;
        config.m_cheliangmingpai.lishimingpai = (jsonroot["34:车辆铭牌照片"]["4:历史铭牌"].asInt() == 1) ? true:false;
        //config.m_cheliangmingpai.fadongjihao = (jsonroot["34:车辆铭牌照片"]["4:发动机号"].asInt() == 1) ? true:false;
        config.m_cheliangmingpai.fadongjixinghao = (jsonroot["34:车辆铭牌照片"]["5:发动机型号"].asInt() == 1) ? true:false;
        config.m_cheliangmingpai.hedingzaike = (jsonroot["34:车辆铭牌照片"]["6:核定载客"].asInt() == 1) ? true:false;
        config.m_cheliangmingpai.gonglv = (jsonroot["34:车辆铭牌照片"]["7:功率"].asInt() == 1) ? true:false;
        config.m_cheliangmingpai.pailiang = (jsonroot["34:车辆铭牌照片"]["8:排量"].asInt() == 1) ? true:false;
        config.m_cheliangmingpai.zhizaoguo = (jsonroot["34:车辆铭牌照片"]["9:制造国"].asInt() == 1) ? true:false;
        config.m_cheliangmingpai.chejiahao = (jsonroot["34:车辆铭牌照片"]["10:车架号"].asInt() == 1) ? true:false;

        config.m_luntaiguige.ltgg = (jsonroot["35:轮胎规格照片"]["2:轮胎规格"].asInt() == 1) ? true:false;

        config.m_fadongjihao.fadongjihao = (jsonroot["36:发动机号照片"]["2:发动机号"].asInt() == 1) ? true:false;

        config.m_diandongchechazuo.exist = (jsonroot["37:电动车插座照片"]["2:检测是否存在"].asInt() == 1) ? true:false;

        config.m_anquandai.exist = (jsonroot["38:安全带照片"]["2:是否存在"].asInt() == 1) ? true:false;

        config.m_chayanyuan.same = (jsonroot["39:查验员照片"]["2:是否一致"].asInt() == 1) ? true:false;

        serviceConfigure.picCode.zqf = jsonroot["31:左前方照片"]["1:照片编号"].asString();
        serviceConfigure.picCode.yhf = jsonroot["32:右后方照片"]["1:照片编号"].asString();
        serviceConfigure.picCode.cjh = jsonroot["33:车架号照片"]["1:照片编号"].asString();
        serviceConfigure.picCode.clmp = jsonroot["34:车辆铭牌照片"]["1:照片编号"].asString();
        serviceConfigure.picCode.ltgg = jsonroot["35:轮胎规格照片"]["1:照片编号"].asString();
        serviceConfigure.picCode.fdjh = jsonroot["36:发动机号照片"]["1:照片编号"].asString();
        serviceConfigure.picCode.ddccz = jsonroot["37:电动车插座照片"]["1:照片编号"].asString();
        serviceConfigure.picCode.aqd   = jsonroot["38:安全带照片"]["1:照片编号"].asString();
        serviceConfigure.picCode.cyyzp = jsonroot["39:查验员照片"]["1:照片编号"].asString();

        serviceConfigure.picCode.syrzp = jsonroot["40:代理人照片"]["1:照片编号"].asString();

        serviceConfigure.picCode.gcfp = jsonroot["41:购车发票照片"]["1:照片编号"].asString();
        config.m_gouchefapiao.suoyouren = (jsonroot["41:购车发票照片"]["2:所有人"].asInt() == 1) ? true:false;
        config.m_gouchefapiao.shenfenzhenghao = (jsonroot["41:购车发票照片"]["3:身份证号"].asInt() == 1) ? true:false;
        config.m_gouchefapiao.hegezhenghao = (jsonroot["41:购车发票照片"]["4:合格证号"].asInt() == 1) ? true:false;
        config.m_gouchefapiao.chejiahao = (jsonroot["41:购车发票照片"]["5:车架号"].asInt() == 1) ? true:false;
        config.m_gouchefapiao.fadongjihao = (jsonroot["41:购车发票照片"]["6:发动机号"].asInt() == 1) ? true:false;
        config.m_gouchefapiao.guoshuiyinzhang = (jsonroot["41:购车发票照片"]["7:国税印章"].asInt() == 1) ? true:false;
        config.m_gouchefapiao.xiaoshoudanwei = (jsonroot["41:购车发票照片"]["8:销售单位名称"].asInt() == 1) ? true:false;


        serviceConfigure.picCode.sfz = jsonroot["42:身份证照片"]["1:照片编号"].asString();
        config.m_shenfenzheng.front = (jsonroot["42:身份证照片"]["2:正面"].asInt() == 1) ? true:false;
        config.m_shenfenzheng.back = (jsonroot["42:身份证照片"]["3:背面"].asInt() == 1) ? true:false;
        config.m_shenfenzheng.valid = (jsonroot["42:身份证照片"]["4:有效期"].asInt() == 1) ? true:false;
        config.m_shenfenzheng.xingming = (jsonroot["42:身份证照片"]["5:姓名"].asInt() == 1) ? true:false;


        serviceConfigure.picCode.hbd = jsonroot["43:水车环保清单照片"]["1:照片编号"].asString();
        config.m_huanbaoqingdan.chejiahao = (jsonroot["43:水车环保清单照片"]["2:车架号"].asInt() == 1) ? true:false;
        config.m_huanbaoqingdan.yinzhang = (jsonroot["43:水车环保清单照片"]["3:印章"].asInt() == 1) ? true:false;
        config.m_huanbaoqingdan.xinnenyuanche = (jsonroot["43:水车环保清单照片"]["4:新能源备注"].asInt() == 1) ? true:false;


        serviceConfigure.picCode.jkpz = jsonroot["44:进口凭证照片"]["1:照片编号"].asString();
        config.m_jinkoupingzheng.yinzhang = (jsonroot["44:进口凭证照片"]["2:印章"].asInt() == 1) ? true:false;
        config.m_jianyanbaogao.chejiahao = (jsonroot["44:进口凭证照片"]["3:车架号"].asInt() == 1) ? true:false;


        serviceConfigure.picCode.jybg = jsonroot["45:机动车安全技术检验报告照片"]["1:照片编号"].asString();
        config.m_jianyanbaogao.jianyanbaogao = (jsonroot["45:机动车安全技术检验报告照片"]["2:检验报告"].asInt() == 1) ? true:false;     //is 'chepai' and 'chejiahao' correct
        config.m_jianyanbaogao.qianming = (jsonroot["45:机动车安全技术检验报告照片"]["3:签名"].asInt() == 1) ? true:false;          //if 'qianming' exist
        config.m_jianyanbaogao.hongzhang = (jsonroot["45:机动车安全技术检验报告照片"]["4:红色印章"].asInt() == 1) ? true:false;         //if 'hongzhang' exist
        config.m_jianyanbaogao.jianyanjielun = (jsonroot["45:机动车安全技术检验报告照片"]["5:检验结论"].asInt() == 1) ? true:false;     //if 'jianyanjielun' pass
        config.m_jianyanbaogao.jianyan_info = (jsonroot["45:机动车安全技术检验报告照片"]["6:检验信息"].asInt() == 1) ? true:false;      //if 'jianyaninfo' pass
        config.m_jianyanbaogao.chepai = (jsonroot["45:机动车安全技术检验报告照片"]["7:车牌"].asInt() == 1) ? true:false;            //is 'chepai' correct
        config.m_jianyanbaogao.chejiahao = (jsonroot["45:机动车安全技术检验报告照片"]["8:车架号"].asInt() == 1) ? true:false;         //is 'chejiahao' correct
        config.m_jianyanbaogao.MA = (jsonroot["45:机动车安全技术检验报告照片"]["9:MA印章"].asInt() == 1) ? true:false;                //if 'MA zhang' exist
        config.m_jianyanbaogao.querenzhang = (jsonroot["45:机动车安全技术检验报告照片"]["10:确认印章"].asInt() == 1) ? true:false;       //if 'cheliang weiyi querenzhang' exist	by gwx
        config.m_jianyanbaogao.chepai_type = (jsonroot["45:机动车安全技术检验报告照片"]["11:车辆型号"].asInt() == 1) ? true:false;       //is 'chepai_type' correct
        config.m_jianyanbaogao.jianyanriqi = (jsonroot["45:机动车安全技术检验报告照片"]["12:检验日期"].asInt() == 1) ? true:false;
        config.m_jianyanbaogao.CMA = (jsonroot["45:机动车安全技术检验报告照片"]["13:CMA印章"].asInt() == 1) ? true:false;
        config.m_jianyanbaogao.cheliangtu = (jsonroot["45:机动车安全技术检验报告照片"]["14:车辆图"].asInt() == 1) ? true:false;


        serviceConfigure.picCode.wszm = jsonroot["46:购置税完税证明照片"]["1:照片编号"].asString();
        config.m_gouzhishui.chepai = (jsonroot["46:购置税完税证明照片"]["2:车牌"].asInt() == 1) ? true:false;
        config.m_gouzhishui.chejiahao = (jsonroot["46:购置税完税证明照片"]["3:车架号"].asInt() == 1) ? true:false;
        config.m_gouzhishui.valid_data = (jsonroot["46:购置税完税证明照片"]["4:无效数据"].asInt() == 1) ? true:false;
        config.m_gouzhishui.chechuanshui = (jsonroot["46:购置税完税证明照片"]["5:车船税"].asInt() == 1) ? true:false;
        config.m_gouzhishui.zhengnian = (jsonroot["46:购置税完税证明照片"]["6:整年"].asInt() == 1) ? true:false;
        config.m_gouzhishui.wanshuizhengming = (jsonroot["46:购置税完税证明照片"]["7:不是完税证明"].asInt() == 1) ? true:false;

        serviceConfigure.picCode.hgz = jsonroot["47:出厂合格证照片"]["1:照片编号"].asString();
        config.m_chuchanghegezheng.cheliangpinpai = (jsonroot["47:出厂合格证照片"]["2:车辆品牌"].asInt() == 1) ? true:false;
        config.m_chuchanghegezheng.cheliangxinghao = (jsonroot["47:出厂合格证照片"]["3:车辆型号"].asInt() == 1) ? true:false;
        config.m_chuchanghegezheng.chejiahao = (jsonroot["47:出厂合格证照片"]["4:车架号"].asInt() == 1) ? true:false;
        config.m_chuchanghegezheng.fadongjixinghao = (jsonroot["47:出厂合格证照片"]["5:发动机型号"].asInt() == 1) ? true:false;
        config.m_chuchanghegezheng.fadongjihao = (jsonroot["47:出厂合格证照片"]["6:发动机号"].asInt() == 1) ? true:false;
        config.m_chuchanghegezheng.ranliaozhonglei = (jsonroot["47:出厂合格证照片"]["7:燃料种类"].asInt() == 1) ? true:false;
        config.m_chuchanghegezheng.luntaiguige = (jsonroot["47:出厂合格证照片"]["8:轮胎规格"].asInt() == 1) ? true:false;
        config.m_chuchanghegezheng.hedingzaike = (jsonroot["47:出厂合格证照片"]["9:核定载客"].asInt() == 1) ? true:false;
        config.m_chuchanghegezheng.zhizaoriqi = (jsonroot["47:出厂合格证照片"]["10:制造日期"].asInt() == 1) ? true:false;
        config.m_chuchanghegezheng.yinzhang = (jsonroot["47:出厂合格证照片"]["11:印章"].asInt() == 1) ? true:false;



        serviceConfigure.picCode.yzxzs = jsonroot["48:车辆一致性照片"]["1:照片编号"].asString();
        config.m_cheliangyizhixing.yinzhang = (jsonroot["48:车辆一致性照片"]["2:印章"].asInt() == 1) ? true:false;
        config.m_cheliangyizhixing.chejiahao = (jsonroot["48:车辆一致性照片"]["3:车架号"].asInt() == 1) ? true:false;

        serviceConfigure.picCode.cxnb = jsonroot["49:车厢内部照片"]["1:照片编号"].asString();

    }
    else{
        return false;
    }
    return true;
}

//读取济南安卓IP配置文件
bool jsonMaker::readJsonJiNan(char *filename)
{

    Json::Value jsonroot;
    Json::Reader reader;
    ifstream ifs(filename,ios::binary);
    int sumcount;
    if( !ifs.is_open() )
    {
        return false;
    }
    if(reader.parse(ifs,jsonroot))
    {
        androidIP[0]["0"] = jsonroot["发送信息至屏幕"].asString();
        serviceConfigure.andirod_wait_time = jsonroot["等待数据回复时间"].asInt();
        sumcount = jsonroot["设备总数"].asInt();
        for(int i = sumcount;i > 0;i--)
        {
            std::string count = "设备编号"+to_string(sumcount-i+1);
            int gongweiID = jsonroot[count]["工位ID"].asInt();
            std::string gongweiIP = jsonroot[count]["工位IP"].asString();
            androidIP[static_cast<size_t>(sumcount-i+1)][to_string(gongweiID)] = gongweiIP;
        }
        sumcount = 0;
        sumcount = jsonroot["查验员总数"].asInt();
        for(int i = sumcount;i > 0;i--)
        {
           std::string name = jsonroot["查验员信息"][to_string(sumcount-i+1)]["姓名"].asString();
           std::string code = jsonroot["查验员信息"][to_string(sumcount-i+1)]["证件号"].asString();
           if("3301"==serviceConfigure.city)
           {
               std::string strvalue=to_string(sumcount-i+1)+","+name;
               cyyxx[code] = strvalue;
           }
           else
               cyyxx[code] = name;
        }

    }

    return true;
}

void jsonMaker::makeJson()
{
    Json::Value jsonroot;

    jsonroot["01:city"]="3701";
    jsonroot["02:开始时间"]=-5;
    jsonroot["03:结束时间"]=1;
    jsonroot["04:照片类型"]=1;
    jsonroot["10:soapIP"]="0.0.0.0:9080";
    jsonroot["11:remoteIP"]="0.0.0.0:9080";
    jsonroot["12:soapUri"]="TmriOutAccess.asmx/writeObjectOuts";
    jsonroot["13:soap超时时间"]="30";
    jsonroot["14:soap流水号查询数量"]="10";
    jsonroot["15:soap序列号"]="63F414CB10CA08494F237C90643083EB";
    jsonroot["16:soap查询接口号"]="18CK3";
    jsonroot["17:soap回复接口号"]="18CL2";
    jsonroot["18:图片存放位置"]="/opt/vehicle/vehicle_photo/";
    jsonroot["19:主从机编号"]=0;
    Json::Value jsonItem;
    jsonItem["1:IP"]= "192.168.40.21:9000";
    jsonItem["2:IP"]= "192.168.40.21:9000";
    jsonroot["20:配置"] = jsonItem;
    jsonItem.clear();

    jsonItem["1:照片编号"] = "0198";
    jsonItem["2:车牌号"] = 0;
    jsonItem["3:车辆品牌"] = 0;
    jsonItem["4:三角架"] = 0;
    jsonItem["5:改装检测"] = 0;
    jsonroot["31:左前方照片"] = jsonItem;
    jsonItem.clear();

    jsonItem["1:照片编号"] = "0102";
    jsonItem["2:车牌号"] = 0;
    jsonItem["3:车辆品牌"] = 0;
    jsonItem["4:三角架"] = 0;
    jsonItem["5:改装检测"] = 0;
    jsonroot["32:右后方照片"] = jsonItem;
    jsonItem.clear();

    jsonItem["1:照片编号"] = "0103";
    jsonItem["2:车架号"] = 0;
    jsonroot["33:车架号照片"] = jsonItem;
    jsonItem.clear();


    jsonItem["1:照片编号"] = "0105";
    jsonItem["2:车辆品牌"] = 0;
    jsonItem["3:车辆型号"] = 0;
    jsonItem["4:发动机号"] = 0;
    jsonItem["5:发动机型号"] = 0;
    jsonItem["6:核定载客"] = 0;
    jsonItem["7:功率"] = 0;
    jsonItem["8:排量"] = 0;
    jsonItem["9:制造国"] = 0;
    jsonroot["34:车辆铭牌照片"] = jsonItem;
    jsonItem.clear();


    jsonItem["1:照片编号"] = "0106";
    jsonItem["2:轮胎规格"] = 0;
    jsonroot["35:轮胎规格照片"] = jsonItem;
    jsonItem.clear();


    Json::StyledWriter writer;
    string json = writer.write(jsonroot);
    ofstream ofs;
    ofs.open("config.json");
    ofs << json;
    ofs.close();
}


std::string jsonMaker::GetCurrentTime(int time_count)
{
    time_t timeinfo = time(nullptr);

    timeinfo += (time_count*86400);


    tm* t_tm = localtime(&timeinfo);

    char current_time[256];
    sprintf(current_time,"%d-%02d-%02d",t_tm->tm_year+1900,t_tm->tm_mon+1,t_tm->tm_mday);

    return  static_cast<std::string>(current_time);


}
