#ifndef PROCESSPHOTO_H
#define PROCESSPHOTO_H
#include "vehicle_info.h"
#include "picture_code.h"
#include "Log.h"
#include "large_vehicle_api.hpp"
#include "Queue.h"
#include "configfile.h"
#define RESULT_OK 0
#define RESULL_FAIL 1
#define PASS        "1"
#define NOPASS      "5"
#define UNDOWNLOAD  "0"
#define UNKOWN      "0"
class service;

class processPhoto
{
public:

    processPhoto(picture_code pic_code,int GPUid,LargeVehicleApi *alg_api,zplx is_zplx_check);
    virtual ~processPhoto();

    cv::Mat input_img;
    LargeVehicleApi* alg;
    Vehicle_Info* pvehicle_info;
    picture_code pictureCode;
    zplx check_zplx;

    int GPU_ID;
    unsigned int vehicle_check();
    unsigned int startProcessPhoto();

    virtual unsigned int vehicle_check_zqf(unsigned int index,Cheliang_ImgOutMsg zqf_out_img);//左前方处理
    virtual unsigned int vehicle_check_yhf(unsigned int index,Cheliang_ImgOutMsg yhf_process_out);//右后方处理
    virtual unsigned int vehicle_check_cjh(unsigned int index,Chejiahao_ImgOutMsg chejiahao_process_out);//车架号处理
    virtual unsigned int vehicle_check_cxnb(unsigned int index,Huochexiang_ImgOutMsg cxnb_process_out);//车厢内部处理
    virtual unsigned int vehicle_check_clmp(unsigned int index,Mingpai_OutMsg mingpai_process_out);//车辆铭牌处理
    virtual unsigned int vehicle_check_fdjh(unsigned int index,Fadongjihao_OutMsg fdjh_process_out);//发动机号处理
    virtual unsigned int vehicle_check_ltgg(unsigned int index,Luntaiguige_ImgOutMsg luntaiguige_process_out);//轮胎规格处理
    virtual unsigned int vehicle_check_ddccz(unsigned int index,Socket_ImgOutMsg ddccz_process_out);//电动车插座处理
    virtual unsigned int vehicle_check_aqd(unsigned int index,Anquandai_ImgOutMsg aqd_process_out);//安全带处理
    virtual unsigned int vehicle_check_syrzp(unsigned int index);
    virtual unsigned int vehicle_check_cyyzp(unsigned int index,Chayanyuan_OutMsg cyy_process_out);

    virtual unsigned int vehicle_check_gcfp(unsigned int index);
    virtual unsigned int vehicle_check_sfz(unsigned int index);
    virtual unsigned int vehicle_check_hbd(unsigned int index);
    virtual unsigned int vehicle_check_jkpz(unsigned int index);
    virtual unsigned int vehicle_check_jybg(unsigned int index);
    virtual unsigned int vehicle_check_wszm(unsigned int index);
    virtual unsigned int vehicle_check_hgz(unsigned int index);
    virtual unsigned int vehicle_check_yzxzs(unsigned int index);

    virtual unsigned int vehicle_is_pass();//整车通过判定
    bool filterChePai(Vehicle_Info* pvehicle_info);
};

#endif // PROCESSPHOTO_H
