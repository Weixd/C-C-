#include "TimeRecord.h"
TimeRecord::TimeRecord()
{
	total = "NULL";
	total_no_wait = "NULL";
	wait_queue = "NULL";

	picture.AllDownload = "NULL";

	picture.process.xsz = "NULL";
	picture.process.sqb = "NULL";
	picture.process.jqx = "NULL";
	picture.process.jybg = "NULL";
	picture.process.cyjl = "NULL";
	picture.process.zqf = "NULL";
	picture.process.yhf = "NULL";
	picture.process.cjh = "NULL";
	picture.process.aqd = "NULL";
	picture.process.zdg = "NULL";
	picture.process.ydg = "NULL";
	picture.process.yzzd = "NULL";
	picture.process.ezzd = "NULL";
	picture.process.zczd = "NULL";
	picture.process.dpdtks = "NULL";
	picture.process.dpdtjs = "NULL";
	picture.process.dpjy = "NULL";
	picture.process.wqjy = "NULL";
	
	picture.process.mhq = "NULL";
	picture.process.yjc = "NULL";
	picture.process.jly = "NULL";
	picture.process.zql = "NULL";
	picture.process.yql = "NULL";
	
    picture.process.xszbk = "NULL";
    picture.process.jyb_bk = "NULL";
    picture.process.wts = "NULL";
    picture.process.zqfcf = "NULL";
    picture.process.yhfcf = "NULL";
    picture.process.cjhcf = "NULL";
    picture.process.wszm = "NULL";
    picture.process.wttzs = "NULL";
    picture.process.jyhgzm = "NULL";
    picture.process.hdzk = "NULL";
    picture.process.dchw = "NULL";
    picture.process.sfz = "NULL";
    picture.process.sfzbk = "NULL";
    picture.process.jcqxbg = "NULL";
    picture.process.chexiang = "NULL";
    picture.process.cjh_ug = "NULL";
    picture.process.chgw = "NULL";
    picture.process.waikuoqianmian = "NULL";
    picture.process.waikuocemian = "NULL";
    picture.process.wxnb = "NULL";
    picture.process.fzzd = "NULL";
    picture.process.abs = "NULL";
    picture.process.clcm = "NULL";
    picture.process.cjhyj = "NULL";
    picture.process.qhp = "NULL";
    picture.process.hhp = "NULL";
    picture.process.clbm = "NULL";
    picture.process.dchp = "NULL";


	picture.response.xsz = "NULL";
	picture.response.sqb = "NULL";
	picture.response.jqx = "NULL";
	picture.response.jybg = "NULL";
	picture.response.cyjl = "NULL";
	picture.response.zqf = "NULL";
	picture.response.yhf = "NULL";
	picture.response.cjh = "NULL";
	picture.response.aqd = "NULL";
	picture.response.zdg = "NULL";
	picture.response.ydg = "NULL";
	picture.response.yzzd = "NULL";
	picture.response.ezzd = "NULL";
	picture.response.zczd = "NULL";
	picture.response.dpdtks = "NULL";
	picture.response.dpdtjs = "NULL";
	picture.response.dpjy = "NULL";
	picture.response.wqjy = "NULL";

	picture.response.mhq = "NULL";
	picture.response.yjc = "NULL";
	picture.response.jly = "NULL";
	picture.response.zql = "NULL";
	picture.response.yql = "NULL";

	video.process.zqf = "NULL";
	video.process.yhf = "NULL";
	video.process.pbzd = "NULL";
	video.process.yzzd = "NULL";
	video.process.ezzd = "NULL";
	video.process.zdg = "NULL";
	video.process.ydg = "NULL";
	video.process.dp = "NULL";
	video.process.glzc = "NULL";
	video.process.pbzc = "NULL";
}

TimeRecord::~TimeRecord()
{

}

void TimeRecord::startTime()
{
	start = std::chrono::system_clock::now();
}

void TimeRecord::endTime()
{
	end = std::chrono::system_clock::now();
}

std::string TimeRecord::getTime()
{
	std::chrono::duration<double, std::milli> milliseconds = end - start;
	return std::to_string((unsigned int)milliseconds.count());
}

void TimeRecord::startTime_total()
{
	start_total = std::chrono::system_clock::now();
}

void TimeRecord::endTime_total()
{
	end_total = std::chrono::system_clock::now();
}

std::string TimeRecord::getTime_total()
{
	std::chrono::duration<double, std::milli> milliseconds = end_total - start_total;
	return std::to_string((unsigned int)milliseconds.count());
}
