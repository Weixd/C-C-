#ifndef _LOG_
#define _LOG_

#include <thread>

#include "./glog/logging.h"

/*
类Log用于整个程序的运行日志显示和记录。
该类是对google glog的封装。

注意：
该类已被定义为单例模式。
已屏蔽(声明但不实现)拷贝构造函数和等号的运算符重载。
只能调用成员函数getInstance来获取唯一的对象指针。
*/
class Log {
public:
    /**
     * @brief 获取该类唯一对象。
     * @return 该类唯一对象指针
     */
    static Log *getInstance();

    /**
     * @brief 启动定时清理log文件的线程。
     * @param[in] num 保留的文件数量
     */
    void startCleanThread(unsigned int num);

    /**
     * @brief 设定日志输出等级（终端和后台日志同时设定）
     * @param[in] level 4种等级
     */
    void setLogLevel(int level);

private:
    Log();
    Log(const Log &);
    Log &operator=(const Log &);
    ~Log();
    void cleanThread(unsigned int num);
    void delete_more_file(std::string dir, unsigned int logNum);

private:
    static Log log_obj;
    std::thread *p_clean_thread;
};

/* 限制单条LOG最大16KB，超过的部分不会被输出 */
#define LOG_OUT(level, ...) \
{\
    char gbuf[16 * 1024] = {0};\
    snprintf(gbuf, 16 * 1024, __VA_ARGS__);\
    LOG(level) << gbuf;\
}

#endif	//	_LOG_
