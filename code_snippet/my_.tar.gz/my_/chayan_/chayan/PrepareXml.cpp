#include <stdio.h>
#include "PrepareXml.h"
#include "Log.h"
#include "ZBase64.h"
#include "http_res_def.h"
#include "chayan_main.h"

#define BUFFSIZE 1024
extern configuration serviceConfigure;
extern std::map<std::string,std::string> cyyxx;
void PrepareXML :: setIP(std::string IP)
{
    this->IP = IP;
}

void PrepareXML :: setPort(std::string Port)
{
    this->Port = Port;
}

void PrepareXML :: setRequestUri(std::string RequestUri)
{
    this->RequestUri = RequestUri;
}

PrepareXML::PrepareXML()
{

}

PrepareXML::~PrepareXML()
{

}

std::string PrepareDistributeData::PrepareXml(Vehicle_Info* pVehicle_info)
{
    char url_temp[256];
    sprintf(url_temp, "http://%s", IP.c_str());
    vehicle_url = url_temp; 

    vehicle_url += RequestUri;
    std::string xmldata;

    CMarkup xml;

    xml.SetDoc("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n");
    xml.AddElem("root");
    xml.IntoElem();
    xml.AddElem("code");
    xml.SetData(VHHICLE_ANALYSE_QUEST);
    xml.AddElem("vehicle");
    xml.IntoElem();
    //add basic info
    for(unsigned int i = 0; i < pVehicle_info->item_description.size(); i++)
    {
        std::string vehicle_type = pVehicle_info->item_description[i].name_tag;
        std::string value = *static_cast<std::string*>(pVehicle_info->item_description[i].value);
        xml.AddElem(vehicle_type);
        xml.SetData(value);
        LOG_OUT(INFO,"%s::%s\n",vehicle_type.c_str(),value.c_str());
    }


    //add photo list

    for(unsigned int i = 0;i < pVehicle_info->photo_list.size();i++)
    {
        xml.AddElem("photodes");
        xml.IntoElem();
        xml.AddElem("zpzl");
        xml.SetData(pVehicle_info->photo_list[i].type);
        xml.AddElem("zpurl");
        xml.SetData(pVehicle_info->photo_list[i].url);
        xml.OutOfElem();
        LOG_OUT(INFO,"%s::%s\n",pVehicle_info->photo_list[i].type.c_str(),pVehicle_info->photo_list[i].url.c_str());
    }

    xml.OutOfElem();
    xml.ResetChildPos();

    std::string xmlstring;
    xmlstring = xml.GetDoc();
    return xmlstring;

}

std::string SalveSendResult::PrepareXml(Vehicle_Info* pVehicle_info)
{
    char url_temp[256];
    sprintf(url_temp, "http://%s", IP.c_str());
    vehicle_url = url_temp;

    vehicle_url += RequestUri;
    std::string xmldata;

    CMarkup xml;

    xml.SetDoc("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n");
    xml.AddElem("root");
    xml.IntoElem();
    xml.AddElem("code");
    xml.SetData(PHOTO_PROCESS_RESULT);
    xml.AddElem("vehicle");
    xml.IntoElem();

    for(unsigned int i = 0; i < pVehicle_info->item_description.size(); i++)
    {
        std::string vehicle_type = pVehicle_info->item_description[i].name_tag;
        std::string value = *static_cast<std::string*>(pVehicle_info->item_description[i].value);
        xml.AddElem(vehicle_type);
        xml.SetData(value);
    }
    xml.OutOfElem();

    xml.AddElem("result");
    xml.IntoElem();
    for(unsigned int i = 0;i < pVehicle_info->photo_list.size();i++)
    {
        std::string streason;
        for(unsigned int j = 0;j < pVehicle_info->photo_list[i].detail.size();j++)
        {
            streason += pVehicle_info->photo_list[i].detail[j];
        }

        xml.AddElem("item");
        xml.AddChildElem("zpzl");
        xml.SetChildData(pVehicle_info->photo_list[i].type);
        xml.AddChildElem("jg");
        xml.SetChildData(pVehicle_info->photo_list[i].result);
        xml.AddChildElem("sm");
        xml.SetChildData(streason);
        xml.AddChildElem("url");
        xml.SetChildData(pVehicle_info->photo_list[i].path);
        xml.AddChildElem("time");
        xml.SetChildData(pVehicle_info->photo_list[i].algorithm_process_time);


    }

    xml.OutOfElem();
    xml.ResetChildPos();

    std::string xmlstring;
    xmlstring = xml.GetDoc();
    LOG_OUT(INFO,"Send data is:\n%s\n",xmlstring.c_str());
    return xmlstring;
}


std::string SendResultToAndroid::handlePhoto(std::string photo_localpath)
{
    if (photo_localpath.find("TBD") != std::string::npos) {
        return "";
    }
    //sleep(1);
    FILE *fd = fopen (photo_localpath.c_str(), "rb");
    if(fd ==nullptr)
    {
        return "";
    }
    fseek(fd,0,SEEK_END);
    unsigned int bufSize = static_cast<unsigned int>(ftell(fd));

    rewind(fd);//将文件指针初始化


    void *buff = calloc(1, bufSize);
    if(buff == nullptr)
    {
        LOG_OUT(ERROR,"malloc free!!!\n");
        return "" ;
    }

    fread(buff,1,bufSize,fd);
    std::string photo_result = ZBase64::Encode((const unsigned char *)buff,bufSize);

    if(buff!=nullptr)
    {
        free(buff);
        buff = nullptr;
    }

    fclose(fd);

    return photo_result;
}

std::string SendResultToAndroid::loadPic(Vehicle_Info* pVehicle_info,unsigned int index)
{
    if(pVehicle_info->photo_list[index].path=="TDB")
    {
        return "";
    }

    if(pVehicle_info->device_ip == "127.0.0.1" || pVehicle_info->device_ip=="无数据" || pVehicle_info->device_ip.empty())
    {
        return handlePhoto(pVehicle_info->photo_list[index].path);
    }

    HttpClient DownloadPhoto;
    std::string encodePath = evhttp_encode_uri(pVehicle_info->photo_list[index].path.c_str());
    std::string url = "http://"+pVehicle_info->device_ip+":9001/loadPic?path="+encodePath;
    LOG_OUT(INFO,"SendResultToAndroid::loadPic : %s\n",url.c_str());

    if(DownloadPhoto.InitData(DOWNLOAD_PHOTO_DATA,url.c_str(),REQUEST_POST_FLAG,nullptr,nullptr))
    {
        DownloadPhoto.startHttpClient();

        LOG_OUT(INFO,"DownloadPhoto.ResponseData:%d\n",DownloadPhoto.ResponseData.size());
        if(DownloadPhoto.d_success_flag)
            return DownloadPhoto.ResponseData;
    }

    LOG_OUT(INFO,"SendResultToAndroid::loadPic err url:%s\n",url.c_str());
    return "";
}


void SendResultToAndroid::change_zplx(std::string zplx)
{
    if(zplx == serviceConfigure.picCode.zqf)
    {
        zplx_chinese = "左前方斜视45度照片";
    }
    else if(zplx == serviceConfigure.picCode.yhf)
    {
        zplx_chinese = "右后方斜视45度照片";
    }
    else if(zplx == serviceConfigure.picCode.clmp)
    {
        zplx_chinese = "车辆标牌照片";
    }
    else if(zplx == "H4")
    {     
         zplx_chinese = "历史铭牌照片";
    }
    else if(zplx == serviceConfigure.picCode.cjh)
    {
        zplx_chinese = "车辆识别代号照片";
    }
    else if(zplx == serviceConfigure.picCode.ltgg)
    {
        zplx_chinese = "轮胎规格照片";
    }
    else if(zplx == serviceConfigure.picCode.fdjh)
    {
        zplx_chinese = "发动机(电机)型号和出厂编号照片";
    }
    else if(zplx == serviceConfigure.picCode.ddccz)
    {
        zplx_chinese = "纯电或混电充电口照片";
    }
    else {
        zplx_chinese = "未知照片类型";
    }
}
void SendResultToAndroid::handleYwlx(Vehicle_Info* pVehicle_info,std::string &value)
{
    if(pVehicle_info->ywlx == "A")
    {
        value = "注册登记";
    }
    else if(pVehicle_info->ywlx == "B")
    {
        value = "转移登记";
    }
    else if(pVehicle_info->ywlx == "I")
    {
        value = "转入";
    }
    else if(pVehicle_info->ywlx == "L" and pVehicle_info->ywyy == "C")
    {
        value = "补领登记证书";
    }
    else if(pVehicle_info->ywlx == "V" and pVehicle_info->ywyy == "C")
    {
        value = "加装/拆除操纵辅助装置";
    }
    else if(pVehicle_info->ywlx == "D" and pVehicle_info->ywyy == "D")
    {
        value = "变更车身颜色";
    }
    else if(pVehicle_info->ywlx == "D" and pVehicle_info->ywyy == "L")
    {
        value = "重新打刻发动机号";
    }
    else if(pVehicle_info->ywlx == "D" and pVehicle_info->ywyy == "F")
    {
        value = "更换发动机";
    }
    else if(pVehicle_info->ywlx == "D" and pVehicle_info->ywyy == "K")
    {
        value = "重新打刻VIN";
    }
    else if(pVehicle_info->ywlx == "D" and pVehicle_info->ywyy == "I")
    {
        value = "变更使用性质";
    }
    else if(pVehicle_info->ywlx == "D" and pVehicle_info->ywyy == "J")
    {
        value = "变更迁出";
    }
    else if(pVehicle_info->ywlx == "D" and pVehicle_info->ywyy == "G")
    {
        value = "变更车身或者车架";
    }

}

void change_index(Vehicle_Info* pVehicle_info,unsigned int i,unsigned int j)
{
   Photo temp_photo;
   temp_photo = pVehicle_info->photo_list[i];
   pVehicle_info->photo_list[i] = pVehicle_info->photo_list[j];
   pVehicle_info->photo_list[j] = temp_photo;
}

void compare_index(std::vector<Photo> &temp_info,Vehicle_Info* pvehicle_info)
{
    for(unsigned int i = 0;i < temp_info.size();i++)
    {
        for(unsigned int j = i+1;j < temp_info.size();j++)
        {
            if(temp_info[i].index > temp_info[j].index)
            {
                Photo temp_photo;
                temp_photo = temp_info[i];
                temp_info[i] = temp_info[j];
                temp_info[j] = temp_photo;
            }
        }
    }
}
void SendResultToAndroid::sort_picture(Vehicle_Info* pVehicle_info)
{
    for(unsigned int i = 0;i < pVehicle_info->photo_list.size();i++)
    {
        pVehicle_info->photo_list[i].index = 0;
        if(pVehicle_info->photo_list[i].type == serviceConfigure.picCode.zqf)
        {
            pVehicle_info->photo_list[i].index = 1;
        }
        else if(pVehicle_info->photo_list[i].type == serviceConfigure.picCode.yhf)
        {
            pVehicle_info->photo_list[i].index = 2;
        }
        else if(pVehicle_info->photo_list[i].type == serviceConfigure.picCode.cjh)
        {
            pVehicle_info->photo_list[i].index = 3;
        }
        else if(pVehicle_info->photo_list[i].type == serviceConfigure.picCode.fdjh)
        {
            pVehicle_info->photo_list[i].index = 4;
        }
        else if(pVehicle_info->photo_list[i].type == serviceConfigure.picCode.clmp)
        {
            pVehicle_info->photo_list[i].index = 5;
        }
        else if(pVehicle_info->photo_list[i].type == serviceConfigure.picCode.ltgg)
        {
            pVehicle_info->photo_list[i].index = 6;
        }
        else if(pVehicle_info->photo_list[i].type == serviceConfigure.picCode.ddccz)
        {
            pVehicle_info->photo_list[i].index = 7;
        }
        else if(pVehicle_info->photo_list[i].type == "H4")
        {
            pVehicle_info->photo_list[i].index = 8;
        }
    }

    std::vector<Photo> nopass_temp;
    for(unsigned int i = 0;i < pVehicle_info->photo_list.size();i++)
    {
        if(pVehicle_info->photo_list[i].result == NOPASS)
        {
            nopass_temp.push_back(pVehicle_info->photo_list[i]);
        }
    }
    std::vector<Photo> unkown_temp;
    for(unsigned int i = 0;i < pVehicle_info->photo_list.size();i++)
    {
        if(pVehicle_info->photo_list[i].result == UNKOWN)
        {
            unkown_temp.push_back(pVehicle_info->photo_list[i]);
        }
    }

    std::vector<Photo> pass_temp;
    for(unsigned int i = 0;i < pVehicle_info->photo_list.size();i++)
    {
        if(pVehicle_info->photo_list[i].result == PASS)
        {
            pass_temp.push_back(pVehicle_info->photo_list[i]);
        }
    }


    compare_index(pass_temp,pVehicle_info);
    compare_index(nopass_temp,pVehicle_info);
    compare_index(unkown_temp,pVehicle_info);


    pVehicle_info->photo_list.clear();

    for(unsigned int i = 0;i < nopass_temp.size();i++)
    {
        pVehicle_info->photo_list.push_back(nopass_temp[i]);
    }
    for(unsigned int i = 0;i < unkown_temp.size();i++)
    {
        pVehicle_info->photo_list.push_back(unkown_temp[i]);
    }
    for(unsigned int i = 0;i < pass_temp.size();i++)
    {
        pVehicle_info->photo_list.push_back(pass_temp[i]);
    }
    /*第一次排序，按照顺序进行*/
   /* for(unsigned int i = 0;i < pVehicle_info->photo_list.size();i++)
    {
        for(unsigned int j = i;j<pVehicle_info->photo_list.size();j++)
        {
            if(pVehicle_info->photo_list[j].type == serviceConfigure.picCode.zqf)
            {
                change_index(pVehicle_info,0,j);break;

            }
            else if(pVehicle_info->photo_list[j].type == serviceConfigure.picCode.yhf)
            {
                change_index(pVehicle_info,1,j);break;

            }
            else if(pVehicle_info->photo_list[j].type == serviceConfigure.picCode.cjh)
            {
                change_index(pVehicle_info,2,j);break;

            }
            else if(pVehicle_info->photo_list[j].type == serviceConfigure.picCode.clmp)
            {
                change_index(pVehicle_info,3,j);break;

            }
            else if(pVehicle_info->photo_list[j].type == serviceConfigure.picCode.fdjh)
            {
                change_index(pVehicle_info,4,j);break;

            }
            else if(pVehicle_info->photo_list[j].type == serviceConfigure.picCode.ltgg)
            {
                change_index(pVehicle_info,5,j);break;

            }
            else if(pVehicle_info->photo_list[j].type == serviceConfigure.picCode.ddccz)
            {
                change_index(pVehicle_info,6,j);break;
            }
        }
    }*/
/*
    unsigned int i = 0;
    for(unsigned int j = 0;j<pVehicle_info->photo_list.size();j++)
    {
        if(pVehicle_info->photo_list[j].result == UNKOWN)
        {
            change_index(pVehicle_info,i,j);
            i++;
        }
    }

    i = 0;

    for(unsigned int j = 0;j<pVehicle_info->photo_list.size();j++)
    {
        if(pVehicle_info->photo_list[j].result == NOPASS)
        {
            change_index(pVehicle_info,i,j);
            i++;
        }
    }
*/

}
std::string SendResultToAndroid::PrepareXml(Vehicle_Info* pVehicle_info)
{

    std::string xmldata;

    CMarkup xml;
    xml.SetDoc("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n");
    xml.AddElem("root");
    xml.IntoElem();
    xml.AddElem("code");
    xml.SetData(REPLY_ANDROID);
    xml.AddElem("vehicle");
    xml.IntoElem();

    for(unsigned int i = 0; i < pVehicle_info->item_description.size(); i++)
    {
        std::string vehicle_type = pVehicle_info->item_description[i].name_tag;
        std::string value = *static_cast<std::string*>(pVehicle_info->item_description[i].value);
        if(vehicle_type == "ywlx")
        {
            handleYwlx(pVehicle_info,value);
        }
        if(vehicle_type == "cyry")//将查验员身份证号码转换为姓名
        {
            if(HANGZHOU==serviceConfigure.city)
            {
                std::string picid_name=cyyxx[value];
                size_t pos=picid_name.find(",");
                size_t iend=picid_name.size();
                value=picid_name.substr(pos+1,iend);

            }
            else
                value = cyyxx[value];
            if(value == "")
            {
                value = "查验员";
            }
        }

        xml.AddElem(vehicle_type);
        xml.SetData(value);
    }
    xml.OutOfElem();

    xml.AddElem("result");
    xml.IntoElem();
    //先得到A，J和公告照片的编码
    std::map<std::string,std::string> compare_photo_encode;//存放所有对比照片的容器
    for(unsigned int i = 0;i < pVehicle_info->photo_list.size();i++)
    {
        if(pVehicle_info->photo_list[i].type == "A")
        {
            compare_photo_encode["D左前方档案照片"] = loadPic(pVehicle_info,i);
        }
        else if(pVehicle_info->photo_list[i].type == "J")
        {
            compare_photo_encode["E拓印膜档案照片"] = loadPic(pVehicle_info,i);
        }
        else if(pVehicle_info->photo_list[i].type == "G1")
        {
            compare_photo_encode["F公告照片G1"] = loadPic(pVehicle_info,i);
        }
        else if(pVehicle_info->photo_list[i].type == "G2")
        {
            compare_photo_encode["G公告照片G2"] = loadPic(pVehicle_info,i);
        }
        else if(pVehicle_info->photo_list[i].type == "G3")
        {
            compare_photo_encode["H公告照片G3"] = loadPic(pVehicle_info,i);
        }
        else if(pVehicle_info->photo_list[i].type == "G4")
        {
            compare_photo_encode["I公告照片G4"] = loadPic(pVehicle_info,i);
        }
        else if(pVehicle_info->photo_list[i].type == "G5")
        {
            compare_photo_encode["J公告照片G5"] = loadPic(pVehicle_info,i);
        }
        else if(pVehicle_info->photo_list[i].type == "G6")
        {
            compare_photo_encode["K公告照片G6"] = loadPic(pVehicle_info,i);
        }
        else if(pVehicle_info->photo_list[i].type == "H1")
        {
            compare_photo_encode["A历史左前方照片"] = loadPic(pVehicle_info,i);
        }
        else if(pVehicle_info->photo_list[i].type == "H2")
        {
            compare_photo_encode["B历史右后方照片"] = loadPic(pVehicle_info,i);
        }
        else if(pVehicle_info->photo_list[i].type == "H3")
        {
            compare_photo_encode["C历史车架号照片"] = loadPic(pVehicle_info,i);
        }
        else if(pVehicle_info->photo_list[i].type == "H4")
        {
            compare_photo_encode["L历史铭牌照片"] = loadPic(pVehicle_info,i);
        }
    }
    sort_picture(pVehicle_info);
    for(unsigned int i = 0;i < pVehicle_info->photo_list.size();i++)
    {
        /*依次遍历照片，得到编码值*/
        std::string zptype = pVehicle_info->photo_list[i].type;
        change_zplx(zptype);
        if(
                (zptype[0] >= '0' and zptype[0] <= '9')
                ||(zptype[0] == 'A'&&zptype.size() >1)
          )
        {
            std::string encode_value = loadPic(pVehicle_info,i);
            std::string streason;
            for(unsigned int j = 0;j < pVehicle_info->photo_list[i].detail.size();j++)
            {
                streason += pVehicle_info->photo_list[i].detail[j];
            }

            xml.AddElem("item");
            xml.AddChildElem("zpzl");
            xml.SetChildData(zplx_chinese);
            xml.AddChildElem("jg");
            if (pVehicle_info->photo_list[i].result.empty()) {
                xml.SetChildData("0");// 照片结果未知
            } else {
                xml.SetChildData(pVehicle_info->photo_list[i].result);
            }
            xml.AddChildElem("sm");
            xml.SetChildData(streason);
            xml.AddChildElem("zpencode");
            xml.SetChildData(encode_value);
            if(zptype == serviceConfigure.picCode.zqf)
            {
                if(compare_photo_encode["A历史左前方照片"] != "")
                {
                    xml.AddChildElem("messageitem");
                    xml.IntoElem();
                    xml.AddChildElem("zpzl");
                    xml.SetChildData("外观对比照片");
                    xml.AddChildElem("zpencode");
                    xml.SetChildData(compare_photo_encode["A历史左前方照片"]);
                    xml.AddChildElem("jg");
                    xml.SetChildData("0");
                    xml.OutOfElem();
                    continue;
                }
                else if(compare_photo_encode["D左前方档案照片"] != "")
                {
                    xml.AddChildElem("messageitem");
                    xml.IntoElem();
                    xml.AddChildElem("zpzl");
                    xml.SetChildData("外观对比照片");
                    xml.AddChildElem("zpencode");
                    xml.SetChildData(compare_photo_encode["D左前方档案照片"]);
                    xml.AddChildElem("jg");
                    xml.SetChildData("0");
                    xml.OutOfElem();
                    continue;
                }
                else
                {
                    for(auto it = compare_photo_encode.begin();it != compare_photo_encode.end();it++)
                    {
                        if(
                           it->first.substr(0,1) == "F"  ||
                           it->first.substr(0,1) == "G"  ||
                           it->first.substr(0,1) == "H"  ||
                           it->first.substr(0,1) == "I"  ||
                           it->first.substr(0,1) == "J"  ||
                           it->first.substr(0,1) == "K"   )
                        {
                            xml.AddChildElem("messageitem");
                            xml.IntoElem();
                            xml.AddChildElem("zpzl");
                            xml.SetChildData("外观对比照片");
                            xml.AddChildElem("zpencode");
                            xml.SetChildData(it->second);
                            xml.AddChildElem("jg");
                            xml.SetChildData("0");
                            xml.OutOfElem();
                        }
                    }
                }
            }
            else if(zptype == serviceConfigure.picCode.yhf)
            {
                if(compare_photo_encode["B历史右后方照片"] != "")
                {
                    xml.AddChildElem("messageitem");
                    xml.IntoElem();
                    xml.AddChildElem("zpzl");
                    xml.SetChildData("外观对比照片");
                    xml.AddChildElem("zpencode");
                    xml.SetChildData(compare_photo_encode["B历史右后方照片"]);
                    xml.AddChildElem("jg");
                    xml.SetChildData("0");
                    xml.OutOfElem();
                    continue;
                }
                else
                {
                    for(auto it = compare_photo_encode.begin();it != compare_photo_encode.end();it++)
                    {
                        if(
                           it->first.substr(0,1) == "F"  ||
                           it->first.substr(0,1) == "G"  ||
                           it->first.substr(0,1) == "H"  ||
                           it->first.substr(0,1) == "I"  ||
                           it->first.substr(0,1) == "J"  ||
                           it->first.substr(0,1) == "K"   )
                        {
                            xml.AddChildElem("messageitem");
                            xml.IntoElem();
                            xml.AddChildElem("zpzl");
                            xml.SetChildData("外观对比照片");
                            xml.AddChildElem("zpencode");
                            xml.SetChildData(it->second);
                            xml.AddChildElem("jg");
                            xml.SetChildData("0");
                            xml.OutOfElem();
                        }
                    }
                }

            }
            else if(zptype == serviceConfigure.picCode.cjh)
            {
                if(compare_photo_encode["C历史车架号照片"] != "")
                {
                    xml.AddChildElem("messageitem");
                    xml.IntoElem();
                    xml.AddChildElem("zpzl");
                    xml.SetChildData("拓印膜对比历史照片");
                    xml.AddChildElem("zpencode");
                    xml.SetChildData(compare_photo_encode["C历史车架号照片"]);
                    xml.AddChildElem("jg");
                    xml.SetChildData("0");
                    xml.OutOfElem();
                    continue;
                }
                else if(compare_photo_encode["E拓印膜档案照片"] != "")
                {
                    xml.AddChildElem("messageitem");
                    xml.IntoElem();
                    xml.AddChildElem("zpzl");
                    xml.SetChildData("拓印膜对比档案照片");
                    xml.AddChildElem("zpencode");
                    xml.SetChildData(compare_photo_encode["E拓印膜档案照片"]);
                    xml.AddChildElem("jg");
                    xml.SetChildData("0");
                    xml.OutOfElem();
                }
            }
            else if(zptype == serviceConfigure.picCode.clmp)
            {
                if(compare_photo_encode["L历史铭牌照片"] != "")
                {
                    xml.AddChildElem("messageitem");
                    xml.IntoElem();
                    xml.AddChildElem("zpzl");
                    xml.SetChildData("外观对比照片");
                    xml.AddChildElem("zpencode");
                    xml.SetChildData(compare_photo_encode["L历史铭牌照片"]);
                    xml.AddChildElem("jg");
                    xml.SetChildData("0");
                    xml.OutOfElem();
                }
                else
                {
                    for(auto it = compare_photo_encode.begin();it != compare_photo_encode.end();it++)
                    {
                        if(
                           it->first.substr(0,1) == "F"  ||
                           it->first.substr(0,1) == "G"  ||
                           it->first.substr(0,1) == "H"  ||
                           it->first.substr(0,1) == "I"  ||
                           it->first.substr(0,1) == "J"  ||
                           it->first.substr(0,1) == "K"   )
                        {
                            xml.AddChildElem("messageitem");
                            xml.IntoElem();
                            xml.AddChildElem("zpzl");
                            xml.SetChildData("外观对比照片");
                            xml.AddChildElem("zpencode");
                            xml.SetChildData(it->second);
                            xml.AddChildElem("jg");
                            xml.SetChildData("0");
                            xml.OutOfElem();
                        }
                    }
                }
            }
        }
    }

    xml.OutOfElem();
    xml.ResetChildPos();

    std::string xmlstring;
    xmlstring = xml.GetDoc();
    //LOG_OUT(INFO,"Send data is:\n%s\n",xmlstring.c_str());
    return xmlstring;
}
