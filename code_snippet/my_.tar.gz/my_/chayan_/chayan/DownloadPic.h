#ifndef DOWNLOADPIC_H
#define DOWNLOADPIC_H


#include "vehicle_info.h"
#include "http_res_def.h"
#include <thread>
#include <mutex>
extern std::mutex openfile;

class JiNanExecutePhoto
{
public:
    std::string queryKey;
    std::string zplx;
};

class DownloadPic
{
public:
    DownloadPic(Vehicle_Info* pvehicle_info,unsigned int count);
    ~DownloadPic();
    unsigned int index;
    Vehicle_Info* vehicle;

    bool Save_PhotoData_To_LocalFile(unsigned char* recv_data,unsigned int recv_length,Photo *pPhoto);
    static std::string addPhotoName(Vehicle_Info* pvehicle_info,Photo *pPhoto);
    bool startDownloadPic(Photo *pPhoto);

    bool DownloadJiNanPhoto(Photo *pPhoto);
    bool analyseJiNanReply(std::string reply_buf,std::string &decode_picture);

};


#endif // DOWNLOADPIC_H

