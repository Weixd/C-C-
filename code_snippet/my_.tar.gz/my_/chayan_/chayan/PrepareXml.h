#ifndef PREPAREXML_H
#define PREPAREXML_H
#include <iostream>
#include "vehicle_info.h"
#include "Markup.h"
#define DISTRIBUTE_CAR_INFO  0
#define SALVEREPLYRESULT  1

//准备http请求xml数据，后期增加方法，只需继承此类，并重写虚函数
class  PrepareXML
{

  public:


    PrepareXML();
    virtual ~PrepareXML();

    void setIP(std::string IP);
    void setPort(std::string Port);
    void setRequestUri(std::string RequestUri);
    virtual std::string PrepareXml(Vehicle_Info* pVehicle_info) = 0;
  public:

    std::string IP;
    std::string Port;
    std::string RequestUri;
    std::string vehicle_url;


};


class PrepareDistributeData : public PrepareXML
{
public:

    std::string PrepareXml(Vehicle_Info* pVehicle_info);
};

class SalveSendResult : public PrepareXML
{
public:

    std::string PrepareXml(Vehicle_Info* pVehicle_info);

};

class SendResultToAndroid : public PrepareXML
{
public:
    std::string zplx_chinese;

    std::string handlePhoto(std::string photo_url);
    std::string loadPic(Vehicle_Info* pVehicle_info,unsigned int index);

    std::string PrepareXml(Vehicle_Info* pVehicle_info);
    void handleYwlx(Vehicle_Info* pVehicle_info,std::string &value);
    void change_zplx(std::string zplx);
    void sort_picture(Vehicle_Info* pVehicle_info);
};





#endif // PREPAREXML_H
