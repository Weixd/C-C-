#ifndef CHECK_VEHICLE_API_HPP
#define CHECK_VEHICLE_API_HPP

#include <opencv.hpp>

//Che view type
enum ECheViewType
{
    eFRONTLEFT = 0, //左前45度（0111）
    eBACKRIGHT=1,   //右后45度（0112）
    eBACKFORWARD=2, //正后（0158）
    eOtherType,   //车牌检测(0170)
};

struct Cheliang_OutMsg
{
    //0:未找到车头车尾
    //1：图像角度太正
    //2：拍摄距离太远
    //3:图像类型错误
    //4:图像为空
    //{常规检测指标，与档案照片无关。
    bool b_quality;
    int errorflag;
    bool b_chepai;          //车牌是否正确
    bool b_chebiao;         //车标是否存在
    std::string logo; //车标类型
    bool b_ori_color;       //与公告照片进行比对时，判断车身颜色与给定答案是否一致；与档案照片进行比对时，判断车身颜色是否一致。
    bool b_sanjiaojia;      //三脚架是否符合标准
    bool b_ori_waiguan;     //外观是否有改装
    //waiguan_info
    bool b_cheliang_type;   //is 'cheliang type' correct
    bool b_light_flag;  //车灯是否一致。
    bool b_lungu_flag;   //轮毂是否一致。
    int  i_tiehua_flag;  //0：无贴花  1：贴花面积小于1/3  2：贴花面积大于等于1/3
    bool b_fanghuzhuangzhi_flag;//是否存在防护装置
    //{当档案照片存在时，该结果表示与档案照片比对的结果（是否一致）。
    //当档案照片不存在时，该结果表示检测到的结果（是否有无）。
    bool b_jiaotaban_flag;
    bool b_xinglijia_flag;
    //}

    std::string cheliang_type; // string of cheliang type
    std::vector<std::string> brand;   // car's make
    std::vector<std::string> model;   // car's specific model
    
    cv::Mat m;              //original image
    cv::Mat m_mask;         //color mat of car parts
    cv::Mat m_waiguan;      //waiguan image
    cv::Mat m_cheshen;
    cv::Rect r_cheshen;
    cv::Rect r_chepai;      //location of 'chepai'
    cv::Rect r_chebiao;     //location of 'chebiao'
    cv::Rect r_sanjiaojia;  //location of 'sanjiaojia'
    cv::Rect r_xinglijia;
    cv::Rect r_jiaotaban;
    cv::Rect r_lungu;
    cv::Rect r_qianzhudeng;
    cv::Rect r_weiyi;
    cv::Rect r_refit;       //location of refitment
};

struct Chejiahao_OutMsg
{
    bool b_pic_quality;         //is picture quality good
    bool b_chejiahao;           //if 'chejiahao' matching
    bool b_tuomo;               //if 'tuomo' matching
    bool b_ori_chejiahao;       //is original 'chejiahao'
    bool b_shuiyin_riqi;
    bool b_ori_space_vertical;
    bool b_ori_space_level;

    int match_score;                  //nanjing - matching score

    std::string date_stamp;     //string of date stamp

    cv::Mat m;                  //original image
    cv::Rect r;                 //location of 'chejiahao'

    cv::Mat roi_m;              //roi image of 'chejiahao'
    std::vector<cv::Rect> rect; //location of 'chejiahao' char

    cv::Mat m_show1;
    cv::Mat m_show2;
};

struct Fadongjihao_OutMsg
{
    bool b_pic_quality;         //is picture quality good
    bool b_fadongjihao;         //if 'fadongjihao' correct
    cv::Mat m;                  //original image
    std::vector<cv::Rect> rt_fadongjihao; //location of 'fadongjihao'
    cv::Mat str_img;
};

struct Mingpai_Input
{
    cv::Mat img_src; //公告照片
    cv::Mat img_his; //历史照片
    std::string ans_cheliangpinpai;
    std::string ans_cheliangxinghao;
    std::string ans_fadongjixinghao;
    std::string ans_zhizaoriqi;
    std::string ans_zhizaoguo;
    std::string ans_pailiang;
    std::string ans_zongzhiliang;
    std::string ans_chejiahao;
    std::string ans_zhizaochangmingcheng;
    std::string ans_hedingzaike;
};

struct Mingpai_OutMsg
{
    bool b_pic_quality;           //is picture quality good
    bool b_mingpai;
    bool b_cheliangpinpai;
    bool b_cheliangxinghao;
    bool b_fadongjixinghao;
    bool b_zhizaoriqi;
    bool b_zhizaoguo;
    bool b_pailiang;
    bool b_zongzhiliang;
    bool b_chejiahao;
    bool b_zhizaochangmingcheng;
    bool b_hedingzaike;

    bool b_ori; //公告照片和历史照片对比结果是否一致

    cv::Mat m;                    //original image
    cv::Rect r_mingpai;           //location of 'mingpai'

    cv::Mat m_mingpai;            //image of 'mingpai'
    cv::Rect r_chejiahao;         //location of 'chejiahao'
    cv::Rect r_fadongjihao;       //location of 'fadongjihao'
    cv::Rect r_pailiang;          //location of 'pailiang'
    cv::Rect r_zhizaonianyue;     //location of 'zhizaonianyue'
};

struct Anquandai_OutMsg
{
    bool b_anquandai; //if anquandai exist

    cv::Mat m;        //original image
    cv::Rect r;       //location of 'anquandai'
};

struct Luntaiguige_ImgOutMsg
{
    bool b_luntaiguige;          //if 'luntaiguige' correct
    cv::Mat m;              //original image
    cv::Rect rt_luntaiguige;  //location of 'luntaiguige' rect
    cv::Mat str_img;  //location of 'luntaiguige' img
};

struct Huochexiang_ImgOutMsg
{
    bool b_ori_chexiang; //is original 'chexiang'(should not be refitted)
    bool b_correct_pose; //is correct images' pose
    bool b_top_closed;   //is the top of 'chexiang' closed
    bool b_roof_modified;//is the top of cangzha（仓栅）modified

    cv::Mat m;           //original image
    cv::Mat m_chewei;    //image of chewei
    cv::Rect r_chexiang; //location of 'chexiang'
};

struct Socket_ImgOutMsg
{
    bool b_socket; //is socket exist
    cv::Mat m;           //original image
    cv::Rect r;       //location of socket
};

struct Chayanyuan_ImgOutMsg
{
    bool b_same; //is the same person
};

//证件表单类
struct ZhuceSQB_Input
{
    cv::Mat img;
    std::string suoyouren; //所有人
    std::string yewuleixing; //业务类型
    std::string haopaizhonglei; //号牌种类
    std::string haopaihaoma; //号牌号码
    std::string cheliangshibiedaihao; //车辆识别代号
    std::string shiyongxingzhi; //使用性质
};

struct ZhuceSQB_OutMsg
{
    std::string suoyourenshouji; //所有人手机号码
    std::string dailiren; //代理人
    std::string dailirenshouji; //代理人手机号码

    bool b_suoyouren; //所有人
    bool b_yewuleixing; //业务类型
    bool b_haopaizhonglei; //号牌种类
    bool b_haopaihaoma; //号牌号码
    bool b_cheliangshibiedaihao; //车辆识别代号
    bool b_shiyongxingzhi; //使用性质
    bool b_qianzi; //签字
};

struct Gouchefapiao_Input
{
    cv::Mat img;
    std::string suoyouren; //所有人
    std::string shenfenzhenghao; //身份证号
    std::string hegezhenghao; //合格证号
    std::string chejiahao; //车架号
    std::string fadongjihao; //发动机号
    std::string xiaoshoudanwei; //销售单位名称
};

struct Gouchefapiao_OutMsg
{
    bool b_suoyouren; //所有人
    bool b_shenfenzhenghao; //身份证号
    bool b_hegezhenghao; //合格证号
    bool b_chejiahao; //车架号
    bool b_fadongjihao; //发动机号
    bool b_guoshuiyinzhang; //国税印章
    bool b_xiaoshoudanwei; //销售单位名称
};

struct Shenfenzheng_Input
{
    cv::Mat img;
    std::string suoyouren; //所有人
    std::string shenfenzhenghao; //身份证号
    std::string tongyishehuidaima; //统一社会代码
};

struct Shenfenzheng_OutMsg
{
    bool b_suoyouren; //所有人
    bool b_shenfenzhenghao; //身份证号
    bool b_tongyishehuidaima; //统一社会代码
};

struct Suicheqingdan_Input
{
    cv::Mat img;
    std::string chejiahao; //车架号
};

struct Suicheqingdan_OutMsg
{
    bool b_chejiahao; //车架号
    bool b_yinzhang; //印章
    bool b_xinnenyuanche; //新能源车是否备注
};

struct Jinkoupingzheng_Input
{
    cv::Mat img;
    std::string chejiahao; //车架号
};

struct Jinkoupingzheng_OutMsg
{
    bool b_chejiahao; //车架号
    bool b_yinzhang; //印章
};

struct Jianyanbaogao_Input
{
    cv::Mat img;
    std::string chejiahao; //车架号
    std::string chepaihao; //车牌号
};

struct Jianyanbaogao_OutMsg
{
    bool b_chejiahao; //车架号
    bool b_chepaihao; //车牌号
    bool b_qianming; //签名
    bool b_yinzhang; //印章
    bool b_jianyanjielun; //检验结论
    bool b_shujuxiang; //数据项
};

struct Wanshuizhengming_Input
{
    cv::Mat img;
    std::string nashuiren; //纳税人
    std::string changpaixinghao; //厂牌型号
    std::string fadongjihao; //发动机号
    std::string chejiahao; //车架号
};

struct Wanshuizhengming_OutMsg
{
    bool b_nashuiren; //纳税人
    bool b_changpaixinghao; //厂牌型号
    bool b_fadongjihao; //发动机号
    bool b_chejiahao; //车架号
};

struct Chechuanshui_Input
{
    cv::Mat img;
    std::string chejiahao; //车架号
};

struct Chechuanshui_OutMsg
{
    bool b_chejiahao; //车架号
    bool b_yinzhang; //印章
};

struct Chayanjilubiao_Input
{
    cv::Mat img;
    std::string haopaihaoma; //号牌号码
    std::string chejiahao; //车架号
};

struct Chayanjilubiao_OutMsg
{
    bool b_haopaihaoma; //号牌号码
    bool b_chejiahao; //车架号
    bool b_chayanjielun; //查验结论
    bool b_qianzi; //查验员签字
};

struct Weituoshu_Input
{
    cv::Mat img;
    std::string chejiahao; //车架号
    std::string haopaihaoma; //号牌号码
};

struct Weituoshu_OutMsg
{
    bool b_haopaihaoma; //号牌号码
    bool b_chejiahao; //车架号
    bool b_qianzi; //所有人签字
    bool b_yinzhang; //印章
};

struct Suoyouquanzhuanyi_Input
{
    cv::Mat img;
    std::string haopaihaoma; //号牌号码
    std::string chejiahao; //车架号
    std::string cheliangleixing; //车辆类型
};

struct Suoyouquanzhuanyi_OutMsg
{
    bool b_maifang; //卖方
    bool b_haopaihaoma; //号牌号码
    bool b_chejiahao; //车架号
    bool b_cheliangleixing; //车辆类型
    bool b_yinzhang; //印章
};

struct Xingshizheng_Input
{
    cv::Mat img;
    std::string haopaihaoma; //号牌号码
    std::string chejiahao; //车架号
    std::string fazhengriqi; //车辆类型
    std::string zhengxinbianhao; //证芯编号
};

struct Xingshizheng_OutMsg
{
    bool b_haopaihaoma; //号牌号码
    bool b_chejiahao; //车架号
    bool b_fazhengriqi; //车辆类型
    bool b_zhengxinbianhao; //证芯编号
};

struct Dengjizhengshu_Input
{
    cv::Mat img;
    std::string cheliangleixing; //车辆类型
    std::string cheliangxinghao; //车辆型号
    std::string chejiahao; //车架号
    std::string fadongjihao; //发动机号
    std::string hedingzaike; //核定载客
    std::string shiyongxingzhi; //使用性质
    std::string chuchangriqi; //出厂日期
    std::string fazhengriqi; //发证日期
};

struct Dengjizhengshu_OutMsg
{
    bool b_cheliangleixing; //车辆类型
    bool b_cheliangxinghao; //车辆型号
    bool b_chejiahao; //车架号
    bool b_fadongjihao; //发动机号
    bool b_hedingzaike; //核定载客
    bool b_shiyongxingzhi; //使用性质
    bool b_chuchangriqi; //出厂日期
    bool b_fazhengriqi; //发证日期
    bool b_jiguanzhang; //发证机关章
};

struct Haopai_Input
{
    cv::Mat img;
    std::string haopaihaoma; //号牌号码
};

struct Haopai_OutMsg
{
    bool b_haopaihaoma; //号牌号码
};

struct BiangengSQB_Input
{
    cv::Mat img;
    std::string haopaizhonglei; //号牌种类
    std::string haopaihaoma; //号牌号码
    std::string biangengleixing; //变更类型
};

struct BiangengSQB_OutMsg
{
    bool b_haopaizhonglei; //号牌种类
    bool b_haopaihaoma; //号牌号码
    bool b_biangengleixing; //变更类型
    bool b_qianzi; //签字
};

struct DiyaSQB_Input
{
    cv::Mat img;
    std::string haopaizhonglei; //号牌种类
    std::string haopaihaoma; //号牌号码
    std::string yewuleixing; //业务类型
    std::string suoyouren; //所有人
};

struct DiyaSQB_OutMsg
{
    bool b_haopaizhonglei; //号牌种类
    bool b_haopaihaoma; //号牌号码
    bool b_yewuleixing; //业务类型
    bool b_suoyourenqianzi; //所有人签字
    bool b_diyaquanren; //抵押权人
    bool b_diyaquanrenqianzi; //抵押权人签字
};

struct Huishouzhengming_Input
{
    cv::Mat img;
    std::string suoyouren; //所有人
    std::string shenfenzhenghao; //身份证号
    std::string haopaihaoma; //号牌号码
    std::string chejiahao; //车架号
};

struct Huishouzhengming_OutMsg
{
    bool b_suoyouren; //所有人
    bool b_shenfenzhenghao; //身份证号
    bool b_haopaihaoma; //号牌号码
    bool b_chejiahao; //车架号
    bool b_fazhengdanweizhang; //发证单位章
    bool b_bumenzhuguanzhang; //主管部门章
    bool b_shouchedanweizhang; //收车单位章
};

struct Mieshizhengming_Input
{
    cv::Mat img;
    std::string haopaihaoma; //号牌号码
};

struct Mieshizhengming_OutMsg
{
    bool b_haopaihaoma; //号牌号码
    bool b_suoyourenqianzi; //所有人签字
    bool b_danweiyinzhang; //查证单位印章
};

struct Chuchanghegezheng_Input
{
    cv::Mat img;
    std::string chejiahao; //车架号
    std::string zhizaoriqi; //制造日期
};

struct Chuchanghegezheng_OutMsg
{
    bool b_chejiahao; //车架号
    bool b_zhizaoriqi; //制造日期
};

struct Yizhixingzhengshu_Input
{
    cv::Mat img;
    std::string chejiahao; //车架号
};

struct Yizhixingzhengshu_OutMsg
{
    bool b_chejiahao; //车架号
    bool b_yinzhang; //印章
};

class CheckVehApi
{
public:
    CheckVehApi(bool useGPU, int gpu_id, int city_code);
    ~CheckVehApi();

    //外观类
    //process cheliang(front-left 45 degree, rear-right 45 degree, rear, waiguan-pic)
    //cheliang_type_answer:车辆类型，类别。
    bool cheliang_api_process(cv::Mat &img, std::vector<cv::Mat> &vec_his_img, std::string chepai_answner,std::string cheliang_type_answer,std::string colors_answer,std::string business_type,ECheViewType echeViewtype,Cheliang_OutMsg &out_msg);

    //process chejiahao
    bool chejiahao_api_process(cv::Mat &img, cv::Mat &his_img, std::string chejiahao_answer, const std::string &ans_shuiyin_riqi, Chejiahao_OutMsg &out_msg,int compare_type);

    //process fadongjihao
    bool fadongjihao_api_process(cv::Mat &img, std::string fadongjihao_answer, Fadongjihao_OutMsg &out_msg);

    //process mingpai
    bool mingpai_api_process(Mingpai_Input &input_msg, Mingpai_OutMsg &out_msg);

    //process anquandai
    bool anquandai_api_process(cv::Mat &img, Anquandai_OutMsg &out_msg);

    //luntaiguige_api_process
    bool luntaiguige_api_process(cv::Mat &img, std::string xinghao_answer, Luntaiguige_ImgOutMsg &out_msg);

    //huochexiang_api_process
    bool huochexiang_api_process(cv::Mat &img, std::string &vehicle_typecode,Huochexiang_ImgOutMsg &out_msg);

    //socket_api_process
    bool socket_api_process(cv::Mat &img, Socket_ImgOutMsg &out_msg);

    bool chayanyuan_api_process(cv::Mat &img1, cv::Mat &img2, Chayanyuan_ImgOutMsg &out_msg);

    //证件表单类
    //机动车注册、转移、注销登记/转入申请表
    bool zhucesqb_api_process(ZhuceSQB_Input &input, ZhuceSQB_OutMsg &out_msg);

    //购车发票
    bool gouchefapiao_api_process(Gouchefapiao_Input &input, Gouchefapiao_OutMsg &out_msg);

    //身份证（或居住证、居住证明、营业执照）
    bool shenfenzheng_api_process(Shenfenzheng_Input &input, Shenfenzheng_OutMsg &out_msg);

    //环保信息随车清单
    bool suicheqingdan_api_process(Suicheqingdan_Input &input, Suicheqingdan_OutMsg &out_msg);

    //进口凭证
    bool jinkoupingzheng_api_process(Jinkoupingzheng_Input &input, Jinkoupingzheng_OutMsg &out_msg);

    //机动车安全技术检验报告
    bool jianyanbaogao_api_process(Jianyanbaogao_Input &input, Jianyanbaogao_OutMsg &out_msg);

    //车辆购置税完税证明（副本）
    bool wanshuizhengming_api_process(Wanshuizhengming_Input &input, Wanshuizhengming_OutMsg &out_msg);

    //车船税或免税证明
    bool chechuanshui_api_process(Chechuanshui_Input &input, Chechuanshui_OutMsg &out_msg);

    //机动车查验记录表
    bool chayanjilubiao_api_process(Chayanjilubiao_Input &input, Chayanjilubiao_OutMsg &out_msg);

    //委托书
    bool weituoshu_api_process(Weituoshu_Input &input, Weituoshu_OutMsg &out_msg);

    //机动车所有权转移的证明、凭证
    bool suoyouquanzhuanyi_api_process(Suoyouquanzhuanyi_Input &input, Suoyouquanzhuanyi_OutMsg &out_msg);

    //机动车行驶证
    bool xingshizheng_api_process(Xingshizheng_Input &input, Xingshizheng_OutMsg &out_msg);

    //机动车登记证书
    bool dengjizhengshu_api_process(Dengjizhengshu_Input &input, Dengjizhengshu_OutMsg &out_msg);

    //机动车号牌
    bool haopai_api_process(Haopai_Input &input, Haopai_OutMsg &out_msg);

    //机动车变更登记/备案申请表
    bool biangengsqb_api_process(BiangengSQB_Input &input, BiangengSQB_OutMsg &out_msg);

    //机动车抵押登记/质押备案申请表
    bool diyasqb_api_process(DiyaSQB_Input &input, DiyaSQB_OutMsg &out_msg);

    //报废机动车回收证明
    bool huishouzhengming_api_process(Huishouzhengming_Input &input, Huishouzhengming_OutMsg &out_msg);

    //机动车灭失证明
    bool mieshizhengming_api_process(Mieshizhengming_Input &input, Mieshizhengming_OutMsg &out_msg);

    //出厂合格证
    bool chuchanghegezheng_api_process(Chuchanghegezheng_Input &input, Chuchanghegezheng_OutMsg &out_msg);

    //车辆一致性证书
    bool yizhixingzhengshu_api_process(Yizhixingzhengshu_Input &input, Yizhixingzhengshu_OutMsg &out_msg);

    //get algorithm version
    static bool algorithm_version(std::string &version);

private:
    void *m_Alg;
};

#endif //USED_VEHICLE_API_HPP
