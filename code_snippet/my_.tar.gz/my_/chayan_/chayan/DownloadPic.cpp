#include "DownloadPic.h"
#include "HttpClient.h"
#include "chayan_main.h"
#include "jsonMaker.h"
#include "ZBase64.h"
std::mutex openfile;
extern Queue service_queue;
extern configuration serviceConfigure;
DownloadPic::DownloadPic(Vehicle_Info* pvehicle_info,unsigned int count)
{
    vehicle = pvehicle_info;
    index = count;

}

DownloadPic::~DownloadPic()
{
    vehicle = nullptr;
}

bool DownloadPic::analyseJiNanReply(std::string reply_buf,std::string &decode_picture)
{
    Json::Value jsonroot;
    Json::Reader reader;
    if(reader.parse(reply_buf,jsonroot))
    {
        int code = jsonroot["code"].asInt();
        if(code == 1)
        {
            LOG_OUT(INFO,"获取济南历史照片成功\n");
            std::string picture_base = jsonroot["picture"].asString();
            decode_picture = ZBase64::Decode((unsigned char*)picture_base.c_str(),picture_base.size());
            return true;
        }
        else
        {
            std::string message = jsonroot["message"].asString();
            LOG_OUT(INFO,"获取济南历史照片失败，code:%d,message:%s\n",code,message.c_str());
            return false;
        }
    }
    return false;
}

bool  DownloadPic::DownloadJiNanPhoto(Photo *pPhoto)
{
    HttpClient historyPhotoDownload;
    LOG_OUT(INFO,"uri is %s\n",pPhoto->url.c_str());
#ifdef TESTANDROID
   if(historyPhotoDownload.InitData(DOWNLOAD_PHOTO_DATA,pPhoto->url.c_str(),REQUEST_GET_FLAG,nullptr,nullptr))
#else
    if(historyPhotoDownload.InitData(DOWNLOAD_PHOTO_DATA,pPhoto->url.c_str(),REQUEST_POST_FLAG,nullptr,nullptr))
#endif
    {
        historyPhotoDownload.m_local_path = DownloadPic::addPhotoName(vehicle,pPhoto);
        historyPhotoDownload.startHttpClient();
        pPhoto->path = historyPhotoDownload.m_photo_filename;
        if(!historyPhotoDownload.ResponseData.empty())
        {
            std::string recv_data;
            if(analyseJiNanReply(historyPhotoDownload.ResponseData,recv_data))
            {
                if(Save_PhotoData_To_LocalFile((unsigned char*)recv_data.c_str(),static_cast<unsigned int>(recv_data.size()),pPhoto))
                {
                    LOG_OUT(INFO,"保存照片成功...%s\n",pPhoto->path.c_str());
                    return true;
                }
                else
                {
                    pPhoto->path = "TBD";
                    LOG_OUT(ERROR,"保存照片失败...TBD\n");
                }
            }else {


                #ifdef TESTANDROID
                    if(historyPhotoDownload.recv_data)
                    {
                      if(Save_PhotoData_To_LocalFile(historyPhotoDownload.recv_data,historyPhotoDownload.recv_length,pPhoto))
                      {
                          LOG_OUT(INFO,"保存照片成功...%s\n",pPhoto->path.c_str());
                      }
                      else
                      {
                          pPhoto->path = "TBD";
                          LOG_OUT(ERROR,"保存照片失败...%s\n",pPhoto->path.c_str());
                      }
                      delete [] historyPhotoDownload.recv_data;
                      historyPhotoDownload.recv_data = nullptr;
                    }
                 #else
                    pPhoto->path = "TBD";
                    LOG_OUT(ERROR,"analyseJiNanReply...err 保存照片失败...TBD\n");
                #endif
            }
        }
        else
        {
            pPhoto->path = "TBD";
            LOG_OUT(INFO,"JiNan history picture is no response!!!\n");
        }
    }

    return false;
}

bool DownloadPic::startDownloadPic(Photo *pPhoto)
{
    char strbuf[256];
    bool ret = false;
#ifdef TESTANDROID
    sprintf(strbuf,"http://%s",serviceConfigure.remoteIp.c_str());
#else
    sprintf(strbuf,"http://%s/pnweb/",serviceConfigure.remoteIp.c_str());
#endif

    HttpClient DownloadPhoto;
    LOG_OUT(INFO,"photo uri is %s",pPhoto->url.c_str());
    if(pPhoto->url == "/TBD")
    {
        pPhoto->path = "TBD";
        return false;
    }
    std::string photo_url = strbuf+pPhoto->url;

    LOG_OUT(INFO,"uri is %s",photo_url.c_str());
    if(DownloadPhoto.InitData(DOWNLOAD_PHOTO_DATA,photo_url.c_str(),REQUEST_GET_FLAG,nullptr,nullptr))
    {
        DownloadPhoto.m_local_path = DownloadPic::addPhotoName(vehicle,pPhoto);

        DownloadPhoto.startHttpClient();

        pPhoto->path = DownloadPhoto.m_photo_filename;//将本地路径赋给vehicle
        if(DownloadPhoto.recv_data)
        {
            if(Save_PhotoData_To_LocalFile(DownloadPhoto.recv_data,DownloadPhoto.recv_length,pPhoto))
            {
                ret = true;
                LOG_OUT(INFO,"保存照片成功...%s\n",pPhoto->path.c_str());
            }
            else
            {
                pPhoto->path = "TBD";
                LOG_OUT(ERROR,"保存照片失败...%s\n",pPhoto->path.c_str());
            }
            delete [] DownloadPhoto.recv_data;
            DownloadPhoto.recv_data = nullptr;
        }
    }
    return ret;
}

//保存照片到本地
bool DownloadPic::Save_PhotoData_To_LocalFile(unsigned char* recv_data,unsigned int recv_length,Photo *pPhoto)
{
    std::lock_guard<std::mutex> lock (openfile);
    if (recv_data == nullptr || recv_length == 0)
    {
        return false;
    }
    FILE *v_file = nullptr;
    int i = 1;
    LOG_OUT(INFO,"pPhoto->path = %s\n",pPhoto->path.c_str());
    std::string v_filename = pPhoto->path;
    char additional[32];
    additional[0] = 0;

    while (access(v_filename.c_str(), 00) == 0)
    {
        sprintf(additional, "-%d", i++);
        v_filename = pPhoto->path;
        v_filename.append(std::string(additional));
    }

    v_filename.append(std::string(additional)); //update new file name


    if (recv_length <= 1000) {
        LOG_OUT(ERROR, "The photo is too small, path: %s \n",v_filename.data());
    }


    v_file = fopen(v_filename.c_str(), "wb");
    if (v_file == nullptr) {
        LOG_OUT(ERROR, " [Save_PhotoData_To_LocalFile()] Can not create and open file: %s \n", v_filename.c_str());
        return false;
    }

    fseek(v_file, 0, SEEK_SET);
    fwrite(recv_data, 1, recv_length, v_file);
    fflush(v_file);
    fclose(v_file);


    return true;
}

string formatFileName(std::string name)
{
    try {
        for (unsigned int i = 0; i < name.size(); i++) {
            if (name[i] == '/') {
                name.replace(i, 1, 1, '=');
            }
        }
    } catch (const std::exception &e) {
        LOG_OUT(ERROR, "formatFileName() failure! \n");
        std::cout << "Error: " << e.what() << std::endl;
        return "";
    }

    return name;
}

//组合照片名字符串
std::string DownloadPic::addPhotoName(Vehicle_Info* pvehicle_info,Photo *pPhoto)
{
    std::string result;
    std::string type = pPhoto->type;
    std::string hphm = (pvehicle_info->hphm == "无数据") ? "None" : pvehicle_info->hphm;
    std::string clsbdh = (pvehicle_info->clsbdh == "无数据") ? "None" : pvehicle_info->clsbdh;
    std::string fdjh = (pvehicle_info->fdjh == "无数据") ? "None" : pvehicle_info->fdjh;
    std::string fdjxh = (pvehicle_info->fdjxh == "无数据") ? "None" : pvehicle_info->fdjxh;
    fdjxh = formatFileName(fdjxh);
    std::string pailiang = (pvehicle_info->pl == "无数据") ? "None" : pvehicle_info->pl;
    std::string chuchangriqi = (pvehicle_info->ccrq == "无数据") ? "None" : pvehicle_info->ccrq;
    std::string cheliangpinpai = (pvehicle_info->clpp1 == "无数据") ? "None" : pvehicle_info->clpp1;
    std::string cheliangxinghao = (pvehicle_info->clxh == "无数据") ? "None" : pvehicle_info->clxh;
    std::string gonglv = (pvehicle_info->gl == "无数据") ? "None" : pvehicle_info->gl;
    std::string zhizaoguo = (pvehicle_info->zzg == "无数据") ? "None" : pvehicle_info->zzg;
    std::string hedingzaike = (pvehicle_info->hdzk == "无数据") ? "None" : pvehicle_info->hdzk;
    std::string zongzhiliang = (pvehicle_info->zzl == "无数据") ? "None" : pvehicle_info->zzl;
    std::string zhizaochang = (pvehicle_info->zzcmc == "无数据") ? "None" : pvehicle_info->zzcmc;
    std::string luntaiguige = (pvehicle_info->ltgg == "无数据") ? "None" : pvehicle_info->ltgg;
    luntaiguige = formatFileName(luntaiguige);

    if(pPhoto->type == serviceConfigure.picCode.clmp)
    {
        result = type + "_" + hphm + "_" + clsbdh + "_" + fdjxh + "_"\
                + pailiang + "_" + chuchangriqi + "_" + cheliangpinpai + "_"\
                + cheliangxinghao + "_" + gonglv + "_" + zhizaoguo + "_" + hedingzaike + "_"\
                + zongzhiliang + "_" + zhizaochang;
    }
    else if(pPhoto->type == serviceConfigure.picCode.fdjh)
    {
        result = type + "_" + hphm + "_" + clsbdh + "_" + fdjh;
    }
    else if(pPhoto->type == serviceConfigure.picCode.ltgg)
    {
        result = type + "_" + hphm + "_" + clsbdh + "_" + luntaiguige;
    }
    else if(pPhoto->type == serviceConfigure.picCode.zqf)
    {
        result = type + "_" + hphm + "_" + clsbdh + "_" + cheliangpinpai;
    }
    else if(pPhoto->type == serviceConfigure.picCode.yhf)
    {
        result = type + "_" + hphm + "_" + clsbdh + "_" + cheliangpinpai;
    }
    else
    {
        result = type + "_" + hphm + "_" + clsbdh;
    }
    return result;

}
