#ifndef _Z_BASE64_
#define _Z_BASE64_

#include <iostream>

using namespace std;

class ZBase64
{
public:
    /**
     * @brief Base64编码。
     * @param[in] Data 编码前的数据地址
     * @param[in] DataByte 编码前的数据长度
     * @return 编码后的数据
     */
    static string Encode(const unsigned char *Data, unsigned int DataByte);

    /**
     * @brief Base64解码。
     * @param[in] Data 解码前的数据地址
     * @param[in] DataByte 解码前的数据长度
     * @return 解码后的数据。如果是空字符串，表示数据不合法或者数据长度为0
     */
    static string Decode(const unsigned char *Data, unsigned int DataByte);

    /**
     * @brief 判定该数据是不是合法的Base64编码数据。
     * @param[in] Data 解码前的数据地址
     * @param[in] DataByte 解码前的数据长度
     * @return true--合法
     *         false--不合法
     */
    static bool isValidData(const unsigned char *Data, unsigned int DataByte);
};

#endif	//	_Z_BASE64_
