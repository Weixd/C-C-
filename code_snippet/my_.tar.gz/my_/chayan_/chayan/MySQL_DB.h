#ifndef MYSQL_DB_H
#define MYSQL_DB_H
#include <mysql/mysql.h>
#include "./Log.h"

class MySQL_DB
{
public:
    bool initialize_MySQL_library();
    bool connect(const char *host, unsigned int port, const char *user, const char *passwd, const char *db);
    void disconnect();
    void terminate_MySQL_library();
    bool createTable(const char *name, const char *format);
    bool createDB(const char *name);
    bool selectDB(const char *name);
    bool dropTable(const char *name);
    bool insert(const char *tableName, const char *valueFormat);
    unsigned long getLastID();
    MYSQL_RES * getResult(const char *SqlStatement);
    void freeResult(MYSQL_RES *result);
    unsigned int getErrorNumber();
    bool update(const char *tableName, const char *valueFormat);
    bool alterTable(const char *tableName, const char *format);
private:
    MYSQL mysql;
};
#endif

