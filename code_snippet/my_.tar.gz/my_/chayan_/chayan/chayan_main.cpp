#include <net/if.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include <mysql/mysql.h>
#include <mysql/mysqld_error.h>
#include "MySQL_DB.h"
#include "chayan_main.h"
#include <sys/stat.h>
#include <ostream>
#include "Queue.h"
#include "PrepareXml.h"
#include "configfile.h"
#include "soapClient.h"
#include "vehicle_info.h"
#include "jsonMaker.h"
#include <atomic>
#include "Utility.h"
#include "licence/MakeLic.h"

#define g_DownloadLimit 3
#define HISTORY_PHOTO_NUM 5
using namespace std;

std::vector<std::string> lsh_filter_temp;

extern bool distributeDataThread(Vehicle_Info* pVehicle_info,std::vector<std::string> IpList);
extern bool slaveSendResult(Vehicle_Info* pVehicle_info,std::string masterIP);
unsigned int get_lsh_gw(std::string cylsh,std::string &gongwei_code);
std::map<std::string,long> send_vehicle_info;//已经发送车辆信息，并等待客户端回应结果，<检验流水号，发送时间>
extern std::vector<RecvRenGongData> rengong_result;
extern void recordSendTime(const Vehicle_Info* pVehicle_info);
bool checkSalveResult();

std::vector<std::map<std::string,std::string>> androidIP(20);

Queue service_queue;
configuration serviceConfigure;
vector<string> lsh_list;
zplx is_zplx_check;
jsonMaker checker;

extern void startInterface();

service::service()
{

}

service::~service()
{
    if(serviceConfigure.is_master)
    {
        delete recvSoapInfo;
        recvSoapInfo = nullptr;

        delete downloadPhoto;
        downloadPhoto = nullptr;

        delete distributeInfo;
        distributeInfo = nullptr;

        delete processPhotoBlock;
        processPhotoBlock = nullptr;

        delete replySoapResult;
        replySoapResult = nullptr;

        delete saveResult;
        saveResult = nullptr;

    }
    else
    {
        delete downloadPhoto;
        downloadPhoto = nullptr;

        delete slaveReplyResult;
        slaveReplyResult = nullptr;

        delete processPhotoBlock;
        processPhotoBlock = nullptr;
        if(androidIP[0]["0"] == "1")
        {
        delete sendtoAndroid;
        sendtoAndroid = nullptr;
        }
    }


}
//struct CurrentTime_t
//{
//    unsigned int second;
//    unsigned int minute;
//    unsigned int hour;
//    unsigned int day;
//    unsigned int month;
//    unsigned int year;
//};

//std::string getCurrentTime(CurrentTime_t &time)
//{
//    std::time_t t = std::time(NULL);
//    std::tm *st = std::localtime(&t);

//    time.year = st->tm_year + 1900;
//    time.month = st->tm_mon + 1;
//    time.day = st->tm_mday;
//    time.hour = st->tm_hour;
//    time.minute = st->tm_min;
//    time.second = st->tm_sec;

//    char tmpArray[128] = { 0 };
//    sprintf(tmpArray, "%d-%02d-%02d %02d:%02d:%02d",
//            time.year, time.month, time.day, time.hour, time.minute, time.second);

//    return std::string(tmpArray);
//}

bool checkLicence()
{
    //return true;
    nvmlReturn_t result;
    char uuid_array[64] = {0};
    std::string uuid;

    do {
        result = nvmlInit();
        if (result != NVML_SUCCESS) {
            LOG_OUT(ERROR, "nvmlInit() failed! \n");
            break;
        }

        nvmlDevice_t device;
        result = nvmlDeviceGetHandleByIndex(0, &device);
        if (result != NVML_SUCCESS) {
            LOG_OUT(ERROR, "nvmlDeviceGetHandleByIndex() failed! \n");
            break;
        }

        result = nvmlDeviceGetUUID(device, uuid_array, 64);
        if (result != NVML_SUCCESS) {
            LOG_OUT(ERROR, "nvmlDeviceGetUUID() failed! \n");
            break;
        }

        uuid = uuid_array;
    } while (false);

    nvmlShutdown();
    if (result != NVML_SUCCESS) {
        LOG_OUT(ERROR, "nvmlErrorString(): %s \n", nvmlErrorString(result));
        return false;
    }

    char fileName[] = "licence";
    if (access(fileName, R_OK) != 0) {
        LOG_OUT(ERROR, "Unable to read \"%s\" file! \n", fileName);
        return false;
    }

    LicDara licenceFile;
    ReadLic(fileName, licenceFile);

    /* 检查UUID是否相等 */
    if (uuid != licenceFile.szMachineID) {
        LOG_OUT(ERROR, "The licence file is invalid! Error code: 1 \n");
        return false;
    }

    /* 检查当前时间是否在有效期内 */
    bool timeValid = true;
    CurrentTime_t current;
    getCurrentTime(current);
    if ((current.year < licenceFile.tStart.dwYear) || (current.year > licenceFile.tEnd.dwYear)) {
        timeValid = false;
    } else if (current.year == licenceFile.tStart.dwYear) {
        if (current.month < licenceFile.tStart.dwMonth) {
            timeValid = false;
        }

        if (current.month == licenceFile.tStart.dwMonth) {
            if (current.day < licenceFile.tStart.dwDay) {
                timeValid = false;
            }
        }
    } else if (current.year == licenceFile.tEnd.dwYear) {
        if (current.month > licenceFile.tEnd.dwMonth) {
            timeValid = false;
        }

        if (current.month == licenceFile.tEnd.dwMonth) {
            if (current.day > licenceFile.tEnd.dwDay) {
                timeValid = false;
            }
        }
    }

    if (!timeValid) {
        LOG_OUT(ERROR, "The licence file is invalid! Error code: 2 \n");
        return false;
    }

    LOG_OUT(INFO, "The licence file has been confirmed. \n");
    return true;
}

const std::string VERSION = "1.3.11";
int main(int argc, char *argv[])
{
    if((argc == 2) && (std::string(argv[1])== "-v"))
    {
        LOG_OUT(INFO,"Version is:%s\n",VERSION.c_str());

        return RESULT_OK;
    }

    if (!checkLicence()) {
        return EXIT_FAILURE;
    }

    checker.readJson(const_cast<char*>("config.json"));
    if(checker.readJsonJiNan(const_cast<char*>("configequip.json")))
    {
        LOG_OUT(INFO,"加载安卓IP配置文件成功\n");
    }
    else
    {
        androidIP[0]["0"] = "0";  //关闭发送至安卓屏幕功能
    }




    is_zplx_check = checker.config;
    service vehicle_service;
    vehicle_service.inint_database();
    //yingshe
    if("3301"==serviceConfigure.city)
    {
        vehicle_service.lncysf();
    }

    vehicle_service.start();


    return RESULT_OK;
}

unsigned int service::start()
{
    try
    {
        if(serviceConfigure.is_master)
        {
            recvSoapInfo       = new std::thread(&service::start_recv_soap_info,this);
            recvSoapInfo->detach();
            downloadPhoto      = new std::thread(&service::start_download_photo,this);
            downloadPhoto->detach();
            distributeInfo     = new std::thread(&service::start_distribute_info,this);
            distributeInfo->detach();
            processPhotoBlock  = new std::thread(&service::start_process_photo,this);
            processPhotoBlock->detach();
            saveResult         = new std::thread(&service::start_save_result,this);
            saveResult->detach();
            replySoapResult    = new std::thread(&service::start_reply_soap_result,this);
            replySoapResult->detach();
            databaseBackup     = new std::thread(&service::start_dump_database,this);
            databaseBackup->detach();
            deleteExpireFile   = new std::thread(&service::start_delete_file,this);
            deleteExpireFile->detach();
            if(androidIP[0]["0"] == "1")
            {
                putIntoReplySoap = new std::thread(&service::putIntoReplySoapQueue,this);
                putIntoReplySoap->detach();
            }

            startInterface();
        }
        else
        {
            downloadPhoto      = new std::thread(&service::start_download_photo,this);
            downloadPhoto->detach();
            slaveReplyResult   = new std::thread(&service::start_slave_reply_result,this);
            slaveReplyResult->detach();
            processPhotoBlock  = new std::thread(&service::start_process_photo,this);
            processPhotoBlock->detach();
//            if(androidIP[0]["0"] == "1")
//            {
//                sendtoAndroid = new std::thread(&service::start_sendto_android,this);
//                sendtoAndroid->detach();
//            }
            deleteExpireFile   = new std::thread(&service::start_delete_file,this);
            deleteExpireFile->detach();
            startInterface();
        }

    }
    catch (const std::system_error& e)
    {
        LOG_OUT(ERROR,"Create new thread failure!!!\n");
        LOG_OUT(ERROR,"Reason:%s",e.what());

        return RESULT_FAIL;
    }
    return RESULT_OK;

}
/**
 * @brief 初始化数据库
 * @return  0--执行正确
 *          1--执行错误
 *
 * @note
 */
bool update_table();
unsigned int service::inint_database()
{
    mysql_library_init(0, nullptr, nullptr);
    if (!update_table()) {
        return RESULL_FAIL;
    }
    return RESULT_OK;
}

unsigned int service::start_recv_soap_info()
{
    string localip = get_ip();
    while (true) {

        try {
        //soap test
        char requestUri[256];
        sprintf(requestUri,"http://%s%s",serviceConfigure.soapIp.c_str(),serviceConfigure.soapurl.c_str());
        std::this_thread::sleep_for(std::chrono::seconds(10));
#ifndef TESTANDROID
        if (!isWorkTime())
        {
            LOG_OUT(INFO, "Not at work time, no SOAP client query. \n");
            continue;
        }
#endif

        char* queryReturn = nullptr;
        soapClient soap_client(30);
        bool lsh_flag =true;
        string msg = "";
        if(serviceConfigure.zplx == 1 || serviceConfigure.zplx == 3)
        {
            msg = soap_client.soapGetLsh("10","1");
            LOG_OUT(INFO, "SOAP server sent to get lsh list: %s \n",msg.c_str());
            soap_client.queryObjectOut((char *)"18",(char*)serviceConfigure.soapxlh.c_str(), (char *)"18CK3", (char *)"01", (char *)localip.c_str() ,requestUri,(char *)msg.c_str() ,queryReturn);
            if (queryReturn == nullptr) {
                LOG_OUT(INFO, "SOAP server no response! \n");
                continue;
            }
            else
            {
                string mesg = soap_client.URLDecode(queryReturn);
                LOG_OUT(INFO, "SOAP server sent to get lsh list receive : %s \n",mesg.c_str());
                if(soap_client.analyse_QueryReturn_Lsh_Data(mesg,true) <= 0)
                {
                    LOG_OUT(ERROR, "Analyse_QueryReturn_Lsh_Data error\n");
                    lsh_flag = false;
                }
            }
        }

        if(serviceConfigure.zplx == 2 || serviceConfigure.zplx == 3)
        {
            msg = soap_client.soapGetLsh("10","2");
            LOG_OUT(INFO, "SOAP server sent to get lsh list model 2: %s \n",msg.c_str());
            soap_client.queryObjectOut((char *)"18",(char*)serviceConfigure.soapxlh.c_str(), (char *)"18CK3", (char *)"01", (char *)localip.c_str() ,requestUri,(char *)msg.c_str() ,queryReturn);
            if (queryReturn == NULL) {
                LOG_OUT(INFO, "SOAP server no response! \n");
                continue;
            }
            else
            {
                string mesg = soap_client.URLDecode(queryReturn);
                LOG_OUT(INFO, "SOAP server sent to get lsh list receive : %s \n",mesg.c_str());
                if(soap_client.analyse_QueryReturn_Lsh_Data(mesg,false) <= 0)
                {
                    LOG_OUT(ERROR, "Analyse_QueryReturn_Lsh_Data error\n");
                    if(!lsh_flag)
                    {
                        continue;
                    }
                }
            }
        }

        soap_client.filterLhs();

        if(soap_client.new_flag)
        {
            for(unsigned int i = 0; i < soap_client.lsh_arrary.size() ; i++)
            {
                char* queryReturn2;
                msg = soap_client.soapGetInfo(soap_client.lsh_arrary[i],"1");
                LOG_OUT(INFO, "SOAP server sent to get info : %s \n",msg.c_str());
                soap_client.queryObjectOut((char *)"18",(char*)serviceConfigure.soapxlh.c_str(), (char *)"18CK3", (char *)"01", (char *)localip.c_str() ,requestUri, (char *)msg.c_str() ,queryReturn2);
                //LOG_OUT(INFO,"qureyreceive_msg :%s \n",queryReturn2);
                if(queryReturn2 != nullptr)
                {
                    string return_msg = soap_client.URLDecode(queryReturn2);
                    LOG_OUT(INFO,"return_msg :%s－－－－－－－ \n",return_msg.c_str());
                    Vehicle_Info * p_vehicle_info = new Vehicle_Info;
                    if(soap_client.analyse_QueryReturn_Info_Data(return_msg,p_vehicle_info, "1") > 0)
                    {
                        LOG_OUT(INFO,"service_queue put OK!!!!! \n");
                        time_t now_time = time(nullptr);
                        tm* t_tm = localtime(&now_time);
                        p_vehicle_info->resultReplyTime = asctime(t_tm);
                        p_vehicle_info->ywyy = getNowTimeLong();
                        service_queue.wait_distribute_queue.Put(p_vehicle_info);
                        continue;
                    }
                    else
                    {
                        delete p_vehicle_info;
                        p_vehicle_info = nullptr;
                        continue;
                    }
                }
            }
        }
        else
        {
            LOG_OUT(INFO, "same lsh! \n");
        }

        for(unsigned int i = 0; i < soap_client.lsh_arrary_model2.size() ; i++)
        {
            char* queryReturn2;
            bool jinan_is_same = true;
            for(auto it_lsh = lsh_filter_temp.begin();it_lsh != lsh_filter_temp.end();it_lsh++)
            {
                if(*it_lsh == soap_client.lsh_arrary_model2[i])
                {
                    jinan_is_same = false;
                    break;
                }
            }
            if(jinan_is_same)
            {
                msg = soap_client.soapGetInfo(soap_client.lsh_arrary_model2[i],"2");
                LOG_OUT(INFO, "SOAP server sent to get info : %s \n",msg.c_str());
                soap_client.queryObjectOut(const_cast<char*>("18"),const_cast<char*>(serviceConfigure.soapxlh.c_str()),const_cast<char*>("18CK3"), const_cast<char*>("01"),const_cast<char*>(localip.c_str()),requestUri,const_cast<char*>(msg.c_str()) ,queryReturn2);
                //LOG_OUT(INFO,"qureyreceive_msg :%s \n",queryReturn2);
                if(queryReturn2 != nullptr)
                {
                    string return_msg = soap_client.URLDecode(queryReturn2);
                    LOG_OUT(INFO,"return_msg :%s \n",return_msg.c_str());
                    Vehicle_Info * p_vehicle_info = nullptr;
                    p_vehicle_info = new Vehicle_Info;
                    if(soap_client.analyse_QueryReturn_Info_Data(return_msg,p_vehicle_info, "2") > 0)
                    {
                         LOG_OUT(INFO,"service_queue put OK!!!!! \n");
                         p_vehicle_info->ywyy = getNowTimeLong();
                         service_queue.wait_distribute_queue.Put(p_vehicle_info);
                         continue;
                    }
                    else
                    {
                        delete p_vehicle_info;
                        p_vehicle_info = nullptr;
                        continue;
                    }
                }

            }
        }
        }catch (exception e) {
            printf("start_recv_soap_info try err\n");
        }

    }

}
/**
 * @brief   主机给从机分配车辆信息函数
 * @return  0--执行正确
 *          1--执行错误
 *
 * @note    分配策略：按照从机列表依次分配，如果分配三次以上都不能得到从机正常响应，则交由主机处理
 *                  如果主机给从机分配的信息超过120s从机未回复，则重新分配
 */
unsigned int service::start_distribute_info()
{
    std::thread checkSalveIsReturn(checkSalveResult);//检测从机是否在规定的时间内返回检测结果
    checkSalveIsReturn.detach();
    static std::map<std::string,unsigned int> lsh_buf;//存储缓存流水号，当lsh数量达到3时，数据交由主机自己处理
    while (true)
    {
        Vehicle_Info* pvehicle_info = nullptr;
        /*从队列中取出...*/
        pvehicle_info = service_queue.wait_distribute_queue.Take();
        pvehicle_info->hbdbqk = std::to_string(service_queue.wait_distribute_queue.Size())+";";
        pvehicle_info->hbdbqk += std::to_string(service_queue.download_queue.Size())+";";
        pvehicle_info->hbdbqk += std::to_string(service_queue.process_queue.Size())+";";
        pvehicle_info->hbdbqk += std::to_string(service_queue.reply_soap_queue.Size())+";";
        pvehicle_info->hbdbqk += "f1_"+getNowTime();
        if(pvehicle_info!=nullptr)
        {
            if(service_queue.download_queue.Size() < 1 && service_queue.process_queue.Size() < 1)
            {
                pvehicle_info->device_ip = "127.0.0.1";
                pvehicle_info->hbdbqk += "f2_"+getNowTime();
                service_queue.download_queue.Put(pvehicle_info);
            }
            else if(serviceConfigure.slaveIP.size())
            {
                LOG_OUT(INFO,"Start distribute data to slave...\n");
                if(lsh_buf.count(pvehicle_info->lsh) == 0)//判断此流水号是否之前分配过
                {
                    lsh_buf[pvehicle_info->lsh] = 1;
                }
                else//如果分配过，则计数加1
                {
                    auto it = lsh_buf.find(pvehicle_info->lsh);
                    unsigned int count = it->second;
                    lsh_buf[pvehicle_info->lsh] = count + 1;
                }
                LOG_OUT(INFO,"lsh_buf size is %ld\n",lsh_buf.size());

                std::string lsh_temp = pvehicle_info->lsh;
                if(distributeDataThread(pvehicle_info,serviceConfigure.slaveIP))
                {
                    if(lsh_buf.size() > MAX_LIMIT)
                    {
                        auto buf_it = lsh_buf.find(lsh_temp);
                        if(buf_it != lsh_buf.end())
                        {
                            lsh_buf.erase(buf_it);
                        }
                    }

                    LOG_OUT(INFO,"Finished distribute data...\n");
                }
                else
                {
                    if(lsh_buf[pvehicle_info->lsh] > 3)
                    {
                        LOG_OUT(INFO,"Master self process...\n");
                           /*放入主机下载队列...*/
                        pvehicle_info->device_ip = "127.0.0.1";
                        pvehicle_info->hbdbqk += "f2_"+getNowTime();
                        service_queue.download_queue.Put(pvehicle_info);
                        //auto it = lsh_buf.find(pvehicle_info->lsh);
                        //lsh_buf.erase(it);
                    }
                    else
                    {
                        service_queue.wait_distribute_queue.RePut(pvehicle_info);//再次放入待分配队列

                    }
                }
            }
            else
            {
                pvehicle_info->device_ip = "127.0.0.1";
                pvehicle_info->hbdbqk += "f2_"+getNowTime();
                service_queue.download_queue.Put(pvehicle_info);
            }

        }


    }
    return RESULT_OK;
}

/*void fun1(DownloadPic pic)
{
    pic.startDownloadPic();
}
void fun2(DownloadPic pic,unsigned int count)
{
    LOG_OUT(INFO,"COUNT IS %d",count);
    pic.startDownloadJiNanPhoto(count);
}*/


bool analyseReplyResult(std::string recv_data,std::string &gongwei_code)
{
    Json::Value jsonroot;
    Json::Reader reader;
    LOG_OUT(INFO,"recv_data is %s \n",recv_data.c_str());
    if(reader.parse(recv_data,jsonroot))
    {
        std::string temp = jsonroot["code"].asString();
        LOG_OUT(INFO,"code is %s \n",temp.c_str());
        if(temp == "1")
        {
            gongwei_code = jsonroot["gwbh"].asString();
            LOG_OUT(INFO,"gongwei_code is %s \n",gongwei_code.c_str());
        }
        else
        {
            gongwei_code.erase();
            LOG_OUT(ERROR,"获取查验工位编号失败...,code = %s\n",temp.c_str());
            return false;
        }
    }
    else
    {
        return false;
    }
    return true;
}


//获取流水号工位
unsigned int get_lsh_gw(std::string cylsh,std::string &gongwei_code)
{
    HttpClient httpclient_get_gw;
    LOG_OUT(INFO,"get_lsh_qw into...\n");
    // 正确的请求URL：http://172.37.254.40:8090/VideoManager/queryGw?cylsh=1190508172147
    std::string str_get_gongwei_uri = "http://172.37.254.41:8090/VideoManager/queryGw?cylsh=";
    str_get_gongwei_uri += cylsh;

    char request_buf[256];
    sprintf(request_buf,"cylsh=%s",cylsh.c_str());//请求数据格式:{"cylsh":"*************"}

    if(httpclient_get_gw.InitData(GET_LSH_GONGWEI, str_get_gongwei_uri.c_str(), REQUEST_GET_FLAG, HTTP_CONTENT_TYPE_URL_ENCODED, request_buf))
    {
        httpclient_get_gw.startHttpClient();

        if(httpclient_get_gw.recv_data)
        {
            delete [] httpclient_get_gw.recv_data;
            httpclient_get_gw.recv_data = nullptr;
        }
    }

    if(httpclient_get_gw.d_success_flag)
    {
        if(!httpclient_get_gw.ResponseData.empty())
        {
            if(analyseReplyResult(httpclient_get_gw.ResponseData,gongwei_code))
            {

                LOG_OUT(INFO,"Recv gongwei_code is %s",gongwei_code.c_str());
                return RESULT_OK;
            }
            else //获取查验工位编号失败
            {
                   LOG_OUT(ERROR,"Analyse gongwei is fail!!!\n");
                   return RESULT_FAIL;
            }
        }
        else
        {
            LOG_OUT(ERROR,"Response data is empty!!!\n");
            return RESULT_FAIL;

        }
    }
    else
    {
        LOG_OUT(ERROR,"Get vehicle gongwei is fail!!!\n");
        return RESULL_FAIL;
    }
    return RESULT_OK;
}

void downloadpicByPhoto(Vehicle_Info* pvehicle_info,unsigned int index)
{
    DownloadPic pic(pvehicle_info,index);
    if(serviceConfigure.city == JINAN)
    {
        if(pvehicle_info->photo_list[index].type.substr(0,1) == "H")
        {
            pic.DownloadJiNanPhoto(&pvehicle_info->photo_list[index]);
        }else {
            pic.startDownloadPic(&pvehicle_info->photo_list[index]);
        }

    }else {
        pic.startDownloadPic(&pvehicle_info->photo_list[index]);
    }
    //pvehicle_info->photo_list[index].detail.push_back("pd2:"+getNowTime()+";");
}
/**
 * @brief   开始下载照片函数
 * @return  0--执行正确
 *          1--执行错误
 *
 * @note    多线程下载，主从机同时启动，采用http协议Get方法
 */
void downloadpic(Vehicle_Info* pvehicle_info)
{

    if(pvehicle_info != nullptr)
    {

#ifdef TESTANDROID
   pvehicle_info->gongwei_code = "3";
#else
        if(serviceConfigure.city == JINAN)
        {
            std::string gongwei_code="";
            if(get_lsh_gw(pvehicle_info->lsh,gongwei_code) == RESULL_FAIL)
            {
                gongwei_code="无数据";
            }
            pvehicle_info->gongwei_code = gongwei_code;
        }
#endif

        if(serviceConfigure.city == JINAN)
        {
            std::vector<JiNanExecutePhoto> photo_type_uri = {
                {"getLeftFrontPicinfo","H1"},
                {"getRightRearPicinfo","H2"},
                {"getCarNumPicinfo","H3"},
                {"getVehNamePlacePicinfo","H4"} };
            for(unsigned int i = 0 ;i < photo_type_uri.size(); i++)
            {
                Photo JiNanPhoto;
                JiNanPhoto.type = photo_type_uri[i].zplx;
#ifdef TESTANDROID
                JiNanPhoto.url =  "http://"+serviceConfigure.remoteIp+"/lishimoni/xiaohuangya1.jpg";
#else
                JiNanPhoto.url = "http://10.10.1.43:9210/tPictureinfo/"+photo_type_uri[i].queryKey+"?vin="+pvehicle_info->clsbdh;
#endif
                pvehicle_info->photo_list.push_back(JiNanPhoto);
            }

        }

//        for(unsigned int i = 0 ;i < pvehicle_info->photo_list.size();i++)
//        {
//            LOG_OUT(INFO, "Vehicle check request(lsh:%s) began to download the photo. \n\n", pvehicle_info->lsh.c_str());
//            DownloadPic pic(pvehicle_info,i);
//            if(serviceConfigure.city == JINAN)
//            {
//                if(pvehicle_info->photo_list[i].type.substr(0,1) == "H")
//                {
//                    pic.DownloadJiNanPhoto(&pvehicle_info->photo_list[i]);
//                }else {
//                    pic.startDownloadPic(&pvehicle_info->photo_list[i]);
//                }

//            }else {
//                pic.startDownloadPic(&pvehicle_info->photo_list[i]);
//            }
//        }

            for(unsigned int i = 0 ;i < pvehicle_info->photo_list.size();i++)
            {
                LOG_OUT(INFO, "Vehicle check request(lsh:%s) began to download the photo. \n\n", pvehicle_info->lsh.c_str());
                //pvehicle_info->photo_list[i].detail.push_back("pd1:"+getNowTime()+";");
                pvehicle_info->photo_list[i].pD_thread = new std::thread(downloadpicByPhoto,pvehicle_info,i);
                //download_thread.detach();
            }

            for(unsigned int i = 0 ;i < pvehicle_info->photo_list.size();i++)
            {
                pvehicle_info->photo_list[i].pD_thread->join();
                delete pvehicle_info->photo_list[i].pD_thread;
            }

        //pvehicle_info->cllx = "Q11";

   }

}

unsigned int service::start_download_photo()
{
    /* 创建照片文件夹 */
    struct stat st_buf = {};
    stat(serviceConfigure.photoFile.c_str(), &st_buf);
    if ((st_buf.st_mode & S_IFMT) != S_IFDIR) {
        mkdir(serviceConfigure.photoFile.c_str(), 0777);
    }
    while (true)
    {
        try
        {
            Vehicle_Info *pvehicle_info = nullptr;

            pvehicle_info = service_queue.download_queue.Take();
            pvehicle_info->hbdbqk += "x1_"+getNowTime();
            LOG_OUT(INFO,"Download queue size is %ld\n",service_queue.download_queue.Size());

            downloadpic(pvehicle_info);

            pvehicle_info->hbdbqk += "x2_"+getNowTime();
            service_queue.process_queue.Put(pvehicle_info);
        }
        catch (const std::system_error& e)
        {
            LOG_OUT(INFO, "Create new thread(exec_Download) failure! \n");
            std::cout << "Error code: " << e.code() << ", reason: " << e.what() << std::endl;
            return false;
        }
    }
    return RESULT_OK;
}
void service::lncysf()
{
    char szBuf[128];
    memset(szBuf, 0x00, sizeof( szBuf));

    getcwd(szBuf, sizeof(szBuf)-1);

    std::string dircode=szBuf,dirdosc;
    dirdosc+=dircode+"/media.tar.gz";
    if(F_OK!=access(dirdosc.c_str(), 0))
    {
        LOG_OUT(ERROR,"media.tar.gz not exit! \n");
        return;
    }
    std::string su="echo 'emdata#2018'|sudo -S ldconfig";
    system(su.c_str());
    std::string systemStr = "tar -zxvf "+dircode+"/media.tar.gz -C ./";
    system(systemStr.c_str());
    systemStr = "ln -s "+dircode+"/media /opt/vehicle/vehicle_photo/szchayan";
    system(systemStr.c_str());
    systemStr = "chmod 777 "+dircode+"/chayan";
    system(systemStr.c_str());
    sleep(200);

}
/**
 * @brief   开始算法处理照片函数
 * @return  0--执行正确
 *          1--执行错误
 *
 * @note    初始化算法时间较长,可以支持多显卡同时处理
 */
unsigned int service::start_process_photo()
{
    unsigned int gpu_numbers;
    nvmlReturn_t result;

    result = nvmlInit();
    if (result != NVML_SUCCESS) {
        LOG_OUT(ERROR, "nvmlInit() fails! Reason: %s \n", nvmlErrorString(result));
        exit(EXIT_FAILURE);
    }

    result = nvmlDeviceGetCount(&gpu_numbers);
    if (result != NVML_SUCCESS) {
        LOG_OUT(ERROR, "nvmlDeviceGetCount() fails! Reason: %s \n", nvmlErrorString(result));
        exit(EXIT_FAILURE);
    }

    LOG_OUT(INFO, "The amount of GPU is %d \n", gpu_numbers);

    LOG_OUT(INFO, "DataAnalyseThread(GPU_ID:%d) running...... \n", gpu_numbers);

#ifndef	NO_ARTHMETIC
    LOG_OUT(INFO, "Start initialization algorithm(GPU_ID:%d)...... \n", gpu_numbers);
    LargeVehicleApi *alg=nullptr;
    EProjectType projectType = EProjectType::eChayanType;
    if("3301"==serviceConfigure.city)
        alg = new LargeVehicleApi(true,0,3301,projectType);
    else
        alg = new LargeVehicleApi(true,0,3701,projectType);


    std::string version;
    version = alg->algorithm_version(version);
    LOG_OUT(INFO, "Algorithm initialization is complete! Version: %s, GPU_ID:%d \n", version.c_str(), gpu_numbers);
#endif


    LOG_OUT(INFO, "所有模块初始化完成，程序已进入正常运行状态...... \n");
    try
    {
        for (unsigned int i = 0; i < gpu_numbers; i++)
        {
            processPhoto *process_photo = new processPhoto(serviceConfigure.picCode, 0,alg, is_zplx_check);
            process_photo->startProcessPhoto();
            delete process_photo;
            process_photo = nullptr;
        }
    }
    catch (const std::system_error& e)
    {
        LOG_OUT(ERROR, "Create new thread failure! \n");
        std::cout << "Error code: " << e.code() << ", reason: " << e.what() << std::endl;
        exit(EXIT_FAILURE);
    }
    if(alg)
    {
        delete alg;
        alg = nullptr;
    }

    return RESULT_OK;
}

/**
 * @brief   开始从机回复结果函数
 * @return  0--执行正确
 *          1--执行错误
 *
 * @note    主机不执行此函数，如果回复失败，则放入队列中再次发送
 */
unsigned int service::start_slave_reply_result()
{
    while(true)
    {
        if(!serviceConfigure.is_master)
        {
            Vehicle_Info* pvehicle_info = nullptr;

            pvehicle_info = service_queue.slave_reply_queue.Take();
            LOG_OUT(INFO,"start_slave_reply_result 111 lsh:%s\n",pvehicle_info->lsh.c_str());
            printf("start_slave_reply_result 111 lsh:%s\n",pvehicle_info->lsh.c_str());
            if(slaveSendResult(pvehicle_info,serviceConfigure.masterIP))
            {
                LOG_OUT(INFO,"start_slave_reply_result 222 lsh:%s\n",pvehicle_info->lsh.c_str());
                printf("start_slave_reply_result 222 lsh:%s\n",pvehicle_info->lsh.c_str());
                LOG_OUT(INFO,"Slave reply result successful...\n");
                service_queue.wait_free_queue.Put(pvehicle_info);
                pvehicle_info = nullptr;
            }
            else
            {
                LOG_OUT(INFO,"Slave reply result fail...\n");
                service_queue.slave_reply_queue.RePut(pvehicle_info);
                pvehicle_info = nullptr;
                continue;
            }

            while(service_queue.wait_free_queue.Size() > MAX_LIMIT)
            {
                pvehicle_info = service_queue.wait_free_queue.Take();
                delete pvehicle_info;
                pvehicle_info = nullptr;
            }
        }
    }

    return RESULT_OK;
}
void delete_jinan_history_pic(Vehicle_Info* pvehicle_info)
{
    auto pvehicle_it = pvehicle_info->photo_list.begin();
    while(pvehicle_it != pvehicle_info->photo_list.end())
    {
        std::string zplx = (*pvehicle_it).type;
        if(zplx[0] == 'H')
        {
            pvehicle_it = pvehicle_info->photo_list.erase(pvehicle_it);
            LOG_OUT(INFO,"erase zptype:%s\n",zplx.c_str());
        }
        else
        {
            pvehicle_it++;
        }
    }
}
unsigned int service::start_reply_soap_result()
{
    Vehicle_Info* pvehicle_info = nullptr;
    string localip = get_ip();
    while(true)
    {
        char* queryReturn = nullptr;
        soapClient client(30);
        char requestUri[256];
        sprintf(requestUri,"http://%s%s",serviceConfigure.soapIp.c_str(),serviceConfigure.soapurl.c_str());
        pvehicle_info = nullptr;
        pvehicle_info = service_queue.reply_soap_queue.Take();
        pvehicle_info->hbdbqk += "r1_"+getNowTime();
        printf("start_reply_soap_result 111 lsh:%s\n",pvehicle_info->lsh.c_str());
        LOG_OUT(INFO, "start_reply_soap_result 111 lsh:%s\n",pvehicle_info->lsh.c_str());
//        if(serviceConfigure.city == JINAN)
//        {
//            delete_jinan_history_pic(pvehicle_info);
//        }

        if(pvehicle_info != nullptr)
        {
            soapClient client(30);
            string write_msg = client.soap_Return_Msg(pvehicle_info);
            LOG_OUT(INFO,"%s",write_msg.c_str());
            client.writeObjectOut((char *)"18",(char*)serviceConfigure.soapxlh.c_str(), (char *)"18CL1", (char *)"01", (char *)localip.c_str() ,requestUri, (char *)write_msg.c_str() ,queryReturn);
        }

        if (queryReturn == NULL) {
            LOG_OUT(ERROR, "SOAP write server no response! \n");
        }
        else
        {
            LOG_OUT(INFO,"response data: %s",client.URLDecode(queryReturn).c_str());
            printf("start_reply_soap_result 222 lsh:%s\n",pvehicle_info->lsh.c_str());
            LOG_OUT(INFO, "start_reply_soap_result 222 lsh:%s\n",pvehicle_info->lsh.c_str());
            pvehicle_info->hbdbqk += "r2_"+getNowTime();
            int count =lsh_list.size();
            LOG_OUT(INFO, "list_size: %d\n",count);
            for(unsigned int k = 0; k < lsh_list.size(); k++)
            {
                if(lsh_list[k].find(pvehicle_info->lsh) == std::string::npos)
                {

                }
                else
                {
                    LOG_OUT(INFO, "start_reply_soap_result 333 lsh:%s\n",pvehicle_info->lsh.c_str());
                    printf("start_reply_soap_result 333 lsh:%s\n",pvehicle_info->lsh.c_str());
                    LOG_OUT(INFO, "list_size erase : %s\n",lsh_list[k].c_str());
                    lsh_list.erase(lsh_list.begin() + k);
                    count =lsh_list.size();
                    LOG_OUT(INFO, "list_size: %d\n",count);
                    break;
                }
            }
        }
        LOG_OUT(INFO, "record_queue put lsh : %s! \n",pvehicle_info->lsh.c_str());
        LOG_OUT(INFO, "start_reply_soap_result 444 lsh:%s\n",pvehicle_info->lsh.c_str());
        printf("start_reply_soap_result 444 lsh:%s\n",pvehicle_info->lsh.c_str());
        service_queue.record_queue.Put(pvehicle_info);

        pvehicle_info = nullptr;
    }
    return RESULT_OK;
}
/**
 * @brief   写主从机数据库操作
 * @return  true--执行成功
 *          false--执行失败
 *
 * @note    主机将主机信息写入自己数据库
 *          从机将本机处理结果保存至本机数据库和主机数据库
 */
bool service::operateDatabase(const Vehicle_Info * p_vehicle_record)
{
    bool ret = false;
    MySQL_DB db;
    std::string timeString;

    LOG_OUT(INFO, "Write data into the local database...... \n");
    // 只有主机写数据库，从机不写数据库
    if (db.connect(serviceConfigure.masterIP.c_str(), 3306, "root", "em-data-9527", "car_info_schema")) {
        std::string sqlString;
        sqlString = "("
                    "lsh, ywlx, ywyy, hpzl, hphm, clsbdh, syr, sxrq, zzrq, cllx, "
                    "syxz, zbzl, fdjh, clpp1, clxh, ccdjrq, ccrq, kssj, jssj, zpzs, "
                    "spzs, xszbh, rlzl, fzrq, csys, pl, gl, zxxs, cwkc, cwkk, "
                    "cwkg, hxnbcd, hxnbkd, hxnbgd, gbthps, zs, zj, qlj, hlj, ltgg, "
                    "lts, zzl, hdzzl, hdzk, zqyzl, qpzk, hpzk, clyt, ytsx, sfxny, "
                    "xnyzl, clpp2, gcjk, zzg, zzcmc, djrq, yxqz, qzbfqz, fzjg, glbm, "
                    "zt, dybj, fdjxh, hbdbqk, jyhgbzbh, xzqh, zsxzqh, zzxzqh, cyqxh, xh, "
                    "cyry, fdjrq, fhgbzrq,model, ispass, time_result_back, status_result_back,device_ip,gongweiID,sqshsj"
                    ")"
                    " VALUES "
                    "(";
        // 插入车辆数据
        for (unsigned int i = 0; i < p_vehicle_record->item_description.size(); i++)
        {
            std::string tmp = *(std::string *)(p_vehicle_record->item_description[i].value);
            sqlString += "'" + tmp + "',";
        }
        sqlString.erase(sqlString.end()-1);
        sqlString += ")";
        // 插入 设备ip ispass
        // fixme devece_ip 后续在 vehicle_info 获取 暂时这样写

        LOG_OUT(INFO, "insert table \"vehicle_info\" SQL is [%s].\n", sqlString.c_str());
        bool b_insert_ret = false;
        b_insert_ret = db.insert("vehicle_info", sqlString.c_str());

        // 准备写入 photo_info 表
        // 由于 photo_info 外键关联了vehicle_info的主键，所以必须判定vehicle_info表插入成功
        if (b_insert_ret) {
            unsigned long vehicle_id = 0;
            std::string str_vehicle_id;
            if ((vehicle_id = db.getLastID()) != 0) {
                str_vehicle_id = std::to_string(vehicle_id);

                // 检索照片列表
                for (unsigned int i = 0; i < p_vehicle_record->photo_list.size(); ++i)
                {
                    sqlString = "(vehicle_id, lsh, clsbdh, hphm, category, path, result, reason, total_time_algorithm) VALUES (";
                    sqlString += str_vehicle_id + ",";
                    sqlString += "'" + p_vehicle_record->lsh + "',";
                    sqlString += "'" + p_vehicle_record->clsbdh + "',";
                    sqlString += "'" + p_vehicle_record->hphm + "',";
                    sqlString += "'" + p_vehicle_record->photo_list[i].type + "',";
                    sqlString += "'" + p_vehicle_record->photo_list[i].path + "',";
                    sqlString += "'" + p_vehicle_record->photo_list[i].result + "',";
                    std::string reason;
                    for (unsigned int j = 0; j < p_vehicle_record->photo_list[i].detail.size(); ++j)
                    {
                        reason += p_vehicle_record->photo_list[i].detail[j];
                    }
                    sqlString += "'" + reason + "',";
                    sqlString += "'" + p_vehicle_record->photo_list[i].algorithm_process_time + "')";

                    LOG_OUT(INFO, "insert photo info [%s].\n", sqlString.c_str());
                    if (!db.insert("photo_info", sqlString.c_str())) {
                        LOG_OUT(ERROR, "insert photo_info failed lsh->[%s] photo type[%s].\n", p_vehicle_record->lsh.c_str(), p_vehicle_record->photo_list[i].type.c_str());
                        return ret;
                    }
                }
                ret = true;
            }
        } else {
            LOG_OUT(ERROR, "insert table \"vehicle_info\" failed.\n");
            return ret;
        }
    } else {
        LOG_OUT(ERROR, "connect local database failed. \n");
        return ret;
    }

    db.disconnect();
    LOG_OUT(INFO, "vehicle_info and photo_info has written.\n");
    return ret;
}
/**
 * @brief   将处理结果保存至数据库
 * @return  0--执行正确
 *          1--执行错误
 *
 * @note    如果本机为主机，则将收到的从机结果和自身处理结果全部保存
 *          反之，将本机处理结果保存至数据库
 */
unsigned int service::start_save_result()
{
    LOG_OUT(INFO, "start_save_result() is running...... \n");

    while(true)
    {
        Vehicle_Info* p_vehicle_record = nullptr;
        Vehicle_Info* pvehicle_temp = nullptr;
        p_vehicle_record = service_queue.record_queue.Take();
        p_vehicle_record->hbdbqk += "s1_"+getNowTime();
        LOG_OUT(INFO, "p_vehicle_record %x %s\n",p_vehicle_record,p_vehicle_record->clsbdh.c_str());
        if(p_vehicle_record != nullptr && !p_vehicle_record->lsh.empty())
        {
            printf("1111111\n");
            LOG_OUT(INFO, "Get a new check info (lsh:%d) \n", &p_vehicle_record->lsh);
            LOG_OUT(INFO, "=================================== record_queue: [%d] ===================================\n", (int)service_queue.record_queue.Size());

            operateDatabase(p_vehicle_record);
            //operateDemoDatabase(p_vehicle_record);

//            if(androidIP[0]["0"] == "1")
//            {
////               int runCount = service_queue.send_to_android.Size() * 2;
////               while(service_queue.send_to_android.Size()> 1)
////               {
////                 pvehicle_temp = service_queue.send_to_android.Take();
////                 if(pvehicle_temp != p_vehicle_record)
////                 {
////                    service_queue.send_to_android.Put(pvehicle_temp);
////                    pvehicle_temp = nullptr;
////                    break;
////                 }

////                 if(runCount-- < 0)
////                 {
////                     break;
////                 }
////               }

////               while(service_queue.wait_free_queue.Size()> MAX_LIMIT)
////               {
////                   pvehicle_temp = service_queue.wait_free_queue.Take();
////                   delete pvehicle_temp;
////                   pvehicle_temp = nullptr;
////               }
//               delete p_vehicle_record;
//               p_vehicle_record = nullptr;
//            }
//            else
//            {
                delete p_vehicle_record;
                p_vehicle_record = nullptr;
//            }

            //LOG_OUT(INFO,"send_to_android queue size is %ld\n",service_queue.send_to_android.Size());
            LOG_OUT(INFO,"wait_free queue size is %ld\n",service_queue.wait_free_queue.Size());
            LOG_OUT(INFO,"reply_soap queue size is %ld\n",service_queue.reply_soap_queue.Size());
            LOG_OUT(INFO,"record queue size is %ld\n",service_queue.record_queue.Size());
            LOG_OUT(INFO,"process queue size is %ld\n",service_queue.process_queue.Size());
            LOG_OUT(INFO,"save_slave_android_info queue size is %ld\n",service_queue.save_slave_android_info.Size());
            LOG_OUT(INFO,"download queue size is %ld\n",service_queue.download_queue.Size());
            LOG_OUT(INFO,"wait_distribute_queue size is %ld\n",service_queue.wait_distribute_queue.Size());
        }else{
            LOG_OUT(INFO, "p_vehicle_record %x lsh err\n",p_vehicle_record);
        }
    }

        return RESULT_OK;
}

void prepareResourcesToApp(Vehicle_Info* pvehicle_info)
{
    std::string gongwei_code ;
    LOG_OUT(INFO,"android is processing...")
    if(androidIP[0]["0"] == "1" )
    {
#ifdef TESTANDROID
        static int count = 1;
        if(count == 4)
        {
            count = 1;
        }
        gongwei_code = to_string(count%10);
        count++;

#else
       if(get_lsh_gw(pvehicle_info->lsh,gongwei_code) == RESULL_FAIL)
       {
           if(serviceConfigure.is_master)
           {
               service_queue.reply_soap_queue.Put(pvehicle_info);
           }
           else
           {
               service_queue.slave_reply_queue.Put(pvehicle_info);
           }
           pvehicle_info = nullptr;
           LOG_OUT(INFO, ">>>>> Reput vehicle_info to record_queue.\n");
           return;
       }
       if(!(strcmp(gongwei_code.c_str(),"1") >= 0 && strcmp(gongwei_code.c_str(),"3") <= 0))
       {
           LOG_OUT(INFO,"获取工位错误：%s",gongwei_code.c_str());
           return;
       }

#endif
    }
    pvehicle_info->gongwei_code = gongwei_code;
    PrepareXML *send_to_android = new SendResultToAndroid();
    LOG_OUT(INFO,"gongweiIndex is %s\n",gongwei_code.c_str());
    LOG_OUT(INFO,"获取安卓设备IP成功...\n");

    char vehicle_url[256];
    sprintf(vehicle_url,"http://%s/CarCheck",serviceConfigure.masterIP.c_str());
    std::string send_data = send_to_android->PrepareXml(pvehicle_info);

    HttpClient send_vehicle_info;
    if(send_vehicle_info.InitData(REPLY_ANDROID,vehicle_url,REQUEST_POST_FLAG,nullptr,send_data.c_str()))//传入固定IP
    {
        send_vehicle_info.startHttpClient();
    }
    send_vehicle_info.d_success_flag = true;
    if(send_vehicle_info.d_success_flag)
    {
        LOG_OUT(INFO,"vehicle_info has been send android.\n");
    }
    else
    {
        service_queue.slave_reply_queue.Put(pvehicle_info);
        pvehicle_info = nullptr;
    }

    delete send_to_android;
    send_to_android = nullptr;

}

unsigned int service::start_sendto_android()
{
    LOG_OUT(INFO,"Start salve send to master for android...");

//    while (true)
//    {

//        Vehicle_Info* pvehicle_info = nullptr;

//        pvehicle_info = service_queue.send_to_android.Take();
//        LOG_OUT(INFO,"android is processing...");
//        std::thread send_data_to_app(prepareResourcesToApp,pvehicle_info);
//        send_data_to_app.detach();
//    }
        /*if(androidIP[0]["0"] == "1" )
        {
#ifdef TESTANDROID
            static int count = 1;
            if(count == 4)
            {
                count = 1;
            }
            gongwei_code = to_string(count%10);
            count++;

#else
           if(get_lsh_gw(pvehicle_info->lsh,gongwei_code) == RESULL_FAIL)
           {
               if(serviceConfigure.is_master)
               {
                   service_queue.reply_soap_queue.Put(pvehicle_info);
               }
               else
               {
                   service_queue.slave_reply_queue.Put(pvehicle_info);
               }
               pvehicle_info = nullptr;
               LOG_OUT(INFO, ">>>>> Reput vehicle_info to record_queue.\n");
               continue;
           }
#endif
        }
        pvehicle_info->gongwei_code = gongwei_code;
        PrepareXML *send_to_android = new SendResultToAndroid();
        LOG_OUT(INFO,"gongweiIndex is %s\n",gongwei_code.c_str());
        LOG_OUT(INFO,"获取安卓设备IP成功...\n");

        char vehicle_url[256];
        sprintf(vehicle_url,"http://%s/CarCheck",serviceConfigure.masterIP.c_str());
        std::string send_data = send_to_android->PrepareXml(pvehicle_info);

        HttpClient send_vehicle_info;
        if(send_vehicle_info.InitData(REPLY_ANDROID,vehicle_url,REQUEST_POST_FLAG,nullptr,send_data.c_str()))//传入固定IP
        {
            send_vehicle_info.startHttpClient();
        }
        send_vehicle_info.d_success_flag = true;
        if(send_vehicle_info.d_success_flag)
        {
            LOG_OUT(INFO,"vehicle_info has been send android.\n");
        }
        else
        {
            service_queue.slave_reply_queue.Put(pvehicle_info);
            pvehicle_info = nullptr;
        }
        service_queue.wait_free_queue.Put(pvehicle_info);
        pvehicle_info = nullptr;
        delete send_to_android;
        send_to_android = nullptr;
    }*/
}


/**
 * @brief   主机记录发送时间函数
 * @return  0--执行正确
 *          1--执行错误
 * @param   指向存有车辆信息的指针
 *
 * @note    主机将每辆车的信息发送至从机后，调用此函数，并将lsh和时间作为一组map结构存储
 */
void recordSendTime(const Vehicle_Info* pVehicle_info)
{
    time_t myt=time(nullptr);
    long starttime = myt;
    send_vehicle_info[pVehicle_info->lsh] = starttime;
}

/**
 * @brief   检查从机是否按时写回结果函数
 * @return  0--执行正确
 *          1--执行错误
 *
 * @note    分配策略：按照从机列表依次分配，如果分配三次以上都不能得到从机正常响应，则交由主机处理
 *                  如果主机给从机分配的信息超过60s从机未回复，则重新分配
 */

bool checkSalveResult()
{
    while(true)
    {
        time_t myt=time(nullptr);
        long endtime = myt;
        for(auto it = send_vehicle_info.begin();it != send_vehicle_info.end();it++)
        {
            if((endtime - it->second)>120)//主机给从机发送信息超过120s没有回复
            {
                for(size_t count = 0;count < lsh_list.size(); count++)
                {
                    if(lsh_list[count] == it->first)
                    {
                        lsh_list.erase(lsh_list.begin() + static_cast<unsigned int >(count));
                        LOG_OUT(INFO,"流水号%s从机未回复,从lsh_list中删除\n",it->first.c_str());
                    }
                }
            }
        }
        sleep(10);
    }
}

void putIntoWaitReplySoapQueue(Vehicle_Info* pvehicle_info)
{
    time_t myt=time(nullptr);
    long starttime = myt;

    std::map<long,Vehicle_Info*> wait_reply_buf;
    wait_reply_buf[starttime] = pvehicle_info;
    service_queue.wait_reply_soap_queue.Put(wait_reply_buf);
}

void service::putIntoReplySoapQueue()
{
    while (true)
    {
        time_t myt=time(nullptr);
        long endtime = myt;

        auto reply_buf = service_queue.wait_reply_soap_queue.Take();
        auto reply_buf_it = reply_buf.begin();

        if(endtime - reply_buf_it->first > serviceConfigure.andirod_wait_time)
        {
            reply_buf_it->second->hbdbqk += "w_"+ getNowTime();
            service_queue.reply_soap_queue.Put(reply_buf_it->second);
        }
        else
        {
            for(size_t count = 0;count < rengong_result.size();count++)
            {
                if(rengong_result[count].lsh == reply_buf_it->second->lsh)
                {
                    for(size_t zp_count = 0;zp_count < reply_buf_it->second->photo_list.size();zp_count++)
                    {
                        if(rengong_result[count].zpzl == reply_buf_it->second->photo_list[zp_count].type)
                        {
                            reply_buf_it->second->photo_list[zp_count].result = rengong_result[count].jg;
                            reply_buf_it->second->photo_list[zp_count].detail.clear();
                            reply_buf_it->second->photo_list[zp_count].detail.push_back(rengong_result[count].sm);
                        }
                    }
                }
            }

            std::map<long,Vehicle_Info*> wait_reply_buf;
            wait_reply_buf[reply_buf_it->first] = reply_buf_it->second;
            service_queue.wait_reply_soap_queue.Put(wait_reply_buf);
        }
    }
}
bool service::operateDemoDatabase(const Vehicle_Info * p_vehicle_record)
{
    MySQL_DB db;
    std::string timeString;

    LOG_OUT(INFO, "Write data into the local demo_database...... \n");
    if (db.connect("localhost", 3306, "root", "em-data-9527", "demo_schema")) {
        std::string sqlString;
        vector<string> demo=
        {
            "jylsh", //#lsh
            "jyjgbh",//#ywlx
            "jylb",//#ywyy
            "hpzl", "hphm", "clsbdh", "syr","sxrq", "zzrq", "cllx",
            "syxz", "zbzl", "kssj", "jssj", "fdjh",
            "clpp",//#clpp1
            "clxh","ccdjrq",
            "ccrq", "xszbh", "fzrq", "rlzl", "zpzs", "spzs", "csys", "pl", "gl", "zxxs", "cwkc", "cwkk", "cwkg", "hxnbcd", "hxnbkd", "hxnbgd",
            "gbthps", "zs", "zj", "qlj", "hlj", "ltgg", "lts", "zzl", "hdzzl", "hdzk", "zqyzl", "qpzk", "hpzk", "clyt", "ytsx", "sfxny", "xnyzl",
            "yxqz", "fzjg", "hbdbqk", "qzbfqz", "xzqh", "gcjk", "dybj", "zzg", "clpp2", "jyhgbzbh", "zt", "djrq", "zsxzqh", "zzxzqh", "fdjxh"
        };
        sqlString = "(";

        for(unsigned int i =0;i < demo.size();i++)
        {
            if(i == demo.size()-1)
            {
              sqlString += demo[i];
              break;
            }
            sqlString += demo[i];
            sqlString += ",";
        }

        sqlString += ")"
                     " VALUES "
                     "(";

        for (unsigned int i = 0; i < demo.size(); i++)
        {
            unsigned int j;
            for(j = 0; j < p_vehicle_record->item_description.size(); j++)
            {
                string nametag = (p_vehicle_record->item_description[j].name_tag);
                if(demo[i] == "jylsh")
                {
                  sqlString += "'" + *(std::string *)(p_vehicle_record->item_description[0].value) +"'";
                  break;
                }
                else if(demo[i] == "jyjgbh")
                {
                  sqlString += "'" + *(std::string *)(p_vehicle_record->item_description[1].value) +"'";
                  break;
                }
                else if(demo[i] == "jylb")
                {
                  sqlString += "'" + *(std::string *)(p_vehicle_record->item_description[2].value) +"'";
                  break;
                }
                else if(demo[i] == "clpp")
                {
                  sqlString += "'" + *(std::string *)(p_vehicle_record->item_description[15].value)+"'";
                  break;
                }
                else if(demo[i] == nametag)
                {
                    std::string tmp = *(std::string *)(p_vehicle_record->item_description[j].value);
                    sqlString += "'" + tmp + "'";
                    break;
                }
            }
            if(j == p_vehicle_record->item_description.size())
            {
                sqlString += "' '";
            }
            if(i < demo.size()-1)
            {
                sqlString += ",";
            }
        }

        sqlString += ")";

        LOG_OUT(INFO, "insert table \"demo_schema\" SQL is [%s].\n", sqlString.c_str());

        if(!db.insert("vehicle_checks", sqlString.c_str()))
        {
            LOG_OUT(INFO, "insert table \"demo_schema.vehicle_checks\" error.\n");
            return false;
        }
        else
        {
            unsigned long vehicle_id = 0;
            std::string str_vehicle_id;
            if ((vehicle_id = db.getLastID()) != 0) {
                str_vehicle_id = std::to_string(vehicle_id);
            }
            for (unsigned int i = 0; i < p_vehicle_record->photo_list.size(); ++i)
            {
                sqlString = "(vehicle_check_id , category, name, result, reason, created_at) VALUES (";
                sqlString += "'" + str_vehicle_id + "',";
                sqlString += "'" + p_vehicle_record->photo_list[i].type + "',";
                sqlString += "'" + p_vehicle_record->photo_list[i].path + "',";
                sqlString += "'" + p_vehicle_record->photo_list[i].result + "',";
                std::string reason;
                for (unsigned int j = 0; j < p_vehicle_record->photo_list[i].detail.size(); ++j)
                {
                    reason += p_vehicle_record->photo_list[i].detail[j];
                }
                sqlString += "'" + reason + "',";
                std::time_t t = std::time(NULL);
                std::tm *st = std::localtime(&t);
                char tmpArray[128] = { 0 };
                sprintf(tmpArray, "%d-%02d-%02d %02d:%02d:%02d",
                        st->tm_year + 1900, st->tm_mon + 1, st->tm_mday,
                        st->tm_hour, st->tm_min, st->tm_sec);
                timeString = tmpArray;
                sqlString += "'" + timeString + "')";
                LOG_OUT(INFO, "insert photo info [%s].\n", sqlString.c_str());
                if (!db.insert("check_infos", sqlString.c_str())) {
                    LOG_OUT(ERROR, "insert check_infos failed lsh->[%s] photo type[%s].\n", p_vehicle_record->lsh.c_str(), p_vehicle_record->photo_list[i].type.c_str());
                    return false;
                }
            }

            sqlString = "(vehicle_check_id, lsh, "
                        "zqf_Cheliang_chepai,zqf_Cheliang_chebiao,zqf_Cheliang_sanjiaojia,zqf_Cheliang_tiehua,"
                        "zqf_Cheliang_b_ori_waiguan,zqf_Cheliang_b_chepai,zqf_Cheliang_b_chebiao,zqf_Cheliang_b_sanjiaojia,"
                        "yhf_Cheliang_chepai,yhf_Cheliang_chebiao,yhf_Cheliang_sanjiaojia,yhf_Cheliang_tiehua,"
                        "yhf_Cheliang_b_ori_waiguan,yhf_Cheliang_b_chepai,yhf_Cheliang_b_chebiao,yhf_Cheliang_b_sanjiaojia,"
                        "Chejiahao_r,Chejiahao_b_pic_quality,Chejiahao_b_chejiahao,"
                        "Anquandai_r,Anquandai_b_anquandai,"    //fadongjihao
                        "Baodan_hongzhan,Baodan_roi,Baodan_chechuanshui,Baodan_chepai,Baodan_chejiahao,Baodan_start_riqi,Baodan_end_riqi,Baodan_fuben,"
                        "Baodan_b_baodan,Baodan_b_riqi,Baodan_b_fuben,Baodan_b_chechuanshui,"
                        "Xingshizheng_xingshizheng,Xingshizheng_b_xingshizheng"
                        ") VALUES (";
            sqlString += "'" + str_vehicle_id + "',";
            sqlString += "'" + p_vehicle_record->lsh + "',";

            sqlString += "'" + rectToString(p_vehicle_record->zuoqianfang.r_chepai) + "',";
            sqlString += "'" + rectToString(p_vehicle_record->zuoqianfang.r_chebiao) + "',";
            sqlString += "'" + rectToString(p_vehicle_record->zuoqianfang.r_sanjiaojia) + "',";
            sqlString += "'" + rectToString(p_vehicle_record->zuoqianfang.r_refit) + "',";
            sqlString += boolToString(p_vehicle_record->zuoqianfang.b_chepai) +",";
            sqlString += boolToString(p_vehicle_record->zuoqianfang.b_chebiao) +",";
            sqlString += boolToString(p_vehicle_record->zuoqianfang.b_sanjiaojia) +",";
            //sqlString += boolToString(p_vehicle_record->zuoqianfang.b_tiehua_flag) +",";

            sqlString += "'',";


            sqlString += "'" + rectToString(p_vehicle_record->youhoufang.r_chepai) + "',";
            sqlString += "'" + rectToString(p_vehicle_record->youhoufang.r_chebiao) + "',";
            sqlString += "'" + rectToString(p_vehicle_record->youhoufang.r_sanjiaojia) + "',";
            sqlString += "'" + rectToString(p_vehicle_record->youhoufang.r_refit) + "',";
            sqlString += boolToString(p_vehicle_record->youhoufang.b_chepai) +",";
            sqlString += boolToString(p_vehicle_record->youhoufang.b_chebiao) +",";
            sqlString += boolToString(p_vehicle_record->youhoufang.b_sanjiaojia) +",";
            //sqlString += boolToString(p_vehicle_record->youhoufang.b_tiehua_flag) +",";


            sqlString += "'',";

            sqlString += "'" + rectToString(p_vehicle_record->youhoufang.r_chepai) + "',";//no use
            sqlString += boolToString(p_vehicle_record->chejiahao.b_pic_quality) +",";
            sqlString += boolToString(p_vehicle_record->chejiahao.b_chejiahao) +",";

            sqlString += "'" + rectToString(p_vehicle_record->mingpai.r_chejiahao) + "',";//fadongjihao
            sqlString += boolToString(p_vehicle_record->fadongjihao.b_fadongjihao) +",";//anquandai

            sqlString += "'" + rectToString(p_vehicle_record->mingpai.r_chejiahao) + "',"; //jiaoqiangxian
            sqlString += "'" + rectToString(p_vehicle_record->mingpai.r_fadongjihao) + "',";
            sqlString += "'" + rectToString(p_vehicle_record->mingpai.r_mingpai) + "',";
            sqlString += "'" + rectToString(p_vehicle_record->mingpai.r_pailiang) + "',";
            sqlString += "'" + rectToString(p_vehicle_record->mingpai.r_zhizaonianyue) + "',";
            sqlString += "'" + rectToString(p_vehicle_record->mingpai.r_chejiahao) + "',";
            sqlString += "'" + rectToString(p_vehicle_record->mingpai.r_chejiahao) + "',";
            sqlString += "'" + rectToString(p_vehicle_record->mingpai.r_chejiahao) + "',";

            sqlString += boolToString(p_vehicle_record->mingpai.b_chejiahao) +",";
            sqlString += boolToString(p_vehicle_record->mingpai.b_fadongjixinghao) +",";
            sqlString += boolToString(p_vehicle_record->mingpai.b_pailiang) +",";
            sqlString += boolToString(p_vehicle_record->mingpai.b_zhizaoriqi) +",";


            sqlString += "'" + boolToString(p_vehicle_record->luntaiguige.b_luntaiguige) + "',";//xingshizheng
            sqlString += boolToString(p_vehicle_record->luntaiguige.b_luntaiguige);
            sqlString += ")";
            LOG_OUT(INFO, "insert demo_msg info [%s].\n", sqlString.c_str());
            if (!db.insert("vehicle_checks_demo_test", sqlString.c_str())) {
                LOG_OUT(ERROR, "insert vehicle_checks_demo_test failed lsh->[%s] .\n", p_vehicle_record->lsh.c_str());
                return false;
            }
        }
    }
    else {
        LOG_OUT(ERROR, "connect local database failed. \n");
        return false;
    }

    db.disconnect();
    LOG_OUT(INFO, "vehicle_info and photo_info has written.\n");
    return true;
}


bool GetFolders(std::string folder, std::vector<std::string>& paths, std::vector<std::string>& names)
{
    struct stat s;
    lstat( folder.c_str() , &s );
    if( ! S_ISDIR( s.st_mode ) )
        return false;

    struct dirent* filename;    // return value for readdir()
    DIR* dir;                   // return value for opendir()
    dir = opendir( folder.c_str() );
    if( nullptr == dir )
        return false;
    while( ( filename = readdir(dir) ) != nullptr )
    {
        // get rid of "." and ".."
        if( std::string(filename->d_name)[0] == '.')
            continue;
        char filePath[256]={0};
        if(folder[folder.size()-1] == '/')
            sprintf(filePath,"%s%s",folder.c_str(),filename->d_name);
        else
            sprintf(filePath,"%s/%s",folder.c_str(),filename->d_name);
        lstat( filePath , &s );
        if( S_ISDIR( s.st_mode ) )
        {
            paths.push_back(filePath);
            names.push_back(filename ->d_name);
        }
        else
            continue;
    }

    closedir(dir);

    return true;
}
unsigned int service::start_dump_database()
{
    while (true)
    {
        std::time_t t = std::time(nullptr);
        std::tm *st = std::localtime(&t);
        if (st->tm_hour == 23)
        {
            bool DB_IsEmpty = false;
            /* 组合导出表vehicle_checks的命令 */
            std::string cmd = "mysqldump -u root -pem-data-9527 car_info_schema vehicle_info --where=";
            char tmpArray[128] = { 0 };
            sprintf(tmpArray, "%d-%02d-%02d", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);
            std::string time = tmpArray;
            std::string FileName = "vehicle_chayan" + time + ".sql";
            time += " 00:00:00";
            cmd += "\"created_time >= \'" + time + "\'\"";
            cmd += " > " + serviceConfigure.photoFile + FileName;

            /* 组合导出表check_infos的命令 */
            {
                cmd += " && ";
                cmd += "mysqldump -u root -pem-data-9527 car_info_schema photo_info --where=";

                /* 查出vehicle_checks当天第一条数据的id */
                MySQL_DB db;
                if (db.connect(nullptr, 3306, "root", "em-data-9527", "car_info_schema")) {
                    std::string SqlStatement = "SELECT id,created_time FROM vehicle_info WHERE created_time >= \"" + time + "\"";
                    LOG_OUT(INFO, "SqlStatement:%s \n",SqlStatement.c_str());
                    MYSQL_RES *result = db.getResult(SqlStatement.c_str());
                    if (result != nullptr) {
                        MYSQL_ROW row = nullptr;
                        row = mysql_fetch_row(result);
                        if (row != nullptr) {
                            std::string id = row[0];
                            cmd += "\"vehicle_id >= " + id + "\"";
                        } else {
                            DB_IsEmpty = true;
                        }

                        db.freeResult(result);
                    }
                }
                db.disconnect();

                cmd += " >> " + serviceConfigure.photoFile + FileName;
            }

            if (DB_IsEmpty) {
                LOG_OUT(INFO, "There is no new data today and no backup is required. \n");
            } else {
                LOG_OUT(INFO, "Execute backup database \n");
                std::system(cmd.c_str());
            }


            std::this_thread::sleep_for(std::chrono::minutes(60));	/* 60 min(休眠防止同一小时再次进行备份操作) */
        }

    }
}

unsigned int service::start_delete_file()
{
    while (true)
    {
        std::time_t t = std::time(nullptr);
        std::tm *st = std::localtime(&t);
        if (st->tm_hour == 23)
        {
            std::string photoFilePath = serviceConfigure.photoFile;
            std::vector<std::string> paths, names;
            GetFolders(photoFilePath, paths, names);
            for (size_t i = 0; i < paths.size(); i++)
            {
                int year, month, day;
                sscanf(names[i].c_str(), "%d-%d-%d", &year, &month, &day);
                std::time_t t = std::time(nullptr);
                std::tm*st = std::localtime(&t);
                unsigned long long fileTotalDay = static_cast<unsigned long long>(year * 365 + month * 30 + day);
                unsigned long long nowTotalDay = static_cast<unsigned long long>((st->tm_year+1900) * 365 + (st->tm_mon+1) * 30 + st->tm_mday);
                if (nowTotalDay - fileTotalDay > 30)//定时删除一个月之外的数据
                {
                    std::string _cmd = "rm -rf " + paths[i];
                    system(_cmd.c_str());
                    LOG_OUT(INFO, "delete photo director 1: [%s] \n", _cmd.c_str());
                }
            }
                paths.clear();
                names.clear();
          }
        std::this_thread::sleep_for(std::chrono::minutes(60));
    }
}
string service::rectToString(cv::Rect rect)
{
    string rect_s;
    rect_s = to_string(rect.x);
    rect_s += ".";
    rect_s += to_string(rect.y);
    rect_s += ".";
    rect_s += to_string(rect.height);
    rect_s += ".";
    rect_s += to_string(rect.width);
    return rect_s;
}

string service::boolToString(bool is_true)
{
    string rect_s;
    if(is_true)
    {
        rect_s = "'1'";
    }else
    {
        rect_s = "'0'";
    }
    return rect_s;
}

string service::get_ip()
{
    int                 sockfd;
    struct sockaddr_in  sin;
    struct ifreq        ifr;

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd == -1) {
        perror("socket error");
        exit(1);
    }
    strncpy(ifr.ifr_name, "enp3s0", IFNAMSIZ);      //Interface name

    if (ioctl(sockfd, SIOCGIFADDR, &ifr) == 0) {    //SIOCGIFADDR 获取interface address
        memcpy(&sin, &ifr.ifr_addr, sizeof(ifr.ifr_addr));
        return inet_ntoa(sin.sin_addr);
    }
    return "0.0.0.0";
}


bool service:: isWorkTime()
{
    std::time_t t = std::time(nullptr);
    std::tm *st = std::localtime(&t);

    if ((st->tm_hour >= serviceConfigure.startTime) && (st->tm_hour < serviceConfigure.endTime)) {
        return true;
    } else {
        return false;
    }
}
