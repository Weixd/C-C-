#include "Log.h"
#include <event2/event.h> 
#include <event2/buffer.h> 
#include <event2/http.h>
#include <event2/http_struct.h>
#include <event2/keyvalq_struct.h>
#include <sys/stat.h>
#include <string>
#include "DownloadPic.h"

using namespace std;

#define REQUEST_SOAP_FLAG               3
#define REQUEST_POST_FLAG               EVHTTP_REQ_POST
#define REQUEST_GET_FLAG                EVHTTP_REQ_GET
#define itoa(number, array, radix) sprintf(array, "%d", number)
#pragma once
#define HTTP_MAX_RECV_LEN 2*1024*1024
class HttpClient
{
public:
	struct evhttp_uri *m_uri;
	struct event_base *base;
	int m_request_flag;
	int m_request_text_type;
	struct evhttp_connection *m_connection;
	struct evhttp_request *m_httpreq;
    char *m_content_type ;
	char *m_post_data;
    std::string m_photo_filename;
    std::string m_photo_fileid;
    std::string m_demo_filename;
    std::string m_local_path;
    std::string ResponseData;
	bool d_success_flag;
    
   
    unsigned int recv_length;//收到的照片长度
    unsigned char* recv_data;//收到的照片二进制数据

public:
	HttpClient();
    bool InitData(int request_type, const char *uri, int request_flag, const char* content_type, const char* data);
    ~HttpClient();
    bool startHttpClient();
	void http_request_free();
	int start_url_request();
    //DownloadPic* downloadPhoto;
    
    

    
};


