#ifndef HTTPSERVER_H
#define HTTPSERVER_H

#include <string>
#include <vector>
#include <event2/event.h>
#include <event2/http.h>

typedef void (*request_callback)(struct evhttp_request *, void *);

class HTTP_Header {
public:
    HTTP_Header(std::string key, std::string value) : key(key), value(value) {}

public:
    std::string key;
    std::string value;
};

/*
类HTTP_Server封装libevent，用以建立HTTP server端。
监听某个端口，以接收HTTP request，并发出响应。
*/
class HTTP_Server {
public:
    enum E_HTTP_CODE {
        OK = HTTP_OK,
        NOCONTENT = HTTP_NOCONTENT,
        MOVEPERM = HTTP_MOVEPERM,
        MOVETEMP = HTTP_MOVETEMP,
        NOTMODIFIED = HTTP_NOTMODIFIED,
        BADREQUEST = HTTP_BADREQUEST,
        NOTFOUND = HTTP_NOTFOUND,
        BADMETHOD = HTTP_BADMETHOD,
        ENTITYTOOLARGE = HTTP_ENTITYTOOLARGE,
        EXPECTATIONFAILED = HTTP_EXPECTATIONFAILED,
        INTERNAL = HTTP_INTERNAL,
        NOTIMPLEMENTED = HTTP_NOTIMPLEMENTED,
        SERVUNAVAIL = HTTP_SERVUNAVAIL
    };

public:
    HTTP_Server(std::string IP, unsigned short int port);
    ~HTTP_Server();

    /**
     * @brief 启动HTTP server，函数阻塞。
     * @param[in] func 当server端收到HTTP请求时，会调用这个函数
     */
    void startListen(request_callback func);

    std::string getRemoteHost(struct evhttp_request *req);
    unsigned int getRemotePort(struct evhttp_request *req);
    std::string getMethod(struct evhttp_request *req);
    std::string getURI(struct evhttp_request *req);
    std::vector<HTTP_Header> getHeaderList(struct evhttp_request *req);
    std::string getBody(struct evhttp_request *req);



    /**
     * @brief 发出HTTP响应。
     * @param[in] req 当前等待响应的request
     * @param[in] code HTTP响应状态码
     * @param[in] HeaderList 头部列表
     * @param[in] body 数据报文
     * @note 即使不传入任何header，libevent也会自动追加默认的三个头部：
     *       Content-Type: text/html; charset=ISO-8859-1
     *       Date: Wed, 29 Aug 2018 08:12:25 GMT
     *       Content-Length: 267
     *
     *       如果传入同样的header，则会覆盖上面的值。
     */
    void sendReply(struct evhttp_request *req, E_HTTP_CODE code, std::vector<HTTP_Header> HeaderList, std::string body);

private:
    std::string IP;
    unsigned short int port;
    event_base *base = nullptr;
    evhttp *http = nullptr;
};
#endif // HTTPSERVER_H
