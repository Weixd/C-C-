#ifndef SOAPCLIENT_H
#define SOAPCLIENT_H
#include <vector>
#include <string>
#include "vehicle_info.h"
#include "Log.h"
#include "chayan_main.h"
#include "soapTmriOutAccessSoapBindingProxy.h"

using namespace std;
class soapClient : public TmriOutAccessSoapBindingProxy
{
public:
    soapClient(int timeout);
    string soap_Return_Msg(Vehicle_Info *p_vehicle_info);
    vector<string> lsh_arrary;
    vector<string> lsh_arrary_model2;
    bool new_flag; //收到的流水号中有新流水号
    int analyse_QueryReturn_Lsh_Data(string msg, bool model);//model true 1 false 2
    int analyse_QueryReturn_Info_Data(string msg, Vehicle_Info *p_vehicle_info, string model);
//private:
public:
    string soapGetLsh(string num, string model);
    string soapGetInfo(string lsh , string model);
    string URLEncode(const string &sIn);
    string URLDecode(const string &sIn);
    void filterLhs();
    unsigned char toHex(const unsigned char &x);
    unsigned char fromHex(const unsigned char &x);





};

#endif // SOAPCLIENT_H
