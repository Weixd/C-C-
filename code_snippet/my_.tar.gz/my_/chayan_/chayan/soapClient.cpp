#include "soapClient.h"
#include "Markup.h"


extern  std::vector<std::string> lsh_filter_temp;
extern vector<string> lsh_list;
extern configuration serviceConfigure;
soapClient::soapClient(int timeout)
{
    this->accept_timeout = timeout;
    this->connect_timeout = timeout;
    this->recv_timeout = timeout;
    this->send_timeout = timeout;
}



std::string soapClientGetCurrentTime(int time_count)
{
    time_t timeinfo = time(nullptr);

    timeinfo += (time_count*86400);

    tm* t_tm = localtime(&timeinfo);

    char current_time[256];
    sprintf(current_time,"%d-%02d-%02d",t_tm->tm_year+1900,t_tm->tm_mon+1,t_tm->tm_mday);

    return  static_cast<std::string>(current_time);
}


string soapClient::soapGetLsh(string num, string model)
{

#ifdef TESTANDROID
    std::string queryxml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><QueryCondition><lsh></lsh><zplb>1</zplb><fhzdjls>";
    queryxml += num;
    queryxml += "</fhzdjls><cxzt>1</cxzt></QueryCondition></root>";

#else
    std::string queryxml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><QueryCondition><lsh></lsh><zplb>";
    queryxml += model;
    queryxml += "</zplb><qsrq>";
    queryxml += soapClientGetCurrentTime(serviceConfigure.qsrqOffset);
    queryxml += "</qsrq><zzrq>";
    queryxml += soapClientGetCurrentTime(serviceConfigure.zzrqOffset);
    queryxml += "</zzrq><fhzdjls>";
    queryxml += num;
    queryxml += "</fhzdjls><cxzt>1</cxzt></QueryCondition></root>";
#endif
    return queryxml;
}
string soapClient::soapGetInfo(string lsh,string model)
{
#ifdef TESTANDROID
    std::string queryxml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><QueryCondition><lsh>";
    queryxml += lsh;
    queryxml += "</lsh><zplb>1</zplb><fhzdjls>1</fhzdjls><cxzt>2</cxzt></QueryCondition></root>";
#else

    std::string queryxml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><QueryCondition><lsh>";
    queryxml += lsh;
    queryxml += "</lsh><zplb>";
    queryxml += model;
    queryxml += "</zplb><qsrq>";
    queryxml += soapClientGetCurrentTime(serviceConfigure.qsrqOffset);
    queryxml += "</qsrq><zzrq>";
    queryxml += soapClientGetCurrentTime(serviceConfigure.zzrqOffset);
    queryxml += "</zzrq><fhzdjls>1</fhzdjls><cxzt>2</cxzt></QueryCondition></root>";
#endif
    return queryxml;
}
string soapClient::soap_Return_Msg(Vehicle_Info * p_vehicle_info)
{
    CMarkup xml;
    xml.SetDoc("<?xml version=\"1.0\" encoding=\"GBK\"?>\r\n");
    xml.AddElem("root");
    xml.IntoElem();
    xml.AddElem("vehcrpara");
    xml.IntoElem();
    xml.AddElem("lsh");
    xml.SetData(p_vehicle_info->lsh);
    xml.AddElem("zplb");
    xml.SetData(p_vehicle_info->model);
    xml.AddElem("zpshjgs");
    xml.IntoElem();
    for(unsigned int i = 0;i < p_vehicle_info->photo_list.size();i++)
    {
        if(
                (p_vehicle_info->photo_list[i].type.substr(0,1) >= "0" && p_vehicle_info->photo_list[i].type.substr(0,1) <= "9")
                ||(p_vehicle_info->photo_list[i].type.substr(0,1) == "A" && p_vehicle_info->photo_list[i].type.size() > 1)
          )
        {
            xml.AddElem("zpshjg");
            xml.AddChildElem("zpzl");
            xml.SetChildData(p_vehicle_info->photo_list[i].type);
            xml.AddChildElem("jg");
            xml.SetChildData(p_vehicle_info->photo_list[i].result);
            xml.AddChildElem("sm");
            string reason = "";
            reason.clear();
            for(unsigned int j = 0;j < p_vehicle_info->photo_list[i].detail.size() ;j++)
            {
                reason += p_vehicle_info->photo_list[i].detail[j];
            }
            reason = URLEncode(reason);
            xml.SetChildData(reason);
        }
        //接口model2的BUG测试
        /*if(p_vehicle_info->photo_list[i].type.substr(0,1) == "G")
        {
            xml.AddElem("zpshjg");
            xml.AddChildElem("zpzl");
            //xml.SetChildData(p_vehicle_info->photo_list[i].type);
            xml.SetChildData("0201");
            xml.AddChildElem("jg");
            xml.SetChildData(p_vehicle_info->photo_list[i].result);
            xml.AddChildElem("sm");
            string reason;
            reason.clear();
            for(unsigned int j = 0;j < p_vehicle_info->photo_list[i].detail.size() ;j++)
            {
                reason += p_vehicle_info->photo_list[i].detail[j];
            }
            reason = URLEncode(reason);
            xml.SetChildData(reason);
        }*/
    }
    xml.OutOfElem();
    xml.OutOfElem();
    xml.OutOfElem();
    std::string xmlstring = "";
    xmlstring = xml.GetDoc();
    //fix me添加回复soap接口
    //xmlstring = URLEncode(xmlstring);
    return xmlstring;
}
void soapClient::filterLhs()
{
//    if(lsh_list.size() == 0)
//    {
//        lsh_list .insert(lsh_list.begin(), lsh_arrary.begin(),lsh_arrary.end());
//        new_flag = true;
//        return;
//    }
    for (unsigned int i = 0; i < lsh_arrary.size();i++)
    {
        for(unsigned int j = 0;j < lsh_list.size();j++)
        {
            if(lsh_arrary[i].find(lsh_list[j])==std::string::npos)
            {
                //LOG_OUT(INFO , "lsh same : %s \n ",lsh_arrary[i].c_str())
            }
            else
            {
                lsh_arrary.erase(lsh_arrary.begin() + i);
                i= i-1;
                break;
            }
        }
    }
    for (unsigned int i = 0; i < lsh_arrary_model2.size();i++)
    {
        for(unsigned int j = 0;j < lsh_list.size();j++)
        {
            if(lsh_arrary_model2[i].find(lsh_list[j])==std::string::npos)
            {
                //LOG_OUT(INFO , "lsh same : %s \n ",lsh_arrary[i].c_str())
            }
            else
            {
                lsh_arrary_model2.erase(lsh_arrary_model2.begin() + i);
                i= i-1;
                break;
            }
        }
    }
    if(!lsh_arrary.empty())
    {
        lsh_list.insert(lsh_list.end(),lsh_arrary.begin(),lsh_arrary.end());
        new_flag = true;
    }
    else {
        LOG_OUT(INFO , "lsh_arrary empty \n ");
    }
    if(!lsh_arrary_model2.empty())
    {
        lsh_list.insert(lsh_list.end(),lsh_arrary_model2.begin(),lsh_arrary_model2.end());
        new_flag = true;
    }
    else {
        LOG_OUT(INFO , "lsh_arrary empty \n ");
    }
}


unsigned char soapClient::toHex(const unsigned char &x)
{
    return x > 9 ? x - 10 + 'A' : x + '0';
}

unsigned char soapClient::fromHex(const unsigned char &x)
{
    if (isdigit(x)) {
        return x - '0';
    } else if (isupper(x)) {
        return x - 'A' + 10;
    } else {
        return x - 'a' + 10;
    }
}

inline string soapClient::URLEncode(const string &sIn)
{
    string sOut;
    for (size_t ix = 0; ix < sIn.size(); ix++)
    {
        unsigned char buf[4];
        memset(buf, 0, 4);
        if (isalnum((unsigned char)sIn[ix]))
        {
            buf[0] = sIn[ix];
        }

        //else if ( isspace( (BYTE)sIn[ix] ) ) //貌似把空格编码成%20或者+都可以
        //{
        //    buf[0] = '+';
        //}

        else
        {
            buf[0] = '%';
            buf[1] = toHex((unsigned char)sIn[ix] >> 4);
            buf[2] = toHex((unsigned char)sIn[ix] % 16);
        }
        sOut += (char *)buf;
    }

    return sOut;

}

string soapClient::URLDecode(const string &sIn)
{
    string sOut = "";
    for (size_t ix = 0; ix < sIn.size(); ix++)
    {
        unsigned char ch = 0;
        if (sIn[ix] == '%')
        {
            ch = (fromHex(sIn[ix + 1]) << 4);
            ch |= fromHex(sIn[ix + 2]);
            ix += 2;
        }
        else if (sIn[ix] == '+')
        {
            ch = ' ';
        }
        else
        {
            ch = sIn[ix];
        }
        sOut += (char)ch;
    }
    return sOut;
}

int soapClient::analyse_QueryReturn_Lsh_Data(string msg,bool model)
{
    char * xmldata =(char *)msg.c_str();
    CMarkup xml;
    int rownum = 0;
    int r_value = -1;//用于xml列表统计与rownum相等
    xml.SetDoc(xmldata);
    xml.ResetMainPos();
    if (!xml.FindElem()) {
        LOG_OUT(ERROR, "Analyse_QueryReturn_Lsh_Data: Can not find XML element! \n");
        LOG_OUT(ERROR, "Analyse_QueryReturn_Lsh_Data: data:\n%s\n", xmldata);
        return r_value;
    }

    xml.IntoElem();
    if (xml.FindElem("head"))
    {
        xml.IntoElem();
        setlocale(LC_ALL, "chs");
        LOG_OUT(INFO, "[解析head]\n");
        if (xml.FindElem("code"))
        {
            if (atoi(xml.GetData().c_str()) == 1)
            {
                r_value = 0;
                xml.ResetMainPos();
                if (xml.FindElem("rownum"))
                { 
                    rownum = atoi(xml.GetData().c_str());
                    if (rownum > 0)
                    {
                        r_value = rownum;
                    }
                }
            }
        }
        else
        {
            xml.ResetMainPos();
            if(xml.FindElem("message"))
            {
                string msg = xml.GetChildData();
                LOG_OUT(ERROR, "Analyse_QueryReturn_Lsh_Data: xml error msg --- \n%s\n",msg.c_str());
                return r_value;
            }
        }


        xml.OutOfElem();
    }

    if (r_value < 0) {
        LOG_OUT(ERROR, "Analyse_QueryReturn_Lsh_Data: Check code error! \n");
        LOG_OUT(ERROR, "Analyse_QueryReturn_Lsh_Data: data:\n%s\n", xmldata);
        return r_value;
    }
    if (rownum == 0) {
        LOG_OUT(INFO, "监管系统当前没有待审核的车辆。 \n");
        return r_value;
    }
    int vehicle_id = 0;

    if (xml.FindElem("body"))
    {
        xml.IntoElem();
        setlocale(LC_ALL, "chs");
        LOG_OUT(INFO, "[解析body]\n");
        while (xml.FindElem("vehicle"))
        {
            if (atoi(xml.GetAttrib("id").c_str()) == vehicle_id)
            {
                if(xml.FindChildElem("lsh"))
                {
                    string lsh=xml.GetChildData();
                    if(model)
                    {
                        lsh_arrary.push_back(lsh);
                    }
                    else
                    {
                        lsh_arrary_model2.push_back(lsh);
                    }
                }
                vehicle_id++;
            }
        }
    }
    if(r_value == vehicle_id)
    {
        LOG_OUT(INFO, "Analyse_QueryReturn_Lsh_Data:解析完成!! \n");
        return r_value;
    }
    else
    {
        LOG_OUT(WARNING, "Analyse_QueryReturn_Lsh_Data:rownum与实际不符　信息错误!!\nrownum:%d\nvehicle_id:%d\n",r_value,vehicle_id);
        return r_value;
    }
    return r_value;

}


int soapClient::analyse_QueryReturn_Info_Data(string msg, Vehicle_Info *p_vehicle_info ,string model)
{

    p_vehicle_info->model = model;
    char * xmldata =(char *)msg.c_str();
    CMarkup xml;
    int rownum = 0;
    int r_value = -1;//用于xml列表统计与rownum相等
    xml.SetDoc(xmldata);
    xml.ResetMainPos();
    if (!xml.FindElem()) {
        LOG_OUT(ERROR, "Analyse_QueryReturn_Info_Data: Can not find XML element! \n");
        LOG_OUT(ERROR, "Analyse_QueryReturn_Info_Data: data:\n%s\n", xmldata);
        return r_value;
    }
    xml.IntoElem();
    if (xml.FindElem("head"))
    {
        xml.IntoElem();
        setlocale(LC_ALL, "chs");
        if (xml.FindElem("code"))
        {
            if (atoi(xml.GetData().c_str()) == 1)
            {
                xml.ResetMainPos();
                if (xml.FindElem("rownum"))
                {
                    rownum = atoi(xml.GetData().c_str());
                    if (rownum > 0)
                    {
                        r_value = rownum;
                    }
                }
            }
        }
        else
        {
            xml.ResetMainPos();
            if(xml.FindElem("message"))
            {
                string msg = xml.GetChildData();
                LOG_OUT(ERROR, "Analyse_QueryReturn_Lsh_Data: xml error msg --- \n%s\n",msg.c_str());
                return r_value;
            }
        }
        xml.OutOfElem();
    }

    if (rownum < 0) {
        LOG_OUT(ERROR, "Analyse_QueryReturn_Info_Data: Check code error! \n");
        LOG_OUT(ERROR, "Analyse_QueryReturn_Info_Data: data:\n%s\n", xmldata);
        return r_value;
    }

    if (rownum == 0) {
        LOG_OUT(ERROR, "Analyse_QueryReturn_Info_Data: rownum = 0 无车辆信息!\n");
        return r_value;
    }
    int vehicle_id = 0;
    if (xml.FindElem("body"))
    {
        xml.IntoElem();
        setlocale(LC_ALL, "chs");
        LOG_OUT(WARNING, "[解析body]\n");
        if(xml.FindElem("vehicle"))
        {
            for(unsigned int k =0 ; k < ITEMCOUNT ;k++)
            {
                if (xml.FindChildElem(p_vehicle_info->item_description[k].name_tag)){
                    std::string vehicle_str = xml.GetChildData();
                    if (vehicle_str.length() > 0)
                    *static_cast<std::string*>(p_vehicle_info->item_description[k].value) = vehicle_str;
                    xml.ResetChildPos();
                    continue;
                }
            }
            vehicle_id++;
        }
        if(model == "2")
        {
            lsh_filter_temp.push_back(p_vehicle_info->lsh);
        }
        r_value = vehicle_id;
        xml.ResetMainPos();
        vehicle_id = 0;
        while(xml.FindElem("photodes"))
        {
            if (atoi(xml.GetAttrib("id").c_str()) == vehicle_id)
            {
                Photo xml_photo;
                if(xml.FindChildElem("zpzl"))
                {
                    xml_photo.type = xml.GetChildData();

                }
                if(xml.FindChildElem("zpurl"))
                {
                    xml_photo.url = xml.GetChildData();
                }
                p_vehicle_info->photo_list.push_back(xml_photo);
                vehicle_id++;
            }
        }
        if(model == "2")
        {
            for(unsigned int i = 0;i < p_vehicle_info->photo_list.size();i++)
            {
                if(p_vehicle_info->photo_list[i].type.substr(0,1) == "0" || (p_vehicle_info->photo_list[i].type.substr(0,1) == "0"&&p_vehicle_info->photo_list[i].type.size()>1))
                {
                     for(auto it_temp = lsh_filter_temp.begin(); it_temp != lsh_filter_temp.end();it_temp++)
                     {
                         if(*it_temp == p_vehicle_info->lsh)
                         {
                             lsh_filter_temp.erase(it_temp);
                             break;
                         }
                     }
                     break;
                }
            }
        }

        if(0 == vehicle_id)
        {
            LOG_OUT(WARNING, "photodes's xml find error (rownum <=0 ) \n");
            //return -1;
        }
        r_value += vehicle_id;
        xml.ResetMainPos();
        vehicle_id = 0;
        while(xml.FindElem("refphotodes"))
        {
            if (atoi(xml.GetAttrib("id").c_str()) == vehicle_id)
            {
                Photo xml_photo;
                if(xml.FindChildElem("lb"))
                {
                    xml_photo.type = xml.GetChildData();
                }
                if(xml.FindChildElem("zpurl"))
                {
                    xml_photo.url = xml.GetChildData();
                }
                p_vehicle_info->photo_list.push_back(xml_photo);
                vehicle_id++;
            }
        }
        r_value += vehicle_id;
    }
    if(r_value == rownum)
    {
        return r_value;
    }
    else
    {
        LOG_OUT(WARNING, "Analyse_QueryReturn_Info_Data:rownum与解析不符　信息错误!!\nrownum:%d\r_value:%d\n",rownum,r_value);
        return r_value;
    }
    return r_value;
}
