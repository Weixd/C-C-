#include "Log.h"
#include "HelperFile.h"

#include <algorithm>
#include <stdio.h>

#define I_DIR "log/info/"
#define W_DIR "log/warning/"
#define E_DIR "log/error/"

bool sort_by_datetime_asc(std::string &p1, std::string &p2);

Log Log::log_obj;

Log::Log()
{
    /* 指定log名称为当前进程名 */
    char path[1024]={0};
    readlink("/proc/self/exe", path, 1024);
    google::InitGoogleLogging(path);

    hl::creatdir(hl::ownerfolder() + I_DIR);
    hl::creatdir(hl::ownerfolder() + W_DIR);
    hl::creatdir(hl::ownerfolder() + E_DIR);
    google::SetLogDestination(google::GLOG_INFO, I_DIR"info_");
    google::SetLogDestination(google::GLOG_WARNING, W_DIR"warning_");
    google::SetLogDestination(google::GLOG_ERROR, E_DIR"error_");

    google::SetStderrLogging(google::GLOG_INFO);    /* 设定LOG输出到stderr（也就是显示在终端）的最小等级，不影响后台日志记录 */
    FLAGS_colorlogtostderr = true;
    FLAGS_logbufsecs = 0;
    FLAGS_max_log_size = 20;
    FLAGS_stop_logging_if_full_disk = true;
    setLogLevel(google::GLOG_INFO);

    p_clean_thread = NULL;
}

Log::~Log()
{
    if (p_clean_thread != NULL) {
        p_clean_thread->detach();
        delete p_clean_thread;
    }

    google::ShutdownGoogleLogging();
}

Log *Log::getInstance()
{
    return &log_obj;
}

void Log::startCleanThread(unsigned int num)
{
    if (p_clean_thread == NULL) {
        p_clean_thread = new std::thread(std::bind(&Log::cleanThread, this, num));
    }
}

void Log::setLogLevel(int level)
{
    if (level < 0 || level >= 4) {
        return;
    }

    FLAGS_minloglevel = level;
}

void Log::cleanThread(unsigned int num)
{
    LOG_OUT(INFO, "Log clean thread is running...... \n");

    while (true) {
        LOG_OUT(INFO, "Start clean log...... \n");
        delete_more_file(hl::ownerfolder() + I_DIR, num);
        delete_more_file(hl::ownerfolder() + W_DIR, num);
        delete_more_file(hl::ownerfolder() + E_DIR, num);
        LOG_OUT(INFO, "Clean log is complete. \n");

        std::this_thread::sleep_for(std::chrono::hours(1));
    }
}

void Log::delete_more_file(std::string dir, unsigned int logNum)
{
    std::vector<std::string> paths;
    hl::enumfiles_all(dir,paths);
    std::sort(paths.begin(), paths.end(), sort_by_datetime_asc);

    int redundance_count = paths.size() - logNum;

    if (redundance_count > 0) {
        for (int i = 0; i < redundance_count; i++) {
            hl::delpath(paths[i]);
        }
    }
}

bool sort_by_datetime_asc(std::string &p1, std::string &p2)
{
    return hl::file_modify_time(p1)<hl::file_modify_time(p2);
}
