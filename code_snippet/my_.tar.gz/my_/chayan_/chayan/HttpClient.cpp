//#include "afx.h"
#include "HttpClient.h"
#include "http_res_def.h"
#include "jsonMaker.h"
#include <ctime>
//#include <io.h>
#include <stdlib.h>
#include <string.h>


//#include <shlwapi.h>
//#pragma comment(lib, "shlwapi.lib")

extern std::string g_requestUri;
extern std::string g_localServerPort;
static std::string g_photoUri = DOWNLOAD_PHOTO_DATA_TXT;
static std::string g_photoFilePath = LOCAL_PHOTOFILE_PATH;
static std::string g_videoFilePath = LOCAL_VIDEOFILE_PATH;
extern std::string g_demo_path;
extern string IP;
extern std::string g_dzjqxbdUri;
extern std::string g_jqxbd_result;
extern std::string g_request_get_checkitem;
extern configuration serviceConfigure;
extern std::string g_request_reply_result;
void http_requset_post_cb(struct evhttp_request *req, void *arg);
void http_requset_get_cb(struct evhttp_request *req, void *arg);
std::string UTF8toANSI(char *strUTF8);
std::string ANSItoUTF8(char* strAnsi);
/**
 * @brief   HttpClient的构造函数
 *
 * @authors zhaiyangbin
 */
HttpClient::HttpClient()
{
	base = event_base_new();

	m_request_text_type = 0;
    m_uri = nullptr;
    m_post_data = nullptr;
    m_connection = nullptr;
    m_request_flag = REQUEST_GET_FLAG;
    m_content_type = strdup(HTTP_CONTENT_TYPE_URL_ENCODED);
    recv_data = nullptr;
    recv_length = 0;

}
/**
 * @brief   HttpClient的析构函数
 *
 * @authors zhaiyangbin
 */
HttpClient::~HttpClient()
{
    if (m_content_type)
    {
        free(m_content_type);
        m_content_type = nullptr;
    }
    if (m_post_data)
    {
        free(m_post_data);
        m_post_data = nullptr;
    }
    event_base_free(base);
}

/**
 * @brief   httpclient服务的初始化函数
 *
 * @param   [0]httpclient请求类型
 *          [1]httpclient请求uri
 *          [2]httpclient请求标识,默认为get
 *          [4]httpclient内容类型,默认为"application/x-www-form-urlencoded"
 *          [5]httpclient请求数据
 *
 * @authors zhaiyangbin
 */
bool HttpClient::InitData(int request_type , const char *uri, int request_flag, const char* content_type, const char* data)
{
    m_request_text_type = request_type;

	m_uri = evhttp_uri_parse(uri);
    if (!m_uri)
    {
        LOG_OUT(ERROR, "URI has unsafe code! \n");
        return false;
	}

	m_request_flag = request_flag;

    if (content_type != nullptr)
    {
        m_content_type = strdup(content_type);
    }

    if (data != nullptr)
    {
        m_post_data = strdup(data);
    }

    return true;
}
/**
 * @brief   http Post服务请求回调函数
 *
 * @param   [0]含有request请求的evhttp_request类型的指针
 *          [1]包含post请求返回数据的指针
 *
 * @authors zhaiyangbin
 */

/************************** Request Function ******************************/
void http_requset_post_cb(struct evhttp_request *req, void *arg)
{
    LOG_OUT(INFO, "<-----http_requset_post_cb is in  - \n");
    HttpClient *httpclientpost = static_cast<HttpClient*>(arg);
    if (req == nullptr)
	{
        LOG_OUT(INFO, "HTTP client[POST]: no response! \n");
        LOG_OUT(INFO, "URL: %s:%d%s \n",
                   evhttp_uri_get_host(httpclientpost->m_uri),
                   evhttp_uri_get_port(httpclientpost->m_uri),
                   evhttp_uri_get_path(httpclientpost->m_uri));

		httpclientpost->d_success_flag = false;
        event_base_loopexit(httpclientpost->base, nullptr);
		return;
	}

    httpclientpost->d_success_flag = true;
    struct evbuffer* buf = evhttp_request_get_input_buffer(req);
    unsigned int len = static_cast<unsigned int>(evbuffer_get_length(buf)) ;

	switch (req->response_code)
	{
    case HTTP_OK:
        if(len > 0 && len < HTTP_MAX_RECV_LEN)
        {
            LOG_OUT(INFO, "http_requset_post_cb HTTP_OK len:%d\n",len);
            char *data = new char[HTTP_MAX_RECV_LEN];
            evbuffer_copyout(buf, data, len);
            *(data + len) = '\0';
            httpclientpost->ResponseData = data;
            delete[] data;
            data = nullptr;
        }

        event_base_loopexit(httpclientpost->base, nullptr);
        break;

    case HTTP_MOVEPERM:
        LOG_OUT(INFO, "<-----Client:");
        LOG_OUT(INFO, "%s\n", "the uri moved permanently");
        break;
    case HTTP_MOVETEMP:
    {
        const char *new_location = evhttp_find_header(req->input_headers, "Location");
        struct evhttp_uri *new_uri = evhttp_uri_parse(new_location);
        evhttp_uri_free(httpclientpost->m_uri);
        httpclientpost->m_uri = new_uri;
        httpclientpost->start_url_request();
        return;
    }
    default:
        LOG_OUT(ERROR, "HTTP client[POST]: abnormal response! \n");
        LOG_OUT(ERROR, "HTTP code: %d, Message:%s \n", req->response_code, req->response_code_line);
        LOG_OUT(ERROR, "URL: %s:%d%s \n",
                   evhttp_uri_get_host(httpclientpost->m_uri),
                   evhttp_uri_get_port(httpclientpost->m_uri),
                   evhttp_uri_get_path(httpclientpost->m_uri));

        event_base_loopexit(httpclientpost->base, nullptr);
        return;
	}

}
/**
 * @brief   http Get服务请求回调函数
 *
 * @param   [0]含有request请求的evhttp_request类型的指针
 *          [1]包含get请求返回数据的指针
 *
 * @authors zhaiyangbin
 */
void http_requset_get_cb(struct evhttp_request *req, void *arg)
{
    LOG_OUT(INFO, "<-----http_requset_get_cb is in  - \n");
    HttpClient *httpclientget = static_cast<HttpClient*>(arg);
    //struct evkeyvalq *headers;
    //struct evkeyval *header;

    if (req == nullptr)
    {
        LOG_OUT(ERROR, "HTTP client[GET]: no response! \n");
        LOG_OUT(ERROR, "URL: %s:%d%s \n",
                   evhttp_uri_get_host(httpclientget->m_uri),
                   evhttp_uri_get_port(httpclientget->m_uri),
                evhttp_uri_get_path(httpclientget->m_uri));

     httpclientget->d_success_flag = false;
     httpclientget->m_photo_filename = "TBD";
     event_base_loopexit(httpclientget->base, nullptr);
     return;
    }

    switch (req->response_code)
	{
	case HTTP_OK:
	{
        LOG_OUT(INFO, "HTTP_OK \n");
        struct evbuffer* buf = evhttp_request_get_input_buffer(req);
        unsigned int len = static_cast<unsigned int>(evbuffer_get_length(buf));
        LOG_OUT(INFO, "http_requset_get_cb HTTP_OK len:%d\n",len);
        if(len > 0 && len < HTTP_MAX_RECV_LEN){
            unsigned char *data = new unsigned char[HTTP_MAX_RECV_LEN];
            evbuffer_copyout(buf, data, len);
            *(data + len) = '\0';

            httpclientget->recv_length = len;
            httpclientget->recv_data = data;
            //sleep(1);
            httpclientget->ResponseData = (char*)data;
            httpclientget->d_success_flag = true;

            //free(data);
            //delete[] data;
            data = nullptr;
        }
        event_base_loopexit(httpclientget->base, nullptr);

		break;
	}
	case HTTP_MOVEPERM:
    {
        LOG_OUT(ERROR, "<-----Client:");
        LOG_OUT(ERROR, "%s\n", "the uri moved permanently");
        httpclientget->m_photo_filename = "TBD";
        event_base_loopexit(httpclientget->base, nullptr);
		break;
    }
	case HTTP_MOVETEMP:
	{
        LOG_OUT(INFO, "HTTP_MOVETEMP \n");
		const char *new_location = evhttp_find_header(req->input_headers, "Location");
		struct evhttp_uri *new_uri = evhttp_uri_parse(new_location);
		evhttp_uri_free(httpclientget->m_uri);
		httpclientget->m_uri = new_uri;
		httpclientget->start_url_request();
		return;
	}

    default:
    {
        LOG_OUT(ERROR, "HTTP client[GET]: abnormal response! \n");
        LOG_OUT(ERROR, "HTTP code: %d, Message:%s \n", req->response_code, req->response_code_line);
        LOG_OUT(ERROR, "URL: %s:%d%s \n",
                   evhttp_uri_get_host(httpclientget->m_uri),
                   evhttp_uri_get_port(httpclientget->m_uri),
                   evhttp_uri_get_path(httpclientget->m_uri));

        httpclientget->m_photo_filename = "TBD";
        event_base_loopexit(httpclientget->base, nullptr);
		return;
    }
	}
}

/************************** Start POST/GET Function ******************************/
/**
* @param content_type: refer HTTP_CONTENT_TYPE_*
*/

int HttpClient::start_url_request()
{
	struct evkeyvalq params;

	if (m_request_text_type == DOWNLOAD_PHOTO_DATA)
	{
		evhttp_parse_query_str(evhttp_uri_get_query(m_uri), &params);
		const char *fid = evhttp_find_header(&params, "id");
        if (fid != nullptr)
        {
            m_photo_fileid = std::string(fid);
        }
        m_photo_filename = serviceConfigure.photoFile;
        struct stat st_first;
        memset(&st_first,0,sizeof(st_first));
        stat(m_photo_filename.c_str(), &st_first);
        if ((st_first.st_mode & S_IFMT) != S_IFDIR) {
            mkdir(m_photo_filename.c_str(), 0777);
        }
        std::time_t t = std::time(nullptr);
		std::tm *st = std::localtime(&t);
		char tmpArray[128] = { 0 };
		sprintf(tmpArray, "%d-%02d-%02d", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);
        std::string strCurTime = tmpArray;
		m_photo_filename += strCurTime;
        struct stat st_buf;
        memset(&st_buf,0,sizeof(st_buf));
        stat(m_photo_filename.c_str(), &st_buf);
        if ((st_buf.st_mode & S_IFMT) != S_IFDIR) {
            mkdir(m_photo_filename.c_str(), 0777);
        }
        m_photo_filename += "/";
        m_photo_filename += m_local_path;//m_photo_filename:/opt/vehilce/vehicle_photo/2019-04-04/0111_hphm_....
        //m_photo_filename += m_photo_fileid;
		evhttp_clear_headers(&params);

	}
	if (m_connection)
		evhttp_connection_free(m_connection);
    int port = evhttp_uri_get_port(m_uri);
    //if (port == -1) port = atoi(g_localServerPort.c_str()) + 1;
    m_connection = evhttp_connection_base_new(base, nullptr, evhttp_uri_get_host(m_uri), static_cast<unsigned short>(port));
    evhttp_connection_set_retries(m_connection, 1);
    evhttp_connection_set_timeout(m_connection, 3);
	/**
	* Request will be released by evhttp connection
	* See info of evhttp_make_request()
	*/
    if (m_request_flag == REQUEST_POST_FLAG)
    {
		m_httpreq = evhttp_request_new(http_requset_post_cb, this);
	}
    else if (m_request_flag == REQUEST_GET_FLAG)
    {
		m_httpreq = evhttp_request_new(http_requset_get_cb, this);
	}
	else if (m_request_flag == REQUEST_SOAP_FLAG)
	{
		m_httpreq = evhttp_request_new(http_requset_post_cb, this);
	}
	/** Set the header properties */
	evhttp_add_header(m_httpreq->output_headers, "Host", evhttp_uri_get_host(m_uri));
    if (m_request_flag == REQUEST_POST_FLAG)
    {
		const char* query = evhttp_uri_get_query(m_uri);
		const char* path = evhttp_uri_get_path(m_uri);
        string path_query = "";
		if (path)
			path_query = path;
		if (query)
		{
			path_query += "?"; 
			path_query += query;
		}
		/** Set the post data */
		if (m_post_data)
			evbuffer_add(m_httpreq->output_buffer, ANSItoUTF8(m_post_data).c_str(), strlen(ANSItoUTF8(m_post_data).c_str()));
		evhttp_add_header(m_httpreq->output_headers, "Content-Type", m_content_type);
        if(m_post_data)
        {
		char num[10];
        //_itoa_s((UINT)strlen(ANSItoUTF8(m_post_data).c_str()), num, 10);

        itoa(static_cast<unsigned int>(strlen(ANSItoUTF8(m_post_data).c_str())) , num, 10);
		evhttp_add_header(m_httpreq->output_headers, "Length", num);
        }
		evhttp_make_request(m_connection, m_httpreq, EVHTTP_REQ_POST,
			(path_query.length()>1) ? path_query.data() : "/");
	}
    else if (m_request_flag == REQUEST_SOAP_FLAG)
    {

		const char* query = evhttp_uri_get_query(m_uri);
		const char* path = evhttp_uri_get_path(m_uri);
		string path_query;
		if (path)
			path_query = path;
		if (query)
		{
			path_query += "?";
			path_query += query;
		}

		/** Set the post data */
		if (m_post_data)
        evbuffer_add(m_httpreq->output_buffer, ANSItoUTF8(m_post_data).c_str(), strlen(ANSItoUTF8(m_post_data).c_str()));
		evhttp_add_header(m_httpreq->output_headers, "Content-Type", m_content_type);
		char num[10];
        //_itoa_s((UINT)strlen(ANSItoUTF8(m_post_data).c_str()), num, 10);
        itoa(static_cast<unsigned int>(strlen(ANSItoUTF8(m_post_data).c_str())), num, 10);
		evhttp_add_header(m_httpreq->output_headers, "Length", num);

		evhttp_make_request(m_connection, m_httpreq, EVHTTP_REQ_POST,
			(path_query.length()>1) ? path_query.data() : "/");
	}
	else if (m_request_flag == REQUEST_GET_FLAG) {
		const char* query = evhttp_uri_get_query(m_uri);
		const char* path = evhttp_uri_get_path(m_uri);
		string path_query;
		if (path)
			path_query = path;
		if (query)
		{
			path_query += "?";
			path_query += query;
		}
		evhttp_make_request(m_connection, m_httpreq, EVHTTP_REQ_GET,
			(path_query.length()>1) ? path_query.data() : "/");
	}
	return 0;
}

/************************** New/Free Function ******************************/
/**
* @param get_flag: refer REQUEST_GET_*
*
*/

void  HttpClient::http_request_free()
{
	evhttp_connection_free(m_connection);
    m_connection = nullptr;
	evhttp_uri_free(m_uri);
    m_uri = nullptr;
}

bool HttpClient::startHttpClient()
{
    LOG_OUT(INFO, "HttpClient ResponseData.clear url:%s ......\n",evhttp_uri_get_path(m_uri));
    ResponseData.clear();
    LOG_OUT(INFO, "HttpClient start_url_request url:%s ......\n",evhttp_uri_get_path(m_uri));
    start_url_request();

    LOG_OUT(INFO, "HTTP client has sent request(host:%s, port:%d, path:%s)......\n",
               evhttp_uri_get_host(m_uri), evhttp_uri_get_port(m_uri), evhttp_uri_get_path(m_uri));

    event_base_dispatch(base);
    http_request_free();

    return true;
}

std::string UTF8toANSI(char *strUTF8)
{
//    size_t nLen = strlen(strUTF8) * 4;    /* 4倍长度足够任何编码形式 */
//    char *szBuffer = new char[nLen + 1];
//    code_convert("UTF-8", "ANSI", strUTF8, strlen(strUTF8), szBuffer, nLen);

//    std::string ansistr;
//    ansistr = szBuffer;

//    delete szBuffer;

    std::string ansistr = "";

    if(strUTF8 != nullptr)
    {
        ansistr = strUTF8;
    }
    return ansistr;
}

std::string ANSItoUTF8(char* strAnsi)
{
//    size_t nLen = strlen(strAnsi) * 4;    /* 4倍长度足够任何编码形式 */
//    char *szBuffer = new char[nLen + 1];
//    code_convert("ANSI", "UTF-8", strAnsi, strlen(strAnsi), szBuffer, nLen);

//    std::string ansistr;
//    ansistr = szBuffer;

//    delete szBuffer;

    std::string ansistr = "";

    if(strAnsi != nullptr)
    {
        ansistr = strAnsi;
    }

    return ansistr;
}



