#include <vector>
#include <iostream>

#include <mysql/mysqld_error.h>
#include "MySQL_DB.h"
#include "./Log.h"

/*
本文件内定义了MySQL数据库表格升级相关的函数。
*/

typedef bool (*update_version)(MySQL_DB &db);

static std::vector<update_version> update_list;

bool update_1(MySQL_DB &db);
bool update_2(MySQL_DB &db);
bool update_3(MySQL_DB &db);
bool update_table()
{
    LOG_OUT(INFO, "开始检查当前数据库表格版本...... \n");
    LOG_OUT(INFO, "请勿终止程序或者操作数据库！\n");

    bool ret = true;
    unsigned int version = 0;

    MySQL_DB db;
    if (db.connect(NULL, 3306, "root", "em-data-9527", NULL)) {
        if (db.selectDB("car_info_schema")) {
            std::string sqlString = "SELECT version FROM database_version";

            MYSQL_RES *result = db.getResult(sqlString.c_str());
            if (result != NULL) {
                MYSQL_ROW row = NULL;
                row = mysql_fetch_row(result);

                try {
                    version = std::stoi(row[0]);
                } catch (const std::exception &e) {
                    std::cout << "Error: " << e.what() << std::endl;
                    ret = false;
                }

                db.freeResult(result);
            } else {
                ret = false;
            }
        } else {
            if (db.getErrorNumber() == ER_BAD_DB_ERROR) {	/* 如果数据库不存在，则创建新的数据库 */
                version = 0;
                LOG_OUT(INFO, "The database \"car_info_schema\" does not exist, ready to create a new database. \n");
            } else {
                ret = false;
            }
        }
    } else {
        ret = false;
    }

    if (ret) {
        /* 加载数据库所有版本的升级函数 */
        update_list.push_back(update_1);
        update_list.push_back(update_2);
        update_list.push_back(update_3);

        if (version < update_list.size()) {
            /* 执行升级过程 */
            for (unsigned int i = version; i < update_list.size(); i++) {
                if (!update_list[i](db)) {  /* 任何一个版本的程序升级失败，都不能再进行下一个版本的升级操作 */
                    ret = false;
                    break;
                }
            }
        } else if (version == update_list.size()) {
            LOG_OUT(INFO,
                    "The current version of the database is [%d], which is the latest version and does not need to be updated. \n",
                    version);
        } else {
            ret = false;
            LOG_OUT(ERROR,
                    "数据库版本异常！当前程序维护版本：%ld，实际获取版本：%d \n",
                    update_list.size(), version);
        }
    }

    db.disconnect();

    LOG_OUT(INFO, "数据库版本检查%s \n", ret ? "完毕。" : "发现错误！");
    return ret;
}

/*
数据库版本：1
内容：
创建表格general_info，photo_info, database_version
*/
bool update_1(MySQL_DB &db)
{
    LOG_OUT(INFO, "Start updating the database to version [1] ...... \n");

    if (!db.createDB("car_info_schema")) {
        return false;
    }

    db.selectDB("car_info_schema");

    std::string sqlString = "(";
    sqlString += "id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT '主键',";
    sqlString += "lsh VARCHAR(64) DEFAULT NULL COMMENT '流水号',";
    sqlString += "ywlx VARCHAR(64) DEFAULT NULL COMMENT '业务类型',";
    sqlString += "ywyy VARCHAR(64) DEFAULT NULL COMMENT '业务原因',";
    sqlString += "hpzl VARCHAR(32) DEFAULT NULL COMMENT '号牌种类',";
    sqlString += "hphm VARCHAR(16) DEFAULT NULL COMMENT '号牌号码',";

    sqlString += "clsbdh VARCHAR(32) DEFAULT NULL COMMENT '车辆识别代号',";
    sqlString += "syr VARCHAR(32) DEFAULT NULL COMMENT '使用人',";
    sqlString += "sxrq VARCHAR(64) DEFAULT NULL COMMENT '生效日期',";
    sqlString += "zzrq VARCHAR(64) DEFAULT NULL COMMENT '终止日期',";
    sqlString += "cllx VARCHAR(16) DEFAULT NULL COMMENT '车辆类型',";

    sqlString += "syxz VARCHAR(16) DEFAULT NULL COMMENT '使用性质',";
    sqlString += "zbzl VARCHAR(16) DEFAULT NULL COMMENT '整备质量',";
    sqlString += "fdjh VARCHAR(64) DEFAULT NULL COMMENT '发动机号_电动机号',";
    sqlString += "clpp1 VARCHAR(32)DEFAULT NULL  COMMENT '车辆品牌',";
    sqlString += "clxh VARCHAR(32) DEFAULT NULL COMMENT '车辆型号',";

    sqlString += "ccdjrq VARCHAR(64) DEFAULT NULL COMMENT '初次登记日期',";
    sqlString += "ccrq VARCHAR(64) DEFAULT NULL COMMENT '出厂日期',";
    sqlString += "kssj VARCHAR(64) DEFAULT NULL COMMENT '开始时间',";
    sqlString += "jssj VARCHAR(64) DEFAULT NULL COMMENT '结束时间',";
    sqlString += "zpzs VARCHAR(16) DEFAULT NULL COMMENT '照片总数',";

    sqlString += "spzs VARCHAR(16) DEFAULT NULL COMMENT '视频总数',";
    sqlString += "xszbh VARCHAR(20) DEFAULT NULL COMMENT '行驶证编号',";
    sqlString += "rlzl VARCHAR(3) DEFAULT NULL COMMENT '燃料种类',";
    sqlString += "fzrq VARCHAR(64) DEFAULT NULL COMMENT '发证日期',";
    sqlString += "csys VARCHAR(8) DEFAULT NULL COMMENT '车身颜色',";

    sqlString += "pl VARCHAR(16) DEFAULT NULL COMMENT '排量',";
    sqlString += "gl VARCHAR(10) DEFAULT NULL COMMENT '功率',";
    sqlString += "zxxs VARCHAR(8) DEFAULT NULL COMMENT '转向形式',";
    sqlString += "cwkc VARCHAR(16) DEFAULT NULL COMMENT '车外廓长',";
    sqlString += "cwkk VARCHAR(16) DEFAULT NULL COMMENT '车外廓宽',";

    sqlString += "cwkg VARCHAR(16) DEFAULT NULL COMMENT '车外廓高',";
    sqlString += "hxnbcd VARCHAR(16) DEFAULT NULL COMMENT '货箱内部长度',";
    sqlString += "hxnbkd VARCHAR(16) DEFAULT NULL COMMENT '货箱内部宽度',";
    sqlString += "hxnbgd VARCHAR(16) DEFAULT NULL COMMENT '货箱内部高度',";
    sqlString += "gbthps VARCHAR(16) DEFAULT NULL COMMENT '钢板弹簧片数',";

    sqlString += "zs VARCHAR(16) DEFAULT NULL COMMENT '轴数',";
    sqlString += "zj VARCHAR(16) DEFAULT NULL COMMENT '轴距',";
    sqlString += "qlj VARCHAR(16) DEFAULT NULL COMMENT '前轮距',";
    sqlString += "hlj VARCHAR(16) DEFAULT NULL COMMENT '后轮距',";
    sqlString += "ltgg VARCHAR(64) DEFAULT NULL COMMENT '轮胎规格',";

    sqlString += "lts VARCHAR(16) DEFAULT NULL COMMENT '轮胎数',";
    sqlString += "zzl VARCHAR(16) DEFAULT NULL COMMENT '总质量',";
    sqlString += "hdzzl VARCHAR(16) DEFAULT NULL COMMENT '核定载质量',";
    sqlString += "hdzk VARCHAR(16) DEFAULT NULL COMMENT '核定载客',";
    sqlString += "zqyzl VARCHAR(16) DEFAULT NULL COMMENT '准牵引质量',";

    sqlString += "qpzk VARCHAR(16) DEFAULT NULL COMMENT '驾驶室前排载客人数',";
    sqlString += "hpzk VARCHAR(16) DEFAULT NULL COMMENT '驾驶室后排载客人数',";
    sqlString += "clyt VARCHAR(8) DEFAULT NULL COMMENT '车辆用途',";
    sqlString += "ytsx VARCHAR(8) DEFAULT NULL COMMENT '用途属性',";
    sqlString += "sfxny VARCHAR(8) DEFAULT NULL COMMENT '是否新能源汽车',";

    sqlString += "xnyzl VARCHAR(8) DEFAULT NULL COMMENT '新能源汽车种类',";
    sqlString += "clpp2 VARCHAR(32)DEFAULT NULL  COMMENT '英文品牌',";
    sqlString += "gcjk VARCHAR(8) DEFAULT NULL COMMENT '国产/进口',";
    sqlString += "zzg VARCHAR(64) DEFAULT NULL COMMENT '制造国',";
    sqlString += "zzcmc VARCHAR(64) DEFAULT NULL COMMENT '制造厂名称',";

    sqlString += "djrq VARCHAR(64) DEFAULT NULL COMMENT '最近定检日期',";
    sqlString += "yxqz VARCHAR(64) DEFAULT NULL COMMENT '检验有效期止',";
    sqlString += "qzbfqz VARCHAR(64) DEFAULT NULL COMMENT '强制报废期止',";
    sqlString += "fzjg VARCHAR(32) DEFAULT NULL COMMENT '发证机关',";
    sqlString += "glbm VARCHAR(16) DEFAULT NULL COMMENT '管理部门',";

    sqlString += "zt VARCHAR(8) DEFAULT NULL COMMENT '机动车状态',";
    sqlString += "dybj VARCHAR(8) DEFAULT NULL COMMENT '抵押标记',";
    sqlString += "fdjxh VARCHAR(64) DEFAULT NULL COMMENT '发动机型号',";
    sqlString += "hbdbqk VARCHAR(128) DEFAULT NULL COMMENT '环保达标情况',";
    sqlString += "jyhgbzbh VARCHAR(20) DEFAULT NULL COMMENT '检验合格标志',";

    sqlString += "xzqh VARCHAR(10) DEFAULT NULL COMMENT '管理辖区',";
    sqlString += "zsxzqh VARCHAR(16) DEFAULT NULL COMMENT '住所地址行政区划',";
    sqlString += "zzxzqh VARCHAR(16) DEFAULT NULL COMMENT '暂住地址行政区划',";
    sqlString += "cyqxh VARCHAR(32) DEFAULT NULL COMMENT '查验区序号',";
    sqlString += "xh VARCHAR(16) DEFAULT NULL COMMENT '机动车序号',";

    sqlString += "cyry VARCHAR(32) DEFAULT NULL COMMENT '查验员身份证明号码',";
    sqlString += "fdjrq VARCHAR(64) DEFAULT NULL COMMENT '发登记证书日期',";
    sqlString += "fhgbzrq VARCHAR(64) DEFAULT NULL COMMENT '发合格标志日期',";
    sqlString += "model VARCHAR(64) DEFAULT NULL COMMENT '外观表单标志',";
    sqlString += "time_result_back VARCHAR(64) DEFAULT NULL COMMENT '结果写回时间',";
    sqlString += "status_result_back VARCHAR(64) DEFAULT NULL COMMENT '结果写回状态',";

    sqlString += "device_ip VARCHAR(32) DEFAULT NULL COMMENT '设备IP',";
    sqlString += "gongweiID VARCHAR(8) DEFAULT NULL COMMENT '工位ID',";
    sqlString += "ispass VARCHAR(8) DEFAULT NULL COMMENT '整车通过',";

    sqlString += "created_time DATETIME NOT NULL DEFAULT NOW() COMMENT '本行创建时间',";
    sqlString += "KEY `index_jylsh` (`lsh`),";
    sqlString += "KEY `index_clsbdh` (`clsbdh`),";
    sqlString += "KEY `index_hphm` (`hphm`),";
    sqlString += "KEY `index_created_time` (`created_time`)";
    sqlString += ") COMMENT='车辆基本信息表'";
    if (!db.createTable("vehicle_info", sqlString.c_str())) {
        return false;
    }

    /* create photo table */
    sqlString = "(";
    sqlString += "id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT '主键',";
    sqlString += "vehicle_id INT UNSIGNED NOT NULL COMMENT '外键，连接vehicle_info的主键',";
    sqlString += "lsh VARCHAR(64) DEFAULT NULL COMMENT '流水号',";
    sqlString += "clsbdh VARCHAR(32) DEFAULT NULL COMMENT '车辆识别代号',";
    sqlString += "hphm VARCHAR(16) DEFAULT NULL COMMENT '号牌号码',";
    sqlString += "type VARCHAR(8) DEFAULT NULL COMMENT '照片种类',";
    sqlString += "path VARCHAR(256) DEFAULT NULL COMMENT '照片保存路径',";
    sqlString += "result VARCHAR(8) DEFAULT NULL COMMENT '照片结果',";
    sqlString += "reason VARCHAR(512) DEFAULT NULL COMMENT '结果详细说明',";
    sqlString += "total_time_algorithm VARCHAR(16) DEFAULT NULL COMMENT '算法处理时间',";
    sqlString += "created_time DATETIME NOT NULL DEFAULT NOW() COMMENT '本行数据记录时间',";
    sqlString += "FOREIGN KEY (`vehicle_id`) REFERENCES `vehicle_info` (`id`),";
    sqlString += "KEY `index_clsbdh` (`clsbdh`),";
    sqlString += "KEY `index_hphm` (`hphm`),";
    sqlString += "KEY `index_created_time` (`created_time`)";
    sqlString += ") COMMENT='车辆照片信息表'";
    if (!db.createTable("photo_info", sqlString.c_str())) {
        return false;
    }

    /* 数据库版本表格*/
    sqlString = "(";
    sqlString += "id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT '主键',";
    sqlString += "version INT DEFAULT -1 COMMENT '数据库表格版本'";
    sqlString += ") COMMENT='数据库版本表'";
    if (!db.createTable("database_version", sqlString.c_str())) {
        return false;
    }

    if (!db.insert("database_version", "(version) VALUES (0)")) {
        return false;
    }

    /* 更新当前数据库版本 */
    if (!db.update("database_version", "SET version='1' WHERE id='1'")) {
        return false;
    }

    sqlString = "convert to character set utf8";
    db.alterTable("car_info_schema.vehicle_info", sqlString.c_str());
    db.alterTable("car_info_schema.photo_info", sqlString.c_str());
    LOG_OUT(INFO, "The update of version [1] has been completed. \n");
    return true;
}

bool update_2(MySQL_DB &db)
{
    LOG_OUT(INFO, "Start updating the database to version [2] ...... \n");

    db.selectDB("car_info_schema");

    std::string sqlString = " CHANGE type category VARCHAR(8) DEFAULT NULL COMMENT '照片种类'";
    if(!db.alterTable("car_info_schema.photo_info",sqlString.c_str()))
    {
        return false;
    }
    /* 更新当前数据库版本 */
    if (!db.update("database_version", "SET version='2' WHERE id='1'")) {
        return false;
    }
    return true;
}

bool update_3(MySQL_DB &db)
{
    LOG_OUT(INFO, "Start updating the database to version [3] ...... \n");

    db.selectDB("car_info_schema");
    std::string sqlString = "ADD COLUMN `sqshsj` VARCHAR(64) DEFAULT NULL COMMENT '申请审核时间' AFTER `djrq`";

    if(!db.alterTable("car_info_schema.vehicle_info",sqlString.c_str()))
    {
        return false;
    }
    /* 更新当前数据库版本 */
    if (!db.update("database_version", "SET version='3' WHERE id='1'")) {
        return false;
    }
    return true;
}
