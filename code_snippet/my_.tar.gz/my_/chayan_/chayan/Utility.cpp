#include "Utility.h"

#include <ctime>
#include <vector>
#include <sys/statfs.h>
#include <dirent.h>
unsigned char toHex(const unsigned char &x)
{
    return x > 9 ? x - 10 + 'A' : x + '0';
}

unsigned char fromHex(const unsigned char &x)
{
    if (isdigit(x)) {
        return x - '0';
    } else if (isupper(x)) {
        return x - 'A' + 10;
    } else {
        return x - 'a' + 10;
    }
}

std::string URLEncode(const std::string &sIn)
{
    std::string sOut;

    for (size_t ix = 0; ix < sIn.size(); ix++) {
        unsigned char buf[4] = {0};

        if (isalnum((unsigned char)sIn[ix])) {
            buf[0] = sIn[ix];
        } else {
            buf[0] = '%';
            buf[1] = toHex((unsigned char)sIn[ix] >> 4);
            buf[2] = toHex((unsigned char)sIn[ix] % 16);
        }

        sOut += (char *)buf;
    }

    return sOut;
}

std::string URLDecode(const std::string &sIn)
{
    std::string sOut;

    for (size_t ix = 0; ix < sIn.size(); ix++) {
        unsigned char ch = 0;

        if (sIn[ix] == '%') {
            ch = (fromHex(sIn[ix + 1]) << 4);
            ch |= fromHex(sIn[ix + 2]);
            ix += 2;
        } else if (sIn[ix] == '+') {
            ch = ' ';
        } else {
            ch = sIn[ix];
        }

        sOut += (char)ch;
    }

    return sOut;
}

std::string getCurrentTime(CurrentTime_t &time)
{
    std::time_t t = std::time(NULL);
    std::tm *st = std::localtime(&t);

    time.year = st->tm_year + 1900;
    time.month = st->tm_mon + 1;
    time.day = st->tm_mday;
    time.hour = st->tm_hour;
    time.minute = st->tm_min;
    time.second = st->tm_sec;

    char tmpArray[128] = { 0 };
    sprintf(tmpArray, "%d-%02d-%02d %02d:%02d:%02d",
            time.year, time.month, time.day, time.hour, time.minute, time.second);

    return std::string(tmpArray);
}

long getFileSystemFreeSpace(const char *path)
{
    struct statfs info = {};

    if (statfs(path, &info) != 0) {
        perror("statfs() failed");
        return -1;
    }

    unsigned long long freeBytes = info.f_bavail * info.f_bsize;
    long freeGB = freeBytes / (1024 * 1024 * 1024);

    return freeGB;
}

bool getFolderContent(const char *path, std::vector<std::string> &list)
{
    struct dirent **namelist;

    int n = scandir(path, &namelist, 0, alphasort);
    if (n < 0) {
        perror("scandir() failed");
        return false;
    }

    for (int i = 0; i < n; i++) {
        list.push_back(std::string(namelist[i]->d_name));
        free(namelist[i]);
    }

    free(namelist);

    return true;
}

std::string getNowTime()
{
    std::string outTime;
    time_t timep;
    time(&timep);
    char tmp[64]={0};

    strftime(tmp,sizeof(tmp),"%H:%M:%S;",localtime(&timep));
    outTime = tmp;
    return outTime;
}

std::string getNowTimeLong()
{
    std::string outTime;
    time_t timep;
    time(&timep);
    char tmp[64]={0};

    strftime(tmp,sizeof(tmp),"%Y-%m-%d %H:%M:%S",localtime(&timep));
    outTime = tmp;
    return outTime;
}

double diffStringTimeNow(const std::string &time_string)
{
    if(time_string.size() != 21)
    {
        return 0;
    }
    struct tm tm1;
    time_t timeNow;
    time_t time1;
    int m=0;

    time(&timeNow);
    sscanf(time_string.c_str(),"%d-%d-%d %d:%d:%d.%d",
           &(tm1.tm_year),
           &(tm1.tm_mon),
           &(tm1.tm_mday),
           &(tm1.tm_hour),
           &(tm1.tm_min),
           &(tm1.tm_sec),
           &m
           );
    tm1.tm_year -= 1900;
    tm1.tm_mon--;

    time1 = mktime(&tm1);

    return difftime(timeNow,time1);
}

std::string getDangTianRiQi()
{
    std::time_t t = std::time(NULL);
    std::tm *st = std::localtime(&t);

    char tmpArray[128] = { 0 };
    sprintf(tmpArray, "%d-%02d-%02d",
            st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);

    return std::string(tmpArray);
}
