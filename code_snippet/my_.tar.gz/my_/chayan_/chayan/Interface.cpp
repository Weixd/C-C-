#include "Log.h"
#include "HttpClient.h"
#include "HttpServer.h"
#include "Utility.h"
#include "vehicle_info.h"
#include "Markup.h"
#include "PrepareXml.h"
#include "time.h"
#include "http_res_def.h"
#include "chayan_main.h"
#include "Queue.h"
#include "jsonMaker.h"
#include <map>
#include "Utility.h"
#include "ZBase64.h"

//本cpp定义为配合http处理相关业务模块
void analyseData(evhttp_request *req, HTTP_Server *server);
bool checkRemoteHost(std::string IP);
bool checkXMLStructure(std::string data);
void sendResponse(evhttp_request *req, HTTP_Server *server, unsigned int ResponseCode, std::string ResultElement);
void request_handle(evhttp_request *req, void *arg);
extern void recordSendTime(const Vehicle_Info* pVehicle_info);
extern std::map<std::string,long> send_vehicle_info;
std::vector<RecvRenGongData> rengong_result;
class service;
extern Queue service_queue;
extern std::mutex my_mutex;
/*开始http监听*/
void startInterface()
{

    int buf_port= atoi(PORT);
    HTTP_Server server("0.0.0.0",static_cast<unsigned short>(buf_port));
    server.startListen(request_handle);

}

//分析从机返回信息
bool analyseSlaveReply(std::string data)
{
    bool is_ok = true;
    int code = 0;
    CMarkup xml;
    xml.SetDoc(data.c_str());

    if(xml.FindElem("root"))
    {
        xml.IntoElem();

        if(xml.FindElem("head"))
        {
            if(xml.FindChildElem("code"))
            {
                code = atoi(xml.GetChildData().c_str());
                if (code != 0)
                {
                    is_ok = false;
                    if(xml.FindElem("message"))
                    {
                        LOG_OUT(ERROR,"Receive slave reply:code is %d,message is %s",code,xml.GetChildData().c_str());
                    }
                }
                else
                {
                    if(xml.FindElem("message"))
                    {
                        LOG_OUT(INFO,"Receive slave reply:code is %d,message is %s",code,xml.GetChildData().c_str());
                    }
                }
            }

        }
    }

    return is_ok;
}
//主机向从机分发车辆信息


bool distributeDataThread(Vehicle_Info* pVehicle_info,std::vector<std::string> IpList)
{
    static unsigned int index = 0;
    std::string IP;

    index = index%IpList.size();//按顺序依次发送给从机
    IP = IpList[index];
    index++;

    std::string RequestUri = "/CarCheck";

    if(pVehicle_info == nullptr)
    {
        return false;
    }
    /*Prepare xml data*/

    PrepareXML* preparexml = new PrepareDistributeData();
    std::string preparexml_data;
    preparexml->setIP(IP);
    preparexml->setPort(PORT);
    preparexml->setRequestUri(RequestUri);
    pVehicle_info->device_ip = IP.substr(0,IP.find(":"));

    preparexml_data = preparexml->PrepareXml(pVehicle_info);

    HttpClient DistributeDate;
    if(DistributeDate.InitData(VHHICLE_ANALYSE_QUEST,preparexml->vehicle_url.c_str(),REQUEST_POST_FLAG,HTTP_CONTENT_TYPE_URL_ENCODED,preparexml_data.c_str()))
    {
       DistributeDate.startHttpClient();
    }

    if(DistributeDate.d_success_flag)
    {

        if (!DistributeDate.ResponseData.empty())
        {

            if (!analyseSlaveReply(DistributeDate.ResponseData))
            {
                delete preparexml;
                preparexml = nullptr;
                LOG_OUT(INFO, "Slave(%s) is too busy, check request is put in the toDistribute_queue again. \n\n", IP.c_str());
                return false;
            }
            else
            {
                recordSendTime(pVehicle_info);
            }

        }
        else
        {
            delete preparexml;
            preparexml = nullptr;

            LOG_OUT(ERROR, "Slave(%s) response is empty, check request is put in the toDistribute_queue again. \n\n", IP.c_str());

            return false;
        }
    }
    else
    {
        if (preparexml) {
            delete preparexml;
            preparexml = nullptr;

        }
        LOG_OUT(ERROR, "Slave(%s) no response, check request is put in the toDistribute_queue again. \n\n", IP.c_str());
        return false;
    }
    if(preparexml)
    {
        delete preparexml;
        preparexml = nullptr;
    }
    if(pVehicle_info)
    {
        delete pVehicle_info;
        pVehicle_info = nullptr;
    }

    return true;


}

//从机向主机发送处理结果
bool slaveSendResult(Vehicle_Info* pVehicle_info,std::string masterIP)
{
    std::string IP = masterIP;
    std::string Port = PORT;
    std::string RequestUri = "/CarCheck";
    if(pVehicle_info == nullptr)
    {
        return false;
    }
    /*Prepare xml data*/

    PrepareXML* preparexml = new SalveSendResult();
    std::string preparexml_data;
    preparexml->setIP(IP);
    preparexml->setPort(Port);
    preparexml->setRequestUri(RequestUri);

    preparexml_data = preparexml->PrepareXml(pVehicle_info);

    HttpClient DistributeDate;
    if(DistributeDate.InitData(PHOTO_PROCESS_RESULT,preparexml->vehicle_url.c_str(),REQUEST_POST_FLAG,HTTP_CONTENT_TYPE_URL_ENCODED,preparexml_data.c_str()))
    {
       DistributeDate.startHttpClient();
    }
    if(DistributeDate.d_success_flag)
    {
        if (!DistributeDate.ResponseData.empty())
        {
            if (analyseSlaveReply(DistributeDate.ResponseData))
            {
                delete preparexml;
                preparexml = nullptr;
                return true;
            }

        }

    }

    delete preparexml;
    preparexml = nullptr;
    LOG_OUT(ERROR,"Slave send result error....");
    return false;
}

void getCarInfo(std::string gongwei_id,std::string area_id, std::string &temp)
{
    LOG_OUT(INFO,"getCarInfo... \n");
    Vehicle_Info* pvehicle_info = nullptr;
    int selectCount = service_queue.wait_reply_soap_queue.Size();

    LOG_OUT(INFO,"1 getCarInfo... selectCount : %d \n",selectCount);

    while(service_queue.wait_reply_soap_queue.Size())
    {
        if(selectCount-- < 0)
        {
            LOG_OUT(INFO,"getCarInfo... selectCount-- < 0\n");
            break;
        }

        auto reply_buf = service_queue.wait_reply_soap_queue.Take();
        auto reply_buf_it = reply_buf.begin();

        pvehicle_info = reply_buf_it->second;

        if(pvehicle_info != nullptr)
        {
            if(pvehicle_info->isSendAndroid)
            {
                LOG_OUT(INFO,"isSendAndroid continue\n");
                std::map<long,Vehicle_Info*> wait_reply_buf;
                wait_reply_buf[reply_buf_it->first] = reply_buf_it->second;
                service_queue.wait_reply_soap_queue.Put(wait_reply_buf);
                continue;
            }


            LOG_OUT(INFO,"selectCount：%d android is processing...\n",selectCount);
            LOG_OUT(INFO,"gongweiIndex is [%s] [%s]\n",pvehicle_info->gongwei_code.c_str(),gongwei_id.c_str());
            LOG_OUT(INFO,"area_id is [%s] [%s]\n",pvehicle_info->cyqxh.c_str(),area_id.c_str());

            if((gongwei_id == pvehicle_info->gongwei_code || gongwei_id =="0")
                    &&(pvehicle_info->cyqxh == area_id || area_id == "0")
              )
            {
                PrepareXML *send_to_android = new SendResultToAndroid();

                LOG_OUT(INFO,"获取安卓设备IP成功...\n");
                temp = send_to_android->PrepareXml(pvehicle_info);

                delete send_to_android;
                send_to_android = nullptr;

                pvehicle_info->isSendAndroid = true;


                std::map<long,Vehicle_Info*> wait_reply_buf;
                wait_reply_buf[reply_buf_it->first] = reply_buf_it->second;
                 LOG_OUT(INFO,"Device:%s SendCarInfo:%s\n",pvehicle_info->device_ip.c_str(),temp.c_str());
                service_queue.wait_reply_soap_queue.Put(wait_reply_buf);

                break;
            }
        }

        std::map<long,Vehicle_Info*> wait_reply_buf;
        wait_reply_buf[reply_buf_it->first] = reply_buf_it->second;
        service_queue.wait_reply_soap_queue.Put(wait_reply_buf);
    }

//    if(service_queue.send_to_android.Size())
//    {
//        pvehicle_info = service_queue.send_to_android.Take();
//    }
//    else
//    {
//        return;
//    }

//    if(pvehicle_info != nullptr)
//    {
//        LOG_OUT(INFO,"android is processing...")
//        LOG_OUT(INFO,"gongweiIndex is [%s] [%s]\n",pvehicle_info->gongwei_code.c_str(),gongwei_id.c_str());
//        LOG_OUT(INFO,"area_id is [%s] [%s]\n",pvehicle_info->cyqxh.c_str(),area_id.c_str());

//        if((gongwei_id == pvehicle_info->gongwei_code || gongwei_id =="0")&&(pvehicle_info->cyqxh == area_id || area_id == "0"))
//        {
//            PrepareXML *send_to_android = new SendResultToAndroid();

//            LOG_OUT(INFO,"获取安卓设备IP成功...\n");
//            temp = send_to_android->PrepareXml(pvehicle_info);

//            delete send_to_android;
//            send_to_android = nullptr;
//        }else {
//            //service_queue.wait_free_queue.Put(pvehicle_info);
//            service_queue.send_to_android.RePut(pvehicle_info);
//            pvehicle_info = nullptr;
//        }


//    }
}

std::string getParam(std::string url,std::string paramName)
{
    std::string paramValue="";
    char value[256]={0};
    paramName+="=";
    if(url.find(paramName) != std::string::npos)
    {
        const char *pStart = url.c_str();
        const char *pName = paramName.c_str();
        const char *pEnd=NULL;;
        pStart = strstr(pStart,pName);
        if(pStart != NULL)
        {
            pEnd = strstr(pStart,"&");

            if(pEnd != NULL)
            {
                pStart +=(paramName.size());
                if(pEnd > pStart)
                {
                    memcpy(value,pStart,(pEnd-pStart));
                    value[pEnd-pStart]='\0';
                    paramValue = value;
                }
            }
            else
            {
                paramValue = pStart+paramName.size();
            }
        }
    }
    return paramValue;
}

std::string Encode(const unsigned char *Data, unsigned int DataByte)
{
    //编码表
    const char EncodeTable[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    //返回值
    string strEncode;
    unsigned char Tmp[4] = { 0 };
    for (int i = 0; i<(int)(DataByte / 3); i++) {
        Tmp[1] = *Data++;
        Tmp[2] = *Data++;
        Tmp[3] = *Data++;
        strEncode += EncodeTable[Tmp[1] >> 2];
        strEncode += EncodeTable[((Tmp[1] << 4) | (Tmp[2] >> 4)) & 0x3F];
        strEncode += EncodeTable[((Tmp[2] << 2) | (Tmp[3] >> 6)) & 0x3F];
        strEncode += EncodeTable[Tmp[3] & 0x3F];
    }
    //对剩余数据进行编码
    int Mod = DataByte % 3;
    if (Mod == 1) {
        Tmp[1] = *Data++;
        strEncode += EncodeTable[(Tmp[1] & 0xFC) >> 2];
        strEncode += EncodeTable[((Tmp[1] & 0x03) << 4)];
        strEncode += "==";
    } else if (Mod == 2) {
        Tmp[1] = *Data++;
        Tmp[2] = *Data++;
        strEncode += EncodeTable[(Tmp[1] & 0xFC) >> 2];
        strEncode += EncodeTable[((Tmp[1] & 0x03) << 4) | ((Tmp[2] & 0xF0) >> 4)];
        strEncode += EncodeTable[((Tmp[2] & 0x0F) << 2)];
        strEncode += "=";
    }

    return strEncode;
}

int readFileByFileName(const char *pFileName,char *pBuf,int maxBufLen)
{
    FILE *fp = std::fopen(pFileName, "rb");
    if (!fp) {
        printf("fopen failure! %s\n",pFileName);
        return -1;
    }

    std::fseek(fp, 0, SEEK_END);
    long length = std::ftell(fp);
    std::fseek(fp, 0, SEEK_SET);

    if(length > maxBufLen)
    {
        return -1;
    }

    long ret = std::fread(pBuf, 1, maxBufLen, fp);
    if (ret != length) {
        printf("fread() failed! \n");
        std::fclose(fp);
        return -1;
    }
    std::fclose(fp);
    return length;
}

#define MAX_PIC_LEN    1024*1024*2

std::string getBase64PicByFileName(const char *pFileName)
{

    std::string photoData;
    unsigned char *Data = (unsigned char *)malloc(MAX_PIC_LEN);

    int length = readFileByFileName(pFileName,(char *)Data,MAX_PIC_LEN);
    if(length >0)
    {
       photoData = Encode(Data, length);
       free(Data);
       return photoData;
    }

    free(Data);
    return "0";
}

std::string loadPhoto(std::string photo_localpath)
{
    if (photo_localpath.find("TBD") != std::string::npos) {
        return "";
    }
    //sleep(1);
    FILE *fd = fopen (photo_localpath.c_str(), "rb");
    if(fd ==nullptr)
    {
        return "";
    }
    fseek(fd,0,SEEK_END);
    unsigned int bufSize = static_cast<unsigned int>(ftell(fd));

    rewind(fd);//将文件指针初始化


    void *buff = calloc(1, bufSize);
    if(buff == nullptr)
    {
        LOG_OUT(ERROR,"malloc free!!!\n");
        return "" ;
    }

    fread(buff,1,bufSize,fd);
    std::string photo_result = ZBase64::Encode((const unsigned char *)buff,bufSize);

    if(buff!=nullptr)
    {
        free(buff);
        buff = nullptr;
    }

    fclose(fd);

    return photo_result;
}

std::string loadBase64Image(std::string path)
{
    //"data:image/jpeg;base64,"+
    std::string base64Image = loadPhoto(path.c_str());

    return base64Image;
}



//事件处理方法
void request_handle(evhttp_request *req, void *arg)
{
    LOG_OUT(INFO,"called func request_handle!\n")
    HTTP_Server *server = static_cast<HTTP_Server*>(arg);
    std::string remoteHost = server->getRemoteHost(req);
    std::string uri = server->getURI(req);
    std::string method = server->getMethod(req);

    LOG_OUT(INFO, "<------------------Received a HTTP request(Host:%s, Method:%s, URI:%s)------------------> \n",
            remoteHost.c_str(), method.c_str(), uri.c_str());

    /* 验证URI */
    if (uri == "/CarCheck")
    {
        if(method == "POST")
        {
            analyseData(req, server);
        }
        else
        {
            LOG_OUT(ERROR, "The Method(%s) is not allowed! \n", method.c_str());
            server->sendReply(req, HTTP_Server::BADMETHOD, std::vector<HTTP_Header>(), std::string());
            LOG_OUT(INFO, "<---------------------------The HTTP response has been sent.---------------------------> \n\n");
        }
    }
    else if(uri == "/SendCarinfo")
    {

        if(method == "POST")
        {
            std::vector<HTTP_Header> http_temp;
            std::string IP = remoteHost;
            std::string temp = "";
            std::string recv_data = server->getBody(req);
            std::string gongwei_id;
            std::string area_id;

            LOG_OUT(INFO,"Send android recv_data:%s\n",recv_data.c_str());

            gongwei_id = getParam(recv_data,"gongwei_id");
            area_id = getParam(recv_data,"area_id");

            std::thread getCarinfothread(getCarInfo,gongwei_id,area_id,std::ref(temp));
            getCarinfothread.join();
            if(temp != "")
            {
                std::vector<HTTP_Header> http_header;
                HTTP_Header type("Content-Type","text/html; charset=UTF-8");
                http_header.push_back(type);
                server->sendReply(req, HTTP_Server::OK,http_header,temp);
                LOG_OUT(INFO,"Send temp android info sucess\n");
            }
            else if(service_queue.save_slave_android_info.Size())//接收到从机的车辆信息
            {
                auto andorid_buf = service_queue.save_slave_android_info.Take();
                auto andorid_it = andorid_buf.begin();
                std::string gongwei = andorid_it->first;
                std::string temp = andorid_it->second;

                LOG_OUT(INFO,"Send slave android info,data is %s\n",temp.c_str());

                std::string cyqxhStr = "<cyqxh>"+area_id+"</cyqxh>";
                bool cyqxhBool = false;

                //if(temp.length() > 3072)
                {
                    cyqxhBool = (temp.find(cyqxhStr.c_str())!=std::string::npos);
                }

                LOG_OUT(INFO,"cyqxhStr:%s  cyqxhBool %d\n",cyqxhStr.c_str(),cyqxhBool);

                if((gongwei == gongwei_id || gongwei_id == "0")&&(cyqxhBool|| area_id == "0"))
                {
                    std::vector<HTTP_Header> http_header;
                    HTTP_Header type("Content-Type","text/html; charset=UTF-8");
                    http_header.push_back(type);
                    server->sendReply(req, HTTP_Server::OK,http_header,temp);

                    LOG_OUT(INFO,"Send slave android info sucess\n");
                }
                else
                {
                    server->sendReply(req, HTTP_Server::NOTFOUND, http_temp, std::string());
                    LOG_OUT(INFO,"Send slave android info NOTFOUND\n");
                }
            }
            else
            {
                server->sendReply(req, HTTP_Server::NOTFOUND, http_temp, std::string());
            }
        }
        else
        {
            LOG_OUT(ERROR, "The Method(%s) is not allowed! \n", method.c_str());
            server->sendReply(req, HTTP_Server::BADMETHOD, std::vector<HTTP_Header>(), std::string());
            LOG_OUT(INFO, "<---------------------------The HTTP response has been sent.---------------------------> \n\n");
        }
    }
    else if(uri.find("/loadPic?") != std::string::npos){
        std::string base64Pic = "";
        std::string path = getParam(uri,"path");
        LOG_OUT(INFO,"loadPic path:%s\n",path.c_str());
        std::vector<HTTP_Header> http_header;
        HTTP_Header type("Content-Type","image/jpeg");
        http_header.push_back(type);
        base64Pic = loadPhoto(path);
        server->sendReply(req, HTTP_Server::OK,http_header,base64Pic);
    }
    else
    {
        LOG_OUT(ERROR, "The URI(%s) is undefined! \n", uri.c_str());
        server->sendReply(req, HTTP_Server::NOTFOUND, std::vector<HTTP_Header>(), std::string());
        LOG_OUT(INFO, "<---------------------------The HTTP response has been sent.---------------------------> \n\n");
        return;
    }



}

/*server处理client上传的数据*/
void analyseData(evhttp_request *req, HTTP_Server *server)
{
    LOG_OUT(INFO, "Header: \n");
    std::vector<HTTP_Header> HeaderList = server->getHeaderList(req);
    for (unsigned int i = 0; i < HeaderList.size(); i++) {
        LOG_OUT(INFO, "    %s: %s\n", HeaderList[i].key.c_str(), HeaderList[i].value.c_str());
    }

    std::string tmp = server->getBody(req);
    std::string body = URLDecode(tmp);

    LOG_OUT(INFO, " body: %s\n", body.c_str());


    if (!checkXMLStructure(body)) {
        LOG_OUT(ERROR, "There is no legal XML structure, data: %s \n", body.c_str());
        sendResponse(req, server, 3, std::string());
        return;
    }

    CMarkup xml;
    xml.SetDoc(body);
    xml.ResetMainPos();

    xml.FindElem("root");
    xml.IntoElem();

    int type;
    xml.FindElem("code");
    type = atoi(xml.GetData().c_str());

    xml.FindElem("vehicle");
    xml.IntoElem();

    if (type == VHHICLE_ANALYSE_QUEST) //接收车辆信息
    {
        Vehicle_Info* vehicle = new Vehicle_Info;
        LOG_OUT(INFO, "Received vehicle information, analyse data: \n");
        for (unsigned int i = 0; i < vehicle->item_description.size(); i++)
        {
            if (xml.FindElem(vehicle->item_description[i].name_tag))
            {
                *(static_cast<std::string*>(vehicle->item_description[i].value)) = xml.GetData();
                LOG_OUT(INFO, "%s: %s\n", vehicle->item_description[i].name_tag.c_str(), (xml.GetData()).c_str());
#ifdef TESTANDROID
                /* 由于测试软件读取的车检数据库里面可能出现“无数据”，导致无法写入数据库 */
                if (*(static_cast<std::string*>(vehicle->item_description[i].value))=="无数据")
                {
                    *(static_cast<std::string*>(vehicle->item_description[i].value)) = "";
                }
#endif
            }
            else
            {
                LOG_OUT(WARNING, "Missing XML element \"%s\"! \n", vehicle->item_description[i].name_tag.c_str());
            }
            xml.ResetMainPos();
            xml.ResetChildPos();
        }

        unsigned int j = 0;
        while(xml.FindElem("photodes"))
        {
            Photo photo_buf;
            xml.IntoElem();

            if(xml.FindElem("zpzl"))
            {
                photo_buf.type = xml.GetData();
                LOG_OUT(INFO,"%s:",photo_buf.type.c_str())
            }
            if(xml.FindElem("zpurl"))
            {

                photo_buf.url = xml.GetData();

                LOG_OUT(INFO,"-------%s--------:",photo_buf.url.c_str());
            }
            vehicle->photo_list.push_back(photo_buf);
            j++;

            xml.OutOfElem();

        }
        while (xml.FindElem("refphotodes"))
        {
            Photo photo_buf;
            xml.IntoElem();

            if(xml.FindElem("lb"))
            {
                photo_buf.type = xml.GetData();
                LOG_OUT(INFO,"%s:",photo_buf.type.c_str())
            }
            if(xml.FindElem("zpurl"))
            {
                photo_buf.url = xml.GetData();
                LOG_OUT(INFO,"------------%s----------------:",photo_buf.url.c_str())
            }
            vehicle->photo_list.push_back(photo_buf);
            j++;
            xml.OutOfElem();
        }

        /*判断车辆识别代号是否为空*/
        if (vehicle->clsbdh.empty()) {
            LOG_OUT(ERROR, "There is no \"clsbdh\" data. \n");
            sendResponse(req, server, 3, std::string());
            return;
        }

        LOG_OUT(INFO, "Vehicle(lsh:%s) information has been recvied. \n", vehicle->lsh.c_str());
        sendResponse(req, server, 0, std::string());
        service_queue.download_queue.Put(vehicle);
        LOG_OUT(INFO,"Vehcile_info has been put download queue\n");

    }
    else if(type == PHOTO_PROCESS_RESULT)//照片处理结果
    {
        LOG_OUT(INFO, "Received slave result information, analyse data: \n");
        Vehicle_Info* vehicle = new Vehicle_Info;
        LOG_OUT(INFO, "Received vehicle information, analyse data: \n");
        for (unsigned int i = 0; i < vehicle->item_description.size(); i++)
        {
            if (xml.FindElem(vehicle->item_description[i].name_tag))
            {
                *(static_cast<std::string*>(vehicle->item_description[i].value)) = xml.GetData();
                LOG_OUT(INFO, "%s: %s\n", vehicle->item_description[i].name_tag.c_str(), (*(static_cast<std::string*>(vehicle->item_description[i].value))).c_str());
            }
            else
            {
                LOG_OUT(WARNING, "    Missing XML element \"%s\"! \n", vehicle->item_description[i].name_tag.c_str());
            }
            xml.ResetMainPos();
            xml.ResetChildPos();
        }
        xml.OutOfElem();

        /*从已发出队列中找接收到的流水号，确认收到信息后将信息删除*/
        if(xml.FindElem("result"))
        {
            xml.IntoElem();
            /*从队列中找到此流水号对应的车辆信息   待开发*/
            while(xml.FindElem("item"))
            {
                Photo photo_buf;
                xml.IntoElem();
                if(xml.FindElem("zpzl"))
                {
                    photo_buf.type = xml.GetData();
                }
                if(xml.FindElem("jg"))
                {
                    photo_buf.result = xml.GetData();
                    //vehicle->photo_list[index].result = atoi(xml.GetData().c_str());
                }
                if(xml.FindElem("sm"))
                {
                    photo_buf.detail.push_back(xml.GetData());
                    //vehicle->photo_list[index].detail.push_back(xml.GetData());
                }
                if(xml.FindElem("url"))
                {
                    photo_buf.path = xml.GetData();
                }
                if(xml.FindElem("time"))
                {
                    photo_buf.algorithm_process_time = xml.GetData();
                }
                LOG_OUT(INFO,"zpzl:%s  result:%s\n",photo_buf.type.c_str(),photo_buf.result.c_str());
                vehicle->photo_list.push_back(photo_buf);
                xml.OutOfElem();
            }
       }
        /*从发送队列中删除*/
        for(auto send_info_it = send_vehicle_info.begin(); send_info_it != send_vehicle_info.end();send_info_it++ )
        {
            if(send_info_it->first == vehicle->lsh)
            {
                send_vehicle_info.erase(send_info_it);
            }
        }
        /*将处理完的信息放入下一队列*/
        sendResponse(req, server, 0, std::string());
        vehicle->hbdbqk += "R_"+ getNowTime();
        if(androidIP[0]["0"] == "1")
        {

            putIntoWaitReplySoapQueue(vehicle);
            //service_queue.reply_soap_queue.Put(vehicle);
        }
        else
        {
            service_queue.reply_soap_queue.Put(vehicle);
        }

       /* if(androidIP[0]["0"] == "1")
        {
            service_queue.wait_free_queue.Put(vehicle);
        }*/


        vehicle = nullptr;
    }
    else if(type == REPLY_ANDROID)
    {
        if(xml.FindElem("gongwei_code"))
        {
            std::map<std::string,std::string> android_buf;
            android_buf[xml.GetData()] = tmp;
            service_queue.save_slave_android_info.Put(android_buf);
        }
        if(xml.FindElem("lsh"))
        {
            LOG_OUT(INFO,"recv slave lsh is %s\n",xml.GetData().c_str());
        }
        sendResponse(req, server, 0, std::string());

        while(service_queue.save_slave_android_info.Size() > 1)
        {
           service_queue.save_slave_android_info.Take();
        }
    }
    else if(type == WAIT_ANDROID_RESPONSE)
    {
        RecvRenGongData recv_buf;

        if(xml.FindElem("lsh"))
        {
            recv_buf.lsh = xml.GetData();
            xml.OutOfElem();
        }
        if(xml.FindElem("result"))
        {
            xml.IntoElem();
            if(xml.FindElem("item"))
            {
                xml.IntoElem();
                if(xml.FindElem("zpzl"))
                {
                    recv_buf.zpzl = xml.GetData();
                }
                if(xml.FindElem("jg"))
                {
                   recv_buf.jg = xml.GetData();
                }
                if(xml.FindElem("sm"))
                {
                    recv_buf.sm = xml.GetData();
                }
                xml.OutOfElem();
            }
            xml.OutOfElem();
        }
        rengong_result.push_back(recv_buf);
        while(rengong_result.size() > MAX_LIMIT)
        {
            rengong_result.erase(rengong_result.begin());
        }
        sendResponse(req, server, 0, std::string());
    }
    else
    {
        sendResponse(req, server, 3, std::string());
    }
}

/**
 * @brief 发出协议中规定的响应数据。
 * @param[in] req 当前等待响应的request
 * @param[in] server 关联的server对象指针
 * @param[in] ResponseCode 协议中规定的响应code
 * @param[in] ResultElement 协议中定义的result节点格式的字符串，如果没有就传空字符串
 */
void sendResponse(evhttp_request *req, HTTP_Server *server, unsigned int ResponseCode, std::string ResultElement)
{
    const char *StatusMessage[] = {
        "数据上传成功",
        "数据来源于未知IP，无法进行处理",
        "尚未收到车辆基本信息，无法对照片进行比对",
        "没有合法的XML结构"
    };

    CMarkup xml;

    xml.SetDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>\r\n");
    xml.AddElem("root");
    xml.IntoElem();

    xml.AddElem("head");
    xml.IntoElem();


    xml.AddChildElem("code");
    xml.SetChildData(static_cast <int> (ResponseCode));
    xml.AddChildElem("message");
    xml.SetChildData(std::string(StatusMessage[ResponseCode]));

    if (!ResultElement.empty()) {
        xml.AddSubDoc(ResultElement);
    }

    xml.OutOfElem();
    std::string xmlString = xml.GetDoc();
    std::string encodeData = URLEncode(xmlString);

    /* 需要加入一个头部，否则libevent默认“Content-Type： text/html; charset=ISO-8859-1” */
    std::vector<HTTP_Header> HeaderList;
    HeaderList.push_back(HTTP_Header("Content-Type", "text/xml"));

    server->sendReply(req, HTTP_Server::OK, HeaderList, encodeData);
    LOG_OUT(INFO, "<---------------------------The HTTP response has been sent.---------------------------> \n\n");

}
/*
bool checkRemoteHost(std::string IP)
{
    for (unsigned int i = 0; i < GlobalConfig.HostList.size(); i++) {
        if (IP == GlobalConfig.HostList[i]) {
            return true;
        }
    }

    return false;
}
*/
/**
 * @brief 检查协议中规定的XML结构的几个关键节点是否都存在。
 * @param[in] data 被检查的数据
 * @return true--通过
 *         false--不通过
 */
bool checkXMLStructure(std::string data)
{
    CMarkup xml;

    xml.SetDoc(data);
    xml.ResetMainPos();

    if (!xml.FindElem("root")) {
        return false;
    }

    xml.IntoElem();

    if (!xml.FindElem("code")) {
        return false;
    }

    if (!xml.FindElem("vehicle")) {
        return false;
    }

    return true;
}



