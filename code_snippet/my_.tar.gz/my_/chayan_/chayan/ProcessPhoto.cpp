#include "ProcessPhoto.h"
#include "chayan_main.h"
#include "configfile.h"
#include "DownloadPic.h"
#include "jsonMaker.h"
#include "Utility.h"

extern std::mutex openfile;
extern Queue service_queue;
extern configuration serviceConfigure;
extern std::vector<std::map<std::string,std::string>> androidIP;
extern void putIntoWaitReplySoapQueue(Vehicle_Info*);
extern void putIntoReplySoapQueue();
processPhoto::processPhoto(picture_code pic_code, int GPUid,LargeVehicleApi* alg_api,zplx is_zplx_check)
{
    GPU_ID = GPUid;
    alg = alg_api;
    pictureCode = pic_code;
    check_zplx = is_zplx_check;

}

processPhoto:: ~ processPhoto()
{
    if(alg)
    {
        alg = nullptr;
    }
    if(pvehicle_info)
    {
        pvehicle_info = nullptr;
    }
}

unsigned int processPhoto::startProcessPhoto()
{
    while (true)
    {
        pvehicle_info = service_queue.process_queue.Take();
        pvehicle_info->hbdbqk += "p1_"+getNowTime();
        LOG_OUT(INFO,"startProcessPhoto 111 lsh:%s %d\n",pvehicle_info->lsh.c_str(),service_queue.process_queue.Size());
        printf("startProcessPhoto 111 lsh:%s %d\n",pvehicle_info->lsh.c_str(),service_queue.process_queue.Size());
        LOG_OUT(INFO,"Take vehicle_info from queue, lsh is %s\n",pvehicle_info->lsh.c_str());

        if((pvehicle_info->cllx.substr(0,1)=="K")||(pvehicle_info->cllx.substr(0,1)=="H"))
        {
            LOG_OUT(INFO,"startProcessPhoto 222 lsh:%s\n",pvehicle_info->lsh.c_str());
            printf("startProcessPhoto 222 lsh:%s\n",pvehicle_info->lsh.c_str());
            vehicle_check();/*调用处理照片方法*/
            LOG_OUT(INFO,"startProcessPhoto 333 lsh:%s\n",pvehicle_info->lsh.c_str());
            printf("startProcessPhoto 333 lsh:%s\n",pvehicle_info->lsh.c_str());
        }
        else
        {
            for(unsigned int count = 0;count <pvehicle_info->photo_list.size();count++)
            {
                pvehicle_info->photo_list[count].result = UNKOWN;
                pvehicle_info->photo_list[count].detail.push_back("照片不在处理范围内");
            }
            pvehicle_info->is_pass = UNKOWN;
        }
        LOG_OUT(INFO,"startProcessPhoto 444 lsh:%s\n",pvehicle_info->lsh.c_str());
        printf("startProcessPhoto 444 lsh:%s\n",pvehicle_info->lsh.c_str());
        pvehicle_info->hbdbqk += "p2_"+getNowTime();
        if(serviceConfigure.is_master)
        {
            if(androidIP[0]["0"] == "1")// && pvehicle_info->model == "1")
            {
                putIntoWaitReplySoapQueue(pvehicle_info);
                //service_queue.reply_soap_queue.Put(pvehicle_info);
            }
            else
            {
                service_queue.reply_soap_queue.Put(pvehicle_info);
            }
        }
        else
        {
//            if(androidIP[0]["0"] == "1" && pvehicle_info->model == "1")
//            {
//                service_queue.send_to_android.Put(pvehicle_info);
//            }
            service_queue.slave_reply_queue.Put(pvehicle_info);
        }
    }
    return RESULT_OK;
}

unsigned int processPhoto::vehicle_check()
{
    LOG_OUT(INFO,"Vehicle_check is processing photo!\n");
    std::lock_guard<std::mutex> lock(openfile);

    for(unsigned int i = 0;i < pvehicle_info->photo_list.size();i++)
    {
        LOG_OUT(INFO,"photo_list_path:%s\n",pvehicle_info->photo_list[i].path.c_str());
        if(pvehicle_info->photo_list[i].type == pictureCode.zqf)//左前方
        {
            std::string ywlx = pvehicle_info->ywlx;
            cv::Mat zqf_compare_img;
            bool is_exist = false;

            if(pvehicle_info->photo_list[i].path == "TBD")
            {
                pvehicle_info->photo_list[i].result = UNDOWNLOAD;
                pvehicle_info->photo_list[i].detail.push_back("左前方-[未能下载到照片资源]");
                continue;
            }

            input_img = cv::imread(pvehicle_info->photo_list[i].path);
            std::vector<cv::Mat> compare_img;

            /*判断是否存在A、G照片*/
            for(unsigned int j = 0;j < pvehicle_info->photo_list.size();j++)
            {
                if(pvehicle_info->photo_list[j].type[0] == 'G' && pvehicle_info->photo_list[j].path != "TBD")
                {
                    zqf_compare_img = cv::imread(pvehicle_info->photo_list[j].path);
                    compare_img.push_back(zqf_compare_img);
                    ywlx = "A";
                }
                else if(pvehicle_info->photo_list[j].type[0] == 'A' && pvehicle_info->photo_list[j].path != "TBD")
                {
                    compare_img.clear();
                    zqf_compare_img = cv::imread(pvehicle_info->photo_list[j].path);
                    compare_img.push_back(zqf_compare_img);
                    ywlx = pvehicle_info->ywlx;
                    is_exist = true;
                    break;
                }
            }
            if(serviceConfigure.city == JINAN && !is_exist)
            {
                for(unsigned int j = 0;j < pvehicle_info->photo_list.size();j++)
                {
                    if(pvehicle_info->photo_list[j].type == "H1" && pvehicle_info->photo_list[j].path != "TBD")
                    {
                        compare_img.clear();
                        zqf_compare_img = cv::imread(pvehicle_info->photo_list[j].path);
                        compare_img.push_back(zqf_compare_img);
                        ywlx = pvehicle_info->ywlx;
                        break;
                    }
                }
            }
            Cheliang_ImgOutMsg zqf_process_out;
            std::string chePai = pvehicle_info->hphm;
            std::string cheliang_type = pvehicle_info->clpp1;
            std::string color = pvehicle_info->csys;
            pvehicle_info->photo_list[i].timeRecord.startTime();

            LOG_OUT(INFO,"Processing zplx:%s,hphm:%s,clsbdh:%s cheliang_type:%s color:%s ywlx:%s compare_img.size:%d\n"
                    ,pictureCode.zqf.c_str(),pvehicle_info->hphm.c_str(),pvehicle_info->clsbdh.c_str()
                    ,cheliang_type.c_str(),color.c_str(),ywlx.c_str()
                    ,compare_img.size());

            alg->cheliang_api_process(input_img,input_img,compare_img,chePai,cheliang_type,color,eFRONTLEFT,zqf_process_out);
            LOG_OUT(INFO,"Alg has process finished,clsbdh is %s\n",pvehicle_info->clsbdh.c_str());
            pvehicle_info->photo_list[i].timeRecord.endTime();
            pvehicle_info->photo_list[i].algorithm_process_time = pvehicle_info->photo_list[i].timeRecord.getTime();

            vehicle_check_zqf(i,zqf_process_out);
        }
        else if(pvehicle_info->photo_list[i].type == pictureCode.yhf)//右后方
        {
            cv::Mat zqf_compare_img;
            std::vector<cv::Mat> compare_img;
            std::string ywlx = pvehicle_info->ywlx;
            input_img = cv::imread(pvehicle_info->photo_list[i].path);

            if(pvehicle_info->photo_list[i].path == "TBD")
            {
                pvehicle_info->photo_list[i].result = UNDOWNLOAD;
                pvehicle_info->photo_list[i].detail.push_back("[右后方]-未能下载到照片资源");
                continue;
            }

            /*判断是否存在G照片*/
            for(unsigned int j = 0;j < pvehicle_info->photo_list.size();j++)
            {
                if(pvehicle_info->photo_list[j].type[0] == 'G' && pvehicle_info->photo_list[j].path != "TBD")
                {
                    zqf_compare_img = cv::imread(pvehicle_info->photo_list[j].path);
                    compare_img.push_back(zqf_compare_img);
                    ywlx = "A";
                }
            }
            if(serviceConfigure.city == JINAN)
            {
                for(unsigned int j = 0;j < pvehicle_info->photo_list.size();j++)
                {
                    if(pvehicle_info->photo_list[j].type == "H2" && pvehicle_info->photo_list[j].path != "TBD")
                    {
                        compare_img.clear();
                        zqf_compare_img = cv::imread(pvehicle_info->photo_list[j].path);
                        compare_img.push_back(zqf_compare_img);
                        ywlx = pvehicle_info->ywlx;
                        break;
                    }
                }
            }
            Cheliang_ImgOutMsg yhf_process_out;
            std::string chePai = pvehicle_info->hphm;
            std::string cheliang_type = pvehicle_info->clpp1;
            std::string color = pvehicle_info->csys;
            pvehicle_info->photo_list[i].timeRecord.startTime();
            LOG_OUT(INFO,"~~~~Processing zplx:%s,hphm:%s,clsbdh:%s\n",pictureCode.yhf.c_str(),pvehicle_info->hphm.c_str(),pvehicle_info->clsbdh.c_str());
            alg->cheliang_api_process(input_img,input_img,compare_img,chePai,cheliang_type,color,eBACKRIGHT,yhf_process_out);
            LOG_OUT(INFO,"~~~~Alg has process finished,clsbdh is %s\n",pvehicle_info->clsbdh.c_str());
            pvehicle_info->photo_list[i].timeRecord.endTime();
            pvehicle_info->photo_list[i].algorithm_process_time = pvehicle_info->photo_list[i].timeRecord.getTime();

            vehicle_check_yhf(i,yhf_process_out);
        }
        else if(pvehicle_info->photo_list[i].type == pictureCode.cjh)//车架号
        {
            input_img = cv::imread(pvehicle_info->photo_list[i].path);
            cv::Mat compare_img;
            if(pvehicle_info->photo_list[i].path == "TBD")
            {
                pvehicle_info->photo_list[i].result = UNDOWNLOAD;
                pvehicle_info->photo_list[i].detail.push_back("[车架号]-未能下载到照片资源");
                continue;
            }
            /*济南判断是否有历史照片*/
            if(serviceConfigure.city == JINAN)
            {
                for(unsigned int j = 0;j < pvehicle_info->photo_list.size();j++)
                {
                    if(pvehicle_info->photo_list[j].type == "H3" && pvehicle_info->photo_list[j].path != "TBD")
                    {
                        compare_img = cv::imread(pvehicle_info->photo_list[j].path);
                        break;
                    }
                }
            }
            /*判断是否存在J照片*/
            for(unsigned int j = 0;j < pvehicle_info->photo_list.size();j++)
            {
                if(serviceConfigure.city != SUZHOU)
                {
                    if(pvehicle_info->photo_list[j].type[0] == 'J' && pvehicle_info->photo_list[j].path != "TBD")
                    {
                        compare_img = cv::imread(pvehicle_info->photo_list[j].path);
                    }
                }
                else
                {
                    if(pvehicle_info->photo_list[j].type == "0199")
                    {
                        compare_img = cv::imread(pvehicle_info->photo_list[j].path);
                    }
                }

            }
            std::string shuiyinriqi = "";
            Chejiahao_ImgOutMsg chejiahao_process_out;
            std::string chejiahao = pvehicle_info->clsbdh;
            pvehicle_info->photo_list[i].timeRecord.startTime();
            LOG_OUT(INFO,"Processing zplx:%s,hphm:%s,clsbdh:%s\n",pictureCode.cjh.c_str(),pvehicle_info->hphm.c_str(),pvehicle_info->clsbdh.c_str());
            alg->chejiaohao_api_process(input_img,compare_img,chejiahao,"",chejiahao_process_out,0);
            LOG_OUT(INFO,"Alg has process finished,clsbdh is %s\n",pvehicle_info->clsbdh.c_str());
            pvehicle_info->photo_list[i].timeRecord.endTime();

            pvehicle_info->photo_list[i].algorithm_process_time = pvehicle_info->photo_list[i].timeRecord.getTime();

            vehicle_check_cjh(i,chejiahao_process_out);
        }
        else if(pvehicle_info->photo_list[i].type == pictureCode.clmp)//车辆铭牌
        {

            input_img = cv::imread(pvehicle_info->photo_list[i].path);
            cv::Mat compare_img;
            if(pvehicle_info->photo_list[i].path == "TBD")
            {
                pvehicle_info->photo_list[i].result = UNDOWNLOAD;
                pvehicle_info->photo_list[i].detail.push_back("[车辆铭牌]-未能下载到照片资源");
                continue;
            }
            if(serviceConfigure.city == JINAN)
            {
                for(unsigned int j = 0;j<pvehicle_info->photo_list.size();j++)
                {
                    if(pvehicle_info->photo_list[j].type == "H4" && pvehicle_info->photo_list[j].path != "TBD")
                    {
                        compare_img = cv::imread(pvehicle_info->photo_list[j].path);
                        break;
                    }
                }
            }
            Mingpai_Input mingpai_input;
            mingpai_input.img_src = input_img;
            mingpai_input.img_his = compare_img;
            mingpai_input.ans_pailiang = pvehicle_info->pl;
            mingpai_input.ans_chejiahao = pvehicle_info->clsbdh;
            mingpai_input.ans_zhizaoguo = pvehicle_info->zzg;
            mingpai_input.ans_zhizaoriqi = pvehicle_info->zzrq;
            mingpai_input.ans_hedingzaike = pvehicle_info->hdzk;
            mingpai_input.ans_zongzhiliang = pvehicle_info->zzl;
            mingpai_input.ans_cheliangpinpai = pvehicle_info->clpp1;
            mingpai_input.ans_cheliangxinghao = pvehicle_info->xh;
            mingpai_input.ans_zhizaochangmingcheng = pvehicle_info->zzcmc;

            Mingpai_OutMsg mingpai_process_out;
            pvehicle_info->photo_list[i].timeRecord.startTime();
            LOG_OUT(INFO,"Processing zplx:%s,hphm:%s,clshdh:%s\n",pictureCode.clmp.c_str(),pvehicle_info->hphm.c_str(),pvehicle_info->clsbdh.c_str());
            alg->mingpai_api_process(mingpai_input,mingpai_process_out);
            LOG_OUT(INFO,"Alg has process finished,clsbdh is %s\n",pvehicle_info->clsbdh.c_str());
            pvehicle_info->photo_list[i].timeRecord.endTime();
            pvehicle_info->photo_list[i].algorithm_process_time = pvehicle_info->photo_list[i].timeRecord.getTime();

            vehicle_check_clmp(i,mingpai_process_out);
        }
        else if(pvehicle_info->photo_list[i].type == pictureCode.ltgg)//轮胎规格
        {
            input_img = cv::imread(pvehicle_info->photo_list[i].path);
            if(pvehicle_info->photo_list[i].path == "TBD")
            {
                pvehicle_info->photo_list[i].result = UNDOWNLOAD;
                pvehicle_info->photo_list[i].detail.push_back("[轮胎规格]-未能下载到照片资源");
                continue;
            }

            Luntaiguige_ImgOutMsg luntaiguige_process_out;
            std::string luntaixinghao = pvehicle_info->ltgg;
            pvehicle_info->photo_list[i].timeRecord.startTime();
            LOG_OUT(INFO,"Processing zplx:%s,hphm:%s,clsbdh:%s\n",pictureCode.ltgg.c_str(),pvehicle_info->hphm.c_str(),pvehicle_info->clsbdh.c_str());
            alg->luntaiguige_api_process(input_img,luntaixinghao,luntaiguige_process_out);
            LOG_OUT(INFO,"Alg has process finished,clsbdh is %s\n",pvehicle_info->clsbdh.c_str());
            pvehicle_info->photo_list[i].timeRecord.endTime();

            pvehicle_info->photo_list[i].algorithm_process_time = pvehicle_info->photo_list[i].timeRecord.getTime();

            vehicle_check_ltgg(i,luntaiguige_process_out);
        }
        else if(pvehicle_info->photo_list[i].type == pictureCode.fdjh)//发动机号
        {
            input_img = cv::imread(pvehicle_info->photo_list[i].path);

            if(pvehicle_info->photo_list[i].path == "TBD")
            {
                pvehicle_info->photo_list[i].result = UNDOWNLOAD;
                pvehicle_info->photo_list[i].detail.push_back("[发动机号]-未能下载到照片资源");
                continue;
            }

            Fadongjihao_OutMsg fdjh_process_out;
            std::string fadongjihao = pvehicle_info->fdjh;
            pvehicle_info->photo_list[i].timeRecord.startTime();
            LOG_OUT(INFO,"Processing zplx:%s,hphm:%s,clsbdh:%s\n",pictureCode.fdjh.c_str(),pvehicle_info->hphm.c_str(),pvehicle_info->clsbdh.c_str());
            alg->fadongjihao_api_process(input_img,fadongjihao,fdjh_process_out);
            LOG_OUT(INFO,"Alg has process finished,clsbdh is %s\n",pvehicle_info->clsbdh.c_str());
            pvehicle_info->photo_list[i].timeRecord.endTime();
            pvehicle_info->photo_list[i].algorithm_process_time = pvehicle_info->photo_list[i].timeRecord.getTime();
            vehicle_check_fdjh(i,fdjh_process_out);

        }
        else if(pvehicle_info->photo_list[i].type == pictureCode.ddccz)//电动车插座
        {
            input_img = cv::imread(pvehicle_info->photo_list[i].path);

            if(pvehicle_info->photo_list[i].path == "TBD")
            {
                pvehicle_info->photo_list[i].result = UNDOWNLOAD;
                pvehicle_info->photo_list[i].detail.push_back("[电动车插座]-未能下载到照片资源");
                continue;
            }

            Socket_ImgOutMsg ddccz_process_out;
            pvehicle_info->photo_list[i].timeRecord.startTime();
            LOG_OUT(INFO,"Processing zplx:%s,hphm:%s,clsbdh:%s\n",pictureCode.ddccz.c_str(),pvehicle_info->hphm.c_str(),pvehicle_info->clsbdh.c_str());
            alg->socket_api_process(input_img,ddccz_process_out);
            LOG_OUT(INFO,"Alg has process finished,clsbdh is %s\n",pvehicle_info->clsbdh.c_str());
            pvehicle_info->photo_list[i].timeRecord.endTime();

            vehicle_check_ddccz(i,ddccz_process_out);
        }
        else if(pvehicle_info->photo_list[i].type == pictureCode.cyyzp)//查验员照片
        {
//            input_img = cv::imread(pvehicle_info->photo_list[i].path);
//            if(pvehicle_info->photo_list[i].path == "TBD")
//            {
//                pvehicle_info->photo_list[i].result = UNDOWNLOAD;
//                pvehicle_info->photo_list[i].detail.push_back("[查验员照片]-未能下载到照片资源");
//                continue;
//            }
//            char str_buf[256];
//            if(HANGZHOU==serviceConfigure.city)
//            {
//                //opt/vehicle/vehicle_photo/szchayan/查验员身份证号码
//                std::string picid_name=cyyxx[pvehicle_info->cyry];
//                size_t  pos=picid_name.find(",");
//                if(std::string::npos == pos)
//                {
//                    pvehicle_info->photo_list[i].result = UNKOWN;
//                    pvehicle_info->photo_list[i].detail.push_back("[查验员信息]-error");
//                    continue;
//                }
//                std::string picid=picid_name.substr(0,pos);
//                if(""==picid)
//                {
//                    pvehicle_info->photo_list[i].result = UNKOWN;
//                    pvehicle_info->photo_list[i].detail.push_back("[查验员信息]-未录入");
//                    continue;
//                }
//                sprintf(str_buf,"%s/szchayan/%s.jpeg",serviceConfigure.photoFile.c_str(),picid.c_str());
//            }
//            else
//                sprintf(str_buf,"%s/szchayan/%s",serviceConfigure.photoFile.c_str(),pvehicle_info->cyry.c_str());

//            Chayanyuan_ImgOutMsg cyy_process_out;
//            cv::Mat source_zp = cv::imread(str_buf);
//            pvehicle_info->photo_list[i].timeRecord.startTime();
//            LOG_OUT(INFO,"Processing zplx:%s,hphm:%s,clsbdh:%s\n",pictureCode.cyyzp.c_str(),pvehicle_info->hphm.c_str(),pvehicle_info->clsbdh.c_str());
//            alg->chayanyuan_api_process(input_img,source_zp,cyy_process_out);
//            pvehicle_info->photo_list[i].timeRecord.endTime();
//            LOG_OUT(INFO,"Alg has process finished,clsbdh is %s\n",pvehicle_info->clsbdh.c_str());

//            vehicle_check_cyyzp(i,cyy_process_out);
            pvehicle_info->photo_list[i].result = PASS;
            if(pvehicle_info->photo_list[i].result == PASS)
            {
                pvehicle_info->photo_list[i].detail.clear();
                pvehicle_info->photo_list[i].detail.push_back("通过");
            }
        }
        else if(pvehicle_info->photo_list[i].type == pictureCode.aqd)//安全带
        {
            input_img = cv::imread(pvehicle_info->photo_list[i].path);
            if(pvehicle_info->photo_list[i].path == "TBD")
            {
                pvehicle_info->photo_list[i].result = UNDOWNLOAD;
                pvehicle_info->photo_list[i].detail.push_back("[安全带照片]-未能下载到照片资源");
                continue;
            }

            Anquandai_ImgOutMsg aqd_process_out;
            pvehicle_info->photo_list[i].timeRecord.startTime();
            LOG_OUT(INFO,"Processing zplx:%s,hphm:%s,clsbdh:%s\n",pictureCode.aqd.c_str(),pvehicle_info->hphm.c_str(),pvehicle_info->clsbdh.c_str());
            alg->anquandai_api_process(input_img,aqd_process_out);
            LOG_OUT(INFO,"Alg has process finished,clsbdh is %s\n",pvehicle_info->clsbdh.c_str());
            pvehicle_info->photo_list[i].timeRecord.endTime();

            vehicle_check_aqd(i,aqd_process_out);
        }
        else if(pvehicle_info->photo_list[i].type == pictureCode.cxnb)//车厢内部
        {
            input_img = cv::imread(pvehicle_info->photo_list[i].path);
            if(pvehicle_info->photo_list[i].path == "")
            {
                pvehicle_info->photo_list[i].result = UNDOWNLOAD;
                pvehicle_info->photo_list[i].detail.push_back("[车厢内部]-未能下载到照片资源");
                continue;
            }


            Huochexiang_ImgOutMsg huochexiang_process_out;
            std::string cllx = pvehicle_info->cllx;
            pvehicle_info->photo_list[i].timeRecord.startTime();
            LOG_OUT(INFO,"Processing zplx:%s,hphm:%s\n",pictureCode.cjh.c_str(),pvehicle_info->hphm.c_str());
            alg->huochexiang_api_process(input_img,cllx,huochexiang_process_out);
            pvehicle_info->photo_list[i].timeRecord.endTime();

            pvehicle_info->photo_list[i].algorithm_process_time = pvehicle_info->photo_list[i].timeRecord.getTime();

            pvehicle_info->photo_list[i].result = PASS;
            pvehicle_info->photo_list[i].detail.push_back("车厢内部-");

            if(!huochexiang_process_out.b_ori_chexiang
                    || !huochexiang_process_out.b_correct_pose
                    || !huochexiang_process_out.b_top_closed
                    || !huochexiang_process_out.b_roof_modified)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[车厢内部不正确]");
            }


            if(pvehicle_info->photo_list[i].result == PASS)
            {
                pvehicle_info->photo_list[i].detail.clear();
                pvehicle_info->photo_list[i].detail.push_back("通过");
            }

        }
        else if(pvehicle_info->photo_list[i].type == pictureCode.syrzp)//所有人照片
        {
            pvehicle_info->photo_list[i].result = PASS;
            pvehicle_info->photo_list[i].detail.push_back("身份证-");


            for(unsigned int  k = 0;k < pvehicle_info->photo_list.size();k++)
            {
                if(pvehicle_info->photo_list[k].type == "0202" || pvehicle_info->photo_list[k].type == "0227")//pictureCode.sfz)//身份证
                {
                    input_img = cv::imread(pvehicle_info->photo_list[i].path);
                    cv::Mat sfz_img = cv::imread(pvehicle_info->photo_list[k].path);

                    Chayanyuan_OutMsg cyy_process_out;
                    pvehicle_info->photo_list[i].timeRecord.startTime();
                    LOG_OUT(INFO,"Processing zplx:%s,hphm:%s,clsbdh:%s\n",pictureCode.cyyzp.c_str(),pvehicle_info->hphm.c_str(),pvehicle_info->clsbdh.c_str());
                    //alg->chayanyuan_api_process(input_img,sfz_img,cyy_process_out);
                    pvehicle_info->photo_list[i].timeRecord.endTime();

//                    if(!cyy_process_out.b_same)
//                    {
//                        pvehicle_info->photo_list[i].result = NOPASS;
//                        pvehicle_info->photo_list[i].detail.push_back("[所有人照片不通过]");
//                    }

                }
            }

            if(pvehicle_info->photo_list[i].result == PASS)
            {
                pvehicle_info->photo_list[i].detail.clear();
                pvehicle_info->photo_list[i].detail.push_back("通过");
            }

        }
        else if(pvehicle_info->photo_list[i].type == pictureCode.gcfp)//购车发票
        {
            input_img = cv::imread(pvehicle_info->photo_list[i].path);

            if(pvehicle_info->photo_list[i].path == "TBD")
            {
                pvehicle_info->photo_list[i].result = UNDOWNLOAD;
                pvehicle_info->photo_list[i].detail.push_back("[购车发票]-未能下载到照片资源");
                continue;
            }

            Gouchefapiao_OutMsg out_msg;
            Gouchefapiao_Input input_msg;
            input_msg.img = input_img;

            input_msg.suoyouren = pvehicle_info->syr; //所有人
            input_msg.shenfenzhenghao = ""; //身份证号
            input_msg.hegezhenghao = ""; //合格证号
            input_msg.chejiahao = pvehicle_info->clsbdh; //车架号
            input_msg.fadongjihao = pvehicle_info->fdjh; //发动机号
            input_msg.xiaoshoudanwei  = ""; //销售单位名称

            pvehicle_info->photo_list[i].timeRecord.startTime();
            LOG_OUT(INFO,"Processing zplx:%s,hphm:%s,clsbdh:%s\n",pictureCode.fdjh.c_str(),pvehicle_info->hphm.c_str(),pvehicle_info->clsbdh.c_str());
            alg->gouchefapiao_api_process(input_msg, out_msg);
            LOG_OUT(INFO,"Alg has process finished,clsbdh is %s\n",pvehicle_info->clsbdh.c_str());
            pvehicle_info->photo_list[i].timeRecord.endTime();
            pvehicle_info->photo_list[i].algorithm_process_time = pvehicle_info->photo_list[i].timeRecord.getTime();

            pvehicle_info->photo_list[i].result = PASS;
            pvehicle_info->photo_list[i].detail.push_back("购车发票-");

            if(!out_msg.b_suoyouren&&check_zplx.m_gouchefapiao.suoyouren)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[所有人不正确]");
            }
            if(!out_msg.b_shenfenzhenghao&&check_zplx.m_gouchefapiao.shenfenzhenghao)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[身份证号不正确]");
            }
            if(!out_msg.b_hegezhenghao&&check_zplx.m_gouchefapiao.hegezhenghao)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[合格证号不正确]");
            }
            if(!out_msg.b_chejiahao&&check_zplx.m_gouchefapiao.chejiahao)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[车架号不正确]");
            }
            if(!out_msg.b_fadongjihao&&check_zplx.m_gouchefapiao.fadongjihao)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[发动机号不正确]");
            }
            if(!out_msg.b_guoshuiyinzhang&&check_zplx.m_gouchefapiao.guoshuiyinzhang)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[没有国税印章]");
            }
            if(!out_msg.b_xiaoshoudanwei&&check_zplx.m_gouchefapiao.xiaoshoudanwei)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[销售单位名称不正确]");
            }

            if(pvehicle_info->photo_list[i].result == PASS)
            {
                pvehicle_info->photo_list[i].detail.clear();
                pvehicle_info->photo_list[i].detail.push_back("通过");
            }
        }
        else if(pvehicle_info->photo_list[i].type == pictureCode.sfz)//)//身份证
        {
            input_img = cv::imread(pvehicle_info->photo_list[i].path);

            if(pvehicle_info->photo_list[i].path == "TBD")
            {
                pvehicle_info->photo_list[i].result = UNDOWNLOAD;
                pvehicle_info->photo_list[i].detail.push_back("[身份证]-未能下载到照片资源");
                continue;
            }

            Shenfenzheng_ImgOutMsg out_msg;
            std::string suoyouren = pvehicle_info->syr;

            pvehicle_info->photo_list[i].timeRecord.startTime();
            LOG_OUT(INFO,"Processing zplx:%s,hphm:%s,clsbdh:%s\n",pictureCode.fdjh.c_str(),pvehicle_info->hphm.c_str(),pvehicle_info->clsbdh.c_str());
            alg->shenfenzheng_api_process(input_img, out_msg,suoyouren);
            LOG_OUT(INFO,"Alg has process finished,clsbdh is %s\n",pvehicle_info->clsbdh.c_str());
            pvehicle_info->photo_list[i].timeRecord.endTime();
            pvehicle_info->photo_list[i].algorithm_process_time = pvehicle_info->photo_list[i].timeRecord.getTime();

            pvehicle_info->photo_list[i].result = PASS;
            pvehicle_info->photo_list[i].detail.push_back("身份证-");

            if(!out_msg.b_front&&check_zplx.m_shenfenzheng.front)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[没有身份证正面]");
            }

            if(!out_msg.b_back&&check_zplx.m_shenfenzheng.back)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[没有身份证背面]");
            }

            if(!out_msg.b_valid&&check_zplx.m_shenfenzheng.valid)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[身份证过期]");
            }

            if(!out_msg.b_xingming&&check_zplx.m_shenfenzheng.xingming)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[姓名不正确]");
            }

            if(pvehicle_info->photo_list[i].result == PASS)
            {
                pvehicle_info->photo_list[i].detail.clear();
                pvehicle_info->photo_list[i].detail.push_back("通过");
            }
        }
        else if(pvehicle_info->photo_list[i].type == pictureCode.hbd && pvehicle_info->zzcmc == "长安福特汽车有限公司")//环保信息随车清单
        {
            input_img = cv::imread(pvehicle_info->photo_list[i].path);

            if(pvehicle_info->photo_list[i].path == "TBD")
            {
                pvehicle_info->photo_list[i].result = UNDOWNLOAD;
                pvehicle_info->photo_list[i].detail.push_back("[环保信息随车清单]-未能下载到照片资源");
                continue;
            }

            Suicheqingdan_OutMsg out_msg;
            Suicheqingdan_Input input_msg;
            input_msg.img = input_img;
            input_msg.chejiahao = pvehicle_info->clsbdh;

            pvehicle_info->photo_list[i].timeRecord.startTime();
            LOG_OUT(INFO,"Processing zplx:%s,hphm:%s,clsbdh:%s\n",pictureCode.fdjh.c_str(),pvehicle_info->hphm.c_str(),pvehicle_info->clsbdh.c_str());
            alg->suicheqingdan_api_process(input_msg, out_msg);
            LOG_OUT(INFO,"Alg has process finished,clsbdh is %s\n",pvehicle_info->clsbdh.c_str());
            pvehicle_info->photo_list[i].timeRecord.endTime();
            pvehicle_info->photo_list[i].algorithm_process_time = pvehicle_info->photo_list[i].timeRecord.getTime();

            pvehicle_info->photo_list[i].result = PASS;
            pvehicle_info->photo_list[i].detail.push_back("环保信息随车清单-");

            if(!out_msg.b_chejiahao&&check_zplx.m_huanbaoqingdan.chejiahao)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[车架号不正确]");
            }


            if(!out_msg.b_yinzhang&&check_zplx.m_huanbaoqingdan.yinzhang)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[没有印章]");
            }


            if(!out_msg.b_xinnenyuanche&&check_zplx.m_huanbaoqingdan.xinnenyuanche)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[新能源车没有备注]");
            }

            if(pvehicle_info->photo_list[i].result == PASS)
            {
                pvehicle_info->photo_list[i].detail.clear();
                pvehicle_info->photo_list[i].detail.push_back("通过");
            }
        }
        else if(pvehicle_info->photo_list[i].type == pictureCode.jkpz)//进口凭证
        {
            input_img = cv::imread(pvehicle_info->photo_list[i].path);

            if(pvehicle_info->photo_list[i].path == "TBD")
            {
                pvehicle_info->photo_list[i].result = UNDOWNLOAD;
                pvehicle_info->photo_list[i].detail.push_back("[进口凭证]-未能下载到照片资源");
                continue;
            }

            Jinkoupingzheng_OutMsg out_msg;
            Jinkoupingzheng_Input input_msg;
            input_msg.img = input_img;
            input_msg.chejiahao = pvehicle_info->clsbdh;

            pvehicle_info->photo_list[i].timeRecord.startTime();
            LOG_OUT(INFO,"Processing zplx:%s,hphm:%s,clsbdh:%s\n",pictureCode.fdjh.c_str(),pvehicle_info->hphm.c_str(),pvehicle_info->clsbdh.c_str());
            alg->jinkoupingzheng_api_process(input_msg, out_msg);
            LOG_OUT(INFO,"Alg has process finished,clsbdh is %s\n",pvehicle_info->clsbdh.c_str());
            pvehicle_info->photo_list[i].timeRecord.endTime();
            pvehicle_info->photo_list[i].algorithm_process_time = pvehicle_info->photo_list[i].timeRecord.getTime();

            pvehicle_info->photo_list[i].result = PASS;
            pvehicle_info->photo_list[i].detail.push_back("进口凭证-");

            if(!out_msg.b_yinzhang&&check_zplx.m_jinkoupingzheng.yinzhang)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[印章不正确]");
            }

            if(!out_msg.b_chejiahao&&check_zplx.m_jinkoupingzheng.chejiahao)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[车架号不正确]");
            }

            if(pvehicle_info->photo_list[i].result == PASS)
            {
                pvehicle_info->photo_list[i].detail.clear();
                pvehicle_info->photo_list[i].detail.push_back("通过");
            }
        }
        else if(pvehicle_info->photo_list[i].type == pictureCode.jybg)//机动车安全技术检验报告
        {
            input_img = cv::imread(pvehicle_info->photo_list[i].path);

            if(pvehicle_info->photo_list[i].path == "TBD")
            {
                pvehicle_info->photo_list[i].result = UNDOWNLOAD;
                pvehicle_info->photo_list[i].detail.push_back("[机动车安全技术检验报告]-未能下载到照片资源");
                continue;
            }

            Jianyanbaogao_ImgOutMsg out_msg;

            pvehicle_info->photo_list[i].timeRecord.startTime();
            LOG_OUT(INFO,"Processing zplx:%s,hphm:%s,clsbdh:%s\n",pictureCode.fdjh.c_str(),pvehicle_info->hphm.c_str(),pvehicle_info->clsbdh.c_str());
            std::string dtrq = getDangTianRiQi();
            alg->jianyanbaogao_api_process(input_img, pvehicle_info->hphm,  pvehicle_info->clsbdh, dtrq, out_msg);
            LOG_OUT(INFO,"Alg has process finished,clsbdh is %s\n",pvehicle_info->clsbdh.c_str());
            pvehicle_info->photo_list[i].timeRecord.endTime();
            pvehicle_info->photo_list[i].algorithm_process_time = pvehicle_info->photo_list[i].timeRecord.getTime();

            pvehicle_info->photo_list[i].result = PASS;
            pvehicle_info->photo_list[i].detail.push_back("机动车安全技术检验报告-");

            if(!out_msg.b_qianming&&check_zplx.m_jianyanbaogao.qianming)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[签名不正确]");
            }

            if(!out_msg.b_hongzhang&&check_zplx.m_jianyanbaogao.hongzhang)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[没有红章]");
            }
            if(!out_msg.b_jianyanjielun&&check_zplx.m_jianyanbaogao.jianyanjielun)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[检验结论不正确]");
            }
            if(!out_msg.b_jianyan_info&&check_zplx.m_jianyanbaogao.jianyan_info)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[检验信息不正确]");
            }
            if(!out_msg.b_chepai&&check_zplx.m_jianyanbaogao.chepai)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[车牌不正确]");
            }
            if(!out_msg.b_chejiahao&&check_zplx.m_jianyanbaogao.chejiahao)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[车架号不正确]");
            }
            if(!out_msg.b_MA&&check_zplx.m_jianyanbaogao.MA)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[没有MA印章]");
            }

            if(!out_msg.b_querenzhang&&check_zplx.m_jianyanbaogao.querenzhang)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[没有确认印章]");
            }
            if(!out_msg.b_chepai_type&&check_zplx.m_jianyanbaogao.chepai_type)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[车辆类型不正确]");
            }
            if(!out_msg.b_jianyanriqi&&check_zplx.m_jianyanbaogao.jianyanriqi)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[检验日期不正确]");
            }
            if(!out_msg.b_CMA&&check_zplx.m_jianyanbaogao.CMA)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[没有CMA印章]");
            }
            if(!out_msg.b_cheliangtu&&check_zplx.m_jianyanbaogao.cheliangtu)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[没有车辆图]");
            }

            if(!out_msg.b_jianyanbaogao&&check_zplx.m_jianyanbaogao.jianyanbaogao)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[不是检验报告]");
            }

            if(pvehicle_info->photo_list[i].result == PASS)
            {
                pvehicle_info->photo_list[i].detail.clear();
                pvehicle_info->photo_list[i].detail.push_back("通过");
            }
        }
        else if(pvehicle_info->photo_list[i].type == pictureCode.wszm)//购置税完税证明
        {
            input_img = cv::imread(pvehicle_info->photo_list[i].path);

            if(pvehicle_info->photo_list[i].path == "TBD")
            {
                pvehicle_info->photo_list[i].result = UNDOWNLOAD;
                pvehicle_info->photo_list[i].detail.push_back("[完税证明]-未能下载到照片资源");
                continue;
            }

            Wanshuizhengming_ImgOutMsg out_msg;

            pvehicle_info->photo_list[i].timeRecord.startTime();
            LOG_OUT(INFO,"Processing zplx:%s,hphm:%s,clsbdh:%s\n",pictureCode.fdjh.c_str(),pvehicle_info->hphm.c_str(),pvehicle_info->clsbdh.c_str());

            alg->wanshuizhengming_api_process(input_img,pvehicle_info->hphm, pvehicle_info->clsbdh, "", out_msg);
            LOG_OUT(INFO,"Alg has process finished,clsbdh is %s\n",pvehicle_info->clsbdh.c_str());
            pvehicle_info->photo_list[i].timeRecord.endTime();
            pvehicle_info->photo_list[i].algorithm_process_time = pvehicle_info->photo_list[i].timeRecord.getTime();

            pvehicle_info->photo_list[i].result = PASS;
            pvehicle_info->photo_list[i].detail.push_back("完税证明-");

            if(!out_msg.b_chepai&&check_zplx.m_gouzhishui.chepai)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[车牌不正确]");
            }
            if(!out_msg.b_chejiahao&&check_zplx.m_gouzhishui.chejiahao)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[车架号不正确]");
            }
            if(!out_msg.b_valid_data&&check_zplx.m_gouzhishui.valid_data)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[无效数据]");
            }
            if(!out_msg.b_chechuanshui&&check_zplx.m_gouzhishui.chechuanshui)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[车船税不正确]");
            }
            if(!out_msg.b_zhengnian&&check_zplx.m_gouzhishui.zhengnian)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[不是整年]");
            }

            if(!out_msg.b_wanshuizhengming&&check_zplx.m_gouzhishui.wanshuizhengming)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.clear();
                pvehicle_info->photo_list[i].detail.push_back("[不是完税证明]");
            }


            if(pvehicle_info->photo_list[i].result == PASS)
            {
                pvehicle_info->photo_list[i].detail.clear();
                pvehicle_info->photo_list[i].detail.push_back("通过");
            }
        }
        else if(pvehicle_info->photo_list[i].type == pictureCode.hgz)//出场合格证
        {
            input_img = cv::imread(pvehicle_info->photo_list[i].path);

            if(pvehicle_info->photo_list[i].path == "TBD")
            {
                pvehicle_info->photo_list[i].result = UNDOWNLOAD;
                pvehicle_info->photo_list[i].detail.push_back("[出场合格证]-未能下载到照片资源");
                continue;
            }

            Chuchanghegezheng_OutMsg out_msg;
            Chuchanghegezheng_Input input_msg;
            input_msg.img = input_img;
            input_msg.cheliangpinpai = pvehicle_info->clpp1; //车辆品牌
            input_msg.cheliangxinghao = pvehicle_info->cllx; //车辆型号
            input_msg.chejiahao =pvehicle_info->clsbdh; //车架号
            input_msg.fadongjixinghao = pvehicle_info->fdjxh; //发动机型号
            input_msg.fadongjihao = pvehicle_info->fdjh; //发动机号
            input_msg.ranliaozhonglei = pvehicle_info->rlzl; //燃料种类
            input_msg.luntaiguige = pvehicle_info->ltgg; //轮胎规格
            input_msg.hedingzaike= pvehicle_info->hdzk; //核定载客
            input_msg.zhizaoriqi = pvehicle_info->zzrq; //制造日期

            pvehicle_info->photo_list[i].timeRecord.startTime();
            LOG_OUT(INFO,"Processing zplx:%s,hphm:%s,clsbdh:%s\n",pictureCode.fdjh.c_str(),pvehicle_info->hphm.c_str(),pvehicle_info->clsbdh.c_str());
            alg->chuchanghegezheng_api_process(input_msg, out_msg);

            LOG_OUT(INFO,"Alg has process finished,clsbdh is %s\n",pvehicle_info->clsbdh.c_str());
            pvehicle_info->photo_list[i].timeRecord.endTime();
            pvehicle_info->photo_list[i].algorithm_process_time = pvehicle_info->photo_list[i].timeRecord.getTime();

            pvehicle_info->photo_list[i].result = PASS;
            pvehicle_info->photo_list[i].detail.push_back("出场合格证-");

            if(!out_msg.b_cheliangpinpai&&check_zplx.m_chuchanghegezheng.cheliangpinpai)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[车辆品牌不正确]");
            }

            if(!out_msg.b_cheliangxinghao&&check_zplx.m_chuchanghegezheng.cheliangxinghao)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[车辆型号不正确]");
            }

            if(!out_msg.b_chejiahao&&check_zplx.m_chuchanghegezheng.chejiahao)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[车架号不正确]");
            }

            if(!out_msg.b_fadongjixinghao&&check_zplx.m_chuchanghegezheng.fadongjixinghao)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[发动机型号不正确]");
            }

            if(!out_msg.b_fadongjihao&&check_zplx.m_chuchanghegezheng.fadongjihao)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[发动机号不正确]");
            }

            if(!out_msg.b_ranliaozhonglei&&check_zplx.m_chuchanghegezheng.ranliaozhonglei)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[燃料种类不正确]");
            }

            if(!out_msg.b_luntaiguige&&check_zplx.m_chuchanghegezheng.luntaiguige)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[轮胎规格不正确]");
            }

            if(!out_msg.b_hedingzaike&&check_zplx.m_chuchanghegezheng.hedingzaike)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[核定载客不正确]");
            }

            if(!out_msg.b_zhizaoriqi&&check_zplx.m_chuchanghegezheng.zhizaoriqi)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[制造日期不正确]");
            }

            if(!out_msg.b_yinzhang&&check_zplx.m_chuchanghegezheng.yinzhang)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[印章不正确]");
            }

            if(pvehicle_info->photo_list[i].result == PASS)
            {
                pvehicle_info->photo_list[i].detail.clear();
                pvehicle_info->photo_list[i].detail.push_back("通过");
            }

        }
        else if(pvehicle_info->photo_list[i].type == pictureCode.yzxzs && pvehicle_info->zzcmc != "长安福特汽车有限公司")//车辆一致性证书
        {
            input_img = cv::imread(pvehicle_info->photo_list[i].path);

            if(pvehicle_info->photo_list[i].path == "TBD")
            {
                pvehicle_info->photo_list[i].result = UNDOWNLOAD;
                pvehicle_info->photo_list[i].detail.push_back("[车辆一致性证书]-未能下载到照片资源");
                continue;
            }
            Yizhixingzhengshu_Input input_msg;
            Yizhixingzhengshu_OutMsg out_msg;
            input_msg.img = input_img;
            input_msg.chejiahao =pvehicle_info->clsbdh;
            pvehicle_info->photo_list[i].timeRecord.startTime();
            LOG_OUT(INFO,"Processing zplx:%s,hphm:%s,clsbdh:%s\n",pictureCode.fdjh.c_str(),pvehicle_info->hphm.c_str(),pvehicle_info->clsbdh.c_str());
            alg->yizhixingzhengshu_api_process(input_msg, out_msg);
            LOG_OUT(INFO,"Alg has process finished,clsbdh is %s\n",pvehicle_info->clsbdh.c_str());
            pvehicle_info->photo_list[i].timeRecord.endTime();
            pvehicle_info->photo_list[i].algorithm_process_time = pvehicle_info->photo_list[i].timeRecord.getTime();

            pvehicle_info->photo_list[i].result = PASS;
            pvehicle_info->photo_list[i].detail.push_back("车辆一致性证书-");

            if(!out_msg.b_yinzhang&&check_zplx.m_cheliangyizhixing.yinzhang)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[印章不正确]");
            }

            if(!out_msg.b_chejiahao&&check_zplx.m_cheliangyizhixing.chejiahao)
            {
                pvehicle_info->photo_list[i].result = NOPASS;
                pvehicle_info->photo_list[i].detail.push_back("[车架号不正确]");
            }

            if(pvehicle_info->photo_list[i].result == PASS)
            {
                pvehicle_info->photo_list[i].detail.clear();
                pvehicle_info->photo_list[i].detail.push_back("通过");
            }

        }
        else
        {
            pvehicle_info->photo_list[i].result = UNKOWN;
            pvehicle_info->photo_list[i].detail.push_back("无法处理的照片类型");
        }
    }

    vehicle_is_pass();
    LOG_OUT(INFO,"Algorithm process finished...\n");

    return RESULT_OK;
}


bool processPhoto::filterChePai(Vehicle_Info* pvehicle_info)
{
    if(!check_zplx.m_zuoqianfang.chepai)
    {
        return false;
    }
    else
    {
        if(pvehicle_info->ywlx == "A" || pvehicle_info->ywlx == "I" || pvehicle_info->ywlx == "B")
        {
            return false;
        }
        else if(pvehicle_info->ywlx == "D" && pvehicle_info->ywyy == "J")
        {
            return false;
        }
        else
        {
            return true;
        }
    }
}
unsigned int processPhoto::vehicle_check_zqf(unsigned int index,Cheliang_ImgOutMsg zqf_out_img)
{
    pvehicle_info->photo_list[index].result = PASS;
    pvehicle_info->photo_list[index].detail.push_back("左前方照片-");
    if(filterChePai(pvehicle_info))
    {
        if(!zqf_out_img.b_chepai)
        {
            pvehicle_info->photo_list[index].result = NOPASS;
            pvehicle_info->photo_list[index].detail.push_back("[车牌号不正确]");
        }
    }
    if(check_zplx.m_zuoqianfang.chebiao)
    {
        if(!zqf_out_img.b_chebiao)
        {
            pvehicle_info->photo_list[index].result = NOPASS;
            pvehicle_info->photo_list[index].detail.push_back("[车标不正确]");
        }
    }
    if(check_zplx.m_zuoqianfang.gaizhuang)
    {
        if(!zqf_out_img.b_xinglijia)
        {
            pvehicle_info->photo_list[index].result = NOPASS;
            pvehicle_info->photo_list[index].detail.push_back("[行李架有变化]");
        }
        if(!zqf_out_img.b_light_flag)
        {
            pvehicle_info->photo_list[index].result = NOPASS;
            pvehicle_info->photo_list[index].detail.push_back("[车灯有变化]");
        }
        if(!zqf_out_img.b_ori_waiguan)
        {
            pvehicle_info->photo_list[index].result = NOPASS;
            pvehicle_info->photo_list[index].detail.push_back("[外观有变化]");
        }
        if(!zqf_out_img.b_ori_color)
        {
            pvehicle_info->photo_list[index].result = NOPASS;
            pvehicle_info->photo_list[index].detail.push_back("[颜色有变化]");
        }

    }
    if(check_zplx.m_zuoqianfang.sanjiaojia)
    {
        if(!zqf_out_img.b_sanjiaojia)
        {
            pvehicle_info->photo_list[index].result = NOPASS;
            pvehicle_info->photo_list[index].detail.push_back("[没有三角架]");
        }
    }

    if(pvehicle_info->photo_list[index].result == PASS)
    {
        pvehicle_info->photo_list[index].detail.clear();
        pvehicle_info->photo_list[index].detail.push_back("通过");
    }
    return RESULT_OK;
}
unsigned int processPhoto::vehicle_check_yhf(unsigned int index,Cheliang_ImgOutMsg yhf_process_out)
{
    pvehicle_info->photo_list[index].result = PASS;
    pvehicle_info->photo_list[index].detail.push_back("右后方照片-");
    if(filterChePai(pvehicle_info))
    {
        if(!yhf_process_out.b_chepai)
        {
            pvehicle_info->photo_list[index].result = NOPASS;
            pvehicle_info->photo_list[index].detail.push_back("[车牌不正确]");
        }
    }
    if(check_zplx.m_youhoufang.chebiao)
    {
        if(!yhf_process_out.b_chebiao)
        {
            pvehicle_info->photo_list[index].result = NOPASS;
            pvehicle_info->photo_list[index].detail.push_back("[车标不正确]");
        }
    }
    if(check_zplx.m_youhoufang.gaizhuang)
    {
        if(!yhf_process_out.b_xinglijia)
        {
            pvehicle_info->photo_list[index].result = NOPASS;
            pvehicle_info->photo_list[index].detail.push_back("[行李架有变化]");
        }
        if(!yhf_process_out.b_light_flag)
        {
            pvehicle_info->photo_list[index].result = NOPASS;
            pvehicle_info->photo_list[index].detail.push_back("[车灯有变化]");
        }
        if(!yhf_process_out.b_ori_waiguan)
        {
            pvehicle_info->photo_list[index].result = NOPASS;
            pvehicle_info->photo_list[index].detail.push_back("[外观有变化]");
        }
        if(!yhf_process_out.b_ori_color)
        {
            pvehicle_info->photo_list[index].result = NOPASS;
            pvehicle_info->photo_list[index].detail.push_back("[颜色有变化]");
        }

    }
    if(check_zplx.m_youhoufang.sanjiaojia)
    {
        if(!yhf_process_out.b_sanjiaojia)
        {
            pvehicle_info->photo_list[index].result = NOPASS;
            pvehicle_info->photo_list[index].detail.push_back("[没有三角架]");
        }
    }

    if(pvehicle_info->photo_list[index].result == PASS)
    {
        pvehicle_info->photo_list[index].detail.clear();
        pvehicle_info->photo_list[index].detail.push_back("通过");
    }
    return RESULT_OK;
}
unsigned int processPhoto::vehicle_check_cjh(unsigned int index,Chejiahao_ImgOutMsg chejiahao_process_out)
{

    pvehicle_info->photo_list[index].result = PASS;
    pvehicle_info->photo_list[index].detail.push_back("车架号照片-");

    if(check_zplx.m_chejiahao.chejiahao)
    {
        if(!chejiahao_process_out.b_chejiahao)
        {
            pvehicle_info->photo_list[index].result = NOPASS;
            pvehicle_info->photo_list[index].detail.push_back("[车架号不正确]");
        }
    }


    if(pvehicle_info->photo_list[index].result == PASS)
    {
        pvehicle_info->photo_list[index].detail.clear();
        pvehicle_info->photo_list[index].detail.push_back("通过");
    }

    return RESULT_OK;
}
unsigned int processPhoto::vehicle_check_cxnb(unsigned int index,Huochexiang_ImgOutMsg cxnb_process_out)
{
    pvehicle_info->photo_list[index].result = PASS;
    pvehicle_info->photo_list[index].detail.push_back("车厢内部-");


    return RESULT_OK;
}

unsigned int processPhoto::vehicle_check_clmp(unsigned int index,Mingpai_OutMsg mingpai_process_out)
{
    pvehicle_info->photo_list[index].result = PASS;
    pvehicle_info->photo_list[index].detail.push_back("车辆铭牌照片-");
    mingpai_process_out.b_ori = PASS;

    if(check_zplx.m_cheliangmingpai.lishimingpai)
    {
        if(!mingpai_process_out.b_ori)
        {
            pvehicle_info->photo_list[index].result = NOPASS;
            pvehicle_info->photo_list[index].detail.push_back("[铭牌照片不正确]");
        }
    }

    if(check_zplx.m_cheliangmingpai.fadongjixinghao)
    {
        if(!mingpai_process_out.b_fadongjixinghao)
        {
            pvehicle_info->photo_list[index].result = NOPASS;
            pvehicle_info->photo_list[index].detail.push_back("[发动机型号不正确]");
        }
    }
    if(check_zplx.m_cheliangmingpai.zhizaoriqi)
    {
        if(!mingpai_process_out.b_zhizaoriqi)
        {
            pvehicle_info->photo_list[index].result = NOPASS;
            pvehicle_info->photo_list[index].detail.push_back("[制造日期不正确]");
        }
    }

    if(check_zplx.m_cheliangmingpai.pailiang)
    {
        if(!mingpai_process_out.b_pailiang)
        {
            pvehicle_info->photo_list[index].result = NOPASS;
            pvehicle_info->photo_list[index].detail.push_back("[排量不正确]");
        }
    }

    if(check_zplx.m_cheliangmingpai.chejiahao)
    {
        if(!mingpai_process_out.b_chejiahao)
        {
            pvehicle_info->photo_list[index].result = NOPASS;
            pvehicle_info->photo_list[index].detail.push_back("[车架号不正确]");
        }
    }

    if(pvehicle_info->photo_list[index].result == PASS)
    {
        pvehicle_info->photo_list[index].detail.clear();
        pvehicle_info->photo_list[index].detail.push_back("通过");
    }
    return RESULT_OK;
}
unsigned int processPhoto::vehicle_check_ltgg(unsigned int index,Luntaiguige_ImgOutMsg luntaiguige_process_out)
{

    pvehicle_info->photo_list[index].result = PASS;
    pvehicle_info->photo_list[index].detail.push_back("轮胎规格照片-");

    if(check_zplx.m_luntaiguige.ltgg)
    {
        if(!luntaiguige_process_out.b_luntaiguige)
        {
            pvehicle_info->photo_list[index].result = NOPASS;
            pvehicle_info->photo_list[index].detail.push_back("[轮胎规格不正确]");
        }
    }


    if(pvehicle_info->photo_list[index].result == PASS)
    {
        pvehicle_info->photo_list[index].detail.clear();
        pvehicle_info->photo_list[index].detail.push_back("通过");
    }

    return RESULT_OK;
}

unsigned int processPhoto::vehicle_check_fdjh(unsigned int index, Fadongjihao_OutMsg fdjh_process_out)
{
    pvehicle_info->photo_list[index].result = PASS;
    pvehicle_info->photo_list[index].detail.push_back("发动机号照片-");

    if(check_zplx.m_fadongjihao.fadongjihao)
    {
        if(!fdjh_process_out.b_fadongjihao)
        {
            pvehicle_info->photo_list[index].result = NOPASS;
            pvehicle_info->photo_list[index].detail.push_back("[发动机号不正确]");
        }
    }
    if(pvehicle_info->photo_list[index].result == PASS)
    {
        pvehicle_info->photo_list[index].detail.clear();
        pvehicle_info->photo_list[index].detail.push_back("通过");
    }
    return RESULT_OK;
}

unsigned int processPhoto::vehicle_check_ddccz(unsigned int index, Socket_ImgOutMsg ddccz_process_out)
{

    pvehicle_info->photo_list[index].result = PASS;
    pvehicle_info->photo_list[index].detail.push_back("电动车插座照片-");
    if(check_zplx.m_diandongchechazuo.exist)
    {
        if(!ddccz_process_out.b_socket)
        {
            pvehicle_info->photo_list[index].result = NOPASS;
            pvehicle_info->photo_list[index].detail.push_back("[电动车插座不存在]");
        }
    }

    if(pvehicle_info->photo_list[index].result == PASS)
    {
        pvehicle_info->photo_list[index].detail.clear();
        pvehicle_info->photo_list[index].detail.push_back("通过");
    }
    return RESULT_OK;

}

unsigned int processPhoto::vehicle_check_aqd(unsigned int index, Anquandai_ImgOutMsg aqd_process_out)
{
    pvehicle_info->photo_list[index].result = PASS;
    pvehicle_info->photo_list[index].detail.push_back("安全带照片-");

    if(check_zplx.m_anquandai.exist)
    {
        if(!aqd_process_out.b_anquandai)
        {
            pvehicle_info->photo_list[index].result = NOPASS;
            pvehicle_info->photo_list[index].detail.push_back("[安全带不存在]");
        }
    }
    if(pvehicle_info->photo_list[index].result == PASS)
    {
        pvehicle_info->photo_list[index].detail.clear();
        pvehicle_info->photo_list[index].detail.push_back("通过");
    }
    return RESULT_OK;
}

unsigned int processPhoto::vehicle_check_syrzp(unsigned int index)
{
    if(pvehicle_info->photo_list[index].path == "")
    {
        pvehicle_info->photo_list[index].result = UNDOWNLOAD;
        pvehicle_info->photo_list[index].detail.push_back("未能下载到照片资源");
        return RESULT_OK;
    }


    return RESULT_OK;
}
unsigned int processPhoto::vehicle_check_cyyzp(unsigned int index,Chayanyuan_OutMsg cyy_out_process)
{
    if(pvehicle_info->photo_list[index].path == "")
    {
        pvehicle_info->photo_list[index].result = UNDOWNLOAD;
        pvehicle_info->photo_list[index].detail.push_back("未能下载到照片资源");
        return RESULT_OK;
    }

    if(check_zplx.m_chayanyuan.same)
    {
        if(!cyy_out_process.b_same)
        {
            pvehicle_info->photo_list[index].result = NOPASS;
            pvehicle_info->photo_list[index].detail.push_back("[查验员人脸比对不一致]");
        }
    }

    if(pvehicle_info->photo_list[index].result == PASS)
    {
        pvehicle_info->photo_list[index].detail.clear();
        pvehicle_info->photo_list[index].detail.push_back("通过");
    }

    return RESULT_OK;
}
unsigned int processPhoto::vehicle_check_gcfp(unsigned int index)
{
    if(pvehicle_info->photo_list[index].path == "")
    {
        pvehicle_info->photo_list[index].result = UNDOWNLOAD;
        pvehicle_info->photo_list[index].detail.push_back("未能下载到照片资源");
        return RESULT_OK;
    }


    return RESULT_OK;
}
unsigned int processPhoto::vehicle_check_sfz(unsigned int index)
{
    if(pvehicle_info->photo_list[index].path == "")
    {
        pvehicle_info->photo_list[index].result = UNDOWNLOAD;
        pvehicle_info->photo_list[index].detail.push_back("未能下载到照片资源");
        return RESULT_OK;
    }


    return RESULT_OK;
}
unsigned int processPhoto::vehicle_check_hbd(unsigned int index)
{
    if(pvehicle_info->photo_list[index].path == "")
    {
        pvehicle_info->photo_list[index].result = UNDOWNLOAD;
        pvehicle_info->photo_list[index].detail.push_back("未能下载到照片资源");
        return RESULT_OK;
    }


    return RESULT_OK;
}
unsigned int processPhoto::vehicle_check_jkpz(unsigned int index)
{
    if(pvehicle_info->photo_list[index].path == "")
    {
        pvehicle_info->photo_list[index].result = UNDOWNLOAD;
        pvehicle_info->photo_list[index].detail.push_back("未能下载到照片资源");
        return RESULT_OK;
    }


    return RESULT_OK;
}
unsigned int processPhoto::vehicle_check_jybg(unsigned int index)
{
    if(pvehicle_info->photo_list[index].path == "")
    {
        pvehicle_info->photo_list[index].result = UNDOWNLOAD;
        pvehicle_info->photo_list[index].detail.push_back("未能下载到照片资源");
        return RESULT_OK;
    }


    return RESULT_OK;
}
unsigned int processPhoto::vehicle_check_wszm(unsigned int index)
{
    if(pvehicle_info->photo_list[index].path == "")
    {
        pvehicle_info->photo_list[index].result = UNDOWNLOAD;
        pvehicle_info->photo_list[index].detail.push_back("未能下载到照片资源");
        return RESULT_OK;
    }


    return RESULT_OK;
}
unsigned int processPhoto::vehicle_check_hgz(unsigned int index)
{
    if(pvehicle_info->photo_list[index].path == "")
    {
        pvehicle_info->photo_list[index].result = UNDOWNLOAD;
        pvehicle_info->photo_list[index].detail.push_back("未能下载到照片资源");
        return RESULT_OK;
    }


    return RESULT_OK;
}
unsigned int processPhoto::vehicle_check_yzxzs(unsigned int index)
{
    if(pvehicle_info->photo_list[index].path == "")
    {
        pvehicle_info->photo_list[index].result = UNDOWNLOAD;
        pvehicle_info->photo_list[index].detail.push_back("未能下载到照片资源");
        return RESULT_OK;
    }


    return RESULT_OK;
}


unsigned int processPhoto::vehicle_is_pass()
{
    unsigned int i = 0;
    std::string is_pass = PASS;
    for( i = 0;i < pvehicle_info->photo_list.size();i++)
    {
        if(
            (pvehicle_info->photo_list[i].type[0] >= '0' and pvehicle_info->photo_list[i].type[0] <= '9')
            ||(pvehicle_info->photo_list[i].type[0] == 'A'&&pvehicle_info->photo_list[i].type.size() >1)
            )
        {
            if(pvehicle_info->photo_list[i].result == NOPASS)
            {
                is_pass = NOPASS;
                break;
            }
            if(pvehicle_info->photo_list[i].result == UNKOWN)
            {
                is_pass = UNKOWN;
            }

        }
    }

    pvehicle_info->is_pass = is_pass;

    return RESULT_OK;

}


