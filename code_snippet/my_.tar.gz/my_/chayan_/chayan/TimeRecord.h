/*
		所有判定项（包括照片和视频）的相关处理时间统计。
*/

#pragma once
#ifndef _TIME_RECORD_
#define _TIME_RECORD_

#include <string>
#include <chrono>

/* 每种照片的算法处理时间（共52种） */
struct p_picture_process {
	std::string xsz;
	std::string sqb;
	std::string jqx;
	std::string jybg;
	std::string cyjl;
	std::string zqf;
    std::string zf;
    std::string yhf;
	std::string cjh;
	std::string aqd;
	std::string zdg;
	std::string ydg;
	std::string yzzd;
	std::string ezzd;
	std::string zczd;
	std::string dpdtks;
	std::string dpdtjs;
	std::string dpjy;
	std::string wqjy;
	std::string mhq;
	std::string yjc;
	std::string jly;
	std::string zql;
	std::string yql;
    std::string xszbk;
    std::string jyb_bk;
    std::string wts;
    std::string zqfcf;
    std::string yhfcf;
    std::string cjhcf;
    std::string wszm;
    std::string wttzs;
    std::string jyhgzm;
    std::string hdzk;
    std::string dchw;
    std::string sfz;
    std::string sfzbk;
    std::string jcqxbg;
    std::string chexiang;
    std::string cjh_ug;
    std::string chgw;
    std::string waikuoqianmian;
    std::string waikuocemian;
    std::string wxnb;
    std::string fzzd;
    std::string abs;
    std::string clcm;
    std::string cjhyj;
    std::string qhp;
    std::string hhp;
    std::string clbm;
    std::string dchp;

};

/* 每种照片的结果返回响应时间（共23种） */
struct p_picture_response {
	std::string xsz;
	std::string sqb;
	std::string jqx;
	std::string jybg;
	std::string cyjl;
	std::string zqf;
	std::string yhf;
	std::string cjh;
	std::string aqd;
	std::string zdg;
	std::string ydg;
	std::string yzzd;
	std::string ezzd;
	std::string zczd;
	std::string dpdtks;
	std::string dpdtjs;
	std::string dpjy;
	std::string wqjy;
	std::string mhq;
	std::string yjc;
	std::string jly;
	std::string zql;
	std::string yql;
};

/* 每种视频下载时间 */
struct p_video_download {
	std::string video_1;	//FixMe,视频种类需要以后扩充
};

/* 每种视频预处理时间（从文件系统读取文件，转换为mat的时间） */
struct p_video_pre {
	std::string video_1;	//FixMe,视频种类需要以后扩充
};

/* 每种视频算法处理时间 */
struct p_video_process {
	std::string zqf;	
	std::string yhf;
	std::string pbzd;
	std::string yzzd;
	std::string ezzd;
	std::string zdg;
	std::string ydg;
	std::string dp;
	std::string glzc;
	std::string pbzc;
};

/* 每种视频结果返回响应时间 */
struct p_video_response {
	std::string video_1;	//FixMe,视频种类需要以后扩充
};

struct p_picture_time {
	std::string AllDownload;
	p_picture_process process;
	p_picture_response response;
};

struct p_video_time {
	p_video_download download;
	p_video_pre pre;
	p_video_process process;
	p_video_response response;
};

class TimeRecord {
public:
	std::string total;
	std::string total_no_wait;
	std::string wait_queue;

	p_picture_time picture;
	p_video_time video;

public:
	TimeRecord();
	~TimeRecord();

	void startTime();			/* 开始计时 */
	void endTime();				/* 结束计时 */
	std::string getTime();		/* 获得时间(单位：ms) */

	void startTime_total();			/* 开始计时 */
	void endTime_total();			/* 结束计时 */
	std::string getTime_total();	/* 获得时间(单位：ms) */

private:
	std::chrono::time_point<std::chrono::system_clock> start;
	std::chrono::time_point<std::chrono::system_clock> end;

	std::chrono::time_point<std::chrono::system_clock> start_total;
	std::chrono::time_point<std::chrono::system_clock> end_total;
};

#endif	//	_TIME_RECORD_
