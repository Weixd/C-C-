#ifndef QUEUE_H
#define QUEUE_H
#include "BlockQueue.h"
#include "vehicle_info.h"
#include <map>
#include <iostream>
class Queue
{
public:

    BlockingQueue<Vehicle_Info*> wait_distribute_queue;//1.等待分配队列
    BlockingQueue<Vehicle_Info*> download_queue;//2.下载照片队列
    BlockingQueue<Vehicle_Info*> process_queue;//3.处理照片队列
    BlockingQueue<Vehicle_Info*> slave_reply_queue;//4.从机回复队列
    BlockingQueue<Vehicle_Info*> reply_soap_queue;//5.主机回复队列
    BlockingQueue<Vehicle_Info*> record_queue;//6.记录数据库队列
    BlockingQueue<Vehicle_Info*> send_to_android;//7.发送给安卓端队列
    BlockingQueue<Vehicle_Info*> wait_free_queue;//8.等待清除队列
    BlockingQueue<std::map<std::string,std::string>> save_slave_android_info;//9.保存从机安卓信息队列
    BlockingQueue<std::map<long,Vehicle_Info*>> wait_reply_soap_queue;//济南等待回复soap队列
};



#endif // QUEUE_H
