/********************************************************************
	created:	2012/03/15
	filename: 	EncodeText.h
	author:		Wuyichen
	
	purpose:	加密文本用
*********************************************************************/
#ifndef ENCODETEXT_H_V1_0
#define ENCODETEXT_H_V1_0

#include <string>
typedef unsigned char       BYTE;

namespace gw_util
{

/************************************
 Description: 对文本进行一次AES加密然后BASE64编码生成密文
 Returns: void
 Parameter:
    const char * clear : 明文
    std::string & cipher : 密文
************************************/
void EncodeTextByAesBase64(const char* clear, std::string& cipher);
void EncodeTextByAesBase64(const char* clear, size_t len, std::string& cipher);

/************************************
 Description: 对密文进行一次BASE64解码然后AES解密生成明文
 Returns: void
 Parameter:
    const char * cipher : 
    std::string & clear : 
************************************/
BYTE *DecodeTextByAesBase64(const char* cipher);

}
#endif // ENCODETEXT_H
