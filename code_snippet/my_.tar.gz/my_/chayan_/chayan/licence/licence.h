#ifndef LICENCE_H
#define LICENCE_H

#include "MakeLic.h"


class  Licence
{

public:
    LicDara ld;
    LicDara rld;
    LicDara tld;
    void MakeLicence(char * filename,LicDara ld);
    void ReadLicence(char * filename,LicDara rld);
    bool ComparLicence(LicDara rld,LicDara tld);

};

#endif // LICENCE_H
