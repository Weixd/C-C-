#ifndef _MAKE_LIC_
typedef unsigned char       BYTE;
typedef unsigned long       DWORD;

typedef struct
{
	DWORD dwYear;        //年
	DWORD dwMonth;       //月
	DWORD dwDay;         //日
	DWORD dwHour;        //时
	DWORD dwMinute;      //分
	DWORD dwSecond;      //秒
} LIC_TIME, *LPLIC_TIME;

typedef struct
{
	LIC_TIME tStart;
	LIC_TIME tEnd;
	LIC_TIME tCur;
	char szMachineID[64];
	char szMachineSN[20];
	char szVersion[20];
	char szLicID[20];
} LicDara, *LPLicDara;


void MakeLic(char *szFile, char *buffer, int len);
void MakeLic(char *szFile, LicDara &ld);
void ReadLic(char *szFile, LicDara &ld);

#endif
