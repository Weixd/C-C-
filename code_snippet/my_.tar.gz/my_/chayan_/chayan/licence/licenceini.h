#ifndef _INI_FILE_H_
#define _INI_FILE_H_

#include <map>
#include <vector>
#include <string.h>

using namespace std;
namespace licence
{
const int RET_OK  = 0;
const int RET_ERR = -1;
const string delim = "\n";
struct LicenceIniItem {
    string key;
    string value;
    string comment;
};
struct LicenceIniSection {
    typedef vector<LicenceIniItem>::iterator iterator;
    iterator begin() {
        return items.begin();
    }
    iterator end() {
        return items.end();
    }

    string name;
    string comment;
    vector<LicenceIniItem> items;
};

class LicenceIni
{
public:
    LicenceIni();
    ~LicenceIni() {
        release();
    }

public:

    typedef map<string, LicenceIniSection *>::iterator iterator;

    iterator begin() {
        return sections_.begin();
    }
    iterator end() {
        return sections_.end();
    }

public:
	//打开然后解析配置文件
    int load(const string &fname);
	//写入当前配置文件
    int save();
	//将配置文件另存为
    int saveas(const string &fname);


    const map<string, LicenceIniSection *> GetAll();
	//获取section段第一个键为key的值,并返回string
    string getStringValue(const string &section, const string &key, int &ret);
	//获取section段第一个键为key的值,并返回int
    int getIntValue(const string &section, const string &key, int &ret);
	//获取section段第一个键为key的值,并返回double
    double getDoubleValue(const string &section, const string &key, int &ret);

	//获取section段第一个键为key的值,并将值赋给value
    int getValue(const string &section, const string &key, string &value);
	//获取section段第一个键为key的值,并将值赋到value中,将注释赋给comment
    int getValue(const string &section, const string &key, string &value, string &comment);

	//获取section段所有键为key的值,并将值赋给values
    int getValues(const string &section, const string &key, vector<string> &values);
	//获取section段所有键为key的值, 并将值赋到values的vector中, , 将注释赋到comments的vector
    int getValues(const string &section, const string &key, vector<string> &value, vector<string> &comments);

    bool hasSection(const string &section) ;
    bool hasKey(const string &section, const string &key) ;
	//获取section段的注释
    int getSectionComment(const string &section, string &comment);
	//设置section段的注释
    int setSectionComment(const string &section, const string &comment);
    //获取注释标记符列表flags
	void getCommentFlags(vector<string> &flags);
	//设置注释标记符列表flags
    void setCommentFlags(const vector<string> &flags);

	//同时设置值和注释
    int setValue(const string &section, const string &key, const string &value, const string &comment = "");
	//删除特定的段
    void deleteSection(const string &section);
	//删除特定段的特定参数
    void deleteKey(const string &section, const string &key);
public:
	//去掉str后面的字符c
    static void trimleft(string &str, char c = ' ');
	//去掉str前面的字符c
    static void trimright(string &str, char c = ' ');
	//去掉str前后的空格符,Tab符等空白符.
    static void trim(string &str);
private:
    LicenceIniSection *getSection(const string &section = "");
    void release();
    int getline(string &str, FILE *fp);
    bool isComment(const string &str);
    bool parse(const string &content, string &key, string &value, char c = '=');


	//for debug
    void print();

private:
  int m_iRepeat;
    map<string, LicenceIniSection *> sections_;
    string fname_;
    vector<string> flags_;
};
}
#endif // _INI_FILE_H_
