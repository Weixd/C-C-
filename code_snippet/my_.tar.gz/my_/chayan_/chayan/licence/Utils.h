#ifndef _UTILS_H

#include <stdlib.h>
#include <string>
#include <iostream>
using namespace std;
typedef unsigned char       BYTE;
typedef unsigned long       DWORD;

//static const char *codes =
//	"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
//
//static 	char ords[128] = {0,0,0,0,0,0,0,0,0,0,
//	0,0,0,0,0,0,0,0,0,0,
//	0,0,0,0,0,0,0,0,0,0,
//	0,0,0,0,0,0,0,0,0,0,
//	0,0,0,62,0,0,0,63,52,53,
//	54,55,56,57,58,59,60,61,0,0,
//	0,-1,0,0,0,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,
//	22,23,24,25,0,0,0,0,0,0,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,
//	0,0,0,0,0
//};
//
//#define PAD -1

//void base64_encode(char *in, const int in_len, char *out, int out_len);
//void base64_decode(char *in, const int in_len, char *out, int *out_len);

//base64编解码
int Base64Encode(const BYTE* pData, int nLen, char* pBuf, int nBufLen);
int Base64Decode(const char* pData, int nLen, BYTE* pBuf, int nBufLen);
void EncrptyAES(BYTE* pBuf, int nLen, BYTE* pKey = NULL);
void DecrptyAES(BYTE* pBuf, int nLen, BYTE* pKey = NULL);

#endif
