#include <string>
#include <vector>

//#include "annual_vehicle_inspection_api.hpp"
#include "large_vehicle_api.hpp"

using namespace cv;
using namespace std;

//车标
struct _logo_word
{
        ELogoType logoindex;    //号牌
        vector <std::string> matchname;
};
vector <_logo_word> logo_data = {
    //{ eAERFALUOMIOU, { "阿尔法罗密欧", "阿尔法", "罗密欧", "Giulia", "MiTo", "ALFA", "Giulietta", "Stelvio" } },
            { eAODI, { "奥迪", "audi", "allroad", "Audi", "Prologue" } },
            //{ eASIDUNMADING, { "阿斯顿马丁", "阿斯顿", "马丁", "拉共达", "Rapide", "Vanquish" } },
            { eBAOJUN, { "宝俊", "宝俊", "乐驰" } },
            { eBAOMA, { "宝马", "bmw", "BMW" } },
            //{ eBAOSHIJIE, { "保时捷", "保时捷", "Panamera", "Cayenne", "Macan", "Boxster" } },
            //{ eBEIJINGQICHE, { "北京汽车", "北汽", "绅宝", "福田" } },
            { eBEIQIWEIWANG, { "北汽威旺", "威旺", "北汽" } },
            { eBENCHI, { "奔驰", "BENZ", "benz" } },
            { eBENTIAN, { "本田", "飞度", "思域", "雅阁" } },
            { eBIAOZHI, { "标致", "PEUGEOT", "307" } },
            { eBIEKE, { "别克", "凯越", "君威", "君威", "威朗", "英朗", "昂科拉", "昂科威", "林荫大道", "荣御" } },
            { eBINLI, { "宾利", "BENTLEY", "慕尚", "飞驰", "添越", "欧陆" } },
            { eBIYADI, { "比亚迪", "BYD", "秦", "唐", "元", "思锐", "速锐", "宋" } },
            { eCHANGAN, { "长安", "CHANGAN", "长安之星", "奔奔", "悦翔", "逸动", "睿骋" } },
            { eCHANGCHENG, { "长城", "哈弗", "风骏" } },
            //{ eDAOQI, { "道奇", "DODGE" } },
            { eDAZHONG, { "大众", "捷达", "桑塔纳", "帕萨特", "甲壳虫", "宝来", "朗逸", "途观", "途安", "Polo" } },
            { eDONGFENG, { "东风", "东风", "悦达" } },
            //{ eFALALI, { "法拉利", "Ferrari" } },
            { eFEIYATE, { "菲亚特", "FYT" } },
            { eFENGTIAN, { "丰田", "Toyota", "花冠", "凯美瑞" } },
            { eFUTE, { "福特", "蒙迪欧", "福克斯" } },
            { eFUTIAN, { "福田", "foton" } },
            { eHAFEI, { "哈飞", "Hafei", "赛马", "路宝" } },
            { eHAIMA, { "海马", "海南马自达" } },
            //{ eHANMA, { "悍马", "Hummer" } },
            { eJIANGHUAI, { "江淮", "JAC", "宾悦" } },
            { eJIANGLING, { "江铃", "JiangLing" } },
            //{ eJIEBAO, { "捷豹", "Jaguar", "路虎" } },
            { eJILI, { "吉利", "Jerry", "自由舰" } },
            { eJINBEI, { "金杯", "JinBei", "海狮" } },
            { eJIPU, { "吉普", "Jeep", "jeep" } },
            { eKAIDILAKE, { "凯迪拉克", "Cadillac", "赛威" } },
            { eKAIRUI, { "开瑞", "Karry" } },
            //{ eLANBOJINI, { "兰博基尼", "Lamborghini" } },
            //{ eLAOSILAISI, { "劳斯莱斯", "Rolls-Royce" } },
            { eLEIKESASI, { "雷克萨斯", "lexus" } },
            { eLEINUO, { "雷诺", "RENAULT" } },
            { eLIEBAO, { "猎豹", "leopaard" } },
            { eLIFAN, { "力帆", "LiFan" } },
            { eLINGMU, { "铃木", "SUZUK", "雨燕" } },
            //{ eLINKEN, { "林肯", "Lincoln" } },
            { eLUFENG, { "陆风", "landwind" } },
            { eLUHU, { "路虎", "landrover" } },
            //{ eMASHALADI, { "马莎拉蒂", "Maserati" } },
            { eMAZIDA, { "马自达", "MAZDA", "马六" } },
            { eMINGJUE, { "名爵", "MG" } },
            //{ eMINI, { "迷你", "Mini", "cooper" } },
            { eQIRUI, { "奇瑞", "Cherry", "东方之子", "旗云" } },
            { eQIYA, { "起亚", "KIA" } },
            { eRICHAN, { "日产", "天籁", "尼桑", "骐达", "轩逸" } },
            { eRONGWEI, { "荣威", "ROEWE", "550" } },
            { eSANLING, { "三菱", "Mitsubishi", "帕杰罗" } },
            //{ eSIKEDA, { "斯柯达", "skoda", "明锐" } },
            //{ eTESILA, { "特斯拉", "Tesla" } },
            { eWOERWO, { "沃尔沃", "Volvo" } },
            { eWULING, { "五菱", "SGMW", "宏光" } },
            { eXIALI, { "夏利", "XiaLi" } },
            { eXIANDAI, { "现代", "Hyundri", "伊兰特", "索纳塔", "胜达" } },
            { eXUEFULAN, { "雪佛兰", "雪弗兰", "景程", "乐风", "乐骋", "科鲁兹", "科帕奇" } },
            { eXUETIELONG, { "雪铁龙", "富康" } },
            { eYINGFEINIDI, { "英菲尼迪", "INFINITI" } },
            { eYIQI, { "一汽", "FAW", "红旗" } },
            { eZHONGHUA, { "中华", "Zhonghua", "俊杰" } },
            { eZHONGTAI, { "众泰", "Zotye" } },
            { eZHONGXING, { "中兴", "zxauto" } },
            { UNSURE, { " ", " " } },
};
