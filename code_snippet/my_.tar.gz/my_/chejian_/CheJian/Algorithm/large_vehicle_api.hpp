#pragma once
#include <opencv2/opencv.hpp>

#define _IS_COUNT_ALG_DEGUG_ 1

enum class EProjectType{
    eJianYanType,
    eChayanType,
    eJianCeZhanType
};

// zhidong input param
enum ZhiDongType{
    eYIERZHOU = 1, // 0322 or 0348 or 0349
    eZHUCHE, // 0351
    ePINGHUA // 0353
};

enum ZhiDongZhouType{
    eYIZHOU = 1, // 1轴
    eERZHOU,
    eSANZHOU,
    eSIZHOU,
    eWUZHOU = 5
};

enum ZhiDongVehicleType{
    eSMALLCAR = 1, // 小车
    eBIGCAR = 2, // 大车
    eMOTOBIKE, // 摩托车
};

//light type
enum ELightType
{
    eFRONT = 0,
    eBACK,
};

//Che view type
enum ECheViewType
{
    eFRONTLEFT = 0, //左前45度（0111）
    eBACKRIGHT=1,   //右后45度（0112）
    eBACKFORWARD=2, //正后（0158）
    eOtherType,   //车牌检测(0170)
};

#define ELogoType_SIZE (57)
enum ELogoType
{
    eAODI = 0,
    eBAOJUN,
    eBAOMA,
    eBEIQIWEIWANG,
    eBENCHI,
    eBENTIAN,
    eBIAOZHI,
    eBIEKE,
    eBINLI,
    eBIYADI,
    eCHANGAN,
    eCHANGAN2,
    eCHANGCHENG,
    eCHANGCHENG2,
    eDAZHONG,
    eDONGFENG,
    eFEIYATE,
    eFENGTIAN,
    eFENGTIANHUANGGUAN,
    eFUTE,
    eFUTIAN,
    eHAFEI,
    eHAIMA,
    eJIANGHUAI,
    eJIANGLING,
    eJILI,
    eJINBEI,
    eJIPU,
    eKAIDILAKE,
    eKAIRUI,
    eLEIKESASI,
    eLEINUO,
    eLIEBAO,
    eLIFAN,
    eLINGMU,
    eLUFENG,
    eLUHU,
    eMAZIDA,
    eMINGJUE,
    eOUGE,
    eQIRUI,
    eQIYA,
    eRICHAN,
    eRONGWEI,
    eSANLING,
    eSIKADA,
    eWOERWO,
    eWULING,
    eXIALI,
    eXIANDAI,
    eXUEFULAN,
    eXUETIELONG,
    eYINGFEINIDI,
    eYIQI,
    eZHONGHUA,
    eZHONGTAI,
    eZHONGXING,
    UNSURE
};

//===================================nature image===================================//
struct Cheliang_ImgOutMsg
{
    //0:未找到车头车尾
    //1：图像角度太正
    //2：拍摄距离太远
    //3:图像类型错误
    //4:图像为空
    //{常规检测指标，与档案照片无关。
    int errorflag; //0:初始化值//１:图像为空//２:未找到车头车尾//3:图像角度太正//4:拍摄距离太远//5 图像类型错误//6 项目类型错误（必须是查验、检验、检测站（检测站目前不支持））

    bool b_quality;
    bool b_chepai;          //is 'chepai' correct
    bool b_chepai_quality;  //车牌是否有掉漆情况
    bool b_chebiao;         //is 'chebiao' exist
    std::string logo;       //车标类型

    bool b_ori_lamp;        //弃用
    bool b_sanjiaojia;      //if 'sanjiaojia' exist
    int num_paiqikong;      //排气孔数量
    bool b_wheeldir_right;  //转向轮方向是否转向
    bool b_luntaihuawen;    //是否有花纹
    bool b_oritation_right; //判断图像实际方向与输入类型（0111,0112）是否一致。(弃用，对应errorflag中的5图像类型错误)
    bool b_anquanmao;       //安全帽是否存在，该值仅用于摩托车
    bool b_fuzhu_houshijing; //是否有辅助后视镜， 太原的教练车特有的需求。
    //}

    //{对输入图片检测的外观指标，不依赖档案图片,当i_tiehua大于1/3时，b_ori_waiguan=false
    bool b_ori_waiguan;     //is original 'waiguan'
    int i_tiehua;   //0：无贴花  1：贴花面积小于1/3  2：贴花面积大于等于1/3
    bool b_weiyi;
    bool b_baowei;
    //}

    //{当档案照片存在时，该结果表示与档案照片比对的结果（是否一致）。
    //当档案照片不存在时，该结果表示检测到的结果（是否有无）。
    bool b_xinglijia;
    bool b_jiaotaban;
    //}

    bool b_ori_color;       //is original 'color'

    std::string message;    //输出errorflag错误信息
    std::string date_stamp; //弃用

    cv::Mat m;              //原始输入图像.　　//以下所有矩形区域均是相对该图像
    cv::Mat m_mask;         //原始输入图像的colorMat，与m大小一致.
    cv::Mat m_waiguan;      //分割color图像
    cv::Rect r_chepai;      //车牌区域
    cv::Rect r_chebiao;     //车标区域
    cv::Rect r_sanjiaojia;  //三脚架区域

    //relate to m_waiguan
    cv::Rect r_cheshen;
    cv::Rect r_xinglijia;   //行李架最大区域
    cv::Rect r_jiaotaban;   //脚踏板区域
    cv::Rect r_baowei;      //发动机防护装置
    cv::Rect r_tiehua;      //面积最大的区域
    cv::Rect r_weiyi;       //尾翼区域
    cv::Rect r_refit;       //弃用，location of refitment


    //查验特有
    cv::Mat m_cheshen;
    bool b_sanjiaojia_hege; //判定三脚架是否是两个红三角嵌套的形式
    bool b_cheliang_type;   //车辆型号
    bool b_light_flag;
    bool b_lungu_flag;
    bool b_fanguangbeixin;

};

struct Haopai_ImgOutMsg {
    bool b_chepai;  // is 'chepai' correct
    bool b_chepailuosi; // is 'chepailuosi' hege

    //cv::Mat m_chepai;       //车牌图像
    //std::vector<cv::Rect> v_r_chepailuosi;
};

struct Chejiahao_ImgOutMsg
{
    bool b_pic_quality;         //is picture quality good
    bool b_chejiahao;           //if 'chejiahao' matching
    bool b_tuomo;               //if 'tuomo' matching
    bool b_ori_chejiahao;       //is original 'chejiahao'

    bool b_ori_space_vertical;
    bool b_ori_space_level;

    int match_brand;            //厂商VIN，0表示不符合，1表示符合，2表示不支持
    int match_score;            //nanjing - matching score
    int score;                  //查验机器人项目-置信度

    cv::Mat m;                  //original image
    cv::Rect r;                 //location of 'chejiahao'

    cv::Mat roi_m;              //roi image of 'chejiahao'
    std::vector<cv::Rect> rect; //location of 'chejiahao' char
};

struct Chejiahao_underglass_OutMsg
{
    bool b_pic_quality;         //is picture quality good
    bool b_chejiahao;           //if 'chejiahao' correct

    cv::Mat m;                  //original image

    std::vector<cv::Rect> rect; //location of 'fadongjihao'
    std::vector<int> rect_index;
};

struct Anquandai_ImgOutMsg
{
    bool b_anquandai;       //if anquandai exist

    cv::Mat m;              //original image
    cv::Rect r;             //location of 'anquandai'
};

struct Zhidong_ImgOutMsg
{
    bool b_zhidong;       //if 'zhidong' pass
    bool b_chepai;        //is 'chepai' correct
    bool b_gongwei;  //get_gongwei by gwx

    cv::Mat img;         //original image
    cv::Rect r_chepai;  //location of 'chepai'
    bool b_guntong;    //check if it is the guntong, 1 is, 0 is not
};

struct Light_ImgOutMsg
{
    bool b_car_left_light_on;       //img(灯光工位) 上 左灯是否亮
    bool b_car_right_light_on;       //img(灯光工位) 上 右灯是否亮
    //bool b_chepai;                   //is 'chepai' correct

    bool b_chepai;                   //is 'car chepai' correct
    bool b_chepai_clear;         //is 'car chepai' clear

    cv::Mat img;         //original image no.1
    cv::Rect r_chepai_1;  //location of 'chepai' in image no.1
    cv::Rect r_leftRt_1;  //location of left light in image no.1
    cv::Rect r_rightRt_1; //location of right light in image no.1

    cv::Mat img_compose;
};

struct Dipan_ImgOutMsg
{
    bool b_dipan;           //is car on 'gongwei'
    bool b_chepai;          //is 'chepai' correct
    bool b_human;           //if human exist

    cv::Mat m;              //original image
    cv::Rect r_chepai;      //location of 'chepai'
    cv::Rect r_human;       //location of human
};

struct Dipandongtai_ImgOutMsg
{
    bool b_move;            //if car move

    bool b_chepai1;         //is start 'chepai' correct
    bool b_chepai2;         //is end 'chepai' correct

    bool b_biaozhi1;        // is start 'biaozhi' correct
    bool b_biaozhi2;        // is end 'biaozhi' correct

    bool b_begin_chewei;    //At the beginning, is chewei correct
    bool b_end_chetou;      //In the end, is chetou correct

    cv::Mat m1;             //image no.1
    cv::Rect r_chepai_1;    //location of 'chepai' in image no.1
    cv::Rect r_biaozhi_1;   //location of 'biaozhi' in image no.1

    cv::Mat m2;             //image no.2
    cv::Rect r_chepai_2;    //location of 'chepai' in image no.2
    cv::Rect r_biaozhi_2;   //location of 'biaozhi' in image no.2
};

struct Weixianggaizhuang_ImgOutMsg
{
    bool b_chepai;
    bool b_gaizhuang;        //if gaizhuang

    cv::Mat m;
};

struct Shenfenzheng_ImgOutMsg
{
    bool b_front;
    bool b_back;
    bool b_valid;
    bool b_xingming;
    std::string s_xingming;
    std::string s_xingbie ;
    std::string s_mingzu ;
    std::string s_chusheng ;
    std::string s_zhuzhi ;
    std::string s_IDhaoma ;
    std::string s_valide ;

    cv::Mat m; //roi of ID card
};

struct FuzhuzhidongSign_ImgOutMsg
{
    bool b_fuzhuzhidong;       //if 'fuzhuzhidong sign' has
    cv::Mat img1;              //original image
    //cv::Rect r_fuzhuzhidong;   //fuzhuzhidong sign location
};

struct ABSSign_ImgOutMsg
{
    bool b_abs;                //if 'abs sign' has
    cv::Mat img1;              //original image
    //std::vector<cv::Rect> vr_abs;   //abs sign location
};

struct Socket_ImgOutMsg
{
    bool b_socket;            //if 'socket' has
    cv::Mat img;              //original image
};

//=====================================text image=====================================//
struct Xingshizheng_ImgOutMsg
{
    bool b_pic_quality;           //is picture quality good
    bool b_xingshizheng;          //is 'chepai' and 'chejiahao' correct
    bool b_fazhengriqi;           //is 'fazhengriqi' correct
    bool b_danganhao;             //is 'danganhao' correct
    bool b_tiaoxingma;            //is 'tiaoxingma' correct
    bool b_chepai;                //is 'chepai' correct
    bool b_chejiahao;             //is 'chejiahao' corrrect
    bool b_cheliang;              //is 'reverse cheliang' correct
    bool b_fuyefanmian;           //is "xsz fuye fanmian" or not
//    bool b_sfz_fanmian;           //is "sfz fanmian" or not
//    bool b_sfz_zhengmian;         //is "sfz zhengmian" or not
//    bool b_sfzrq_valid;           //is "sfz riqi" valid or not
    bool b_xsz_dache;             //is "xsz_dache" correct for shangrao
    bool b_renshu;
    bool b_chetype;
    bool b_qiangzhibaofie;
    bool b_fadan;
    bool b_zhuceriqi;

    std::vector<cv::Rect> cundeR;
    //行驶证主页
    std::string s_haopaihaoma; //号牌号码
    std::string s_cheliangleixing; //车辆类型
    std::string s_suoyouren; //所有人
    std::string s_zhuzhi; //住址
    std::string s_shiyongxingzhi; //使用性质
    std::string s_pinpaixinghao; //品牌型号
    std::string s_cheliangshibiedaihao; //车辆识别代号
    std::string s_fadongjihaoma; //发动机号码
    std::string s_zhuceriqi; //注册日期
    std::string s_fazhengriqi; //发证日期

    //行驶证副页
    std::string s_haopaihaoma2; //号牌号码2
    std::string s_danganbianhao; //档案编号
    std::string s_hedingzairenshu; //核定载人数
    std::string s_zongzhiliang; //总质量
    std::string s_zhengbeizhiliang; //整备质量
    std::string s_hedingzaizhiliang; //核定载质量
    std::string s_waikuochicun; //外廓尺寸
    std::string s_zhunqianyinzongzhiliang; //准牵引总质量
    std::string s_beizhu; //备注
    std::string s_jianyanjilu; //检验记录
    std::string s_ranyouzhonglei; //燃油种类
    std::string s_tiaoxingma; //条形码
    std::string s_qianzhibaofeiqizhi;//


    cv::Mat m;                    //original image
    cv::Rect r_xingshizheng;      //location of 'zhengye'
    cv::Rect r_xingshizheng_fuye; //location of 'fuye'

    cv::Mat m_xingshizheng;       //image of 'zhengye'
    cv::Rect r_chepai;            //location of 'chepai'
    cv::Rect r_chejiahao;         //location of 'chejiahao'
    cv::Rect r_fazhengriqi;       //location of 'fazhengriqi'

    cv::Mat m_xingshizheng_fuye;  //image of 'fuye'
    cv::Rect r_chepai_fuye;       //location of 'chepai' in 'fuye'
    cv::Rect r_danganhao_fuye;    //location of 'danganhao'
    cv::Rect r_tiaoxingma_fuye;   //location of 'tiaoxingma'

    int fuyezhang_cnt;            //num of "xsz fuye zhang"  for anshun[5204]
};

struct XingshizhengNew_ImgOutMsg
{
    bool b_pic_quality; //is picture quality good

    //行驶证主页
    std::string s_haopaihaoma; //号牌号码
    std::string s_cheliangleixing; //车辆类型
    std::string s_suoyouren; //所有人
    std::string s_zhuzhi; //住址
    std::string s_shiyongxingzhi; //使用性质
    std::string s_pinpaixinghao; //品牌型号
    std::string s_cheliangshibiedaihao; //车辆识别代号
    std::string s_fadongjihaoma; //发动机号码
    std::string s_zhuceriqi; //注册日期
    std::string s_fazhengriqi; //发证日期

    //行驶证副页
    std::string s_haopaihaoma2; //号牌号码2
    std::string s_danganbianhao; //档案编号
    std::string s_hedingzairenshu; //核定载人数
    std::string s_zongzhiliang; //总质量
    std::string s_zhengbeizhiliang; //整备质量
    std::string s_hedingzaizhiliang; //核定载质量
    std::string s_waikuochicun; //外廓尺寸
    std::string s_zhunqianyinzongzhiliang; //准牵引总质量
    std::string s_beizhu; //备注
    std::string s_jianyanjilu; //检验记录
    std::string s_ranyouzhonglei; //燃油种类
    std::string s_tiaoxingma; //条形码
};

struct Baodan_ImgOutMsg
{
    bool b_pic_quality;      //is picture quality good
    bool b_baodan;           //is 机动车交通事故责任强制保险单（纸质保单）
    bool b_riqi;             //is 'riqi' correct
    bool b_fuben;            //is 'fuben' detected
    bool b_xiaoshouquyu;     //is 'xiaoshouquyu' detected
    bool b_chaoben;          //is 'chaoben' detected
    bool b_chechuanshui;     //is 'chechuanshui' value positive
    bool b_chepai;           //is 'chepai' correct
    bool b_chejiahao;        //is 'chejiahao' correct
    bool b_hongzhang;        //is 'hongzhang' correct
    bool b_fadongjihao;      //is 'fadongjihao' correct
    bool b_qianzi;
    bool b_suzhou_zhang;        // has "suzhou_qianzi_zhang" or not
    bool b_sz_zhang_qianzi;     //"suzhou_qianzi_zhang" has "qianzi" or not
    bool b_dg_toubaozhuangtai;  //is "dongguan toubaozhaungtai" correct

    //for liangshan
    bool b_zaikerenshu;   //"zaikerenshu" is correct

    // for shenzhen dianzibaodan
    bool b_dianzi;        //is 电子保单
    bool b_jiaoqiangxian; //是否是交强险（深圳电子保单特有）

    std::string str_xiaoshouquyu; //string of 'xiaoshouquyu'

    cv::Mat m;               //original image
    cv::Rect r_hongzhang;    //location of 'hongzhang'
    cv::Rect r_roi;          //location of main roi
    cv::Rect r_chechuanshui; //location of 'chechuanshui'

    cv::Mat m_roi;           //image of main roi
    cv::Rect r_chepai;       //location of 'chepai'
    cv::Rect r_chejiahao;    //location of 'chejiahao'
    cv::Rect r_fadongjihao;  //location of 'fadongjihao'
    cv::Rect r_start_riqi;   //location of start 'riqi'
    cv::Rect r_end_riqi;     //location of end 'riqi'

    cv::Mat m_fuben;         //image of 'fuben' area
    cv::Mat m_chaoben;       //image of 'chaoben' area
    cv::Rect r_fuben;        //location of 'fuben'
    cv::Rect r_xiaoshouquyu; //location of 'xiaoshouquyu'
    cv::Rect r_chaoben;      //location of 'chaoben'
    cv::Mat m_table;         //image of detected table
};

struct Jianyanbaogao_ImgOutMsg
{
    bool b_pic_quality;       //is picture quality good
    bool b_jianyanbaogao;     //is 'chepai' and 'chejiahao' correct
    bool b_qianming;          //if 'qianming' exist
    bool b_hongzhang;         //if 'hongzhang' exist
    bool b_jianyanjielun;     //if 'jianyanjielun' pass
    bool b_jianyan_info;      //if 'jianyaninfo' pass
    bool b_chepai;            //is 'chepai' correct
    bool b_chejiahao;         //is 'chejiahao' correct
    bool b_MA;                //if 'MA zhang' exist
    bool b_querenzhang;       //if 'cheliang weiyi querenzhang' exist	by gwx
    bool b_chepai_type;       //is 'chepai_type' correct
    bool b_jianyanriqi;
    bool b_CMA;
    bool b_cheliangtu;

    cv::Rect r_auxiliary;     //location of main roi
    cv::Rect r_compare;       //location of 'jianyaninfo' roi
    cv::Rect r_qianming;      //location of 'qianming'
    cv::Rect r_hongzhang;     //location of 'yinzhang'
    cv::Rect r_jianyanjielun; //location of 'jianyanjielun'
    cv::Rect r_chejiahao;     //location of 'chejiahao'
    cv::Rect r_chepai;        //location of 'chepai'
    cv::Rect r_querenzhang;       //location of 'cheliang weiyi querenzhang'	by gwx
    cv::Rect r_chepai_type;   //location of 'chepai_type'  ps. currently used for nanning city

    cv::Mat m_rotate;         //rotated image
    cv::Mat m_auxiliary;      //image of main roi
    cv::Mat m_compare;        //image of detected 'jianyaninfo'
    cv::Mat m_table;          //image of detected table
    cv::Mat m_chepai_type;    //in order to check the result's
};

struct Jianyanbaogao_yiqi_ImgOutMsg
{
    bool b_jianyanbaogao_yiqi;//is "yiqi"
    bool b_hongzhang;         //if 'hongzhang' exist
    bool b_jianyanjielun;     //if 'jianyanjielun' pass
    bool b_chepai;            //is 'chepai' correct
    bool b_chejiahao;         //is 'chejiahao' correct
    bool b_panding;  //if result of panding can use
    bool b_qianming;
    bool b_MA;

    std::vector<int> v_panding_chongqing; //chongqing
    std::vector<int> v_panding_chongqing_yizhou;
    std::vector<int> v_panding_chongqing_erzhou;
    std::vector<int> v_panding_chongqing_zuowaideng;
    std::vector<int> v_panding_chongqing_youwaideng;

    cv::Rect r_hongzhang;     //location of 'yinzhang'
    cv::Rect r_jianyanjielun; //location of 'jianyanjielun'
    cv::Rect r_chejiahao;     //location of 'chejiahao'
    cv::Rect r_chepai;        //location of 'chepai'

    cv::Mat m_rotate;         //rotated image
};

struct Jiludan_ImgOutMsg
{
     bool b_hongzhang;         //if 'hongzhang' exist
    bool b_MA;
    cv::Rect r_hongzhang;     //location of 'yinzhang'
    cv::Rect r_MA;        //location of 'MA_zhang'
    cv::Mat m_rotate;         //rotated image
};

struct weituoshu_ImgOutMsg
{
    bool b_weituoshu; //is weituoshu
    bool b_hongzhang; //if 'hongzhang' exist
    bool b_shenfenzheng_front;
};

struct Shenqingdan_ImgOutMsg
{
    bool b_pic_quality;                 //is picture quality good
    bool b_chepai;                      //is 'chepai' correct
    bool b_chejiahao;                   //is 'chejiahao' correct
    bool b_qianming;                    //if 'qianming' exist
    bool b_chepai_type;                 //if 'chepai type' correct
    bool b_postcode;                    //if 'postcode' correct
    bool b_address;                     //if 'address' exist
    bool b_shenqingbiao;                //if picture is shenqingbiao
    bool b_yinzhang;                    //if yinzhang is exist
    bool b_xingming;                    //if xingming is exist
    bool b_dailirenxingming;            //if dailiren xingming is exist
    bool b_jianyanhegebiaozhi;          //if jianyanhegebiaozhi is tick
    bool b_date;                        //if date is exist
    int  registeringarea_flag;          //号牌登记地区标识   0:本地、异地 都没有打钩，无法判断  1：本地申请 2：异地申请

    std::string s_dailiren_name;        //保定送检人姓名，其他地市为代理人姓名
    std::string telephone_suoyouren;    //if telephone exist
    std::string telephone_dailiren;     //if telephone exist
    std::string telephone_gudingdianhua; //if gudingdianhua exit

    cv::Mat m_rotate;                   //rotated image
    cv::Mat m_chepai_type;              //image of chepai type
    cv::Mat m_address;                  //image of address
    cv::Mat m_postcode;                 //image of postcode
    cv::Mat m_table;                    //image of detected table
    cv::Mat m_yinzhang;                 //image of yinzhang
    cv::Mat m_xingming;                 //image of xingming

    cv::Rect r_chepai;                  //location of 'chepai'
    cv::Rect r_chejiahao;
    cv::Rect r_qianming;                //location of 'qianming'
    cv::Rect r_telephone_suoyouren;     //location of telephone
    cv::Rect r_telephone_dailiren;      //location of telephone
    cv::Rect r_chepai_type;             // location of chepai type
    cv::Rect r_address;                 // location of address
    cv::Rect r_postcode;                // location of post code
    cv::Rect r_yinzhang;                // location of 'yinzhang'
    cv::Rect r_xingming;                // location of 'xingming'
    cv::Rect r_dailiren_xingming;       // location of 'dailiren xingming'
};

struct Jianyanbiao_ImgOutMsg
{
    bool b_jianyanbiao;         //is text 'jianyanbiao'

    bool b_waiguan_sign;        //if 'waiguan' signature exist
    bool b_yinche_sign;         //also called “dongtai”   if 'yinche' signature exist
    bool b_dipan_sign;          //also called "bujian"    if 'dipan' signature exist

    bool b_hongzhang;
    bool b_qianzi;           // if Handwritten signature exist
    bool b_jielun;           //is "hege" or "tongguo"
    bool b_chepai;           //is chepai right
    bool b_jianyanjieguo5; //if the fifth item of jianyanjieguo is hege
    bool b_jianyanriqi; //if jianyanriqi is today
    bool b_xian_panding_all;
    bool b_panding; // 连云港判定项目有 “×” 代表不合格

    std::vector<int> v_panding;

    cv::Mat m_rotate;           //rotated image
    cv::Rect r_table;           //location of table
    cv::Mat m_table;            //image of detected table
    std::vector<cv::Rect> rect; //location of signatures
    cv::Rect r_chepai_roi;
};

struct Jianyanbiaoback_ImgOutMsg
{
    bool b_jianyanbiao_back;     //is back side of text 'jianyanbiao'
    bool b_waiguan_sign;        //if 'waiguan' (also called 'jianyanyuan') signature exist
    bool b_yinche_sign;         //if 'yinche' (also called 'dipandongtai') signature exist
    bool b_dipan_sign;          //if 'dipan' signature exist

    cv::Mat m_roi;              //image of roi
    std::vector<cv::Rect> rect; //location of signatures

    cv::Mat m_table;            //image of detected table
};

struct Huanbaodan_ImgOutMsg
{
    bool b_jiancejielun;     //if 'jiancejielun' pass
    bool b_jiancejielun_waijian;
    bool b_jiancejielun_paiqiwuran;
    bool b_chepai;           //is 'chepai' correct
    bool b_chejiahao;        //is 'chejiahao' correct
    bool b_yinzhang;         //if 'yinzhang' exist
    bool b_qianzi;           //if 'qianzi' exist
    bool b_MA;
    bool b_yinzhang_hege;
    bool b_qianzi_caozuoyuan; //if 'qianzi' of 'caozuoyuan' exist
    bool b_qianzi_jiashiyuan; //if 'qianzi' of 'jiashiyuan' exist
    bool b_qianzi_shenheyuan; //if 'qianzi' of 'shenheyuan' exist
    bool b_qianzi_pizhunren;  //if 'qianzi' of 'pizhunren' exist
    bool b_qianzi_shouquan;
    bool b_qianzi_jianyanyuan;
    bool b_has_qianfariqi;
    bool b_riqi_shijian; //if 'jianceriqi' correct
    bool b_huanbaodan;  //if the image is huanbaodan
    bool b_dianzibiaoge; //if the image is dianzibiaoge
    bool b_valid_date;    //Is the time within the validity period
    bool b_engine_num;  // is ‘fadongjihao’ correct;
    bool b_cheliangxinghao;
    bool b_bianhao_is_same; // for tianjin

    cv::Mat m_rotate;        //rotated image
    cv::Rect r_table;        //location of table roi
    cv::Rect r_chepai;       //location of 'chepai'
    cv::Rect r_chejiahao;    //location of 'chejiahao'
    cv::Rect r_yinzhang;     //location of 'yinzhang'
    cv::Rect r_qianzi;       //location of 'qianzi'

    cv::Mat m_table;         //image of table roi
    cv::Rect r_jiancejielun; //location of 'jianyanjielun'
};

struct Waikuochicun_ImgOutMsg
{
    bool b_waikuochicun;
    bool b_chepai;           //is 'chepai' correct
    bool b_chejiahao;        //is 'chejiahao' correct
    bool b_yinzhang;         //if 'yinzhang' exist
    bool b_qianzi;           //if 'qianzi' exist
    bool b_data_vaild;
    bool b_jiancejieguo;


    cv::Mat m_rot;     //rotated image
};

struct Wanshuizhengming_ImgOutMsg
{
    bool b_chepai;
    bool b_chejiahao;                //is 'chejiahao' correct
    bool b_valid_data;              //Whether the date is within the validity period
    bool b_chechuanshui;
    bool b_zhengnian;               //Whether the date is one year
    bool b_wanshuizhengming;        //Whether the image is wanshuizhengming
    bool b_dianzibaodan;

    std::string shuikuan_start_riqi; //string of start 'shuikuanriqi'
    std::string shuikuan_end_riqi;   //string of end 'shuikuanriqi'
};

struct Weituotongzhishu_ImgOutMsg
{
    bool b_weituotongzhishu;  //is weituotongzhishu
    bool b_chepai;           //is 'chepai' correct
    bool b_chejiahao;        //is 'chejiahao' correct
    bool b_yinzhang;         //if 'yinzhang' exist

    cv::Rect r_chepai;       //location of 'chepai'
    cv::Rect r_chejiahao;    //location of 'chejiahao'
    cv::Rect r_yinzhang;     //location of 'yinzhang'
};

struct Quxianbaogao_ImgOutMsg
{
    bool b_quxianbaobao;      //is quxianbaogao
    bool b_chepai;           //is 'chepai' correct
    bool b_yinzhang;         //if 'yinzhang' exist

    cv::Rect r_chepai;       //location of 'chepai'
    cv::Rect r_yinzhang;     //location of 'yinzhang'

    cv::Mat m_chepai;        //chepai image
    cv::Mat m_yinzhang;      //yinzhang image
};

struct Jianyanhege_ImgOutMsg
{
    bool b_jianyanhege;      //is jianyanhege
    bool b_chepai;           //is 'chepai' correct
    bool b_chejiahao;        //is 'chejiahao' correct
    bool b_riqi;             //is  riqi  valid
    bool b_yinzhang;         //if 'yinzhang' exist

    cv::Rect r_jianyanhege;  //location of 'jianyanhege'
    cv::Rect r_chepai;       //location of 'chepai'
    cv::Rect r_chejiahao;    //location of 'chejiahao'
    cv::Rect r_riqi;         //location of 'riqi'
    cv::Rect r_yinzhang;     //location of 'yinzhang'

    cv::Mat m_jianyanhege;   //jianyanhege image
    cv::Mat m_chepai;        //chepai image
    cv::Mat m_chejiahao;     //chejiahao image
    cv::Mat m_riqi;          //chepai image
    cv::Mat m_yinzhang;      //yinzhang image
};

struct Yingyezhizhao_ImgOutMsg
{
    bool b_yingyezhizhao;          //is yingyezhizhao
    bool b_yingyezhizhao_code;     //is yingyezhidao code exit
    bool b_yinzhang;               //if 'yinzhang' exist

    cv::Rect r_yingyezhizhao;      //location of 'yingyezhizhao'
    cv::Rect r_yingyezhizhao_code; //location of 'yingyezhizhao_code'
    cv::Rect r_yinzhang;           //location of 'yinzhang'

    cv::Mat m_yingyezhizhao;       //yingyezhizhao image
    cv::Mat m_yingyezhizhao_code;  //yingyezhizhao_code image
    cv::Mat m_yinzhang;            //yinzhang image
};

struct Bolitouguanglv_ImgOutMsg
{
    bool b_bolitouguanglv;         //is bolitouguanglv
    bool b_chepai;                 //is chepai right
    bool b_jianyanyuan_yinzhang;   //is jianyanyuan_yinzhang exist
    bool b_jianchezhan_yinzhang;   //is jianchezhan_yinzhang exit

    cv::Rect r_bolitouguanglv;     //location of 'bolitouguanglv'
    cv::Rect r_chepai;             //location of 'chepai'
    cv::Rect r_jianyanyuan_yinzhang; //jianyanyuan_yinzhang
    cv::Rect r_jianchezhan_yinzhang; //jianchezhan_yinzhang

    cv::Mat m_bolitouguanglv;       //yingyezhizhao image
    cv::Mat m_chepai;               //yingyezhizhao_code image
    cv::Mat m_jianyanyuan_yinzhang; //jianyanyuan_yinzhang image
    cv::Mat m_jianchezhan_yinzhang; //jianchezhan_yinzhang image
};

struct Gaozhishu_ImgOutMsg
{
     bool b_hongzhang;               // if the hongzhang exist
    bool b_qianming;                      // if the qianming exist
};

struct Rongqueshouli_ImgOutMsg
{
    bool b_qianming;               //if the image belongs to gaozhishu
    bool b_dagou;               // if the hongzhang exist

};

struct Zhaotong_fanguangbiaoshi_ImgOutMsg
{
    bool b_fanguangbiaoshi;      //is image is fanguangbiaoshi jian ce
    bool b_chepai;               //is chepai correct
    bool b_data_tongguo;         // is the jiancexiang data tong guo
};

//=====================================video======================================//
struct Cheliang_VideoOutMsg
{
    bool b_chepai;          //is 'chepai' correct
    bool b_time;             //if human exist && check enough time

    cv::Mat img;            //image to show
    cv::Rect r_chepai;      //location of 'chepai'
};


struct Light_VideoOutMsg
{
    bool b_chepai;          //is 'chepai' correct
    bool b_light_on;        //is front light on
    bool b_human_clear;     //is there clear of human
    bool b_tester_move;     //is light tester move after light on
    bool b_time;            //检验时间是否合格

    cv::Mat img_show;
    std::vector<cv::Mat> img_vector;    //image to show
    cv::Rect r_chepai;      //location of 'chepai'
    cv::Rect r_left_light;  //location of left light
    cv::Rect r_right_light; //location of right light
    cv::Rect r_human;       //location of human
    cv::Rect r_light_tester;//location of light tester
};

struct Dipan_VideoOutMsg
{
    bool b_time;            //check enough time
    bool b_human;           //if human exist
    cv::Mat img;            //image to show
    cv::Rect r_human;       //location of human
};

struct Zhidong_VideoOutMsg
{
    bool b_chepai;          //is 'chepai' correct
    bool b_yizhou;          //is yizhou pass
    bool b_erzhou;          //is erzhou pass
    bool b_zhuche;          //is zhuche pass
    bool b_bounce_up;
    bool b_human_clear;           //is there clear of human
    bool b_light;           //is the light on
    bool b_guntong;
    bool b_time;            //检验时间是否合格

    std::vector<cv::Mat> img_vector;
    cv::Mat img_show;
    cv::Rect r_chepai;      //location of 'chepai'
    cv::Rect r_human;       //location of human

};

struct Dipandongtai_VideoOutMsg
{
    bool b_chepai;
    bool b_move;            //if car move
    bool b_time;            //if human exist && check enough time

    cv::Mat img;            //image to show
    cv::Rect r_chepai;      //location of chepai
    cv::Rect r_human;       //location of human
};


//=====================================large vehicle======================================//
struct Yingjichui_ImgOutMsg
{
    bool b_yingjichui;      //if 'yingjichui' exist

    cv::Mat m;              //original image
    cv::Rect r;             //location of 'yingjichui'
};

struct Miehuoqi_ImgOutMsg
{
    bool b_miehuoqi;        //if 'miehuoqi' exist
    bool b_yalibiao;
    cv::Mat m;              //original image
    cv::Rect r_miehuoqi;    //location of 'miehuoqi'
    cv::Rect r_yalibiao;    //location of 'yalibiao'
};

struct Xingchejiluyi_ImgOutMsg
{
    bool b_xingchejiluyi;   //if 'xingchejiluyi' exist
    bool b_triple_c;        //if triple-c exist
    bool b_screen;          //if screen is on
    cv::Mat m;              //original image

    cv::Mat m_xcjly;        //xingchejiluyi image
    cv::Rect r_triple_c;    //location of triple-c
    cv::Rect r_screen;      //location of 'screen'
};

struct Luntaihuawen_ImgOutMsg
{
    //bool b_luntai;          //if 'luntaiguige' correct
    bool b_luntai_huawen; // if 'luntai huawen' correct
    bool b_chepai;          //if chepai correct

    cv::Mat m1,m2;              //original image
    //std::vector<cv::Point> p_luntaiguige;  //location of 'luntaiguige' points
};

struct Luntaiguige_ImgOutMsg
{
    bool b_luntaiguige;          //if 'luntaiguige' correct
    int score;            //置信度

    cv::Mat m;              //original image with det_rect
    std::vector<cv::Point> p_luntaiguige;  //location of 'luntaiguige' points

};

struct Huoche_ImgOutMsg
{
    bool b_quality;
    int errorflag;//0:暂不支持（新车）1：图像角度太正 2：拍摄距离太远 3:未检测到车尾

    bool b_left_reflect;      //if left reflector pass
    bool b_left_protect;      //if left protector pass
    bool b_right_reflect;     //if right reflector pass
    bool b_right_protect;     //if right protector pass
    bool b_rear_reflect;      //if rear reflector pass
    bool b_rear_protect;      //if rear protector pass
    bool b_rear_plate;        //if rear mark plate pass
    bool b_pentu_chepai;      //is 'pentu_chepai' correct
    bool b_sanjiaojia;
    bool b_chepai;
    bool b_chebiao;
    cv::Rect r_chebiao;
    std::string logo;


    cv::Mat m;                //original image
    cv::Rect r_left_reflect;  //location of left reflector
    cv::Rect r_left_protect;  //location of left protector
    cv::Rect r_right_reflect; //location of right reflector
    cv::Rect r_right_protect; //location of right protector
    cv::Rect r_rear_reflect;  //location of rear reflector
    cv::Rect r_rear_protect;  //location of rear protector
    cv::Rect r_rear_plate;    //location of rear mark plate
    cv::Rect r_pentu_chepai;  //location of 'pentu_chepai'
};

struct Chemenpentu_ImgOutMsg
{
    bool b_total_mass;       //总质量
    bool b_board_height;     //栏板高度
    bool b_person_number;    //载客人数
    bool b_hezai_ziyang;//核载字样
    bool b_chaoyuanweifa_ziyang;    //超员违法字样
    bool b_report_phone_ziyang;     //举报电话字样
    bool b_jiaolianche_ziyang; //教练车字样

    cv::Mat m;               //original image
    cv::Rect r_door; //location of door
    cv::Rect r_total_mass;  //location of total_mass
    cv::Rect r_board_height;    //location of board_height
    cv::Rect r_person_number;    //location of person_number
    cv::Rect r_chaoyuanweifa;    //location of chaoyuanweifa
    cv::Rect r_report_phone;    //location of report_phone
};

struct Huochexiang_ImgOutMsg
{
    bool b_ori_chexiang; //is original 'chexiang'(should not be refitted)
    bool b_correct_pose; //is correct images' pose
    bool b_top_closed;   //is the top of 'chexiang' closed
    bool b_roof_modified;//is the top of cangzha（仓栅）modified

    cv::Mat m;           //original image
    cv::Mat m_chewei;    //image of chewei
    cv::Rect r_chexiang; //location of 'chexiang'
};

struct Kechexiang_ImgOutMsg
{
    bool b_seat;                  //is the number of 'seat' correct
    bool b_internal;              //is the internal of minibus
    bool b_suspect_modified;      //is the vehicle(K39) modified

    bool b_anquandai;             //是否有安全带

    int num_seat;

    cv::Mat ori_img;                 //original image
};

struct Mingpai_Input
{
    cv::Mat img_src; //公告照片
    cv::Mat img_his; //历史照片
    std::string ans_cheliangpinpai;
    std::string ans_cheliangxinghao;
    std::string ans_fadongjixinghao;
    std::string ans_zhizaoriqi;
    std::string ans_zhizaoguo;
    std::string ans_pailiang;
    std::string ans_zongzhiliang;
    std::string ans_chejiahao;
    std::string ans_zhizaochangmingcheng;
    std::string ans_hedingzaike;
};

struct Mingpai_OutMsg
{
    bool b_pic_quality;           //is picture quality good
    bool b_mingpai;
    bool b_cheliangpinpai;
    bool b_cheliangxinghao;
    bool b_fadongjixinghao;
    bool b_zhizaoriqi;
    bool b_zhizaoguo;
    bool b_pailiang;
    bool b_zongzhiliang;
    bool b_chejiahao;
    bool b_zhizaochangmingcheng;
    bool b_hedingzaike;
    bool b_ori; //公告照片和历史照片对比结果是否一致

    cv::Mat m;                    //original image
    cv::Rect r_mingpai;           //location of 'mingpai'

    cv::Mat m_mingpai;            //image of 'mingpai'
    cv::Rect r_chejiahao;         //location of 'chejiahao'
    cv::Rect r_fadongjihao;       //location of 'fadongjihao'
    cv::Rect r_pailiang;          //location of 'pailiang'
    cv::Rect r_zhizaonianyue;     //location of 'zhizaonianyue'
};

//专网证件表单类
struct ZhuceSQB_Input
{
    cv::Mat img;
    std::string suoyouren; //所有人
    std::string yewuleixing; //业务类型
    std::string haopaizhonglei; //号牌种类
    std::string haopaihaoma; //号牌号码
    std::string cheliangshibiedaihao; //车辆识别代号
    std::string shiyongxingzhi; //使用性质
};

struct ZhuceSQB_OutMsg
{
    std::string suoyourenshouji; //所有人手机号码
    std::string dailiren; //代理人
    std::string dailirenshouji; //代理人手机号码

    bool b_suoyouren; //所有人
    bool b_yewuleixing; //业务类型
    bool b_haopaizhonglei; //号牌种类
    bool b_haopaihaoma; //号牌号码
    bool b_cheliangshibiedaihao; //车辆识别代号
    bool b_shiyongxingzhi; //使用性质
    bool b_qianzi; //签字
};

struct Gouchefapiao_Input
{
    cv::Mat img;
    std::string suoyouren; //所有人
    std::string shenfenzhenghao; //身份证号
    std::string hegezhenghao; //合格证号
    std::string chejiahao; //车架号
    std::string fadongjihao; //发动机号
    std::string xiaoshoudanwei; //销售单位名称
};

struct Gouchefapiao_OutMsg
{
    bool b_suoyouren; //所有人
    bool b_shenfenzhenghao; //身份证号
    bool b_hegezhenghao; //合格证号
    bool b_chejiahao; //车架号
    bool b_fadongjihao; //发动机号
    bool b_guoshuiyinzhang; //国税印章
    bool b_xiaoshoudanwei; //销售单位名称
};

struct Suicheqingdan_Input
{
    cv::Mat img;
    std::string chejiahao; //车架号
};

struct Suicheqingdan_OutMsg
{
    bool b_chejiahao; //车架号
    bool b_yinzhang; //印章
    bool b_xinnenyuanche; //新能源车是否备注
};

struct Jinkoupingzheng_Input
{
    cv::Mat img;
    std::string chejiahao; //车架号
};

struct Jinkoupingzheng_OutMsg
{
    bool b_chejiahao; //车架号
    bool b_yinzhang; //印章
};

struct Chechuanshui_Input
{
    cv::Mat img;
    std::string chejiahao; //车架号
};

struct Chechuanshui_OutMsg
{
    bool b_chejiahao; //车架号
    bool b_yinzhang; //印章
};

struct Suoyouquanzhuanyi_Input
{
    cv::Mat img;
    std::string haopaihaoma; //号牌号码
    std::string chejiahao; //车架号
    std::string cheliangleixing; //车辆类型
};

struct Suoyouquanzhuanyi_OutMsg
{
    bool b_maifang; //卖方
    bool b_haopaihaoma; //号牌号码
    bool b_chejiahao; //车架号
    bool b_cheliangleixing; //车辆类型
    bool b_yinzhang; //印章
};

struct Dengjizhengshu_Input
{
    cv::Mat img;
    std::string cheliangleixing; //车辆类型
    std::string cheliangxinghao; //车辆型号
    std::string chejiahao; //车架号
    std::string fadongjihao; //发动机号
    std::string hedingzaike; //核定载客
    std::string shiyongxingzhi; //使用性质
    std::string chuchangriqi; //出厂日期
    std::string fazhengriqi; //发证日期
};

struct Dengjizhengshu_OutMsg
{
    bool b_cheliangleixing; //车辆类型
    bool b_cheliangxinghao; //车辆型号
    bool b_chejiahao; //车架号
    bool b_fadongjihao; //发动机号
    bool b_hedingzaike; //核定载客
    bool b_shiyongxingzhi; //使用性质
    bool b_chuchangriqi; //出厂日期
    bool b_fazhengriqi; //发证日期
    bool b_jiguanzhang; //发证机关章
};

struct Haopai_Input
{
    cv::Mat img;
    std::string haopaihaoma; //号牌号码
};

struct Haopai_OutMsg
{
    bool b_haopaihaoma; //号牌号码
};

struct BiangengSQB_Input
{
    cv::Mat img;
    std::string haopaizhonglei; //号牌种类
    std::string haopaihaoma; //号牌号码
    std::string biangengleixing; //变更类型
};

struct BiangengSQB_OutMsg
{
    bool b_haopaizhonglei; //号牌种类
    bool b_haopaihaoma; //号牌号码
    bool b_biangengleixing; //变更类型
    bool b_qianzi; //签字
};

struct DiyaSQB_Input
{
    cv::Mat img;
    std::string haopaizhonglei; //号牌种类
    std::string haopaihaoma; //号牌号码
    std::string yewuleixing; //业务类型
    std::string suoyouren; //所有人
};

struct DiyaSQB_OutMsg
{
    bool b_haopaizhonglei; //号牌种类
    bool b_haopaihaoma; //号牌号码
    bool b_yewuleixing; //业务类型
    bool b_suoyourenqianzi; //所有人签字
    bool b_diyaquanren; //抵押权人
    bool b_diyaquanrenqianzi; //抵押权人签字
};

struct Huishouzhengming_Input
{
    cv::Mat img;
    std::string suoyouren; //所有人
    std::string shenfenzhenghao; //身份证号
    std::string haopaihaoma; //号牌号码
    std::string chejiahao; //车架号
};

struct Huishouzhengming_OutMsg
{
    bool b_suoyouren; //所有人
    bool b_shenfenzhenghao; //身份证号
    bool b_haopaihaoma; //号牌号码
    bool b_chejiahao; //车架号
    bool b_fazhengdanweizhang; //发证单位章
    bool b_bumenzhuguanzhang; //主管部门章
    bool b_shouchedanweizhang; //收车单位章
};

struct Mieshizhengming_Input
{
    cv::Mat img;
    std::string haopaihaoma; //号牌号码
};

struct Mieshizhengming_OutMsg
{
    bool b_haopaihaoma; //号牌号码
    bool b_suoyourenqianzi; //所有人签字
    bool b_danweiyinzhang; //查证单位印章
};

struct Chuchanghegezheng_Input
{
    cv::Mat img;
    std::string cheliangpinpai; //车辆品牌
    std::string cheliangxinghao; //车辆型号
    std::string chejiahao; //车架号
    std::string fadongjixinghao; //发动机型号
    std::string fadongjihao; //发动机号
    std::string ranliaozhonglei; //燃料种类
    std::string luntaiguige; //轮胎规格
    std::string hedingzaike; //核定载客
    std::string zhizaoriqi; //制造日期
};

struct Chuchanghegezheng_OutMsg
{
    bool b_cheliangpinpai; //车辆品牌
    bool b_cheliangxinghao; //车辆型号
    bool b_chejiahao; //车架号
    bool b_fadongjixinghao; //发动机型号
    bool b_fadongjihao; //发动机号
    bool b_ranliaozhonglei; //燃料种类
    bool b_luntaiguige; //轮胎规格
    bool b_hedingzaike; //核定载客
    bool b_zhizaoriqi; //制造日期
    bool b_yinzhang;   //印章
};

struct Yizhixingzhengshu_Input
{
    cv::Mat img;
    std::string chejiahao; //车架号
};

struct Yizhixingzhengshu_OutMsg
{
    bool b_chejiahao; //车架号
    bool b_yinzhang; //印章
};

struct Fadongjihao_OutMsg
{
    bool b_pic_quality;         //is picture quality good
    bool b_fadongjihao;         //if 'fadongjihao' correct
    cv::Mat m;                  //original image
    std::vector<cv::Rect> rt_fadongjihao; //location of 'fadongjihao'
    cv::Mat str_img;
};

struct Chayanyuan_OutMsg
{
    bool b_same; //is the same person
};

struct ShareDetect_Input
{
    int city_code;
    cv::Mat img;
    std::string label_name; //label名称
};

struct ShareDetect_OutMsg
{
    bool b_obj;           //if human exist

    cv::Mat img;              //image
    cv::Rect rect_obj;       //location of human
};

struct VehicelType_Input
{
    cv::Mat img1;
    cv::Mat img2;
};

struct VehicelType_OutMsg
{
    int result;   //1:通过 0：不通过 -1：未知
};

class LargeVehicleApi
{
public:
    LargeVehicleApi(bool b_use_gpu, int gpu_id, int city_code, EProjectType eprojecttype);
    ~LargeVehicleApi();

    //=================================nature image=================================//
    //process cheliang(front-left 45 degree, rear-right 45 degree for all 'cheliang')
    //车辆接口查验（前提EProjectType 为 eChayanType）需要传入的参数：1、cv::Mat &img,2、std::vector<cv::Mat> &vec_his_img, 3、std::string chepai_answner,4、std::string cheliang_type_answer, 5、std::string colors_answer, 6、ECheViewType echeViewtype, 7、Cheliang_ImgOutMsg &out_msg
    //车辆接口检验（前提EProjectType 为 eJianYanType）需要传入的参数：1、cv::Mat &img, 2、cv::Mat &his_img, 3、std::string chepai_answner, 4、std::string color_answer, 5、ECheViewType echeViewtype, 6、Cheliang_ImgOutMsg &out_msg
    bool cheliang_api_process(cv::Mat &img, cv::Mat &his_img, std::vector<cv::Mat> &vec_his_img, std::string chepai_answner, std::string cheliang_type_answer, std::string color_answer, ECheViewType echeViewtype, Cheliang_ImgOutMsg &out_msg);

    bool haopai_api_process(cv::Mat &img, std::string chepai_answner, Haopai_ImgOutMsg &out_msg);

    //process chejiahao == compare_type 0:chejia&chejia 1:chejia&tuomo 2: tuomo&chejia 3:tuomo&tuomo
    bool chejiaohao_api_process(cv::Mat &img, cv::Mat &his_img, std::string chejiahao_answner, std::string brand, Chejiahao_ImgOutMsg &out_msg, int compare_type=1);

    //process chejiahao_underglass
    bool chejiahao_underglass_api_process(cv::Mat &img, std::string cjh_answer, Chejiahao_underglass_OutMsg &out_msg);

    //b_date_vaild：true  答案与水印相差15天以内
    bool shuiyin_riqi_api_process(cv::Mat &img, std::string &ans_shuiyin_riqi, bool &b_date_vaild);

    //process anquandai
    bool anquandai_api_process(cv::Mat &img, Anquandai_ImgOutMsg &out_msg);

    //process zhidong       i_flg: 1(0322 0348)  2(0351) 3(0353)  zhou_label: 1是一轴; 2是二轴  car_kind: 1 is car; 2 is big_car; 3 is motor
    bool zhidong_api_process(cv::Mat &img, std::string chepai_answner, int i_flg,int zhou_label, int car_kind, Zhidong_ImgOutMsg &out_msg);

    //process dengguang
    bool light_api_process(cv::Mat &img, std::string chepai_answner, Light_ImgOutMsg &out_msg);

    //process dipan
    bool dipan_api_process(cv::Mat &img, std::string chepai_answner, Dipan_ImgOutMsg &out_msg);

    //process dipandongtai
    bool dipandongtai_api_process(cv::Mat &img1, cv::Mat &img2, std::string chepai_answner, Dipandongtai_ImgOutMsg &out_msg);

    //process weixianggaizhuang
    bool weixianggaizhuang_api_process(cv::Mat &img , std::string &chepai_answer, Weixianggaizhuang_ImgOutMsg &out_msg);

    //process fuzhuzhidong sign
    bool fuzhuzhidongsign_api_process(cv::Mat &img, FuzhuzhidongSign_ImgOutMsg &out_msg);

    //rongde
    bool rongqueshouli_api_process(cv::Mat &img, Rongqueshouli_ImgOutMsg &out_msg);

    //process abs sign
    bool abssign_api_process(cv::Mat &img, ABSSign_ImgOutMsg &out_msg);

    //process socket
    bool socket_api_process(cv::Mat &img, Socket_ImgOutMsg &out_msg);

    //发动机号比对
    bool fadongjihao_api_process(cv::Mat &img,std::string fdj_ans, Fadongjihao_OutMsg &out_msg);

    //通用目标检测
    bool sharedetect_api_process(ShareDetect_Input &input, ShareDetect_OutMsg &out_msg);

    //车辆型号比对
    bool vehicle_type_api_process(VehicelType_Input &input, VehicelType_OutMsg &out_msg);

    //=================================text image=================================//
    //process text xingshizheng
    bool xingshizheng_api_process(cv::Mat &img, std::string chepai_answner, std::string chejiahao_answner, std::string fazhengriqi_answer, std::string danganhao_answer, std::string tiaoxingma_answer,std::string chetype,std::string renshu, std::string qiangzhiriqi,std::string zhuceriqi,Xingshizheng_ImgOutMsg &out_msg);

    //process text xingshizheng_new
    bool xingshizheng_new_api_process(cv::Mat &img, XingshizhengNew_ImgOutMsg &out_msg);

    //process text baoxiandan
    bool baodan_api_process(cv::Mat &img, std::string chepai_answner, std::string chejiahao_answner,  std::string riqi_cur, std::string fadongjihao_answer, const int zaikerenshu, Baodan_ImgOutMsg &out_msg);

    //process shenfenzheng
    bool shenfenzheng_api_process(cv::Mat &img,Shenfenzheng_ImgOutMsg &out_msg,std::string &Xingming);

    //process text jianyanbaogao
    bool jianyanbaogao_api_process(cv::Mat &img, std::string chepai_answner, std::string chejiahao_answner, std::string jianyanriqi_answner,  Jianyanbaogao_ImgOutMsg &out_msg);

    //process text jianyanbaogao_yiqi
    bool jianyanbaogao_yiqi_api_process(cv::Mat &img, std::string chepai_answner, std::string chejiahao_answner, Jianyanbaogao_yiqi_ImgOutMsg &out_msg);

    bool jiludan_api_process(cv::Mat &img,Jiludan_ImgOutMsg &out_msg);

    bool gaozhishu_api_process(cv::Mat &img, Gaozhishu_ImgOutMsg &out_msg);

    //process text weituoshu
    bool weituoshu_api_process(cv::Mat &img, weituoshu_ImgOutMsg &out_msg);

    //process text shenqingbiao
    bool shenqingbiao_api_process(cv::Mat &img, std::string chepai_answner, std::string chejiahao_answner, std::string chepai_type, Shenqingdan_ImgOutMsg &out_msg);

    //process text jianyanbiao
    bool jianyanbiao_api_process(cv::Mat &img, std::string chepai_answer,std::string chejiahao_answer,std::string date_today,Jianyanbiao_ImgOutMsg &out_msg);

    //process text jianyanbiaoback
    bool jianyanbiaoback_api_process(cv::Mat &img, Jianyanbiaoback_ImgOutMsg &out_msg);

    //process text huanbaodan
    bool huanbaodan_api_process(cv::Mat &img,cv::Mat &img2, std::string chepai_answner, std::string chejiahao_answner,std::string riqi,std::vector<std::string> shijian,std::string today,std::string engine_num,std::string cheliangxinghao,Huanbaodan_ImgOutMsg &out_msg);

    bool waikuochicun_api_process(cv::Mat &img, std::string chepai_answner, std::string chejiahao_answner,Waikuochicun_ImgOutMsg &out_msg);

    //process text wanshuizhengming         Date format:: 20180706
    bool wanshuizhengming_api_process(cv::Mat &img, std::string chepai_ans, std::string chejiahao_ans, std::string riqi,Wanshuizhengming_ImgOutMsg &out_msg);

    //process text weituoshu
    bool weituotongzhishu_api_process(cv::Mat &img, std::string chepai_answner, std::string chejiahao_answner, Weituotongzhishu_ImgOutMsg &out_msg);

    //process text quxianbaogao
    bool quxianbaogao_api_process(cv::Mat &img, std::string chepai_answner, Quxianbaogao_ImgOutMsg &out_msg);

    //process text jianyanhege
    bool jianyanhege_api_process(cv::Mat &img, std::string chepai_answner, std::string chejiahao_answner, std::string riqi_cur, Jianyanhege_ImgOutMsg &out_msg);

    //Process test yingyezhizhao
    bool yingyezhizhao_api_process(cv::Mat &img, Yingyezhizhao_ImgOutMsg &out_msg);

    //Process test bolitouguanglv
    bool bolitouguanglv_api_process(cv::Mat &img, std::string chepai_answner, Bolitouguanglv_ImgOutMsg &out_msg);

    //Process test zhaotong_fangguangbiaoshi
    bool zhaotong_fanguangbiaoshi_api_process(cv::Mat &img, std::string chepai_answner, Zhaotong_fanguangbiaoshi_ImgOutMsg &out_msg);

    //===================================video====================================//
    //process cheliang video(front-left 45 degree, rear-right 45 degree)
    bool cheliang_video_api_process(std::string &video_path, std::string &chepai_answer, std::string &cllx, std::string &syxz, Cheliang_VideoOutMsg &out_msg);
    //proces light video(left-light, right-light)
    bool light_video_api_process(std::string &video_path, std::string chepai_answer, std::string &cllx, std::string &syxz, Light_VideoOutMsg &out_msg);

    //proces dipan video
    bool dipan_video_api_process(std::string &video_path, std::string &cllx, std::string &syxz, Dipan_VideoOutMsg &out_msg);

    //proces dipandongtai video
    bool dipandongtai_video_api_process(std::string &video_path, std::string &chepai_answer,std::string &cllx, std::string &syxz, Dipandongtai_VideoOutMsg &out_msg);

    //proces zhidong video
    bool zhidong_video_api_process(std::string &video_path, std::string chepai_answer,bool b_flg, bool b_zhou, std::string &cllx, std::string &syxz, Zhidong_VideoOutMsg &out_msg);//b_flag: true is 12zhou,false is zhuche; b_zhou:true is 1zhou, false is 2zhou

    //===================================large vehicle====================================//
    //yingjichui_api_process
    bool yingjichui_api_process(cv::Mat &img, Yingjichui_ImgOutMsg &out_msg);

    //miehuoqi_api_process
    bool miehuoqi_api_process(cv::Mat &img, Miehuoqi_ImgOutMsg &out_msg);

    //xingchejiluyi_api_process
    bool xingchejiluyi_api_process(cv::Mat &img, Xingchejiluyi_ImgOutMsg &out_msg);

    //luntaihuawen_api_process
    bool luntaihuawen_api_process(cv::Mat &img_1, cv::Mat &img_2, std::string &chepai_answer,Luntaihuawen_ImgOutMsg &out_msg);

    //luntaiguige_api_process
    bool luntaiguige_api_process(cv::Mat &img,  std::string xinghao_answer, Luntaiguige_ImgOutMsg &out_msg);

    //eHuocheViewtype:图像方向信息：左前，右后，正后，其他
    bool huoche_api_process(cv::Mat &img, std::string chepai_answer, ECheViewType eHuocheViewtype, Huoche_ImgOutMsg &out_msg,const int boardheight=0);

    //chemenpentu_api_process
    bool chemenpentu_api_process(cv::Mat &img, const std::string& total_mass_answer, const std::string& board_height_answer, const std::string& person_number_answer,int city_code,Chemenpentu_ImgOutMsg &out_msg);

    //huochexiang_api_process
    bool huochexiang_api_process(cv::Mat &img, std::string &vehicle_typecode,Huochexiang_ImgOutMsg &out_msg);

    //kechexiang_api_process
    bool kechexiang_api_process(const cv::Mat ori_img, const int seat_num, Kechexiang_ImgOutMsg &out_msg);

    //铭牌
    bool mingpai_api_process(Mingpai_Input &input_msg, Mingpai_OutMsg &out_msg);

    //人脸比对
    bool chayanyuan_api_process(cv::Mat &img1, cv::Mat &img2, Chayanyuan_OutMsg &out_msg);

    //专网文本表单类
    //机动车注册、转移、注销登记/转入申请表
    bool zhucesqb_api_process(ZhuceSQB_Input &input, ZhuceSQB_OutMsg &out_msg);

    //购车发票
    bool gouchefapiao_api_process(Gouchefapiao_Input &input, Gouchefapiao_OutMsg &out_msg);

    //环保信息随车清单
    bool suicheqingdan_api_process(Suicheqingdan_Input &input, Suicheqingdan_OutMsg &out_msg);

    //进口凭证
    bool jinkoupingzheng_api_process(Jinkoupingzheng_Input &input, Jinkoupingzheng_OutMsg &out_msg);

    //车船税或免税证明
    bool chechuanshui_api_process(Chechuanshui_Input &input, Chechuanshui_OutMsg &out_msg);

    //机动车所有权转移的证明、凭证
    bool suoyouquanzhuanyi_api_process(Suoyouquanzhuanyi_Input &input, Suoyouquanzhuanyi_OutMsg &out_msg);

    //机动车登记证书
    bool dengjizhengshu_api_process(Dengjizhengshu_Input &input, Dengjizhengshu_OutMsg &out_msg);

    //机动车号牌
    //bool haopai_api_process(Haopai_Input &input, Haopai_OutMsg &out_msg);

    //机动车变更登记/备案申请表
    bool biangengsqb_api_process(BiangengSQB_Input &input, BiangengSQB_OutMsg &out_msg);

    //机动车抵押登记/质押备案申请表
    bool diyasqb_api_process(DiyaSQB_Input &input, DiyaSQB_OutMsg &out_msg);

    //报废机动车回收证明
    bool huishouzhengming_api_process(Huishouzhengming_Input &input, Huishouzhengming_OutMsg &out_msg);

    //机动车灭失证明
    bool mieshizhengming_api_process(Mieshizhengming_Input &input, Mieshizhengming_OutMsg &out_msg);

    //出厂合格证
    bool chuchanghegezheng_api_process(Chuchanghegezheng_Input &input, Chuchanghegezheng_OutMsg &out_msg);

    //车辆一致性证书
    bool yizhixingzhengshu_api_process(Yizhixingzhengshu_Input &input, Yizhixingzhengshu_OutMsg &out_msg);

    //其他类
    //get algorithm version
    static bool algorithm_version(std::string &version);

    //chenge city_code
    void change_city_code(int city_code);

    void get_city_code();

private:
    void *m_Alg;
    int m_city_code;
    EProjectType e_projectType;
    std::map<std::string, std::map<std::string, std::vector<std::string>> > m_vin_map;  //厂商车架号映射表
    std::vector< std::vector<std::string> > m_changshang_map;                           //厂商名称映射表
    std::vector< std::vector<std::string> > m_pinpai_map;                               //品牌名称映射表
    std::vector< std::string> m_vehicle_type_map;                                       //车辆型号映射表
};
