#include <thread>
#include <system_error>
#include <vector>
#include <algorithm>

#include <event2/event.h>
#include <event2/http.h>
#include <event2/buffer.h>
#include <event2/keyvalq_struct.h>
#include <event2/http_struct.h>

#include "trace_log.h"
#include "Markup.h"
#include "http_res_def.h"
#include "MySQL_DB.h"
#include "AlgProcess/base/basetool.h"

extern std::string g_localServerIp;
extern std::string g_master_IP;
std::string URLEncode(const std::string &sIn);
std::string URLDecode(const std::string &sIn);

#define LISTEN_PORT 9001
#define TOKEN_TIME 3600

void HTTPServerListening_Thread();
void requestHandler(struct evhttp_request *req, void *arg);
std::string convertHTTPMethod(evhttp_cmd_type cmd_type);
void sendResponse(struct evhttp_request *req, unsigned int code);
void sendToken(struct evhttp_request *req, std::string token);
void MethodHandler_POST(struct evhttp_request *req);
int checkIDandMAC(std::string ID, std::string MAC);
void generateToken(int index);
void clearToken();
bool checkToken(std::string token);
bool insertDatabase(std::string data);

static const char *ErrorMessage[] = {
    "数据接收成功",
    "没有合法的XML结构",
    "token不正确或者已过期",
    "ID或者MAC不正确",
    "未定义的XML元素或属性",
    "当前保有的有效Token数量已达到最大值，无法产生新的Token",
    "数据格式或内容不合法"
};

struct Token {
    std::string value;
    std::chrono::steady_clock::time_point start;
};

struct InterfaceItem {
    std::string ID;
    std::vector<std::string> MAC;
    Token token;
};

static std::vector<InterfaceItem> InterfaceList;

void runThirdPartInterface()
{
    /* 读取接口列表 */
    CMarkup xml;
    std::string conf_name = "ThirdPartList.xml";
    if(baseTool::fileIsExist("/opt/vehicle/program/CheJianConfig/ThirdPartList.xml"))
    {
        conf_name = "/opt/vehicle/program/CheJianConfig/ThirdPartList.xml";
    }


    if (!xml.Load(conf_name.c_str())) {
        DATA_PRINT(LEVEL_ERROR, "ThirdPartInterface: Can not open ThirdPartList.xml! \n");
        return;
    }

    if (xml.FindElem("List")) {
        xml.IntoElem();

        while (xml.FindElem("Interface")) {
            InterfaceItem item;

            if (xml.FindChildElem("ID")) {
                item.ID = xml.GetChildData();
            }

            while (xml.FindChildElem("MAC")) {
                item.MAC.push_back(xml.GetChildData());
            }

            item.token.value.clear();
            InterfaceList.push_back(item);
        }
    }

    DATA_PRINT(LEVEL_INFO, "ThirdPartInterface: Interface list: \n");
    for (unsigned int i = 0; i < InterfaceList.size(); i++) {
        DATA_PRINT(LEVEL_INFO, "\tID: %s\n", InterfaceList[i].ID.c_str());

        for (unsigned int j = 0; j < InterfaceList[i].MAC.size(); j++) {
            DATA_PRINT(LEVEL_INFO, "\t\tMAC: %s\n", InterfaceList[i].MAC[j].c_str());
        }
    }

    std::thread *p_thread;

    try {
        (void)p_thread;
        p_thread = new std::thread(HTTPServerListening_Thread);
    } catch (const std::system_error& e) {
        DATA_PRINT(LEVEL_ERROR, "Create \"HTTPServerListening_Thread\" failure! \n");
        std::cout << "Error code: " << e.code() << ", reason: " << e.what() << std::endl;
    }
}

void HTTPServerListening_Thread()
{
    event_base *base = event_base_new();
    if (base == NULL) {
        DATA_PRINT(LEVEL_ERROR, "ThirdPartInterface: event_base_new() failed! \n");
        return;
    }

    evhttp *http_server = evhttp_new(base);

    /* 绑定端口和地址 */
    if (evhttp_bind_socket(http_server, g_localServerIp.c_str(), LISTEN_PORT) == -1) {
        DATA_PRINT(LEVEL_ERROR, "ThirdPartInterface: evhttp_bind_socket() failed! \n");
        return;
    }

    /* 绑定事件处理函数 */
    evhttp_set_gencb(http_server, requestHandler, NULL);

    /* 启动事件循环 */
    DATA_PRINT(LEVEL_INFO, "HTTP server(ThirdPartInterface) listening(%s:%d)...... \n", g_localServerIp.c_str(), LISTEN_PORT);
    event_base_dispatch(base);

    DATA_PRINT(LEVEL_ERROR, "HTTP server(ThirdPartInterface) thread is over! \n");
}

/* HTTP server 事件回调函数 */
void requestHandler(struct evhttp_request *req, void *arg)
{
    (void)arg;
    evhttp_cmd_type cmd_type = evhttp_request_get_command(req);
    const char *uri = evhttp_request_get_uri(req);

    DATA_PRINT(LEVEL_DEBUG, "HTTP server(ThirdPartInterface) received a request(Method:%s, URI:%s) \n",
               convertHTTPMethod(cmd_type).c_str(), uri);

    /* 验证URI */
    if (strcmp("/ThirdPartInterface.asmx", uri) != 0) {
        DATA_PRINT(LEVEL_ERROR, "ThirdPartInterface: The URI(%s) is undefined! \n", uri);
        return;
    }

    if (cmd_type == EVHTTP_REQ_POST) {
        MethodHandler_POST(req);
    } else {
        DATA_PRINT(LEVEL_ERROR, "ThirdPartInterface: The Method(%s) is undefined! \n", convertHTTPMethod(cmd_type).c_str());
    }
}

/* 将libevent中定义的evhttp_cmd_type类型转化为HTTP标准的请求方法 */
std::string convertHTTPMethod(evhttp_cmd_type cmd_type)
{
    std::string method;

    switch (cmd_type) {
        case EVHTTP_REQ_GET:     method = "GET";break;
        case EVHTTP_REQ_POST:    method = "POST"; break;
        case EVHTTP_REQ_HEAD:    method = "HEAD"; break;
        case EVHTTP_REQ_PUT:     method = "PUT"; break;
        case EVHTTP_REQ_DELETE:  method = "DELETE"; break;
        case EVHTTP_REQ_OPTIONS: method = "OPTIONS"; break;
        case EVHTTP_REQ_TRACE:   method = "TRACE"; break;
        case EVHTTP_REQ_CONNECT: method = "CONNECT"; break;
        case EVHTTP_REQ_PATCH:   method = "PATCH"; break;
        default:                 method = "";
    }

    return method;
}

void sendResponse(struct evhttp_request *req, unsigned int code)
{
    CMarkup xml;

    xml.SetDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>\r\n");
    xml.AddElem("response");
    xml.IntoElem();
    setlocale(LC_ALL, "chs");

    xml.AddElem("code");
    xml.SetData(code);
    xml.AddElem("message");
    xml.SetData(URLEncode(std::string(ErrorMessage[code])));

    xml.OutOfElem();
    std::string xmlString = xml.GetDoc();

    evbuffer *buf = evbuffer_new();
    if (buf == NULL) {
        DATA_PRINT(LEVEL_ERROR, "ThirdPartInterface: evbuffer_new() failed! \n");
    }

    evbuffer_add(buf, xmlString.c_str(), strlen(xmlString.c_str()));
    evhttp_add_header(req->output_headers, "Content-Type", HTTP_CONTENT_TYPE_URL_ENCODED);
    evhttp_send_reply(req, HTTP_OK, "OK", buf);

    evbuffer_free(buf);
}

void sendToken(struct evhttp_request *req, std::string token)
{
    CMarkup xml;
    xml.SetDoc("<?xml version=\"1.0\" encoding=\"utf-8\"?>\r\n");
    xml.AddElem("reply_token");
    xml.IntoElem();
    xml.AddElem("token");
    xml.SetData(token);
    xml.AddElem("valid_time");
    xml.SetData(std::to_string(TOKEN_TIME));

    xml.OutOfElem();
    std::string xmlString = xml.GetDoc();

    evbuffer *buf = evbuffer_new();
    if (buf == NULL) {
        DATA_PRINT(LEVEL_ERROR, "ThirdPartInterface: evbuffer_new() failed! \n");
    }

    evbuffer_add(buf, xmlString.c_str(), strlen(xmlString.c_str()));
    evhttp_add_header(req->output_headers, "Content-Type", HTTP_CONTENT_TYPE_URL_ENCODED);
    evhttp_send_reply(req, HTTP_OK, "OK", buf);

    evbuffer_free(buf);
}

void MethodHandler_POST(struct evhttp_request *req)
{
    struct evkeyvalq *headers;
    struct evkeyval *header;

    DATA_PRINT(LEVEL_DEBUG, "Headers: \n");
    headers = evhttp_request_get_input_headers(req);
    for (header = headers->tqh_first; header; header = header->next.tqe_next) {
        DATA_PRINT(LEVEL_DEBUG, "%s: %s\n", header->key, header->value);
    }

    struct evbuffer *buf = evhttp_request_get_input_buffer(req);

    size_t len = evbuffer_get_length(buf);
    char *data = (char *)malloc(len + 1);
    evbuffer_copyout(buf, data, len);
    *(data + len) = 0;

    std::string decodeData = URLDecode(std::string(data));
    free(data);

    CMarkup xml;

    xml.SetDoc(std::string(decodeData));

    if (!xml.FindElem()) {
        DATA_PRINT(LEVEL_ERROR, "ThirdPartInterface: Can not find XML element! \n");
        DATA_PRINT(LEVEL_ERROR, "ThirdPartInterface: data:\n%s\n", decodeData.c_str());

        sendResponse(req, 1);
        return;
    }

    xml.ResetPos();

    bool CompleteElement = true;    /* XML元素是否完整 */
    if (xml.FindElem("token")) {
        xml.IntoElem();
        std::string ID;
        std::string MAC;

        if (xml.FindElem("ID")) {
            ID = xml.GetData();
            DATA_PRINT(LEVEL_DEBUG, "ID: %s \n", ID.c_str());
        } else {
            CompleteElement = false;
        }

        if (xml.FindElem("MAC")) {
            MAC = xml.GetData();
            DATA_PRINT(LEVEL_DEBUG, "MAC: %s \n", MAC.c_str());
        } else {
            CompleteElement = false;
        }

        if (CompleteElement) {
            int index = checkIDandMAC(ID, MAC);
            if (index != -1) {
                generateToken(index);
                sendToken(req, InterfaceList[index].token.value);
            } else {
                sendResponse(req, 3);
                DATA_PRINT(LEVEL_ERROR, "ThirdPartInterface: This interface(ID=%s, MAC=%s) is not in the Interface list! \n", ID.c_str(), MAC.c_str());
            }
        } else {
            DATA_PRINT(LEVEL_ERROR, "ThirdPartInterface: XML element is not defined or the lack of certain elements! \n");
            DATA_PRINT(LEVEL_ERROR, "ThirdPartInterface: data:\n%s\n", decodeData.c_str());

            sendResponse(req, 4);
        }
    } else if (xml.FindElem("root")) {
        xml.IntoElem();

        if (xml.FindElem("token")) {
            std::string token = xml.GetData();

            if (!checkToken(token)) {
                DATA_PRINT(LEVEL_ERROR, "ThirdPartInterface: Token error:%s \n", token.c_str());
                sendResponse(req, 2);
                return;
            }
        } else {
            CompleteElement = false;
        }

        std::string clsbdh;

        if (xml.FindElem("body")) {
            std::string category = xml.GetAttrib("category");

            /* 这个属性用来区别数据类型。0:尾气数据，其他：待定。 */
            if (category == "0") {
                xml.IntoElem();

                if (xml.FindElem("data")) {
                    /* data的category属性被用来区别，同一种数据（比如尾气），不同地方的差异。
                     * 目前暂时没有使用。
                    */

                    xml.IntoElem();
                    std::vector<std::string> data;

                    if (xml.FindElem("hphm")) {
                        DATA_PRINT(LEVEL_DEBUG, "ThirdPartInterface: hphm=%s \n", xml.GetData().c_str());
                        data.push_back(xml.GetData());
                    }

                    if (xml.FindElem("clsbdh")) {
                        DATA_PRINT(LEVEL_DEBUG, "ThirdPartInterface: clsbdh=%s \n", xml.GetData().c_str());
                        data.push_back(clsbdh = xml.GetData());
                    }

                    if (xml.FindElem("jcrq")) {
                        DATA_PRINT(LEVEL_DEBUG, "ThirdPartInterface: jcrq=%s \n", xml.GetData().c_str());
                        data.push_back(xml.GetData());
                    }

                    if (xml.FindElem("jczmc")) {
                        DATA_PRINT(LEVEL_DEBUG, "ThirdPartInterface: jczmc=%s \n", xml.GetData().c_str());
                        data.push_back(xml.GetData());
                    }

                    if (xml.FindElem("jcbgbh")) {
                        DATA_PRINT(LEVEL_DEBUG, "ThirdPartInterface: jcbgbh=%s \n", xml.GetData().c_str());
                        data.push_back(xml.GetData());
                    }

                    if (xml.FindElem("pass")) {
                        DATA_PRINT(LEVEL_DEBUG, "ThirdPartInterface: pass=%s \n", xml.GetData().c_str());
                        data.push_back(xml.GetData());
                    }

                    std::string sqlData;
                    for (unsigned int i = 0; i < data.size(); i++) {
                        sqlData += "'" + data[i] + "'";

                        if (i < data.size() - 1) {
                            sqlData += ",";
                        }
                    }

                    if (!insertDatabase(sqlData)) {
                        DATA_PRINT(LEVEL_ERROR, "ThirdPartInterface: The data cannot be inserted into the database! \n");
                        DATA_PRINT(LEVEL_ERROR, "ThirdPartInterface: data:\n%s\n", xml.GetDoc().c_str());
                        sendResponse(req, 6);
                        return;
                    }
                }
            } else {
                CompleteElement = false;
            }
        } else {
            CompleteElement = false;
        }

        if (CompleteElement) {
            sendResponse(req, 0);
            DATA_PRINT(LEVEL_INFO, "ThirdPartInterface: A vehicle information(clsbdh:%s) about \'dz_wq\' has been recorded. \n", clsbdh.c_str());
        } else {
            DATA_PRINT(LEVEL_ERROR, "ThirdPartInterface: XML element is not defined or the lack of certain elements! \n");
            DATA_PRINT(LEVEL_ERROR, "ThirdPartInterface: data:\n%s\n", decodeData.c_str());

            sendResponse(req, 4);
        }
    } else {
        DATA_PRINT(LEVEL_ERROR, "ThirdPartInterface: XML element is not defined or the lack of certain elements! \n");
        DATA_PRINT(LEVEL_ERROR, "ThirdPartInterface: data:\n%s\n", decodeData.c_str());

        sendResponse(req, 4);
    }
}

int checkIDandMAC(std::string ID, std::string MAC)
{
    int find = -1;

    /* 将原始的MAC进行转换，-转换: */
    while (true) {
        std::string::size_type pos(0);

        if ((pos = MAC.find("-")) != std::string::npos) {
            MAC.replace(pos, 1, ":");
        } else {
            break;
        }
    }

    /* 所有小写字母转换成大写字母 */
    transform(MAC.begin(), MAC.end(), MAC.begin(), ::toupper);

    for (unsigned int i = 0; i < InterfaceList.size(); i++) {
        if (ID == InterfaceList[i].ID) {
            for (unsigned int j = 0; j < InterfaceList[i].MAC.size(); j++) {
                if (MAC == InterfaceList[i].MAC[j]) {
                    find = i;
                    break;
                }
            }
        }
    }

    return find;
}

void generateToken(int index)
{
    clearToken();

    if (InterfaceList[index].token.value.empty()) {
        char token_array[9] = {0};

        std::srand(std::time(nullptr)); /* 以当前时间为随机生成器的种子 */
        for (unsigned int i = 0; i < 8; i++) {
            token_array[i] = 'A' + std::rand() % 26;
        }

        InterfaceList[index].token.value = std::string(token_array);
        InterfaceList[index].token.start = std::chrono::steady_clock::now();

        DATA_PRINT(LEVEL_DEBUG, "generateToken: %s \n", InterfaceList[index].token.value.c_str());
    }
}

/* 将超时的Token从列表中移除 */
void clearToken()
{
    for (unsigned int i = 0; i < InterfaceList.size(); i++) {
        if (!InterfaceList[i].token.value.empty()) {
            auto interval = std::chrono::duration_cast<std::chrono::seconds>(std::chrono::steady_clock::now() - InterfaceList[i].token.start);

            if (interval.count() > TOKEN_TIME) {
                InterfaceList[i].token.value.clear();
            }
        }
    }
}

bool checkToken(std::string token)
{
    clearToken();

    for (unsigned int i = 0; i < InterfaceList.size(); i++) {
        if (InterfaceList[i].token.value == token) {
            return true;
        }
    }

    return false;
}

bool insertDatabase(std::string data)
{
    MySQL_DB db;
    bool result = true;

    DATA_PRINT(LEVEL_INFO, "ThirdPartInterface: Insert data into the database...... \n");

    if (db.connect(g_master_IP.c_str(), 6033, "root", getDBPassWord(DBPWD).c_str(), "car_schema")) {
        std::string sqlString;

        sqlString = "("
                    "hphm, clsbdh, jcrq, jczmc, jcbgbh, pass"
                    ")"
                    " VALUES "
                    "(";

        sqlString += data;
        sqlString += ")";

        DATA_PRINT(LEVEL_DEBUG, "Insert into dz_wq, data: %s \n", sqlString.c_str());

        result = db.insert("dz_wq", sqlString.c_str());
    } else {
        result = false;
    }

    db.disconnect();

    return result;
}
