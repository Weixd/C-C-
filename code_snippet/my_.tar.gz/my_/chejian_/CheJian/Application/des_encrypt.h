#include <string>
#include <string.h>
#include <vector>

#ifndef DES_ENCRYPT_H
#define DES_ENCRYPT_H

std::string des_encrypt(const std::string &clearText, const std::string &key);



#endif
