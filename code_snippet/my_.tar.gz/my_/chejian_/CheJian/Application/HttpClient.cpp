//#include "afx.h"
#include "HttpClient.h"
#include "http_res_def.h"
#include <ctime>
//#include <io.h>
#include "Markup.h"
#include <string.h>
//#include <shlwapi.h>
//#pragma comment(lib, "shlwapi.lib")

extern std::string g_requestUri;
extern std::string g_localServerPort;
std::string g_photoUri = DOWNLOAD_PHOTO_DATA_TXT;
std::string g_photoFilePath = LOCAL_PHOTOFILE_PATH;
std::string g_videoFilePath = LOCAL_VIDEOFILE_PATH;
extern std::string g_demo_path;
extern string IP;
extern std::string g_dzjqxbdUri;
extern std::string g_jqxbd_result;
extern std::string g_request_reply_result;
extern std::string g_request_get_checkitem;
extern std::string g_request_get_env_insurance;
extern std::string g_request_get_ins_insurance;
extern std::string g_request_get_vin;
extern std::string g_request_get_pic;
void http_requset_post_cb(struct evhttp_request *req, void *arg);
void http_requset_get_cb(struct evhttp_request *req, void *arg);
void http_requset_get_bdpic_cb(struct evhttp_request *req, void *arg);
//void http_requset_get_bdpic_cbwyd();
extern std::string UTF8toANSI(char *strUTF8);
extern std::string ANSItoUTF8(char* strAnsi);
std::string URLDecode(const std::string &sIn);
// 写文件
std::string fun_write_new_file(std::string, std::string, std::string);
// B64 decode
//std::string b64Decode(const char* Data, int DataByte);
HttpClient::HttpClient()
{
	base = event_base_new();
	m_request_text_type = 0;
	m_uri = NULL;
	m_post_data = NULL;
	m_connection = NULL;
    m_soap_action = NULL;
	m_request_flag = REQUEST_GET_FLAG;
    m_content_type = NULL;
    m_retries = 5;
    m_timeout = 15;
}

bool HttpClient::init_data(const char *uri, int request_flag, char* content_type, char *data, char *soap_action)
{
    m_uri = evhttp_uri_parse(uri);
    if (!m_uri) {
        DATA_PRINT(LEVEL_INFO, "URI has unsafe code! %s\n"," ");
        return false;
    }

    m_request_flag = request_flag;
    if (m_request_flag == REQUEST_POST_FLAG)
    {
        if (content_type == NULL)
        {
            m_content_type = strdup(HTTP_CONTENT_TYPE_URL_ENCODED);
        }
        else
        {
            m_content_type = strdup(content_type);
        }

        if (data == NULL)
        {
            m_post_data = NULL;
        }
        else
        {
            m_post_data = strdup(data);
        }
        if(soap_action == NULL)
        {
            m_soap_action = NULL;
        }
        else
        {
           m_soap_action = strdup(soap_action);
        }
        return true;
    }
}

BOOL HttpClient::InitData(const char *uri, int request_flag, char* content_type, char *data)
{
	if (strstr(uri, g_requestUri.c_str()) != NULL)
	{
		m_request_text_type = VHHICLE_ANALYSE_QUEST_RESULT;
	}
    else if ( strstr(uri, g_photoUri.c_str()) != NULL || strstr(uri, "DzdaOutNewAccess") != nullptr)
	{
		m_request_text_type = DOWNLOAD_PHOTO_DATA;
    }
    else if (strstr(uri, g_dzjqxbdUri.c_str()) != NULL)
    {
        DATA_PRINT(LEVEL_DEBUG, "DZBD URI init KO\n");
        m_request_text_type = VHHICLE_ANALYSE_QUEST_RESULT;
    }
    else if(strstr(uri,g_request_get_checkitem.c_str()) != NULL)
    {
        m_request_text_type = GETCHECKITEM;
    }
    else if (strstr(uri, g_request_get_env_insurance.c_str()) != NULL) {
        m_request_text_type = GETENVINSURANCE;
    }
    else if (strstr(uri, g_request_get_ins_insurance.c_str()) != NULL) {
        m_request_text_type = GETINSINSURANCE;
    } else if (strstr(uri, "rminf") != NULL) {
        m_request_text_type = GETVEHICLELICENSE;
    }
    else if(strstr(uri,g_request_reply_result.c_str()) != nullptr)
    {
        m_request_text_type = REPLYP_MASTER_RESULT;
    }
    else if(strstr(uri, g_request_get_vin.c_str()) != nullptr)
    {
        m_request_text_type = GET_VIN;
    }
    else if(strstr(uri, "Video") != nullptr)
    {
        DATA_PRINT(LEVEL_INFO, "m_request_text_type = GETBINZHOUVIDEO \n");
        m_request_text_type = GETBINZHOUVIDEO;
    }
    else {
//        m_request_text_type = DOWNLOAD_PHOTO_DATA;
        DATA_PRINT(LEVEL_INFO, "Unauthentic URI be refused! %s\n"," ");
        return FALSE;
	}

	m_uri = evhttp_uri_parse(uri);
    if (!m_uri) {
        DATA_PRINT(LEVEL_INFO, "URI has unsafe code! %s\n"," ");
		return FALSE;
	}

	m_request_flag = request_flag;
	if (m_request_flag == REQUEST_POST_FLAG) {
		if (content_type == NULL) {
            m_content_type = strdup(HTTP_CONTENT_TYPE_URL_ENCODED);
		}else
            m_content_type = strdup(content_type);

		if (data == NULL) {
			m_post_data = NULL;
		}
		else 
            m_post_data = strdup(data);
	}
	if (m_request_flag == REQUEST_SOAP_FLAG) {
		if (content_type == NULL) {
            m_content_type = strdup(HTTP_CONTENT_TYPE_URL_ENCODED);
		} else
            m_content_type = strdup(content_type);

		if (data == NULL) {
			m_post_data = NULL;
		} else
            m_post_data = strdup(data);
	}
    if (m_request_flag == REQUEST_GET_FLAG)
    {
        if(content_type == NULL)
        {
            m_content_type = strdup(HTTP_CONTENT_TYPE_URL_ENCODED);
        }
        else
        {
            m_content_type = strdup(content_type);
        }
    }

	return TRUE;
}

HttpClient::~HttpClient()
{
	if (m_request_flag == REQUEST_POST_FLAG) {
		if (m_content_type) {
			free(m_content_type);
			m_content_type = NULL;
		}
		if (m_post_data) {
			free(m_post_data);
			m_post_data = NULL;
		}
        if(m_soap_action) {
            free(m_soap_action);
            m_soap_action = NULL;
        }
	}
    if (m_request_flag == REQUEST_SOAP_FLAG) {
        if (m_content_type) {
            free(m_content_type);
            m_content_type = NULL;
        }
        if (m_post_data) {
            free(m_post_data);
            m_post_data = NULL;
        }
    }
    if (m_request_flag == REQUEST_GET_FLAG)
    {
        if (m_content_type) {
            free(m_content_type);
            m_content_type = NULL;
        }

    }
	event_base_free(base);
}

/************************** Request Function ******************************/
void http_requset_post_cb(struct evhttp_request *req, void *arg)
{
    DATA_PRINT(LEVEL_DEBUG, "<-----http_requset_post_cb is in  - \n");
	HttpClient *httpclientpost = (HttpClient *)arg;
	if (req == NULL)
	{
        DATA_PRINT(LEVEL_ERROR, "HTTP client[POST]: no response! \n");
        DATA_PRINT(LEVEL_ERROR, "URL: %s:%d%s \n",
                   evhttp_uri_get_host(httpclientpost->m_uri),
                   evhttp_uri_get_port(httpclientpost->m_uri),
                   evhttp_uri_get_path(httpclientpost->m_uri));

		httpclientpost->d_success_flag = false;
		event_base_loopexit(httpclientpost->base, 0);
		return;
	}

	//DATA_PRINT(LEVEL_DEBUG, "<-----Client:");
	//DATA_PRINT(LEVEL_DEBUG, "Received a %d request for %s\n",
	//evhttp_request_get_command(req), evhttp_request_get_uri(req));

	httpclientpost->d_success_flag = true;
	struct evbuffer* buf = evhttp_request_get_input_buffer(req);
	UINT len = (UINT)evbuffer_get_length(buf);
	if (len > 0)
	{
		char *data = (char*)malloc(len + 1);
        if(evbuffer_copyout(buf, data, len) != -1)
        {
            *(data + len) = 0;
        }
        else
        DATA_PRINT(LEVEL_DEBUG, "event_copyout = -1 !!!!");
		//..................................
		//DATA_PRINT(LEVEL_ALL, "%s\n", UTF8toANSI(data).GetString());
		if (strstr(evhttp_request_get_uri(req), "InsurService.asmx") != NULL)
		{
            g_jqxbd_result.assign(data);
            DATA_PRINT(LEVEL_DEBUG, "token assign ok !!!!");
		}	
		free(data);
	}

	switch (req->response_code)
	{
    case HTTP_OK:
    {
        /*struct evbuffer* buf = evhttp_request_get_input_buffer(req);
        headers = evhttp_request_get_input_headers(req);
        for (header = headers->tqh_first; header;
            header = header->next.tqe_next) {
            DATA_PRINT(LEVEL_DATA, "  %s: %s\n", header->key, header->value);
        }*/
        //DATA_PRINT(LEVEL_DEBUG, "200 OK\n");

        if (len > 0) {
            char *data = (char *)malloc(len + 1);
            evbuffer_copyout(buf, data, len);
            *(data + len) = 0;
            httpclientpost->ResponseData = data;
            free(data);
        }

        event_base_loopexit(httpclientpost->base, 0);
        break;
    }
    case HTTP_MOVEPERM:
        DATA_PRINT(LEVEL_ERROR, "<-----Client:");
        DATA_PRINT(LEVEL_ERROR, "%s\n", "the uri moved permanently");
        break;
    case HTTP_MOVETEMP:
    {
        const char *new_location = evhttp_find_header(req->input_headers, "Location");
        struct evhttp_uri *new_uri = evhttp_uri_parse(new_location);
        evhttp_uri_free(httpclientpost->m_uri);
        httpclientpost->m_uri = new_uri;
        httpclientpost->start_url_request();
        return;
    }
    default:
        DATA_PRINT(LEVEL_ERROR, "HTTP client[POST]: abnormal response! \n");
        DATA_PRINT(LEVEL_ERROR, "HTTP code: %d, Message:%s \n", req->response_code, req->response_code_line);
        DATA_PRINT(LEVEL_ERROR, "URL: %s:%d%s \n",
                   evhttp_uri_get_host(httpclientpost->m_uri),
                   evhttp_uri_get_port(httpclientpost->m_uri),
                   evhttp_uri_get_path(httpclientpost->m_uri));

        event_base_loopexit(httpclientpost->base, 0);
        return;
	}
}

void http_requset_get_cb(struct evhttp_request *req, void *arg)
{
	HttpClient *httpclientget = (HttpClient *)arg;
//	struct evkeyvalq *headers;
//	struct evkeyval *header;

    if (req == NULL) {
        DATA_PRINT(LEVEL_ERROR, "HTTP client[GET]: no response! \n");
        DATA_PRINT(LEVEL_ERROR, "URL: %s:%d%s \n",
                   evhttp_uri_get_host(httpclientget->m_uri),
                   evhttp_uri_get_port(httpclientget->m_uri),
                   evhttp_uri_get_path(httpclientget->m_uri));

        httpclientget->m_photo_filename = "TBD";
		event_base_loopexit(httpclientget->base, 0);
		return;
	}

	switch (req->response_code)
	{
	case HTTP_OK:
	{
		struct evbuffer* buf = evhttp_request_get_input_buffer(req);
		//DATA_PRINT(LEVEL_DEBUG, "<-----Client:");
		//DATA_PRINT(LEVEL_DATA, "Received a %d request for %s\nHeaders:\n",
		//	evhttp_request_get_command(req), evhttp_request_get_uri(req));

//		headers = evhttp_request_get_input_headers(req);
//		for (header = headers->tqh_first; header;
//			header = header->next.tqe_next) {
//			//DATA_PRINT(LEVEL_ALL, "  %s: %s\n", header->key, header->value);
//		}

		UINT len = (UINT)evbuffer_get_length(buf);
        unsigned char *data = (unsigned char *)malloc(len + 1);
		evbuffer_copyout(buf, data, len);
		*(data + len) = 0;
        if(httpclientget->m_request_text_type== DOWNLOAD_PHOTO_DATA)
        {
            httpclientget->Save_PhotoData_To_LocalFile(data, len);
        }
        else if(httpclientget->m_request_text_type == GETBINZHOUVIDEO )
        {
            DATA_PRINT(LEVEL_INFO, " httpclientget->m_request_text_type == GETBINZHOUVIDEO\n");
            httpclientget->Save_VideoData_To_LocalFile(data, len);
        }
        else if(httpclientget->m_request_text_type == GETCHECKITEM )
        {
            httpclientget->SaveHostCheckItemXML(data,len);
        }
		free(data);

		event_base_loopexit(httpclientget->base, 0);
		break;
	}
	case HTTP_MOVEPERM:
        DATA_PRINT(LEVEL_ERROR, "<-----Client:");
        DATA_PRINT(LEVEL_ERROR, "%s\n", "the uri moved permanently");
        httpclientget->m_photo_filename = "TBD";
		event_base_loopexit(httpclientget->base, 0);
		break;
	case HTTP_MOVETEMP:
	{
		const char *new_location = evhttp_find_header(req->input_headers, "Location");
		struct evhttp_uri *new_uri = evhttp_uri_parse(new_location);
		evhttp_uri_free(httpclientget->m_uri);
		httpclientget->m_uri = new_uri;
		httpclientget->start_url_request();
		return;
	}
	default:

        DATA_PRINT(LEVEL_ERROR, "HTTP client[GET]: abnormal response! \n");
        DATA_PRINT(LEVEL_ERROR, "HTTP code: %d, Message:%s \n", req->response_code, req->response_code_line);
        DATA_PRINT(LEVEL_ERROR, "URL: %s:%d%s \n",
                   evhttp_uri_get_host(httpclientget->m_uri),
                   evhttp_uri_get_port(httpclientget->m_uri),
                   evhttp_uri_get_path(httpclientget->m_uri));

        httpclientget->m_photo_filename = "TBD";
		event_base_loopexit(httpclientget->base, 0);
		return;
	}
}

void http_requset_get_bdpic_cb(struct evhttp_request *req, void *arg)
{
    DATA_PRINT(LEVEL_DEBUG, "<-----http_requset_get_bdpic_cb is in  - \n");
    HttpClient *httpclientgetpic = (HttpClient *)arg;

    if (req == NULL) {
        DATA_PRINT(LEVEL_ERROR, "HTTP client[GET]: no response! \n");
        DATA_PRINT(LEVEL_ERROR, "URL: %s:%d%s \n",
                   evhttp_uri_get_host(httpclientgetpic->m_uri),
                   evhttp_uri_get_port(httpclientgetpic->m_uri),
                   evhttp_uri_get_path(httpclientgetpic->m_uri));
        httpclientgetpic->d_success_flag = false;
        httpclientgetpic->m_photo_filename = "TBD";
        event_base_loopexit(httpclientgetpic->base, 0);
        return;
    }

    switch (req->response_code)
    {
    case HTTP_OK:
    {
        struct evbuffer* buf = evhttp_request_get_input_buffer(req);

        UINT len = (UINT)evbuffer_get_length(buf);
        char *data = (char *)malloc(len + 1);
        evbuffer_copyout(buf, data, len);
        *(data + len) = 0;
        std::string strurl = URLDecode(data);
        std::string getstrurl="";
        httpclientgetpic->parsexmldata(strurl,getstrurl);
        if(0!=getstrurl.size())
        {
            if(httpclientgetpic->getparsexmldata(getstrurl))
                httpclientgetpic->d_success_flag = true;
            else
                DATA_PRINT(LEVEL_INFO, "文件写入失败 \n");
        }
        free(data);

        event_base_loopexit(httpclientgetpic->base, 0);
        break;
    }
    case HTTP_MOVEPERM:
        DATA_PRINT(LEVEL_ERROR, "<-----Client:");
        DATA_PRINT(LEVEL_ERROR, "%s\n", "the uri moved permanently");
        httpclientgetpic->m_photo_filename = "TBD";
        event_base_loopexit(httpclientgetpic->base, 0);
        break;
    case HTTP_MOVETEMP:
    {
        const char *new_location = evhttp_find_header(req->input_headers, "Location");
        struct evhttp_uri *new_uri = evhttp_uri_parse(new_location);
        evhttp_uri_free(httpclientgetpic->m_uri);
        httpclientgetpic->m_uri = new_uri;
        httpclientgetpic->start_url_request();
        return;
    }
    default:

        DATA_PRINT(LEVEL_ERROR, "HTTP client[GET]: abnormal response! \n");
        DATA_PRINT(LEVEL_ERROR, "HTTP code: %d, Message:%s \n", req->response_code, req->response_code_line);
        DATA_PRINT(LEVEL_ERROR, "URL: %s:%d%s \n",
                   evhttp_uri_get_host(httpclientgetpic->m_uri),
                   evhttp_uri_get_port(httpclientgetpic->m_uri),
                   evhttp_uri_get_path(httpclientgetpic->m_uri));

        httpclientgetpic->m_photo_filename = "TBD";
        event_base_loopexit(httpclientgetpic->base, 0);
        return;
    }
}
void HttpClient::parsexmldata(std::string &src,std::string &dst)
{
    CMarkup xml;
    xml.SetDoc(src);
    xml.ResetMainPos();
    bool gets_or_f=false;
    std::string str_childcode="";
    if (xml.FindChildElem("soapenv:Body")) {
        xml.IntoElem();
        if (xml.FindChildElem("ns1:queryimagebyclsbdhResponse")) {// 车辆基本信息流水号
            xml.IntoElem();
            if (xml.FindChildElem("queryimagebyclsbdhReturn")) {// 车辆基本信息流水号
                //                    xml.IntoElem();
                str_childcode= xml.GetChildData();
                gets_or_f=true;
                while (true) {
                    std::string::size_type pos(0);

                    if ((pos = str_childcode.find("&lt;")) != std::string::npos) {
                        str_childcode.replace(pos, 4, "<");
                    } else {
                        break;
                    }
                }

                while (true) {
                    std::string::size_type pos(0);

                    if ((pos = str_childcode.find("&gt;")) != std::string::npos) {
                        str_childcode.replace(pos, 4, ">");
                    } else {
                        break;
                    }
                }
                while (true) {
                    std::string::size_type pos(0);

                    if ((pos = str_childcode.find("&quot;")) != std::string::npos) {
                        str_childcode.replace(pos, 6, "\"");
                    } else {
                        break;
                    }
                }
            }
        }
    }
    dst=str_childcode;
}
bool HttpClient::getparsexmldata(std::string &src)
{
    CMarkup xmlson;
    xmlson.SetDoc(src);
    xmlson.ResetMainPos();
    if (xmlson.FindElem("root")){
        xmlson.IntoElem();
        if (xmlson.FindElem("head")) {// 车辆基本信息流水号
            xmlson.IntoElem();
            if (xmlson.FindElem("code")) {// 车辆基本信息流水号
                std::string code= xmlson.GetData();

                //child
                if("1"!=code)
                {
                    return false;
                }
                xmlson.ResetPos();
                if (xmlson.FindElem("root")){
                    xmlson.IntoElem();
                    if (xmlson.FindElem("body")){
                        xmlson.IntoElem();
                        if (xmlson.FindElem("vehimage")) {// 车辆基本信息流水号
                            xmlson.IntoElem();
                            if (xmlson.FindElem("image")) {// 车辆基本信息流水号
                                //                    xml.IntoElem();
                                std::string code= xmlson.GetData();
                                std::string zp_binary(Decode((const unsigned char *)code.c_str(), code.size()));
                                DATA_PRINT(LEVEL_INFO, "照片decode完成\n");
                                std::string zplj = fun_write_new_file(m_photo_filepath,filename, zp_binary);
                                m_photo_filename =zplj;
                                DATA_PRINT(LEVEL_INFO, "文件写入成功 照片路径:[%s] \n", zplj.c_str());
                                return true;
                            }


                        }

                    }

                }

            }

        }
    }
    return false;

}
bool HttpClient::isValidData(const unsigned char *Data, unsigned int DataByte)
{
    for (unsigned int i = 0; i < DataByte; i++) {
        if ((Data[i] >= 'A') && (Data[i] <= 'Z')) {
            continue;
        } else if ((Data[i] >= 'a') && (Data[i] <= 'z')) {
            continue;
        } else if ((Data[i] >= '0') && (Data[i] <= '9')) {
            continue;
        } else if ((Data[i] == '+') || (Data[i] == '/')) {
            continue;
        } else if ((Data[i] == '\r') || (Data[i] == '\n')) {
            continue;
        } else if (Data[i] == '=') {
            continue;
        } else {
            DATA_PRINT(LEVEL_ERROR, "Base64: Find invalid character: %d \n", Data[i]);
            return false;
        }
    }

    return true;
}

std::string HttpClient::Decode(const unsigned char *Data, unsigned int DataByte)
{
    if (!isValidData(Data, DataByte)) {
        return "";
    }

    //解码表
    const char DecodeTable[] =
    {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        62, // '+'
        0, 0, 0,
        63, // '/'
        52, 53, 54, 55, 56, 57, 58, 59, 60, 61, // '0'-'9'
        0, 0, 0, 0, 0, 0, 0,
        0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12,
        13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, // 'A'-'Z'
        0, 0, 0, 0, 0, 0,
        26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38,
        39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, // 'a'-'z'
    };
    //返回值
    string strDecode;
    int nValue;
    unsigned int i = 0;
    while (i < DataByte) {
        if (*Data != '\r' && *Data != '\n') {
            nValue = DecodeTable[*Data++] << 18;
            nValue += DecodeTable[*Data++] << 12;
            strDecode += (nValue & 0x00FF0000) >> 16;

            if (*Data != '=') {
                nValue += DecodeTable[*Data++] << 6;
                strDecode += (nValue & 0x0000FF00) >> 8;

                if (*Data != '=') {
                    nValue += DecodeTable[*Data++];
                    strDecode += nValue & 0x000000FF;
                }
            }
            i += 4;
        } else// 回车换行,跳过
        {
            Data++;
            i++;
        }
    }
    return strDecode;


}
bool HttpClient::start_bdurl_request()
{

    if (m_request_text_type == DOWNLOAD_PHOTO_DATA)
    {

//        this->m_photo_filepath = g_photoFilePath;
        this->m_photo_filepath = "/opt/vehicle/vehicle_photo/";
    }

    if (m_connection)
        evhttp_connection_free(m_connection);

    int port = evhttp_uri_get_port(m_uri);
    if (port == -1) port = atoi(g_localServerPort.c_str()) + 1;

    m_connection = evhttp_connection_base_new(base, NULL, evhttp_uri_get_host(m_uri), port);
    evhttp_connection_set_retries(m_connection, m_retries);
    evhttp_connection_set_timeout(m_connection, m_timeout);
    if (m_request_flag != REQUEST_POST_FLAG) {
        DATA_PRINT(LEVEL_ERROR, "接口调用错误");
        return false;
    }
    m_httpreq = evhttp_request_new(http_requset_get_bdpic_cb, this);

    /** Set the header properties */
    evhttp_add_header(m_httpreq->output_headers, "Host", evhttp_uri_get_host(m_uri));
    const char* query = evhttp_uri_get_query(m_uri);
    const char* path = evhttp_uri_get_path(m_uri);
    string path_query;
    if (path)
        path_query = path;
    if (query)
    {
        path_query += "?";
        path_query += query;
    }
    /** Set the post data */
    if (m_post_data)
        evbuffer_add(m_httpreq->output_buffer, ANSItoUTF8(m_post_data).c_str(), strlen(ANSItoUTF8(m_post_data).c_str()));
    evhttp_add_header(m_httpreq->output_headers, "Content-Type", m_content_type);
    char num[10];
    itoa((UINT)strlen(ANSItoUTF8(m_post_data).c_str()), num, 10);
    evhttp_add_header(m_httpreq->output_headers, "Length", num);

    evhttp_make_request(m_connection, m_httpreq, EVHTTP_REQ_POST,(path_query.length()>1) ? path_query.data() : "/");
    return true;
}
/************************** Start POST/GET Function ******************************/
/**
* @param content_type: refer HTTP_CONTENT_TYPE_*
*/

int HttpClient::start_url_request()
{
	struct evkeyvalq params;

//    DATA_PRINT(LEVEL_DEBUG, "----->Client[%s]:", (m_request_text_type == DOWNLOAD_PHOTO_DATA)? "Get":"Post");
//    DATA_PRINT(LEVEL_DEBUG, " [scheme:%s]\n", evhttp_uri_get_scheme(m_uri));
//    DATA_PRINT(LEVEL_DEBUG, " [host:%s]\n", evhttp_uri_get_host(m_uri));
//    DATA_PRINT(LEVEL_DEBUG, " [path:%s]\n", evhttp_uri_get_path(m_uri));
//    DATA_PRINT(LEVEL_DEBUG, " [port:%d]\n", evhttp_uri_get_port(m_uri));
//    DATA_PRINT(LEVEL_DEBUG, " [query:%s]\n", evhttp_uri_get_query(m_uri));
//    DATA_PRINT(LEVEL_DEBUG, " [userinfo:%s]\n", evhttp_uri_get_userinfo(m_uri));
//    DATA_PRINT(LEVEL_DEBUG, " [fragment:%s]\n", evhttp_uri_get_fragment(m_uri));
	
	if (m_request_text_type == DOWNLOAD_PHOTO_DATA)
    {
		evhttp_parse_query_str(evhttp_uri_get_query(m_uri), &params);
        //const char *faction = evhttp_find_header(&params, "ction");
        evhttp_find_header(&params, "ction");
		const char *fid = evhttp_find_header(&params, "id");
        //DATA_PRINT(LEVEL_DATA, "[解析: ction=%s ", faction);
		//DATA_PRINT(LEVEL_DATA, "id=%s \n", fid);
		if (fid != NULL)
            m_photo_fileid = std::string(fid);

        m_photo_filename = g_photoFilePath;

		std::time_t t = std::time(NULL);
		std::tm *st = std::localtime(&t);
		char tmpArray[128] = { 0 };
		sprintf(tmpArray, "%d-%02d-%02d", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);
        std::string strCurTime = tmpArray;

		m_photo_filename += strCurTime;

        struct stat st_buf;
        memset(&st_buf,0,sizeof(st_buf));
        stat(m_photo_filename.c_str(), &st_buf);
        if ((st_buf.st_mode & S_IFMT) != S_IFDIR) {
            mkdir(m_photo_filename.c_str(), 0777);
        }

        m_photo_filename += "/";
        m_photo_filename += m_photo_fileid;
		evhttp_clear_headers(&params);

#ifdef DEMO_TEST
		string demo_path = (char *)evhttp_uri_get_path(m_uri);
		if (demo_path.length() >= strlen(g_photoUri.c_str()))
		{
			//std::string demofilename;
            m_demo_filename = g_demo_path;

#ifdef CHE_JIAN_LINUX
            struct stat st_buf = {0};
            stat(m_demo_filename.c_str(), &st_buf);
            if ((st_buf.st_mode & S_IFMT) != S_IFDIR) {
                mkdir(m_demo_filename.c_str(), 0777);
            }
#else
			if (!PathIsDirectory(m_demo_filename.c_str()))
				CreateDirectory(m_demo_filename.c_str(), NULL);
#endif

			m_demo_filename += strCurTime;

#ifdef CHE_JIAN_LINUX
            struct stat st_buf2 = {0};
            stat(m_demo_filename.c_str(), &st_buf2);
            if ((st_buf2.st_mode & S_IFMT) != S_IFDIR) {
                mkdir(m_demo_filename.c_str(), 0777);
            }
#else
			if (!PathIsDirectory(m_demo_filename.c_str()))
				CreateDirectory(m_demo_filename.c_str(), NULL);
#endif

#ifdef CHE_JIAN_LINUX
            m_demo_filename += "/";
#else
			m_demo_filename += L"\\\\";
#endif
			/*if (m_photo_fileid == L"unknown")
				demofilename = (demo_path.substr(demo_path.find(g_photoUri) + strlen(g_photoUri.c_str()))).c_str();
			else
				demofilename = fid;*/
			m_demo_filename += m_photo_fileid;
		}
        else m_demo_filename = "TBD";
#endif
	}

	if (m_connection)
		evhttp_connection_free(m_connection);

	int port = evhttp_uri_get_port(m_uri);
    if (port == -1) port = atoi(g_localServerPort.c_str()) + 1;

    m_connection = evhttp_connection_base_new(base, NULL, evhttp_uri_get_host(m_uri), port);
    evhttp_connection_set_retries(m_connection, m_retries);
    evhttp_connection_set_timeout(m_connection, m_timeout);

	/**
	* Request will be released by evhttp connection
	* See info of evhttp_make_request()
	*/
	if (m_request_flag == REQUEST_POST_FLAG) {
		m_httpreq = evhttp_request_new(http_requset_post_cb, this);
	}
	else if (m_request_flag == REQUEST_GET_FLAG) {
		m_httpreq = evhttp_request_new(http_requset_get_cb, this);
	}
	else if (m_request_flag == REQUEST_SOAP_FLAG)
	{
		m_httpreq = evhttp_request_new(http_requset_post_cb, this);
	}

	/** Set the header properties */
    evhttp_add_header(m_httpreq->output_headers, "Host", evhttp_uri_get_host(m_uri));
	if (m_request_flag == REQUEST_POST_FLAG) {

		const char* query = evhttp_uri_get_query(m_uri);
		const char* path = evhttp_uri_get_path(m_uri);
		string path_query;
		if (path)
			path_query = path;
		if (query)
		{
			path_query += "?"; 
			path_query += query;
		}

		/** Set the post data */
		if (m_post_data)
			evbuffer_add(m_httpreq->output_buffer, ANSItoUTF8(m_post_data).c_str(), strlen(ANSItoUTF8(m_post_data).c_str()));
		evhttp_add_header(m_httpreq->output_headers, "Content-Type", m_content_type);
        if(m_soap_action != NULL)
        {
            evhttp_add_header(m_httpreq->output_headers, "SOAPAction", m_soap_action);
        }
		char num[10];
        //_itoa_s((UINT)strlen(ANSItoUTF8(m_post_data).c_str()), num, 10);
        itoa((UINT)strlen(ANSItoUTF8(m_post_data).c_str()), num, 10);
		evhttp_add_header(m_httpreq->output_headers, "Length", num);

		evhttp_make_request(m_connection, m_httpreq, EVHTTP_REQ_POST,
            (path_query.length()>1) ? path_query.data() : "/");
	}
	else if (m_request_flag == REQUEST_SOAP_FLAG) {

		const char* query = evhttp_uri_get_query(m_uri);
		const char* path = evhttp_uri_get_path(m_uri);
		string path_query;
		if (path)
			path_query = path;
		if (query)
		{
			path_query += "?";
			path_query += query;
		}

		/** Set the post data */
		if (m_post_data)
        evbuffer_add(m_httpreq->output_buffer, ANSItoUTF8(m_post_data).c_str(), strlen(ANSItoUTF8(m_post_data).c_str()));
		evhttp_add_header(m_httpreq->output_headers, "Content-Type", m_content_type);
		char num[10];
        //_itoa_s((UINT)strlen(ANSItoUTF8(m_post_data).c_str()), num, 10);
        itoa((UINT)strlen(ANSItoUTF8(m_post_data).c_str()), num, 10);
		evhttp_add_header(m_httpreq->output_headers, "Length", num);

		evhttp_make_request(m_connection, m_httpreq, EVHTTP_REQ_POST,
            (path_query.length()>1) ? path_query.data() : "/");
	}
	else if (m_request_flag == REQUEST_GET_FLAG) {
		const char* query = evhttp_uri_get_query(m_uri);
		const char* path = evhttp_uri_get_path(m_uri);
		string path_query;
		if (path)
			path_query = path;
		if (query)
		{
			path_query += "?";
			path_query += query;
		}
		evhttp_make_request(m_connection, m_httpreq, EVHTTP_REQ_GET,
            (path_query.length()>1) ? path_query.data() : "/");
	}

	return 0;
}

/************************** New/Free Function ******************************/
/**
* @param get_flag: refer REQUEST_GET_*
*
*/

void  HttpClient::http_request_free()
{
	evhttp_connection_free(m_connection);
	m_connection = NULL;
	evhttp_uri_free(m_uri);
	m_uri = NULL;
}

BOOL HttpClient::startHttpClient(std::string filename)
{
    ResponseData.clear();
    if("TBD"==filename)
    {
        start_url_request();
    }
    else
    {
        this->filename = filename + "_J_FTP";
        start_bdurl_request();
    }

    DATA_PRINT(LEVEL_INFO, "HTTP client has sent request(host:%s, port:%d, path:%s)......\n",
               evhttp_uri_get_host(m_uri), evhttp_uri_get_port(m_uri), evhttp_uri_get_path(m_uri));

	event_base_dispatch(base);
	http_request_free();
	
	return TRUE;
}

BOOL HttpClient::Save_PhotoData_To_LocalFile(unsigned char *data, unsigned int f_length)
{
	FILE *v_file = NULL;
	int i = 1;
    std::string v_filename = m_photo_filename;
	char additional[32];
	additional[0] = 0;

    while (access(v_filename.c_str(), 0) == 0) {
        sprintf(additional, "-%d", i++);
        v_filename = m_photo_filename;
        v_filename.append(std::string(additional));
    }
//    while (access(v_filename.c_str(), 00) == 0) {
//        sprintf(additional, "-%d\0", i++);
//		v_filename = m_photo_filename;
//        v_filename.append(std::string(additional));
//	}

    m_photo_filename.append(std::string(additional)); //update new file name
    m_demo_filename.append(std::string(additional));

    if (f_length <= 1000) {
        DATA_PRINT(LEVEL_DEBUG, "The photo is too small, path: %s \n", m_photo_filename.data());
    }

    v_file = fopen(m_photo_filename.c_str(), "w");
	if (v_file == NULL) {
        DATA_PRINT(LEVEL_ERROR, " [Save_PhotoData_To_LocalFile()] Can not create and open file: %s \n", m_photo_filename.c_str());
		return FALSE;
	}

	fseek(v_file, 0, SEEK_SET);
	fwrite(data, 1, f_length, v_file);
	fflush(v_file);
	fclose(v_file);

	return TRUE;
}
bool HttpClient::Save_bd_PhotoData_To_LocalFile(unsigned char* data, unsigned int f_length)
{
    if(!SaveHostXML(data,f_length))
    {
       return false;
    }

    FILE *v_file = NULL;

    if (f_length <= 1000) {
        DATA_PRINT(LEVEL_DEBUG, "The photo is too small, path: %s \n", m_photo_filename.data());
    }

    v_file = fopen(m_photo_filename.c_str(), "w");
    if (v_file == NULL) {
        DATA_PRINT(LEVEL_ERROR, " [Save_PhotoData_To_LocalFile()] Can not create and open file: %s \n", m_photo_filename.c_str());
        return FALSE;
    }

    fseek(v_file, 0, SEEK_SET);
    fwrite(data, 1, f_length, v_file);
    fflush(v_file);
    fclose(v_file);

    return TRUE;
}
BOOL HttpClient::SaveHostCheckItemXML(unsigned char* data,unsigned int length)
{
    FILE *pfile = NULL;
    pfile = fopen("checkitemhost.xml","w");
    if(pfile == NULL)
    {
        DATA_PRINT(LEVEL_ERROR,"Save HostCheckItem can't create and open file\n");
        return FALSE;
    }

    fwrite(data,1,length,pfile);
    fflush(pfile);
    fclose(pfile);

    return TRUE;
}

void HttpClient::set_retries_timeout(int retries, int timeout)
{
    m_retries = retries, m_timeout = timeout;
}

BOOL HttpClient::Save_VideoData_To_LocalFile(unsigned char *data, unsigned int f_length)
{
    FILE *v_file = NULL;
    int i = 1;
    std::string v_filename = m_video_filename;
    char additional[32];
    additional[0] = 0;

    while (access(v_filename.c_str(), 0) == 0) {
        sprintf(additional, "-%d", i++);
        v_filename = m_video_filename;
        v_filename.append(std::string(additional));
    }

    m_video_filename.append(std::string(additional)); //update new file name
    m_demo_filename.append(std::string(additional));

    if (f_length <= 1000) {
        DATA_PRINT(LEVEL_DEBUG, "The video is too small, path: %s \n", m_video_filename.data());
    }

    v_file = fopen(m_video_filename.c_str(), "w");
    if (v_file == NULL) {
        DATA_PRINT(LEVEL_ERROR, " [Save_VideoData_To_LocalFile()] Can not create and open file: %s \n", m_video_filename.c_str());
        return FALSE;
    }

    fseek(v_file, 0, SEEK_SET);
    fwrite(data, 1, f_length, v_file);
    fflush(v_file);
    fclose(v_file);

    return TRUE;
}
bool HttpClient::SaveHostXML(unsigned char* data,unsigned int length)
{
    FILE *file_xml = nullptr;
    std::string xml_filename=m_photo_filename + "recive.xml";
    file_xml = fopen(xml_filename.c_str(), "w");
    if (nullptr == file_xml ) {
        DATA_PRINT(LEVEL_ERROR, " [Save_xml_To_LocalFile()] Can not create and open file: %s \n", xml_filename.c_str());
        return FALSE;
    }

    fwrite(data,1,length,file_xml);
    fflush(file_xml);
    fclose(file_xml);
    CMarkup xml;
    if (!xml.Load(xml_filename.c_str())) {
        DATA_PRINT(LEVEL_ERROR, "读取文件%s.xml失败！ \n",xml_filename.c_str());
        DATA_PRINT(LEVEL_ERROR, "原因: %s \n", xml.GetError().data());
        return FALSE;
    }

    return TRUE;
}
