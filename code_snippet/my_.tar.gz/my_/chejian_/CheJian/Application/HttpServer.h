
#include "trace_log.h"
#include <event2/event.h> 
#include <event2/buffer.h> 
#include <event2/http.h>
#include "vehicle_inf.h"
#include <string>
using namespace std;

#pragma once
BOOL recordRevCarInfo(vehicle_inf *pvehicle_inf,BOOL flage);
class HttpServer
{
public:
	string s_ip;
	int s_port;
	event_base* base;
	evhttp* http_server;
	std::string m_method;
	std::string m_jkxlh;
	std::string m_jkid;
	std::string m_xtlb;

public:
	HttpServer();
	~HttpServer();
	bool startHttpServer(const char* ip, int port, void(*cb)(struct evhttp_request *, void *), void *arg);
	int run();
	void stop();
};

