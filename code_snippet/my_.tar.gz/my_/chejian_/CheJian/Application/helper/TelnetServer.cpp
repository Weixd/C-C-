#include "TelnetServer.h"
#include "../trace_log.h"
#include "HelperString.h"
#include "HelperFile.h"
#include "../vehicle_inf.h"
#include "../BlockQueue.h"
#include <fstream>
#include "TextTable.h"
#include <sstream>
#include "../vehicle_check_service.h"
#include "../Markup.h"
#include <arpa/telnet.h>
#include <regex>
#include <../MySQL_DB.h>
#include <math.h>
#include <ctype.h>

#define is_num(c) (c>='0' && c<='9')

extern unsigned int g_device_ID;
extern std::string g_version;
extern int g_SlaveCount;
extern std::string g_master_IP;
extern unsigned int g_debug_level;
extern std::string g_localServerIp;
extern std::string g_localServerPort;
extern std::string g_photoUri;
extern std::string g_photoFilePath;
extern std::string g_videoFilePath;
extern std::string g_demo_path;
extern BlockingQueue<vehicle_inf*> toanalyse_queue;
extern BlockingQueue<vehicle_inf*> download_queue;
extern BlockingQueue<video_inf*> video_queue;
extern BlockingQueue<vehicle_inf *> reply_queue;

char cmd_telnet[9] = {(char)0xff, (char)0xfb, (char)0x01, (char)0xff, (char)0xfb, (char)0x03, (char)0xff, (char)0xfc, (char)0x1f};

std::string VecToString(std::vector<std::string>& vec,std::string delim)
{
    std::string ret="";
    for(unsigned int i=0;i<vec.size();i++)
    {
        if(i==0)
            ret=vec[i];
        else
            ret+=delim+vec[i];
    }
    return ret;
}

TelnetServer::TelnetServer()
{
    bRun_=false;
    servFd_=-1;
    pService_=nullptr;
    supportCondPropery={"jyjgbh","tplx","hpzl","jylb","syxz","cllx","jyjg"};
    supportStatPropery={"jyjgbh","tplx","hpzl","jylb","syxz","cllx","clpp","clxh"};

    man_["v"]["NAME"]="show the program version.";
    man_["v"]["SYNOPSIS"]="v";
    man_["v"]["OPTIONS"]="\n";

    man_["st-show"]["NAME"]="statistics and display vehicle attributes associated with results table.";
    man_["st-show"]["SYNOPSIS"]="st-show [-a dbIp] [-u dbUserName] [-p dbPassWord] [-n dbName] [-s \"queryStartTime\"] [-e \"queryEndTime\"] [-o outputPath] [-jyjgbh jyjgbhStr] [-tplx tplxStr] [-hpzl hpzlStr] [-jylb jylbStr] [-syxz syxzStr] [-cllx cllxStr] [-jyjg jyjgStr] [-asc sortColumn] [-desc sortColumn] propery";
    man_["st-show"]["OPTIONS"]="\t-a  appoint query database ip.\n"
                               "\t-u  appoint query database user name.\n"
                               "\t-p  appoint query database password.\n"
                               "\t-n  appoint query database name.\n"
                               "\t-s  appoint query start time,time format is like '\"2018-01-22 00:00:00\"'.\n"
                               "\t-e  appoint query end time,time format is like '\"2018-01-22 00:00:00\"'.\n"
                               "\t-o  output the statistics info to the file,outputPath is like '/home/awood/aa'\n"
                               "\t-jyjgbh  jyjgbh string,like \"10000111,1000222,1000003\".\n"
                               "\t-tplx  tplx string,like \"110,111,112\".\n"
                               "\t-hpzl  hpzl string,like \"A,B,C\".\n"
                               "\t-jylb  jylb string,like \"aa,bb,cc\".\n"
                               "\t-syxz  syxz string,like \"aa,bb,cc\".\n"
                               "\t-cllx  cllx string,like \"aa,bb,cc\".\n"
                               "\t-jyjg  jyjg string,like \"aa,bb,cc\".\n"
                               "\t-asc  sort by sortColumn ascending,sortColumn>=1.\n"
                               "\t-desc sort by sortColumn descending,sortColumn>=1.\n";

    man_["st-cond"]["NAME"]="set or show query condition.";
    man_["st-cond"]["SYNOPSIS"]="st-cond [-a] [-d] [propery] [value]";
    man_["st-cond"]["OPTIONS"]="\t-a  add element to property array.\n"
                               "\t-d  delete element from property array.\n"
                               "\tproperty:  must be ["+VecToString(supportCondPropery,",")+"].\n"
                               "\tvalue: sould like '0111,0222,3333',if you do not appoint value,-a and -d,it will show all the element about the property.\n"
                               "\tif not appoint any args,it will show all the condition info.\n";

    man_["st-clean"]["NAME"]="reset query condition.";
    man_["st-clean"]["SYNOPSIS"]="st-clean [property]";
    man_["st-clean"]["OPTIONS"]="\tproperty:  must be ["+VecToString(supportCondPropery,",")+"].\n"
                                "\tif not support property,it will clean all conditions.\n";

    man_["clear"]["NAME"]="clear the screen.";
    man_["clear"]["SYNOPSIS"]="clear.";
    man_["clear"]["OPTIONS"]="\n";

    man_["getc"]["NAME"]="get the config or it's element.";
    man_["getc"]["SYNOPSIS"]="getc [elementChain]";
    man_["getc"]["OPTIONS"]="\telementChain:  like 'config>devId' \n";

    man_["delc"]["NAME"]="delete config's element.";
    man_["delc"]["SYNOPSIS"]="delc elementChain";
    man_["delc"]["OPTIONS"]="\telementChain:  like 'config>devId' \n";

    man_["setc"]["NAME"]="set or add element to config.";
    man_["setc"]["SYNOPSIS"]="setc elementChain elementStr";
    man_["setc"]["OPTIONS"]="\telementChain:  like 'config>devId' \n"
                            "\telementStr:  like '<peple>wdy</people>' \n";

    man_["restart"]["NAME"]="restart the program.";
    man_["restart"]["SYNOPSIS"]="restart";
    man_["restart"]["OPTIONS"]="\n";

    man_["ldconfig"]["NAME"]="reload config file.";
    man_["ldconfig"]["SYNOPSIS"]="ldconfig";
    man_["ldconfig"]["OPTIONS"]="\n";

    man_["nodes"]["NAME"]="show neighbor node's run info.";
    man_["nodes"]["SYNOPSIS"]="nodes";
    man_["nodes"]["OPTIONS"]="\n";

    man_["update"]["NAME"]="update nodes's version to highest version.";
    man_["update"]["SYNOPSIS"]="update [-s] devIdStr";
    man_["update"]["OPTIONS"]="\t[-s]:  stop update which node's devId in devIdStr \n"
                              "\tdevIdStr:  you can run nodes command to got the devId and the devIdStr is like '0,1,2' \n";

}

TelnetServer::~TelnetServer()
{
    if(bRun_)
        Stop();
}

void TelnetServer::Stop()
{
    if(bRun_)
    {
        bRun_=false;
        shutdown(servFd_, SHUT_RDWR);
        close(servFd_);
        acceptTh_->join();
        for(auto& c:clnts)
        {
            close(c.first);
            c.second->detach();
        }
    }
}

int TelnetServer::WriteData(int sockfd,std::string str)
{
    return write(sockfd, str.c_str(), str.length());
}

int TelnetServer::WriteData(int sockfd,char* data,int len)
{
    return write(sockfd, data, len);
}

int TelnetServer::WTextAtBegin(int sockfd,std::string str)
{
    std::string clsline="\033["+std::to_string(CMD_BUF_SIZE)+"D\033[J";
    WriteData(sockfd,clsline);
    str=hl::strreplace(str,"\n","\n"+clsline);
    return write(sockfd, str.c_str(), str.length());
}

bool TelnetServer::ReadCmdLine(int sockfd,char *buf,bool bLogin,ThreadGlobal& tg)
{
    int ret=0,pos=0,idx=-1,scw=0,sch=0,sx=0,sy=0,flag=0;
    memset(buf,0,CMD_BUF_SIZE);
    WriteData(sockfd,"\033[s\033[0;2048H\033[6n");
    for(;;)
    {
        char chars[3]={0};
        int bpos=pos,blen=strlen(buf);
        ret = read(sockfd, chars, 3);
        if(ret <= 0)
            return false;
        else if(ret == 1)
        {
            if(chars[0]==0x08 || chars[0]==0x7f)
            {
                if(pos > 0)
                {
                    int p=pos;
                    for(;buf[p]!='\0';p++)
                    {
                        buf[p-1]=buf[p];
                    }
                    buf[p-1]='\0';
                    pos--;
                }
            }
            else if(isprint(chars[0])!=0)
            {
                if(pos>=CMD_BUF_SIZE-2)
                {
                    pos=CMD_BUF_SIZE-2;
                    return true;
                }
                unsigned int epos=strlen(buf);
                for(;epos>pos;epos--)
                {
                    buf[epos]=buf[epos-1];
                }
                buf[pos]=chars[0];
                pos++;
            }
        }
        else if(ret == 2)
        {
            if(chars[0] == '\r')
            {
                if(!bLogin)
                    tg.AddCmdHistory(buf);
                WriteData(sockfd,"\n");
                return true;
            }
            else
            {
                if(pos>=CMD_BUF_SIZE-2)
                {
                    pos=CMD_BUF_SIZE-2;
                    return true;
                }
                if(isprint(chars[0])==0)
                    chars[0]=' ';
                if(isprint(chars[1])==0)
                    chars[1]=' ';

                unsigned int epos=strlen(buf);
                for(;epos>pos+1;epos--)
                {
                    buf[epos+1]=buf[epos-1];
                    buf[epos]=buf[epos-2];
                }
                buf[pos]=chars[0];
                buf[pos+1]=chars[1];
                pos+=2;
            }
        }
        else
        {
            if(chars[0] == 0x1b && chars[1] == 0x5b && chars[2] == 0x44) //left move
            {
                pos--;
                pos=pos<0?0:pos;
            }
            else if(chars[0] == 0x1b && chars[1] == 0x5b && chars[2] == 0x43) //right move
            {
                pos++;
                pos = pos>strlen(buf)?strlen(buf):pos;
            }
            else if(chars[0] == 0x1b && chars[1] == 0x5b && chars[2] == 0x41) //up move
            {
                if(tg.cmdHistory_.size()>0)
                {
                    idx++;
                    idx=idx>tg.cmdHistory_.size()-1?tg.cmdHistory_.size()-1:idx;
                    memset(buf,0,CMD_BUF_SIZE);
                    strcpy(buf,tg.cmdHistory_[idx].c_str());
                    //move cursor to start pos
                    int a=ceil(sx/float(scw));
                    int b=ceil((bpos+sx)/float(scw));
                    if(b-a>0)
                    {
                        WriteData(sockfd,"\033["+std::to_string(b-a)+"A");
                        int c=sx%scw;
                        c=c==0?scw:c;
                        int d=(bpos+sx)%scw;
                        d=d==0?scw:d;
                        if(d-c>0)
                            WriteData(sockfd,"\033["+std::to_string(d-c)+"D");
                        else if(d-c<0)
                            WriteData(sockfd,"\033["+std::to_string(c-d)+"C");

                    }
                    else if(b==a)
                    {
                        if(bpos>0)
                            WriteData(sockfd,"\033["+std::to_string(bpos)+"D");
                    }
                    WriteData(sockfd,"\033[J");
                    pos=strlen(buf);
                    bpos=0;
                    blen=0;
                }
            }
            else if(chars[0] == 0x1b && chars[1] == 0x5b && chars[2] == 0x42) //down move
            {
                if(tg.cmdHistory_.size()>0)
                {
                    if(idx == -1)
                        continue;
                    idx--;
                    idx=idx<0?0:idx;
                    memset(buf,0,CMD_BUF_SIZE);
                    strcpy(buf,tg.cmdHistory_[idx].c_str());
                    //move cursor to start pos
                    int a=ceil(sx/float(scw));
                    int b=ceil((bpos+sx)/float(scw));
                    if(b-a>0)
                    {
                        WriteData(sockfd,"\033["+std::to_string(b-a)+"A");
                        int c=sx%scw;
                        c=c==0?scw:c;
                        int d=(bpos+sx)%scw;
                        d=d==0?scw:d;
                        if(d-c>0)
                            WriteData(sockfd,"\033["+std::to_string(d-c)+"D");
                        else if(d-c<0)
                            WriteData(sockfd,"\033["+std::to_string(c-d)+"C");

                    }
                    else if(b==a)
                    {
                        if(bpos>0)
                            WriteData(sockfd,"\033["+std::to_string(bpos)+"D");
                    }
                    WriteData(sockfd,"\033[J");
                    pos=strlen(buf);
                    bpos=0;
                    blen=0;
                }
            }
            else if(chars[0] == 0x1b && chars[1] == 0x5b)
            {
                char cur[64]={0};
                memcpy(cur,chars,3);
                read(sockfd, cur+3, 16);
                std::string curstr=hl::strreplace(cur,"R","");
                curstr=hl::strreplace(curstr,"\033[","");
                std::vector<std::string> els;
                hl::strsplit(els,curstr,";");
                if(flag == 0)
                {
                    scw=atoi(els.back().c_str());
                    sch=atoi(els.front().c_str());
                    (void)sch;
                    WriteData(sockfd,"\033[u");
                    WriteData(sockfd,"\033[6n");
                    flag++;
                }
                else
                {
                    sx=atoi(els.back().c_str());
                    sy=atoi(els.front().c_str());
                    (void)sy;
                }

            }
            else if(chars[0] != -1)
            {
                if(pos>=CMD_BUF_SIZE-2)
                {
                    pos=CMD_BUF_SIZE-2;
                    return true;
                }
                if(isprint(chars[0])==0)
                    chars[0]=' ';
                if(isprint(chars[1])==0)
                    chars[1]=' ';
                if(isprint(chars[2])==0)
                    chars[2]=' ';

                int epos=strlen(buf);
                for(;epos>pos+2;epos--)
                {
                    buf[epos+2]=buf[epos-1];
                    buf[epos+1]=buf[epos-2];
                    buf[epos]=buf[epos-3];
                }
                buf[pos]=chars[0];
                buf[pos+1]=chars[1];
                buf[pos+2]=chars[2];
                pos+=3;
            }
        }
        if(scw == 0)
        {
            memset(buf,0,CMD_BUF_SIZE);
            pos=0;
            idx=-1;
            continue;
        }

        std::string output=buf;
        int rpos=pos-bpos;
        if(blen == output.length())
        {
            int a=ceil((bpos+sx)/float(scw));
            int b=ceil((pos+sx)/float(scw));
            if(b-a>0)
                WriteData(sockfd,"\033[1B\033["+std::to_string(scw)+"D");
            else if(b==a)
            {
                if(rpos>0)
                    WriteData(sockfd,"\033["+std::to_string(rpos)+"C");
                else if(rpos<0)
                    WriteData(sockfd,"\033["+std::to_string(-rpos)+"D");
            }
            else
                WriteData(sockfd,"\033[1A\033["+std::to_string(scw)+"D\033["+std::to_string(scw-1)+"C");
        }
        else
        {
            if(rpos>0)
            {
                std::string oo=buf+bpos;
                if(bLogin){
                    for(auto& s:oo)
                        s='*';
                }
                std::string roo;
                for(unsigned int i=0;i<oo.length();i++)
                {
                    roo+=oo[i];
                    if((sx+bpos+i)%scw == 0)
                        roo+="\n\033["+std::to_string(scw)+"D";
                }
                WriteData(sockfd,roo);
                int a=ceil((pos+sx)/float(scw));
                int b=ceil((strlen(buf)+sx)/float(scw));
                if(b-a>0)
                {
                    WriteData(sockfd,"\033["+std::to_string(b-a)+"A");
                    int c=(strlen(buf)+sx)%scw;
                    c=c==0?scw:c;
                    int d=(pos+sx)%scw;
                    d=d==0?scw:d;
                    if(d-c>0)
                        WriteData(sockfd,"\033["+std::to_string(d-c)+"C");
                    else if(d-c<0)
                        WriteData(sockfd,"\033["+std::to_string(c-d)+"D");

                }
                else if(b==a)
                {
                    int m=strlen(buf)-pos;
                    if(m>0)
                        WriteData(sockfd,"\033["+std::to_string(m)+"D");
                }
            }
            else if(rpos<0)
            {
                if((sx+pos)%scw == 0)
                    WriteData(sockfd,"\033[1A\033["+std::to_string(scw)+"D\033["+std::to_string(scw-1)+"C");
                else
                    WriteData(sockfd,"\033[1D");
                WriteData(sockfd,"\033[s");
                std::string oo=buf+pos;
                if(bLogin){
                    for(auto& s:oo)
                        s='*';
                }
                std::string roo;
                for(unsigned int i=0;i<oo.length();i++)
                {
                    roo+=oo[i];
                    if((sx+pos+i)%scw == 0)
                        roo+="\n\033["+std::to_string(scw)+"D";
                }
                WriteData(sockfd,roo+"\033[J\033[u");
            }
        }
    }
    return true;
}

void TelnetServer::TelnetSession(TelnetServer* pts,int fd)
{
    char cmdbuf[CMD_BUF_SIZE]={0};
    pts->WriteData(fd,cmd_telnet,sizeof(cmd_telnet));
    bool bLogin=false;
    ThreadGlobal tg;
    while(pts->bRun_)
    {
BeginLoop:
        if(!bLogin)
        {
            pts->WTextAtBegin(fd,"\033[31mwelcome to chejian program!\033[37m\033[5m\n");
            pts->WTextAtBegin(fd,"\033[32mpassword: \033[37m\033[5m");
            if(!pts->ReadCmdLine(fd, cmdbuf,true,tg))
                break;
            std::string cmdstr=cmdbuf;
            cmdstr=hl::strreplace(cmdstr,"\r","");
            cmdstr=hl::strreplace(cmdstr,"\n","");
            if(cmdstr == "exit")
            {
                std::string clsline="\033["+std::to_string(CMD_BUF_SIZE)+"D";
                pts->WriteData(fd,clsline);
                break;
            }
            else if(cmdstr == "emdata#2018")
            {
                bLogin=true;
                pts->WTextAtBegin(fd,"login successful\n");
            }
            else
            {
                bLogin=false;
                pts->WTextAtBegin(fd,"login failed\n");
            }
            goto BeginLoop;
        }
        pts->WTextAtBegin(fd,"\033[32mchejian:~$\033[37m \033[5m");
        if(!pts->ReadCmdLine(fd, cmdbuf,false,tg))
            break;
        std::string cmdstr=cmdbuf;
        cmdstr=hl::strreplace(cmdstr,"\r","");
        cmdstr=hl::strreplace(cmdstr,"\n","");
        for(unsigned int i=0;i<cmdstr.size();)
        {
            if(cmdstr[i] == '\"')
            {
                unsigned int j=i+1;
                for(;j<cmdstr.size();j++)
                {
                    if(cmdstr[j] == '\"')
                        break;
                    else if(cmdstr[j] == ' ')
                        cmdstr[j]='\n';
                }
                if(j==cmdstr.size())
                {
                    pts->WTextAtBegin(fd,"unclosed quotation marks\n");
                    goto BeginLoop;
                }
                i=j+1;
            }
            else
                i++;
        }
        std::vector<std::string> cc,rcc;
        hl::strsplit(cc,cmdstr," ");
        for(auto& c:cc)
        {
            c=hl::strreplace(c,"\n"," ");
            c=hl::strreplace(c,"\"","");
            if(c!="")
                rcc.push_back(c);
        }
        if(rcc.size()<=0)
        {
            pts->WTextAtBegin(fd,"command can't empty\n");
            goto BeginLoop;
        }
        if(rcc[0] == "exit")
        {
            std::string clsline="\033["+std::to_string(CMD_BUF_SIZE)+"D";
            pts->WriteData(fd,clsline);
            break;
        }
        pts->ProcessCommand(fd,rcc,tg);
    }
    shutdown(fd, SHUT_RDWR);
    close(fd);
    std::lock_guard<std::mutex> lg(pts->clntsMutex_);
    std::map<int,std::shared_ptr<std::thread>>::iterator it=pts->clnts.find(fd);
    if(it!=pts->clnts.end())
    {
        it->second->detach();
        pts->clnts.erase(it);
    }
}

void TelnetServer::ServAccept(TelnetServer* pts)
{
    while(pts->bRun_)
    {
        socklen_t sin_size=sizeof(struct sockaddr_in);
        int clntFd=-1;
        struct sockaddr_in remote_addr;
        if((clntFd=accept(pts->servFd_,(struct sockaddr *)&remote_addr,&sin_size))<0)
        {
            DATA_PRINT(LEVEL_ERROR, "telnet accept error! \n");
            return;
        }
        std::lock_guard<std::mutex> lg(pts->clntsMutex_);
        pts->clnts[clntFd]=std::shared_ptr<std::thread>(new std::thread(&TelnetServer::TelnetSession,pts,clntFd));
    }
}

bool TelnetServer::Run(vehicle_check_service* pService,int port)
{
    struct sockaddr_in server_addr;
    memset(&server_addr,0,sizeof(server_addr));
    server_addr.sin_family=AF_INET;
    server_addr.sin_addr.s_addr=htonl(INADDR_ANY);
    server_addr.sin_port=htons(port);

    if((servFd_=socket(AF_INET,SOCK_STREAM,0))<0)
    {
        DATA_PRINT(LEVEL_ERROR, "telnet create socket error! \n");
        return false;
    }
    int on = 1;
    setsockopt(servFd_, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));
    if (bind(servFd_,(struct sockaddr *)&server_addr,sizeof(struct sockaddr))<0)
    {
        close(servFd_);
        DATA_PRINT(LEVEL_ERROR, "telnet bind socket error! port=%d\n",port);
        return false;
    }
    listen(servFd_,1024);
    bRun_=true;
    pService_=pService;
    acceptTh_=std::shared_ptr<std::thread>(new std::thread(&TelnetServer::ServAccept, this));
    DATA_PRINT(LEVEL_INFO, "telnet start accepting! \n");
    return true;
}

bool IsHave(std::vector<std::string>& cmds,std::string op)
{
    for(auto& c:cmds)
    {
        if(c == op)
            return true;
    }
    return false;
}

std::string GetOptionValue(std::vector<std::string>& cmds,std::string op)
{
    for(unsigned int i=0;i<cmds.size();i++)
    {
        if(cmds[i] == op)
        {
            if((i+1)< cmds.size() && cmds[i+1]!="" && cmds[i+1][0] != '-')
                return cmds[i+1];
            else
                return "";
        }
    }
    return "";
}

void GetNonOptionValue(std::vector<std::string>& cmds,std::string& v1,std::string& v2)
{
    bool scond=cmds.size()-1 >0 && cmds[cmds.size()-1]!="" && cmds[cmds.size()-1][0] != '-';
    bool first=cmds.size()-2 >0 && cmds[cmds.size()-2]!="" && cmds[cmds.size()-2][0] != '-';
    if(scond)
    {
        if(first)
        {
            v1=cmds[cmds.size()-2];
            v2=cmds[cmds.size()-1];
        }
        else
        {
            v1=cmds[cmds.size()-1];
            v2="";
        }
    }
    else
    {
        v1="";
        v2="";
    }
}

void GetNonOptionValue(std::vector<std::string>& cmds,std::string& v1)
{
    if(cmds.size()-1 >0 && cmds[cmds.size()-1]!="" && cmds[cmds.size()-1][0] != '-')
        v1=cmds[cmds.size()-1];
    else
        v1="";
}

void SortTable(TextTable&t,int col,bool isAsc)
{
    if(t._rows.size()<=3)
        return;
    col=col<=0?1:(col>t._rows[1].size()-1?t._rows[1].size()-1:col);
    std::sort(t._rows.begin()+2,t._rows.end(),[=](TextTable::Row& p1, TextTable::Row& p2)
    {
        std::vector<std::string> v;
        hl::strsplit(v,p1[col],"/");
        if(v.size()<1)
            return true;
        int p1n=atoi(v[0].c_str());
        v.clear();
        hl::strsplit(v,p2[col],"/");
        if(v.size()<1)
            return true;
        int p2n=atoi(v[0].c_str());
        if(isAsc)
            return p1n<p2n;
        return p1n>p2n;
    });
}

void TelnetServer::ProcessCommand(int fd,std::vector<std::string>& cmds,ThreadGlobal& tg)
{
    if(cmds[0] == "v")
        WTextAtBegin(fd,g_version+"\n");
    else if(cmds[0] == "cat")
    {
        if(cmds.size()>=2)
        {
            std::string path=hl::ownerfolder()+cmds[1];
            if(hl::pathexist(path))
            {
                std::fstream fs;
                fs.open(path,std::ios::in);
                if(!fs.is_open())
                    WTextAtBegin(fd,"file open failed\n");
                else
                {
                    fs.seekg(0,std::ios::end);
                    size_t size=fs.tellg();
                    fs.seekg(0,std::ios::beg);
                    char* p=new char[size];
                    fs.read(p,size);
                    WTextAtBegin(fd,p);
                    WTextAtBegin(fd,"\n");
                    delete p;
                    fs.close();
                }
            }
            else
                WTextAtBegin(fd,"file not exist\n");
        }
        else
            WTextAtBegin(fd,"args error\n");
    }
#ifdef APPLY_MULTICAST
    else if(cmds[0] == "nodes")
    {
        TextTable t('-', '|', '+');
        std::lock_guard<std::mutex> lg(pService_->m_mc.cjClntsMutex_);
        t._rows.clear();
        t.add("DevId");
        t.add("Master");
        t.add("   version   ");
        t.add("     IP      ");
        t.add("Download(N)");
        t.add("Analyse(N)");
        t.add("Video(N)");
        t.add("Reply(N)");
        t.endOfRow();

        t.add(std::to_string(g_device_ID)+"(local)");
        int8_t bMaster = (g_SlaveCount != -1);
        t.add(bMaster?"YES":"NO");
        t.add(g_version);
        t.add(pService_->m_httpserver.s_ip);
        t.add(std::to_string(download_queue.Size()));
        t.add(std::to_string(toanalyse_queue.Size()));
        t.add(std::to_string(video_queue.Size()));
        t.add(std::to_string(reply_queue.Size()));
        t.endOfRow();

        for (auto& c : pService_->m_mc.cjClnts_)
        {
            t.add(std::to_string(c.second.devId));
            t.add(c.second.bMaster?"YES":"NO");
            t.add(c.second.ver);
            t.add(c.second.ip);
            t.add(std::to_string(c.second.downloadQueueSize));
            t.add(std::to_string(c.second.analyseQueueSize));
            t.add(std::to_string(c.second.videoQueueSize));
            t.add(std::to_string(c.second.replyQueueSize));
            t.endOfRow();
        }
        std::stringstream ss;
        ss << t;
        WTextAtBegin(fd,(char*)ss.str().c_str());
    }
    else if(cmds[0] == "update")
    {
        bool isUpdate=!IsHave(cmds,"-s");
        std::string value;
        GetNonOptionValue(cmds,value);
        if(value == "")
        {
            WTextAtBegin(fd,"please appoint the devIdStr,like '0,1,2'\n");
            return;
        }
        std::vector<std::string> devIds;
        hl::strsplit(devIds,value,",");
        for(auto& d:devIds)
        {
            for(auto& c:d)
            {
                if(!is_num(c))
                {
                    WTextAtBegin(fd,"devId must be number\n");
                    return;
                }
            }
        }
        pService_->m_mc.Update(isUpdate,value);
        WTextAtBegin(fd,"operate successful\n");
    }
#endif
    else if(cmds[0] == "ldconfig")
    {
        getVehicleCheck();
        getCheckItem();
        WTextAtBegin(fd,"load config successful\n");
    }
    else if(cmds[0] == "restart")
    {
        WTextAtBegin(fd,"restarting\n");
        pService_->stop();
        char path[1024]={0};
        readlink("/proc/self/exe", path, 1024);
        execlp(path, NULL, NULL);
    }
    else if(cmds[0] == "setc")
    {
        if(cmds.size() == 3)
        {
            std::vector<std::string> nodes;
            hl::strsplit(nodes,cmds[1],">");
            std::string xmlpath=hl::ownerfolder()+"vehicle_check.xml";
            CMarkup xml;
            if(xml.Load(xmlpath))
            {
                xml.ResetMainPos();
                for(auto& n:nodes)
                {
                    if (xml.FindElem(n))
                    {
                        xml.IntoElem();
                        continue;
                    }
                    else
                    {
                        xml.AddElem(n);
                        xml.IntoElem();
                    }
                }
                xml.OutOfElem();
                xml.SetElemContent(cmds[2]);
                if(xml.SetDoc(xml.GetDoc()))
                {
                    xml.Save(xmlpath);
                    WTextAtBegin(fd,"write successful\n");
                }
                else
                {
                    WTextAtBegin(fd,cmds[2]+",not well formed\n");
                }
            }
            else
            {
                WTextAtBegin(fd,"load vehicle_check.xml failed\n");
            }
        }
        else
        {
            WTextAtBegin(fd,"args error,should like: setc config>localServerIp 192.168.1.1\n");
        }
    }
    else if(cmds[0] == "delc")
    {
        if(cmds.size() == 2)
        {
            std::vector<std::string> nodes;
            hl::strsplit(nodes,cmds[1],">");
            std::string xmlpath=hl::ownerfolder()+"vehicle_check.xml";
            CMarkup xml;
            if(xml.Load(xmlpath))
            {
                xml.ResetMainPos();
                for(auto& n:nodes)
                {
                    if (xml.FindElem(n))
                    {
                        xml.IntoElem();
                        continue;
                    }
                    else
                    {
                        WTextAtBegin(fd,"node not exist\n");
                        return;
                    }
                }
                xml.OutOfElem();
                xml.RemoveElem();
                xml.Save(xmlpath);
                WTextAtBegin(fd,"delete successful\n");
            }
            else
            {
                WTextAtBegin(fd,"load vehicle_check.xml failed\n");
            }
        }
        else
        {
            WTextAtBegin(fd,"args error,should like: delc config>localServerIp\n");
        }
    }
    else if(cmds[0] == "getc")
    {
        if(cmds.size() == 1)
        {
            std::string xmlpath=hl::ownerfolder()+"vehicle_check.xml";
            CMarkup xml;
            if(xml.Load(xmlpath))
            {
                xml.ResetMainPos();
                WTextAtBegin(fd,xml.GetDoc()+"\n");
            }
            else
            {
                WTextAtBegin(fd,"load vehicle_check.xml failed\n");
            }
        }
        else if(cmds.size() == 2)
        {
            std::vector<std::string> nodes;
            hl::strsplit(nodes,cmds[1],">");
            std::string xmlpath=hl::ownerfolder()+"vehicle_check.xml";
            CMarkup xml;
            if(xml.Load(xmlpath))
            {
                xml.ResetMainPos();
                for(auto& n:nodes)
                {
                    if (xml.FindElem(n))
                    {
                        xml.IntoElem();
                        continue;
                    }
                    else
                    {
                        WTextAtBegin(fd,"node not exist\n");
                        return;
                    }
                }
                xml.OutOfElem();
                WTextAtBegin(fd,xml.GetElemContent()+"\n");
            }
            else
            {
                WTextAtBegin(fd,"load vehicle_check.xml failed\n");
            }
        }
        else
        {
            WTextAtBegin(fd,"args error,should like: getc config>localServerIp\n");
        }
    }
    else if(cmds[0] == "clear")
    {
        WTextAtBegin(fd,"\033[2J\033[0;0H");
    }
    else if(cmds[0] == "st-clean")
    {
        std::string value;
        GetNonOptionValue(cmds,value);
        if(value != "")
        {
            if(IsHave(supportCondPropery,value))
                tg.conditions_[value].clear();
            else
                WTextAtBegin(fd,"not support the property:"+value+",must in("+VecToString(supportCondPropery,",")+")\n");
            return;
        }
        tg.ReSet();
    }
    else if(cmds[0] == "st-cond")
    {
        bool isAdd=IsHave(cmds,"-a");
        bool isDel=IsHave(cmds,"-d");
        if(isAdd && isDel)
        {
            WTextAtBegin(fd,"-a,-d can't appear at the same time\n");
            return;
        }
        if(!isAdd && !isDel)
        {
            std::string value;
            GetNonOptionValue(cmds,value);
            if(value != "")
            {
                if(IsHave(supportCondPropery,value))
                {
                    for(auto& v:tg.conditions_[value])
                    {
                        WTextAtBegin(fd,v+"\n");
                    }
                }
                else
                {
                    WTextAtBegin(fd,"not support the property:"+value+",must in("+VecToString(supportCondPropery,",")+")\n");
                }
            }
            else
            {
                for(auto& cond:tg.conditions_)
                    WTextAtBegin(fd,cond.first+":"+VecToString(cond.second,",")+"\n");

            }
            return;
        }
        if(isAdd || isDel)
        {
            std::string v1,v2;
            GetNonOptionValue(cmds,v1,v2);
            if(v1 == "")
            {
                WTextAtBegin(fd,"please appoint the property\n");
                return;
            }
            if(v2 == "")
            {
                WTextAtBegin(fd,"please appoint the value\n");
                return;
            }
            if(IsHave(supportCondPropery,v1))
            {
                if(isAdd)
                {
                    std::vector<std::string> vv;
                    hl::strsplit(vv,v2,",");
                    for(auto& v:vv)
                        tg.conditions_[v1].push_back(v);
                    WTextAtBegin(fd,"add successful\n");
                }
                else
                {
                    std::vector<std::string> vv;
                    hl::strsplit(vv,v2,",");
                    for(auto& v:vv)
                    {
                        std::vector<std::string>& vs=tg.conditions_[v1];
                        std::vector<std::string>::iterator it=std::find(vs.begin(),vs.end(),v);
                        if(it != vs.end())
                            vs.erase(it);
                        else
                            WTextAtBegin(fd,"value:"+v+" not exist\n");
                    }
                }
            }
            else
            {
                WTextAtBegin(fd,"not support the property:"+v1+",must in("+VecToString(supportCondPropery,",")+")\n");
            }
            return;
        }
    }
    else if(cmds[0] == "st-show")
    {
        bool isReQuery=true;
        std::string ipaddr="localhost";
        std::string stime="1900-01-01 00:00:00";
        std::string etime="3000-01-01 00:00:00";
        std::string dbname="car_schema";
        std::string uname="root";
        std::string upasswd=getDBPassWord(DBPWD).c_str();
        std::string propery="";
        std::string opath="";
        bool asc=false,desc=false;
        int ascCol=1,descCol=1;
        if(IsHave(cmds,"-a"))
        {
            std::string ip=GetOptionValue(cmds,"-a");
            if(ip=="")
            {
                WTextAtBegin(fd,"please appoint ip address\n");
                return;
            }
            if(ip != "localhost")
            {
                std::vector<std::string> ii;
                hl::strsplit(ii,ip,".");
                if(ii.size() != 4)
                {
                    WTextAtBegin(fd,"ip must 4 elements\n");
                    return;
                }
                else
                {
                    for(auto& i:ii)
                    {
                        for(auto& c:i)
                        {
                            if(!is_num(c))
                            {
                                WTextAtBegin(fd,"ip element must number\n");
                                return;
                            }
                        }
                        if(atoi(i.c_str())<0 || atoi(i.c_str())>255 )
                        {
                            WTextAtBegin(fd,"ip element must between 0 and 255\n");
                            return;
                        }
                    }
                }
            }
            ipaddr=ip;
        }
        if(IsHave(cmds,"-s"))
        {
            std::string time=GetOptionValue(cmds,"-s");
            if(time=="")
            {
                WTextAtBegin(fd,"please appoint query start time\n");
                return;
            }
            std::regex reg("^\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}$");
            if(!std::regex_match(time,reg))
            {
                WTextAtBegin(fd,"start time format error,must like '\"2017-02-03 00:00:00\"'\n");
                return;
            }
            stime=time;
        }
        if(IsHave(cmds,"-e"))
        {
            std::string time=GetOptionValue(cmds,"-e");
            if(time=="")
            {
                WTextAtBegin(fd,"please appoint query end time\n");
                return;
            }
            std::regex reg("^\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}$");
            if(!std::regex_match(time,reg))
            {
                WTextAtBegin(fd,"end time format error,must like '\"2017-02-03 00:00:00\"'\n");
                return;
            }
            etime=time;
        }
        if(IsHave(cmds,"-n"))
        {
            std::string value=GetOptionValue(cmds,"-n");
            if(value=="")
            {
                WTextAtBegin(fd,"please appoint query database name\n");
                return;
            }
            dbname=value;
        }
        if(IsHave(cmds,"-u"))
        {
            std::string value=GetOptionValue(cmds,"-u");
            if(value=="")
            {
                WTextAtBegin(fd,"please appoint query database user name\n");
                return;
            }
            uname=value;
        }
        if(IsHave(cmds,"-p"))
        {
            std::string value=GetOptionValue(cmds,"-p");
            if(value=="")
            {
                WTextAtBegin(fd,"please appoint query database user password\n");
                return;
            }
            upasswd=value;
        }
        if(IsHave(cmds,"-asc"))
        {
            asc=true;
            std::string value=GetOptionValue(cmds,"-asc");
            if(value!="")
                ascCol=atoi(value.c_str());
        }
        if(IsHave(cmds,"-desc"))
        {
            desc=true;
            std::string value=GetOptionValue(cmds,"-desc");
            if(value!="")
                descCol=atoi(value.c_str());
        }
        tg.conditions_.clear();
        for(auto& s:supportCondPropery)
        {
            if(IsHave(cmds,"-"+s))
            {
                std::string value=GetOptionValue(cmds,"-"+s);
                if(value=="")
                {
                    WTextAtBegin(fd,"please appoint the value of "+s+"\n");
                    return;
                }
                std::vector<std::string> vv;
                hl::strsplit(vv,value,",");
                for(auto& v:vv)
                    tg.conditions_[s].push_back(v);
            }
        }

        if(IsHave(cmds,"-r"))
            isReQuery=true;

        propery="jyjgbh";
        /*
        GetNonOptionValue(cmds,propery);
        if(propery=="")
        {
            WTextAtBegin(fd,"please appoint the property\n");
            return;
        }
        if(!IsHave(supportStatPropery,propery))
        {
            WTextAtBegin(fd,"not support the property:"+propery+",must in("+VecToString(supportStatPropery,",")+")\n");
            return;
        }
        */
        if(IsHave(cmds,"-o"))
        {
            std::string value=GetOptionValue(cmds,"-o");
            if(value == "")
                opath="./"+propery;
            else
            {
                if(value.back() == '/')
                {
                    hl::creatdir(value);
                    opath=value+propery;
                }
                else
                {
                    std::string pp=hl::higher_level_folder(value);
                    hl::creatdir(pp);
                    opath=value;
                }
            }
        }

        if(isReQuery)
            tg.ReSetStat();

        long long count=0;
        if(!tg.bHadQuery_)
        {
            MySQL_DB db;
            if (db.connect(ipaddr.c_str(), 6033, uname.c_str(), upasswd.c_str(), dbname.c_str()))
            {
                std::string sql="SELECT category,result,jyjgbh,hpzl,jylb,syxz,cllx,clpp,clxh FROM check_infos as A,vehicle_checks as B where A.vehicle_check_id=B.id"
                                " and A.reason not like '%处理范围%' and A.reason not like '%未能获取到该资源数据%' and (B.created_at >= '"+stime+"' and B.created_at <= '"+etime+"')";
                for(auto& c:tg.conditions_)
                {
                    std::string pname=c.first;
                    if(pname == "tplx")
                        pname="category";
                    else if(pname == "jyjg")
                        pname="result";
                    if(c.second.size()>0)
                    {
                        sql+=" and (";
                        for(unsigned int i=0;i<c.second.size();i++)
                        {
                            std::string cc=c.second[i];
                            if(i==0)
                                sql+=pname+"='"+cc+"'";
                            else
                                sql+=" or "+pname+"='"+cc+"'";
                        }
                        sql+=")";
                    }
                }
                WTextAtBegin(fd,"quering...");
                MYSQL_RES *result = db.getResult(sql.c_str());
                if (result != NULL)
                {
                    MYSQL_ROW row = NULL;
                    system_clock::time_point tick = system_clock::now() - std::chrono::seconds(1);
                    while ((row = mysql_fetch_row(result)) != NULL)
                    {
                        for(unsigned int i=0;i<result->field_count;i++)
                        {
                            std::string fname=result->fields[i].name;
                            if(fname == "category")
                                fname="tplx";
                            else if(fname == "result")
                                fname="jyjg";
                            std::string rowi=row[i]?row[i]:"unknow";
                            rowi=rowi==""?"unknow":rowi;
                            std::string row1=row[1]?row[1]:"unknow";
                            row1=row1==""?"unknow":row1;
                            tg.properyMap_[fname][rowi]++;
                            tg.propery_jyjgMap_[fname][rowi+std::string("--")+row1]++;
                        }
                        std::string _jyjgbh=row[2]?row[2]:"unknow";
                        std::string _tplx=row[0]?row[0]:"unknow";
                        std::string _jyjg=row[1]?row[1]:"unknow";
                        tg.jyjgbh_tplx_jyjgMap_[_jyjgbh][_tplx][_jyjg]++;

                        count++;
                        if (duration<double, std::milli>(system_clock::now() - tick).count() > 1000 || count == result->row_count)
                        {
                            char buf[16] = { 0 };
                            sprintf(buf, "%.1f", count * 100 / double(result->row_count));
                            WTextAtBegin(fd,std::string(buf)+"%");
                            tick = system_clock::now();
                        }
                    }
                    db.freeResult(result);
                    tg.bHadQuery_=true;

                    db.disconnect();
                }
                else
                {
                    WTextAtBegin(fd,"db.getResult error\n");
                    db.disconnect();
                    return;
                }
            }
            else
            {
                WTextAtBegin(fd,"database connect failed\n");
                db.disconnect();
                return;
            }
        }
        /*
        TextTable t('-', '|', '+');
        int total=0;
        t._rows.clear();
        t.add(propery+"\\jyjg");
        for (auto& p : tg.properyMap_["jyjg"])
        {
            t.add(p.first);
            total+=p.second;
        }
        t.add("total");
        t.endOfRow();
        if(total<=0)
        {
            WTextAtBegin(fd,"query no data\n");
            return;
        }
        for (auto& p : tg.properyMap_[propery])
        {
            t.add(p.first);
            int to=0;
            for (auto& j : tg.properyMap_["jyjg"])
            {
                std::string key = p.first + "--" + j.first;
                int num=tg.propery_jyjgMap_[propery][key];
                char buf[16] = { 0 };
                sprintf(buf, "%.2f", num * 100 / float(total));
                t.add(std::to_string(num) + "/" + buf + "%");
                to+=num;
            }
            char buf[16] = { 0 };
            sprintf(buf, "%.2f", to * 100 / float(total));
            t.add(std::to_string(to) + "/" + buf + "%");
            t.endOfRow();
        }
        t.add("total");
        for (auto& j : tg.properyMap_["jyjg"])
        {
            char buf[16] = { 0 };
            sprintf(buf, "%.2f", j.second * 100 / float(total));
            t.add(std::to_string(j.second) + "/" + buf + "%");
        }
        t.add("\\");
        t.endOfRow();
        if(asc)
            SortTable(t,ascCol,true);
        else if(desc)
            SortTable(t,descCol,false);

        std::string header;
        header = "total records:"+std::to_string(total)+"\n";
        std::stringstream ss;
        ss << header;
        ss << t;
        WTextAtBegin(fd,(char*)ss.str().c_str());
        if(opath!="")
        {
            std::fstream fs;
            fs.open(opath, std::ios::out | std::ios::trunc);
            if(fs.is_open())
            {
                fs << ss.str();
                fs.close();
            }
        }
        */
        std::string header;
        header = "total records:"+std::to_string(count)+"\n\n";
        std::stringstream ss;
        ss << header;
        for(auto& j:tg.properyMap_["jyjgbh"])
        {
            TextTable t('-', '|', '+');
            t.add(j.first);
            t.endOfRow();

            t.add(std::string("tplx")+"\\jyjg");
            for (auto& p : tg.properyMap_["jyjg"])
            {
                t.add(p.first);
            }
            t.add("total");
            t.endOfRow();

            for (auto& tl : tg.properyMap_["tplx"])
            {
                int total=0;
                for(auto& mm:tg.jyjgbh_tplx_jyjgMap_[j.first][tl.first])
                {
                    total+=mm.second;
                }
                if(total==0)
                    continue;

                bool bskip=false;
                for(auto& w:tl.first)
                {
                    if(!is_num(w))
                    {
                        bskip=true;
                        break;
                    }
                }
                if(bskip)
                    continue;

                t.add(tl.first);
                for (auto& jj : tg.properyMap_["jyjg"])
                {
                    int num=tg.jyjgbh_tplx_jyjgMap_[j.first][tl.first][jj.first];
                    char buf[16] = { 0 };
                    if(total == 0)
                        sprintf(buf, "0.00%%");
                    else
                        sprintf(buf, "%.2f", num * 100 / float(total));
                    t.add(std::to_string(num) + "/" + buf + "%");
                }
                t.add(std::to_string(total));
                t.endOfRow();
            }

            if(asc)
                SortTable(t,ascCol,true);
            else if(desc)
                SortTable(t,descCol,false);
            ss << t << "\n";
        }
        WTextAtBegin(fd,(char*)ss.str().c_str());
        if(opath!="")
        {
            std::fstream fs;
            fs.open(opath, std::ios::out | std::ios::trunc);
            if(fs.is_open())
            {
                fs << ss.str();
                fs.close();
            }
        }
    }
    else if(cmds[0] == "man")
    {
        if(cmds.size() ==1)
        {
            WTextAtBegin(fd,"COMMANDS:\n");
            for(auto& c:man_)
                WTextAtBegin(fd,c.first+" : "+c.second["NAME"]+"\n");
        }
        else
        {
            auto it=man_.find(cmds[1]);
            if(it != man_.end())
            {
                WTextAtBegin(fd,"NAME: \n");
                WTextAtBegin(fd,"\t"+cmds[1]+","+man_[cmds[1]]["NAME"]+"\n");
                WTextAtBegin(fd,"SYNOPSIS: \n");
                WTextAtBegin(fd,"\t"+man_[cmds[1]]["SYNOPSIS"]+"\n");
                WTextAtBegin(fd,"OPTIONS: \n");
                WTextAtBegin(fd,man_[cmds[1]]["OPTIONS"]+"\n");
            }
            else
            {
                WTextAtBegin(fd,"command-arg:"+cmds[1]+" not exist\n");
            }
        }
    }
    else
        WTextAtBegin(fd,"command not found\n");
}
