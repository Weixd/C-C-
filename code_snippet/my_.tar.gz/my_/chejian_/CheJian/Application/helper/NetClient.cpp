#include "NetClient.h"
#include <fstream>

NetIoRet::NetIoRet()
{
    RetsetParams();
}

NetIoRet::~NetIoRet()
{

}

void NetIoRet::RetsetParams()
{
    szHttpHeader="";
    szHttpBody="";
    mapHeader.clear();
    headerLines.clear();
}

bool NetIoRet::IsSuccess()
{
    return (retCode == CURLE_OK);
}

void NetIoRet::StrSplit(std::vector<std::string>& lines,std::string sourceStr, std::string delims)
{
    std::string sub_string=sourceStr;
    auto n = sub_string.find(delims);
    while(n!=std::string::npos)
    {
        std::string tmp = sub_string.substr(0,n);
        if (tmp!="")
            lines.push_back(tmp);
        sub_string = sub_string.substr(n+delims.length());
        n = sub_string.find(delims);
    }
    if (sub_string!="")
        lines.push_back(sub_string);
}
std::string NetIoRet::GetHeaderValue(std::string name)
{
    if(headerLines.size()<=0)
        StrSplit(headerLines,szHttpHeader,"\r\n");
    if(headerLines.size()<=0)
        return "";
    if(mapHeader.size() <= 0)
    {
        for(auto str : headerLines)
        {
            std::vector<std::string> words;
            StrSplit(words,str,": ");
            if (words.size()==2)
                mapHeader[words[0]]=words[1];
        }
    }
    return mapHeader[name];
}

int NetIoRet::GetHttpStatusCode()
{
    if(headerLines.size()<=0)
        StrSplit(headerLines,szHttpHeader,"\r\n");
    if(headerLines.size()<=0)
        return 0;
    std::vector<std::string> words;
    StrSplit(words,headerLines[0]," ");
    if (words.size()>=2)
        return atoi(words[1].c_str());
    return 0;
}

void NetIoRet::SetFinishCode(CURLcode code)
{
    retCode=code;
    StrSplit(headerLines,szHttpHeader,"\r\n");
}

///////////////////////////////////////////////////////////////////////////////

size_t writer_string( void* ptr, size_t size, size_t nmemb, void* stream )
{
    std::string* content = (std::string*) stream;
    content->append((const char*) ptr, size * nmemb);
    return size * nmemb;
}
int cur_progress(void *clientp, double dltotal, double dlnow, double ultotal, double ulnow)
{
    (void)dltotal;(void)dlnow;(void)ultotal;(void)ulnow;
    NetClient* curl = static_cast<NetClient*>(clientp);
    if(curl->bTryStop_)
        return CURLE_ABORTED_BY_CALLBACK;
    return 0;
}
size_t writer_file(void* ptr, size_t size, size_t nmemb, void* stream)
{
    std::fstream* fws=(std::fstream*)stream;
    int seekb=int(fws->tellg());
    fws->write((const char*)ptr,nmemb*size);
    return int(fws->tellg())-seekb;
}
size_t read_file( void *ptr, size_t size, size_t nmemb, void *stream )
{
    std::fstream* frs =(std::fstream*)stream;
    frs->read((char*)ptr,size*nmemb);
    return frs->gcount();
}
NetClient::NetClient()
{
    pCurl_=NULL;
    slist_=NULL;;
    post_=NULL;
    lastPost_=NULL;
    bTryStop_=false;
}

NetClient::~NetClient()
{
    Stop();
}
void NetClient::Stop()
{
    bTryStop_=true;
    if (pCurl_)
    {
        curl_easy_cleanup(pCurl_);
        pCurl_=NULL;
    }
    if (slist_)
    {
        curl_slist_free_all(slist_);
        slist_=NULL;
    }
    if (lastPost_)
    {
        curl_formfree(lastPost_);
        lastPost_=NULL;
    }
    if (post_)
    {
        curl_formfree(post_);
        post_=NULL;
    }
}

void NetClient::SoftStop()
{
    bTryStop_=true;
}

bool NetClient::Init(std::string url,int connectTimeout, int opTimeout)
{
    Stop();
    bTryStop_=false;
    ioRet_.RetsetParams();
    pCurl_=curl_easy_init();
    if (!pCurl_)
        return false;
    curl_easy_reset(pCurl_);
    curl_easy_setopt(pCurl_, CURLOPT_URL,url.c_str());
    curl_easy_setopt(pCurl_, CURLOPT_HEADERFUNCTION, writer_string);
    curl_easy_setopt(pCurl_, CURLOPT_HEADERDATA, &ioRet_.szHttpHeader);
    curl_easy_setopt(pCurl_, CURLOPT_WRITEFUNCTION, writer_string);
    curl_easy_setopt(pCurl_, CURLOPT_WRITEDATA, &ioRet_.szHttpBody);
    curl_easy_setopt(pCurl_, CURLOPT_SSL_VERIFYPEER, 0);
    curl_easy_setopt(pCurl_, CURLOPT_SSL_VERIFYHOST, 0);
    curl_easy_setopt(pCurl_, CURLOPT_NOPROGRESS, 0);
    curl_easy_setopt(pCurl_, CURLOPT_PROGRESSFUNCTION,cur_progress);
    curl_easy_setopt(pCurl_, CURLOPT_PROGRESSDATA, this);
    curl_easy_setopt(pCurl_, CURLOPT_CONNECTTIMEOUT, connectTimeout);
    curl_easy_setopt(pCurl_, CURLOPT_TIMEOUT, opTimeout);
    return true;
}

void NetClient::AppendHeader(std::string name,std::string val)
{
    std::string _header;
    _header+=name;
    _header+=": ";
    _header+=val;
    slist_ =curl_slist_append(slist_,_header.c_str());
}

void NetClient::AppendForms(std::string name,std::string val)
{
    curl_formadd(&post_, &lastPost_, CURLFORM_COPYNAME, name.c_str(),CURLFORM_COPYCONTENTS, val.c_str(), CURLFORM_END);
}
bool NetClient::FtpDownload(std::string path,std::string uname, std::string passwd)
{

    std::fstream fws;
    fws.open(path.c_str(),std::ios::out|std::ios::binary|std::ios::trunc);
    if(!fws.is_open())
        return false;
    curl_easy_setopt(pCurl_, CURLOPT_USERPWD,(uname+":"+passwd).c_str());
    curl_easy_setopt(pCurl_, CURLOPT_WRITEFUNCTION, writer_file);
    curl_easy_setopt(pCurl_, CURLOPT_WRITEDATA, &fws);
    curl_easy_setopt(pCurl_, CURLOPT_VERBOSE, 1L);
    ioRet_.SetFinishCode(curl_easy_perform(pCurl_));
    fws.close();
    return ioRet_.IsSuccess();
}
bool NetClient::FtpUpload(std::string path,std::string uname,std::string passwd)
{
    std::fstream frs;
    frs.open(path.c_str(),std::ios::in|std::ios::binary);
    if(!frs.is_open())
        return false;
    curl_easy_setopt(pCurl_, CURLOPT_UPLOAD, 1L);
    curl_easy_setopt(pCurl_, CURLOPT_USERPWD,(uname+":"+passwd).c_str());
    curl_easy_setopt(pCurl_, CURLOPT_READFUNCTION,read_file);
    curl_easy_setopt(pCurl_, CURLOPT_READDATA, &frs);
    curl_easy_setopt(pCurl_, CURLOPT_VERBOSE, 1L);
    curl_easy_setopt(pCurl_, CURLOPT_FTPPORT, "-");
    curl_easy_setopt(pCurl_, CURLOPT_FTP_CREATE_MISSING_DIRS, 1L);
    ioRet_.SetFinishCode(curl_easy_perform(pCurl_));
    frs.close();
    return ioRet_.IsSuccess();
}
bool NetClient::UploadFile(std::string path)
{
    std::fstream frs;
    frs.open(path.c_str(),std::ios::in|std::ios::binary);
    if(!frs.is_open())
        return false;
    frs.seekg(0,std::ios::end);
    int flen=frs.tellg();
    frs.seekg(0,std::ios::beg);
    curl_easy_setopt(pCurl_, CURLOPT_UPLOAD, 1L);
    curl_easy_setopt(pCurl_, CURLOPT_PUT, 1L);
    slist_ = curl_slist_append(slist_, "Expect:");
    curl_easy_setopt(pCurl_,CURLOPT_HTTPHEADER,slist_);
    curl_easy_setopt(pCurl_, CURLOPT_READFUNCTION,read_file);
    curl_easy_setopt(pCurl_, CURLOPT_READDATA, &frs);
    curl_easy_setopt(pCurl_, CURLOPT_INFILESIZE_LARGE,flen);
    ioRet_.SetFinishCode(curl_easy_perform(pCurl_));
    frs.close();
    return ioRet_.IsSuccess();
}

bool NetClient::DownloadFile(std::string path)
{
    std::fstream fws;
    fws.open(path.c_str(),std::ios::out|std::ios::binary|std::ios::trunc);
    if(!fws.is_open())
        return false;
    curl_easy_setopt(pCurl_, CURLOPT_LOW_SPEED_LIMIT, 1L);
    curl_easy_setopt(pCurl_, CURLOPT_LOW_SPEED_TIME, 30L);
    curl_easy_setopt(pCurl_, CURLOPT_NOSIGNAL, 1);
    curl_easy_setopt(pCurl_, CURLOPT_FOLLOWLOCATION, 1);
    curl_easy_setopt(pCurl_, CURLOPT_HTTPGET, 1);
    curl_easy_setopt(pCurl_, CURLOPT_WRITEFUNCTION, writer_file);
    curl_easy_setopt(pCurl_, CURLOPT_WRITEDATA, &fws);
    slist_ = curl_slist_append(slist_, "Expect:");
    curl_easy_setopt(pCurl_, CURLOPT_HTTPHEADER, slist_);
    ioRet_.SetFinishCode(curl_easy_perform(pCurl_));
    fws.close();
    return ioRet_.IsSuccess();
}

bool NetClient::Get()
{
    curl_easy_setopt(pCurl_, CURLOPT_HTTPGET, 1);
    slist_ = curl_slist_append(slist_, "Expect:");
    curl_easy_setopt(pCurl_,CURLOPT_HTTPHEADER,slist_);
    ioRet_.SetFinishCode(curl_easy_perform(pCurl_));
    return ioRet_.IsSuccess();
}

bool NetClient::Post()
{
    slist_ = curl_slist_append(slist_, "Expect:");
    curl_easy_setopt(pCurl_,CURLOPT_HTTPHEADER,slist_);
    curl_easy_setopt(pCurl_, CURLOPT_HTTPPOST,post_);
    ioRet_.SetFinishCode(curl_easy_perform(pCurl_));
    return ioRet_.IsSuccess();
}

bool NetClient::Post(const char* data,int len,std::string contentType)
{
    AppendHeader("Content-Type",contentType);
    slist_ = curl_slist_append(slist_, "Expect:");
    curl_easy_setopt(pCurl_,CURLOPT_HTTPHEADER,slist_);
    curl_easy_setopt(pCurl_, CURLOPT_HTTPPOST,post_);
    curl_easy_setopt(pCurl_, CURLOPT_POSTFIELDS,data);
    curl_easy_setopt(pCurl_, CURLOPT_POSTFIELDSIZE,len);
    ioRet_.SetFinishCode(curl_easy_perform(pCurl_));
    return ioRet_.IsSuccess();
}
