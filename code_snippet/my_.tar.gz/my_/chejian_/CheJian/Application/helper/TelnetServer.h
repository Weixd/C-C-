#ifndef TELNETSERVER_H
#define TELNETSERVER_H
#include <string>
#include <memory>
#include <map>
#include <mutex>
#include <thread>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <functional>
#include <vector>
#include <deque>
#include <algorithm>

#define CMD_BUF_SIZE 16*1024

struct ThreadGlobal
{
    bool bHadQuery_;
    std::map<std::string,std::vector<std::string>> conditions_;
    std::map<std::string,std::map<std::string,long long>> properyMap_;
    std::map<std::string,std::map<std::string,long long>> propery_jyjgMap_;
    std::map<std::string,std::map<std::string,std::map<std::string,long long>>> jyjgbh_tplx_jyjgMap_;
    std::deque<std::string> cmdHistory_;
    ThreadGlobal()
    {
        ReSet();
    }
    void AddCmdHistory(std::string cmd)
    {
        if(cmd=="")
            return;
        auto it=std::find(cmdHistory_.begin(),cmdHistory_.end(),cmd);
        if(it!=cmdHistory_.end())
        {
            cmdHistory_.erase(it);
            cmdHistory_.push_front(cmd);
        }
        else
            cmdHistory_.push_front(cmd);
    }
    void ReSet()
    {
        conditions_.clear();
        bHadQuery_=false;
        ReSetStat();
    }
    void ReSetStat()
    {
        bHadQuery_=false;
        properyMap_.clear();
        propery_jyjgMap_.clear();
        jyjgbh_tplx_jyjgMap_.clear();
    }
};
class vehicle_check_service;
class TelnetServer
{
public:
    TelnetServer();
    virtual ~TelnetServer();
public:
    bool Run(vehicle_check_service* pService,int port);
    void Stop();
    void ProcessCommand(int fd,std::vector<std::string>& cmds,ThreadGlobal& tg);
    int WriteData(int sockfd,std::string str);
    int WriteData(int sockfd,char* data,int len);
    int WTextAtBegin(int sockfd,std::string str);
    bool ReadCmdLine(int sockfd, char *cmdLine,bool bLogin,ThreadGlobal& tg);
    static void ServAccept(TelnetServer* pts);
    static void TelnetSession(TelnetServer* pts,int fd);
public:
    vehicle_check_service* pService_;
    bool bRun_;
    int servFd_;
    std::shared_ptr<std::thread> acceptTh_;
    std::mutex clntsMutex_;
    std::map<int,std::shared_ptr<std::thread>> clnts;
    std::map<std::string,std::map<std::string,std::string>> man_;
    std::vector<std::string> supportCondPropery;
    std::vector<std::string> supportStatPropery;
};

#endif
