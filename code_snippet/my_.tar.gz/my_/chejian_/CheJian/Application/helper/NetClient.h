#ifndef NetClient_H
#define NetClient_H
#include <map>
#include <vector>
#include <string>
#include "../curl/curl.h"

class NetIoRet
{
public:
    NetIoRet();
    virtual ~NetIoRet();
    void RetsetParams();
    bool IsSuccess();
    std::string GetHeaderValue(std::string name);
    int GetHttpStatusCode();
    CURLcode GetCulCode(){ return retCode; }
    void SetFinishCode(CURLcode code);
protected:
    void StrSplit(std::vector<std::string>& lines,std::string sourceStr, std::string delims);
public:
    std::string szHttpHeader;
    std::string szHttpBody;
private:
    std::map<std::string,std::string> mapHeader;
    std::vector<std::string> headerLines;
    CURLcode retCode;
};

class NetClient
{
public:
    NetClient();
    virtual ~NetClient();

    bool Init(std::string url,int connectTimeout=20,int opTimeout=20);
    void AppendHeader(std::string name,std::string val);
    void AppendForms(std::string name,std::string val);
    bool FtpDownload(std::string path,std::string uname,std::string passwd);
    bool FtpUpload(std::string path,std::string uname,std::string passwd);
    bool UploadFile(std::string path);
    bool DownloadFile(std::string path);
    bool Get();
    bool Post();
    bool Post(const char* data,int len,std::string contentType="application/json");
    void Stop();
    void SoftStop();
public:
    NetIoRet ioRet_;
    bool bTryStop_;
protected:
    CURL* pCurl_;
    curl_slist* slist_;
    curl_httppost* post_;
    curl_httppost* lastPost_;
};

#endif
