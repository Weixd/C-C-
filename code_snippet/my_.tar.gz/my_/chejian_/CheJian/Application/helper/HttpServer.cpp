#include "HttpServer.h"
#include <event.h>
#include <evhttp.h>
#include <event2/thread.h>
#include <cstring>
#include <iostream>
#ifdef __linux
#include <unistd.h>
#endif
#include <memory>
#include <stdlib.h>
#include <fcntl.h>
#include <iostream>
#include "../HelperFile.h"
#include "../HelperString.h"

void HttpServerHandler(struct evhttp_request* req, void* arg)
{
    Worker* worker=(Worker*)arg;
    const char* uri=evhttp_request_uri(req);
    std::string cleanUrl="",valueString="";
    struct evkeyvalq *headers;
    struct evkeyval *header;
    Worker::HTTP_METHOD method = Worker::EV_UNKNOWN;
    std::map<std::string,std::string> nameVals;
    char* decoded_uri=evhttp_decode_uri(uri);
    std::string decodeUri=decoded_uri;
    free(decoded_uri);

    switch (evhttp_request_get_command(req))
    {
    case EVHTTP_REQ_GET: method = Worker::EV_GET; break;
    case EVHTTP_REQ_POST: method = Worker::EV_POST; break;
    case EVHTTP_REQ_HEAD: method = Worker::EV_HEAD; break;
    case EVHTTP_REQ_PUT: method = Worker::EV_PUT; break;
    case EVHTTP_REQ_DELETE: method = Worker::EV_DELETE; break;
    case EVHTTP_REQ_OPTIONS: method = Worker::EV_OPTIONS; break;
    case EVHTTP_REQ_TRACE: method = Worker::EV_TRACE; break;
    case EVHTTP_REQ_CONNECT: method = Worker::EV_CONNECT; break;
    case EVHTTP_REQ_PATCH: method = Worker::EV_PATCH; break;
    default: method = Worker::EV_UNKNOWN; break;
    }

    headers = evhttp_request_get_input_headers(req);
    for (header = headers->tqh_first; header;
         header = header->next.tqe_next)
    {
        nameVals[header->key]=header->value;
    }

    char* post_data=(char *)EVBUFFER_DATA(req->input_buffer);
    if(post_data)
        valueString=post_data;
    std::string::size_type pos=decodeUri.find('?');
    if(pos != std::string::npos)
    {
        cleanUrl=decodeUri.substr(0,pos);
        if(valueString == "")
            valueString=decodeUri.substr(pos+1);
        else
            valueString+="&"+decodeUri.substr(pos+1);
    }
    else
        cleanUrl=decodeUri;

    std::vector<std::string> pairs;
    hl::strsplit(pairs,valueString,"&");
    for(auto str:pairs)
    {
        std::vector<std::string> pair;
        hl::strsplit(pair,str,"=");
        if(pair.size()==2)
            nameVals[pair[0]]=pair[1];
    }

    int RESPONS_CODE=HTTP_NOTFOUND;
    std::string ostr="";
    std::string opath="";
    int ofd=-1;
    struct stat st;
    std::map<std::string,ROUTE_FUNCTION_TYPE>::iterator it=worker->serv_->router_.find(cleanUrl);
    if(it!=worker->serv_->router_.end())
    {
        it->second(method,nameVals,ostr,opath);
        if(opath != "")
        {
            const char *type = guess_content_type(decoded_path);
            if ((fd = open(whole_path, O_RDONLY)) < 0) {
                perror("open");
                goto err;
            }

            if (fstat(fd, &st)<0) {
                /* Make sure the length still matches, now that we
                                     * opened the file :/ */
                perror("fstat");
                goto err;
            }
            evhttp_add_header(evhttp_request_get_output_headers(req),
                              "Content-Type", type);
            evbuffer_add_file(evb, fd, 0, st.st_size);
        }
        RESPONS_CODE=HTTP_OK;
    }
    else
    {
        responseStr="NOT FOUND!!!";
        RESPONS_CODE=HTTP_NOTFOUND;
    }
    evhttp_add_header(req->output_headers, "Server", "myhttpserver v 0.0.1");
    evhttp_add_header(req->output_headers, "Content-Type", "text/plain; charset=UTF-8");
    evhttp_add_header(req->output_headers, "Connection", "close");
    struct evbuffer* buf = evbuffer_new();
    evbuffer_add_printf(buf, "%s", responseStr.c_str());
    evhttp_send_reply(req, RESPONS_CODE, "OK", buf);
    evbuffer_free(buf);
}

void HttpExitHandler(evutil_socket_t fd, short events, void* arg)
{
    Worker* hs = (Worker*)arg;
    hs->Exit();
}

Worker::Worker()
{
    
}

Worker::~Worker()
{

}

bool Worker::Init(HttpServer* serv,int fd)
{
    bool retBool=false;
    serv_=serv;
#ifdef __linux
    if(evutil_socketpair(AF_UNIX, SOCK_STREAM, 0, exitSocks_) < 0)
        return false;
#else
    if(evutil_socketpair(AF_INET, SOCK_STREAM, 0, exitSocks_) < 0)
        return false;
#endif
    evutil_make_socket_nonblocking(exitSocks_[0]);
    evutil_make_socket_nonblocking(exitSocks_[1]);
    base_ = event_base_new();
    evHttpServ_ = evhttp_new(base_);
    if (evHttpServ_)
    {
        if(evhttp_accept_socket(evHttpServ_, fd) == 0)
        {
            evhttp_set_gencb(evHttpServ_, HttpServerHandler, (void*)this);
            exitEv_ = event_new(base_, exitSocks_[0], EV_READ|EV_PERSIST, HttpExitHandler, (void*)this);
            event_add(exitEv_, NULL);
            retBool=true;
        }
        else
        {
            evhttp_free(evHttpServ_);
            event_base_free(base_);
        }
    }
    else
    {
        event_base_free(base_);
    }
    return retBool;
}

void Worker::Run()
{
    event_base_dispatch(base_);
    event_free(exitEv_);
    evhttp_free(evHttpServ_);
    event_base_free(base_);
    close(exitSocks_[0]);
    close(exitSocks_[1]);
}

void Worker::Stop()
{
    char buf[1] = {'-'};
    send(exitSocks_[1], buf, 1,0);
}

void Worker::Exit()
{
    if(base_)
        event_base_loopexit(base_,0);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
#define _MIN_(a, b) (a)>=(b)?(b):(a)
#define _MAX_(a, b) (a)>=(b)?(a):(b)

HttpServer::HttpServer()
{
    port_ = 80;
    workers_n_=10;
    fd_=-1;
#if __linux
    evthread_use_pthreads();
#else
    WSADATA WSAData;
    WSAStartup(MAKEWORD(1, 1), &WSAData);
    evthread_use_windows_threads();
#endif
}

HttpServer::~HttpServer()
{
#ifndef __linux
    WSACleanup();
#endif
}

bool HttpServer::RunAndLoop(int port,int workerNum)
{
    port_=port;
    workers_n_ = _MIN_(_MAX_(workerNum, 1), 100);

    fd_ = socket(AF_INET, SOCK_STREAM, 0);
    if (fd_ < 0)
        return false;
    int one = 1;
    int r = setsockopt(fd_, SOL_SOCKET, SO_REUSEADDR, (char *)&one, sizeof(int));

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons(port_);

    r = bind(fd_, (struct sockaddr*)&addr, sizeof(addr));
    if (r < 0)
        return false;
    r = listen(fd_, 1024);
    if (r < 0)
        return false;

#ifdef __linux
    int flags;
    if ((flags = fcntl(fd_, F_GETFL, 0)) < 0 || fcntl(fd_, F_SETFL, flags | O_NONBLOCK) < 0)
        return false;
#else
    unsigned long flags = 1;
    ioctlsocket(nfd, FIONBIO, &flags);
#endif

    for(int i=0; i<workers_n_; i++)
    {
        if(workers_[i].Init(this,fd_))
            worker_threads_.push_back(std::shared_ptr<std::thread>(new std::thread(&Worker::Run, &workers_[i])));
        else
            return false;
    }

    return true;
}

void HttpServer::Stop()
{
    for(int i=0; i<workers_n_; i++)
        workers_[i].Stop();
    close(fd_);
    for(auto& t:worker_threads_)
        t->join();
}

void HttpServer::AddRouter(std::string path,ROUTE_FUNCTION_TYPE cb)
{
    router_[path]=cb;
}
