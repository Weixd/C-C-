#ifndef GLOGHELPER_H
#define GLOGHELPER_H
#include <thread>

class GLogHelper
{
public:
    enum LogLever
    {
        INFO=0,
        WARNING,
        ERROR,
        FATAL
    };
    GLogHelper();
    virtual ~GLogHelper();
    void ThreadFunc();
    void SetMaxLogSizeMb(int mb);
    void SetStdLevel(LogLever level);
    void SetPreservLogFileNum(int logFileNum);
private:
    std::thread* th_;
    bool running_;
    int logNum_;
};

#endif
