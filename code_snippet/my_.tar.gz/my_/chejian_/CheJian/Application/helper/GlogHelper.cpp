#include "GlogHelper.h"
#include "../glog/logging.h"
#include "HelperFile.h"
#include <functional>
#include <algorithm>
#include <chrono>
#include "../trace_log.h"

using namespace std::chrono;

GLogHelper::GLogHelper()
{
    hl::creatdir(hl::ownerfolder()+"log/info/");
    hl::creatdir(hl::ownerfolder()+"log/warning/");
    hl::creatdir(hl::ownerfolder()+"log/error/");
    char path[1024]={0};
    readlink("/proc/self/exe", path, 1024);
    google::InitGoogleLogging(path);
    google::SetLogDestination(google::GLOG_INFO, "log/info/info_");
    google::SetLogDestination(google::GLOG_WARNING, "log/warning/warning_");
    google::SetLogDestination(google::GLOG_ERROR,"log/error/error_");
    google::SetStderrLogging(google::GLOG_INFO);
    FLAGS_colorlogtostderr = true;
    FLAGS_logbufsecs = 0;
    FLAGS_max_log_size = 10;
    FLAGS_stop_logging_if_full_disk = true;
    logNum_=30;
    running_=true;
    th_=new std::thread(std::bind(&GLogHelper::ThreadFunc, this));
}

void GLogHelper::SetMaxLogSizeMb(int mb)
{
    FLAGS_max_log_size = mb;
}

void GLogHelper::SetPreservLogFileNum(int logFileNum)
{
    if(logFileNum >0)
        logNum_=logFileNum;
}

void GLogHelper::SetStdLevel(LogLever level)
{
    if(level == INFO)
        google::SetStderrLogging(google::GLOG_INFO);
    else if(level == WARNING)
        google::SetStderrLogging(google::GLOG_WARNING);
    else if(level == ERROR)
        google::SetStderrLogging(google::GLOG_ERROR);
    else
        google::SetStderrLogging(google::GLOG_FATAL);
}

GLogHelper::~GLogHelper()
{
    running_=false;
    if(th_)
    {
        th_->join();
        delete th_;
    }
    google::ShutdownGoogleLogging();
}

bool sort_by_datetime_asc(std::string& p1, std::string& p2)
{
    return hl::file_modify_time(p1)<hl::file_modify_time(p2);
}

void delete_more_file(std::string dir,int logNum)
{
    std::vector<std::string> paths;
    hl::enumfiles_all(dir,paths);
    std::sort(paths.begin(),paths.end(),sort_by_datetime_asc);
    for (int i = 0; i < (int(paths.size()) - logNum); i++)
        hl::delpath(paths[i]);
}

void GLogHelper::ThreadFunc()
{
    system_clock::time_point tick = system_clock::now() - std::chrono::hours(2);
    while (running_)
    {
        if (duration<double, std::milli>(system_clock::now() - tick).count() > 3600*1000)
        {
            DATA_PRINT(LEVEL_INFO, "start log clean ...... \n");
            delete_more_file(hl::ownerfolder()+"log/info/",logNum_);
            delete_more_file(hl::ownerfolder()+"log/warning/",logNum_);
            delete_more_file(hl::ownerfolder()+"log/error/",logNum_);
            tick = system_clock::now();
        }

        std::this_thread::sleep_for(std::chrono::seconds(1));
    }
}
