#pragma once

#include <string>
#include <vector>

#include "TimeRecord.h"

using namespace std;

struct _photo_resource
{
    string zptype;
    string zpurl;
    string zpid;
    string local_path;
#ifdef DEMO_TEST
    string demo_local_path = "TBD";
#endif
};

struct _video_resource
{
    string id;
    string sptype;
    string spzl;
    string dzzl;
    string spurl;
    string name;
    string local_path;
#ifdef DEMO_TEST
    string demo_local_path = "TBD";
#endif
};

struct _dbbhg_list
{
    string zptype;
    string dbbhg_desc;
    string zpid;
    string dbresult;
};

struct _item_desc
{
    const char *name_desc;
    const char *name_tag;
    void *value;
};

class vehicle_inf
{
    /* 以下字段不需要由主机发给从机 */
public:
    TimeRecord timeRecord;
    bool AlgorithmCheck = false;            /* 本条车辆数据是否经过算法处理 */
    int b_jqxdzbd = 2;
    std::string dzjqxbhgyy = "";                  /* 宁波 较强险不合格原因  */
    std::string m_dzjqxbhgyy = "";          /* 电子交强险不合格原因  */
    int m_jqxdzbd = 2;                      /* 电子交强险状态 2. 未查到保单 3. 保单不通过*/
    std::string BaoDing_J_FTP = "TBD";      /* "保定"车架号拓印膜档案照片 */
    bool b_xianning_wrw_pass = true;       // 咸宁污染物通过一张就算过
    bool ten_year=false;
    bool is_black_list=false;               /* 宁波外blacklist */
    bool is_waisheng=false;                 /* 外省车标记 */
    bool is_beimian=false;                  /* 宁波查验背面标记 */
    bool is_new_vehicle = false;
    unsigned int insurance_result = 2;      /* 临沂，电子保单数据库查询结果：0--不通过，1--通过，2--未查到 */

    bool is_chepai_off = false; //天津oracle免检车牌
    bool is_video_check = false; //视频检验标记
    std::string vehicle_check_video_id = "无数据";//视频审核id号与主表关联
    /*
    保定电子检验报告，判定结果。
    0--通过
    1--没有电子检验报告
    2--电子检验报告不合格
    3--电子检验报告数据库无法访问
    */
    unsigned int BaoDing_JYBG = 0;

    /*
    保定电子仪器检测结果。
    0--通过
    1--没有仪器检测结果
    2--仪器检测结果不合格
    3--仪器检测数据库无法访问
    */
    unsigned int BaoDing_YQ = 0;

    bool dz_wq_pass;                        /* 苏州电子环保单 */
    string dz_wqjcrq;
    bool is_dz_wq;

    string m_strZqfCheBiao = "";
    string m_strYhfCheBiao = "";
    string m_strZuoFangCheBiao = "";
    bool is_video_check_shizhong = false;   /*宜春事中视频审核标识*/

public:
	vector<_item_desc> item_description;

    string m_jylsh = "无数据";
    string m_jyjgbh = "无数据";
    string m_jylb = "无数据";
    string m_hpzl = "无数据";
    string m_hphm = "无数据";
    string m_clsbdh = "无数据";
    string m_syr = "无数据";
    string m_sjhm = "无数据";
    string m_sxrq = "无数据";
    string m_zzrq = "无数据";
    string m_cllx = "无数据";
    string m_syxz = "无数据";
    string m_zbzl = "无数据";
    string m_kssj = "无数据";
    string m_jssj = "无数据";
    string m_fdjh = "无数据";
    string m_clpp1 = "无数据";
    string m_clxh = "无数据";
    string m_ccdjrq = "无数据";
    string m_ccrq = "无数据";
    string m_wgjcjyy = "无数据";
    string m_xszbh = "无数据";
    string m_fzrq = "无数据";
    string m_rlzl = "无数据";
    string m_csys = "无数据";
    string m_pl = "无数据";
    string m_gl = "无数据";
    string m_zxxs = "无数据";
    string m_cwkc = "无数据";
    string m_cwkk = "无数据";
    string m_cwkg = "无数据";
    string m_hxnbcd = "无数据";
    string m_hxnbkd = "无数据";
    string m_hxnbgd = "无数据";
    string m_gbthps = "无数据";
    string m_zs = "无数据";
    string m_zj = "无数据";
    string m_qlj = "无数据";
    string m_hlj = "无数据";
    string m_ltgg = "无数据";
    string m_lts = "无数据";
    string m_zzl = "无数据";
    string m_hdzzl = "无数据";
    string m_hdzk = "无数据";
    string m_zqyzl = "无数据";
    string m_qpzk = "无数据";
    string m_hpzk = "无数据";
    string m_clyt = "无数据";
    string m_ytsx = "无数据";
    string m_sfxny = "无数据";
    string m_xnyzl = "无数据";
    string m_zpzs = "无数据";
    string m_spzs = "无数据";
	vector<_photo_resource> m_ckdbzplist;
	vector<_photo_resource> m_zplist;
	vector<_video_resource> m_splist;
    string m_dbbhgs = "0";
	vector<_dbbhg_list> m_dbbhglist;

    std::string m_yxqz = "无数据";
    std::string m_fzjg = "无数据";
    std::string m_hbdbqk = "无数据";
    std::string m_qzbfqz = "无数据";
    std::string m_xzqh = "无数据";
    std::string m_gcjk = "无数据";
    std::string m_dybj = "无数据";
    std::string m_zzg = "无数据";
    std::string m_clpp2 = "无数据";
    std::string m_jyhgbzbh = "无数据";
    std::string m_sfmj = "无数据";
    std::string m_zt = "无数据";
    std::string m_djrq = "无数据";
    std::string m_zsxzqh = "无数据";
    std::string m_zzxzqh = "无数据";
    std::string m_fdjxh = "无数据";
    std::string m_sgcssbwqk = "无数据";
    std::string m_bmjyy = "无数据";
    std::string m_glbm = "无数据";
    std::string m_zzcmc = "无数据";
    std::string m_jylsh2 = "无数据";
    //std::string vehicle_check_video_id = "无数据";
    bool m_b_ip = false;  // 在检测站内？
    bool m_video_down = true;// 视频下载完成？
    bool m_b_zqf_checked  = false;
    bool m_b_yhf_checked  = false;
    bool m_b_yz_checked   = false;
    bool m_b_ez_checked   = false;
    bool m_b_zdg_checked  = false;
    bool m_b_ydg_checked  = false;
    bool m_b_dp_checked   = false;
    bool m_b_dtks_checked = false;
    bool m_b_dtjs_checked = false;
    bool m_b_dggw_checked = false;
    bool m_b_dpdt_checked = false;
    bool m_b_zczd_checked = false;
#ifdef DEMO_TEST
    std::string demo_sqlString;
    std::string demo_sqlString0;
#endif

    std::string m_isPass = "无数据";
    std::string m_deviceId = "0";

public:
    
	vehicle_inf()
	{
		_item_desc _item_description[] = {
            /*0*/{ "检验流水号", ("lsh"), &m_jylsh },     /* 这个实际上是流水号lsh */
            /*1*/{ "检验机构编号", ("jyjgbh"), &m_jyjgbh },
            /*2*/{ "检验类别", ("jylb"), &m_jylb },
            /*3*/{ "号牌种类", ("hpzl"), &m_hpzl },
            /*4*/{ "号牌号码", ("hphm"), &m_hphm },
            /*5*/{ "车辆识别代号", ("clsbdh"), &m_clsbdh },
            /*6*/{ "使用人", ("syr"), &m_syr },
            /*7*/{ "手机号码", ("sjhm"), &m_sjhm },     /* SOAP接口没有该字段（2018-04-28） */
            /*8*/{ "生效日期", ("sxrq"), &m_sxrq },
            /*9*/{ "终止日期", ("zzrq"), &m_zzrq },
            /*10*/{ "车辆类型", ("cllx"), &m_cllx },
            /*11*/{ "使用性质", ("syxz"), &m_syxz },
            /*12*/{ "整备质量", ("zbzl"), &m_zbzl },
            /*13*/{ "检验开始时间", ("kssj"), &m_kssj },
            /*14*/{ "检验结束时间", ("jssj"), &m_jssj },
            /*15*/{ "发动机/电动机号码", ("fdjh"), &m_fdjh },
            /*16*/{ "车辆品牌", ("clpp1"), &m_clpp1 },
            /*17*/{ "车辆型号", ("clxh"), &m_clxh },
            /*18*/{ "初次登记日期", ("ccdjrq"), &m_ccdjrq },
            /*19*/{ "出厂日期", ("ccrq"), &m_ccrq },
            /*20*/{ "车辆外观检验员", ("wgjcjyy"), &m_wgjcjyy },
            /*21*/{ "行驶证编号", ("xszbh"), &m_xszbh },
            /*22*/{ "行驶证发证日期", ("fzrq"), &m_fzrq },
            /*23*/{ "燃料种类", ("rlzl"), &m_rlzl },
            /*24*/{ "需要对比照片总数", ("zpzs"), &m_zpzs },
            /*25*/{ "参考对比照片列表", ("ckdbzplist"), &m_ckdbzplist },
            /*26*/{ "需要对比照片列表", ("zplist"), &m_zplist },
            /*27*/{ "需要对比视频总数", ("spzs"), &m_spzs },
            /*28*/{ "需要对比视频列表", ("splist"), &m_splist },
            /*29*/{ "对比不合格数", ("dbbhgs"), &m_dbbhgs },
            /*30*/{ "对比不合格明细", ("dbbhglist"), &m_dbbhglist },
            /*31*/{"车身颜色", ("csys"), &m_csys },
            /*32*/{"排量", ("pl"), &m_pl },
            /*33*/{"功率", ("gl"), &m_gl },
            /*34*/{"转向形式", ("zxxs"), &m_zxxs },
            /*35*/{"车外廓长", ("cwkc"), &m_cwkc },
            /*36*/{"车外廓宽", ("cwkk"), &m_cwkk },
            /*37*/{"车外廓高", ("cwkg"), &m_cwkg },
            /*38*/{"货箱内部长度", ("hxnbcd"), &m_hxnbcd },
            /*39*/{"货箱内部宽度", ("hxnbkd"), &m_hxnbkd },
            /*40*/{"货箱内部高度", ("hxnbgd"), &m_hxnbgd },
            /*41*/{"钢板弹簧片数", ("gbthps"), &m_gbthps },
            /*42*/{"轴数", ("zs"), &m_zs },
            /*43*/{"轴距", ("zj"), &m_zj },
            /*44*/{"前轮距", ("qlj"), &m_qlj },
            /*45*/{"后轮距", ("hlj"), &m_hlj },
            /*46*/{"轮胎规格", ("ltgg"), &m_ltgg },
            /*47*/{"轮胎数", ("lts"), &m_lts },
            /*48*/{"总质量", ("zzl"), &m_zzl },
            /*49*/{"核定载质量", ("hdzzl"), &m_hdzzl },
            /*50*/{"核定载客", ("hdzk"), &m_hdzk },
            /*51*/{"准牵引质量", ("zqyzl"), &m_zqyzl },
            /*52*/{"驾驶室前排载客人数", ("qpzk"), &m_qpzk },
            /*53*/{"驾驶室后排载客人数", ("hpzk"), &m_hpzk },
            /*54*/{"车辆用途", ("clyt"), &m_clyt },
            /*55*/{"用途属性", ("ytsx"), &m_ytsx },
            /*56*/{"是否新能源汽车", ("sfxny"), &m_sfxny },
            /*57*/{"新能源种类", ("xnyzl"), &m_xnyzl },

            /*58*/{"检验有效期止", ("yxqz"), &m_yxqz },
            /*59*/{"发证机关", ("fzjg"), &m_fzjg },
            /*60*/{"环保达标情况", ("hbdbqk"), &m_hbdbqk },
            /*61*/{"强制报废期止", ("qzbfqz"), &m_qzbfqz },
            /*62*/{"管理辖区", ("xzqh"), &m_xzqh },
            /*63*/{"国产/进口", ("gcjk"), &m_gcjk },
            /*64*/{"抵押标记", ("dybj"), &m_dybj },
            /*65*/{"制造国", ("zzg"), &m_zzg },
            /*66*/{"英文品牌", ("clpp2"), &m_clpp2 },
            /*67*/{"检验合格标志", ("jyhgbzbh"), &m_jyhgbzbh },
            /*68*/{"是否免检", ("sfmj"), &m_sfmj },
            /*69*/{"机动车状态", ("zt"), &m_zt },
            /*70*/{"最近定检日期", ("djrq"), &m_djrq },
            /*71*/{"住所地址行政区划", ("zsxzqh"), &m_zsxzqh },
            /*72*/{"联系地址行政区划", ("zzxzqh"), &m_zzxzqh },
            /*73*/{"发动机型号", ("fdjxh"), &m_fdjxh },
            /*74*/{"事故车损伤部位情况", ("sgcssbwqk"), &m_sgcssbwqk },
            /*75*/{"不免检原因", ("bmjyy"), &m_bmjyy },
            /*76*/{"管理部门", ("glbm"), &m_glbm },
            /*77*/{"制造厂名称", ("zzcmc"), &m_zzcmc },
            /*78*/{"检验流水号(real)", ("jylsh"), &m_jylsh2 },   /* 这个是真正的检验流水号jylsh */
            ///*79*/{"车辆主表ID", ("vehicle_check_video_id"), &vehicle_check_video_id },

        };

        /* 主机分配给从机的数据和需要写入数据库的数据，都要加入到item_description中 */
        for (int i = 0; i < 79; i++) {
			item_description.push_back(_item_description[i]);
        }
	}

	~vehicle_inf()
	{
		item_description.clear();
		m_ckdbzplist.clear();
        m_zplist.clear();
        m_splist.clear();
		m_dbbhglist.clear();
	}
public:
    inline unsigned short get_count(void) { return m_xsz_pass_count; }
    inline void set_count(unsigned short us_num) { this->m_xsz_pass_count = us_num; }
    inline void set_count_add_num(unsigned short us_num) { this->m_xsz_pass_count += us_num; }

private:
    unsigned int m_xsz_pass_count = 0;  // 存储焦作行驶证通过项数
};



class video_inf
{
public:

	vector<_item_desc> item_description;
    string v_jylsh= "无数据";
    string v_jyjgbh= "无数据";
    string v_hphm= "无数据";
    string v_clsbdh= "无数据";
    string v_cllx= "无数据";
    string v_txxlh= "无数据";
    string v_message= "无数据";
    string v_rownum= "无数据";
	vector<_video_resource> v_splist;


public:
	video_inf()
	{
		_item_desc _item_description[] = {
			/*1*/{"检验流水号", ("jylsh"), &v_jylsh },
            /*2*/{"检验机构编号", ("jyjgbh"), &v_jyjgbh },
            /*3*/{"号牌号码", ("hphm"), &v_hphm },
            /*4*/{"车辆识别代号", ("clsbdh"), &v_clsbdh },
            /*5*/{"车辆类型", ("cllx"), &v_cllx },
            /*6*/{"通信序列号", ("txxlh"), &v_txxlh },
            /*7*/{"信息", ("message"), &v_message },
            /*8*/{"条目数", ("rownum"), &v_rownum },
		};
			for (int i = 0; i < 8; i++)
				item_description.push_back(_item_description[i]);
	}
	~video_inf()
	{
		item_description.clear();
		v_splist.clear();
	}
};

