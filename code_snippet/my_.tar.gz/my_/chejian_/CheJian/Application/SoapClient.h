#ifndef _SOAPCLIENT_
#define _SOAPCLIENT_
#include "vehicle_inf.h"
#include <string>
#include <ctime>
#include <vector>


using namespace std;

class  SoapClient {
public:
	SoapClient();
	~SoapClient();

	bool isTokenValid();
	void getToken(std::string IP, std::string MAC_Address);
	bool get_vehicle_adr(vehicle_inf* vehicle);
	bool out_result(std::string xml_result);
	std::string encode(std::string data);

	
private:
	std::string SHIPIN_URI;
	static std::string token;
	static std::time_t token_start;

private:
	std::string SOAP_BodyPackage(std::string data);
	std::vector<std::string> get_clsbdh_FromReply(std::string reply);
	bool get_vehicle_FromReply(std::string reply, vehicle_inf *vehicle);
	std::string XML_code_EntityReference(std::string data);
	std::string XML_decode_EntityReference(std::string data);
	std::string BackslashToSlash(std::string data);
};

#endif // _SOAPCLIENT_
