#include "trace_log.h"
#include <event2/event.h> 
#include <event2/buffer.h> 
#include <event2/http.h>
#include <event2/http_struct.h>
#include <event2/keyvalq_struct.h>

#include <string>
using namespace std;
#define REQUEST_SOAP_FLAG               3
#define REQUEST_POST_FLAG               EVHTTP_REQ_POST
#define REQUEST_GET_FLAG                EVHTTP_REQ_GET

#pragma once
class HttpClient
{
public:
	struct evhttp_uri *m_uri;
	struct event_base *base;
	int m_request_flag;
	int m_request_text_type;
	struct evhttp_connection *m_connection;
	struct evhttp_request *m_httpreq;
    char *m_content_type ;
	char *m_post_data;
    std::string m_photo_filename;
    std::string m_photo_fileid;
    std::string m_demo_filename;
    std::string ResponseData;
    std::string m_video_filename;
    bool d_success_flag;
	std::string filename;
    std::string m_photo_filepath;
    char *m_soap_action;

public:
    HttpClient();
	BOOL InitData(const char *uri, int request_flag, char* content_type, char *data);
    bool init_data(const char *uri, int request_flag, char* content_type, char *data, char *soap_action = NULL);
	~HttpClient();
    BOOL startHttpClient(std::string filename="TBD");
	void http_request_free();
	int start_url_request();
    bool start_bdurl_request();
	BOOL Save_PhotoData_To_LocalFile(unsigned char* data, unsigned int f_length);
    bool Save_bd_PhotoData_To_LocalFile(unsigned char* data, unsigned int f_length);
    BOOL SaveHostCheckItemXML(unsigned char* data,unsigned int length);
    bool SaveHostXML(unsigned char* data,unsigned int length);
    void set_retries_timeout(int retries, int timeout);
    BOOL Save_VideoData_To_LocalFile(unsigned char *data, unsigned int f_length);
    void parsexmldata(std::string &src,std::string &dst);
    bool getparsexmldata(std::string &src);
    std::string Decode(const unsigned char *Data, unsigned int DataByte);
    bool isValidData(const unsigned char *Data, unsigned int DataByte);

private:
    int m_retries; /* 该值会传递给evhttp_connection_set_retries */
    int m_timeout; /* 该值会传递给evhttp_connection_set_timeout */
};

