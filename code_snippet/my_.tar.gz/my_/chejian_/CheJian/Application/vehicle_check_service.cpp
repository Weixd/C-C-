//#include "afx.h"
#include "vehicle_check_service.h"
#include "BlockQueue.h"
#include "http_res_def.h"
#include "Markup.h"
#include "trace_log.h"
#include "soapTmriOutAccessSoapBindingProxy.h"
#include "check_item.h"
#include "SoapClient.h"
#include "Ftp_download.h"
#include "MySQL_DB.h"
#include <ctime>
#include <iostream>
#include <vector>
#include <string>
#include <sys/stat.h>
#include <sys/statfs.h>
#include <unistd.h>
#include <dirent.h>
#include <stdlib.h>
#include <stdio.h>
#include "./helper/HelperFile.h"
//#include <io.h>

#include "soapTmriOutAccessSoapBindingProxy.h"
#include "check_item.h"
#include "ResultCollection.h"
#include "ftplib.h"
#include "occi_wrap.h"
#include "nvml.h"
#include "Customization.h"
#include "ispass.h"
#include "AlgProcess/base/processbaseclass.h"
#include "AlgProcess/webserver/webserver.h"


//#include <shlwapi.h>
//#pragma comment(lib, "shlwapi.lib")
extern std::string demo_sqlString, demo_sqlString0;
extern std::string g_jqxbd_result;
extern std::string g_soap_token;
extern int g_timelimit;
extern std::string g_localServerIp;
extern std::string LocalMac;
extern bool g_group_response;
extern int g_photoKeepMonths;
extern int g_videoKeepDays;
extern int g_diskPreserveSizeG;
extern std::string g_version;
extern unsigned int g_DownloadLimit;
extern std::string g_QueryNumber;
extern unsigned int g_QueryInterval;
extern bool g_Interface;
extern bool g_3rdInterface;
extern bool g_TestMode;
extern BlockingQueue<vehicle_inf *> binzhou_download_queue;
extern std::string g_strdzbdjkxlh;
time_t start = 0;

struct _vedio_dwl_data{
    UINT down_num;
    UINT index;
    vehicle_inf * pvehicle_inf;
};
#ifndef NO_NVR
#include "NvrSdk.h"

void VedioCallBack(int &ns, const char* strSaveFile,LPVOID pParam);
BOOL Start_RTSP_request(const char * rtspurl, _vedio_dwl_data* vedio_dwl_data);
BOOL Start_NVR_request(const char * nvrurl, _vedio_dwl_data* vedio_dwl_data);
#endif

#ifndef NO_ARTHMETIC
//#include "annual_vehicle_inspection_api.hpp"
#include "large_vehicle_api.hpp"
#endif

#ifndef NO_DATABASE
void operateDatabase(const vehicle_inf *v_vehicle_inf);
void videoOperateDatabase(const vehicle_inf *v_vehicle_inf);
#endif

extern vector<std::string> confirm_lsh;
extern std::string g_localServerIp;
extern std::string LocalMac;
std::string g_remoteServerIp = REMOTE_VEHICLE_SYS_IP;
std::vector<std::string> g_vec_remote_server_ip;
char *g_remoteServerIp_Char = NULL;
std::string g_remoteServerPort = REMOTE_VEHICLE_SYS_PORT;
extern std::string g_photoUri;
extern std::string g_photoFilePath;
extern std::string g_videoFilePath;
extern std::string g_confJkxlh;
//std::string g_nvr_dwl_duration = "10";
std::string g_nvr_dwl_duration = "0";
extern std::string g_demo_path;
BlockingQueue<vehicle_inf *> toDistribute_queue;
extern BlockingQueue<vehicle_inf *> toanalyse_queue;
extern BlockingQueue<vehicle_inf *> download_queue;
extern BlockingQueue<vehicle_inf *> reply_queue;
BlockingQueue<vehicle_inf *> g_record_3rd_queue;
extern BlockingQueue<video_inf *> video_queue;
extern BlockingQueue<vehicle_inf *> record_queue;
extern BlockingQueue<vehicle_inf *> reply_master_queue;

BlockingQueue<std::string> sqlstr_queue;
//extern void * model_test;
//extern void * table_test;
extern std::vector<SlaveInfo> SlaveList;
extern std::vector<std::string> SYXZ_List;
extern std::string g_requestUri;
extern int g_SlaveCount;
extern unsigned int g_device_ID;
extern std::string g_master_IP;
bool b_ok = false;
int  g_n_remote_ip_index = 0;
bool analyseSlaveReply(std::string data);
void DataRequestThread();
void DataAnalyseThread(unsigned int GPU_ID);
void DB_BackUpThread();
void DB_Video_Thread();
void ReplyThread();
void ReplyMasterThread();
void RecordThread();
void exec_analyse(void *lpParam, LargeVehicleApi *alg);
void exec_analyse_new(void *lpParam, processBaseClass *pProcessBaseClass, LargeVehicleApi *alg);
void PhotoDwlThread();
void transfer_to_slave(vehicle_inf *v_vehicle_inf);
void binzhou_download_video(void);
void exec_downlond(void *lpParam);
int Analyse_QueryReturn_Data(char* xmldata, void* pvehicle_inf, unsigned int flag);
std::string Prepare_SoapXml_Data(vehicle_inf * pvehicle_inf, UINT index);
std::string Prepare_Xml_Data(vehicle_inf * pvehicle_inf);
std::string Prepare_Soap_Data(char* xmldata);
int process_photo(vehicle_inf *pvehicle_inf, LargeVehicleApi *alg);
extern std::string UTF8toANSI(char *strUTF8);
extern std::string ANSItoUTF8(char *strAnsi);
bool DistributeData(vehicle_inf *v_vehicle_inf);
inline BYTE toHex(const BYTE &x);
inline BYTE fromHex(const BYTE &x);
inline string URLEncode(const string &sIn);
inline string URLDecode(const string &sIn);
void recordResponseTime(vehicle_inf *v_vehicle_inf, std::string picture_type, std::string time);
std::string BackslashToSlash(std::string data);
std::vector<std::string> getFiles(std::string dir);
void deleteDirectory(std::string dir);
std::string LeftString(std::string str, unsigned int count);
extern vehicle_check_service g_service;
void runThirdPartInterface();
void* fun_3rd_part_interface(void *);
void BaoDing_FTP_Download(vehicle_inf *p_vehicle_inf);

void BaoDing_JYBG(vehicle_inf *p_vehicle_inf);
void NINGBO_BLACKLIST(vehicle_inf *p_vehicle_inf);
void NINGBO_DZBD(vehicle_inf *v_vehicle_inf);
void SUZHOU_DianZiHuanBaoDan(vehicle_inf *p_vehicle_inf);
void getDzbdInformation(vehicle_inf *p_vehicle_inf);
void TIANJIN_OracleDate(vehicle_inf *p_vehicle_inf);
void YICHUN_VideoCheckSerch(vehicle_inf *p_vehicle_inf);
void Video_Download(vehicle_inf *v_vehicle_inf);

std::string is_pass_ShangHai(const vehicle_inf *v_vehicle_inf, int hdzk);
bool checkTime(string start,string end,string now);
int dataToInt(string datatime);

void videoCheckSerch();
void binzhou_video_check(void *lpParam);
void get_xml_data(vehicle_inf *pvehicle_inf, std::vector<std::string> vec_ip, int index, std::string str_xml);
void runVideoServerListening();
void BaoDing_ClearFtpPic();
void distribution_thread();
bool isReCheck(string lsh);

std::string makeResultMessage(const vehicle_inf *pvehicle_inf);
bool analyseResultMessage(const std::string message, vehicle_inf *pvehicle_inf, unsigned int &device_ID);
bool distributeAssignment_IP(vehicle_inf *v_vehicle_inf, std::string assignment_IP);
void sendPhotoResult(const vehicle_inf *p_vehicle, int zplist_index, std::string data);
void sendAllPhotoResult(const vehicle_inf *p_vehicle, int zplist_index, std::string data);

string jyjg_list[9] = { "3200000011", "3200000014", "3205000001", "3205000003", "3205000005", "3205000006", "3205000007", "3205000008", "3205000040" };



/* 保定clsbdh.txt本地存放位置 */
#define BAODING_TXT_DIR (g_photoFilePath + "BaoDingTXT/")
#define BAODING_HTTP_IP "192.168.8.156"
#define BAODING_HTTP_PORT "7888"
#define BAODINGSOAPCLSBH "7D1D09090202170408157DE6EB88F6F8E581E8F28FF4FF5840746D72693E636E"
unsigned int gpu_numbers;   /* 当前设备的显卡数量 */

vehicle_check_service::vehicle_check_service()
{
    m_Analyse_hThread = NULL;
    m_Download_hThread = NULL;
}

vehicle_check_service::~vehicle_check_service()
{
}

void vehicle_check_service::check_master()
{
#ifdef APPLY_MULTICAST
    if (g_SlaveCount == -1) {
        g_SlaveCount = m_mc.cjClnts_.size();
        SlaveList.clear();
        for (auto c : m_mc.cjClnts_) {
            SlaveInfo si;
            si.ip = c.second.ip.c_str();
            si.port = std::to_string(c.second.port).c_str();
            SlaveList.push_back(si);
        }
        if (JGSYS_SOAP_PROCOTOL)
            data_request();
    }
#endif
}

void vehicle_check_service::check_slave()
{
#ifdef APPLY_MULTICAST
    if (g_SlaveCount != -1) {
        g_SlaveCount = -1;
    }
#endif
}
#ifdef APPLY_MULTICAST
void OutPutFile(Worker::HTTP_METHOD method,std::map<std::string,std::string>& nameVals,std::string& ostr,std::string& opath)
{
    std::string ver=nameVals["version"];
    if(ver == g_version)
    {
        std::string pkg="/opt/vehicle/program/Release_"+ver+".tar.gz";
        if(hl::pathexist(pkg))
            opath=pkg;
        else
        {
            DATA_PRINT(LEVEL_ERROR, "http server not found file : %s \n",pkg.c_str());
        }
    }
}
void SetMaster(Worker::HTTP_METHOD method,std::map<std::string,std::string>& nameVals,std::string& ostr,std::string& opath)
{
    std::string bMaster=nameVals["bmaster"];
    if(bMaster == "yes")
        g_service.check_master();
    else
        g_service.check_slave();
    ostr="set ok";
}
void GetMaster(Worker::HTTP_METHOD method,std::map<std::string,std::string>& nameVals,std::string& ostr,std::string& opath)
{
    if(g_SlaveCount == -1)
        ostr="no";
    else
        ostr="yes";

}
#endif

void vehicle_check_service::start()
{
#ifdef WIN32
    WSADATA wsaData;
    WSAStartup(MAKEWORD(2, 2), &wsaData);
#endif
    std::string udpIp = g_localServerIp;
    if (udpIp == "0.0.0.0") {
        char    HostName[100];
        hostent* hname;
        gethostname(HostName, sizeof(HostName));// 获得本机主机名.
        hname = gethostbyname(HostName);//根据本机主机名得到本机ip
        udpIp = inet_ntoa(*(struct in_addr *)hname->h_addr_list[0]);//把ip换成字符串形式
    }
#ifdef APPLY_MULTICAST
    m_verServ.AddRouter("/GetPackage",OutPutFile);
    m_verServ.AddRouter("/SetMaster",SetMaster);
    m_verServ.AddRouter("/GetMaster",GetMaster);
    bool ret1=m_mc.Start(this, (char*)udpIp.c_str(), MULTICAST_LOCAL_PORT, MULTICAST_IP, MULTICAST_PORT, MultiCast::OnRecv,true,true);
    bool ret2=m_verServ.Run(16389,5);
    if (!ret1 || !ret2)
    {
        DATA_PRINT(LEVEL_ERROR, "组播组件或版本服務器开启失败 %s:%d %s:%d\n", udpIp.c_str(), MULTICAST_LOCAL_PORT, MULTICAST_IP, MULTICAST_PORT);
    }
#else
    if(false){}
#endif
    else
    {
#ifdef APPLY_TELNET_SERV
        if(!m_ts.Run(this,12345))
        {
            DATA_PRINT(LEVEL_ERROR, "telnet server开启失败! \n");
            return;
        }
#endif

        /* 启动第三方数据通信接口 */
        if (g_Interface) {
            runThirdPartInterface();
        }
        /* 启动第三方数据通信接口,暂时苏州只有217机器开启该接口 */
        pthread_t third_thread_id;
        if (g_3rdInterface) {
            pthread_create(&third_thread_id, NULL, fun_3rd_part_interface, NULL);
            DATA_PRINT(LEVEL_INFO, " 事后审核开始运行.\n");
        }

        if (g_SlaveCount == -1) {   /* 从机模式 */
            if (g_CheckItem.dlvideo.soapflag)
            {
                runVideoServerListening();
            }
            startAlgorithm();
            startOtherModules();
            m_httpserver.run();
        } else {                    /* 主机模式或独立模式 */
            if (JGSYS_SOAP_PROCOTOL) {
                data_request();
            }

            startAlgorithm();
            startOtherModules();
            m_httpserver.run(); /* 主机模式也需要建立HTTP server，否则主线程会直接退出。 */
        }
    }
}

void vehicle_check_service::stop()
{
#ifdef APPLY_MULTICAST
    //m_mc.Stop();
    m_verServ.Stop();
#endif

#ifdef APPLY_TELNET_SERV
    m_ts.Stop();
#endif

    m_httpserver.stop();

    if (NULL != m_Analyse_hThread) {
        m_Analyse_hThread->detach();
        delete m_Analyse_hThread;
        m_Analyse_hThread = NULL;
    }

    if (NULL != m_Download_hThread) {
        m_Download_hThread->detach();
        delete m_Download_hThread;
        m_Download_hThread = NULL;
    }

    if (NULL != m_Request_hThread) {
        m_Request_hThread->detach();
        delete m_Request_hThread;
        m_Request_hThread = NULL;
    }

    if (NULL != m_DB_BackUp_hThread) {
        m_DB_BackUp_hThread->detach();
        delete m_DB_BackUp_hThread;
        m_DB_BackUp_hThread = NULL;
    }

    if (NULL != m_Reply_hThread) {
        m_Reply_hThread->detach();
        delete m_Reply_hThread;
        m_Reply_hThread = NULL;
    }

    if (NULL != m_Record_hThread) {
        m_Record_hThread->detach();
        delete m_Record_hThread;
        m_Record_hThread = NULL;
    }
}

void vehicle_check_service::startAlgorithm()
{
#ifndef CLOSE_DATA_ANALYSE

    nvmlReturn_t result;

    result = nvmlInit();
    if (result != NVML_SUCCESS) {
        DATA_PRINT(LEVEL_ERROR, "nvmlInit() fails! Reason: %s \n", nvmlErrorString(result));
        exit(EXIT_FAILURE);
    }

    result = nvmlDeviceGetCount(&gpu_numbers);
    if (result != NVML_SUCCESS) {
        DATA_PRINT(LEVEL_ERROR, "nvmlDeviceGetCount() fails! Reason: %s \n", nvmlErrorString(result));
        exit(EXIT_FAILURE);
    }

    DATA_PRINT(LEVEL_INFO, "The amount of GPU is %d \n", gpu_numbers);

    try {
        for (unsigned int i = 0; i < gpu_numbers; i++) {
            new std::thread(DataAnalyseThread, i);
        }
    } catch (const std::system_error& e) {
        DATA_PRINT(LEVEL_ERROR, "Create new thread failure! \n");
        std::cout << "Error code: " << e.code() << ", reason: " << e.what() << std::endl;
        exit(EXIT_FAILURE);
    }

#endif
}

int vehicle_check_service::startOtherModules()
{
    try {
        if (!g_TestMode) {

            if (g_CheckItem.City == BAODING) {
                /* 初始化OCCI的环境（需要在查询检验报告电子数据开始前进行）。 */
                /* 由于当前为linux，指定建立连接的编码为AL32UTF8 */
                occi_wrap::initialize(true, "AL32UTF8", "AL32UTF8");

                /* 定期同步人工审核结果，只需要主机来执行 */
                if (g_SlaveCount >= 0) {
                    new std::thread(synchronizeManualResult_Thread, "", "", "");
                }
            } else if (g_CheckItem.City == SUZHOU) {
                /* 初始化OCCI的环境（需要在"获取外地车历史照片"和“同步人工审核结果”开始前进行）。 */
                /* 由于当前为linux，指定建立连接的编码为AL32UTF8 */
                occi_wrap::initialize(true, "AL32UTF8", "AL32UTF8");

                /* 定期同步人工审核结果，只需要主机来执行 */
                if (g_SlaveCount >= 0) {
                    new std::thread(synchronizeManualResult_Thread,
                                    "shyk", "shykysj001", "192.168.0.252:1521/orcl");
                }
            } else if (g_CheckItem.City == LINYI) {
                /* 初始化OCCI的环境（需要在“查询电子保单数据库”开始前进行）。 */
                /* 由于当前为linux，指定建立连接的编码为AL32UTF8 */
                occi_wrap::initialize(true, "AL32UTF8", "AL32UTF8");
            }
        }
        new std::thread(distribution_thread);
        m_Download_hThread = new std::thread(PhotoDwlThread);
        m_DB_BackUp_hThread = new std::thread(DB_BackUpThread);
        m_Reply_hThread = new std::thread(ReplyThread);
        m_Record_hThread = new std::thread(RecordThread);
        m_Reply_master_hThread = new std::thread(ReplyMasterThread);

        if (g_CheckItem.dlvideo.soapflag)
        {
            m_DB_Video_Thread = new std::thread(DB_Video_Thread);
        }
    } catch (const std::system_error& e) {
        DATA_PRINT(LEVEL_ERROR, "Create new thread failure! \n");
        std::cout << "Error code: " << e.code() << ", reason: " << e.what() << std::endl;

        m_Download_hThread = NULL;
        m_DB_BackUp_hThread = NULL;
        m_Reply_hThread = NULL;
        m_DB_Video_Thread = NULL;
        m_Record_hThread = NULL;

        return FALSE;
    }

    return TRUE;
}

int vehicle_check_service::data_request()
{
    try {
        m_Request_hThread = new std::thread(DataRequestThread);
    } catch (const std::system_error& e) {
        DATA_PRINT(LEVEL_ERROR, "Create new thread failure! \n");
        std::cout << "Error code: " << e.code() << ", reason: " << e.what() << std::endl;
        m_Request_hThread = NULL;
        return FALSE;
    }

    return TRUE;
}

#ifndef NO_DATABASE

/* 根据城市编号判定ispass的值 */
std::string is_Pass(const vehicle_inf *v_vehicle_inf)
{
    /*
    -1：软件没有审核。使用性质，车辆类型等不在软件处理范围内。照片没有经过算法处理。
    0：软件审核不通过。照片数量不全，或者任何一个照片判定为不通过。
    1：软件审核通过。所有照片都经过算法处理，并且都通过。
    2：人工审核通过
    3：人工审核不通过
    4：软件审核未知。所有照片都经过算法处理，出现了判定为未知的照片，并且没有出现判定为不通过的照片。

    没有特殊要求的城市：
    is_pass=1只能是同时满足以下3个条件的车辆：
    1. 使用性质是A
    2. 核定载客小于7
    3. 车辆类型属于下表中
       {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38",
        "K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48"};
    */
    std::string is_pass = "1";

    if (!v_vehicle_inf->AlgorithmCheck) {
        is_pass = "-1";
        return is_pass;
    }

    /* 将“核定载客数”转为数字 */
    int hdzk = 0;
    try {
        if (v_vehicle_inf->m_hdzk == "无数据") {
            hdzk = 7;
        } else {
            hdzk = std::stoi(v_vehicle_inf->m_hdzk);
        }
    } catch (const std::exception &e) {
        DATA_PRINT(LEVEL_INFO, "Exception! std::stoi() \n");
        DATA_PRINT(LEVEL_INFO, "Exception cause: %s \n", e.what());
        DATA_PRINT(LEVEL_INFO, "v_vehicle_inf->m_hdzk: %s \n", v_vehicle_inf->m_hdzk.c_str());
        hdzk = 7;   /* 如果不能转换，将核定载客数设为7 */
    }

    bool BigVehicle = false;

    if (g_CheckItem.City == WUHAN) {

        /*
            is_pass为1的车，必须满足：
            1. 核定载客数小于7
            2. 不含档案照片的照片数量（十年以上的车>=18，十年以内的车>=14）
            3. 除了档案照片，其它检测清单内部照片都通过
            4. 若不通过若干结果为"4" 返回"4" 若结果为"5" 返回"0"

        */

        if (hdzk >= 7) {
            return "-1";
        }
        std::vector<std::string> small_vehicle = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38",
                                                  "K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48", "K49"};
        unsigned int i ,j;
        for (i = 0; i < small_vehicle.size(); i++) {
            if (v_vehicle_inf->m_cllx == small_vehicle[i]) {
                break;
            }
        }
        if (i == small_vehicle.size()) {
            return "-1";
        }

        /* “登记日期”为10年内的车，必须要有的照片 */
        std::vector<std::string> photo_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0202", "0203", "0204", "0205", "0265",
            "0321", "0352", "0322", "0348"
        };

        /* “登记日期”超过10年的车，额外要有的照片 */
        std::vector<std::string> photo_list_addition = {
            "0351", "0344", "0342", "0323"
        };

        std::vector<std::string> photo_all_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0202", "0203", "0204", "0205", "0265",
            "0321", "0352", "0322", "0348",
            "0351", "0344", "0342", "0323"
        };


        for (i = 0; i < photo_list.size(); i++) {
            for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                if (photo_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                    break;
                }
            }
            if (j == v_vehicle_inf->m_zplist.size()) {
                return "0";
            }
        }

        ResultCollection tmp;
        if (tmp.isTenYears(v_vehicle_inf)) {
            for (i = 0; i < photo_list_addition.size(); i++) {
                for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                    if (photo_list_addition[i] == v_vehicle_inf->m_zplist[j].zptype) {
                        break;
                    }
                }
                if (j == v_vehicle_inf->m_zplist.size()) {
                    return "0";
                }
            }
        }
        string is_pass = "1";
        for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++) {
            /* 如果照片类型的第一个字符是数字，表示普通照片（非档案照片） */
            if ((v_vehicle_inf->m_dbbhglist[i].zptype[0] >= '0') && (v_vehicle_inf->m_dbbhglist[i].zptype[0] <= '9')) {
                for (j = 0; j < photo_all_list.size() ; j++)
                {
                    if(v_vehicle_inf->m_dbbhglist[i].zptype == photo_all_list[j])
                    {
                        if(v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                        {
                            if(is_pass == "0")
                            {
                                continue;
                            }
                            is_pass = "4";
                        }
                        else if(v_vehicle_inf->m_dbbhglist[i].dbresult == "5")
                            is_pass = "0";
                    }
                }
            }
        }
        return is_pass;
    } else if (g_CheckItem.City == SUZHOU) {
        /* 判定该车的车辆类型是否在苏州正常审核的范围之外(是否“大车”) */
        std::vector<std::string> CheLiangLeiXing_SZ = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38",
                                                       "K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48", "K49"};

        unsigned int k;
        for (k = 0; k < CheLiangLeiXing_SZ.size(); k++) {
            if (v_vehicle_inf->m_cllx == CheLiangLeiXing_SZ[k]) {
                break;
            }
        }

        if (k == CheLiangLeiXing_SZ.size()) {
            return "-1";    /* 苏州“大车”is_pass值为-1(但是其照片是经过算法处理的) */
        }

        if (hdzk >= 7) {
            return "-1";
        }

        /*
         * 所有车，必须要有的基本照片。
         * 注：苏州要求照片数量最少13张
        */
        std::vector<std::string> basic_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0202", "0203", "0204", "0210",
            "0321", "0352", "0322", "0348"
        };

        /* “登记日期”超过10年的车，额外要有的照片 */
        std::vector<std::string> addition_list = {
            "0351", "0344", "0342", "0323"
        };

        bool find_4_photo = false;  /* 是否发现了档案照片以外的，结果为4的照片 */

        /* 检查基本照片是否都有，并且都通过 */
        for (unsigned int i = 0; i < basic_list.size(); i++) {
            unsigned int j;

            for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {

                /* 找到一张基本照片，需要确认该照片是否通过 */
                if (basic_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                    for (unsigned int k = 0; k < v_vehicle_inf->m_dbbhglist.size(); k++) {
                        if (basic_list[i] == v_vehicle_inf->m_dbbhglist[k].zptype) {
                            if (v_vehicle_inf->m_dbbhglist[k].dbresult == "5") {
                                return "0";
                            } else {
                                find_4_photo = true;
                            }
                        }
                    }

                    break;
                }
            }

            if (j == v_vehicle_inf->m_zplist.size()) {
                return "0";
            }
        }

        /* 检查超过10年的车额外的照片 */
        ResultCollection tmp;
        if (tmp.isTenYears(v_vehicle_inf)) {

            for (unsigned int i = 0; i < addition_list.size(); i++) {
                unsigned int j;

                for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {

                    /* 找到一张额外照片，需要确认该照片是否通过 */
                    if (addition_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                        for (unsigned int k = 0; k < v_vehicle_inf->m_dbbhglist.size(); k++) {
                            if (addition_list[i] == v_vehicle_inf->m_dbbhglist[k].zptype) {
                                if (v_vehicle_inf->m_dbbhglist[k].dbresult == "5") {
                                    return "0";
                                } else {
                                    find_4_photo = true;
                                }
                            }
                        }

                        break;
                    }
                }

                if (j == v_vehicle_inf->m_zplist.size()) {
                    return "0";
                }
            }
        }

        /* 苏州"非营运"的车不判定“侧滑工位照片0353” */
        if (v_vehicle_inf->m_syxz != "A") {
            unsigned int i;

            for (i = 0; i < v_vehicle_inf->m_zplist.size(); i++) {
                if (v_vehicle_inf->m_zplist[i].zptype == "0353") {
                    for (unsigned int k = 0; k < v_vehicle_inf->m_dbbhglist.size(); k++) {
                        if (v_vehicle_inf->m_dbbhglist[k].zptype == "0353") {
                            if (v_vehicle_inf->m_dbbhglist[k].dbresult == "5") {
                                return "0";
                            } else {
                                find_4_photo = true;
                            }
                        }
                    }

                    break;
                }
            }

            if (i == v_vehicle_inf->m_zplist.size()) {
                return "0";
            }
        }

        if (find_4_photo) {
            return "4";
        }

        return "1";
    } else if (g_CheckItem.City == BAODING) {
        bool BigVehicle2=false;
        /* 判定该车的车辆类型是否在正常审核的范围之外(是否“大车”) */
        std::vector<std::string> CheLiangLeiXing_SZ = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38","K39",
                                                       "K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48","K49"};

        std::vector<std::string> CheLiangLeiXing2_SZ ={"K39","K49"};
        unsigned int i, k, j;
        for (k = 0; k < CheLiangLeiXing_SZ.size(); k++) {
            if (v_vehicle_inf->m_cllx == CheLiangLeiXing_SZ[k]) {
                break;
            }
        }

        if (k == CheLiangLeiXing_SZ.size()) {
            BigVehicle = true;
        }

        for (j = 0; j < CheLiangLeiXing2_SZ.size(); j++) {
            if (v_vehicle_inf->m_cllx == CheLiangLeiXing2_SZ[j]) {
                break;
            }
        }

        if (j == CheLiangLeiXing_SZ.size()) {
            BigVehicle2 = true;
        }

        /* 判定is_pass */
        if (!BigVehicle) {
            if (hdzk < 7) {

                /* “登记日期”为10年内的车，必须要有的照片 */
                std::vector<std::string> photo_list = {
                    "0111", "0112", "0113", "0157",
                    //"0201", "0202", "0203", "0204", "0205", "0212",
                    "0201", "0202", "0203", "0204", "0212",
                    "0321", "0352", "0322", "0348"
                };

                /* “登记日期”超过10年的车，额外要有的照片 */
                std::vector<std::string> photo_list_addition = {
                    "0351", "0344", "0342", "0323"
                };

                std::vector<std::string> photo_all_list = {
                    "0111", "0112", "0113", "0157",
                    //"0201", "0202", "0203", "0204", "0205", "0212",
                    "0201", "0202", "0203", "0204","0212",
                    "0321", "0352", "0322", "0348",
                    "0351", "0344", "0342", "0323"
                };


                for (i = 0; i < photo_list.size(); i++) {
                    for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                        if (photo_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                            break;
                        }
                    }

                    if (j == v_vehicle_inf->m_zplist.size()) {
                        return "0";
                    }
                }

                ResultCollection tmp;
                if (tmp.isTenYears(v_vehicle_inf)||BigVehicle2) {
                    for (i = 0; i < photo_list_addition.size(); i++) {
                        for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                            if (photo_list_addition[i] == v_vehicle_inf->m_zplist[j].zptype) {
                                break;
                            }
                        }

                        if (j == v_vehicle_inf->m_zplist.size()) {
                            return "0";
                        }
                    }
                }
                for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++) {
                    /* 如果照片类型的第一个字符是数字，表示普通照片（非档案照片） */
                    if ((v_vehicle_inf->m_dbbhglist[i].zptype[0] >= '0') && (v_vehicle_inf->m_dbbhglist[i].zptype[0] <= '9')) {
                        for (j = 0; j < photo_all_list.size() ; j++)
                        {
                            if(v_vehicle_inf->m_dbbhglist[i].zptype == photo_all_list[j])
                            {
                                if(v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                                {
                                    if(is_pass == "0")
                                    {
                                        continue;
                                    }
                                    is_pass = "4";
                                }
                                else if(v_vehicle_inf->m_dbbhglist[i].dbresult == "5")
                                    is_pass = "0";
                            }
                        }
                    }
                }
                return is_pass;
            } else {
                is_pass = "-1";
            }

        } else {
            is_pass = "-1";
        }
    } else if (g_CheckItem.City == NINGBO) {

        std::vector<std::string> CheLiangLeiXing_SZ = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38","K39",
                                                       "K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48","K49"};
        unsigned int i,k,j;
        for (k = 0; k < CheLiangLeiXing_SZ.size(); k++) {
            if (v_vehicle_inf->m_cllx == CheLiangLeiXing_SZ[k]) {
                break;
            }
        }
        if (k == CheLiangLeiXing_SZ.size()) {
            return "-1";
        }
        bool out_side;
        if (v_vehicle_inf->m_fzjg.find("浙") == string::npos){
            out_side = true;
        }

        /* “登记日期”为10年内的车，必须要有的照片 */
        std::vector<std::string> photo_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0202", "0204", "0205", "0209", "0299",
            "0321", "0352", "0322", "0348"
        };

        /* “登记日期”超过10年的车，额外要有的照片 */
        std::vector<std::string> photo_list_addition = {
            "0351", "0344", "0342", "0323"
        };

        std::vector<std::string> photo_all_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0202", "0204", "0205", "0209", "0299",
            "0321", "0352", "0322", "0348",
            "0351", "0344", "0342", "0323"
        };


        for (i = 0; i < photo_list.size(); i++) {
            if(!v_vehicle_inf->is_beimian){
                if(photo_list[i] == "0299"){
                    continue;
                }
            }
            for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {

                if (photo_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                    break;
                }

            }
            if (j == v_vehicle_inf->m_zplist.size()) {
                return "0";
            }
        }
        /*1.外省不检测委托书
          2.没有查验记录表背面则不判别背面是否存在*/
        ResultCollection tmp;
        if (tmp.isTenYears(v_vehicle_inf)) {
            for (i = 0; i < photo_list_addition.size(); i++) {
                if(!v_vehicle_inf->is_beimian){
                    if(photo_list[i] == "0299"){
                        continue;
                    }
                }
                for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                    if (photo_list_addition[i] == v_vehicle_inf->m_zplist[j].zptype) {
                        break;
                    }
                }
                if (j == v_vehicle_inf->m_zplist.size()) {
                    return "0";
                }
            }
        }
        for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++) {
            /* 如果照片类型的第一个字符是数字，表示普通照片（非档案照片） */
            if ((v_vehicle_inf->m_dbbhglist[i].zptype[0] >= '0') && (v_vehicle_inf->m_dbbhglist[i].zptype[0] <= '9')) {
                for (j = 0; j < photo_all_list.size() ; j++)
                {
                    if(v_vehicle_inf->m_dbbhglist[i].zptype == photo_all_list[j])
                    {
                        if(v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                        {
                            if(is_pass == "0")
                            {
                                continue;
                            }
                            is_pass = "4";
                        }
                        else if(v_vehicle_inf->m_dbbhglist[i].dbresult == "5")
                                 is_pass = "0";
                    }
                }
            }
        }


    } else if (g_CheckItem.City == NANNING) {
        unsigned int i,j;
        if (hdzk >= 7) {
            return "-1";
        }
        std::vector<std::string> small_vehicle = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38",
                                                  "K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48", "K49"};
        for (i = 0; i < small_vehicle.size(); i++) {
            if (v_vehicle_inf->m_cllx == small_vehicle[i]) {
                break;
            }

        }
        if (i == small_vehicle.size()) {
            return "-1";
        }
        /* “登记日期”为10年内的车，必须要有的照片 */
        std::vector<std::string> photo_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0202", "0204", "0224", "0227",
            "0321", "0352", "0322", "0348",
        };

        /* “登记日期”超过10年的车，额外要有的照片 */
        std::vector<std::string> photo_list_addition = {
            "0351", "0344", "0342", "0323"
        };

        std::vector<std::string> photo_all_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0202", "0204", "0224", "0227",
            "0321", "0352", "0322", "0348",
            "0351", "0344", "0342", "0323"
        };


        ResultCollection tmp;
        for (i = 0; i < photo_list.size(); i++) {
            if(tmp.isTenYears(v_vehicle_inf)&&(photo_list[i] == "0201"))
            {
                continue;
            }
            if((v_vehicle_inf->m_fzjg.find("桂") == -1)&&(photo_list[i] == "0208")) {/* 外省车标记 */
                continue;
            }
            for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                if (photo_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                    break;
                }
            }
            if (j == v_vehicle_inf->m_zplist.size()) {
                return "0";
            }
        }

        if (tmp.isTenYears(v_vehicle_inf)) {
            for (i = 0; i < photo_list_addition.size(); i++) {
                for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                    if (photo_list_addition[i] == v_vehicle_inf->m_zplist[j].zptype) {
                        break;
                    }
                }
                if (j == v_vehicle_inf->m_zplist.size()) {
                    return "0";
                }
            }
        }
        for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++) {
            /* 如果照片类型的第一个字符是数字，表示普通照片（非档案照片） */
            if ((v_vehicle_inf->m_dbbhglist[i].zptype[0] >= '0') && (v_vehicle_inf->m_dbbhglist[i].zptype[0] <= '9')) {
                for (j = 0; j < photo_all_list.size() ; j++)
                {
                    if(v_vehicle_inf->m_dbbhglist[i].zptype == photo_all_list[j])
                    {
                        if(v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                        {
                            if(is_pass == "0")
                            {
                                continue;
                            }
                            is_pass = "4";
                        }
                        else if(v_vehicle_inf->m_dbbhglist[i].dbresult == "5")
                            is_pass = "0";
                    }
                }
            }
        }
    } else if (g_CheckItem.City == SHENZHEN){
        if (hdzk >= 7) {
            return "-1";
        }
        std::vector<std::string> small_vehicle = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38",
                                                  "K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48", "K49"};
        unsigned int i,j;
        for (i = 0; i < small_vehicle.size(); i++) {
            if (v_vehicle_inf->m_cllx == small_vehicle[i]) {
                break;
            }

        }
        if (i == small_vehicle.size()) {
            return "-1";
        }
        /* “登记日期”为10年内的车，必须要有的照片 */
        std::vector<std::string> photo_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0202", "0203", "0204", "0209", "0261","0259",
            "0321", "0352", "0322", "0348"
        };

        /* “登记日期”超过10年的车，额外要有的照片 */
        std::vector<std::string> photo_list_addition = {
            "0351", "0344", "0342", "0323"
        };

        std::vector<std::string> photo_all_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0202", "0203", "0204", "0209", "0261","0259",
            "0321", "0352", "0322", "0348",
            "0351", "0344", "0342", "0323"
        };


        for (i = 0; i < photo_list.size(); i++) {
            for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                if (photo_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                    break;
                }
            }
            if (j == v_vehicle_inf->m_zplist.size()) {
                return "0";
            }
        }
        ResultCollection tmp;
        if (tmp.isTenYears(v_vehicle_inf)) {
            for (i = 0; i < photo_list_addition.size(); i++) {
                for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                    if (photo_list_addition[i] == v_vehicle_inf->m_zplist[j].zptype) {
                        break;
                    }
                }
                if (j == v_vehicle_inf->m_zplist.size()) {
                    return "0";
                }
            }
        }
        for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++) {
            /* 如果照片类型的第一个字符是数字，表示普通照片（非档案照片） */
            if ((v_vehicle_inf->m_dbbhglist[i].zptype[0] >= '0') && (v_vehicle_inf->m_dbbhglist[i].zptype[0] <= '9')) {
                for (j = 0; j < photo_all_list.size() ; j++)
                {
                    if(v_vehicle_inf->m_dbbhglist[i].zptype == photo_all_list[j])
                    {
                        if(v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                        {
                            if(is_pass == "0")
                            {
                                continue;
                            }
                            is_pass = "4";
                        }
                        else if(v_vehicle_inf->m_dbbhglist[i].dbresult == "5")
                            is_pass = "0";
                    }
                }
            }
        }
    } else if (g_CheckItem.City == TIANJIN){

        if(!isReCheck(v_vehicle_inf->m_jylsh))
        {
            ResultCollection tmp;
            isPass res(v_vehicle_inf, g_CheckItem ,tmp.isTenYears(v_vehicle_inf));
            is_pass = res.returnIsPass();
        }
        else
        {
            is_pass = "-1";
        }

    } else if (g_CheckItem.City == LINYI) {
        if (v_vehicle_inf->m_syxz != "A") {
            return "-1";
        }

        if (hdzk >= 7) {
            return "-1";
        }

        std::vector<std::string> small_vehicle = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38",
                                                  "K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48", "K49"};

        unsigned int i;
        for (i = 0; i < small_vehicle.size(); i++) {
            if (v_vehicle_inf->m_cllx == small_vehicle[i]) {
                break;
            }
        }

        if (i == small_vehicle.size()) {
            return "-1";
        }

        /*
         * 所有车，必须要有的基本照片。
         * 注：
         * 0203由于有联网电子保单信息，另行处理
         * 0205实际数量太少（5617辆车只有8张），忽略
        */
        std::vector<std::string> basic_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0202", "0203", "0204", "0209",
            "0321", "0352", "0322", "0348"
        };

        /* “登记日期”超过10年的车，额外要有的照片 */
        std::vector<std::string> addition_list = {
            "0351", "0344", "0342", "0323"
        };

        /* 检查基本照片是否都有，并且都通过 */
        for (unsigned int i = 0; i < basic_list.size(); i++) {
            unsigned int j;

            if (basic_list[i] == "0203") {
                if (v_vehicle_inf->insurance_result == 0) {
                    return "0";
                } else if (v_vehicle_inf->insurance_result == 1) {
                    continue;
                }
            }

            for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {

                /* 找到一张基本照片，需要确认该照片是否通过 */
                if (basic_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                    for (unsigned int k = 0; k < v_vehicle_inf->m_dbbhglist.size(); k++) {
                        if (basic_list[i] == v_vehicle_inf->m_dbbhglist[k].zptype) {
                            return "0";
                        }
                    }

                    break;
                }
            }

            if (j == v_vehicle_inf->m_zplist.size()) {
                return "0";
            }
        }

        /* 检查额外的照片 */
        ResultCollection tmp;
        if (tmp.isTenYears(v_vehicle_inf)) {
            for (unsigned int i = 0; i < addition_list.size(); i++) {
                unsigned int j;

                for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {

                    /* 找到一张额外照片，需要确认该照片是否通过 */
                    if (addition_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                        for (unsigned int k = 0; k < v_vehicle_inf->m_dbbhglist.size(); k++) {
                            if (addition_list[i] == v_vehicle_inf->m_dbbhglist[k].zptype) {
                                return "0";
                            }
                        }

                        break;
                    }
                }

                if (j == v_vehicle_inf->m_zplist.size()) {
                    return "0";
                }
            }
        }

        return "1";
    } else if (g_CheckItem.City == HULUNBEIER){

        /* “登记日期”为10年内的车，必须要有的照片 */
        std::vector<std::string> photo_list = {
            "0111", "0112", "0113",
            "0201", "0202", "0203", "0204", "0205", "0206", "0209",
            "0321", "0352", "0322", "0348"
        };

        /* “登记日期”超过10年的车，额外要有的照片 */
        std::vector<std::string> photo_list_addition = {
            "0351", "0344", "0342", "0323"
        };

        std::vector<std::string> photo_all_list = {
            "0111", "0112", "0113",
            "0201", "0202", "0203", "0204", "0205", "0206", "0209",
            "0321", "0352", "0322", "0348",
            "0351", "0344", "0342", "0323"
        };
        unsigned int i,j;
        for (i = 0; i < photo_list.size(); i++) {
            for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                if (photo_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                    break;
                }
            }
            if (j == v_vehicle_inf->m_zplist.size()) {
                return "0";
            }
        }

        ResultCollection tmp;
        if (tmp.isTenYears(v_vehicle_inf)) {
            for (i = 0; i < photo_list_addition.size(); i++) {
                for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                    if (photo_list_addition[i] == v_vehicle_inf->m_zplist[j].zptype) {
                        break;
                    }
                }
                if (j == v_vehicle_inf->m_zplist.size()) {
                    return "0";
                }
            }
        }
        else{
            if (!tmp.isYingYun(v_vehicle_inf)){
                for (i = 0;i < v_vehicle_inf->m_zplist.size();i++){
                    if ("0323" == v_vehicle_inf->m_zplist[i].zptype){
                        break;
                    }

                }
                if (i == v_vehicle_inf->m_zplist.size()){
                        return "0";
                }
            }
        }
        for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++) {
            /* 如果照片类型的第一个字符是数字，表示普通照片（非档案照片） */
            if ((v_vehicle_inf->m_dbbhglist[i].zptype[0] >= '0') && (v_vehicle_inf->m_dbbhglist[i].zptype[0] <= '9')) {
                for (j = 0; j < photo_all_list.size() ; j++)
                {
                    if(v_vehicle_inf->m_dbbhglist[i].zptype == photo_all_list[j])
                    {
                        if(v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                        {
                            if(is_pass == "0")
                            {
                                continue;
                            }
                            is_pass = "4";
                        }
                        else if(v_vehicle_inf->m_dbbhglist[i].dbresult == "5")
                            is_pass = "0";
                    }
                }
            }
        }
    } else if (g_CheckItem.City == PUTIAN) {

        /* “登记日期”为10年内的车，必须要有的照片 */
        std::vector<std::string> photo_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0202", "0203", "0204", "0205", "0209" , "0210" , "0213"
        };
        unsigned int i,j;
        for (i = 0; i < photo_list.size(); i++) {
            for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                if (photo_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                    break;
                }
            }
            if (j == v_vehicle_inf->m_zplist.size()) {
                return "0";
            }
        }
        /* 除了档案照片，其他照片通过就算全部通过 */
        for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++) {
            /* 如果照片类型的第一个字符是数字，表示普通照片（非档案照片） */
            if ((v_vehicle_inf->m_dbbhglist[i].zptype[0] >= '0') && (v_vehicle_inf->m_dbbhglist[i].zptype[0] <= '9'))
            {
                if (v_vehicle_inf->m_dbbhglist[i].zptype[1] == '3') {
                    continue;
                }
                else if ((v_vehicle_inf->m_dbbhglist[i].zptype[1] >= '0') && (v_vehicle_inf->m_dbbhglist[i].zptype[1] <= '9')) {
                    for (j = 0; j < photo_list.size() ; j++)
                    {
                        if(v_vehicle_inf->m_dbbhglist[i].zptype == photo_list[j])
                        {
                            if(v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                            {
                                if(is_pass == "0")
                                {
                                    continue;
                                }
                                is_pass = "4";
                            }
                            else if(v_vehicle_inf->m_dbbhglist[i].dbresult == "5")
                                is_pass = "0";
                        }
                    }
                }
            }
        }
    } else if (g_CheckItem.City == QIANDONGNAN){
        if(hdzk>7)
        {
            return "-1";
        }
        std::vector<std::string> small_vehicle = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38",
                                                  "K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48", "K49"};
        unsigned int i,j;
        for (i = 0; i < small_vehicle.size(); i++) {
            if (v_vehicle_inf->m_cllx == small_vehicle[i]) {
                break;
            }

        }
        if (i == small_vehicle.size()) {
            return "-1";
        }
        /* “登记日期”为10年内的车，必须要有的照片 */
        std::vector<std::string> photo_list = {
            "0111", "0112", "0113", "0119", "0157",
            "0201", "0202", "0203", "0204", "0209", "0213",
            "0321", "0352", "0322", "0348"
        };

        /* “登记日期”超过10年的车，额外要有的照片 */
        std::vector<std::string> photo_list_addition = {
            "0351", "0344", "0342", "0323"
        };

        std::vector<std::string> photo_all_list = {
            "0111", "0112", "0113", "0119", "0157",
            "0201", "0202", "0203", "0204", "0209", "0213",
            "0321", "0352", "0322", "0348",
            "0351", "0344", "0342", "0323"
        };
        for (i = 0; i < photo_list.size(); i++) {
            for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                if (photo_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                    break;
                }
            }
            if (j == v_vehicle_inf->m_zplist.size()) {
                return "0";
            }
        }

        ResultCollection tmp;
        if (tmp.isTenYears(v_vehicle_inf)) {
            for (i = 0; i < photo_list_addition.size(); i++) {
                for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                    if (photo_list_addition[i] == v_vehicle_inf->m_zplist[j].zptype) {
                        break;
                    }
                }
                if (j == v_vehicle_inf->m_zplist.size()) {
                    return "0";
                }
            }
        }
        for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++) {
            /* 如果照片类型的第一个字符是数字，表示普通照片（非档案照片） */
            if ((v_vehicle_inf->m_dbbhglist[i].zptype[0] >= '0') && (v_vehicle_inf->m_dbbhglist[i].zptype[0] <= '9')) {
                for (j = 0; j < photo_all_list.size() ; j++)
                {
                    if(v_vehicle_inf->m_dbbhglist[i].zptype == photo_all_list[j])
                    {
                        if(v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                            if(v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                            {
                                if(is_pass == "0")
                                {
                                    continue;
                                }
                                is_pass = "4";
                            }
                            else if(v_vehicle_inf->m_dbbhglist[i].dbresult == "5")
                                is_pass = "0";
                        else if(v_vehicle_inf->m_dbbhglist[i].dbresult == "5")
                            is_pass = "0";
                    }
                }
            }
        }
    } else if (g_CheckItem.City == QINGHAI){
        if (hdzk >= 7) {
            return "-1";
        }
        std::vector<std::string> small_vehicle = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38",
                                                  "K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48", "K49"};
        unsigned int i,j;
        for (i = 0; i < small_vehicle.size(); i++) {
            if (v_vehicle_inf->m_cllx == small_vehicle[i]) {
                break;
            }

        }
        if (i == small_vehicle.size()) {
            return "-1";
        }
        /* “登记日期”为10年内的车，必须要有的照片 */
        std::vector<std::string> photo_list = {
            "0111", "0112", "0113", "0114", "0157",
            "0201", "0202", "0203", "0204", "0290",
            "0321", "0352", "0322", "0348"
        };

        /* “登记日期”超过10年的车，额外要有的照片 */
        std::vector<std::string> photo_list_addition = {
            "0351", "0344", "0342", "0323"
        };

        std::vector<std::string> photo_all_list = {
            "0111", "0112", "0113", "0114", "0157",
            "0201", "0202", "0203", "0204", "0290",
            "0321", "0352", "0322", "0348",
            "0351", "0344", "0342", "0323"
        };
        for (i = 0; i < photo_list.size(); i++) {
            for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                if (photo_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                    break;
                }
            }
            if (j == v_vehicle_inf->m_zplist.size()) {
                return "0";
            }
        }
        ResultCollection tmp;
        if (tmp.isTenYears(v_vehicle_inf)) {
            for (i = 0; i < photo_list_addition.size(); i++) {
                for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                    if (photo_list_addition[i] == v_vehicle_inf->m_zplist[j].zptype) {
                        break;
                    }
                }
                if (j == v_vehicle_inf->m_zplist.size()) {
                    return "0";
                }
            }
        }
        for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++) {
            /* 如果照片类型的第一个字符是数字，表示普通照片（非档案照片） */
            if ((v_vehicle_inf->m_dbbhglist[i].zptype[0] >= '0') && (v_vehicle_inf->m_dbbhglist[i].zptype[0] <= '9')) {
                for (j = 0; j < photo_all_list.size() ; j++)
                {
                    if(v_vehicle_inf->m_dbbhglist[i].zptype == photo_all_list[j])
                    {
                        if(v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                        {
                            if(is_pass == "0")
                            {
                                continue;
                            }
                            is_pass = "4";
                        }
                        else if(v_vehicle_inf->m_dbbhglist[i].dbresult == "5")
                            is_pass = "0";
                    }
                }
            }
        }
    } else if (g_CheckItem.City == NANCHANG){
        if (hdzk >= 7) {
            return "-1";
        }
        std::vector<std::string> small_vehicle = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38",
                                                  "K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48", "K49"};
        unsigned int i,j;
        for (i = 0; i < small_vehicle.size(); i++) {
            if (v_vehicle_inf->m_cllx == small_vehicle[i]) {
                break;
            }

        }
        if (i == small_vehicle.size()) {
            return "-1";
        }
        /* “登记日期”为10年内的车，必须要有的照片 */
        std::vector<std::string> photo_list = {
            "0111", "0112", "0113", "0157", "0158",
            "0201", "0202", "0203", "0204", "0209",
            "0321", "0352", "0322", "0348"
        };

        /* “登记日期”超过10年的车，额外要有的照片 */
        std::vector<std::string> photo_list_addition = {
            "0351", "0344", "0342", "0323"
        };

        std::vector<std::string> photo_all_list = {
            "0111", "0112", "0113", "0157", "0158",
            "0201", "0202", "0203", "0204", "0209",
            "0321", "0352", "0322", "0348",
            "0351", "0344", "0342", "0323"
        };


        for (i = 0; i < photo_list.size(); i++) {
            for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                if (photo_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                    break;
                }
            }
            if (j == v_vehicle_inf->m_zplist.size()) {
                return "0";
            }
        }
        ResultCollection tmp;
        if (tmp.isTenYears(v_vehicle_inf)) {
            for (i = 0; i < photo_list_addition.size(); i++) {
                for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                    if (photo_list_addition[i] == v_vehicle_inf->m_zplist[j].zptype) {
                        break;
                    }
                }
                if (j == v_vehicle_inf->m_zplist.size()) {
                    return "0";
                }
            }
        }
        for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++) {
            /* 如果照片类型的第一个字符是数字，表示普通照片（非档案照片） */
            if ((v_vehicle_inf->m_dbbhglist[i].zptype[0] >= '0') && (v_vehicle_inf->m_dbbhglist[i].zptype[0] <= '9')) {
                for (j = 0; j < photo_all_list.size() ; j++)
                {
                    if(v_vehicle_inf->m_dbbhglist[i].zptype == photo_all_list[j])
                    {
                        if(v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                        {
                            if(is_pass == "0")
                            {
                                continue;
                            }
                            is_pass = "4";
                        }
                        else if(v_vehicle_inf->m_dbbhglist[i].dbresult == "5")
                            is_pass = "0";
                    }
                }
            }
        }
    } else if (g_CheckItem.City == SHANGRAO){
        if (hdzk >= 7) {
            return "-1";
        }
        std::vector<std::string> small_vehicle = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38",
                                                  "K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48", "K49"};

        unsigned int i,j;
        for (i = 0; i < small_vehicle.size(); i++) {
            if (v_vehicle_inf->m_cllx == small_vehicle[i]) {
                break;
            }

        }
        if (i == small_vehicle.size()) {
            return "-1";
        }
        /* “登记日期”为10年内的车，必须要有的照片 */
        std::vector<std::string> photo_list = {
            "0111", "0112", "0113",
            "0201", "0202", "0203", "0204", "0205", "0209",
            "0321", "0352", "0322", "0348"
        };

        /* “登记日期”超过10年的车，额外要有的照片 */
        std::vector<std::string> photo_list_addition = {
            "0351", "0323"
        };

        std::vector<std::string> photo_all_list = {
            "0111", "0112", "0113",
            "0201", "0202", "0203", "0204", "0205", "0209",
            "0321", "0352", "0322", "0348",
            "0351", "0323"
        };
        for ( i = 0; i < photo_list.size(); i++) {
            for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                if (photo_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                    break;
                }
            }
            if (j == v_vehicle_inf->m_zplist.size()) {
                return "0";
            }
        }
        ResultCollection tmp;
        if (tmp.isTenYears(v_vehicle_inf)) {
            for (i = 0; i < photo_list_addition.size(); i++) {
                for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                    if (photo_list_addition[i] == v_vehicle_inf->m_zplist[j].zptype) {
                        break;
                    }
                }
                if (j == v_vehicle_inf->m_zplist.size()) {
                    return "0";
                }
            }
        }
        for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++) {
            /* 如果照片类型的第一个字符是数字，表示普通照片（非档案照片） */
            if ((v_vehicle_inf->m_dbbhglist[i].zptype[0] >= '0') && (v_vehicle_inf->m_dbbhglist[i].zptype[0] <= '9')) {
                for (j = 0; j < photo_all_list.size() ; j++)
                {
                    if(v_vehicle_inf->m_dbbhglist[i].zptype == photo_all_list[j])
                    {
                        if(v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                        {
                            if(is_pass == "0")
                            {
                                continue;
                            }
                            is_pass = "4";
                        }
                        else if(v_vehicle_inf->m_dbbhglist[i].dbresult == "5")
                            is_pass = "0";
                    }
                }
            }
        }
    } else if (g_CheckItem.City == ANSHUN){
        if (hdzk >= 7) {
            return "-1";
        }
        std::vector<std::string> small_vehicle = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38",
                                                  "K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48", "K49"};
        unsigned int i,j;
        for (i = 0; i < small_vehicle.size(); i++) {
            if (v_vehicle_inf->m_cllx == small_vehicle[i]) {
                break;
            }

        }
        if (i == small_vehicle.size()) {
            return "-1";
        }
        /* “登记日期”为10年内的车，必须要有的照片 */
        std::vector<std::string> photo_list = {
            "0111", "0112", "0113", "0157", "0167", "0168", "0175",
            "0201", "0202", "0203", "0204", "0205", "0214", "0254", "0297",// "0209",
            "0321", "0352", "0322", "0348"
        };

        /* “登记日期”超过10年的车，额外要有的照片 */
        std::vector<std::string> photo_list_addition = {
            "0351", "0344", "0342", "0323"
        };

        std::vector<std::string> photo_all_list = {
            "0111", "0112", "0113", "0157", "0167", "0168", "0175",
            "0201", "0202", "0203", "0204", "0205", "0214", "0254", "0297",//"0209",
            "0321", "0352", "0322", "0348",
            "0351", "0344", "0342", "0323"
        };


        for (i = 0; i < photo_list.size(); i++) {
            for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                if (photo_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                    break;
                }
            }

            if (j == v_vehicle_inf->m_zplist.size()) {
                return "0";
            }
        }

        ResultCollection tmp;
        if (tmp.isTenYears(v_vehicle_inf)) {
            for (i = 0; i < photo_list_addition.size(); i++) {
                for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                    if (photo_list_addition[i] == v_vehicle_inf->m_zplist[j].zptype) {
                        break;
                    }
                }

                if (j == v_vehicle_inf->m_zplist.size()) {
                    return "0";
                }
            }
        }
        for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++) {
            /* 如果照片类型的第一个字符是数字，表示普通照片（非档案照片） */
            if ((v_vehicle_inf->m_dbbhglist[i].zptype[0] >= '0') && (v_vehicle_inf->m_dbbhglist[i].zptype[0] <= '9')) {
                for (j = 0; j < photo_all_list.size() ; j++)
                {
                    if(v_vehicle_inf->m_dbbhglist[i].zptype == photo_all_list[j])
                    {
                        if(v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                        {
                            if(is_pass == "0")
                            {
                                continue;
                            }
                            is_pass = "4";
                        }
                        else if(v_vehicle_inf->m_dbbhglist[i].dbresult == "5")
                            is_pass = "0";
                    }
                }
            }
        }
    } else if (g_CheckItem.City == HENGSHUI){
        if(isReCheck(v_vehicle_inf->m_jylsh))
        {
            return "-1";
        }
        if (hdzk >= 7) {
            return "-1";
        }
        std::vector<std::string> small_vehicle = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38",
                                                  "K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48", "K49"};
        unsigned int i,j;
        for (i = 0; i < small_vehicle.size(); i++) {
            if (v_vehicle_inf->m_cllx == small_vehicle[i]) {
                break;
            }

        }
        if (i == small_vehicle.size()) {
            return "-1";
        }
        /* “登记日期”为10年内的车，必须要有的照片 */
        std::vector<std::string> photo_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0202", "0203", "0204",
            "0321", "0352", "0322", "0348","0214"
        };

        /* “登记日期”超过10年的车，额外要有的照片 */
        std::vector<std::string> photo_list_addition = {
            "0351", "0344", "0342", "0323"
        };

        std::vector<std::string> photo_all_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0202", "0203", "0204",
            "0321", "0352", "0322", "0348","0214",
            "0351", "0344", "0342", "0323"
        };


        for (i = 0; i < photo_list.size(); i++) {
            for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                if (photo_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                    break;
                }
            }

            if (j == v_vehicle_inf->m_zplist.size()) {
                return "0";
            }
        }

        ResultCollection tmp;
        if (tmp.isTenYears(v_vehicle_inf)) {
            for (i = 0; i < photo_list_addition.size(); i++) {
                for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                    if (photo_list_addition[i] == v_vehicle_inf->m_zplist[j].zptype) {
                        break;
                    }
                }

                if (j == v_vehicle_inf->m_zplist.size()) {
                    return "0";
                }
            }
        }
        for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++) {
            /* 如果照片类型的第一个字符是数字，表示普通照片（非档案照片） */
            if ((v_vehicle_inf->m_dbbhglist[i].zptype[0] >= '0') && (v_vehicle_inf->m_dbbhglist[i].zptype[0] <= '9')) {
                for (j = 0; j < photo_all_list.size() ; j++)
                {
                    if(v_vehicle_inf->m_dbbhglist[i].zptype == photo_all_list[j])
                    {
                        if(v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                        {
                            if(is_pass == "0")
                            {
                                continue;
                            }
                            is_pass = "4";
                        }
                        else if(v_vehicle_inf->m_dbbhglist[i].dbresult == "5")
                            is_pass = "0";
                    }
                }
            }
        }
    } else if (g_CheckItem.City == ZHOUKOU){
        if (hdzk >= 7) {
            return "-1";
        }
        std::vector<std::string> small_vehicle = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38",
                                                  "K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48"};
        unsigned int i,j;
        for (i = 0; i < small_vehicle.size(); i++) {
            if (v_vehicle_inf->m_cllx == small_vehicle[i]) {
                break;
            }

        }
        if (i == small_vehicle.size()) {
            return "-1";
        }
        /* “登记日期”为10年内的车，必须要有的照片 */
        std::vector<std::string> photo_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0202", "0203", "0204", "0296", "0298",
            "0321", "0352", "0322", "0348"
        };

        /* “登记日期”超过10年的车，额外要有的照片 */
        std::vector<std::string> photo_list_addition = {
            "0351", "0344", "0342", "0323"
        };

        std::vector<std::string> photo_all_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0202", "0203", "0204", "0296", "0298",
            "0321", "0352", "0322", "0348",
            "0351", "0344", "0342", "0323"
        };


        for (i = 0; i < photo_list.size(); i++) {
            for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                if (photo_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                    break;
                }
            }

            if (j == v_vehicle_inf->m_zplist.size()) {
                return "0";
            }
        }

        ResultCollection tmp;
        if (tmp.isTenYears(v_vehicle_inf)) {
            for (i = 0; i < photo_list_addition.size(); i++) {
                for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                    if (photo_list_addition[i] == v_vehicle_inf->m_zplist[j].zptype) {
                        break;
                    }
                }
                if (j == v_vehicle_inf->m_zplist.size()) {
                    return "0";
                }
            }
        }
        for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++) {
            /* 如果照片类型的第一个字符是数字，表示普通照片（非档案照片） */
            if ((v_vehicle_inf->m_dbbhglist[i].zptype[0] >= '0') && (v_vehicle_inf->m_dbbhglist[i].zptype[0] <= '9')) {
                for (j = 0; j < photo_all_list.size() ; j++)
                {
                    if(v_vehicle_inf->m_dbbhglist[i].zptype == photo_all_list[j])
                    {
                        if(v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                        {
                            if(is_pass == "0")
                            {
                                continue;
                            }
                            is_pass = "4";
                        }
                        else if(v_vehicle_inf->m_dbbhglist[i].dbresult == "5")
                            is_pass = "0";
                    }
                }
            }
        }
    } else if (g_CheckItem.City == LINFEN){
        if (hdzk >= 7) {
            return "-1";
        }
        std::vector<std::string> small_vehicle = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38",
                                                  "K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48", "K49"};
        unsigned int i,j;
        for (i = 0; i < small_vehicle.size(); i++) {
            if (v_vehicle_inf->m_cllx == small_vehicle[i]) {
                break;
            }

        }
        if (i == small_vehicle.size()) {
            return "-1";
        }
        /* “登记日期”为10年内的车，必须要有的照片 */
        std::vector<std::string> photo_list = {
            "0111", "0112", "0113", "0157",
            "0202", "0204", "0205", "0208", "0298",
            "0321", "0352", "0322", "0348"
        };

        /* “登记日期”超过10年的车，额外要有的照片 */
        std::vector<std::string> photo_list_addition = {
            "0351", "0344", "0342", "0323"
        };

        std::vector<std::string> photo_all_list = {
            "0111", "0112", "0113", "0157",
            "0202", "0204", "0205", "0208", "0298",
            "0321", "0352", "0322", "0348",
            "0351", "0344", "0342", "0323"
        };


        for (i = 0; i < photo_list.size(); i++) {
            for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                if (photo_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                    break;
                }
            }

            if (j == v_vehicle_inf->m_zplist.size()) {
                return "0";
            }
        }

        ResultCollection tmp;
        if (tmp.isTenYears(v_vehicle_inf)) {
            for (i = 0; i < photo_list_addition.size(); i++) {
                for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                    if (photo_list_addition[i] == v_vehicle_inf->m_zplist[j].zptype) {
                        break;
                    }
                }

                if (j == v_vehicle_inf->m_zplist.size()) {
                    return "0";
                }
            }
        }
        for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++) {
            /* 如果照片类型的第一个字符是数字，表示普通照片（非档案照片） */
            if ((v_vehicle_inf->m_dbbhglist[i].zptype[0] >= '0') && (v_vehicle_inf->m_dbbhglist[i].zptype[0] <= '9')) {
                for (j = 0; j < photo_all_list.size() ; j++)
                {
                    if(v_vehicle_inf->m_dbbhglist[i].zptype == photo_all_list[j])
                    {
                        if(v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                        {
                            if(is_pass == "0")
                            {
                                continue;
                            }
                            is_pass = "4";
                        }
                        else if(v_vehicle_inf->m_dbbhglist[i].dbresult == "5")
                            is_pass = "0";
                    }
                }
            }
        }
    } else if (g_CheckItem.City == NANJING) {
        if (isReCheck(v_vehicle_inf->m_jylsh)) {
            return "-1";
        }
        if (hdzk > 7) {
            return "-1";
        }
        if (v_vehicle_inf->m_syxz.compare("A") != 0) {
            return "-1";
        }
        std::vector<std::string> small_vehicle = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38","K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48"};
        unsigned int i,j;
        for (i = 0; i < small_vehicle.size(); i++)
        {
            if (v_vehicle_inf->m_cllx == small_vehicle[i]) {
                break;
            }
        }

        if (i == small_vehicle.size()) {
            return "-1";
        }
        /* “登记日期”为10年内的车，必须要有的照片 */
        std::vector<std::string> photo_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0202", "0203", "0204", "0205", "0209",
            "0321", "0322", "0348"
        };

        /* “登记日期”超过10年的车，额外要有的照片 */
        std::vector<std::string> photo_list_addition = {
            "0323", "0351"
        };

        std::vector<std::string> photo_all_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0202", "0203", "0204", "0205", "0209",
            "0321", "0322", "0348",
            "0323", "0351"
        };

        for (i = 0; i < photo_list.size(); i++)
        {
            for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                if (photo_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                    break;
                }
            }

            if (j == v_vehicle_inf->m_zplist.size()) {
                return "0";
            }
        }

        ResultCollection tmp;
        if (tmp.isTenYears(v_vehicle_inf)) {
            for (i = 0; i < photo_list_addition.size(); i++) {
                for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                    if (photo_list_addition[i] == v_vehicle_inf->m_zplist[j].zptype) {
                        break;
                    }
                }

                if (j == v_vehicle_inf->m_zplist.size()) {
                    return "0";
                }
            }
        }
        const char *s_axis_one = "一轴制动工位-照片:[刹车灯不合格]";
        const char *s_axis_two = "二轴制动工位-照片:[刹车灯不合格]";
        const char *s_parking = "驻车制动工位-照片:[刹车灯不合格]";
        for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++)
        {
            /* 如果照片类型的第一个字符是数字，表示普通照片（非档案照片） */
            if ((v_vehicle_inf->m_dbbhglist[i].zptype[0] >= '0') && (v_vehicle_inf->m_dbbhglist[i].zptype[0] <= '9'))
            {
                for (j = 0; j < photo_all_list.size() ; j++)
                {
                    if(v_vehicle_inf->m_dbbhglist[i].zptype == photo_all_list[j])
                    {
                        switch (std::stoi(v_vehicle_inf->m_dbbhglist[i].zptype))
                        {
                        case 322:
                            if (s_axis_one == v_vehicle_inf->m_dbbhglist[i].dbbhg_desc)
                                continue;
                            break;
                        case 348:
                            if (s_axis_two == v_vehicle_inf->m_dbbhglist[i].dbbhg_desc)
                                continue;
                            break;
                        case 351:
                            if (s_parking == v_vehicle_inf->m_dbbhglist[i].dbbhg_desc)
                                continue;
                            break;
                        default:
                            break;
                        }

                        if(v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                        {
                            if(is_pass == "0")
                            {
                                continue;
                            }
                            is_pass = "4";
                        }
                        else if(v_vehicle_inf->m_dbbhglist[i].dbresult == "5")
                            is_pass = "0";
                    }
                }
            }
        }
    } else if (g_CheckItem.City == XUZHOU){
        if (hdzk >= 7) {
            return "-1";
        }
        std::vector<std::string> small_vehicle = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38",
                                                  "K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48", "K49"};
        unsigned int i,j;
        for (i = 0; i < small_vehicle.size(); i++) {
            if (v_vehicle_inf->m_cllx == small_vehicle[i]) {
                break;
            }

        }
        if (i == small_vehicle.size()) {
            return "-1";
        }
        /* “登记日期”为10年内的车，必须要有的照片 */
        std::vector<std::string> photo_list = {
            "0111", "0112", "0113","0157",
            "0201", "0202", "0203", "0204", "0205","0209",
            "0321", "0352", "0322", "0348"
        };

        /* “登记日期”超过10年的车，额外要有的照片 */
        std::vector<std::string> photo_list_addition = {
            "0351", "0344", "0342", "0323"
        };

        std::vector<std::string> photo_all_list = {
            "0111", "0112", "0113","0157",
            "0201", "0202", "0203", "0204", "0205","0209",
            "0321", "0352", "0322", "0348",
            "0351", "0344", "0342", "0323"
        };


        for (i = 0; i < photo_list.size(); i++) {
            for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                if (photo_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                    break;
                }
            }
            if (j == v_vehicle_inf->m_zplist.size()) {
                return "0";
            }
        }
        ResultCollection tmp;
        if (tmp.isTenYears(v_vehicle_inf)) {
            for (i = 0; i < photo_list_addition.size(); i++) {
                for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                    if (photo_list_addition[i] == v_vehicle_inf->m_zplist[j].zptype) {
                        break;
                    }
                }
                if (j == v_vehicle_inf->m_zplist.size()) {
                    return "0";
                }
            }
        }
        for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++) {
            /* 如果照片类型的第一个字符是数字，表示普通照片（非档案照片） */
            if ((v_vehicle_inf->m_dbbhglist[i].zptype[0] >= '0') && (v_vehicle_inf->m_dbbhglist[i].zptype[0] <= '9')) {
                for (j = 0; j < photo_all_list.size() ; j++)
                {
                    if(v_vehicle_inf->m_dbbhglist[i].zptype == photo_all_list[j])
                    {
                        if(v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                        {
                            if(is_pass == "0")
                            {
                                continue;
                            }
                            is_pass = "4";
                        }
                        else if(v_vehicle_inf->m_dbbhglist[i].dbresult == "5")
                            is_pass = "0";
                    }
                }
            }
        }
    } else if (g_CheckItem.City == ZHAOTONG){
        if (hdzk >= 7) {
            return "-1";
        }
        std::vector<std::string> small_vehicle = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38",
                                                  "K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48", "K49"};
        unsigned int i,j;
        for (i = 0; i < small_vehicle.size(); i++) {
            if (v_vehicle_inf->m_cllx == small_vehicle[i]) {
                break;
            }

        }
        if (i == small_vehicle.size()) {
            return "-1";
        }
        /* “登记日期”为10年内的车，必须要有的照片 */
        std::vector<std::string> photo_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0202", "0203", "0204", "0209", "0261",
            "0321", "0352", "0322", "0348"
        };

        /* “登记日期”超过10年的车，额外要有的照片 */
        std::vector<std::string> photo_list_addition = {
            "0351", "0344", "0342", "0323"
        };

        std::vector<std::string> photo_all_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0202", "0203", "0204", "0209", "0261"
            "0321", "0352", "0322", "0348",
            "0351", "0344", "0342", "0323"
        };


        for (i = 0; i < photo_list.size(); i++) {
            for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                if (photo_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                    break;
                }
            }
            if (j == v_vehicle_inf->m_zplist.size()) {
                return "0";
            }
        }

        ResultCollection tmp;
        if (tmp.isTenYears(v_vehicle_inf)) {
            for (i = 0; i < photo_list_addition.size(); i++) {
                for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                    if (photo_list_addition[i] == v_vehicle_inf->m_zplist[j].zptype) {
                        break;
                    }
                }
                if (j == v_vehicle_inf->m_zplist.size()) {
                    return "0";
                }
            }
        }
        for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++) {
            /* 如果照片类型的第一个字符是数字，表示普通照片（非档案照片） */
            if ((v_vehicle_inf->m_dbbhglist[i].zptype[0] >= '0') && (v_vehicle_inf->m_dbbhglist[i].zptype[0] <= '9')) {
                for (j = 0; j < photo_all_list.size() ; j++)
                {
                    if(v_vehicle_inf->m_dbbhglist[i].zptype == photo_all_list[j])
                    {
                        if(v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                        {
                            if(is_pass == "0")
                            {
                                continue;
                            }
                            is_pass = "4";
                        }
                        else if(v_vehicle_inf->m_dbbhglist[i].dbresult == "5")
                            is_pass = "0";
                    }
                }
            }
        }
    } else if (g_CheckItem.City == FUZHOU){
        if (hdzk >= 7) {
            return "-1";
        }
        std::vector<std::string> small_vehicle = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38",
                                                  "K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48", "K49"};
        unsigned int i,j;
        for (i = 0; i < small_vehicle.size(); i++) {
            if (v_vehicle_inf->m_cllx == small_vehicle[i]) {
                break;
            }

        }
        if (i == small_vehicle.size()) {
            return "-1";
        }
        /* “登记日期”为10年内的车，必须要有的照片 */
        std::vector<std::string> photo_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0202", "0203", "0204", "0205", "0296",
            "0321", "0352", "0322", "0348"
        };

        /* “登记日期”超过10年的车，额外要有的照片 */
        std::vector<std::string> photo_list_addition = {
            "0351", "0344", "0342", "0323"
        };

        std::vector<std::string> photo_all_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0202", "0203", "0204", "0205", "0296",
            "0321", "0352", "0322", "0348",
            "0351", "0344", "0342", "0323"
        };


        for (i = 0; i < photo_list.size(); i++) {
            for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                if (photo_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                    break;
                }
            }

            if (j == v_vehicle_inf->m_zplist.size()) {
                return "0";
            }
        }

        ResultCollection tmp;
        if (tmp.isTenYears(v_vehicle_inf)) {
            for (i = 0; i < photo_list_addition.size(); i++) {
                for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                    if (photo_list_addition[i] == v_vehicle_inf->m_zplist[j].zptype) {
                        break;
                    }
                }

                if (j == v_vehicle_inf->m_zplist.size()) {
                    return "0";
                }
            }
        }
        for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++) {
            /* 如果照片类型的第一个字符是数字，表示普通照片（非档案照片） */
            if ((v_vehicle_inf->m_dbbhglist[i].zptype[0] >= '0') && (v_vehicle_inf->m_dbbhglist[i].zptype[0] <= '9')) {
                for (j = 0; j < photo_all_list.size() ; j++)
                {
                    if(v_vehicle_inf->m_dbbhglist[i].zptype == photo_all_list[j])
                    {
                        if(v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                        {
                            if(is_pass == "0")
                            {
                                continue;
                            }
                            is_pass = "4";
                        }
                        else if(v_vehicle_inf->m_dbbhglist[i].dbresult == "5")
                            is_pass = "0";
                    }
                }
            }
        }
    } else if (g_CheckItem.City == FOSHAN){

        if (hdzk >= 7) {
            return "-1";
        }

        std::vector<std::string> small_vehicle = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38",
                                                  "K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48", "K49"};

        unsigned int i;
        for (i = 0; i < small_vehicle.size(); i++) {
            if (v_vehicle_inf->m_cllx == small_vehicle[i]) {
                break;
            }
        }

        if (i == small_vehicle.size()) {
            return "-1";
        }

        /*
         * 所有车，必须要有的基本照片。
         * 注：
         * 0208委托书，理论上本人办理车检时不需要，所以不考虑。
        */
        std::vector<std::string> basic_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0202", "0203", "0204", "0206", "0256", "0258", "0297",
            "0321", "0352", "0322", "0348"
        };

        /* “登记日期”超过10年的车，额外要有的照片 */
        std::vector<std::string> addition_list = {
            "0351", "0344", "0342", "0323"
        };

        /* 检查基本照片是否都有，并且都通过 */
        for (unsigned int i = 0; i < basic_list.size(); i++) {
            unsigned int j;

            for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {

                /* 找到一张基本照片，需要确认该照片是否通过 */
                if (basic_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                    for (unsigned int k = 0; k < v_vehicle_inf->m_dbbhglist.size(); k++) {
                        if (basic_list[i] == v_vehicle_inf->m_dbbhglist[k].zptype) {
                            return "0";
                        }
                    }

                    break;
                }
            }

            if (j == v_vehicle_inf->m_zplist.size()) {
                return "0";
            }
        }

        /* 检查额外的照片 */
        ResultCollection tmp;
        if (tmp.isTenYears(v_vehicle_inf)) {
            for (unsigned int i = 0; i < addition_list.size(); i++) {
                unsigned int j;

                for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {

                    /* 找到一张额外照片，需要确认该照片是否通过 */
                    if (addition_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                        for (unsigned int k = 0; k < v_vehicle_inf->m_dbbhglist.size(); k++) {
                            if (addition_list[i] == v_vehicle_inf->m_dbbhglist[k].zptype) {
                                return "0";
                            }
                        }

                        break;
                    }
                }

                if (j == v_vehicle_inf->m_zplist.size()) {
                    return "0";
                }
            }
        }

        return "1";

    } else if (g_CheckItem.City == LIANYUNGANG){
        if (hdzk >= 7) {
            return "-1";
        }
        std::vector<std::string> small_vehicle = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38",
                                                  "K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48", "K49"};
        unsigned int i,j;
        for (i = 0; i < small_vehicle.size(); i++) {
            if (v_vehicle_inf->m_cllx == small_vehicle[i]) {
                break;
            }

        }
        if (i == small_vehicle.size()) {
            return "-1";
        }
        /* “登记日期”为10年内的车，必须要有的照片 */
        std::vector<std::string> photo_list = {
            "0111", "0112", "0113", "0114", "0157", "0120",
            "0201", "0202", "0203", "0204", "0209", "0212", "0213",
            "0321", "0352", "0322", "0348"
        };

        /* “登记日期”超过10年的车，额外要有的照片 */
        std::vector<std::string> photo_list_addition = {
            "0351", "0344", "0342", "0323"
        };

        std::vector<std::string> photo_all_list = {
            "0111", "0112", "0113", "0114", "0157", "0120",
            "0201", "0202", "0203", "0204", "0209", "0212", "0213",
            "0321", "0352", "0322", "0348",
            "0351", "0344", "0342", "0323"
        };


        for (i = 0; i < photo_list.size(); i++) {
            for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                if (photo_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                    break;
                }
            }
            if (j == v_vehicle_inf->m_zplist.size()) {
                return "0";
            }
        }
        ResultCollection tmp;
        if (tmp.isTenYears(v_vehicle_inf)) {
            for (i = 0; i < photo_list_addition.size(); i++) {
                for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                    if (photo_list_addition[i] == v_vehicle_inf->m_zplist[j].zptype) {
                        break;
                    }
                }
                if (j == v_vehicle_inf->m_zplist.size()) {
                    return "0";
                }
            }
        }
        for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++) {
            /* 如果照片类型的第一个字符是数字，表示普通照片（非档案照片） */
            if ((v_vehicle_inf->m_dbbhglist[i].zptype[0] >= '0') && (v_vehicle_inf->m_dbbhglist[i].zptype[0] <= '9')) {
                for (j = 0; j < photo_all_list.size() ; j++)
                {
                    if(v_vehicle_inf->m_dbbhglist[i].zptype == photo_all_list[j])
                    {
                        if(v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                            if(v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                            {
                                if(is_pass == "0")
                                {
                                    continue;
                                }
                                is_pass = "4";
                            }
                            else if(v_vehicle_inf->m_dbbhglist[i].dbresult == "5")
                                is_pass = "0";
                    }
                }
            }
        }
    }
    else if (g_CheckItem.City == HUZHOU){
            if (hdzk >= 7) {
                return "-1";
            }
            std::vector<std::string> small_vehicle = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38",
                                                      "K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48", "K49"};
            unsigned int i,j;
            for (i = 0; i < small_vehicle.size(); i++) {
                if (v_vehicle_inf->m_cllx == small_vehicle[i]) {
                    break;
                }

            }
            if (i == small_vehicle.size()) {
                return "-1";
            }
            std::vector<std::string> photo_list;
            std::vector<std::string> photo_all_list;
            if (v_vehicle_inf->m_hpzl == "52") {    /* 小型新能源汽车 */
                /* “登记日期”为10年内的车，必须要有的照片 */
                photo_list = {
                    "0111", "0112", "0113", "0157",
                    "0201", "0202", "0203", "0204", "0205",
                    "0321", "0352", "0322", "0348"
                };
            }
            else
            {
                /* “登记日期”为10年内的车，必须要有的照片 */
                photo_list = {
                    "0111", "0112", "0113", "0157",
                    "0201", "0202", "0203", "0204", "0205", "0209",
                    "0321", "0352", "0322", "0348"
                };
            }


            /* “登记日期”超过10年的车，额外要有的照片 */
            std::vector<std::string> photo_list_addition = {
                "0351", "0344", "0342", "0323"
            };

            if (v_vehicle_inf->m_hpzl == "52") {    /* 小型新能源汽车 */
                photo_all_list = {
                                "0111", "0112", "0113", "0157",
                                "0201", "0202", "0203", "0204", "0205",
                                "0321", "0352", "0322", "0348",
                                "0351", "0344", "0342", "0323"
                            };
            }
            else
            {
                photo_all_list = {
                    "0111", "0112", "0113", "0157",
                    "0201", "0202", "0203", "0204", "0205", "0209",
                    "0321", "0352", "0322", "0348",
                    "0351", "0344", "0342", "0323"
                };
            }



            for (i = 0; i < photo_list.size(); i++) {
                for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                    if (photo_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                        break;
                    }
                }
                if (j == v_vehicle_inf->m_zplist.size()) {
                    return "0";
                }
            }
            ResultCollection tmp;
            if (tmp.isTenYears(v_vehicle_inf)) {
                for (i = 0; i < photo_list_addition.size(); i++) {
                    for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                        if (photo_list_addition[i] == v_vehicle_inf->m_zplist[j].zptype) {
                            break;
                        }
                    }
                    if (j == v_vehicle_inf->m_zplist.size()) {
                        return "0";
                    }
                }
            }
            for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++) {
                /* 如果照片类型的第一个字符是数字，表示普通照片（非档案照片） */
                if ((v_vehicle_inf->m_dbbhglist[i].zptype[0] >= '0') && (v_vehicle_inf->m_dbbhglist[i].zptype[0] <= '9')) {
                    for (j = 0; j < photo_all_list.size() ; j++)
                    {
                        if(v_vehicle_inf->m_dbbhglist[i].zptype == photo_all_list[j])
                        {

                                if(v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                                {
                                    if(is_pass == "0")
                                    {
                                        continue;
                                    }
                                    is_pass = "4";
                                }
                                else if(v_vehicle_inf->m_dbbhglist[i].dbresult == "5")
                                    is_pass = "0";
                        }
                    }
                }
            }
    } else if (g_CheckItem.City == XIAN){
        if (isReCheck(v_vehicle_inf->m_jylsh)) {
            return "-1";
        }
        if (("A" != v_vehicle_inf->m_syxz) &&
            ("D" != v_vehicle_inf->m_syxz) &&
            ("G" != v_vehicle_inf->m_syxz) &&
            ("M" != v_vehicle_inf->m_syxz) &&
            ("L" != v_vehicle_inf->m_syxz))
        {
            return "-1";
        }

        unsigned int i,j;
        if ("K39" != v_vehicle_inf->m_cllx)
        {
            if (hdzk >= 7)
            {
                return "-1";
            }

            std::vector<std::string> small_vehicle = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38",
                                                      "K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48",
                                                      "H31", "H32", "H33" };
            for (i = 0; i < small_vehicle.size(); i++)
            {
                if (v_vehicle_inf->m_cllx == small_vehicle[i]) {
                    break;
                }
            }

            if (i == small_vehicle.size()) {
                return "-1";
            }
        }

        std::vector<std::string> photo_list = {
            "0111", "0112", "0113", "0157", "0166", "0167",
            "0201", "0203", "0204", "0224", "0225", "0260", "0261"
        };
        /* 新车没有牌证申请表 */
        if (!v_vehicle_inf->is_new_vehicle) {
            photo_list.push_back("0202");
        }

        for (i = 0; i < photo_list.size(); i++)
        {
            for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                if (photo_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                    break;
                }
            }

            if (j == v_vehicle_inf->m_zplist.size()) {
                return "0";
            }
        }

        for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++)
        {
            /* 如果照片类型的第一个字符是数字，表示普通照片（非档案照片） */
            if ((v_vehicle_inf->m_dbbhglist[i].zptype[0] >= '0') && (v_vehicle_inf->m_dbbhglist[i].zptype[0] <= '9')) {
                for (j = 0; j < photo_list.size() ; j++)
                {
                    if(v_vehicle_inf->m_dbbhglist[i].zptype == photo_list[j])
                    {
                        if(v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                        {
                            if(is_pass == "0")
                            {
                                continue;
                            }
                            is_pass = "4";
                        }
                        else if(v_vehicle_inf->m_dbbhglist[i].dbresult == "5")
                            is_pass = "0";
                    }
                }
            }
        }
    } else if (g_CheckItem.City == SHANGHAI) {
        return is_pass_ShangHai(v_vehicle_inf, hdzk);
    } else if (g_CheckItem.City == LIANGSHAN) {
        if (isReCheck(v_vehicle_inf->m_jylsh)) {
            return "-1";
        }
        if (hdzk >= 7) {
            return "-1";
        }
        if (v_vehicle_inf->m_syxz.compare("A") != 0) {
            return "-1";
        }
        std::vector<std::string> small_vehicle = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38","K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48", "K49"};
        unsigned int i,j;
        for (i = 0; i < small_vehicle.size(); i++)
        {
            if (v_vehicle_inf->m_cllx == small_vehicle[i]) {
                break;
            }
        }

        if (i == small_vehicle.size()) {
            return "-1";
        }
        /* “登记日期”为10年内的车，必须要有的照片 */
        std::vector<std::string> photo_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0202", "0203", "0204", "0205",
            "0321", "0322"
        };

        /* “登记日期”超过10年的车，额外要有的照片 */
        std::vector<std::string> photo_list_addition = {
            "0351", "0323"
        };

        std::vector<std::string> photo_all_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0202", "0203", "0204", "0205",
            "0321", "0322",
            "0351", "0323"
        };

        for (i = 0; i < photo_list.size(); i++)
        {
            for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                if (photo_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                    break;
                }
            }

            if (j == v_vehicle_inf->m_zplist.size()) {
                return "0";
            }
        }

        ResultCollection tmp;
        if (tmp.isTenYears(v_vehicle_inf)) {
            for (i = 0; i < photo_list_addition.size(); i++) {
                for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                    if (photo_list_addition[i] == v_vehicle_inf->m_zplist[j].zptype) {
                        break;
                    }
                }

                if (j == v_vehicle_inf->m_zplist.size()) {
                    return "0";
                }
            }
        }
        for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++)
        {
            /* 如果照片类型的第一个字符是数字，表示普通照片（非档案照片） */
            if ((v_vehicle_inf->m_dbbhglist[i].zptype[0] >= '0') && (v_vehicle_inf->m_dbbhglist[i].zptype[0] <= '9')) {
                for (j = 0; j < photo_all_list.size() ; j++)
                {
                    if(v_vehicle_inf->m_dbbhglist[i].zptype == photo_all_list[j])
                    {
                        if(v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                            if(v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                            {
                                if(is_pass == "0")
                                {
                                    continue;
                                }
                                is_pass = "4";
                            }
                            else if(v_vehicle_inf->m_dbbhglist[i].dbresult == "5")
                                is_pass = "0";
                        else if(v_vehicle_inf->m_dbbhglist[i].dbresult == "5")
                            is_pass = "0";
                    }
                }
            }
        }
    } else if (g_CheckItem.City == NANCHONG) {
        if (isReCheck(v_vehicle_inf->m_jylsh)) {
            return "-1";
        }
        if (hdzk >= 7) {
            return "-1";
        }
        if (v_vehicle_inf->m_syxz.compare("A") != 0) {
            return "-1";
        }
        std::vector<std::string> small_vehicle = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38","K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48", "K49"};
        unsigned int i,j;
        for (i = 0; i < small_vehicle.size(); i++)
        {
            if (v_vehicle_inf->m_cllx == small_vehicle[i]) {
                break;
            }
        }

        if (i == small_vehicle.size()) {
            return "-1";
        }
        /* “登记日期”为10年内的车，必须要有的照片 */
        std::vector<std::string> photo_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0202", "0203", "0204", "0298",
            "0321", "0352", "0322", "0348"
        };

        /* “登记日期”超过10年的车，额外要有的照片 */
        std::vector<std::string> photo_list_addition = {
            "0351", "0323", "0342", "0344"
        };

        std::vector<std::string> photo_all_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0202", "0203", "0204", "0206", "0210", "0298",
            "0321", "0352", "0322", "0348",
            "0351", "0323", "0342", "0344"
        };

        for (i = 0; i < photo_list.size(); i++)
        {
            for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                if (photo_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                    break;
                }
            }

            if (j == v_vehicle_inf->m_zplist.size()) {
                return "0";
            }
        }

        ResultCollection tmp;
        if (tmp.isTenYears(v_vehicle_inf)) {
            for (i = 0; i < photo_list_addition.size(); i++) {
                for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                    if (photo_list_addition[i] == v_vehicle_inf->m_zplist[j].zptype) {
                        break;
                    }
                }

                if (j == v_vehicle_inf->m_zplist.size()) {
                    return "0";
                }
            }
        }
        for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++)
        {
            /* 如果照片类型的第一个字符是数字，表示普通照片（非档案照片） */
            if ((v_vehicle_inf->m_dbbhglist[i].zptype[0] >= '0') && (v_vehicle_inf->m_dbbhglist[i].zptype[0] <= '9')) {
                for (j = 0; j < photo_all_list.size() ; j++)
                {
                    if(v_vehicle_inf->m_dbbhglist[i].zptype == photo_all_list[j])
                    {
                        if(v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                            if(v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                            {
                                if(is_pass == "0")
                                {
                                    continue;
                                }
                                is_pass = "4";
                            }
                            else if(v_vehicle_inf->m_dbbhglist[i].dbresult == "5")
                                is_pass = "0";
                        else if(v_vehicle_inf->m_dbbhglist[i].dbresult == "5")
                            is_pass = "0";
                    }
                }
            }
        }
    } else if (g_CheckItem.City == JIAOZUO) {
        if (isReCheck(v_vehicle_inf->m_jylsh)) {
            return "-1";
        }
        if (hdzk > 7) {
            return "-1";
        }
        if (v_vehicle_inf->m_syxz.compare("A") != 0) {
            return "-1";
        }
        std::vector<std::string> small_vehicle = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38","K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48"};
        unsigned int i,j;
        for (i = 0; i < small_vehicle.size(); i++)
        {
            if (v_vehicle_inf->m_cllx == small_vehicle[i]) {
                break;
            }
        }

        if (i == small_vehicle.size()) {
            return "-1";
        }
        /* “登记日期”为10年内的车，必须要有的照片 */
        std::vector<std::string> photo_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0204", "0296", "0210",
            "0321", "0352", "0322", "0348"
        };
        bool b_has = false;
        for (auto it = v_vehicle_inf->m_zplist.begin(); it != v_vehicle_inf->m_zplist.end(); it++)
        {
            if ("0203" == (*it).zptype)
            {
                photo_list.push_back("0203");
                b_has = true;
            }
        }

        if ((v_vehicle_inf->m_jqxdzbd != 1) && (!b_has) && (!g_TestMode))
        {
            return "0";
        }

        /* “登记日期”超过10年的车，额外要有的照片 */
        std::vector<std::string> photo_list_addition = {
            "0351", "0344", "0342", "0323"
        };

        std::vector<std::string> photo_all_list = photo_list;
        for (unsigned int i = 0; i < photo_list_addition.size(); i++)
        {
            photo_all_list.push_back(photo_list_addition[i]);
        }

        for (i = 0; i < photo_list.size(); i++)
        {
            for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                if (photo_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                    break;
                }
            }

            if (j == v_vehicle_inf->m_zplist.size()) {
                return "0";
            }
        }

        ResultCollection tmp;
        if (tmp.isTenYears(v_vehicle_inf)) {
            for (i = 0; i < photo_list_addition.size(); i++) {
                for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                    if (photo_list_addition[i] == v_vehicle_inf->m_zplist[j].zptype) {
                        break;
                    }
                }

                if (j == v_vehicle_inf->m_zplist.size()) {
                    return "0";
                }
            }
        }
        for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++)
        {
            /* 如果照片类型的第一个字符是数字，表示普通照片（非档案照片） */
            if ((v_vehicle_inf->m_dbbhglist[i].zptype[0] >= '0') && (v_vehicle_inf->m_dbbhglist[i].zptype[0] <= '9')) {
                for (j = 0; j < photo_all_list.size() ; j++)
                {
                    if(v_vehicle_inf->m_dbbhglist[i].zptype == photo_all_list[j])
                    {
                        if(v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                        {
                            if(is_pass == "0")
                            {
                                continue;
                            }
                            is_pass = "4";
                        }
                        else if(v_vehicle_inf->m_dbbhglist[i].dbresult == "5")
                            is_pass = "0";
                    }
                }
            }
        }
    } else if (g_CheckItem.City == LANGFANG) {
        if (isReCheck(v_vehicle_inf->m_jylsh)) {
            return "-1";
        }
        if (hdzk >= 7) {
            return "-1";
        }
        if (v_vehicle_inf->m_syxz.compare("A") != 0) {
            return "-1";
        }
        std::vector<std::string> small_vehicle = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38","K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48"};
        unsigned int i,j;
        for (i = 0; i < small_vehicle.size(); i++)
        {
            if (v_vehicle_inf->m_cllx == small_vehicle[i]) {
                break;
            }
        }

        if (i == small_vehicle.size()) {
            return "-1";
        }
        /* “登记日期”为10年内的车，必须要有的照片 */
        std::vector<std::string> photo_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0203", "0204", "0202", "0296", "0297",
            "0321", "0352", "0322", "0348"
        };

        /* “登记日期”超过10年的车，额外要有的照片 */
        std::vector<std::string> photo_list_addition = {
            "0351", "0323"
        };

        std::vector<std::string> photo_all_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0203", "0204", "0202", "0296", "0297",
            "0321", "0352", "0322", "0348",
            "0351", "0323"
        };

        for (i = 0; i < photo_list.size(); i++)
        {
            for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                if (photo_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                    break;
                }
            }

            if (j == v_vehicle_inf->m_zplist.size()) {
                return "0";
            }
        }

        ResultCollection tmp;
        if (tmp.isTenYears(v_vehicle_inf)) {
            for (i = 0; i < photo_list_addition.size(); i++) {
                for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                    if (photo_list_addition[i] == v_vehicle_inf->m_zplist[j].zptype) {
                        break;
                    }
                }

                if (j == v_vehicle_inf->m_zplist.size()) {
                    return "0";
                }
            }
        }
        for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++)
        {
            /* 如果照片类型的第一个字符是数字，表示普通照片（非档案照片） */
            if ((v_vehicle_inf->m_dbbhglist[i].zptype[0] >= '0') && (v_vehicle_inf->m_dbbhglist[i].zptype[0] <= '9')) {
                for (j = 0; j < photo_all_list.size() ; j++)
                {
                    if(v_vehicle_inf->m_dbbhglist[i].zptype == photo_all_list[j])
                    {
                        if(v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                        {
                            if(is_pass == "0")
                            {
                                continue;
                            }
                            is_pass = "4";
                        }
                        else if(v_vehicle_inf->m_dbbhglist[i].dbresult == "5")
                            is_pass = "0";
                    }
                }
            }
        }
    } else if (g_CheckItem.City == XIANNING){
        if (isReCheck(v_vehicle_inf->m_jylsh)) {
            return "-1";
        }
        if (hdzk > 7) {
            return "-1";
        }
        if (v_vehicle_inf->m_syxz.compare("A") != 0) {
            return "-1";
        }
        std::vector<std::string> small_vehicle = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38","K39","K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48"};
        unsigned int i,j;
        for (i = 0; i < small_vehicle.size(); i++)
        {
            if (v_vehicle_inf->m_cllx == small_vehicle[i]) {
                break;
            }
        }

        if (i == small_vehicle.size()) {
            return "-1";
        }
        /* “登记日期”为10年内的车，必须要有的照片 */
        std::vector<std::string> photo_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0202", "0203", "0204", "0205", "0260",
            "0321", "0352", "0322", "0348"
        };

        /* “登记日期”超过10年的车，额外要有的照片 */
        std::vector<std::string> photo_list_addition = {
            "0351", "0344", "0342", "0323"
        };

        std::vector<std::string> photo_all_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0202", "0203", "0204", "0205", "0260",
            "0321", "0352", "0322", "0348",
            "0351", "0344", "0342", "0323"
        };

        for (i = 0; i < photo_list.size(); i++)
        {
            for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                if (photo_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                    break;
                }
            }

            if ((photo_list[i] == "0260") || (photo_list[i] == "0261"))
            {
                if (v_vehicle_inf->b_xianning_wrw_pass)
                    continue;
                else
                    return "0";
            }

            if (j == v_vehicle_inf->m_zplist.size()) {
                return "0";
            }
        }


        ResultCollection tmp;
        if (tmp.isTenYears(v_vehicle_inf)) {
            for (i = 0; i < photo_list_addition.size(); i++) {
                for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                    if (photo_list_addition[i] == v_vehicle_inf->m_zplist[j].zptype) {
                        break;
                    }
                }

                if (j == v_vehicle_inf->m_zplist.size()) {
                    return "0";
                }
            }
        }
        for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++)
        {
            /* 如果照片类型的第一个字符是数字，表示普通照片（非档案照片） */
            if ((v_vehicle_inf->m_dbbhglist[i].zptype[0] >= '0') && (v_vehicle_inf->m_dbbhglist[i].zptype[0] <= '9')) {
                for (j = 0; j < photo_all_list.size() ; j++)
                {
                    if(v_vehicle_inf->m_dbbhglist[i].zptype == photo_all_list[j])
                    {
                        if(v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                        {
                            if(is_pass == "0")
                            {
                                continue;
                            }
                            is_pass = "4";
                        }
                        else if(v_vehicle_inf->m_dbbhglist[i].dbresult == "5")
                            is_pass = "0";
                    }
                }
            }
        }
    } else if (g_CheckItem.City == BINZHOU) {
        if (isReCheck(v_vehicle_inf->m_jylsh)) {
            return "-1";
        }
        if (hdzk >= 7) {
            return "-1";
        }
        if (v_vehicle_inf->m_syxz.compare("A") != 0) {
            return "-1";
        }
        std::vector<std::string> small_vehicle = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38","K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48"};
        unsigned int i,j;
        for (i = 0; i < small_vehicle.size(); i++)
        {
            if (v_vehicle_inf->m_cllx == small_vehicle[i]) {
                break;
            }
        }

        if (i == small_vehicle.size()) {
            return "-1";
        }
        /* “登记日期”为10年内的车，必须要有的照片 */
        std::vector<std::string> photo_list = {
            "0111", "0112", "0113", "0157", "0158",
            "0201", "0215", "0202", "0204", "0209", "0214",
            "0321", "0352", "0322", "0348"
        };
        for (auto it = v_vehicle_inf->m_zplist.begin(); it != v_vehicle_inf->m_zplist.end(); it++)
        {
            if ("0203" == (*it).zptype)
                photo_list.push_back("0203");
        }

        /* “登记日期”超过10年的车，额外要有的照片 */
        std::vector<std::string> photo_list_addition = {
            "0323", "0342", "0344", "0351"
        };

        std::vector<std::string> photo_all_list = photo_list;
        for (unsigned int i = 0; i < photo_list_addition.size(); i++)
        {
            photo_all_list.push_back(photo_list_addition[i]);
        }

        for (i = 0; i < photo_list.size(); i++)
        {
            for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                if (photo_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                    break;
                }
            }

            if (j == v_vehicle_inf->m_zplist.size()) {
                return "0";
            }
        }

        ResultCollection tmp;
        if (tmp.isTenYears(v_vehicle_inf)) {
            for (i = 0; i < photo_list_addition.size(); i++) {
                for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                    if (photo_list_addition[i] == v_vehicle_inf->m_zplist[j].zptype) {
                        break;
                    }
                }

                if (j == v_vehicle_inf->m_zplist.size()) {
                    return "0";
                }
            }
        }
        for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++)
        {
            /* 如果照片类型的第一个字符是数字，表示普通照片（非档案照片） */
            if ((v_vehicle_inf->m_dbbhglist[i].zptype[0] >= '0') && (v_vehicle_inf->m_dbbhglist[i].zptype[0] <= '9')) {
                for (j = 0; j < photo_all_list.size() ; j++)
                {
                    if(v_vehicle_inf->m_dbbhglist[i].zptype == photo_all_list[j])
                    {
                        if(v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                        {
                            if(is_pass == "0")
                            {
                                continue;
                            }
                            is_pass = "4";
                        }
                        else if(v_vehicle_inf->m_dbbhglist[i].dbresult == "5")
                            is_pass = "0";
                    }
                }
            }
        }
    } else if (g_CheckItem.City == QingDao){
        if (isReCheck(v_vehicle_inf->m_jylsh)){
            return "-1";
        }
        if (hdzk > 7){
            return "-1";
        }
        if (v_vehicle_inf->m_syxz.compare("A") != 0){
            return "-1";
        }
        std::vector<std::string> small_vehicle = {"K30","K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38","K39","K40","K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48", "K49"};
        unsigned int i,j;
        for (i = 0;i < small_vehicle.size(); i++)
        {
            if (v_vehicle_inf->m_cllx == small_vehicle[i]){
                break;
            }
        }
        if (i == small_vehicle.size()){
            return "-1";
        }
        /* “登记日期”为10年内的车，必须要有的照片 */
        std::vector<std::string> photo_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0204", "0296", "0210",
            "0321", "0352", "0322", "0348"
        };

        /* “登记日期”超过10年的车，额外要有的照片 */
        std::vector<std::string> photo_list_addition = {
            "0351", "0323", "0342", "0344"
        };

        std::vector<std::string> photo_all_list = {
            "0111", "0112", "0113", "0157",
            "0201", "0202", "0203", "0204", "0209",
            "0321", "0352", "0322", "0348",
            "0351", "0323", "0342", "0344"
        };
        for (i = 0; i < photo_list.size(); i++)
        {
            for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++)
            {
                if(photo_list[i] == v_vehicle_inf->m_zplist[j].zptype){
                    break;
                }
            }
            if (j == v_vehicle_inf->m_zplist.size()){
                return "0";
            }
        }
        ResultCollection tmp;
        if (tmp.isTenYears(v_vehicle_inf)){
            for (i = 0; i < photo_list_addition.size(); i++)
            {
                for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++)
                {
                    if (photo_list_addition[i] == v_vehicle_inf->m_zplist[j].zptype){
                        break;
                    }
                }
                if (j == v_vehicle_inf->m_zplist.size()){
                    return "0";
                }
            }
        }
        for (i = 0;i < v_vehicle_inf->m_dbbhglist.size(); i++)
        {
            /* 如果照片类型的第一个字符是数字，表示普通照片（非档案照片） */
            if((v_vehicle_inf->m_dbbhglist[i].zptype[0] >= '0') && (v_vehicle_inf->m_dbbhglist[i].zptype[0] <= '9')){
                for (j = 0; j < photo_all_list.size(); j++)
                {
                    if (v_vehicle_inf->m_dbbhglist[i].zptype == photo_all_list[j]){
                        if (v_vehicle_inf->m_dbbhglist[i].dbresult == "4"){
                            if (v_vehicle_inf->m_dbbhglist[i].dbresult == "4")
                            {
                                if (is_pass == "0")
                                {
                                    continue;
                                }
                                is_pass = "4";
                            }
                            else if (v_vehicle_inf->m_dbbhglist[i].dbresult == "5")
                                is_pass = "0";
                        }
                    }
                }
            }
        }


    }else {    /* 没有特殊约定的其他城市 */
        ResultCollection tmp;
        isPass res(v_vehicle_inf, g_CheckItem ,tmp.isTenYears(v_vehicle_inf));
        is_pass = res.returnIsPass();
    }

    return is_pass;
}

void operateDatabase(const vehicle_inf *v_vehicle_inf)
{
    MySQL_DB db;
    std::string checks_String;				/* 表vehicle_checks数据记录，用于从机写入主机数据库 */
    std::string timeString;
    unsigned int algorithm_total = 0;

    DATA_PRINT(LEVEL_INFO, "Write data into the local database...... \n");
    if (db.connect(NULL, 6033, "root", getDBPassWord(DBPWD).c_str(), "car_schema")) {
        std::string idString;
        std::string sqlString;

        /* 注意字段排列顺序必须和vehicle_inf里面的item_description成员顺序一致 */
        sqlString = "("
                    "jylsh, jyjgbh, jylb, hpzl, hphm, clsbdh, syr, sjhm, sxrq, zzrq, "
                    "cllx, syxz, zbzl, kssj, jssj, fdjh, clpp, clxh, ccdjrq, ccrq, "
                    "wgjcjyy, xszbh, fzrq, rlzl, zpzs, ckbdzplist, zplist, spzs, splist, bdbhgs, "
                    "bdbhglist, csys, pl, gl, zxxs, cwkc, cwkk, cwkg, hxnbcd, hxnbkd, "
                    "hxnbgd, gbthps, zs, zj, qlj, hlj, ltgg, lts, zzl, hdzzl, "
                    "hdzk, zqyzl, qpzk, hpzk, clyt, ytsx, sfxny, xnyzl, yxqz, fzjg, "
                    "hbdbqk, qzbfqz, xzqh, gcjk, dybj, zzg, clpp2, jyhgbzbh, sfmj, zt, "
                    "djrq, zsxzqh, zzxzqh, fdjxh, sgcssbwqk, bmjyy, glbm, zzcmc, jylsh2, "
                    "is_pass, device_id, created_at"
                    ")"
                    " VALUES "
                    "(";

        /* 插入车辆数据 */
        for (unsigned int i = 0; i < v_vehicle_inf->item_description.size(); i++) {
            if (strcmp(v_vehicle_inf->item_description[i].name_tag, "ckdbzplist") == 0) {
                CMarkup xml;
                xml.SetDoc("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n");
                xml.AddElem("root");
                xml.IntoElem();
                setlocale(LC_ALL, "chs");

                for (unsigned int j = 0; j < v_vehicle_inf->m_ckdbzplist.size(); j++) {
                    xml.AddElem("item");
                    xml.AddChildElem("zpzl");
                    xml.SetChildData(v_vehicle_inf->m_ckdbzplist[j].zptype);
                    xml.AddChildElem("zpurl");
                    xml.SetChildData(v_vehicle_inf->m_ckdbzplist[j].zpurl);
                }

                std::string xmlstring;
                xmlstring = xml.GetDoc();
                if(/*g_CheckItem.City == XIANGYANG*/false)
                {
                    sqlString += "ENCODE('" + xmlstring + "','key'),";
                }
                else {
                    sqlString += "'" + xmlstring + "',";
                }
            } else if (strcmp(v_vehicle_inf->item_description[i].name_tag, "zplist") == 0) {
                CMarkup xml;
                xml.SetDoc("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n");
                xml.AddElem("root");
                xml.IntoElem();
                setlocale(LC_ALL, "chs");

                for (unsigned int j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                    xml.AddElem("item");
                    xml.AddChildElem("zpzl");
                    xml.SetChildData(v_vehicle_inf->m_zplist[j].zptype);
                    xml.AddChildElem("zpurl");
                    xml.SetChildData(v_vehicle_inf->m_zplist[j].zpurl);
                }

                std::string xmlstring;
                xmlstring = xml.GetDoc();
                if(/*g_CheckItem.City == XIANGYANG*/false)
                {
                    sqlString += "ENCODE('" + xmlstring + "','key'),";
                }
                else {
                    sqlString += "'" + xmlstring + "',";
                }
            } else if (strcmp(v_vehicle_inf->item_description[i].name_tag, "splist") == 0) {
                CMarkup xml;
                xml.SetDoc("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n");
                xml.AddElem("root");
                xml.IntoElem();
                setlocale(LC_ALL, "chs");

                for (unsigned int j = 0; j < v_vehicle_inf->m_splist.size(); j++) {
                    xml.AddElem("item");
                    xml.AddChildElem("spzl");
                    xml.SetChildData(v_vehicle_inf->m_splist[j].sptype);
                    xml.AddChildElem("dzzl");
                    xml.SetChildData(v_vehicle_inf->m_splist[j].dzzl);
                    xml.AddChildElem("spurl");
                    xml.SetChildData(v_vehicle_inf->m_splist[j].spurl);
                }

                std::string xmlstring;
                xmlstring = xml.GetDoc();
                if(/*g_CheckItem.City == XIANGYANG*/false)
                {
                    sqlString += "ENCODE('" + xmlstring + "','key'),";
                }
                else {
                    sqlString += "'" + xmlstring + "',";
                }
            } else if (strcmp(v_vehicle_inf->item_description[i].name_tag, "dbbhglist") == 0) {
                CMarkup xml;
                xml.SetDoc("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n");
                xml.AddElem("root");
                xml.IntoElem();
                setlocale(LC_ALL, "chs");

                for (unsigned int j = 0; j < v_vehicle_inf->m_dbbhglist.size(); j++) {
                    xml.AddElem("item");
                    xml.AddChildElem("zpzl");
                    xml.SetChildData(v_vehicle_inf->m_dbbhglist[j].zptype);
                    xml.AddChildElem("sm");
                    xml.SetChildData(v_vehicle_inf->m_dbbhglist[j].dbbhg_desc);
                    xml.AddChildElem("jg");
                    xml.SetChildData(v_vehicle_inf->m_dbbhglist[j].dbresult);
                    xml.AddChildElem("zpid");
                    xml.SetChildData(v_vehicle_inf->m_dbbhglist[j].zpid);
                }

                std::string xmlstring;
                xmlstring = xml.GetDoc();
                if(/*g_CheckItem.City == XIANGYANG*/false)
                {
                    sqlString += "ENCODE('" + xmlstring + "','key'),";
                }
                else {
                    sqlString += "'" + xmlstring + "',";
                }


            } else {	/* 非XML格式的普通数据 */
                std::string tmp = *(std::string *)(v_vehicle_inf->item_description[i].value);
                if(/*g_CheckItem.City == XIANGYANG*/false)
                {
                    sqlString += "ENCODE('" + tmp + "','key'),";
                }
                else {
                    sqlString += "'" + tmp + "',";
                }

            }
        }

        CityType cityType = (CityType)atoi(g_CheckItem.City.c_str());
//        bool isNewPhotoProcess = processBaseClass::checkCity(cityType);
//        if(isNewPhotoProcess)
//        {
            sqlString += "'" + v_vehicle_inf->m_isPass + "',";
//        }
//        else
//        {
//            sqlString += "'" + v_vehicle_inf->m_isPass + "',";
//        }
        sqlString += "'" + v_vehicle_inf->m_deviceId + "',";
        /* 插入当前时间，并将条目加入表vehicle_checks */
        std::time_t t = std::time(NULL);
        std::tm *st = std::localtime(&t);
        char tmpArray[128] = { 0 };
        sprintf(tmpArray, "%d-%02d-%02d %02d:%02d:%02d",
                st->tm_year + 1900, st->tm_mon + 1, st->tm_mday,
                st->tm_hour, st->tm_min, st->tm_sec);
        timeString = tmpArray;
        sqlString += "'" + timeString + "'";
        sqlString += ")";

        checks_String = sqlString;
        DATA_PRINT(LEVEL_INFO, "Insert into vehicle_checks, data: %s \n", sqlString.c_str());

        bool tableResult = false;
        tableResult = db.insert("vehicle_checks", sqlString.c_str());

        /* 准备表check_infos的数据(由于它的外键关联了vehicle_checks的主键，因此必须判断上一个语句成功) */
        if (tableResult) {
            unsigned long id = 0;
            if ((id = db.getLastID()) != 0) {
                char tmpArray[128] = { 0 };
                sprintf(tmpArray, "%lu", id);
                idString = tmpArray;

                /* 检索照片列表，并标注判定结果 */
                for (unsigned int j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                    sqlString = "(vehicle_check_id, category, name, result, reason, created_at) VALUES (";

                    sqlString += "'" + idString + "',";
                    sqlString += "'" + v_vehicle_inf->m_zplist[j].zptype + "',";
                    sqlString += "'" + v_vehicle_inf->m_zplist[j].local_path + "',";

                    /* 查询本文件是否在不合格列表中出现 */
                    unsigned int i;
                    for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++) {
                        if (v_vehicle_inf->m_zplist[j].zptype == v_vehicle_inf->m_dbbhglist[i].zptype) {
                            sqlString += "'" + v_vehicle_inf->m_dbbhglist[i].dbresult + "',";
                            sqlString += "'" + v_vehicle_inf->m_dbbhglist[i].dbbhg_desc + "'";
                            break;
                        }
                    }

                    if (i == v_vehicle_inf->m_dbbhglist.size()) {
                        sqlString += "'1',";	/*0--未处理， 1--通过，其他--不通过 */
                        sqlString += "'通过'";
                    }

                    sqlString += ",";
                    sqlString += "'" + timeString + "'";
                    sqlString += ")";

                    DATA_PRINT(LEVEL_DEBUG, "Insert into check_infos, data: %s \n", sqlString.c_str());
                    db.insert("check_infos", sqlString.c_str());
                }

                if (g_CheckItem.picture.CheJiaHao.BaoDing_FTP) {
                    sqlString = "(vehicle_check_id, category, name, result, reason, created_at) VALUES (";
                    sqlString += "'" + idString + "',";
                    sqlString += "'J_FTP',";
                    sqlString += "'" + v_vehicle_inf->BaoDing_J_FTP + "',";
                    sqlString += "'1',";	/*0--未处理， 1--通过，其他--不通过 */
                    sqlString += "'保定车架号档案照片'";
                    sqlString += ",";
                    sqlString += "'" + timeString + "'";
                    sqlString += ")";

                    DATA_PRINT(LEVEL_DEBUG, "Insert into check_infos, data: %s \n", sqlString.c_str());
                    db.insert("check_infos", sqlString.c_str());
                }

                /* 检索视频列表，并标注判定结果 */
                for (unsigned int j = 0; j < v_vehicle_inf->m_splist.size(); j++) {
                    sqlString = "(vehicle_check_id, category, name, result, reason, created_at) VALUES (";

                    sqlString += "'" + idString + "',";
                    sqlString += "'" + v_vehicle_inf->m_splist[j].sptype + "',";
                    sqlString += "'" + v_vehicle_inf->m_splist[j].local_path + "',";

                    /* 查询本文件是否在不合格列表中出现 */
                    unsigned int i;
                    for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++) {
                        if (v_vehicle_inf->m_splist[j].sptype == v_vehicle_inf->m_dbbhglist[i].zptype) {
                            sqlString += "'" + v_vehicle_inf->m_dbbhglist[i].dbresult + "',";
                            sqlString += "'" + v_vehicle_inf->m_dbbhglist[i].dbbhg_desc + "'";
                            break;
                        }
                    }

                    if (i == v_vehicle_inf->m_dbbhglist.size()) {
                        sqlString += "'1',";	/*0--未处理， 1--通过，其他--不通过 */
                        sqlString += "'通过'";
                    }

                    sqlString += ",";
                    sqlString += "'" + timeString + "'";
                    sqlString += ")";

                    DATA_PRINT(LEVEL_DEBUG, "Insert into check_infos, data: %s \n", sqlString.c_str());
                    db.insert("check_infos", sqlString.c_str());
                }
            }
        }

        /* 准备写入表time_infos */
        if (tableResult) {
            if (idString != "0") {
                try {
                    /* 计算出算法处理的总时间 */
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.xsz == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.xsz));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.sqb == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.sqb));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.jqx == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.jqx));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.jybg == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.jybg));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.cyjl == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.cyjl));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.zqf == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.zqf));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.yhf == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.yhf));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.cjh == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.cjh));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.aqd == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.aqd));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.zdg == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.zdg));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.ydg == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.ydg));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.yzzd == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.yzzd));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.ezzd == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.ezzd));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.zczd == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.zczd));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.dpdtks == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.dpdtks));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.dpdtjs == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.dpdtjs));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.dpjy == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.dpjy));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.wqjy == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.wqjy));

                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.xszbk == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.xszbk));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.jyb_bk == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.jyb_bk));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.wts == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.wts));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.zqfcf == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.zqfcf));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.yhfcf == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.yhfcf));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.cjhcf == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.cjhcf));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.wszm == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.wszm));

                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.wttzs == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.wttzs));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.jyhgzm == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.jyhgzm));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.hdzk == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.hdzk));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.dchw == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.dchw));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.sfz == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.sfz));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.sfzbk == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.sfzbk));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.jcqxbg == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.jcqxbg));

                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.chexiang == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.chexiang));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.cjh_ug == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.cjh_ug));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.chgw == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.chgw));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.waikuoqianmian == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.waikuoqianmian));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.waikuocemian == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.waikuocemian));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.wxnb == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.wxnb));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.fzzd == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.fzzd));

                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.abs == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.abs));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.clcm == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.clcm));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.cjhyj == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.cjhyj));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.qhp == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.qhp));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.hhp == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.hhp));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.clbm == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.clbm));
                    algorithm_total += (v_vehicle_inf->timeRecord.picture.process.dchp == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.dchp));
                }  catch (const std::exception &e) {
                    DATA_PRINT(LEVEL_INFO, "Exception! std::stoi() \n");
                    DATA_PRINT(LEVEL_INFO, "Exception cause: %s \n", e.what());
                    algorithm_total = 0;
                }

                sqlString = "("
                            "`vehicle_check_id`, "
                            "`xsz_process`, `sqb_process`, `jqx_process`, `jybg_process`, `cyjl_process`, `zqf_process`, `yhf_process`, "
                            "`cjh_process`, `aqd_process`, `zdg_process`, `ydg_process`, `yzzd_process`, `ezzd_process`, `zczd_process`, `dpdtks_process`, `dpdtjs_process`, `dpjy_process`, `wqjy_process`, "
                            "`xszbk_process`,`jyb_bk_process`,`wts_process`,`zqfcf_process`,`yhfcf_process`,`cjhcf_process`,`wszm_process`,`wttzs_process`,`jyhgzm_process`,`hdzk_process`,`dchw_process`,`sfz_process`,`sfzbk_process`,`jcqxbg_process`,"
                            "`chexiang_process`,`cjh_ug_process`,`chgw_process`,`waikuoqianmian_process`,`waikuocemian_process`,`wxnb_process`,`fzzd_process`,`abs_process`,`clcm_process`,`cjhyj_process`,`qhp_process`,`hhp_process`,`clbm_process`,`dchp_process`,"
                            "`xsz_response`, `sqb_response`, `jqx_response`, `jybg_response`, `cyjl_response`, `zqf_response`, `yhf_response`, "
                            "`cjh_response`, `aqd_response`, `zdg_response`, `ydg_response`, `yzzd_response`, `ezzd_response`, `zczd_response`, `dpdtks_response`, `dpdtjs_response`, `dpjy_response`, `wqjy_response`, "
                            "`picture_download`, `algorithm_total`, `total`, `wait_queue`, `total_no_wait`, `device_id`, `created_at`"
                            ")"
                            " VALUES ";

                sqlString += "(";
                sqlString += idString + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.xsz + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.sqb + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.jqx + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.jybg + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.cyjl + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.zqf + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.yhf + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.cjh + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.aqd + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.zdg + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.ydg + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.yzzd + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.ezzd + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.zczd + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.dpdtks + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.dpdtjs + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.dpjy + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.wqjy + ",";

                sqlString += v_vehicle_inf->timeRecord.picture.process.xszbk + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.jyb_bk + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.wts + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.zqfcf + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.yhfcf + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.cjhcf + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.wszm + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.wttzs + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.jyhgzm + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.hdzk + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.dchw + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.sfz + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.sfzbk + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.jcqxbg + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.chexiang + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.cjh_ug + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.chgw + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.waikuoqianmian + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.waikuocemian + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.wxnb + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.fzzd + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.abs + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.clcm + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.cjhyj + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.qhp + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.hhp + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.clbm + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.dchp + ",";


                sqlString += v_vehicle_inf->timeRecord.picture.response.xsz + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.sqb + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.jqx + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.jybg + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.cyjl + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.zqf + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.yhf + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.cjh + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.aqd + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.zdg + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.ydg + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.yzzd + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.ezzd + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.zczd + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.dpdtks + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.dpdtjs + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.dpjy + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.wqjy + ",";

                sqlString += v_vehicle_inf->timeRecord.picture.AllDownload + ",";

                if (algorithm_total == 0) {
                    sqlString += "NULL,";
                } else {
                    sqlString += std::to_string(algorithm_total) + ",";
                }

                sqlString += v_vehicle_inf->timeRecord.total + ",";
                sqlString += v_vehicle_inf->timeRecord.wait_queue + ",";
                sqlString += v_vehicle_inf->timeRecord.total_no_wait + ",";

                sqlString += "'" + std::to_string(g_device_ID) + "',";
                sqlString += "'" + timeString + "'";
                sqlString += ")";

                DATA_PRINT(LEVEL_DEBUG, "Insert into time_infos, data: %s \n", sqlString.c_str());
                db.insert("time_infos", sqlString.c_str());
            }
        }


        /* 准备写入表black_list */
        if(g_CheckItem.City==NINGBO)
        {
            if(v_vehicle_inf->is_black_list)
            {
              sqlString = "("
                      "`hphm`, `clsbdh`"
                      ")"
                      " VALUES ";
              sqlString += "('";
              sqlString += v_vehicle_inf->m_hphm + "','";
              sqlString += v_vehicle_inf->m_clsbdh + "')";
              DATA_PRINT(LEVEL_DEBUG, "Insert into black_list, data: %s \n", sqlString.c_str());
              db.insert("black_list", sqlString.c_str());
            }
        }

        std::string lshbuf = v_vehicle_inf->m_jylsh;
        std::string demosqlString;

#ifdef DEMO_TEST
        if (v_vehicle_inf->demo_sqlString.empty()) {
            DATA_PRINT(LEVEL_INFO, "vehicle_checks_demo_test message is not correct \n");
        } else {
            demosqlString = v_vehicle_inf->demo_sqlString0;
            demosqlString += "'";
            demosqlString += idString;
            demosqlString += "',";
            demosqlString += "'";
            demosqlString += lshbuf;
            demosqlString += "',";
            demosqlString += v_vehicle_inf->demo_sqlString;
            DATA_PRINT(LEVEL_DEBUG, "Insert into vehicle_checks_demo_test: %s \n", demosqlString.c_str());
            db.insert("vehicle_checks_demo_test", demosqlString.c_str());
        }
#endif
    }

    db.disconnect();
    DATA_PRINT(LEVEL_INFO, "The local database has been written. \n");

    /* 从机将数据写入主机的数据库*/
#ifdef NEWMODEL
    if (g_SlaveCount == -1) {
        const char* masterIp = g_master_IP.c_str();

        DATA_PRINT(LEVEL_INFO, "Write data into the remote database(%s)...... \n", masterIp);

        if (db.connect(masterIp, 6033, "root", getDBPassWord(DBPWD).c_str(), "car_schema")) {
            /* 准备写入表vehicle_checks的数据 */
            bool tableResult;
            tableResult = db.insert("vehicle_checks", checks_String.c_str());

            /* 准备写入表check_infos的数据 */
            std::string sqlString;
            std::string idString;
            if (tableResult) {
                unsigned long id = 0;
                if ((id = db.getLastID()) != 0) {
                    char tmpArray[128] = { 0 };
                    sprintf(tmpArray, "%lu", id);
                    idString = tmpArray;

                    /* 检索照片列表，并标注判定结果 */
                    for (unsigned int j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                        sqlString = "(vehicle_check_id, category, name, result, reason, created_at)"
                                    " VALUES "
                                    "(";

                        sqlString += "'" + idString + "',";
                        sqlString += "'" + v_vehicle_inf->m_zplist[j].zptype + "',";
                        sqlString += "'" + v_vehicle_inf->m_zplist[j].local_path + "',";

                        /* 查询本文件是否在不合格列表中出现 */
                        unsigned int i;
                        for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++) {
                            if (v_vehicle_inf->m_zplist[j].zptype == v_vehicle_inf->m_dbbhglist[i].zptype) {
                                sqlString += "'" + v_vehicle_inf->m_dbbhglist[i].dbresult + "',";
                                sqlString += "'" + v_vehicle_inf->m_dbbhglist[i].dbbhg_desc + "'";
                                break;
                            }
                        }

                        if (i == v_vehicle_inf->m_dbbhglist.size()) {
                            sqlString += "'1',";
                            sqlString += "'通过'";
                        }

                        sqlString += ",";
                        sqlString += "'" + timeString + "'";
                        sqlSitring += ")";

                        DATA_PRINT(LEVEL_DEBUG, "Insert into check_infos, data: %s \n", sqlString.c_str());
                        db.insert("check_infos", sqlString.c_str());
                    }

                    if (g_CheckItem.picture.CheJiaHao.BaoDing_FTP) {
                        sqlString = "(vehicle_check_id, category, name, result, reason, created_at) VALUES (";
                        sqlString += "'" + idString + "',";
                        sqlString += "'J_FTP',";
                        sqlString += "'" + v_vehicle_inf->BaoDing_J_FTP + "',";
                        sqlString += "'1',";	/*0--未处理， 1--通过，其他--不通过 */
                        sqlString += "'保定车架号档案照片'";
                        sqlString += ",";
                        sqlString += "'" + timeString + "'";
                        sqlString += ")";

                        DATA_PRINT(LEVEL_DEBUG, "Insert into check_infos, data: %s \n", sqlString.c_str());
                        db.insert("check_infos", sqlString.c_str());
                    }

                    /* 检索视频列表，并标注判定结果 */
                    for (unsigned int j = 0; j < v_vehicle_inf->m_splist.size(); j++) {
                        sqlString = "(vehicle_check_id, category, name, result, reason, created_at)"
                                    " VALUES "
                                    "(";

                        sqlString += "'" + idString + "',";
                        sqlString += "'" + v_vehicle_inf->m_splist[j].sptype + "',";
                        sqlString += "'" + v_vehicle_inf->m_splist[j].local_path + "',";

                        /* 查询本文件是否在不合格列表中出现 */
                        unsigned int i;
                        for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++) {
                            if (v_vehicle_inf->m_splist[j].sptype == v_vehicle_inf->m_dbbhglist[i].zptype) {
                                sqlString += "'" + v_vehicle_inf->m_dbbhglist[i].dbresult + "',";
                                sqlString += "'" + v_vehicle_inf->m_dbbhglist[i].dbbhg_desc + "'";
                                break;
                            }
                        }

                        if (i == v_vehicle_inf->m_dbbhglist.size()) {
                            sqlString += "'1',";
                            sqlString += "'通过'";
                        }

                        sqlString += ",";
                        sqlString += "'" + timeString + "'";
                        sqlString += ")";

                        DATA_PRINT(LEVEL_DEBUG, "Insert into check_infos, data: %s \n", sqlString.c_str());
                        db.insert("check_infos", sqlString.c_str());
                    }
                }
            }

            /* 准备写入表time_infos的数据 */
            if (tableResult) {
                if (idString != "0") {
                    sqlString = "("
                                "`vehicle_check_id`, "
                                "`xsz_process`, `sqb_process`, `jqx_process`, `jybg_process`, `cyjl_process`, `zqf_process`, `yhf_process`, "
                                "`cjh_process`, `aqd_process`, `zdg_process`, `ydg_process`, `yzzd_process`, `ezzd_process`, `zczd_process`, `dpdtks_process`, `dpdtjs_process`, `dpjy_process`, `wqjy_process`, "
                                "`xszbk_process`,`jyb_bk_process`,`wts_process`,`zqfcf_process`,`yhfcf_process`,`cjhcf_process`,`wszm_process`,`wttzs_process`,`jyhgzm_process`,`hdzk_process`,`dchw_process`,`sfz_process`,`sfzbk_process`,`jcqxbg_process`,"
                                "`chexiang_process`,`cjh_ug_process`,`chgw_process`,`waikuoqianmian_process`,`waikuocemian_process`,`wxnb_process`,`fzzd_process`,`abs_process`,`clcm_process`,`cjhyj_process`,`qhp_process`,`hhp_process`,`clbm_process`,`dchp_process`,"
                                "`xsz_response`, `sqb_response`, `jqx_response`, `jybg_response`, `cyjl_response`, `zqf_response`, `yhf_response`, "
                                "`cjh_response`, `aqd_response`, `zdg_response`, `ydg_response`, `yzzd_response`, `ezzd_response`, `zczd_response`, `dpdtks_response`, `dpdtjs_response`, `dpjy_response`, `wqjy_response`, "
                                "`picture_download`, `algorithm_total`, `total`, `wait_queue`, `total_no_wait`, `device_id`, `created_at`"
                                ")"
                                " VALUES ";

                    sqlString += "(";
                    sqlString += idString + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.xsz + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.sqb + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.jqx + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.jybg + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.cyjl + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.zqf + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.yhf + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.cjh + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.aqd + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.zdg + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.ydg + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.yzzd + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.ezzd + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.zczd + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.dpdtks + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.dpdtjs + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.dpjy + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.wqjy + ",";

                    sqlString += v_vehicle_inf->timeRecord.picture.process.xszbk + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.jyb_bk + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.wts + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.zqfcf + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.yhfcf + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.cjhcf + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.wszm + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.wttzs + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.jyhgzm + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.hdzk + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.dchw + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.sfz + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.sfzbk + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.jcqxbg + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.chexiang + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.cjh_ug + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.chgw + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.waikuoqianmian + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.waikuocemian + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.wxnb + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.fzzd + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.abs + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.clcm + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.cjhyj + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.qhp + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.hhp + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.clbm + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.process.dchp + ",";

                    sqlString += v_vehicle_inf->timeRecord.picture.response.xsz + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.response.sqb + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.response.jqx + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.response.jybg + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.response.cyjl + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.response.zqf + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.response.yhf + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.response.cjh + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.response.aqd + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.response.zdg + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.response.ydg + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.response.yzzd + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.response.ezzd + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.response.zczd + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.response.dpdtks + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.response.dpdtjs + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.response.dpjy + ",";
                    sqlString += v_vehicle_inf->timeRecord.picture.response.wqjy + ",";

                    sqlString += v_vehicle_inf->timeRecord.picture.AllDownload + ",";

                    if (algorithm_total == 0) {
                        sqlString += "NULL,";
                    } else {
                        sqlString += std::to_string(algorithm_total) + ",";
                    }

                    sqlString += v_vehicle_inf->timeRecord.total + ",";
                    sqlString += v_vehicle_inf->timeRecord.wait_queue + ",";
                    sqlString += v_vehicle_inf->timeRecord.total_no_wait + ",";

                    /* 插入本机ID */
                    sqlString += "'" + std::to_string(g_device_ID) + "',";
                    sqlString += "'" + timeString + "'";
                    sqlString += ")";

                    DATA_PRINT(LEVEL_DEBUG, "Insert into time_infos, data: %s \n", sqlString.c_str());
                    db.insert("time_infos", sqlString.c_str());
                }
            }


            /* 准备写入表black_list */
            if(g_CheckItem.City==NINGBO)
            {
                if(v_vehicle_inf->is_black_list)
                {
                  sqlString = "("
                          "`hphm`, `clsbdh`"
                          ")"
                          " VALUES ";
                  sqlString += "(";
                  sqlString += v_vehicle_inf->m_hphm + ",";
                  sqlString += v_vehicle_inf->m_clsbdh + ")";
                  DATA_PRINT(LEVEL_DEBUG, "Insert into black_list, data: %s \n", sqlString.c_str());
                  db.insert("black_list", sqlString.c_str());
                }
            }
        }

        db.disconnect();

        DATA_PRINT(LEVEL_INFO, "The remote database has been written. \n");
    }
    #endif
}

void videoOperateDatabase(const vehicle_inf *v_vehicle_inf)
{
    MySQL_DB db;
    DATA_PRINT(LEVEL_INFO, "Write data into the local database...... \n");
    const char* masterIp;
    if (g_SlaveCount == -1) {
        masterIp = g_master_IP.c_str();
    }
    else
    {
        masterIp = NULL;
    }
    if (db.connect(masterIp, 6033, "root", getDBPassWord(DBPWD).c_str(), "car_schema")) {
        std::string sqlString;
        for (unsigned int j = 0; j < v_vehicle_inf->m_splist.size(); j++) {
            sqlString = "SET ";
            sqlString += "vehicle_check_id = ";
            sqlString += "'" + v_vehicle_inf->vehicle_check_video_id + "',";
            sqlString += "localpath = ";
            sqlString += "'" + v_vehicle_inf->m_splist[j].local_path + "',";

            /* 查询本文件是否在不合格列表中出现 */
            unsigned int i;
            for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++) {
                if (v_vehicle_inf->m_splist[j].sptype == v_vehicle_inf->m_dbbhglist[i].zptype) {
                    sqlString += "result = ";
                    sqlString += "'" + v_vehicle_inf->m_dbbhglist[i].dbresult + "',";
                    sqlString += "reason = ";
                    sqlString += "'" + v_vehicle_inf->m_dbbhglist[i].dbbhg_desc + "'";
                    break;
                }
            }

            if (i == v_vehicle_inf->m_dbbhglist.size()) {
                sqlString += "result = ";
                sqlString += "'1',";
                sqlString += "reason = ";
                sqlString += "'通过'";
            }
            sqlString += " where id = '";
            sqlString += v_vehicle_inf->m_splist[j].id;
            sqlString += "'";
            DATA_PRINT(LEVEL_DEBUG, "update check_video_infos, data: %s \n", sqlString.c_str());
            db.update("check_video_infos", sqlString.c_str());
        }
        if(v_vehicle_inf->vehicle_check_video_id == "0")
        {
            string hphm = v_vehicle_inf->m_hphm;
            DATA_PRINT(LEVEL_ERROR, "没找到主表中相应车辆:%s \n",hphm.c_str());
        }
        else
        {
            string hphm = v_vehicle_inf->m_hphm;
            sqlString = "SET is_video_check = '1' where id = '";
            sqlString += v_vehicle_inf->vehicle_check_video_id;
            sqlString += "'";
            DATA_PRINT(LEVEL_DEBUG, "Insert into vehicle_checks, data: %s \n", sqlString.c_str());
            db.update("vehicle_checks", sqlString.c_str());
            DATA_PRINT(LEVEL_INFO, "vehicle_checks 插入车辆视频审核结果 :%s \n",hphm.c_str());
        }

        db.disconnect();
    }
    else
    {
       DATA_PRINT(LEVEL_INFO, "Write data into the local database...... \n");
    }
}
/* 车检处理结果写入数据库(用于组播结果，目前不使用) */
void insertCheckResult(const vehicle_inf *v_vehicle_inf, const unsigned int device_id)
{
    MySQL_DB db;

    DATA_PRINT(LEVEL_INFO, "Write data into the database...... \n");

    if (db.connect(NULL, 6033, "root", getDBPassWord(DBPWD).c_str(), "car_schema")) {
        std::string idString;
        std::string sqlString;

        /* 注意字段排列顺序必须和vehicle_inf里面的item_description成员顺序一致 */
        sqlString = "("
                    "jylsh, jyjgbh, jylb, hpzl, hphm, clsbdh, syr, sjhm, sxrq, zzrq, "
                    "cllx, syxz, zbzl, kssj, jssj, fdjh, clpp, clxh, ccdjrq, ccrq, "
                    "wgjcjyy, xszbh, fzrq, rlzl, zpzs, ckbdzplist, zplist, spzs, splist, bdbhgs, "
                    "bdbhglist, csys, pl, gl, zxxs, cwkc, cwkk, cwkg, hxnbcd, hxnbkd, "
                    "hxnbgd, gbthps, zs, zj, qlj, hlj, ltgg, lts, zzl, hdzzl, "
                    "hdzk, zqyzl, qpzk, hpzk, clyt, ytsx, sfxny, xnyzl, is_pass, device_id, created_at"
                    ")"
                    " VALUES "
                    "(";

        /* 插入车辆数据 */
        for (unsigned int i = 0; i < v_vehicle_inf->item_description.size(); i++) {
            if (strcmp(v_vehicle_inf->item_description[i].name_tag, "ckdbzplist") == 0) {
                CMarkup xml;
                xml.SetDoc("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n");
                xml.AddElem("root");
                xml.IntoElem();
                setlocale(LC_ALL, "chs");

                for (unsigned int j = 0; j < v_vehicle_inf->m_ckdbzplist.size(); j++) {
                    xml.AddElem("item");
                    xml.AddChildElem("zpzl");
                    xml.SetChildData(v_vehicle_inf->m_ckdbzplist[j].zptype);
                    xml.AddChildElem("zpurl");
                    xml.SetChildData(v_vehicle_inf->m_ckdbzplist[j].zpurl);
                }

                std::string xmlstring;
                xmlstring = xml.GetDoc();
                sqlString += "'" + xmlstring + "',";
            } else if (strcmp(v_vehicle_inf->item_description[i].name_tag, "zplist") == 0) {
                CMarkup xml;
                xml.SetDoc("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n");
                xml.AddElem("root");
                xml.IntoElem();
                setlocale(LC_ALL, "chs");

                for (unsigned int j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                    xml.AddElem("item");
                    xml.AddChildElem("zpzl");
                    xml.SetChildData(v_vehicle_inf->m_zplist[j].zptype);
                    xml.AddChildElem("zpurl");
                    xml.SetChildData(v_vehicle_inf->m_zplist[j].zpurl);
                }

                std::string xmlstring;
                xmlstring = xml.GetDoc();
                sqlString += "'" + xmlstring + "',";
            } else if (strcmp(v_vehicle_inf->item_description[i].name_tag, "splist") == 0) {
                CMarkup xml;
                xml.SetDoc("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n");
                xml.AddElem("root");
                xml.IntoElem();
                setlocale(LC_ALL, "chs");

                for (unsigned int j = 0; j < v_vehicle_inf->m_splist.size(); j++) {
                    xml.AddElem("item");
                    xml.AddChildElem("spzl");
                    xml.SetChildData(v_vehicle_inf->m_splist[j].sptype);
                    xml.AddChildElem("dzzl");
                    xml.SetChildData(v_vehicle_inf->m_splist[j].dzzl);

                    if (v_vehicle_inf->m_splist[j].dzzl == "nvr") {
                        xml.AddChildSubDoc(v_vehicle_inf->m_splist[j].spurl);
                    } else {
                        xml.AddChildElem("spurl");
                        xml.SetChildData(v_vehicle_inf->m_splist[j].spurl);
                    }
                }

                std::string xmlstring;
                xmlstring = xml.GetDoc();
                sqlString += "'" + xmlstring + "',";
            } else if (strcmp(v_vehicle_inf->item_description[i].name_tag, "dbbhglist") == 0) {
                CMarkup xml;
                xml.SetDoc("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n");
                xml.AddElem("root");
                xml.IntoElem();
                setlocale(LC_ALL, "chs");

                for (unsigned int j = 0; j < v_vehicle_inf->m_dbbhglist.size(); j++) {
                    xml.AddElem("item");
                    xml.AddChildElem("zpzl");
                    xml.SetChildData(v_vehicle_inf->m_dbbhglist[j].zptype);
                    xml.AddChildElem("sm");
                    xml.SetChildData(v_vehicle_inf->m_dbbhglist[j].dbbhg_desc);
                    xml.AddChildElem("jg");
                    xml.SetChildData(v_vehicle_inf->m_dbbhglist[j].dbresult);
                    xml.AddChildElem("zpid");
                    xml.SetChildData(v_vehicle_inf->m_dbbhglist[j].zpid);
                }

                std::string xmlstring;
                xmlstring = xml.GetDoc();
                sqlString += "'" + xmlstring + "',";

            } else {	/* 非XML格式的普通数据 */
                std::string tmp = *(std::string *)(v_vehicle_inf->item_description[i].value);
                sqlString += "'" + tmp + "',";
            }
        }

        /* 判定is_pass */
        std::string is_pass = "1";
        if (v_vehicle_inf->AlgorithmCheck) {
            int count_list=v_vehicle_inf->m_zplist.size()-v_vehicle_inf->m_dbbhglist.size();

            if(count_list>=13)//临时处理：如果照片不全则不判定整车通过
            {
                for (unsigned int i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++) {
                    /* 如果照片类型的第一个字母是数字，表示普通照片（非档案照片） */
                    if ((v_vehicle_inf->m_dbbhglist[i].zptype[0] >= '0') && (v_vehicle_inf->m_dbbhglist[i].zptype[0] <= '9')) {

                        /* 苏州"非营运"的车不判定“侧滑工位照片” */
                        if ((v_vehicle_inf->m_dbbhglist[i].zptype == "0353") && (v_vehicle_inf->m_syxz == "A")) {
                            continue;
                        }

                        is_pass = "0";
                        break;
                    }
                }
            }else
            {
              is_pass = "0";
            }
        } else {
            is_pass = "-1";
        }

        sqlString += "'" + is_pass + "',";
        sqlString += "'" + std::to_string(device_id) + "',";

        /* 插入当前时间，并将条目加入表vehicle_checks */
        std::time_t t = std::time(NULL);
        std::tm *st = std::localtime(&t);
        char tmpArray[128] = { 0 };
        sprintf(tmpArray, "%d-%02d-%02d %02d:%02d:%02d",
                st->tm_year + 1900, st->tm_mon + 1, st->tm_mday,
                st->tm_hour, st->tm_min, st->tm_sec);
        std::string timeString = tmpArray;
        sqlString += "'" + timeString + "'";
        sqlString += ")";

        DATA_PRINT(LEVEL_DEBUG, "Insert into vehicle_checks, data: %s \n", sqlString.c_str());

        bool tableResult = false;
        tableResult = db.insert("vehicle_checks", sqlString.c_str());

        /* 准备表check_infos的数据(由于它的外键关联了vehicle_checks的主键，因此必须判断上一个语句成功) */
        if (tableResult) {
            unsigned long id = 0;
            if ((id = db.getLastID()) != 0) {
                char tmpArray[128] = { 0 };
                sprintf(tmpArray, "%lu", id);
                idString = tmpArray;

                /* 检索照片列表，并标注判定结果 */
                for (unsigned int j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {
                    sqlString = "(vehicle_check_id, category, name, result, reason, created_at) VALUES (";

                    sqlString += "'" + idString + "',";
                    sqlString += "'" + v_vehicle_inf->m_zplist[j].zptype + "',";
                    sqlString += "'" + v_vehicle_inf->m_zplist[j].local_path + "',";

                    /* 查询本文件是否在不合格列表中出现 */
                    unsigned int i;
                    for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++) {
                        if (v_vehicle_inf->m_zplist[j].zptype == v_vehicle_inf->m_dbbhglist[i].zptype) {
                            sqlString += "'" + v_vehicle_inf->m_dbbhglist[i].dbresult + "',";
                            sqlString += "'" + v_vehicle_inf->m_dbbhglist[i].dbbhg_desc + "'";
                            break;
                        }
                    }

                    if (i == v_vehicle_inf->m_dbbhglist.size()) {
                        sqlString += "'1',";	/*0--未处理， 1--通过，其他--不通过 */
                        sqlString += "'通过'";
                    }

                    sqlString += ",";
                    sqlString += "'" + timeString + "'";
                    sqlString += ")";

                    DATA_PRINT(LEVEL_DEBUG, "Insert into check_infos, data: %s \n", sqlString.c_str());
                    db.insert("check_infos", sqlString.c_str());
                }

                /* 检索视频列表，并标注判定结果 */
                for (unsigned int j = 0; j < v_vehicle_inf->m_splist.size(); j++) {
                    sqlString = "(vehicle_check_id, category, name, result, reason, created_at) VALUES (";

                    sqlString += "'" + idString + "',";
                    sqlString += "'" + v_vehicle_inf->m_splist[j].spzl + "',";
                    sqlString += "'" + v_vehicle_inf->m_splist[j].local_path + "',";

                    /* 查询本文件是否在不合格列表中出现 */
                    unsigned int i;
                    for (i = 0; i < v_vehicle_inf->m_dbbhglist.size(); i++) {
                        if (v_vehicle_inf->m_splist[j].sptype == v_vehicle_inf->m_dbbhglist[i].zptype) {
                            sqlString += "'" + v_vehicle_inf->m_dbbhglist[i].dbresult + "',";
                            sqlString += "'" + v_vehicle_inf->m_dbbhglist[i].dbbhg_desc + "'";
                            break;
                        }
                    }

                    if (i == v_vehicle_inf->m_dbbhglist.size()) {
                        sqlString += "'1',";	/*0--未处理， 1--通过，其他--不通过 */
                        sqlString += "'通过'";
                    }

                    sqlString += ",";
                    sqlString += "'" + timeString + "'";
                    sqlString += ")";

                    DATA_PRINT(LEVEL_DEBUG, "Insert into check_infos, data: %s \n", sqlString.c_str());
                    db.insert("check_infos", sqlString.c_str());
                }
            }
        }

        /* 准备写入表time_infos */
        if (tableResult) {
            if (idString != "0") {

                /* 计算出算法处理的总时间 */
                unsigned int algorithm_total = 0;

                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.xsz == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.xsz));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.sqb == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.sqb));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.jqx == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.jqx));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.jybg == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.jybg));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.cyjl == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.cyjl));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.zqf == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.zqf));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.yhf == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.yhf));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.cjh == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.cjh));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.aqd == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.aqd));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.zdg == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.zdg));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.ydg == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.ydg));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.yzzd == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.yzzd));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.ezzd == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.ezzd));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.zczd == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.zczd));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.dpdtks == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.dpdtks));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.dpdtjs == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.dpdtjs));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.dpjy == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.dpjy));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.wqjy == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.wqjy));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.mhq == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.mhq));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.yjc == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.yjc));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.jly == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.jly));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.zql == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.zql));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.yql == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.yql));

                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.xszbk == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.xszbk));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.jyb_bk == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.jyb_bk));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.wts == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.wts));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.zqfcf == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.zqfcf));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.yhfcf == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.yhfcf));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.cjhcf == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.cjhcf));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.wszm == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.wszm));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.wttzs == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.wttzs));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.jyhgzm == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.jyhgzm));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.hdzk == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.hdzk));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.dchw == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.dchw));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.sfz == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.sfz));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.sfzbk == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.sfzbk));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.jcqxbg == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.jcqxbg));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.chexiang == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.chexiang));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.cjh_ug == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.cjh_ug));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.chgw == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.chgw));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.waikuoqianmian == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.waikuoqianmian));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.waikuocemian == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.waikuocemian));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.wxnb == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.wxnb));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.fzzd == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.fzzd));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.abs == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.abs));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.clcm == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.clcm));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.cjhyj == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.cjhyj));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.qhp == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.qhp));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.hhp == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.hhp));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.clbm == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.clbm));
                algorithm_total += (v_vehicle_inf->timeRecord.picture.process.dchp == "NULL") ? (0) : (std::stoi(v_vehicle_inf->timeRecord.picture.process.dchp));

                sqlString = "("
                            "`vehicle_check_id`, "
                            "`xsz_process`, `sqb_process`, `jqx_process`, `jybg_process`, `cyjl_process`, `zqf_process`, `yhf_process`, "
                            "`cjh_process`, `aqd_process`, `zdg_process`, `ydg_process`, `yzzd_process`, `ezzd_process`, `zczd_process`, `dpdtks_process`, `dpdtjs_process`, `dpjy_process`, `wqjy_process`, "
                            "`mhq_process`, `yjc_process`, `jly_process`, `zql_process`, `yql_process`, "
                            "`xsz_response`, `sqb_response`, `jqx_response`, `jybg_response`, `cyjl_response`, `zqf_response`, `yhf_response`, "
                            "`cjh_response`, `aqd_response`, `zdg_response`, `ydg_response`, `yzzd_response`, `ezzd_response`, `zczd_response`, `dpdtks_response`, `dpdtjs_response`, `dpjy_response`, `wqjy_response`, "
                            "`mhq_response`, `yjc_response`, `jly_response`, `zql_response`, `yql_response`, "
                            "`picture_download`, `algorithm_total`, `total`, `wait_queue`, `total_no_wait`, `device_id`, `created_at`"
                            ")"
                            " VALUES ";

                sqlString += "(";
                sqlString += idString + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.xsz + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.sqb + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.jqx + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.jybg + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.cyjl + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.zqf + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.yhf + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.cjh + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.aqd + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.zdg + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.ydg + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.yzzd + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.ezzd + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.zczd + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.dpdtks + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.dpdtjs + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.dpjy + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.wqjy + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.mhq + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.yjc + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.jly + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.zql + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.yql + ",";

                sqlString += v_vehicle_inf->timeRecord.picture.process.xszbk + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.jyb_bk + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.wts + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.zqfcf + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.yhfcf + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.cjhcf + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.wszm + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.wttzs + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.jyhgzm + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.hdzk + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.dchw + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.sfz + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.sfzbk + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.jcqxbg + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.chexiang + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.cjh_ug + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.chgw + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.waikuoqianmian + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.waikuocemian + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.wxnb + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.fzzd + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.abs + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.clcm + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.cjhyj + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.qhp + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.hhp + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.clbm + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.process.dchp + ",";

                sqlString += v_vehicle_inf->timeRecord.picture.response.xsz + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.sqb + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.jqx + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.jybg + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.cyjl + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.zqf + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.yhf + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.cjh + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.aqd + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.zdg + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.ydg + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.yzzd + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.ezzd + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.zczd + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.dpdtks + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.dpdtjs + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.dpjy + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.wqjy + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.mhq + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.yjc + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.jly + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.zql + ",";
                sqlString += v_vehicle_inf->timeRecord.picture.response.yql + ",";

                sqlString += v_vehicle_inf->timeRecord.picture.AllDownload + ",";

                if (algorithm_total == 0) {
                    sqlString += "NULL,";
                } else {
                    sqlString += std::to_string(algorithm_total) + ",";
                }

                sqlString += v_vehicle_inf->timeRecord.total + ",";
                sqlString += v_vehicle_inf->timeRecord.wait_queue + ",";
                sqlString += v_vehicle_inf->timeRecord.total_no_wait + ",";

                sqlString += "'" + std::to_string(g_device_ID) + "',";
                sqlString += "'" + timeString + "'";
                sqlString += ")";

                DATA_PRINT(LEVEL_DEBUG, "Insert into time_infos, data: %s \n", sqlString.c_str());
                db.insert("time_infos", sqlString.c_str());
            }
        }
    }

    db.disconnect();
    DATA_PRINT(LEVEL_INFO, "The database has been written. \n");
}

#endif

/* 查询当前系统时间，判定是否处于配置文件中规定的工作时间 */
bool isWorkTime()
{
    std::time_t t = std::time(NULL);
    std::tm *st = std::localtime(&t);

    if ((st->tm_hour >= g_CheckItem.ShiJian.KaiShi) && (st->tm_hour < g_CheckItem.ShiJian.JieShu)) {
        return true;
    } else {
        return false;
    }
}

/**
@name:	 compare_JYJG
@brief:  比较两个检验机构的优先级数字大小
@param:  jyjgbh_1--检验机构编号
         jyjgbh_2--检验机构编号
@return: 1--jyjgbh_1比jyjgbh_2大
         0--一样大
         -1--jyjgbh_1比jyjgbh_2小
@others: 比较的是优先级的数字，不是优先级！
@see:
*/
//int compare_JYJG(std::string jyjgbh_1, std::string jyjgbh_2)
//{
//    if (g_CheckItem.JianYanJiGou.size() == 0) {
//        return 0;/* 如果检验机构列表为空，表示所有检验机构优先级都一样 */
//    }

//    unsigned int priority_1, priority_2;

//    unsigned int i;
//    for (i = 0; i < g_CheckItem.JianYanJiGou.size(); i++) {
//        if (jyjgbh_1 == g_CheckItem.JianYanJiGou[i].bh) {
//            priority_1 = g_CheckItem.JianYanJiGou[i].priority;
//            break;
//        }
//    }
//    if (i == g_CheckItem.JianYanJiGou.size()) {
//        priority_1 = 9;	/* 如果没有找到该检验机构，则使用默认最低的优先级9 */
//    }

//    for (i = 0; i < g_CheckItem.JianYanJiGou.size(); i++) {
//        if (jyjgbh_2 == g_CheckItem.JianYanJiGou[i].bh) {
//            priority_2 = g_CheckItem.JianYanJiGou[i].priority;
//            break;
//        }
//    }
//    if (i == g_CheckItem.JianYanJiGou.size()) {
//        priority_2 = 9;	/* 如果没有找到该检验机构，则使用默认最低的优先级9 */
//    }

//    if (priority_1 > priority_2) {
//        return 1;
//    } else if (priority_1 < priority_2) {
//        return -1;
//    } else {
//        return 0;
//    }
//}

void DataRequestThread()
{
    DATA_PRINT(LEVEL_INFO, "DataRequestThread running...... \n");
    std::map<std::string, time_t> map_record_info;

    vehicle_inf *v_vehicle_inf = NULL;
    //TmriOutAccessSoapBindingProxy soapclient;
    char *queryReturn = NULL;
    vector<std::string> recurrent_lsh;
    std::vector<std::string> current_lsh;
    int flaglsh = 0, flaglsh2 = 0;

    while (g_SlaveCount != -1)
    {
        /* 控制查询间隔 */
        std::this_thread::sleep_for(std::chrono::seconds(g_QueryInterval));
        if (!isWorkTime()) {
            if ((g_CheckItem.dlvideo.soapflag)&&(toanalyse_queue.Size()<6))
            {
                //添加视频审核
                DATA_PRINT(LEVEL_INFO, "Not at work time, video checking .... \n");
                videoCheckSerch();
                continue;
            }

            DATA_PRINT(LEVEL_INFO, "Not at work time, no SOAP client query. \n");
            continue;
        }

        TmriOutAccessSoapBindingProxy soapclient;
        soapclient.accept_timeout = 30;
        soapclient.connect_timeout = 30;
        soapclient.recv_timeout = 30;
        soapclient.send_timeout = 30;
        std::string queryString;
        if(g_timelimit>0)
        {
            std::time_t t = std::time(NULL);
            t += 86400;
            std::tm *st = std::localtime(&t);
            char tmpArray[128] = { 0 };
            sprintf(tmpArray, "%d-%02d-%02d", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);
            t -= (g_timelimit*86400);
            st = std::localtime(&t);
            char tmpArray2[128] = { 0 };
            sprintf(tmpArray2, "%d-%02d-%02d", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);
            queryString = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><QueryCondition><lsh></lsh>";
            queryString += "<qsrq>";
            queryString += tmpArray2;
            queryString += "</qsrq><zzrq>";
            queryString += tmpArray;
            queryString += "</zzrq><fhzdjls>";
            queryString += g_QueryNumber;
            queryString += "</fhzdjls><cxzt>1</cxzt></QueryCondition></root>";
        }
        else
        {
            queryString = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><QueryCondition><lsh></lsh><fhzdjls>";
            queryString += g_QueryNumber;
            queryString += "</fhzdjls><cxzt>1</cxzt></QueryCondition></root>";
        }
        DATA_PRINT(LEVEL_INFO, "The SOAP client is querying...... \n");
        soapclient.queryObjectOut("18", (char *)g_confJkxlh.c_str(), "18C22", (char *)queryString.c_str(), queryReturn);
//        char* writeReturn=NULL;
//        string writeString;
//        writeString="";
//        soapclient.writeObjectOut("18", (char *)g_confJkxlh.c_str(), "18C22", (char *)writeString.c_str(), writeReturn);
        /*
        <?xml version="1.0" encoding="GBK"?> <root> <head>
        <code>1</code> <message>数据下载成功！</message>
        <rownum>1</rownum> </head> <body> <vehicle id="0"> <jssj></jssj> <wgjcjyy></wgjcjyy>
        <lsh>17052736000300280336</lsh> <sxrq></sxrq> <ccdjrq></ccdjrq> <syxz></syxz> <clpp1></clpp1> <syr></syr>
        <hphm></hphm> <zpzs></zpzs> <jylsh></jylsh> <jyjgbh></jyjgbh> <cllx></cllx> <spzs></spzs> <clxh></clxh>
        <zbzl></zbzl> <hpzl></hpzl> <clsbdh></clsbdh> <fdjh></fdjh> <zzrq></zzrq> <kssj></kssj> <ccrq></ccrq>
        </vehicle> </body></root>
        */
        //DATA_PRINT(LEVEL_INFO, "<-----SoapServer(%s)\n", queryReturn == NULL ? "NULL" : "LSH");
        //DATA_PRINT(LEVEL_DATA, "Received a SoapServer response for ");
        if (queryReturn == NULL) {
            DATA_PRINT(LEVEL_INFO, "SOAP server no response! \n");
            if (g_CheckItem.City == NANYANG) {
                g_n_remote_ip_index++;
                if (g_vec_remote_server_ip.size() <= g_n_remote_ip_index) {
                    g_n_remote_ip_index = 0;
                }
                if (!g_vec_remote_server_ip.empty()) {
                    DATA_PRINT(LEVEL_INFO, "g_n_remote_ip_index = %d , g_vec_remote_server_ip.size() = %d \n", g_n_remote_ip_index, g_vec_remote_server_ip.size());
                    try {
                        g_remoteServerIp = g_vec_remote_server_ip.at(g_n_remote_ip_index);
                        g_remoteServerIp_Char = (char *)g_remoteServerIp.c_str();
                        DATA_PRINT(LEVEL_INFO, "remoteServerIp:[%s]\t remoteServerIp_Char[%s]\n", g_remoteServerIp.c_str(), g_remoteServerIp_Char);
                    } catch (const std::exception &e) {
                        DATA_PRINT(LEVEL_ERROR, "g_vec_remote_server_ip.at(g_n_remote_ip_index): %s \n", e.what());
                    }
                }
            }
        }
        else
        {
            DATA_PRINT(LEVEL_INFO, "response data: %s\n", URLDecode(queryReturn).c_str());

            vector<std::string> received_lsh;

            if (Analyse_QueryReturn_Data((char *)URLDecode(queryReturn).c_str(), &received_lsh, 1) <= 0)
                continue;

            //检查重复删除流水号 7.11修改 （流水号未收到回复刷新）
            int count_conlsh = confirm_lsh.size();
            int count_lsh;
            int pos2 = 0;
            while (count_conlsh > 0)
            {
                count_lsh = current_lsh.size();
                bool same = FALSE;
                int s;
                for ( s= 0; s < count_lsh; s++)
                {
                    if (current_lsh[s] == confirm_lsh[pos2])
                    {
                        same = TRUE;
                        break;
                    }
                }
                if (same)
                {
                    current_lsh.erase(current_lsh.begin() + s);
                    confirm_lsh.erase(confirm_lsh.begin() + pos2);
                }
                else
                    pos2++;

                count_conlsh--;
            }
            /*******流水号重复测试后去重复*******/
            if (!recurrent_lsh.empty())
            {
                unsigned int count = recurrent_lsh.size() / 2;
                for (unsigned int i = 0; i < count; i++)
                {
                    if (recurrent_lsh[i] == current_lsh[i])
                    {

                    }
                    else
                    {
                        flaglsh = 0;
                        break;
                    }
                    if (i == (count - 1))
                    {
                        flaglsh++;
                    }
                }
                if (flaglsh > 40)
                {
                    flaglsh = 0;
                    flaglsh2 = 0;
                    for (int s = 0; s < count; s++)
                    {
                        current_lsh.erase(current_lsh.begin() + s);
                    }
                }
                if (recurrent_lsh[0] == current_lsh[0])
                {
                    flaglsh2++;
                    if (flaglsh2 > 50)
                    {
                        flaglsh2 = 0;
                        current_lsh.erase(current_lsh.begin());
                    }
                }
                else
                {
                    flaglsh2 = 0;
                }
            }
            /**************/

            recurrent_lsh = current_lsh;
            //update current_lsh
            count_lsh = current_lsh.size();
            int pos = 0;

            while (count_lsh > 0)
            {
                BOOL found_lsh = FALSE;
                for (unsigned int s = 0; s < received_lsh.size(); s++)
                {
                    if (current_lsh[pos] == received_lsh[s])
                    {
                        found_lsh = TRUE;
                        break;
                    }
                }
                if (!found_lsh)
                    current_lsh.erase(current_lsh.begin() + pos);
                else
                    pos++;

                count_lsh--;
            }

            std::vector<vehicle_inf *> vehicle_queue;

            for (unsigned int n = 0; n < received_lsh.size(); n++)
            {
                //获取流水号
                BOOL new_lsh = TRUE;

                for (unsigned int s = 0; s < current_lsh.size(); s++)
                {
                    if (received_lsh[n] == current_lsh[s])
                    {
                        new_lsh = FALSE;
                        break;
                    }
                }

                if (new_lsh)
                {
                    DATA_PRINT(LEVEL_INFO, "Rec new LSH:%s\n", received_lsh[n].c_str());
                    //获取数据
                    //v_vehicle_inf->vehicle_sys_uri = "http://192.168.16.176:9008/trffweb/services/TmriOutAccess.asmx/writeObjectOut"; //test
                    queryReturn = NULL;
                    std::string queryxml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><QueryCondition><lsh>";
                    queryxml += received_lsh[n];
                    queryxml += "</lsh><fhzdjls>1</fhzdjls><cxzt>2</cxzt></QueryCondition></root>";

                    DATA_PRINT(LEVEL_DEBUG, "Request vehicle info according to the LSH(%s)...... \n", received_lsh[n].c_str());
                    soapclient.queryObjectOut("18", (char *)g_confJkxlh.c_str(), "18C22", (char *)queryxml.c_str(), queryReturn);

                    //建立对象数据，插入下载队列
                    if (queryReturn != NULL)
                    {

                        //			SoapClient video_dowload;
                        //			string jgbh = v_vehicle_inf->m_jyjgbh;
                        //			for (int c; c < 9; c++)
                        //			{
                        //				if (jyjg_list[c].compare(jgbh) == 0)
                        //				{
                        //						if (video_dowload.isTokenValid() == false){
                        //							DATA_PRINT(LEVEL_DATA, "<------------------- GET TOKEN START  -------------------> \n\n");
                        //							string IP = g_localServerIp;
                        //							string MAC = LocalMac;
                        //							video_dowload.getToken(IP, MAC);

                        //						}
                        //						video_dowload.get_vehicle_adr(v_vehicle_inf);
                        //						break;
                        //				}
                        //				DATA_PRINT(LEVEL_DATA, "<------------------- ÊÓÆµÐÅÏ¢²»ÔÚŽŠÀí·¶Î§ÄÚ -------------------> \n\n");
                        //			}
//                        if (g_CheckItem.dlvideo.soapflag)
//                        {
//                            SoapClient video_dowload;
//                            if (video_dowload.isTokenValid() == false){
//                                DATA_PRINT(LEVEL_DEBUG, "<------------------- GET TOKEN START  -------------------> \n\n");
//                                string IP = g_localServerIp;
//                                string MAC = LocalMac;
//                                video_dowload.getToken(IP, MAC);

//                            }
//                            video_dowload.get_vehicle_adr(v_vehicle_inf);
//                            if (0 != v_vehicle_inf->m_splist.size())
//                            {
//                                DATA_PRINT(LEVEL_DEBUG, "<------------------- Don't have video  -------------------> \n\n");
//                            }
//                            else
//                            {
//                                MySQL_DB dbv;
//                                dbv.connect(g_master_IP.c_str(), 6033, "root", getDBPassWord(DBPWD).c_str(), "car_schema");
//                                string term = "jylsh =";
//                                term += v_vehicle_inf->m_jylsh;
//                                dbv.getVideoMsg("spzl,spurl", "car_schema.video_infos", term.c_str(), v_vehicle_inf);
//                                dbv.disconnect();

//                            }
//                        }

                        DATA_PRINT(LEVEL_INFO, "<--------------------Received origin vehicle info-----------------> \n");
                        DATA_PRINT(LEVEL_INFO, "%s\n", (char *)UTF8toANSI((char *)URLDecode(queryReturn).c_str()).c_str());
                        DATA_PRINT(LEVEL_INFO, "<-----------------------------------------------------------------> \n");

                        v_vehicle_inf = new vehicle_inf;
                        int n_result = Analyse_QueryReturn_Data((char *)UTF8toANSI((char *)URLDecode(queryReturn).c_str()).c_str(), v_vehicle_inf, 2);
                        if (n_result >= 0)
                        {
                            current_lsh.push_back(received_lsh[n]);
                            //download_queue.Put(v_vehicle_inf);

                            if ((BINZHOU == g_CheckItem.City) && (!g_TestMode)) // get video download address
                            {
                                DATA_PRINT(LEVEL_INFO, "binzhou_video_check(v_vehicle_inf)\n");
                                binzhou_video_check(v_vehicle_inf);
                            }
                            if (v_vehicle_inf->m_b_ip)
                            {
                                DATA_PRINT(LEVEL_INFO, "跳过主从机分配, 主机单独处理 ...\n");
                                continue;
                            }

                            vehicle_queue.push_back(v_vehicle_inf);
                            flaglsh = 0;
                        }
                        else
                            delete v_vehicle_inf;
                    }
                } else {
                    DATA_PRINT(LEVEL_INFO, "Ignore same LSH:%s \n", received_lsh[n].c_str());
                }
            }

//            /* 按照检验机构的优先级，进行排序，优先级数字小的排在前面 */
//            for (int i = 0; i < (int)(vehicle_queue.size() - 1); i++) {
//                for (int j = 0; j < (int)(vehicle_queue.size() - 1 - i); j++) {
//                    if (compare_JYJG(vehicle_queue[j]->m_jyjgbh, vehicle_queue[j + 1]->m_jyjgbh) > 0) {
//                        vehicle_inf *tmp = vehicle_queue[j];
//                        vehicle_queue[j] = vehicle_queue[j + 1];
//                        vehicle_queue[j + 1] = tmp;
//                    }
//                }
//            }

            /* 佛山：不在“检验机构”列表里面的车辆信息直接丢弃 */
            if (g_CheckItem.City == FOSHAN) {
                for (unsigned int i = 0; i < vehicle_queue.size(); ) {
                    unsigned int j;

                    for (j = 0; j < g_CheckItem.JianYanJiGou.size(); j++) {
                        if (vehicle_queue[i]->m_jyjgbh == g_CheckItem.JianYanJiGou[j].bh) {
                            break;
                        }
                    }

                    if ((j == g_CheckItem.JianYanJiGou.size()) && (j != 0)) {
                        DATA_PRINT(LEVEL_INFO, "Discard vehicle info that is not in the jyjgbh list. (LSH: %s, JYJGBH: %s) \n",
                                   vehicle_queue[i]->m_jylsh.data(), vehicle_queue[i]->m_jyjgbh.data());

                        delete vehicle_queue[i];
                        vehicle_queue.erase(vehicle_queue.begin() + i);
                    } else {
                        i++;
                    }
                }
            }


/*//             * 南充和凉山会接收到四川省所有的车辆信息，需要过滤
//             * 只处理当前检验机构列表里面的数据
//             * 四川如果有新增加城市，只用在这里添加城市代码就好
/*            if ((g_CheckItem.City == NANCHONG) || (g_CheckItem.City == LIANGSHAN)) {
                for (unsigned int vehicle_pos = 0; vehicle_pos < vehicle_queue.size(); vehicle_pos++)
                {
                    unsigned int jigou_pos;
                    for (jigou_pos = 0; jigou_pos < g_CheckItem.JianYanJiGou.size(); jigou_pos++)
                    {
                        if (vehicle_queue[vehicle_pos]->m_jyjgbh == g_CheckItem.JianYanJiGou[jigou_pos].bh)
                            break;
                    }

//                     * 不在检测机构范围内的2中情况：
//                     * 1. 是该地区的车辆(等待10分钟该车辆信息还在就放入分配队列)
//                     * 2. 不是该地区的车辆(其他城市自己会拿走，不处理)
                    if ((jigou_pos == g_CheckItem.JianYanJiGou.size()) && (jigou_pos != 0))  {
                        DATA_PRINT(LEVEL_INFO, "不在检测机构范围内. 流水号:[%s], 检验机构编号:[%s]) \n", vehicle_queue[vehicle_pos]->m_jylsh.data(),
                                   vehicle_queue[vehicle_pos]->m_jyjgbh.data());

//                         *  1.增加map中不存在的流水号
//                         *  2.存在则进入分配队列
                        auto it_find = map_record_info.find( vehicle_queue[vehicle_pos]->m_jylsh);
                        if (it_find != map_record_info.end()) { // 再次收到相同流水号的车辆，且间隔时间够10分钟，放入分配队列
//                            if (time((time_t*)NULL) - (it_find->second) >= 600) {
                                toDistribute_queue.Put(vehicle_queue[vehicle_pos]);
                                vehicle_queue.erase(vehicle_queue.begin()+vehicle_pos);
                                map_record_info.erase(it_find);
                                DATA_PRINT(LEVEL_INFO, "to distribute vehicle_queue info.\n");
//                            } else {
//                                delete vehicle_queue[vehicle_pos];
//                                vehicle_queue.erase(vehicle_queue.begin()+vehicle_pos);
//                            }
                        } else {
                            map_record_info.insert(pair<std::string, time_t>(vehicle_queue[vehicle_pos]->m_jylsh, time((time_t*)NULL)));
                            delete vehicle_queue[vehicle_pos];
                            vehicle_queue.erase(vehicle_queue.begin()+vehicle_pos);
                            DATA_PRINT(LEVEL_INFO, "put in map_record_info.\n");
                        }
                    }
                }
            }*/

            for (unsigned int i = 0; i < vehicle_queue.size(); i++) {
                DATA_PRINT(LEVEL_INFO, "Get one vehicle info[LSH:%s], and has been put in the toDistribute_queue. \n", vehicle_queue[i]->m_jylsh.c_str());
                toDistribute_queue.Put(vehicle_queue[i]);
            }
        }
    }
}

/*
 * Summary: 主机调用该函数分发车检请求
 * Parameters:
 *     [IN]v_vehicle_inf:车检数据
 * Return : true--已分发给从机，
 *          false--未分发给从机
 */
bool DistributeData(vehicle_inf *v_vehicle_inf)
{
    static unsigned int CurrentSlave = 0;

    if (CurrentSlave >= SlaveList.size()) {
        CurrentSlave = 0;
        return false;
    }

    /* 获得当前已经被指定检验机构的机器的IP列表 */
    std::vector<std::string> IP_list;
    for (unsigned int i = 0; i < g_CheckItem.JianYanJiGou.size(); i++) {
        if (!g_CheckItem.JianYanJiGou[i].assignment_IP.empty()) {
            IP_list.push_back(g_CheckItem.JianYanJiGou[i].assignment_IP);
        }
    }

    /*
    如果某个从机IP已被指定处理某个检验机构的车辆信息，那么其他检验机构的信息就不会再发给它
    */
    unsigned int i = 0;
    while (i < IP_list.size()) {
        if (SlaveList[CurrentSlave].ip == IP_list[i]) {
            CurrentSlave++;
            if (CurrentSlave >= SlaveList.size()) {
                CurrentSlave = 0;
                return false;
            } else {
                i = 0;
                continue;
            }
        }

        i++;
    }

    std::string IP = SlaveList[CurrentSlave].ip;
    std::string port = SlaveList[CurrentSlave].port;

    HttpClient DistributeRequest;
    char url_temp[256];
    sprintf(url_temp, "http://%s:%s", IP.c_str(), port.c_str());
    std::string vehicleurl = url_temp;
    vehicleurl += g_requestUri;
    //vehicleurl += v_vehicle_inf->vehicle_sys_uri;

    std::string xmldata;
    sprintf(url_temp, "xtlb=%s&jkxlh=%s&jkid=%s&xmlDoc=", VEHICLE_XTLB, g_confJkxlh.c_str(), VEHICLE_JKID);
    xmldata = url_temp;
    xmldata += Prepare_Xml_Data(v_vehicle_inf);
    if (DistributeRequest.InitData(vehicleurl.c_str(), REQUEST_POST_FLAG, HTTP_CONTENT_TYPE_URL_ENCODED, (char *)xmldata.c_str()))
    {
        DistributeRequest.set_retries_timeout(1, 2);
        DistributeRequest.startHttpClient();
    }

    if (DistributeRequest.d_success_flag)
    {
        if (!DistributeRequest.ResponseData.empty()) {

            if (analyseSlaveReply(DistributeRequest.ResponseData)) {
                DATA_PRINT(LEVEL_INFO, "LSH(%s) has been distributed to slave: %s \n\n", v_vehicle_inf->m_jylsh.data(), IP.c_str());

                if (v_vehicle_inf) {
                    delete v_vehicle_inf;
                }

                CurrentSlave++;
                return true;
            } else {
                toDistribute_queue.RePut(v_vehicle_inf);
                DATA_PRINT(LEVEL_INFO, "Slave(%s) is too busy, LSH(%s) is put in the toDistribute_queue again. \n\n", IP.c_str(), v_vehicle_inf->m_jylsh.data());
                CurrentSlave++;
                return true;
            }
        } else {
            toDistribute_queue.RePut(v_vehicle_inf);
            DATA_PRINT(LEVEL_ERROR, "Slave(%s) response is empty, LSH(%s) is put in the toDistribute_queue again. \n\n", IP.c_str(), v_vehicle_inf->m_jylsh.data());
            CurrentSlave++;
            return true;
        }
    }
    else
    {
        if (v_vehicle_inf) {
            toDistribute_queue.RePut(v_vehicle_inf);
        }

        DATA_PRINT(LEVEL_ERROR, "Slave(%s) no response, LSH(%s) is put in the toDistribute_queue again. \n\n", IP.c_str(), v_vehicle_inf->m_jylsh.data());
        CurrentSlave++;
        return true;
    }
}

bool analyseSlaveReply(std::string data)
{
    CMarkup xml;
    xml.SetDoc(data.c_str());

    if (xml.FindElem("root")) {
        xml.IntoElem();

        if (xml.FindElem("head")) {
            if (xml.FindChildElem("code")) {
                int code = atoi(xml.GetChildData().c_str());
                if (code == 1) {
                    return true;
                }
            }
        }
    }

    return false;
}

int Analyse_QueryReturn_Data(char *xmldata, void *pvehicle_void, unsigned int flag) //flag: 0-only check code 1-get lsh 2-get data
{
    CMarkup xml;
    int rownum = 0;
    int r_value = -1;
    vehicle_inf temp_vehicle_inf;
    vehicle_inf *pvehicle_inf = NULL;
    vector<std::string> *pcurrent_lsh;
    xml.SetDoc(xmldata);
    xml.ResetMainPos();
    if (!xml.FindElem()) {
        DATA_PRINT(LEVEL_ERROR, "Analyse_QueryReturn_Data: Can not find XML element! \n");
        DATA_PRINT(LEVEL_ERROR, "Analyse_QueryReturn_Data: data:\n%s\n", xmldata);
        return r_value;
    }

    xml.IntoElem();
    if (xml.FindElem("head"))
    {
        xml.IntoElem();
        setlocale(LC_ALL, "chs");
        if (flag != 1)DATA_PRINT(LEVEL_DEBUG, "[解析head]\n");

        if (xml.FindElem("code"))
        {
            if (atoi(xml.GetData().c_str()) == 1)
            {
                r_value = 0;
                xml.ResetMainPos();
                if (xml.FindElem("rownum"))
                {
                    rownum = atoi(xml.GetData().c_str());
                    if (rownum > 0)
                    {
                        if (flag == 1)DATA_PRINT(LEVEL_INFO, "查询到%d个待检数据\n", rownum);
                        r_value = rownum;
                    }
                }
            }
        }

        xml.OutOfElem();
    }

    if (r_value < 0) {
        DATA_PRINT(LEVEL_ERROR, "Analyse_QueryReturn_Data: Check code error! \n");
        DATA_PRINT(LEVEL_ERROR, "Analyse_QueryReturn_Data: data:\n%s\n", xmldata);
    }

    if (flag == 0) {
        return r_value;
    }

    if (rownum == 0) {
        DATA_PRINT(LEVEL_INFO, "监管系统当前没有待审核的车辆。 \n");
        return r_value;
    }

    if (flag == 1)
    {
        pcurrent_lsh = (std::vector<std::string> *)pvehicle_void;
        pvehicle_inf = &temp_vehicle_inf;
    }
    else
        pvehicle_inf = (vehicle_inf *)pvehicle_void;

    std::vector<_photo_resource> UnknownPicList;

    if (xml.FindElem("body"))
    {
        int photodes_id = 0;
        int vehicle_id = 0;
        xml.IntoElem();
        setlocale(LC_ALL, "chs");
        DATA_PRINT(LEVEL_DEBUG, "[解析body]\n");

        while (xml.FindElem("vehicle"))
        {
            if (atoi(xml.GetAttrib("id").c_str()) == vehicle_id)
            {
                for (unsigned int i = 0; i < pvehicle_inf->item_description.size(); i++)
                {
                    if (flag == 2) {
                        DATA_PRINT(LEVEL_DEBUG, "%s--", pvehicle_inf->item_description[i].name_desc);
                    }

                    if (xml.FindChildElem(pvehicle_inf->item_description[i].name_tag)){
                        //other basic inf:
                        std::string vehicle_str = xml.GetChildData();
                        if (vehicle_str.length() > 0)
                            *(std::string *)(pvehicle_inf->item_description[i].value) = vehicle_str;

                       if (flag == 2) {
                            DATA_PRINT(LEVEL_DEBUG, "%s \n", (*(std::string *)(pvehicle_inf->item_description[i].value)).c_str());
                       }
                    }
                    else
                    {
                        if (flag == 2) {
                            DATA_PRINT(LEVEL_DEBUG, "not found \n");
                        }
                    }

                    xml.ResetChildPos();
                }
                if (flag == 1) pcurrent_lsh->push_back(pvehicle_inf->m_jylsh);
            }
            vehicle_id++;
        }

        if (flag == 1) {
            if (r_value < 0) {
                DATA_PRINT(LEVEL_ERROR, "Analyse_QueryReturn_Data: get lsh error! \n");
                DATA_PRINT(LEVEL_ERROR, "Analyse_QueryReturn_Data: data:\n%s\n", xmldata);
            }

            return r_value;
        }

        xml.ResetMainPos();
        while (xml.FindElem("photodes"))
        {
            _photo_resource v_photo_resource;
            if (atoi(xml.GetAttrib("id").c_str()) == photodes_id)
            {
                if (xml.FindChildElem("zpzl"))
                {
                    unsigned int s = 0;
                    std::string zpzltemp = xml.GetChildData();
                    vector<std::string> zpzl_check = ZPZL_CHECK;
                    for (s = 0; s < zpzl_check.size(); s++)
                    {
                        if (zpzltemp == zpzl_check[s])
                            break;
                    }

                    //if (s < zpzl_check.size())//ignore some photos
                    if(1)
                    {
                        v_photo_resource.zptype = zpzltemp;
                        if (xml.FindChildElem("zpurl"))
                        {
                            std::string zpurlstr = "http://";
                            zpurlstr += g_remoteServerIp;
                            zpurlstr += ":";
                            zpurlstr += g_remoteServerPort;
                            zpurlstr += "/";
                            zpurlstr += g_photoUri;
                            zpurlstr += "/";
                            zpurlstr += xml.GetChildData();
                            v_photo_resource.zpurl = zpurlstr;
                        }
                        v_photo_resource.local_path = "TBD";
                        pvehicle_inf->m_zplist.push_back(v_photo_resource);
                    }
                    else
                    {
                        v_photo_resource.zptype = zpzltemp;
                        UnknownPicList.push_back(v_photo_resource);
                    }
                }
            }

            photodes_id++;
        }

        xml.ResetMainPos();
        photodes_id = 0;
        while (xml.FindElem("refphotodes"))
        {
            _photo_resource v_photo_resource;
            if (atoi(xml.GetAttrib("id").c_str()) == photodes_id)
            {
                if (xml.FindChildElem("lb")) {
                    v_photo_resource.zptype = xml.GetChildData();
                }

                if (xml.FindChildElem("zpurl"))
                {
                    std::string zpurlstr = "http://";
                    zpurlstr += g_remoteServerIp;
                    zpurlstr += ":";
                    zpurlstr += g_remoteServerPort;
                    zpurlstr += "/";
                    zpurlstr += g_photoUri;
                    zpurlstr += "/";
                    zpurlstr += xml.GetChildData();
                    v_photo_resource.zpurl = zpurlstr;
                }
                v_photo_resource.local_path = "TBD";
                //pvehicle_inf->m_ckdbzplist.push_back(v_photo_resource);
                pvehicle_inf->m_zplist.push_back(v_photo_resource); //test GongGao photo
            }
            photodes_id++;
        }

        xml.OutOfElem();//body
        for (unsigned int i = 0; i<pvehicle_inf->m_ckdbzplist.size(); i++) {
            DATA_PRINT(LEVEL_DEBUG, "[ckzptype=%s url=%s loc=%s]\n",
                       pvehicle_inf->m_ckdbzplist[i].zptype.c_str(),
                       pvehicle_inf->m_ckdbzplist[i].zpurl.c_str(),
                       pvehicle_inf->m_ckdbzplist[i].local_path.c_str());
        }

        if (g_CheckItem.City == SUZHOU) {
            addPhoto_A_J(pvehicle_inf);
        }
    } else {
        r_value = -1;
    }

    if (r_value < 0) {
        DATA_PRINT(LEVEL_ERROR, "Analyse_QueryReturn_Data: get vehicle info error! \n");
        DATA_PRINT(LEVEL_ERROR, "Analyse_QueryReturn_Data: data:\n%s\n", xmldata);
    }

    return r_value;
}

std::string getMethod(evhttp_request *req)
{
    std::string method;

    switch (evhttp_request_get_command(req)) {
        case EVHTTP_REQ_GET:     method = "GET";break;
        case EVHTTP_REQ_POST:    method = "POST"; break;
        case EVHTTP_REQ_HEAD:    method = "HEAD"; break;
        case EVHTTP_REQ_PUT:     method = "PUT"; break;
        case EVHTTP_REQ_DELETE:  method = "DELETE"; break;
        case EVHTTP_REQ_OPTIONS: method = "OPTIONS"; break;
        case EVHTTP_REQ_TRACE:   method = "TRACE"; break;
        case EVHTTP_REQ_CONNECT: method = "CONNECT"; break;
        case EVHTTP_REQ_PATCH:   method = "PATCH"; break;
        default:                 method = "";
    }

    return method;
}

void webCB(evhttp_request *req, void *arg)
{
    UNUSED(arg);
    HTTP_REQ_HANDLE httpHandle;
    struct tm *m;
    time_t timep;

    memset(&httpHandle,0,sizeof(HTTP_REQ_HANDLE));

    httpHandle.req = req;
    httpHandle.remoteHost = std::string(req->remote_host);

    httpHandle.uri = std::string(evhttp_uridecode(evhttp_request_get_uri(req), 0, NULL));
    httpHandle.method = getMethod(req);

   time(&timep);
    m = localtime(&timep);
    sprintf(httpHandle.requesttime, "%4d-%02d-%02d %02d:%02d:%02d", (1900 + m->tm_year), (1 + m->tm_mon), m->tm_mday, m->tm_hour, m->tm_min, m->tm_sec);
    requestEvent(&httpHandle);
}
void startweb()
{
   HttpServer Https;
   initWebName2cb();
   Https.startHttpServer("0.0.0.0", 10080,webCB,NULL);
}

#include <thread>
void DataAnalyseThread(unsigned int GPU_ID)
{
    DATA_PRINT(LEVEL_INFO, "DataAnalyseThread(GPU_ID:%d) running...... \n", GPU_ID);

#ifndef	NO_ARTHMETIC
    DATA_PRINT(LEVEL_INFO, "Start initialization algorithm(GPU_ID:%d)...... \n", GPU_ID);
    EProjectType type =EProjectType::eJianYanType;
    LargeVehicleApi alg_api(true, GPU_ID,atoi(g_CheckItem.City.c_str()),type);
    std::string version;
    alg_api.algorithm_version(version);
    DATA_PRINT(LEVEL_INFO, "Algorithm initialization is complete! Version: %s, GPU_ID:%d \n", version.c_str(), GPU_ID);
#endif

    CityType cityType = (CityType)atoi(g_CheckItem.City.c_str());

    processBaseClass * pProcessBaseClass  = NULL;
    bool isNewPhotoProcess = processBaseClass::checkCity(cityType);
    if(isNewPhotoProcess)
    {
        pProcessBaseClass = processBaseClass::creatPicProcessClass(cityType);
        setProcessBaseClass(pProcessBaseClass);
        setMasterInfo(g_master_IP);
        for (unsigned int i = 0; i < SlaveList.size(); i++) {
             setSlaveInfo(SlaveList[i].ip);
        }

        new std::thread(startweb);
    }

    /* 由于算法初始化时间最长，应该是所有模块最后一个初始化完成的，所以把这句话放在这个位置。 */
    DATA_PRINT(LEVEL_INFO, "所有模块初始化完成，程序已进入正常运行状态...... \n");

    while (true) {
        vehicle_inf *v_vehicle_inf = NULL;

        v_vehicle_inf = toanalyse_queue.Take();
        v_vehicle_inf->timeRecord.endTime();
        v_vehicle_inf->timeRecord.wait_queue = std::to_string(std::stol(v_vehicle_inf->timeRecord.getTime())/1000); // milliseconds to seconds

        DATA_PRINT(LEVEL_INFO, "========================analyse_queue:%d, GPU_ID:%d==========================\n", toanalyse_queue.Size(), GPU_ID);
        if(isNewPhotoProcess)
        {
            exec_analyse_new(v_vehicle_inf, pProcessBaseClass, &alg_api);
        }else {
            exec_analyse(v_vehicle_inf, &alg_api);
        }
    }
}

void exec_analyse_new(void *lpParam, processBaseClass *pProcessBaseClass, LargeVehicleApi *alg)
{
    vehicle_inf *v_vehicle_inf = (vehicle_inf *)lpParam;

#ifndef NO_ARTHMETIC
    std::vector<classItem> paramList;
    std::vector<PhotoItem> photoList;

    baseTool::loadParamByVehicleInfo(&paramList,v_vehicle_inf);
    baseTool::loadPhotoListByVehicleInfo(&photoList,v_vehicle_inf);
    v_vehicle_inf->m_isPass = std::to_string(pProcessBaseClass->picProcess(paramList, &photoList, alg));
    v_vehicle_inf->m_deviceId = std::to_string(g_device_ID);
    baseTool::loadVehicleInfoByPhotoList(v_vehicle_inf,&photoList);
    baseTool::msgOut(baseTool::ERR, __FILE__, __LINE__, "~~~~~~~~~~~~~~~~~picProcess chePai:%s:"+v_vehicle_inf->m_hphm+" isPass:"+v_vehicle_inf->m_isPass);

#endif

    // su zhou 3rd interface
    if (g_3rdInterface) {
        time_t* p_curseconds = new time_t;
        time(p_curseconds);
        struct tm *p_curtime = localtime(p_curseconds);  //日历时间转化为本地时间
        delete(p_curseconds);
        /* 查询当前系统时间，判定是否处于配置文件中规定的工作时间段之外 */
        int time_start = g_CheckItem.ShiJian.KaiShi-1;
        int time_end   = g_CheckItem.ShiJian.JieShu+1;
        int time_cur   = p_curtime->tm_hour;
        if ((time_cur >= time_start) && (time_cur <= time_end)) { // 不在工作时间
            DATA_PRINT(LEVEL_INFO, "<3rd httpserver> 不在工作时间.\n");
        } else {
            g_record_3rd_queue.Put(v_vehicle_inf);
            return;
        }
    }

    if(g_SlaveCount != -1)//not master
    {
        reply_queue.Put(v_vehicle_inf);
    }
    else
    {
        reply_master_queue.Put(v_vehicle_inf);
    }


    return;
}



void exec_analyse(void *lpParam, LargeVehicleApi *alg)
{
    vehicle_inf *v_vehicle_inf = (vehicle_inf *)lpParam;
//    std::string xmldata;
//    char url_temp[256];
//    HttpClient AnalyseResult;
//    sprintf(url_temp, "http://%s:%s\0", g_remoteServerIp.c_str(), g_remoteServerPort.c_str());
//    std::string vehicleurl = url_temp;
//    vehicleurl += v_vehicle_inf->vehicle_sys_uri;
//    if (JGSYS_SOAP_PROCOTOL) {
//        //vehicleurl = "http://192.168.16.176:9008/trffweb/services/TmriOutAccess.asmx/writeObjectOut"; //test
//        vehicleurl = "http://" + g_localServerIp + ":9008/trffweb/services/TmriOutAccess.asmx/writeObjectOut";
//    }

#ifndef NO_ARTHMETIC
    /*for photo process*/
    process_photo(v_vehicle_inf, alg);
    v_vehicle_inf->m_isPass = is_Pass(v_vehicle_inf);
    DATA_PRINT(LEVEL_INFO, "process ispass=%s", v_vehicle_inf->m_isPass.c_str());
    v_vehicle_inf->m_deviceId = std::to_string(g_device_ID);

#endif

    // su zhou 3rd interface
    if (g_3rdInterface) {
        time_t* p_curseconds = new time_t;
        time(p_curseconds);
        struct tm *p_curtime = localtime(p_curseconds);  //日历时间转化为本地时间
        delete(p_curseconds);
        /* 查询当前系统时间，判定是否处于配置文件中规定的工作时间段之外 */
        int time_start = g_CheckItem.ShiJian.KaiShi-1;
        int time_end   = g_CheckItem.ShiJian.JieShu+1;
        int time_cur   = p_curtime->tm_hour;
        if ((time_cur >= time_start) && (time_cur <= time_end)) { // 不在工作时间
            DATA_PRINT(LEVEL_INFO, "<3rd httpserver> 不在工作时间.\n");
        } else {
            g_record_3rd_queue.Put(v_vehicle_inf);
            return;
        }
    }

    ////////////////////////////////////////////////
/*    if (JGSYS_SOAP_PROCOTOL)//test JiAn interface
    {
        TmriOutAccessSoapBindingProxy soapclient;
        soapclient.accept_timeout = 30;
        soapclient.connect_timeout = 30;
        soapclient.recv_timeout = 30;
        soapclient.send_timeout = 30;

        vehicle_inf lsh_vehicle_inf;
        char *queryReturn = NULL;
        DATA_PRINT(LEVEL_DEBUG, "[创建]\n");

        if (v_vehicle_inf->m_dbbhglist.size() == 0)
        {
            xmldata = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><vehispara><lsh>";
            xmldata += v_vehicle_inf->m_jylsh;
            //xmldata += v_vehicle_inf->m_lsh;
            xmldata += "</lsh><zpzl></zpzl><jg>1</jg><sm>ok</sm></vehispara></root>";
            soapclient.writeObjectOut("18", (char*)g_confJkxlh.GetString(), "18C92",
                (char *)xmldata.GetString(), queryReturn);

            DATA_PRINT(LEVEL_DEBUG, "<-----SoapServer\n");
            DATA_PRINT(LEVEL_ALL, "Received a SoapServer response for ");
            if (queryReturn != NULL)
            {
                DATA_PRINT(LEVEL_ALL, "%s\n", (char *)UTF8toANSI((char *)URLDecode(queryReturn).c_str()).GetString());
                if (Analyse_QueryReturn_Data((char *)UTF8toANSI(queryReturn).GetString(), &lsh_vehicle_inf, 0) < 0)
                {
                    DATA_PRINT(LEVEL_ERROR, "Write data to SoapServer unsuccessful!\n");
                }
                else DATA_PRINT(LEVEL_DEBUG, "OK\n");//返回位置
            }
            else
            {
                confirm_lsh.push_back(v_vehicle_inf->m_jylsh);//流水号插入 7.11
            }
        }
        ///////else
        //vector <CString> feedback_list = ZPZL_CHECK;
        BOOL b_check_noresponse = TRUE;
        for (unsigned int i = 0; i < v_vehicle_inf->m_zplist.size(); i++)
        {
            bool b_feedbackok = TRUE;
            unsigned int j = 0;
            for (; j < v_vehicle_inf->m_dbbhglist.size(); j++)
            {
                if (v_vehicle_inf->m_dbbhglist[j].zptype == v_vehicle_inf->m_zplist[i].zptype)
                {
                    xmldata = Prepare_SoapXml_Data(v_vehicle_inf, j);
                    b_feedbackok = FALSE;
                    break;
                }
            }

            //DATA_PRINT(LEVEL_DATA, "%s\n", xmldata.GetString());
            if (b_feedbackok)
            {
                xmldata = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><vehispara><lsh>";
                xmldata += v_vehicle_inf->m_jylsh;
                //xmldata += v_vehicle_inf->m_lsh;
                xmldata += "</lsh><zpzl>";
                xmldata += v_vehicle_inf->m_zplist[i].zptype;
                xmldata += "</zpzl><jg>1</jg><sm>ok</sm></vehispara></root>";
            }

            DATA_PRINT(LEVEL_INFO, "Writing the check result for %s to SOAP server...... \n", v_vehicle_inf->m_zplist[i].zptype.c_str());
            v_vehicle_inf->timeRecord.startTime();
            soapclient.writeObjectOut("18", (char *)g_confJkxlh.c_str(), "18C92", (char *)xmldata.c_str(), queryReturn);
            v_vehicle_inf->timeRecord.endTime();
            recordResponseTime(v_vehicle_inf, v_vehicle_inf->m_zplist[i].zptype, v_vehicle_inf->timeRecord.getTime());

            DATA_PRINT(LEVEL_INFO, "SOAP server has received the check result. The response is: ");
            if (queryReturn != NULL)
            {
                if (Analyse_QueryReturn_Data((char *)UTF8toANSI(queryReturn).c_str(), &lsh_vehicle_inf, 0) < 0)
                {
                    DATA_PRINT(LEVEL_ERROR, "Write data to SoapServer unsuccessful! \n");
                }
                else
                {
                    DATA_PRINT(LEVEL_DEBUG, "OK \n");
                }
            }
            else
            {
                if (b_check_noresponse)
                {
                    b_check_noresponse = FALSE;
                    confirm_lsh.push_back(v_vehicle_inf->m_jylsh);//流水号插入 7.11
                    DATA_PRINT(LEVEL_ERROR, "SoapServer no response for lsh: %s ,check again\n", v_vehicle_inf->m_jylsh.c_str());
                }
            }
        }
        DATA_PRINT(LEVEL_INFO, "\n");

        DATA_PRINT(LEVEL_DEBUG, "dbbhglist: \n");
        for (unsigned int k = 0; k < v_vehicle_inf->m_dbbhglist.size(); k++) {
            DATA_PRINT(LEVEL_DEBUG, "[type=%s sm=%s jg=%s]\n",
                       v_vehicle_inf->m_dbbhglist[k].zptype.c_str(),
                       v_vehicle_inf->m_dbbhglist[k].dbbhg_desc.c_str(),
                       v_vehicle_inf->m_dbbhglist[k].dbresult.c_str());
        }

        // 如果zplist为空，回复“建议人工”
        if (v_vehicle_inf->m_zplist.size() == 0) {
            DATA_PRINT(LEVEL_ERROR, "zplist is empty! \n");

            xmldata = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><vehispara><lsh>";
            xmldata += v_vehicle_inf->m_jylsh;
            xmldata += "</lsh><zpzl>";
            xmldata += "</zpzl><jg>4</jg><sm>no picture</sm></vehispara></root>";

            soapclient.writeObjectOut("18", (char *)g_confJkxlh.c_str(), "18C92", (char *)xmldata.c_str(), queryReturn);

            if (queryReturn != NULL)
            {
                if (Analyse_QueryReturn_Data((char *)UTF8toANSI(queryReturn).c_str(), &lsh_vehicle_inf, 0) < 0)
                {
                    DATA_PRINT(LEVEL_ERROR, "Write data to SoapServer unsuccessful!\n");
                } else
                {
                    DATA_PRINT(LEVEL_DEBUG, "OK\n");
                }
            } else
            {
                if (b_check_noresponse)
                {
                    b_check_noresponse = FALSE;
                    confirm_lsh.push_back(v_vehicle_inf->m_jylsh);//流水号插入 7.11
                    DATA_PRINT(LEVEL_ERROR, "SoapServer no response for lsh: %s ,check again\n", v_vehicle_inf->m_jylsh.c_str());
                }
            }
        }
    }

    v_vehicle_inf->timeRecord.endTime_total();
    v_vehicle_inf->timeRecord.total = v_vehicle_inf->timeRecord.getTime_total();

    unsigned long total_no_wait = std::stoul(v_vehicle_inf->timeRecord.total) - std::stoul(v_vehicle_inf->timeRecord.wait_queue);
    v_vehicle_inf->timeRecord.total_no_wait = std::to_string(total_no_wait);

#ifndef	NO_DATABASE
    operateDatabase(v_vehicle_inf);
#endif

    if (v_vehicle_inf)
        delete v_vehicle_inf;

    DATA_PRINT(LEVEL_DEBUG, "<------------------- A vehicle check request has been handled. -------------------> \n\n");
*/
    if(g_SlaveCount != -1)//not master
    {
        reply_queue.Put(v_vehicle_inf);
    }
    else
    {
        reply_master_queue.Put(v_vehicle_inf);
    }

    return;
}

BlockingQueue<int> DownloadThreadCount;

void PhotoDwlThread()
{
    std::thread *exec_Download;
    /* 创建照片文件夹 */
    struct stat st_buf = {};
    stat(g_photoFilePath.c_str(), &st_buf);
    if ((st_buf.st_mode & S_IFMT) != S_IFDIR) {
        mkdir(g_photoFilePath.c_str(), 0777);
    }

    if (g_CheckItem.picture.CheJiaHao.BaoDing_FTP) {
        FtpInit();

        /* 创建保定clsbdh.txt的文件夹 */
        std::string dir = BAODING_TXT_DIR;
        struct stat st_buf = {};
        stat(dir.c_str(), &st_buf);
        if ((st_buf.st_mode & S_IFMT) != S_IFDIR) {
            mkdir(dir.c_str(), 0777);
        }
    }

    while (true) {
        vehicle_inf *v_vehicle_inf = NULL;
        v_vehicle_inf = download_queue.Take();
        DATA_PRINT(LEVEL_INFO, "===========================download_queue:%d=============================\n", download_queue.Size());

        try {
            /* 判断同时开启的线程数是否超过限制 */
            if (DownloadThreadCount.Size() < g_DownloadLimit) {
                v_vehicle_inf->timeRecord.start_total_time = v_vehicle_inf->timeRecord.getCurrentTime();
                DATA_PRINT(LEVEL_INFO,"current time is %ld\n",v_vehicle_inf->timeRecord.start_total_time);
                exec_Download = new std::thread(exec_downlond, v_vehicle_inf);
                exec_Download->detach();
                delete exec_Download;
                DownloadThreadCount.Put(1);

                DATA_PRINT(LEVEL_INFO, "Vehicle check request(lsh:%s) began to download the photo. \n\n", v_vehicle_inf->m_jylsh.c_str());
            } else {
                download_queue.RePut(v_vehicle_inf);
                DATA_PRINT(LEVEL_INFO, "Thread[exec_downlond] count has reached maximum limit(%d), check request is put in the download_queue again. \n\n", g_DownloadLimit);
                std::this_thread::sleep_for(std::chrono::milliseconds(1000));
            }
        } catch (const std::system_error& e) {
            DATA_PRINT(LEVEL_ERROR, "Create new thread(exec_Download) failure! \n");
            std::cout << "Error code: " << e.code() << ", reason: " << e.what() << std::endl;
            return;
        }
    }
}

/* 由于linux文件系统不支持某些符号作为文件名，因此要将其转换 */
string formatFileName(std::string name)
{
    try {
        for (unsigned int i = 0; i < name.size(); i++) {
            if (name[i] == '/') {
                name.replace(i, 1, 1, '=');
            }
        }
    } catch (const std::exception &e) {
        DATA_PRINT(LEVEL_ERROR, "formatFileName() failure! \n");
        std::cout << "Error: " << e.what() << std::endl;
        return "";
    }

    return name;
}

string formatFileNameLunTai(std::string name)
{
    std::string name_buf = name;
    try {
        for (unsigned int i = 0; i < name.size(); i++) {
            if (name_buf[i] == ',' || name_buf[i] == ' ' || name_buf[i] == ';') {
                name_buf.erase(i);
                break;
            }
        }
    } catch (const std::exception &e) {
        DATA_PRINT(LEVEL_ERROR, "formatFileName() failure! \n");
        std::cout << "Error: " << e.what() << std::endl;
        return "";
    }

    return name_buf;
}
extern _ZhaoPianZL ZhaoPianZL;
std::string addPhotoName(const vehicle_inf *vehicle, int index)
{
    std::string result;
    std::string type = vehicle->m_zplist[index].zptype;
    std::string hphm = (vehicle->m_hphm == "无数据") ? "None" : vehicle->m_hphm;
    std::string clsbdh = (vehicle->m_clsbdh == "无数据") ? "None" : vehicle->m_clsbdh;
    ResultCollection tmp;

    result = type + "_" + hphm + "_" + clsbdh;

    if (vehicle->m_zplist[index].zptype == ZhaoPianZL.XingShiZheng) {	/* 行驶证保存照片增加“行驶证编号”和“发证日期” */
        std::string xszbh = (vehicle->m_xszbh == "无数据") ? "None" : vehicle->m_xszbh;
        std::string fzrq = (vehicle->m_fzrq == "无数据") ? "None" : vehicle->m_fzrq;
        std::string zcrq = (vehicle->m_ccdjrq == "无数据") ? "None" : vehicle->m_ccdjrq;

        if (fzrq != "None") {
            fzrq = tmp.formatingDate(fzrq);
        }

        if (zcrq != "None") {
            zcrq = tmp.formatingDate(zcrq);
        }

        result += "_" + xszbh + "_" + fzrq + "_" + zcrq;
    }else if(vehicle->m_zplist[index].zptype == ZhaoPianZL.WanShuiZhengMing)
    {
        string jssj = (vehicle->m_jssj == "无数据") ? "None" : vehicle->m_jssj;
        result += "_" + jssj;
    }else if (vehicle->m_zplist[index].zptype == ZhaoPianZL.ZuoQianFang || vehicle->m_zplist[index].zptype == ZhaoPianZL.YouHouFang || vehicle->m_zplist[index].zptype == ZhaoPianZL.ZuoFang) {
        //std::string clpp = (vehicle->m_clpp1 == "无数据") ? "None" : vehicle->m_clpp1;
        std::string clxh = (vehicle->m_clxh == "无数据") ? "None" : vehicle->m_clxh;
        std::string cllx = (vehicle->m_cllx == "无数据") ? "None" : vehicle->m_cllx;
        //result += "_" + clpp + "_" + clxh;

        clxh = formatFileName(clxh);
        std::string csys = (vehicle->m_csys == "无数据") ? "None" :vehicle->m_csys;
        result += "_" + clxh + "_" + cllx + "_" + csys;
    } else if ((vehicle->m_zplist[index].zptype == ZhaoPianZL.ZuoQianLun) || (vehicle->m_zplist[index].zptype == ZhaoPianZL.YouQianLun)) {	/* 轮胎相关照片增加“轮胎规格” */
        std::string ltgg = (vehicle->m_ltgg == "无数据") ? "None" : vehicle->m_ltgg;

        ltgg = formatFileName(ltgg);
        ltgg = formatFileNameLunTai(ltgg);

        result += "_" + ltgg;
    } else if ((vehicle->m_zplist[index].zptype == ZhaoPianZL.DaCheHaoPai)|| (vehicle->m_zplist[index].zptype == ZhaoPianZL.WaiKuoQianMian)|| (vehicle->m_zplist[index].zptype == ZhaoPianZL.WaiKuoCeMian)) {	/* 外观相关照片增加“cllx” */
            std::string cllx = (vehicle->m_ltgg == "无数据") ? "None" : vehicle->m_cllx;
            result += "_" + cllx;
    } else if (vehicle->m_zplist[index].zptype == ZhaoPianZL.JiaoQiangXian) {	/* 交强险增加保险开始和结束日期,检验结束日期,发动机号 */
        std::string sxrq = (vehicle->m_sxrq == "无数据") ? "None" : vehicle->m_sxrq;
        std::string zzrq = (vehicle->m_zzrq == "无数据") ? "None" : vehicle->m_zzrq;
        std::string jssj;
        std::string fdjh = (vehicle->m_fdjh == "无数据" || vehicle->m_fdjh == "无") ? "None" : vehicle->m_fdjh;
        std::string hdzk = (vehicle->m_cllx == "无数据") ? "None" : vehicle->m_hdzk;

        if (g_CheckItem.City == BAODING || g_CheckItem.City == TAIYUAN || g_CheckItem.City == XUZHOU) {  /* 保定太原要求保单判定当天时间 */
            if(!g_TestMode)
            {
                std::time_t t = std::time(NULL);
                std::tm *st = std::localtime(&t);
                char tmpArray[128] = { 0 };
                sprintf(tmpArray, "%d%02d%02d", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);
                jssj = tmpArray;
            }
            else
            {
                jssj = (vehicle->m_jssj == "无数据") ? "None" : vehicle->m_jssj;
            }

        } else {
            jssj = (vehicle->m_jssj == "无数据") ? "None" : vehicle->m_jssj;
        }

        if (sxrq != "None") {
            sxrq = tmp.formatingDate(sxrq);
        }

        if (zzrq != "None") {
            zzrq = tmp.formatingDate(zzrq);
        }

        if (jssj != "None") {
            jssj = tmp.formatingDate(jssj);
        }

        fdjh = formatFileName(fdjh);

        result += "_" + sxrq + "_" + zzrq + "_" + jssj + "_" + fdjh + "_" + hdzk;
    } else if (vehicle->m_zplist[index].zptype == ZhaoPianZL.WeiQiJianYan) {	/* 增加开始日期 */
        if(g_CheckItem.City == SUZHOU)
        {
            std::string kssj = (vehicle->dz_wqjcrq == "") ? "None" : vehicle->dz_wqjcrq;
            if (kssj != "None") {
                kssj = tmp.formatingDate(kssj,1);

            }
            result += "_" + kssj;
        }
        else if(g_CheckItem.City == PUTIAN)
        {/*  莆田环保单增加发动机编号和检测时间 */
            string jssj;
            std::time_t t = std::time(NULL);
            std::tm *st = std::localtime(&t);
            char tmpArray[128] = { 0 };
            sprintf(tmpArray, "%d%02d%02d", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);
            jssj = tmpArray;
            std::string fdjxh = (vehicle->m_cllx == "无数据") ? "None" : vehicle->m_fdjxh;
            result += "_" + fdjxh + "_" + jssj;
        }
    } else if ((vehicle->m_zplist[index].zptype == ZhaoPianZL.YiZhouZhiDong) || (vehicle->m_zplist[index].zptype == ZhaoPianZL.ErZhouZhiDong)||(vehicle->m_zplist[index].zptype == ZhaoPianZL.ZhuCheZhiDong)) {	/* 一轴和二轴制动照片增加“检验机构编号” */
        std::string jyjgbh = (vehicle->m_jyjgbh == "无数据") ? "None" : vehicle->m_jyjgbh;

        result += "_" + jyjgbh;
    } else if (vehicle->m_zplist[index].zptype == ZhaoPianZL.CheLiangMingPai) {

        /* 连云港“车辆铭牌”照片：增加“发动机号”，“排量”，“出厂日期” */
        if (g_CheckItem.City == LIANYUNGANG) {
            std::string fdjxh = (vehicle->m_fdjxh == "无数据" || vehicle->m_fdjxh == "无") ? "None" : vehicle->m_fdjxh;
            std::string pl = (vehicle->m_pl == "无数据") ? "None" : vehicle->m_pl;
            std::string ccrq = (vehicle->m_ccrq == "无数据") ? "None" : vehicle->m_ccrq;

            if (ccrq != "None") {
                ccrq = tmp.formatingDate(ccrq);
            }

            fdjxh = formatFileName(fdjxh);

            result += "_" + fdjxh + "_" + pl + "_" + ccrq;
        }
    }  else if (vehicle->m_zplist[index].zptype == ZhaoPianZL.CheXiang) {
        std::string hdzk = (vehicle->m_hdzk == "无数据") ? "None" : vehicle->m_hdzk;
        std::string cllx = (vehicle->m_cllx == "无数据") ? "None" : vehicle->m_cllx;
         result += "_" + hdzk + "_" + cllx;
    }   else if(vehicle->m_zplist[index].zptype == ZhaoPianZL.CheLiangCeMian)
     {
        std::string zzl = (vehicle->m_zzl == "无数据") ? "None" :vehicle->m_zzl;
        std::string hxnbgd = (vehicle->m_hxnbgd == "无数据") ? "None" :vehicle->m_hxnbgd;
        std::string hdzk = (vehicle->m_hdzk == "无数据") ? "None" :vehicle->m_hdzk;
        result += "_" + zzl + "_" + hxnbgd + "_" + hdzk;
     }
    else if(vehicle->m_zplist[index].zptype == ZhaoPianZL.HeDingZaiKe)
    {
        std::string hdzk = (vehicle->m_hdzk == "无数据") ? "None" :vehicle->m_hdzk;
        result += "_"  + hdzk;
    }
    return result;
}

class PictureResult {
public:
    bool ok;
    unsigned int number;
    _photo_resource info;
};

class PictureInfo {
public:
    unsigned int number;
    std::string photourl;
    std::string photo_fileid;

    BlockingQueue<PictureResult> *queue;
};

void downloadPicture(PictureInfo *lpParam)
{
    PictureInfo *picture = lpParam;

    HttpClient RequestPhoto;
    PictureResult result;
    result.ok = false;
    result.number = picture->number;

    if (RequestPhoto.InitData(picture->photourl.c_str(), REQUEST_GET_FLAG, NULL, NULL)) {
        RequestPhoto.m_photo_fileid = picture->photo_fileid;
        RequestPhoto.startHttpClient(); //下载照片

        result.ok = true;
        result.info.zpid = RequestPhoto.m_photo_fileid;
        result.info.local_path = RequestPhoto.m_photo_filename;
#ifdef DEMO_TEST
        result.info.demo_local_path = RequestPhoto.m_demo_filename;
#endif
    }

    picture->queue->Put(result);
    delete picture;
}



void Video_Download(vehicle_inf *v_vehicle_inf)
{
    /* 视频下载 */
   DATA_PRINT(LEVEL_INFO, "start video download  ............... \n");
   struct stat st_buf = {};
   stat(g_videoFilePath.c_str(), &st_buf);
   if ((st_buf.st_mode & S_IFMT) != S_IFDIR) {
       mkdir(g_videoFilePath.c_str(), 0777);
       DATA_PRINT(LEVEL_INFO, "生成视频文件夹 ............... \n");
   }
   string video_datapath;
   video_datapath = g_videoFilePath;
   std::time_t t = std::time(NULL);
   std::tm *st = std::localtime(&t);
   char tmpArray[128] = { 0 };
   sprintf(tmpArray, "%d-%02d-%02d", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);
   std::string strCurTime = tmpArray;
   video_datapath+=strCurTime;
   video_datapath+="/";
   struct stat st_buf1;
   memset(&st_buf1,0,sizeof(st_buf1));
   stat(video_datapath.c_str(), &st_buf1);
   if ((st_buf1.st_mode & S_IFMT) != S_IFDIR) {
       mkdir(video_datapath.c_str(), 0777);
       DATA_PRINT(LEVEL_INFO, "生成视频当前日期文件夹 ............... \n");
   }
   for (unsigned int j = 0; j< v_vehicle_inf->m_splist.size() ;j++)
   {
       v_vehicle_inf->m_splist[j].dzzl = "ftp";
       if(v_vehicle_inf->m_splist[j].spurl.find(g_localServerIp.c_str()) != string::npos)
       {/*判断机器本身就是ftp服务器*/
           std::string spurl = v_vehicle_inf->m_splist[j].spurl;
           std::string file_name = "\0";
           std::string::size_type pos1 = std::string::npos;
           pos1 = spurl.rfind('/');
           if (pos1 != std::string::npos)
           {/*获取视频文件名位置*/
               file_name = spurl.substr(0, pos1);
               pos1 = file_name.rfind('/');
               if (pos1 != std::string::npos)
                {/*获取视频日期文件夹位置*/
                   file_name = spurl.substr(pos1 + 1, spurl.length() - 1 - pos1);
                }
           }
           v_vehicle_inf->m_splist[j].local_path = g_videoFilePath;
           v_vehicle_inf->m_splist[j].local_path += file_name;
           DATA_PRINT(LEVEL_INFO, "video spurl:%s, local_path:%s \n", v_vehicle_inf->m_splist[j].spurl.c_str(), v_vehicle_inf->m_splist[j].local_path.c_str());
       }
       else
       {
           v_vehicle_inf->m_splist[j].name =  v_vehicle_inf->m_splist[j].spzl + "_";
           v_vehicle_inf->m_splist[j].name += v_vehicle_inf->m_hphm;
           v_vehicle_inf->m_splist[j].name += "_" + v_vehicle_inf->m_clsbdh;
           if(v_vehicle_inf->m_splist[j].spurl.find(".mp4") != string::npos)
           {
               v_vehicle_inf->m_splist[j].name += ".mp4";
           }
           else if(v_vehicle_inf->m_splist[j].spurl.find(".flv") != string::npos)
           {
               v_vehicle_inf->m_splist[j].name += ".flv";
           }
           else if(v_vehicle_inf->m_splist[j].spurl.find(".avi") != string::npos)
           {
               v_vehicle_inf->m_splist[j].name += ".avi";
           }
           else
           {
               v_vehicle_inf->m_splist[j].name +="";
           }
           v_vehicle_inf->m_splist[j].local_path = video_datapath ;
           v_vehicle_inf->m_splist[j].local_path += v_vehicle_inf->m_splist[j].name;
           //原url为ftp://192.168.18.26:21//2019-09-26/dc110a9efcaa49b18be2ee2233ef9559.mp4改为ftp://192.168.18.26:21/2019-09-26/dc110a9efcaa49b18be2ee2233ef9559.mp4
           std::string spurl = v_vehicle_inf->m_splist[j].spurl;
          // spurl.replace(spurl.rfind("//"), 2, g_videoFilePath.c_str());
           spurl.replace(spurl.rfind("//"), 2, "/");
           FtpClient ftpc;
           if(ftpc.ftpdownload(spurl ,v_vehicle_inf->m_splist[j].local_path))
           {
               DATA_PRINT(LEVEL_INFO, "FTP Download Video Success, spurl:%s, local_path:%s \n", spurl.c_str(), v_vehicle_inf->m_splist[j].local_path.c_str());
           }
           else
           {
               DATA_PRINT(LEVEL_INFO, "FTP Download Video Failed, spurl:%s, local_path:%s \n", spurl.c_str(), v_vehicle_inf->m_splist[j].local_path.c_str());
           }
        }
     }
}

void exec_downlond(void *lpParam)
{
    vehicle_inf *v_vehicle_inf = (vehicle_inf *)lpParam;
    _vedio_dwl_data* vedio_dwl_data = NULL;
    int video_count=0;
    v_vehicle_inf->timeRecord.startTime();

    /* 苏州电子交强险保单审核结果获取解析 */
    if ((g_CheckItem.picture.JiaoQiangXian.DianZiBaoDan)&&(!g_TestMode)&&(g_CheckItem.City=="3205"))
    {
        std::string data;
        g_jqxbd_result.empty();
        std::string Bddata;
        std::string pf;
        //get g_soap_token
        time_t end;
        end = std::time(nullptr);
        if ((start == 0) || ((end - start) > 3600))
        {
            Bddata = "<?xml version=\"1.0\" encoding=\"utf-8\"?><soap:Envelope xmlns:xsi = \"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap = \"http://schemas.xmlsoap.org/soap/envelope/\">";
            Bddata += "<soap:Body><GetToken xmlns = \"http://tempuri.org/\"><App_ID>SHYK</App_ID><App_Secret>SHYK</App_Secret><AppIP>";
            Bddata += g_localServerIp;
            Bddata += "</AppIP><App_Mac>";
            Bddata += LocalMac;
            Bddata += "</App_Mac></GetToken></soap:Body></soap:Envelope>";
            HttpClient gettoken;
            DATA_PRINT(LEVEL_DEBUG, "sent %s ", Bddata.c_str());
            if (gettoken.InitData("http://192.168.0.242:7999/InsurService.asmx", REQUEST_SOAP_FLAG, HTTP_CONTENT_TYPE_TEXT_XML, (char *)Bddata.c_str()))
            //if (gettoken.InitData((char*)"http://192.168.100.215:9898/InsurService.asmx", REQUEST_SOAP_FLAG,HTTP_CONTENT_TYPE_TEXT_XML, (char *)Bddata.c_str()))
            {
                DATA_PRINT(LEVEL_DEBUG, "token http int OK !! ");
                g_jqxbd_result.empty();
                gettoken.startHttpClient();
            }
            //debug
            pf = g_jqxbd_result;
            //DATA_PRINT(LEVEL_DEBUG, "token is:%s\n", pf.c_str());
            DATA_PRINT(LEVEL_DEBUG, "token copy pf \n");
            if (pf.find("获取Token成功") != std::string::npos) {
                int position = pf.find("ACCESS_TOKEN");
                position += 15;
                g_soap_token =pf.substr(position, 20);
                DATA_PRINT(LEVEL_DEBUG, "token operation finished \n");
                start = std::time(nullptr);
            } else {
                DATA_PRINT(LEVEL_ERROR, "Failed to get the DianZiBaoDan token！ \n");
            }

        }
        //get result
        Bddata = "<?xml version=\"1.0\" encoding=\"utf-8\"?><soap:Envelope xmlns:xsi = \"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap = \"http://schemas.xmlsoap.org/soap/envelope/\"><soap:Body><InsurancePassNew xmlns=\"http://tempuri.org/\"><token>";
        Bddata += g_soap_token;
        Bddata += "</token><HPHM>";
        Bddata += v_vehicle_inf->m_hphm;
        Bddata += "</HPHM><HPZL>";
        Bddata += v_vehicle_inf->m_hpzl;
        Bddata += "</HPZL><VIN>";
        Bddata += v_vehicle_inf->m_clsbdh;
        Bddata += "</VIN><DEPTCODE>";
        Bddata += v_vehicle_inf->m_jyjgbh;
        Bddata += "</DEPTCODE><type>1</type></InsurancePassNew></soap:Body></soap:Envelope>";
        pf = Bddata;
        //DATA_PRINT(LEVEL_DEBUG, "-------------------------check response :\n %s\n", pf.c_str());
        HttpClient Jqxbd;
        if (Jqxbd.InitData("http://192.168.0.242:7999/InsurService.asmx", REQUEST_SOAP_FLAG, HTTP_CONTENT_TYPE_TEXT_XML, (char *)Bddata.c_str()))
        //if (Jqxbd.InitData((char*)"http://192.168.100.215:9898/InsurService.asmx", REQUEST_SOAP_FLAG,HTTP_CONTENT_TYPE_TEXT_XML, (char *)Bddata.c_str()))
        {
            g_jqxbd_result.empty();
            Jqxbd.startHttpClient();
        }

        pf = g_jqxbd_result;
        DATA_PRINT(LEVEL_DEBUG, "get result is:%s\n", pf.c_str());
        /* 解析部分 */
        std::string dzbd_result;
        if((g_jqxbd_result.find("true",0) == string::npos)&&(g_jqxbd_result.find("false",0) == string::npos))
        {
            v_vehicle_inf->b_jqxdzbd=2;
            dzbd_result="未查询到车辆保险信息";
            DATA_PRINT(LEVEL_DEBUG, "dzbd response not find\n");
        }
        else
        {

            if(g_jqxbd_result.find("未查询到车辆保险信息",0) == string::npos)
            {
                if(g_jqxbd_result.find("false",0) == string::npos)
                {
                    v_vehicle_inf->b_jqxdzbd=1;
                    dzbd_result="交强险在有效期内";
                    DATA_PRINT(LEVEL_DEBUG, "dzbd response pass\n");
                }
                else
                {
                    v_vehicle_inf->b_jqxdzbd=3;
                     dzbd_result="保单信息不通过";
                    DATA_PRINT(LEVEL_DEBUG, "dzbd response not pass\n");
                }
            }
            else
            {
                 v_vehicle_inf->b_jqxdzbd=2;
                 dzbd_result="未查询到车辆保险信息";
                 DATA_PRINT(LEVEL_DEBUG, "dzbd response need alg's answer\n");
            }
        }

        MySQL_DB db_dzbd;
        if (db_dzbd.connect(NULL, 6033, "root", getDBPassWord(DBPWD).c_str(), "car_schema")) {
            std::string sqlString;
            sqlString = "("
                        "jylsh, hphm, jyjgbh, clsbdh, hpzl, dzjl, dzyy, hfxx, device_id"
                        ")"
                        " VALUES "
                        "(";
            sqlString += "'" + v_vehicle_inf->m_jylsh + "'";
            sqlString += ",";
            sqlString += "'" + v_vehicle_inf->m_hphm + "'";
            sqlString += ",";
            sqlString += "'" + v_vehicle_inf->m_jyjgbh + "'";
            sqlString += ",";
            sqlString += "'" + v_vehicle_inf->m_clsbdh + "'";
            sqlString += ",";
            sqlString += "'" + v_vehicle_inf->m_hpzl + "'";
            sqlString += ",";
            sqlString += "'" + to_string(v_vehicle_inf->b_jqxdzbd) + "'";
            sqlString += ",";
            sqlString += "'" + dzbd_result + "'";
            sqlString += ",";
            sqlString += "'" + g_jqxbd_result + "'";
            sqlString += ",";
            sqlString += "'" + to_string(g_device_ID) + "'";
            sqlString += ")";
            DATA_PRINT(LEVEL_DEBUG, "Insert into suzhou_dzbd, data: %s \n", sqlString.c_str());
            db_dzbd.insert("suzhou_dzbd", sqlString.c_str());
            db_dzbd.disconnect();
            }
        else {
            DATA_PRINT(LEVEL_DEBUG, "Insert into suzhou_dzbd database not connected\n");
        }
        if((g_SlaveCount==-1)&&(g_CheckItem.City==SUZHOU)) {
            if (db_dzbd.connect(g_master_IP.c_str(), 6033, "root", getDBPassWord(DBPWD).c_str(), "car_schema")) {
                std::string sqlString;
                sqlString = "("
                            "jylsh, hphm, jyjgbh, clsbdh, hpzl, dzjl, dzyy, hfxx, device_id"
                            ")"
                            " VALUES "
                            "(";
                sqlString += "'" + v_vehicle_inf->m_jylsh + "'";
                sqlString += ",";
                sqlString += "'" + v_vehicle_inf->m_hphm + "'";
                sqlString += ",";
                sqlString += "'" + v_vehicle_inf->m_jyjgbh + "'";
                sqlString += ",";
                sqlString += "'" + v_vehicle_inf->m_clsbdh + "'";
                sqlString += ",";
                sqlString += "'" + v_vehicle_inf->m_hpzl + "'";
                sqlString += ",";
                sqlString += "'" + to_string(v_vehicle_inf->b_jqxdzbd) + "'";
                sqlString += ",";
                sqlString += "'" + dzbd_result + "'";
                sqlString += ",";
                sqlString += "'" + g_jqxbd_result + "'";
                sqlString += ",";
                sqlString += "'" + to_string(g_device_ID) + "'";
                sqlString += ")";
                DATA_PRINT(LEVEL_DEBUG, "Insert into suzhou_dzbd for MASTER, data: %s \n", sqlString.c_str());
                db_dzbd.insert("suzhou_dzbd", sqlString.c_str());
                db_dzbd.disconnect();
                }
            else {
                DATA_PRINT(LEVEL_DEBUG, "Insert into suzhou_dzbd for MASTER database not connected\n");
            }
        }
    }
    /* 苏州电子环保单审核结果获取解析 */
    if (g_CheckItem.City == SUZHOU) {
//        if(g_CheckItem.picture.WeiQiJianYan.DianZiBaoGao)
//        {
            SUZHOU_DianZiHuanBaoDan(v_vehicle_inf);
//        }
    }
    /*finish*/

    //        for (unsigned int i = 0; i < v_vehicle_inf->m_zplist.size(); i++)
    //        {
    //            HttpClient RequestPhoto;
    //            std::string photourl;
    //            photourl = WstringToString(v_vehicle_inf->m_zplist[i].zpurl);
    //            if (1)
    //            {
    //                if (RequestPhoto.InitData(photourl.c_str(), REQUEST_GET_FLAG, NULL, NULL))
    //                {
    //                   RequestPhoto.m_photo_fileid = v_vehicle_inf->m_zplist[i].zptype + L"_" + v_vehicle_inf->m_hphm + L"_" + v_vehicle_inf->m_clsbdh;
    //                    RequestPhoto.startHttpClient(); //下载照片
    //                    v_vehicle_inf->m_zplist[i].zpid = RequestPhoto.m_photo_fileid;
    //                    v_vehicle_inf->m_zplist[i].local_path = RequestPhoto.m_photo_filename;
    //    #ifdef DEMO_TEST
    //                    v_vehicle_inf->m_zplist[i].demo_local_path = RequestPhoto.m_demo_filename;
    //    #endif
    //                }
    //            }
    //        }

    /* 宁波电子交强险保单审核结果获取解析 */
    if((g_CheckItem.City == NINGBO)&&(!g_TestMode))
    {
        NINGBO_DZBD(v_vehicle_inf);
    }

    if ((!g_strdzbdjkxlh.empty()) && (!g_TestMode)) // 电子保单开启条件：1. 接口序列号不为空  2. 非测试模式
    {
        DATA_PRINT(LEVEL_INFO, "open dzbd interface.\n");
        getDzbdInformation(v_vehicle_inf);
    }

    /* 多线程下载图片 */
    {
        std::thread *DownloadPic_Thread;
        BlockingQueue<PictureResult> DownloadPic_Queue;
        int ResultCnt = v_vehicle_inf->m_zplist.size(); /* 苏州获取的历史照片会加入m_zplist，所以ResultCnt要在此提前获取m_zplist的大小 */

        for (unsigned int i = 0; i < v_vehicle_inf->m_zplist.size(); i++) {
            PictureInfo *picture = new PictureInfo();
            picture->number = i;
            picture->photo_fileid = addPhotoName(v_vehicle_inf, i);
            picture->photourl = v_vehicle_inf->m_zplist[i].zpurl;
            picture->queue = &DownloadPic_Queue;

            try {
                DownloadPic_Thread = new std::thread(downloadPicture, picture);
                DownloadPic_Thread->detach();
                delete DownloadPic_Thread;
            } catch (const std::system_error& e) {
                DATA_PRINT(LEVEL_ERROR, "Download picture create new thread failure! \n");
                std::cout << "Error code: " << e.code() << ", reason: " << e.what() << std::endl;
            }
        }

        if (!g_TestMode) {
            if (g_CheckItem.picture.CheJiaHao.BaoDing_FTP) {
                BaoDing_FTP_Download(v_vehicle_inf);
            }
        }

        if((g_CheckItem.dlvideo.dlflag)&&(v_vehicle_inf->is_video_check)&&(BINZHOU!=g_CheckItem.City))
        {
        if(g_CheckItem.City == YICHUN)
            {
                Video_Download(v_vehicle_inf);
            }
            else
            {
                /* 视频下载 */
               DATA_PRINT(LEVEL_INFO, "start video download  ............... \n");
               struct stat st_buf = {};
               stat(g_videoFilePath.c_str(), &st_buf);
               if ((st_buf.st_mode & S_IFMT) != S_IFDIR) {
                   mkdir(g_videoFilePath.c_str(), 0777);
                   DATA_PRINT(LEVEL_INFO, "生成视频文件夹 ............... \n");
               }
               string video_datapath;
               video_datapath = g_videoFilePath;
               std::time_t t = std::time(NULL);
               std::tm *st = std::localtime(&t);
               char tmpArray[128] = { 0 };
               sprintf(tmpArray, "%d-%02d-%02d", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);
               std::string strCurTime = tmpArray;
               video_datapath+=strCurTime;
               video_datapath+="/";
               struct stat st_buf1;
               memset(&st_buf1,0,sizeof(st_buf1));
               stat(video_datapath.c_str(), &st_buf1);
               if ((st_buf1.st_mode & S_IFMT) != S_IFDIR) {
                   mkdir(video_datapath.c_str(), 0777);
                   DATA_PRINT(LEVEL_INFO, "生成视频当前日期文件夹 ............... \n");
               }
               for (unsigned int j = 0; j< v_vehicle_inf->m_splist.size() ;j++)
               {
                   v_vehicle_inf->m_splist[j].name =  v_vehicle_inf->m_splist[j].spzl + "_";
                   v_vehicle_inf->m_splist[j].name += v_vehicle_inf->m_hphm;
                   v_vehicle_inf->m_splist[j].name += "_" + v_vehicle_inf->m_clsbdh;
                   if(v_vehicle_inf->m_splist[j].spurl.find(".mp4") != string::npos)
                   {
                       v_vehicle_inf->m_splist[j].name += ".mp4";
                   }
                   else if(v_vehicle_inf->m_splist[j].spurl.find(".flv") != string::npos)
                   {
                       v_vehicle_inf->m_splist[j].name += ".flv";
                   }
                   else if(v_vehicle_inf->m_splist[j].spurl.find(".avi") != string::npos)
                   {
                       v_vehicle_inf->m_splist[j].name += ".avi";
                   }
                   else
                   {
                       v_vehicle_inf->m_splist[j].name ="";
                   }
                   v_vehicle_inf->m_splist[j].local_path = video_datapath ;
                   v_vehicle_inf->m_splist[j].local_path += v_vehicle_inf->m_splist[j].name;
                  FtpClient ftpc;
                  if(ftpc.ftpdownload(v_vehicle_inf->m_splist[j].spurl ,v_vehicle_inf->m_splist[j].local_path))
                  {
                      video_count++;
                  }
               }
            }

        }
        /* 为提高下载时间利用率，请将获取其它类型车辆信息(主要是可能耗时的操作，例如网络通信，访问数据库等)放在此处 */
        {
            if (g_CheckItem.City == BAODING) {  /* 获取“保定”仪器检测电子数据和检验报告电子数据 */
                BaoDing_JYBG(v_vehicle_inf);
            }

            if (g_CheckItem.City == NINGBO) {
                NINGBO_BLACKLIST(v_vehicle_inf);
            }

            if (g_CheckItem.City == SUZHOU) {
                getHistoryPhoto(v_vehicle_inf);
            }

            if (g_CheckItem.City == LINYI) {
                getInsuranceResult(v_vehicle_inf);
            }

            if (g_CheckItem.City == TIANJIN){
                if(g_CheckItem.picture.XingShiZheng.TianJin)
                {
                    TIANJIN_OracleDate(v_vehicle_inf);
                }

            }
            if(isWorkTime())
            {
                if( (g_CheckItem.City == YICHUN) && (g_CheckItem.dlvideo.shizhongshenheflag))
                {
                    YICHUN_VideoCheckSerch(v_vehicle_inf);
                    if(v_vehicle_inf->is_video_check_shizhong)
                    {
                        Video_Download(v_vehicle_inf);
                    }

                }
            }

        }

        /* 轮询阻塞等待所有下载线程结束 */
        PictureResult result;
        while (ResultCnt != 0) {
            result = DownloadPic_Queue.Take();
            if (result.ok) {
                v_vehicle_inf->m_zplist[result.number].zpid = result.info.zpid;
                v_vehicle_inf->m_zplist[result.number].local_path = result.info.local_path;
#ifdef DEMO_TEST
                v_vehicle_inf->m_zplist[result.number].demo_local_path = result.info.demo_local_path;
#endif
            }

            ResultCnt--;
        }
    }

    v_vehicle_inf->timeRecord.endTime();
    v_vehicle_inf->timeRecord.picture.AllDownload = v_vehicle_inf->timeRecord.getTime();

    for (unsigned int i = 0; i < v_vehicle_inf->m_ckdbzplist.size(); i++)
    {
        HttpClient RequestPhoto;
        std::string photourl;
        photourl = v_vehicle_inf->m_ckdbzplist[i].zpurl;

        if (RequestPhoto.InitData(photourl.c_str(), REQUEST_GET_FLAG, NULL, NULL))
        {
            RequestPhoto.startHttpClient(); //下载照片
            v_vehicle_inf->m_ckdbzplist[i].zpid = RequestPhoto.m_photo_fileid;
            v_vehicle_inf->m_ckdbzplist[i].local_path = RequestPhoto.m_photo_filename;
#ifdef DEMO_TEST
            v_vehicle_inf->m_ckdbzplist[i].demo_local_path = RequestPhoto.m_demo_filename;
#endif
        }
    }


//    for (unsigned int i = 0; i < v_vehicle_inf->m_splist.size(); i++)
//    {
//        HttpClient RequestVedio;
//        std::string vediourl;
//        if (vedio_dwl_data == NULL)
//        {
//            vedio_dwl_data = new(_vedio_dwl_data);
//            vedio_dwl_data->down_num = 0;
//            vedio_dwl_data->pvehicle_inf = v_vehicle_inf;
//        }

//        vediourl = v_vehicle_inf->m_splist[i].spurl;

//        if (v_vehicle_inf->m_splist[i].dzzl == "http")
//        {
//            vedio_dwl_data->down_num++;
//            if (RequestVedio.InitData(vediourl.c_str(), REQUEST_GET_FLAG, NULL, NULL))
//            {
//                RequestVedio.startHttpClient(); //下载视频
//                v_vehicle_inf->m_splist[i].local_path = RequestVedio.m_photo_filename;
//            }
//#ifdef DEMO_TEST
//            v_vehicle_inf->m_splist[i].demo_local_path = RequestVedio.m_demo_filename;
//#endif
//            vedio_dwl_data->down_num--;//need sempro next
//        }


//#ifndef NO_NVR
//        else if (v_vehicle_inf->m_splist[i].dzzl == "rtsp")
//        {
//            vedio_dwl_data->down_num++;
//            vedio_dwl_data->index = i;
//            if (1)//if(!Start_RTSP_request(vediourl.GetString(), vedio_dwl_data))
//            {
//                vedio_dwl_data->down_num--;//need sempro next
//                DATA_PRINT(LEVEL_DATA, " ..............One rtsp video request ignored\n ");
//            }
//            else
//                DATA_PRINT(LEVEL_DATA, " ..............One rtsp video request done\n ");
//        }
//        else if (v_vehicle_inf->m_splist[i].dzzl == "nvr")
//        {
//            vedio_dwl_data->down_num++;
//            vedio_dwl_data->index = i;
//            if (!Start_NVR_request(vediourl.GetString(), vedio_dwl_data))
//            {
//                vedio_dwl_data->down_num--;//need sempro next
//                DATA_PRINT(LEVEL_DATA, " ..............One NVR video request ignored\n ");
//            }
//            else
//                DATA_PRINT(LEVEL_DATA, " ..............One NVR video request done\n ");
//        }
//#endif
//    }

    if (vedio_dwl_data == NULL) //no video
    {
        if (v_vehicle_inf) {
            v_vehicle_inf->timeRecord.startTime();
            toanalyse_queue.Put(v_vehicle_inf); // photo完成下载，插入处理队列,无视频下载
        }
    }
    else if (video_count != 0)
    {
        if (v_vehicle_inf) {
            v_vehicle_inf->timeRecord.startTime();
            toanalyse_queue.Put(v_vehicle_inf); // photo/视频完成下载，插入处理队列
        }

    }

    DownloadThreadCount.Take();
    return;
}

std::string Prepare_SoapXml_Data(vehicle_inf * pvehicle_inf, UINT index)
{
    CMarkup xml;

    xml.SetDoc("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n");
    xml.AddElem("root");
    xml.IntoElem();
    setlocale(LC_ALL, "chs");

    xml.AddElem("vehispara");
    xml.AddChildElem("lsh");
    xml.SetChildData(pvehicle_inf->m_jylsh);
    xml.AddChildElem("zpzl");
    xml.SetChildData(pvehicle_inf->m_dbbhglist[index].zptype);
    xml.AddChildElem("jg");
    xml.SetChildData(pvehicle_inf->m_dbbhglist[index].dbresult);

    xml.AddChildElem("sm");
    std::string smcstr = pvehicle_inf->m_dbbhglist[index].dbbhg_desc;
    smcstr = ANSItoUTF8((char *)smcstr.c_str());
    std::string smstr = smcstr;
    smstr = URLEncode(smstr.c_str());
    smcstr = smstr.c_str();
    xml.SetChildData(smcstr);

    xml.OutOfElem();
    std::string xmlstring;
    xmlstring = xml.GetDoc();
    return xmlstring;
}

std::string Prepare_Xml_Data(vehicle_inf * pvehicle_inf)
{
    CMarkup xml;

    xml.SetDoc("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n");
    xml.AddElem("root");
    xml.IntoElem();
    xml.AddElem("vehispara");
    xml.IntoElem();
    setlocale(LC_ALL, "chs");

    DATA_PRINT(LEVEL_DEBUG, "[创建]\n");
    for (unsigned int i = 0; i < pvehicle_inf->item_description.size(); i++)
    {
        DATA_PRINT(LEVEL_DEBUG,"%d: %s", i, pvehicle_inf->item_description[i].name_tag);
        if (strcmp(pvehicle_inf->item_description[i].name_tag , "dbbhglist")==0)
        {
            xml.AddElem("dbbhglist");
            xml.IntoElem();
            for (unsigned int j = 0; j<pvehicle_inf->m_dbbhglist.size(); j++)
            {
                xml.AddElem("item");
                xml.AddChildElem("zpzl");
                xml.SetChildData(pvehicle_inf->m_dbbhglist[j].zptype);
                xml.AddChildElem("sm");
                xml.SetChildData(pvehicle_inf->m_dbbhglist[j].dbbhg_desc);
                xml.AddChildElem("jg");
                xml.SetChildData(pvehicle_inf->m_dbbhglist[j].dbresult);
                xml.AddChildElem("zpid");
                xml.SetChildData(pvehicle_inf->m_dbbhglist[j].zpid);
            }

            DATA_PRINT(LEVEL_DEBUG, "\n");

            for (unsigned int k = 0; k<pvehicle_inf->m_dbbhglist.size(); k++) {
                DATA_PRINT(LEVEL_DEBUG, "[type=%s sm=%s jg=%s]\n",
                           pvehicle_inf->m_dbbhglist[k].zptype.c_str(),
                           pvehicle_inf->m_dbbhglist[k].dbbhg_desc.c_str(),
                           pvehicle_inf->m_dbbhglist[k].dbresult.c_str());
            }

            xml.OutOfElem();
        }
        else if (strcmp(pvehicle_inf->item_description[i].name_tag , "zplist")==0)
        {
            xml.AddElem("zplist");
            xml.IntoElem();
            for (unsigned int j = 0; j<pvehicle_inf->m_zplist.size(); j++)
            {
                xml.AddElem("item");
                xml.AddChildElem("zpzl");
                xml.SetChildData(pvehicle_inf->m_zplist[j].zptype);
                xml.AddChildElem("zpurl");
                xml.SetChildData(pvehicle_inf->m_zplist[j].zpurl);
#ifdef DEMO_TEST
                xml.AddChildElem("localfile");
                std::string demofile = pvehicle_inf->m_zplist[j].demo_local_path + "_1.jpg";

                if (access(demofile.c_str(), 00) == 0)
                    xml.SetChildData(demofile);
                else
                    xml.SetChildData(pvehicle_inf->m_zplist[j].local_path);
#endif
            }

            DATA_PRINT(LEVEL_DEBUG, "\n");

            for (unsigned int k = 0; k<pvehicle_inf->m_zplist.size(); k++) {
                DATA_PRINT(LEVEL_DEBUG, "[zptype=%s url=%s loc=%s]\n",
                           pvehicle_inf->m_zplist[k].zptype.c_str(),
                           pvehicle_inf->m_zplist[k].zpurl.c_str(),
                           pvehicle_inf->m_zplist[k].local_path.c_str());
            }

            xml.OutOfElem();
        }
        else if (strcmp(pvehicle_inf->item_description[i].name_tag, "splist") == 0)
        {
            xml.AddElem("splist");
            xml.IntoElem();
            for (unsigned int j = 0; j<pvehicle_inf->m_splist.size(); j++)
            {
                xml.AddElem("item");
                xml.AddChildElem("sptype");
                xml.SetChildData(pvehicle_inf->m_splist[j].sptype);
                xml.AddChildElem("dzzl");
                xml.SetChildData(pvehicle_inf->m_splist[j].dzzl);
                xml.AddChildElem("id");
                xml.SetChildData(pvehicle_inf->m_splist[j].id);
                xml.AddChildElem("spzl");
                xml.SetChildData(pvehicle_inf->m_splist[j].spzl);
                xml.AddChildElem("spurl");
                xml.SetChildData(pvehicle_inf->m_splist[j].spurl);
//                if (pvehicle_inf->m_splist[j].dzzl == "nvr")
//                    xml.AddChildSubDoc(pvehicle_inf->m_splist[j].spurl);
//                else
//                {
//                    xml.AddChildElem("spurl");
//                    xml.SetChildData(pvehicle_inf->m_splist[j].spurl);
//                }
#ifdef DEMO_TEST
                xml.AddChildElem("localfile");
                std::string demofile = pvehicle_inf->m_splist[j].demo_local_path + "_1.jpg";

                //CFileFind f_file;
                if (1)//(f_file.FindFile(demofile, 0))
                    xml.SetChildData(demofile);
                else
                    xml.SetChildData(pvehicle_inf->m_splist[j].local_path);
#endif
            }

            DATA_PRINT(LEVEL_DEBUG, "\n");

            for (unsigned int k = 0; k<pvehicle_inf->m_splist.size(); k++) {
                DATA_PRINT(LEVEL_DEBUG, "[sptype=%s dzzl=%s url=%s loc=%s]\n",
                           pvehicle_inf->m_splist[k].sptype.c_str(),
                           pvehicle_inf->m_splist[k].dzzl.c_str(),
                           pvehicle_inf->m_splist[k].spurl.c_str(),
                           pvehicle_inf->m_splist[k].local_path.c_str());
            }

            xml.OutOfElem();
        }
        else if (strcmp(pvehicle_inf->item_description[i].name_tag , "ckdbzplist")==0)
        {
            xml.AddElem("ckdbzplist");
            xml.IntoElem();
            for (unsigned int j = 0; j<pvehicle_inf->m_ckdbzplist.size(); j++)
            {
                xml.AddElem("item");
                xml.AddChildElem("zpzl");
                xml.SetChildData(pvehicle_inf->m_ckdbzplist[j].zptype);
                xml.AddChildElem("zpurl");
                xml.SetChildData(pvehicle_inf->m_ckdbzplist[j].zpurl);
            }

            DATA_PRINT(LEVEL_DEBUG, "\n");

            for (unsigned int k = 0; k<pvehicle_inf->m_ckdbzplist.size(); k++) {
                DATA_PRINT(LEVEL_DEBUG, "[ckzptype=%s url=%s loc=%s]\n",
                           pvehicle_inf->m_ckdbzplist[k].zptype.c_str(),
                           pvehicle_inf->m_ckdbzplist[k].zpurl.c_str(),
                           pvehicle_inf->m_ckdbzplist[k].local_path.c_str());
            }

            xml.OutOfElem();
        }
        else  //other basic inf:
        {
            std::string value;
            std::string basictag = pvehicle_inf->item_description[i].name_tag;
            value = *(std::string *)(pvehicle_inf->item_description[i].value);
            xml.AddElem(basictag);
            xml.SetData(value);
            DATA_PRINT(LEVEL_DEBUG, " %s=%s\n", pvehicle_inf->item_description[i].name_desc,
                       (*(std::string *)(pvehicle_inf->item_description[i].value)).c_str());
        }
        //离线视频审核标记，传入后将进行视频处理
        if(pvehicle_inf->is_video_check)
        {
            xml.AddElem("video_check");
            xml.SetData("1");
        }

        xml.ResetChildPos();
    }
    std::string xmlstring;
    xmlstring = xml.GetDoc();
    return xmlstring;
}

std::string Prepare_Soap_Data(char* xmldata)
{
    CMarkup xml;

    xml.SetDoc("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n");
    xml.AddElem("soap:Envelope");
    xml.SetAttrib("xmlns:soap", "http://schemas.xmlsoap.org/soap/envelope/");
    xml.SetAttrib("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
    xml.SetAttrib("xmlns:xsd", "http://www.w3.org/2001/XMLSchema");
    xml.IntoElem();
    xml.AddElem("soap:Body");
    xml.IntoElem();
    xml.AddElem("writeObjectOut");
    xml.SetAttrib("xmlns", "http://tempuri.org/");
    xml.IntoElem();
    xml.AddElem("jkxlh", g_confJkxlh);
    xml.AddElem("xmlDoc");
    xml.SetData(xmldata);

    std::string xmlstring;
    xmlstring = xml.GetDoc();
    return xmlstring;
}
bool MyGetDiskFreeSpace(std::string path, unsigned long long& freeSpace)
{
    bool fResult = false;
    struct statfs diskInfo = {};
    if(0 == statfs(path.c_str(), &diskInfo))
    {
        unsigned long long blocksize = diskInfo.f_bsize;
        freeSpace = diskInfo.f_bavail * blocksize;
        fResult=true;
    }
    return fResult;
}

bool GetFolders(std::string folder, std::vector<std::string>& paths, std::vector<std::string>& names)
{
    struct stat s;
    lstat( folder.c_str() , &s );
    if( ! S_ISDIR( s.st_mode ) )
        return false;

    struct dirent* filename;    // return value for readdir()
    DIR* dir;                   // return value for opendir()
    dir = opendir( folder.c_str() );
    if( NULL == dir )
        return false;
    while( ( filename = readdir(dir) ) != NULL )
    {
        // get rid of "." and ".."
        if( std::string(filename->d_name)[0] == '.')
            continue;
        char filePath[256]={0};
        if(folder[folder.size()-1] == '/')
            sprintf(filePath,"%s%s",folder.c_str(),filename->d_name);
        else
            sprintf(filePath,"%s/%s",folder.c_str(),filename->d_name);
        lstat( filePath , &s );
        if( S_ISDIR( s.st_mode ) )
        {
            paths.push_back(filePath);
            names.push_back(filename ->d_name);
        }
        else
            continue;
    }

    closedir(dir);

    return true;
}
void DB_BackUpThread()
{
    while (true) {
        std::time_t t = std::time(NULL);
        std::tm *st = std::localtime(&t);

        if (st->tm_hour == 23) {
            bool DB_IsEmpty = false;

            /* 组合导出表vehicle_checks的命令 */
            std::string cmd = "mysqldump -u root -p"+getDBPassWord(DBPWD)+" car_schema vehicle_checks --where=";
            char tmpArray[128] = { 0 };
            sprintf(tmpArray, "%d-%02d-%02d", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);
            std::string time = tmpArray;
            std::string FileName = "vehicle_" + time + ".sql";
            time += " 00:00:00";
            cmd += "\"created_at >= \'" + time + "\'\"";
            cmd += " > " + g_photoFilePath + FileName;

            /* 组合导出表check_infos的命令 */
            {
                cmd += " && ";
                cmd += "mysqldump -u root -p"+getDBPassWord(DBPWD)+" car_schema check_infos --where=";

                /* 查出vehicle_checks当天第一条数据的id */
                MySQL_DB db;
                if (db.connect(NULL, 6033, "root", getDBPassWord(DBPWD).c_str(), "car_schema")) {
                    std::string SqlStatement = "SELECT id,created_at FROM vehicle_checks WHERE created_at >= \"" + time + "\"";
                    DATA_PRINT(LEVEL_INFO, "SqlStatement:%s \n",SqlStatement.c_str());
                    MYSQL_RES *result = db.getResult(SqlStatement.c_str());
                    if (result != NULL) {
                        MYSQL_ROW row = NULL;
                        row = mysql_fetch_row(result);
                        if (row != NULL) {
                            std::string id = row[0];
                            cmd += "\"vehicle_check_id >= " + id + "\"";
                        } else {
                            DB_IsEmpty = true;
                        }

                        db.freeResult(result);
                    }
                }
                db.disconnect();

                cmd += " >> " + g_photoFilePath + FileName;
            }

            if (DB_IsEmpty) {
                DATA_PRINT(LEVEL_INFO, "There is no new data today and no backup is required. \n");
            } else {
                DATA_PRINT(LEVEL_INFO, "Execute backup database \n");
                std::system(cmd.c_str());
            }

            if (g_CheckItem.picture.CheJiaHao.BaoDing_FTP) {
                BaoDing_ClearFtpPic();
            }

            //增加磁盘定时删除功能
            {
                std::string photoFilePath = g_photoFilePath;
                std::string videoFilePath = g_videoFilePath;
                std::vector<std::string> paths, names;
                GetFolders(photoFilePath, paths, names);
                for (unsigned int i = 0; i < paths.size(); i++)
                {
                    int year, month, day;
                    sscanf(names[i].c_str(), "%d-%d-%d", &year, &month, &day);
                    std::time_t t = std::time(NULL);
                    std::tm*st = std::localtime(&t);
                    unsigned long long fileTotalDay = year * 365 + month * 30 + day;
                    unsigned long long nowTotalDay = (st->tm_year+1900) * 365 + (st->tm_mon+1) * 30 + st->tm_mday;
                    unsigned long long g_photoKeepMonths30 = (unsigned long long)g_photoKeepMonths * 30;
                    if (nowTotalDay - fileTotalDay > g_photoKeepMonths30)
                    {
                        std::string _cmd = "rm -rf " + paths[i];
                        system(_cmd.c_str());
                        DATA_PRINT(LEVEL_INFO, "delete photo director 1: [%s] \n", _cmd.c_str());
                    }
                }
                paths.clear(); names.clear();
                GetFolders(videoFilePath, paths, names);
                for (unsigned int i = 0; i < paths.size(); i++)
                {
                    int year, month, day;
                    sscanf(names[i].c_str(), "%d-%d-%d", &year, &month, &day);
                    std::time_t t = std::time(NULL);
                    std::tm *st = std::localtime(&t);
                    unsigned long long fileTotalDay = year * 365 + month * 30 + day;
                    unsigned long long nowTotalDay = (st->tm_year+1900) * 365 + (st->tm_mon+1) * 30 + st->tm_mday;
                    unsigned long long g_videoKeepDays_ = (unsigned long long)g_videoKeepDays;
                    if (nowTotalDay - fileTotalDay > g_videoKeepDays_)
                    {
                        std::string _cmd = "rm -rf " + paths[i];
                        system(_cmd.c_str());
                        DATA_PRINT(LEVEL_INFO, "delete video director 2: [%s] \n", _cmd.c_str());
                    }
                }
                unsigned long long freeSpace;
                while (MyGetDiskFreeSpace(photoFilePath, freeSpace))
                {
                    int G = (int)(freeSpace / (1024 * 1024 * 1024));
                    if (G > g_diskPreserveSizeG)
                        break;
                    paths.clear(); names.clear();
                    GetFolders(videoFilePath, paths, names);
                    GetFolders(photoFilePath, paths, names);
                    std::vector<std::string> waitPaths;
                    for (unsigned int i = 0; i < paths.size(); i++)
                    {
                        int year, month, day;
                        sscanf(names[i].c_str(), "%d-%d-%d", &year, &month, &day);
                        std::time_t t = std::time(NULL);
                        std::tm *st = std::localtime(&t);
                        if (year == (st->tm_year+1900) && month == (st->tm_mon+1) && day == st->tm_mday)
                            continue;
                        else
                            waitPaths.push_back(paths[i]);
                    }
                    if (waitPaths.size() <= 0)
                        break;
                    std::string _cmd = "rm -rf " + waitPaths[0];
                    system(_cmd.c_str());
                    DATA_PRINT(LEVEL_INFO, "delete photo and video director 3: [%s] \n", _cmd.c_str());
                }
            }
#ifdef DEMO_TEST	/* 清理DEMO图片文件夹 */
            //            int day = st->tm_mday - 15;	/* 保留最近15天的照片 */
            //			int month;
            //			int year;
            //			if (day <= 0) {
            //				day = 31 + day;		/* 每个月都按31天计算 */

            //                month = st->tm_mon + 1 - 1;

            //				if (month == 0) {
            //					month = 12;
            //                    year = st->tm_year + 1900 - 1;
            //				} else {
            //                    year = st->tm_year + 1900;
            //				}
            //			} else {
            //                month = st->tm_mon + 1;
            //                year = st->tm_year + 1900;
            //			}

            //			std::string tmp = g_demo_path;
            //			std::vector<std::string> files = getFiles(tmp);

            //			for (int i = 0; i < files.size(); i++) {
            //				bool NeedDelete = false;

            //				int FileYear = std::stoi(files[i].substr(0, 4));
            //				int FileMonth = std::stoi(files[i].substr(5, 2));
            //				int FileDay = std::stoi(files[i].substr(8, 2));

            //				if (FileYear < year) {
            //					NeedDelete = true;
            //				} else if (FileYear == year) {
            //					if (FileMonth < month) {
            //						NeedDelete = true;
            //					} else if (FileMonth == month) {
            //						if (FileDay <= day) {
            //							NeedDelete = true;
            //						}
            //					}
            //				}

            //				if (NeedDelete) {
            //					deleteDirectory(tmp + files[i]);
            //				}
            //			}
#endif

            std::this_thread::sleep_for(std::chrono::minutes(35));	/* 35 min(休眠防止同一小时再次进行备份操作) */
        }

        std::this_thread::sleep_for(std::chrono::minutes(30));	/* 30 min */
    }
}


void DB_Video_Thread()
{
    while(true)
    {
        if(0==video_queue.Size())
        {
           std::this_thread::sleep_for(std::chrono::seconds(6));
        }
        else
        {
            std::this_thread::sleep_for(std::chrono::seconds(6));
            video_inf * v_video_inf=NULL;
            v_video_inf=video_queue.Take();
            MySQL_DB db ;
            if(db.connect(g_master_IP.c_str(),6033,"root",getDBPassWord(DBPWD).c_str(),"car_schema"))
            {
                std::string v_data_String;
                std::string v_rear_data;
                std::string sqlString;
                v_data_String="("
                              "jylsh, jyjgbh, hphm, clsbdh, cllx, spzl, spurl, jcxbh, sxtbh, sjks, sjjs, check_flag"
                              ")"
                              " VALUES "
                              "(";
                v_data_String += "'" + v_video_inf->v_jylsh + "'";
                v_data_String += ",";
                v_data_String += "'" + v_video_inf->v_jyjgbh + "'";
                v_data_String += ",";
                v_data_String += "'" + v_video_inf->v_hphm + "'";
                v_data_String += ",";
                v_data_String += "'" + v_video_inf->v_clsbdh + "'";
                v_data_String += ",";
                v_data_String += "'" + v_video_inf->v_cllx + "'";
                v_data_String += ",";
                for (unsigned int i = 0; i < v_video_inf->v_splist.size(); i++)
                {
                    v_rear_data.empty();
                    v_rear_data = "'" + v_video_inf->v_splist[i].spzl + "'";
                    v_rear_data += ",";
                    v_rear_data += "'" + v_video_inf->v_splist[i].spurl + "'";
                    v_rear_data += ",";
                    v_rear_data += "' '";
                    v_rear_data += ",";
                    v_rear_data += "' '";
                    v_rear_data += ",";
                    v_rear_data += "' '";
                    v_rear_data += ",";
                    v_rear_data += "' '";
                    v_rear_data += ",";
                    v_rear_data += "'0'";
                    v_rear_data += ")";
                    sqlString = v_data_String + v_rear_data;
                    DATA_PRINT(LEVEL_DEBUG, "Insert into check_video_infos, data: %s \n", sqlString.c_str());
                    db.insert("check_video_infos", sqlString.c_str());
                }
            }
            db.disconnect();
            delete v_video_inf;
            v_video_inf = NULL;
        }
    }
}


/* 删除dir目录下所有文件（不包括文件夹），然后删除dir目录自身。不会递归查找子目录 */
void deleteDirectory(std::string dir)
{
    std::system((std::string("rm -rf ") + dir).c_str());
}

///* 获取dir目录下所有文件（包括文件夹）的文件名，不会递归查找子目录 */
//std::vector<std::string> getFiles(std::string dir)
//{
//	dir += "\\*";

//	_finddata_t file;
//	long lf;
//	std::vector<std::string> files;

//	if ((lf = _findfirst(dir.c_str(), &file)) != -1) {
//		do {
//			if ((strcmp(file.name, ".") == 0) || (strcmp(file.name, "..") == 0)) {
//				continue;
//			}

//			files.push_back(file.name);
//		} while (_findnext(lf, &file) == 0);

//		_findclose(lf);
//	}

//	return files;
//}

std::string PrepareXmlData(vehicle_inf* pVehicle_info)
{

    CMarkup xml;
    xml.SetDoc("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n");
    xml.AddElem("root");
    xml.IntoElem();
    xml.AddElem("code");
    xml.SetData(PHOTO_PROCESS_RESULT);
    xml.AddElem("vehicle");
    xml.IntoElem();
    for(unsigned int i = 0; i < pVehicle_info->item_description.size(); i++)
    {
        if( strcmp(pVehicle_info->item_description[i].name_tag,"ckdbzplist") != 0 &&
            strcmp(pVehicle_info->item_description[i].name_tag,"zplist") != 0 &&
            strcmp(pVehicle_info->item_description[i].name_tag,"splist") != 0 &&
            strcmp(pVehicle_info->item_description[i].name_tag,"dbbhglist") !=0 )
        {
            std::string vehicle_type = pVehicle_info->item_description[i].name_tag;
            std::string value = *static_cast<std::string*>(pVehicle_info->item_description[i].value);
            xml.AddElem(vehicle_type);
            xml.SetData(value);
            DATA_PRINT(LEVEL_INFO,"%s:%s\n",vehicle_type.c_str(),value.c_str());
        }

    }
    xml.OutOfElem();
    xml.AddElem("zplist");
    xml.IntoElem();
    for(unsigned int i = 0;i < pVehicle_info->m_zplist.size();i++)
    {
        xml.AddElem("item");
        xml.AddChildElem("zpzl");
        xml.SetChildData(pVehicle_info->m_zplist[i].zptype);
        //xml.AddChildElem("jg");
        //xml.SetChildData(pVehicle_info->photo_list[i].result);
        xml.AddChildElem("id");
        xml.SetChildData(pVehicle_info->m_zplist[i].zpid);
        xml.AddChildElem("uri");
        xml.SetChildData(pVehicle_info->m_zplist[i].zpurl);
        xml.AddChildElem("local_path");
        xml.SetChildData(pVehicle_info->m_zplist[i].local_path);
    }
    xml.OutOfElem();
    xml.AddElem("bhglist");
    xml.IntoElem();
    for(unsigned int count = 0;count < pVehicle_info->m_dbbhglist.size();count++)
    {
        xml.AddElem("item");
        xml.AddChildElem("id");
        xml.SetChildData(pVehicle_info->m_dbbhglist[count].zpid);
        xml.AddChildElem("zpzl");
        xml.SetChildData(pVehicle_info->m_dbbhglist[count].zptype);
        xml.AddChildElem("result");
        xml.SetChildData(pVehicle_info->m_dbbhglist[count].dbresult);
        xml.AddChildElem("reason");
        xml.SetChildData(pVehicle_info->m_dbbhglist[count].dbbhg_desc);
    }
    xml.OutOfElem();

    xml.AddElem("timeinfo");
    xml.IntoElem();
    xml.AddElem("start_total");
    xml.SetData(to_string(pVehicle_info->timeRecord.start_total_time));
    xml.AddElem("total_no_wait");
    xml.SetData(pVehicle_info->timeRecord.total_no_wait);
    DATA_PRINT(LEVEL_INFO,"send total_no_wait is %s\n", pVehicle_info->timeRecord.total_no_wait.c_str());
    xml.AddElem("wait_queue");
    xml.SetData(pVehicle_info->timeRecord.wait_queue);
    DATA_PRINT(LEVEL_INFO,"send wait_queue is %s\n", pVehicle_info->timeRecord.wait_queue.c_str());
    xml.OutOfElem();

    xml.AddElem("picturetime");
    xml.IntoElem();
    xml.AddElem("alldownload");
    xml.SetData(pVehicle_info->timeRecord.picture.AllDownload);
    xml.AddElem("zf");
    xml.SetData(pVehicle_info->timeRecord.picture.process.zf);
    xml.AddElem("abs");
    xml.SetData(pVehicle_info->timeRecord.picture.process.abs);
    xml.AddElem("aqd");
    xml.SetData(pVehicle_info->timeRecord.picture.process.aqd);
    xml.AddElem("cjh");
    xml.SetData(pVehicle_info->timeRecord.picture.process.cjh);
    xml.AddElem("hhp");
    xml.SetData(pVehicle_info->timeRecord.picture.process.hhp);
    xml.AddElem("jly");
    xml.SetData(pVehicle_info->timeRecord.picture.process.jly);
    xml.AddElem("jqx");
    xml.SetData(pVehicle_info->timeRecord.picture.process.jqx);
    xml.AddElem("mhq");
    xml.SetData(pVehicle_info->timeRecord.picture.process.mhq);
    xml.AddElem("qhp");
    xml.SetData(pVehicle_info->timeRecord.picture.process.qhp);
    xml.AddElem("sfz");
    xml.SetData(pVehicle_info->timeRecord.picture.process.sfz);
    xml.AddElem("sqb");
    xml.SetData(pVehicle_info->timeRecord.picture.process.sqb);
    xml.AddElem("wts");
    xml.SetData(pVehicle_info->timeRecord.picture.process.wts);
    xml.AddElem("xsz");
    xml.SetData(pVehicle_info->timeRecord.picture.process.xsz);
    xml.AddElem("ydg");
    xml.SetData(pVehicle_info->timeRecord.picture.process.ydg);
    xml.AddElem("yhf");
    xml.SetData(pVehicle_info->timeRecord.picture.process.yhf);
    xml.AddElem("yjc");
    xml.SetData(pVehicle_info->timeRecord.picture.process.yjc);
    xml.AddElem("yql");
    xml.SetData(pVehicle_info->timeRecord.picture.process.yql);
    xml.AddElem("zdg");
    xml.SetData(pVehicle_info->timeRecord.picture.process.zdg);
    xml.AddElem("zqf");
    xml.SetData(pVehicle_info->timeRecord.picture.process.zqf);
    xml.AddElem("zql");
    xml.SetData(pVehicle_info->timeRecord.picture.process.zql);
    xml.AddElem("chgw");
    xml.SetData(pVehicle_info->timeRecord.picture.process.chgw);
    xml.AddElem("clbm");
    xml.SetData(pVehicle_info->timeRecord.picture.process.clbm);
    xml.AddElem("clcm");
    xml.SetData(pVehicle_info->timeRecord.picture.process.clcm);
    xml.AddElem("cyjl");
    xml.SetData(pVehicle_info->timeRecord.picture.process.cyjl);
    xml.AddElem("dchp");
    xml.SetData(pVehicle_info->timeRecord.picture.process.dchp);
    xml.AddElem("dchw");
    xml.SetData(pVehicle_info->timeRecord.picture.process.dchw);
    xml.AddElem("dpjy");
    xml.SetData(pVehicle_info->timeRecord.picture.process.dpjy);
    xml.AddElem("ezzd");
    xml.SetData(pVehicle_info->timeRecord.picture.process.ezzd);
    xml.AddElem("fzzd");
    xml.SetData(pVehicle_info->timeRecord.picture.process.fzzd);
    xml.AddElem("hdzk");
    xml.SetData(pVehicle_info->timeRecord.picture.process.hdzk);
    xml.AddElem("jybg");
    xml.SetData(pVehicle_info->timeRecord.picture.process.jybg);
    xml.AddElem("wqjy");
    xml.SetData(pVehicle_info->timeRecord.picture.process.wqjy);
    xml.AddElem("wszm");
    xml.SetData(pVehicle_info->timeRecord.picture.process.wszm);
    xml.AddElem("wxnb");
    xml.SetData(pVehicle_info->timeRecord.picture.process.wxnb);
    xml.AddElem("yzzd");
    xml.SetData(pVehicle_info->timeRecord.picture.process.yzzd);
    xml.AddElem("zczd");
    xml.SetData(pVehicle_info->timeRecord.picture.process.zczd);
    xml.AddElem("cjhcf");
    xml.SetData(pVehicle_info->timeRecord.picture.process.cjhcf);
    xml.AddElem("cjhyj");
    xml.SetData(pVehicle_info->timeRecord.picture.process.cjhyj);
    xml.AddElem("sfzbk");
    xml.SetData(pVehicle_info->timeRecord.picture.process.sfzbk);
    xml.AddElem("wttzs");
    xml.SetData(pVehicle_info->timeRecord.picture.process.wttzs);
    xml.AddElem("xszbk");
    xml.SetData(pVehicle_info->timeRecord.picture.process.xszbk);
    xml.AddElem("yhfcf");
    xml.SetData(pVehicle_info->timeRecord.picture.process.yhfcf);
    xml.AddElem("zqfcf");
    xml.SetData(pVehicle_info->timeRecord.picture.process.zqfcf);
    xml.AddElem("cjhug");
    xml.SetData(pVehicle_info->timeRecord.picture.process.cjh_ug);
    xml.AddElem("dpdtjs");
    xml.SetData(pVehicle_info->timeRecord.picture.process.dpdtjs);
    xml.AddElem("dpdtks");
    xml.SetData(pVehicle_info->timeRecord.picture.process.dpdtks);
    xml.AddElem("jcqxbg");
    xml.SetData(pVehicle_info->timeRecord.picture.process.jcqxbg);
    xml.AddElem("jyb_bk");
    xml.SetData(pVehicle_info->timeRecord.picture.process.jyb_bk);

    xml.AddElem("jyhgzm");
    xml.SetData(pVehicle_info->timeRecord.picture.process.jyhgzm);
    xml.AddElem("chexiang");
    xml.SetData(pVehicle_info->timeRecord.picture.process.chexiang);
    xml.AddElem("waikuocemian");
    xml.SetData(pVehicle_info->timeRecord.picture.process.waikuocemian);
    xml.AddElem("waikuoqianmian");
    xml.SetData(pVehicle_info->timeRecord.picture.process.waikuoqianmian);
    xml.AddElem("isPass");
    xml.SetData(pVehicle_info->m_isPass);
    xml.AddElem("deviceId");
    xml.SetData(pVehicle_info->m_deviceId);
    xml.OutOfElem();


    xml.ResetChildPos();
    std::string xmlstring;
    xmlstring = xml.GetDoc();
    DATA_PRINT(LEVEL_INFO,"Send data is:\n%s\n",xmlstring.c_str());
    return xmlstring;
}
void ReplyMasterThread()
{
    if(g_SlaveCount == -1)
    {
        DATA_PRINT(LEVEL_INFO,"ReplyMasterThread running......\n");
        while (true)
        {
            char uri_buf[256];
            sprintf(uri_buf,"http://%s:%d/SendProcessResult",g_master_IP.c_str(),9000);

            vehicle_inf *p_vehicle_inf = nullptr;
            p_vehicle_inf = reply_master_queue.Take();
            DATA_PRINT(LEVEL_INFO, "Get one check result, lsh is %s \n", p_vehicle_inf->m_jylsh.c_str());
            DATA_PRINT(LEVEL_INFO, "=======================reply_master_queue:%d======================\n", reply_master_queue.Size());

            DATA_PRINT(LEVEL_ERROR, "slave send ispass=%s, hphm=%s\n", p_vehicle_inf->m_isPass.c_str(), p_vehicle_inf->m_hphm.c_str());
            std::string prepare_data = PrepareXmlData(p_vehicle_inf);

            HttpClient reply_master_result;

            if(reply_master_result.InitData(uri_buf,REQUEST_POST_FLAG,HTTP_CONTENT_TYPE_TEXT_XML,const_cast<char*>(prepare_data.c_str())))
            {
                reply_master_result.startHttpClient();
                if(!reply_master_result.d_success_flag)
                {
                    DATA_PRINT(LEVEL_ERROR,"master is no response ...\nReput reply_master_queue...\n");
                    reply_master_queue.RePut(p_vehicle_inf);
                }
                else
                {
                    DATA_PRINT(LEVEL_INFO,"lsh:%s is send to master\n",p_vehicle_inf->m_jylsh.c_str());
                    record_queue.Put(p_vehicle_inf);
                    p_vehicle_inf = nullptr;
                }
            }
        }
    }
}

void ReplyThread()
{
    DATA_PRINT(LEVEL_INFO, "ReplyThread running...... \n");

    while (true) {
        vehicle_inf *p_vehicle_inf = NULL;
        p_vehicle_inf = reply_queue.Take();
        DATA_PRINT(LEVEL_INFO, "Get one check result, lsh is %s \n", p_vehicle_inf->m_jylsh.c_str());
        DATA_PRINT(LEVEL_INFO, "=======================reply_queue:%d======================\n", reply_queue.Size());

        std::string xmldata;

        /* 照片列表为空时，需要回复一个“建议人工”的结果 */
        if (p_vehicle_inf->m_zplist.size() == 0) {
            xmldata = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><vehispara><lsh>";
            xmldata += p_vehicle_inf->m_jylsh;
            xmldata += "</lsh><zpzl>";
            xmldata += "</zpzl><jg>4</jg><sm>no picture</sm></vehispara></root>";

            DATA_PRINT(LEVEL_INFO, "The zplist is empty, writing the check result to SOAP server...... \n");
            sendPhotoResult(p_vehicle_inf, -1, xmldata);
        } else {
            if(g_group_response)
            {
                CMarkup xml;
                xml.SetDoc("<?xml version=\"1.0\" encoding=\"GBK\"?>\r\n");
                xml.AddElem("root");
                xml.IntoElem();
                setlocale(LC_ALL, "chs");
                xml.AddElem("vehispara");
                xml.IntoElem();
                xml.AddElem("lsh");
                xml.SetData(p_vehicle_inf->m_jylsh);
                xml.AddElem("zpshjgs");
                xml.IntoElem();
                for (unsigned int i = 0; i < p_vehicle_inf->m_zplist.size(); i++) {
                    unsigned int j;
                    DATA_PRINT(LEVEL_INFO,"i = %d\n",i);
                    if(p_vehicle_inf->m_zplist[i].zptype.substr(0,1)=="0")
                    {
                        for (j = 0; j < p_vehicle_inf->m_dbbhglist.size(); j++) {
                            DATA_PRINT(LEVEL_INFO,"j = %d\n",j);
                            if (p_vehicle_inf->m_zplist[i].zptype == p_vehicle_inf->m_dbbhglist[j].zptype) {
                                break;
                            }
                        }
                        if (j == p_vehicle_inf->m_dbbhglist.size()) {   /* 照片通过 */
                            xml.AddElem("zpshjg");
                            xml.AddChildElem("zpzl");
                            xml.SetChildData(p_vehicle_inf->m_zplist[i].zptype);
                            xml.AddChildElem("jg");
                            xml.SetChildData("1");
                            xml.AddChildElem("sm");
                            xml.SetChildData("ok");
                        } else {										/* 照片不通过 */
                            xml.AddElem("zpshjg");
                            xml.AddChildElem("zpzl");
                            xml.SetChildData(p_vehicle_inf->m_dbbhglist[j].zptype);
                            xml.AddChildElem("jg");
                            if(p_vehicle_inf->m_dbbhglist[j].dbresult.find("4")==string::npos)
                            {
                                xml.SetChildData(p_vehicle_inf->m_dbbhglist[j].dbresult);
                            }
                            else
                            {
                                xml.SetChildData("0");
                            }
                            xml.AddChildElem("sm");
                            std::string smcstr = p_vehicle_inf->m_dbbhglist[j].dbbhg_desc;
                            smcstr = ANSItoUTF8((char *)smcstr.c_str());
                            std::string smstr = smcstr;
                            smstr = URLEncode(smstr.c_str());
                            smcstr = smstr.c_str();
                            xml.SetChildData(smcstr);
                       }
                    }
                }
                xml.OutOfElem();
                xml.OutOfElem();
                xml.OutOfElem();
                xmldata = xml.GetDoc();
                p_vehicle_inf->timeRecord.startTime();
                DATA_PRINT(LEVEL_INFO, "The result XML message has been send: \n %s---------------------\n",xmldata.c_str());
                sendAllPhotoResult(p_vehicle_inf, -1, xmldata);
                p_vehicle_inf->timeRecord.endTime();
                recordResponseTime(p_vehicle_inf, "0111", p_vehicle_inf->timeRecord.getTime());
            }
            else
            {
                for (unsigned int i = 0; i < p_vehicle_inf->m_zplist.size(); i++) {
                    unsigned int j;
                    if(p_vehicle_inf->m_zplist[i].zptype.substr(0,1)=="0")
                    {

                        for (j = 0; j < p_vehicle_inf->m_dbbhglist.size(); j++) {
                            if (p_vehicle_inf->m_zplist[i].zptype == p_vehicle_inf->m_dbbhglist[j].zptype) {
                                break;
                            }
                        }

                        if (j == p_vehicle_inf->m_dbbhglist.size()) {   /* 照片通过 */
                            xmldata = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><vehispara><lsh>";
                            xmldata += p_vehicle_inf->m_jylsh;
                            xmldata += "</lsh><zpzl>";
                            xmldata += p_vehicle_inf->m_zplist[i].zptype;
                            xmldata += "</zpzl><jg>1</jg><sm>ok</sm></vehispara></root>";
                        } else {										/* 照片不通过 */
                            xmldata = Prepare_SoapXml_Data(p_vehicle_inf, j);
                        }
                        p_vehicle_inf->timeRecord.startTime();
                        sendPhotoResult(p_vehicle_inf, i, xmldata);
                        p_vehicle_inf->timeRecord.endTime();
                        recordResponseTime(p_vehicle_inf, p_vehicle_inf->m_zplist[i].zptype, p_vehicle_inf->timeRecord.getTime());
                    }
                }
            }

        }
        p_vehicle_inf->timeRecord.end_total_time = p_vehicle_inf->timeRecord.getCurrentTime();
        p_vehicle_inf->timeRecord.total = to_string(p_vehicle_inf->timeRecord.getTime_total());
        unsigned long total_no_wait = std::stoul(p_vehicle_inf->timeRecord.total) - std::stoul(p_vehicle_inf->timeRecord.wait_queue);
        DATA_PRINT(LEVEL_INFO, "total_no_wait =[%lds] \n", total_no_wait);
        p_vehicle_inf->timeRecord.total_no_wait = std::to_string(total_no_wait);

        DATA_PRINT(LEVEL_INFO, "<------------------- Vehicle check request(lsh:%s) has been handled. -------------------> \n\n", p_vehicle_inf->m_jylsh.c_str());

//        /* 组合出处理结果，并通过组播发出 */
//        std::string message = makeResultMessage(p_vehicle_inf);

//        DATA_PRINT(LEVEL_INFO, "Send result XML message by multicast...... \n");
//        g_service.m_mc.SendSqlStr(message);
//        DATA_PRINT(LEVEL_INFO, "The result XML message has been send. \n");

//        if (p_vehicle_inf) {
//            delete p_vehicle_inf;
//        }

        record_queue.Put(p_vehicle_inf);
    }
}

/* 处理结果的记录线程（也就是数据库写入线程） */
void RecordThread()
{
    DATA_PRINT(LEVEL_INFO, "RecordThread running...... \n");

    while (true) {
//        std::string message = sqlstr_queue.Take();
//        DATA_PRINT(LEVEL_INFO, "Received vehicle check result message. \n");
//        DATA_PRINT(LEVEL_INFO, "=======================sqlstr_queue:%d======================\n", sqlstr_queue.Size());

//        vehicle_inf *p_vehicle_inf = new vehicle_inf;
//        unsigned int device_id;

//        if (analyseResultMessage(message, p_vehicle_inf, device_id)) {

//#ifndef	NO_DATABASE
//            insertCheckResult(p_vehicle_inf, device_id);
//#endif

//            DATA_PRINT(LEVEL_INFO, "<------------------- Vehicle check result (lsh:%s) has been insert into database. -------------------> \n\n", p_vehicle_inf->m_jylsh.c_str());
//        } else {
//            DATA_PRINT(LEVEL_ERROR, "Can not analyse the message data! \n");
//        }

        vehicle_inf *p_vehicle_inf = NULL;
        p_vehicle_inf = record_queue.Take();

        DATA_PRINT(LEVEL_INFO, "Take a vehicle check result(lsh:%s) \n", p_vehicle_inf->m_jylsh.c_str());
        DATA_PRINT(LEVEL_INFO, "=======================record_queue:%d======================\n", record_queue.Size());


#ifndef	NO_DATABASE
        if(!p_vehicle_inf->is_video_check)
        {
            operateDatabase(p_vehicle_inf);
        }
        else
        {
            videoOperateDatabase(p_vehicle_inf);
        }

#endif

        DATA_PRINT(LEVEL_INFO, "<------------------- Vehicle check result (lsh:%s) has been insert into database. -------------------> \n\n", p_vehicle_inf->m_jylsh.c_str());

        if (p_vehicle_inf) {
            delete p_vehicle_inf;
        }
    }
}

#ifndef NO_NVR
void VedioCallBack(int &ns, const char* strSaveFile, LPVOID pParam)
{
    if (strSaveFile)
    {
        char szMsg[255] = { 0 };
        sprintf(szMsg, "st==VedioCallBack[%s] [%d]", strSaveFile, ns);
        OutputDebugStringA(szMsg);
    }
    else
    {
        char szMsg[255] = { 0 };
        sprintf(szMsg, "st==VedioCallBack[%s] [%d]", "NULL !", ns);
        OutputDebugStringA(szMsg);
    }
    _vedio_dwl_data* vedio_dwl_data = (_vedio_dwl_data*)pParam;
    vedio_dwl_data->pvehicle_inf->m_splist[vedio_dwl_data->index].local_path = StringToWstring(strSaveFile);
    std::string single_name = "TEMP";
    int len = strlen(strSaveFile);
    for (int i = len - 1; i > 0; i--)
    {
        if (*(strSaveFile + i) == '\\')
        {
            single_name = (char *)(strSaveFile + i + 1);
            break;
        }
    }
    vedio_dwl_data->pvehicle_inf->m_splist[vedio_dwl_data->index].demo_local_path = StringToWstring(g_demo_path + single_name);
    if (vedio_dwl_data->down_num > 0) vedio_dwl_data->down_num--;
    if (vedio_dwl_data->down_num == 0)
    {
        if (vedio_dwl_data->pvehicle_inf)
            toanalyse_queue.Put(vedio_dwl_data->pvehicle_inf); // 视频完成下载，插入处理队列
        delete vedio_dwl_data;
    }
    return;
}

BOOL Start_RTSP_request(const char * rtspurl, _vedio_dwl_data* vedio_dwl_data)
{
    CNvrSdk *pNvr = CNvrSdk::getInstance();
    int iCurChanIndex = 0;//0通道

    //测试
    iCurChanIndex = 1;

    struct evkeyvalq params;
    struct evhttp_uri *m_uri = evhttp_uri_parse_with_flags(rtspurl, 0);
    if (!m_uri)
        return FALSE;
    string scheme = evhttp_uri_get_scheme(m_uri);
    string userinfo = evhttp_uri_get_userinfo(m_uri);
    string username = userinfo.substr(0, userinfo.find(":"));
    string password = userinfo.substr(userinfo.find(":") + 1);
    string c_path = evhttp_uri_get_path(m_uri);
    string c_host = evhttp_uri_get_host(m_uri);
    int nport = evhttp_uri_get_port(m_uri);
    DATA_PRINT(LEVEL_DATA, "[RTSP解析：c_host=%s ", c_host.c_str());
    DATA_PRINT(LEVEL_DATA, "port=%d ", nport);
    DATA_PRINT(LEVEL_DATA, "scheme=%s ", scheme.c_str());
    DATA_PRINT(LEVEL_DATA, "userinfo=%s ", userinfo.c_str());
    DATA_PRINT(LEVEL_DATA, "c_path=%s ", c_path.c_str());
    evhttp_parse_query(rtspurl, &params);
    string starttime = evhttp_find_header(&params, "starttime");
    string endtime = evhttp_find_header(&params, "endtime");
    DATA_PRINT(LEVEL_DATA, "starttime=%s ", starttime.c_str());
    DATA_PRINT(LEVEL_DATA, "endtime=%s \n", endtime.c_str());
    evhttp_clear_headers(&params);
    evhttp_uri_free(m_uri);
    if ((starttime.length() != 16) || (endtime.length() != 16))
        return FALSE;

    //测试
    c_host = "192.168.16.29";
    password = "12345";
    nport = 8000;
    username = "admin";

    if (!pNvr->DoLogin((char *)c_host.c_str(), (char *)password.c_str(), nport, (char *)username.c_str()))
        return FALSE;
    //开始时间
    NET_DVR_TIME StartSearchTime;
    StartSearchTime.dwYear = atoi(starttime.substr(0, 4).c_str());// 2017;
    StartSearchTime.dwMonth = atoi(starttime.substr(4, 2).c_str());//3;
    StartSearchTime.dwDay = atoi(starttime.substr(6, 2).c_str());//18;
    StartSearchTime.dwHour = atoi(starttime.substr(9, 2).c_str());//0;
    StartSearchTime.dwMinute = atoi(starttime.substr(11, 2).c_str());//0;
    StartSearchTime.dwSecond = atoi(starttime.substr(13, 2).c_str());//0;

    //测试
    StartSearchTime.dwYear = 2017;
    StartSearchTime.dwMonth = 4;
    StartSearchTime.dwDay = 8;
    StartSearchTime.dwHour = 18;
    StartSearchTime.dwMinute = 42;
    StartSearchTime.dwSecond = 47;

    //结束时间
    NET_DVR_TIME StopSearchTime;
    StopSearchTime.dwYear = atoi(endtime.substr(0, 4).c_str());// 2017;
    StopSearchTime.dwMonth = atoi(endtime.substr(4, 2).c_str());//3;
    StopSearchTime.dwDay = atoi(endtime.substr(6, 2).c_str());//18;
    StopSearchTime.dwHour = atoi(endtime.substr(9, 2).c_str());//0;
    StopSearchTime.dwMinute = atoi(endtime.substr(11, 2).c_str());//0;
    StopSearchTime.dwSecond = atoi(endtime.substr(13, 2).c_str());//0;

    //测试
    StopSearchTime.dwYear = 2017;
    StopSearchTime.dwMonth = 4;
    StopSearchTime.dwDay = 8;
    StopSearchTime.dwHour = 18;
    StopSearchTime.dwMinute = 43;
    StopSearchTime.dwSecond = 48;

    int ns = pNvr->FindVideo(iCurChanIndex, StartSearchTime, StopSearchTime);
    if (ns == 1)
    {
        vector <NET_DVR_FINDDATA_V30> *pVecFiles = pNvr->GetVideo();
        for (int n = 0; n < pVecFiles->size(); n++)
        {
            pNvr->DownloadVideo(pVecFiles->at(0).sFileName, "c:\\", VedioCallBack, (LPVOID)vedio_dwl_data);
        }
    }
    return TRUE;
}

BOOL Start_NVR_request(const char * nvrdesc, _vedio_dwl_data* vedio_dwl_data) //TBD
{
    if (atoi(g_nvr_dwl_duration.c_str()) == 0)
        return FALSE;
    CNvrSdk *pNvr = CNvrSdk::getInstance();
    int iCurChanIndex = 0;//0通道
    std::string c_host,c_port, username, password, channel, cstarttime, cendtime;
    CMarkup xml;
    std::wstring strdata;
    strdata = StringToWstring(nvrdesc);
    xml.SetDoc(strdata);
    if (!xml.FindElem())//<spurl>
        return FALSE;
    xml.IntoElem();
    if (xml.FindElem("sbip"))
    {
        c_host = WstringToString(xml.GetData());
        string strdevice = c_host;
        c_host = strdevice.substr(0, strdevice.find(":")).c_str();
        c_port = strdevice.substr(strdevice.find(":") + 1).c_str();
    }
    xml.ResetMainPos();
    if (xml.FindElem("sbuser"))
        username = WstringToString(xml.GetData());
    xml.ResetMainPos();
    if (xml.FindElem("sbmm"))
        password = WstringToString(xml.GetData());
    xml.ResetMainPos();
    if (xml.FindElem(L"channel"))
        channel = WstringToString(xml.GetData());
    xml.ResetMainPos();
    if (xml.FindElem(L"kssj"))
        cstarttime = WstringToString(xml.GetData());
    xml.ResetMainPos();
    if (xml.FindElem(L"jssj"))
        cendtime = WstringToString(xml.GetData());
    DATA_PRINT(LEVEL_DATA, "[NVR解析：c_host=%s ", c_host.c_str());
    DATA_PRINT(LEVEL_DATA, "port=%s ", c_port.c_str());
    DATA_PRINT(LEVEL_DATA, "username=%s ", username.c_str());
    DATA_PRINT(LEVEL_DATA, "password=%s ", password.c_str());
    DATA_PRINT(LEVEL_DATA, "channel=%s ", channel.c_str());
    DATA_PRINT(LEVEL_DATA, "starttime=%s ", cstarttime.c_str());
    DATA_PRINT(LEVEL_DATA, "endtime=%s \n", cendtime.c_str());
    string starttime = cstarttime;
    string endtime = cendtime;
    if ((starttime.length() != 19) || (endtime.length() != 19))
        return FALSE;
    if (!pNvr->DoLogin((char *)c_host.c_str(), (char *)password.c_str(), atoi(c_port.c_str()), (char *)username.c_str()))
        return FALSE;
    //开始时间
    NET_DVR_TIME StartSearchTime;//2017-04-01 09:26:33
    StartSearchTime.dwYear = atoi(starttime.substr(0, 4).c_str());// 2017;
    StartSearchTime.dwMonth = atoi(starttime.substr(5, 2).c_str());//3;
    StartSearchTime.dwDay = atoi(starttime.substr(8, 2).c_str());//18;
    StartSearchTime.dwHour = atoi(starttime.substr(11, 2).c_str());//0;
    StartSearchTime.dwMinute = atoi(starttime.substr(14, 2).c_str());//0;
    StartSearchTime.dwSecond = atoi(starttime.substr(17, 2).c_str());//0;

    //DATA_PRINT(LEVEL_DATA, "new starttime=%d - %d -%d %d-%d-%d ", StartSearchTime.dwYear, StartSearchTime.dwMonth, StartSearchTime.dwDay, StartSearchTime.dwHour, StartSearchTime.dwMinute, StartSearchTime.dwSecond);
    //DATA_PRINT(LEVEL_DATA, "endtime=%s \n", cendtime.GetString());

    //结束时间
    NET_DVR_TIME StopSearchTime;
    StopSearchTime.dwYear = atoi(endtime.substr(0, 4).c_str());// 2017;
    StopSearchTime.dwMonth = atoi(endtime.substr(5, 2).c_str());//3;
    StopSearchTime.dwDay = atoi(endtime.substr(8, 2).c_str());//18;
    StopSearchTime.dwHour = atoi(endtime.substr(11, 2).c_str());//0;
    StopSearchTime.dwMinute = atoi(endtime.substr(14, 2).c_str());//0;
    StopSearchTime.dwSecond = atoi(endtime.substr(17, 2).c_str());//0;

    //DATA_PRINT(LEVEL_DATA, "new endtime=%d - %d -%d %d-%d-%d ", StopSearchTime.dwYear, StopSearchTime.dwMonth, StopSearchTime.dwDay, StopSearchTime.dwHour, StopSearchTime.dwMinute, StopSearchTime.dwSecond);

    if (StartSearchTime.dwYear > StopSearchTime.dwYear)
    {
        StopSearchTime.dwYear = StartSearchTime.dwYear;
        StopSearchTime.dwMonth = StartSearchTime.dwMonth;
        StopSearchTime.dwDay = StartSearchTime.dwDay;
        StopSearchTime.dwHour = StartSearchTime.dwHour;
        StopSearchTime.dwMinute = StartSearchTime.dwMinute;
        if (StopSearchTime.dwMinute < 54)
            StopSearchTime.dwMinute += 5;
        else StopSearchTime.dwMinute = 60;
        StopSearchTime.dwSecond = StartSearchTime.dwSecond;
    }

    //DATA_PRINT(LEVEL_DATA, "new endtime2=%d - %d -%d %d-%d-%d ", StopSearchTime.dwYear, StopSearchTime.dwMonth, StopSearchTime.dwDay, StopSearchTime.dwHour, StopSearchTime.dwMinute, StopSearchTime.dwSecond);
    iCurChanIndex = atoi(channel.c_str()) - 1;
    if (iCurChanIndex < 0)
        iCurChanIndex = 0;
    int ns = pNvr->FindVideo(iCurChanIndex, StartSearchTime, StopSearchTime);
    if (ns == 1)
    {
        vector <NET_DVR_FINDDATA_V30> *pVecFiles = pNvr->GetVideo();
        pNvr->m_MaxDwlTime_S = atoi(g_nvr_dwl_duration.c_str());
        for (int n = 0; n < pVecFiles->size(); n++)
        {
            pNvr->DownloadVideo(pVecFiles->at(0).sFileName, g_photoFilePath.c_str(), VedioCallBack, (LPVOID)vedio_dwl_data);
            //g_photoFilePath.ReleaseBuffer();
            break;
        }
    }
    return TRUE;
}
#endif

inline BYTE toHex(const BYTE &x)
{
    return x > 9 ? x - 10 + 'A' : x + '0';
}

inline BYTE fromHex(const BYTE &x)
{
    if (isdigit(x)) {
        return x - '0';
    } else if (isupper(x)) {
        return x - 'A' + 10;
    } else {
        return x - 'a' + 10;
    }
}

inline string URLEncode(const string &sIn)
{
    string sOut;
    for (size_t ix = 0; ix < sIn.size(); ix++)
    {
        BYTE buf[4];
        memset(buf, 0, 4);
        if (isalnum((BYTE)sIn[ix]))
        {
            buf[0] = sIn[ix];
        }

        //else if ( isspace( (BYTE)sIn[ix] ) ) //貌似把空格编码成%20或者+都可以
        //{
        //    buf[0] = '+';
        //}

        else
        {
            buf[0] = '%';
            buf[1] = toHex((BYTE)sIn[ix] >> 4);
            buf[2] = toHex((BYTE)sIn[ix] % 16);
        }
        sOut += (char *)buf;
    }

    return sOut;

}

inline string URLDecode(const string &sIn)
{
    string sOut;
    for (size_t ix = 0; ix < sIn.size(); ix++)
    {
        BYTE ch = 0;
        if (sIn[ix] == '%')
        {
            ch = (fromHex(sIn[ix + 1]) << 4);
            ch |= fromHex(sIn[ix + 2]);
            ix += 2;
        }
        else if (sIn[ix] == '+')
        {
            ch = ' ';
        }
        else
        {
            ch = sIn[ix];
        }
        sOut += (char)ch;
    }
    return sOut;
}

void recordResponseTime(vehicle_inf *v_vehicle_inf, std::string picture_type, std::string time)
{
    if (picture_type == "0201") {
        v_vehicle_inf->timeRecord.picture.response.xsz = time;
    } else if (picture_type == "0202") {
        v_vehicle_inf->timeRecord.picture.response.sqb = time;
    } else if (picture_type == "0203") {
        v_vehicle_inf->timeRecord.picture.response.jqx = time;
    } else if (picture_type == "0204") {
        v_vehicle_inf->timeRecord.picture.response.jybg = time;
    } else if (picture_type == "0111") {
        v_vehicle_inf->timeRecord.picture.response.zqf = time;
    } else if (picture_type == "0112") {
        v_vehicle_inf->timeRecord.picture.response.yhf = time;
    } else if (picture_type == "0113") {
        v_vehicle_inf->timeRecord.picture.response.cjh = time;
    } else if (picture_type == "0157") {
        v_vehicle_inf->timeRecord.picture.response.aqd = time;
    } else if (picture_type == "0321") {
        v_vehicle_inf->timeRecord.picture.response.zdg = time;
    } else if (picture_type == "0352") {
        v_vehicle_inf->timeRecord.picture.response.ydg = time;
    } else if (picture_type == "0351") {
        v_vehicle_inf->timeRecord.picture.response.zczd = time;
    } else if (picture_type == "0205") {
        v_vehicle_inf->timeRecord.picture.response.cyjl = time;
    } else if (picture_type == "0265" || picture_type == "0210" || picture_type == "0209" || picture_type == "0212") {
        v_vehicle_inf->timeRecord.picture.response.wqjy = time;
    } else if (picture_type == "0344") {
        v_vehicle_inf->timeRecord.picture.response.dpdtks = time;
    } else if (picture_type == "0342") {
        v_vehicle_inf->timeRecord.picture.response.dpdtjs = time;
    } else if (picture_type == "0323") {
        v_vehicle_inf->timeRecord.picture.response.dpjy = time;
    } else if (picture_type == "0322") {
        v_vehicle_inf->timeRecord.picture.response.yzzd = time;
    } else if (picture_type == "0348") {
        v_vehicle_inf->timeRecord.picture.response.ezzd = time;
    }
}

/* 组合出处理结果，以通过组播发出 */
std::string makeResultMessage(const vehicle_inf *pvehicle_inf)
{
    DATA_PRINT(LEVEL_INFO, "Start make result XML message...... \n");

    CMarkup xml;

    xml.SetDoc("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n");
    xml.AddElem("vehicle_result");
    xml.IntoElem();
    setlocale(LC_ALL, "chs");

    for (unsigned int i = 0; i < pvehicle_inf->item_description.size(); i++) {
        if (strcmp(pvehicle_inf->item_description[i].name_tag , "dbbhglist") == 0) {
            xml.AddElem("dbbhglist");
            xml.IntoElem();

            for (unsigned int j = 0; j < pvehicle_inf->m_dbbhglist.size(); j++) {
                xml.AddElem("item");
                xml.AddChildElem("zpzl");
                xml.SetChildData(pvehicle_inf->m_dbbhglist[j].zptype);
                xml.AddChildElem("sm");
                xml.SetChildData(pvehicle_inf->m_dbbhglist[j].dbbhg_desc);
                xml.AddChildElem("jg");
                xml.SetChildData(pvehicle_inf->m_dbbhglist[j].dbresult);
                xml.AddChildElem("zpid");
                xml.SetChildData(pvehicle_inf->m_dbbhglist[j].zpid);
            }

            xml.OutOfElem();
        } else if (strcmp(pvehicle_inf->item_description[i].name_tag , "zplist") == 0) {
            xml.AddElem("zplist");
            xml.IntoElem();

            for (unsigned int j = 0; j < pvehicle_inf->m_zplist.size(); j++) {
                xml.AddElem("item");
                xml.AddChildElem("zpzl");
                xml.SetChildData(pvehicle_inf->m_zplist[j].zptype);
                xml.AddChildElem("zpurl");
                xml.SetChildData(pvehicle_inf->m_zplist[j].zpurl);
                xml.AddChildElem("path");
                xml.SetChildData(pvehicle_inf->m_zplist[j].local_path);
                xml.AddChildElem("id");
                xml.SetChildData(pvehicle_inf->m_zplist[j].zpid);
            }

            xml.OutOfElem();
        } else if (strcmp(pvehicle_inf->item_description[i].name_tag, "splist") == 0) {
            xml.AddElem("splist");
            xml.IntoElem();

            for (unsigned int j = 0; j<pvehicle_inf->m_splist.size(); j++) {
                xml.AddElem("item");
                xml.AddChildElem("spzl");
                xml.SetChildData(pvehicle_inf->m_splist[j].sptype);
                xml.AddChildElem("dzzl");
                xml.SetChildData(pvehicle_inf->m_splist[j].dzzl);

                if (pvehicle_inf->m_splist[j].dzzl == "nvr") {
                    xml.AddChildSubDoc(pvehicle_inf->m_splist[j].spurl);
                } else {
                    xml.AddChildElem("spurl");
                    xml.SetChildData(pvehicle_inf->m_splist[j].spurl);
                }
            }

            xml.OutOfElem();
        } else if (strcmp(pvehicle_inf->item_description[i].name_tag , "ckdbzplist") == 0) {
            xml.AddElem("ckdbzplist");
            xml.IntoElem();

            for (unsigned int j = 0; j<pvehicle_inf->m_ckdbzplist.size(); j++) {
                xml.AddElem("item");
                xml.AddChildElem("zpzl");
                xml.SetChildData(pvehicle_inf->m_ckdbzplist[j].zptype);
                xml.AddChildElem("zpurl");
                xml.SetChildData(pvehicle_inf->m_ckdbzplist[j].zpurl);
            }

            xml.OutOfElem();
        } else {
            std::string value;
            std::string basictag = pvehicle_inf->item_description[i].name_tag;
            value = *(std::string *)(pvehicle_inf->item_description[i].value);

            xml.AddElem(basictag);
            xml.SetData(value);
        }

        xml.ResetChildPos();
    }

    xml.AddElem("AlgorithmCheck");
    xml.SetData(pvehicle_inf->AlgorithmCheck ? "1" : "0");

    /* 组合TimeRecord信息 */
    {
        xml.AddElem("TimeRecord");
        xml.IntoElem();

        {
            xml.AddElem("process");
            xml.IntoElem();

            xml.AddElem("xsz");
            xml.SetData(pvehicle_inf->timeRecord.picture.process.xsz);
            xml.AddElem("sqb");
            xml.SetData(pvehicle_inf->timeRecord.picture.process.sqb);
            xml.AddElem("jqx");
            xml.SetData(pvehicle_inf->timeRecord.picture.process.jqx);
            xml.AddElem("jybg");
            xml.SetData(pvehicle_inf->timeRecord.picture.process.jybg);
            xml.AddElem("cyjl");
            xml.SetData(pvehicle_inf->timeRecord.picture.process.cyjl);
            xml.AddElem("zqf");
            xml.SetData(pvehicle_inf->timeRecord.picture.process.zqf);
            xml.AddElem("yhf");
            xml.SetData(pvehicle_inf->timeRecord.picture.process.yhf);
            xml.AddElem("cjh");
            xml.SetData(pvehicle_inf->timeRecord.picture.process.cjh);
            xml.AddElem("aqd");
            xml.SetData(pvehicle_inf->timeRecord.picture.process.aqd);
            xml.AddElem("zdg");
            xml.SetData(pvehicle_inf->timeRecord.picture.process.zdg);
            xml.AddElem("ydg");
            xml.SetData(pvehicle_inf->timeRecord.picture.process.ydg);
            xml.AddElem("yzzd");
            xml.SetData(pvehicle_inf->timeRecord.picture.process.yzzd);
            xml.AddElem("ezzd");
            xml.SetData(pvehicle_inf->timeRecord.picture.process.ezzd);
            xml.AddElem("zczd");
            xml.SetData(pvehicle_inf->timeRecord.picture.process.zczd);
            xml.AddElem("dpdtks");
            xml.SetData(pvehicle_inf->timeRecord.picture.process.dpdtks);
            xml.AddElem("dpdtjs");
            xml.SetData(pvehicle_inf->timeRecord.picture.process.dpdtjs);
            xml.AddElem("dpjy");
            xml.SetData(pvehicle_inf->timeRecord.picture.process.dpjy);
            xml.AddElem("wqjy");
            xml.SetData(pvehicle_inf->timeRecord.picture.process.wqjy);
            xml.AddElem("mhq");
            xml.SetData(pvehicle_inf->timeRecord.picture.process.mhq);
            xml.AddElem("yjc");
            xml.SetData(pvehicle_inf->timeRecord.picture.process.yjc);
            xml.AddElem("jly");
            xml.SetData(pvehicle_inf->timeRecord.picture.process.jly);
            xml.AddElem("zql");
            xml.SetData(pvehicle_inf->timeRecord.picture.process.zql);
            xml.AddElem("yql");
            xml.SetData(pvehicle_inf->timeRecord.picture.process.yql);

            xml.OutOfElem();
        }

        {
            xml.AddElem("response");
            xml.IntoElem();

            xml.AddElem("xsz");
            xml.SetData(pvehicle_inf->timeRecord.picture.response.xsz);
            xml.AddElem("sqb");
            xml.SetData(pvehicle_inf->timeRecord.picture.response.sqb);
            xml.AddElem("jqx");
            xml.SetData(pvehicle_inf->timeRecord.picture.response.jqx);
            xml.AddElem("jybg");
            xml.SetData(pvehicle_inf->timeRecord.picture.response.jybg);
            xml.AddElem("cyjl");
            xml.SetData(pvehicle_inf->timeRecord.picture.response.cyjl);
            xml.AddElem("zqf");
            xml.SetData(pvehicle_inf->timeRecord.picture.response.zqf);
            xml.AddElem("yhf");
            xml.SetData(pvehicle_inf->timeRecord.picture.response.yhf);
            xml.AddElem("cjh");
            xml.SetData(pvehicle_inf->timeRecord.picture.response.cjh);
            xml.AddElem("aqd");
            xml.SetData(pvehicle_inf->timeRecord.picture.response.aqd);
            xml.AddElem("zdg");
            xml.SetData(pvehicle_inf->timeRecord.picture.response.zdg);
            xml.AddElem("ydg");
            xml.SetData(pvehicle_inf->timeRecord.picture.response.ydg);
            xml.AddElem("yzzd");
            xml.SetData(pvehicle_inf->timeRecord.picture.response.yzzd);
            xml.AddElem("ezzd");
            xml.SetData(pvehicle_inf->timeRecord.picture.response.ezzd);
            xml.AddElem("zczd");
            xml.SetData(pvehicle_inf->timeRecord.picture.response.zczd);
            xml.AddElem("dpdtks");
            xml.SetData(pvehicle_inf->timeRecord.picture.response.dpdtks);
            xml.AddElem("dpdtjs");
            xml.SetData(pvehicle_inf->timeRecord.picture.response.dpdtjs);
            xml.AddElem("dpjy");
            xml.SetData(pvehicle_inf->timeRecord.picture.response.dpjy);
            xml.AddElem("wqjy");
            xml.SetData(pvehicle_inf->timeRecord.picture.response.wqjy);
            xml.AddElem("mhq");
            xml.SetData(pvehicle_inf->timeRecord.picture.response.mhq);
            xml.AddElem("yjc");
            xml.SetData(pvehicle_inf->timeRecord.picture.response.yjc);
            xml.AddElem("jly");
            xml.SetData(pvehicle_inf->timeRecord.picture.response.jly);
            xml.AddElem("zql");
            xml.SetData(pvehicle_inf->timeRecord.picture.response.zql);
            xml.AddElem("yql");
            xml.SetData(pvehicle_inf->timeRecord.picture.response.yql);

            xml.OutOfElem();
        }

        xml.AddElem("AllDownload");
        xml.SetData(pvehicle_inf->timeRecord.picture.AllDownload);

        xml.AddElem("total");
        xml.SetData(pvehicle_inf->timeRecord.total);

        xml.AddElem("wait_queue");
        xml.SetData(pvehicle_inf->timeRecord.wait_queue);

        xml.AddElem("total_no_wait");
        xml.SetData(pvehicle_inf->timeRecord.total_no_wait);

        xml.OutOfElem();
    }

    /* 填充device_id */
    xml.AddElem("device_ID");
    xml.SetData(g_device_ID);

    xml.OutOfElem();

    DATA_PRINT(LEVEL_INFO, "Result XML message has been constructed. \n");
    DATA_PRINT(LEVEL_DEBUG, "XML message:\n%s\n", xml.GetDoc().c_str());

    return xml.GetDoc();
}

/* 解析收到的组播消息，组合成vehicle_inf结构 */
bool analyseResultMessage(const std::string message, vehicle_inf *pvehicle_inf, unsigned int &device_ID)
{
    CMarkup xml;

    xml.SetDoc(message);

    if (xml.FindElem("vehicle_result")) {
        xml.IntoElem();
        setlocale(LC_ALL, "chs");

        /* 解析车辆信息 */
        for (unsigned int i = 0; i < pvehicle_inf->item_description.size(); i++) {
            if (xml.FindElem(std::string(pvehicle_inf->item_description[i].name_tag))) {

                if (strcmp(pvehicle_inf->item_description[i].name_tag , "dbbhglist") == 0) {
                    _dbbhg_list v_dbhhg_list;

                    xml.IntoElem();

                    while (xml.FindElem("item")) {
                        if (xml.FindChildElem("zpzl")) {
                            v_dbhhg_list.zptype = xml.GetChildData();
                        }

                        if (xml.FindChildElem("sm")) {
                            v_dbhhg_list.dbbhg_desc = xml.GetChildData();
                        }

                        if (xml.FindChildElem("jg"))  {
                            v_dbhhg_list.dbresult = xml.GetChildData();
                        }

                        if (xml.FindChildElem("zpid"))  {
                            v_dbhhg_list.zpid = xml.GetChildData();
                        }

                        pvehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
                    }

                    xml.OutOfElem();
                } else if (strcmp(pvehicle_inf->item_description[i].name_tag , "zplist") == 0) {
                    _photo_resource v_photo_resource;

                    xml.IntoElem();

                    while (xml.FindElem("item")) {
                        if (xml.FindChildElem("zpzl")) {
                            v_photo_resource.zptype = xml.GetChildData();
                        }

                        if (xml.FindChildElem("zpurl")) {
                            v_photo_resource.zpurl = xml.GetChildData();
                        }

                        if (xml.FindChildElem("path")) {
                            v_photo_resource.local_path = xml.GetChildData();
                        }

                        if (xml.FindChildElem("id")) {
                            v_photo_resource.zpid = xml.GetChildData();
                        }

                        pvehicle_inf->m_zplist.push_back(v_photo_resource);
                    }

                    xml.OutOfElem();
                } else if (strcmp(pvehicle_inf->item_description[i].name_tag, "splist") == 0) {
                    _video_resource v_video_resource;
                    xml.IntoElem();

                    while (xml.FindElem("item")) {
                        if (xml.FindChildElem("spzl")) {
                            v_video_resource.sptype = xml.GetChildData();
                        }

                        if (xml.FindChildElem("dzzl")) {
                            v_video_resource.dzzl = xml.GetChildData();
                        }

                        if (xml.FindChildElem("spurl")) {
                            if (v_video_resource.dzzl == "nvr") {
                                v_video_resource.spurl = xml.GetChildSubDoc();
                            } else {
                                v_video_resource.spurl = xml.GetChildData();
                            }
                        }

                        v_video_resource.local_path = "TBD";
                        pvehicle_inf->m_splist.push_back(v_video_resource);
                    }

                    xml.OutOfElem();
                } else if (strcmp(pvehicle_inf->item_description[i].name_tag , "ckdbzplist") == 0) {
                    _photo_resource v_photo_resource;
                    xml.IntoElem();

                    while (xml.FindElem("item")) {
                        if (xml.FindChildElem("zpzl")) {
                            v_photo_resource.zptype = xml.GetChildData();
                        }

                        if (xml.FindChildElem("zpurl")) {
                            v_photo_resource.zpurl = xml.GetChildData();
                        }

                        pvehicle_inf->m_ckdbzplist.push_back(v_photo_resource);
                    }

                    xml.OutOfElem();
                } else {
                    *(std::string *)(pvehicle_inf->item_description[i].value) = xml.GetData();
                }
            } else {
                DATA_PRINT(LEVEL_ERROR,
                           "analyseResultMessage: Can not find %s \n", pvehicle_inf->item_description[i].name_tag);
            }

            xml.ResetMainPos();
            xml.ResetChildPos();
        }

        if (xml.FindElem("AlgorithmCheck")) {
            pvehicle_inf->AlgorithmCheck = (xml.GetData() == "1");
        } else {
            DATA_PRINT(LEVEL_ERROR, "analyseResultMessage: Can not find \"AlgorithmCheck\" element! \n");
            return false;
        }

        /* 解析TimeRecord */
        if (xml.FindElem("TimeRecord")) {
            xml.IntoElem();

            if (xml.FindElem("process")) {
                xml.FindChildElem("xsz");
                pvehicle_inf->timeRecord.picture.process.xsz = xml.GetChildData();
                xml.FindChildElem("sqb");
                pvehicle_inf->timeRecord.picture.process.sqb = xml.GetChildData();
                xml.FindChildElem("jqx");
                pvehicle_inf->timeRecord.picture.process.jqx = xml.GetChildData();
                xml.FindChildElem("jybg");
                pvehicle_inf->timeRecord.picture.process.jybg = xml.GetChildData();
                xml.FindChildElem("cyjl");
                pvehicle_inf->timeRecord.picture.process.cyjl = xml.GetChildData();
                xml.FindChildElem("zqf");
                pvehicle_inf->timeRecord.picture.process.zqf = xml.GetChildData();
                xml.FindChildElem("yhf");
                pvehicle_inf->timeRecord.picture.process.yhf = xml.GetChildData();
                xml.FindChildElem("cjh");
                pvehicle_inf->timeRecord.picture.process.cjh = xml.GetChildData();
                xml.FindChildElem("aqd");
                pvehicle_inf->timeRecord.picture.process.aqd = xml.GetChildData();
                xml.FindChildElem("zdg");
                pvehicle_inf->timeRecord.picture.process.zdg = xml.GetChildData();
                xml.FindChildElem("ydg");
                pvehicle_inf->timeRecord.picture.process.ydg = xml.GetChildData();
                xml.FindChildElem("yzzd");
                pvehicle_inf->timeRecord.picture.process.yzzd = xml.GetChildData();
                xml.FindChildElem("ezzd");
                pvehicle_inf->timeRecord.picture.process.ezzd = xml.GetChildData();
                xml.FindChildElem("zczd");
                pvehicle_inf->timeRecord.picture.process.zczd = xml.GetChildData();
                xml.FindChildElem("dpdtks");
                pvehicle_inf->timeRecord.picture.process.dpdtks = xml.GetChildData();
                xml.FindChildElem("dpdtjs");
                pvehicle_inf->timeRecord.picture.process.dpdtjs = xml.GetChildData();
                xml.FindChildElem("dpjy");
                pvehicle_inf->timeRecord.picture.process.dpjy = xml.GetChildData();
                xml.FindChildElem("wqjy");
                pvehicle_inf->timeRecord.picture.process.wqjy = xml.GetChildData();
                xml.FindChildElem("mhq");
                pvehicle_inf->timeRecord.picture.process.mhq = xml.GetChildData();
                xml.FindChildElem("yjc");
                pvehicle_inf->timeRecord.picture.process.yjc = xml.GetChildData();
                xml.FindChildElem("jly");
                pvehicle_inf->timeRecord.picture.process.jly = xml.GetChildData();
                xml.FindChildElem("zql");
                pvehicle_inf->timeRecord.picture.process.zql = xml.GetChildData();
                xml.FindChildElem("yql");
                pvehicle_inf->timeRecord.picture.process.yql = xml.GetChildData();
            }

            if (xml.FindElem("response")) {
                xml.FindChildElem("xsz");
                pvehicle_inf->timeRecord.picture.response.xsz = xml.GetChildData();
                xml.FindChildElem("sqb");
                pvehicle_inf->timeRecord.picture.response.sqb = xml.GetChildData();
                xml.FindChildElem("jqx");
                pvehicle_inf->timeRecord.picture.response.jqx = xml.GetChildData();
                xml.FindChildElem("jybg");
                pvehicle_inf->timeRecord.picture.response.jybg = xml.GetChildData();
                xml.FindChildElem("cyjl");
                pvehicle_inf->timeRecord.picture.response.cyjl = xml.GetChildData();
                xml.FindChildElem("zqf");
                pvehicle_inf->timeRecord.picture.response.zqf = xml.GetChildData();
                xml.FindChildElem("yhf");
                pvehicle_inf->timeRecord.picture.response.yhf = xml.GetChildData();
                xml.FindChildElem("cjh");
                pvehicle_inf->timeRecord.picture.response.cjh = xml.GetChildData();
                xml.FindChildElem("aqd");
                pvehicle_inf->timeRecord.picture.response.aqd = xml.GetChildData();
                xml.FindChildElem("zdg");
                pvehicle_inf->timeRecord.picture.response.zdg = xml.GetChildData();
                xml.FindChildElem("ydg");
                pvehicle_inf->timeRecord.picture.response.ydg = xml.GetChildData();
                xml.FindChildElem("yzzd");
                pvehicle_inf->timeRecord.picture.response.yzzd = xml.GetChildData();
                xml.FindChildElem("ezzd");
                pvehicle_inf->timeRecord.picture.response.ezzd = xml.GetChildData();
                xml.FindChildElem("zczd");
                pvehicle_inf->timeRecord.picture.response.zczd = xml.GetChildData();
                xml.FindChildElem("dpdtks");
                pvehicle_inf->timeRecord.picture.response.dpdtks = xml.GetChildData();
                xml.FindChildElem("dpdtjs");
                pvehicle_inf->timeRecord.picture.response.dpdtjs = xml.GetChildData();
                xml.FindChildElem("dpjy");
                pvehicle_inf->timeRecord.picture.response.dpjy = xml.GetChildData();
                xml.FindChildElem("wqjy");
                pvehicle_inf->timeRecord.picture.response.wqjy = xml.GetChildData();
                xml.FindChildElem("mhq");
                pvehicle_inf->timeRecord.picture.response.mhq = xml.GetChildData();
                xml.FindChildElem("yjc");
                pvehicle_inf->timeRecord.picture.response.yjc = xml.GetChildData();
                xml.FindChildElem("jly");
                pvehicle_inf->timeRecord.picture.response.jly = xml.GetChildData();
                xml.FindChildElem("zql");
                pvehicle_inf->timeRecord.picture.response.zql = xml.GetChildData();
                xml.FindChildElem("yql");
                pvehicle_inf->timeRecord.picture.response.yql = xml.GetChildData();
            }

            xml.FindElem("AllDownload");
            pvehicle_inf->timeRecord.picture.AllDownload = xml.GetData();

            xml.FindElem("total");
            pvehicle_inf->timeRecord.total = xml.GetData();

            xml.FindElem("wait_queue");
            pvehicle_inf->timeRecord.wait_queue = xml.GetData();

            xml.FindElem("total_no_wait");
            pvehicle_inf->timeRecord.total_no_wait = xml.GetData();

            xml.OutOfElem();
        } else {
            DATA_PRINT(LEVEL_ERROR, "analyseResultMessage: Can not find \"TimeRecord\" element! \n");
            return false;
        }

        xml.FindElem("device_ID");
        device_ID = std::stoi(xml.GetData());
    } else {
        DATA_PRINT(LEVEL_ERROR, "analyseResultMessage: Can not find \"vehicle_result\" root element! \n");
        return false;
    }

    return true;
}

/* 保定车架号拓印膜照片下载函数 */
void BaoDing_FTP_Download(vehicle_inf *p_vehicle_inf)
{
    if (p_vehicle_inf->m_clsbdh == "无数据") {
        DATA_PRINT(LEVEL_INFO, "Unable to download BaoDing J_FTP picture, without clsbdh. \n");
        return;
    }
    std::string xmlDoc;
    xmlDoc.clear();
    xmlDoc += "<?xml version=\"1.0\" encoding=\"GBK\"?>";
    xmlDoc += "<root>";
    xmlDoc += "<vehimage>";
    xmlDoc += "<clsbdh>";
    xmlDoc += p_vehicle_inf->m_clsbdh;
    xmlDoc +="</clsbdh>";
    xmlDoc += "<daxh>09</daxh><djy>1</djy>";
    xmlDoc += "</vehimage>";
    xmlDoc += "</root>";
    while (true) {
        std::string::size_type pos(0);

        if ((pos = xmlDoc.find("<")) != std::string::npos) {
            xmlDoc.replace(pos, 1, "&lt;");
        } else {
            break;
        }
    }

    while (true) {
        std::string::size_type pos(0);

        if ((pos = xmlDoc.find(">")) != std::string::npos) {
            xmlDoc.replace(pos, 1, "&gt;");
        } else {
            break;
        }
    }
    std::string bodyString;
    bodyString.clear();
    bodyString += "<queryimagebyclsbdh xmlns=\"http://192.168.8.156:7888/catm_proxy/services/DzdaOutNewAccess\">";
    bodyString += "<jkxlh>7D1D09090202170408157DE6EB88F6F8E581E8F28FF4FF5840746D72693E636E</jkxlh>";
    bodyString += "<QueryXmlDoc>" + xmlDoc + "</QueryXmlDoc>";
    bodyString += "</queryimagebyclsbdh>";
    std::string result;
    result.clear();
    result += "<?xml version=\"1.0\" encoding=\"GBK\"?>";
    result += "<soap:Envelope ";
    result += "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" ";
    result += "xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" ";
    result += "xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"";
    result += ">";
    result += "<soap:Body>";
    result += bodyString;
    result += "</soap:Body>";
    result += "</soap:Envelope>";

    HttpClient get_pic_httpclient;

    if(get_pic_httpclient.InitData("http://192.168.8.156:7888/catm_proxy/services/DzdaOutNewAccess",REQUEST_POST_FLAG,HTTP_CONTENT_TYPE_TEXT_XML,(char *)result.c_str()))
    {
        get_pic_httpclient.set_retries_timeout(5, 8);
        get_pic_httpclient.startHttpClient(p_vehicle_inf->m_clsbdh);
    }
    if (get_pic_httpclient.d_success_flag)
    {
        DATA_PRINT(LEVEL_ERROR, "Slave(%s) response is successful. \n\n", p_vehicle_inf->m_clsbdh.c_str());

    }
    else
    {
        DATA_PRINT(LEVEL_ERROR, "Slave(%s) is fail. \n\n", p_vehicle_inf->m_clsbdh.c_str());
        return ;
    }

//    /* 创建clsbdh.txt，然后上传FTP */
//    std::string txt = BAODING_TXT_DIR + p_vehicle_inf->m_clsbdh + ".txt";
//    FILE *fp = std::fopen(txt.c_str(), "w");
//    if (!fp) {
//        DATA_PRINT(LEVEL_ERROR, "fopen failure! \n");
//        FtpQuit(conn);
//        return;
//    }

//    std::fclose(fp);

//    std::string out_file = "/out/" + p_vehicle_inf->m_clsbdh + ".txt";
//    if (!FtpPut(txt.c_str(), out_file.c_str(), FTPLIB_IMAGE, conn)) {
//        DATA_PRINT(LEVEL_ERROR, "FtpPut() failure: %s \n", FtpLastResponse(conn));
//        FtpQuit(conn);
//        return;
//    }

//    /* 轮询查看是否有jpg */
//    unsigned int i;
//    unsigned int count = 15;
//    for (i = 0; i < count; i++) {
//        if (!FtpNlst((BAODING_TXT_DIR + "in_list").c_str(), "/in", conn)) {
//            DATA_PRINT(LEVEL_ERROR, "FtpNlst() failure: %s \n", FtpLastResponse(conn));
//            break;
//        }

//        FILE *fp = std::fopen((BAODING_TXT_DIR + "in_list").c_str(), "r");
//        if (!fp) {
//            DATA_PRINT(LEVEL_ERROR, "fopen failure! \n");
//            break;
//        }

//        bool FindFile = false;
//        char buf[256] = {0};
//        while (std::fgets(buf, sizeof(buf), fp) != NULL) {
//            char jpg_name[64];
//            std::sscanf(buf, "/in/%s.jpg", jpg_name);

//            /* 找到匹配文件，下载文件 */
//            if (std::string(jpg_name) == (p_vehicle_inf->m_clsbdh + ".jpg")) {

//                std::string FilePath = g_photoFilePath;

//                std::time_t t = std::time(NULL);
//                std::tm *st = std::localtime(&t);
//                char tmpArray[128] = { 0 };
//                sprintf(tmpArray, "%d-%02d-%02d", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);
//                std::string strCurTime = tmpArray;

//                FilePath += strCurTime + "/";

//                struct stat st_buf;
//                memset(&st_buf,0,sizeof(st_buf));
//                stat(FilePath.c_str(), &st_buf);
//                if ((st_buf.st_mode & S_IFMT) != S_IFDIR) {
//                    mkdir(FilePath.c_str(), 0777);
//                }

//                std::string clsbdh_pic = FilePath + p_vehicle_inf->m_clsbdh + "_J_FTP";

//                int result = FtpGet(clsbdh_pic.c_str(),
//                                    ("/in/" + p_vehicle_inf->m_clsbdh + ".jpg").c_str(),
//                                    FTPLIB_IMAGE,
//                                    conn);

//                if (!result) {
//                    DATA_PRINT(LEVEL_ERROR, "FtpGet() failure, path: %s \n", ("/in/" + p_vehicle_inf->m_clsbdh + ".jpg").c_str());
//                } else {
//                    p_vehicle_inf->BaoDing_J_FTP = clsbdh_pic;
//                    DATA_PRINT(LEVEL_INFO, "FTP has download file[%s]. \n", clsbdh_pic.c_str());
//                }

//                /* 删除文件，以减少空间占用 */
//                if (!FtpDelete(("/in/" + p_vehicle_inf->m_clsbdh + ".jpg").c_str(), conn)) {
//                    DATA_PRINT(LEVEL_ERROR, "FtpDelete() failure, path: %s \n", ("/in/" + p_vehicle_inf->m_clsbdh + ".jpg").c_str());
//                }

//                FindFile = true;
//                break;
//            }
//        }

//        if (std::ferror(fp)) {
//            DATA_PRINT(LEVEL_ERROR, "I/O error when reading!! \n");
//        }

//        std::fclose(fp);

//        if (FindFile) {
//            break;
//        }

//        std::this_thread::sleep_for(std::chrono::milliseconds(1000));
//    }

//    FtpQuit(conn);

//    if (i == count) {
//        DATA_PRINT(LEVEL_INFO, "Can not find %s.jpg in FTP server! \n", p_vehicle_inf->m_clsbdh.c_str());
//    }

//    /* 删除本地的txt文件 */
//    std::string cmd = "rm " + txt;
//    std::system(cmd.c_str());

//    std::chrono::steady_clock::time_point end = std::chrono::steady_clock::now();
//    DATA_PRINT(LEVEL_INFO, "BaoDing J_FTP picture download is complete! Time consuming: %d s \n",
//               std::chrono::duration_cast<std::chrono::seconds>(end - start).count());
}

/* 由于occi库不能直接传递std::string，只能把函数定义在此 */
std::string occi_convertString(char *data)
{
    if (data == NULL) {
        return "";
    }

    std::string ret = data;
    free(data);
    return ret;
}

#define JYBG_ITEM_COUNT 10  /* 检验报告的字段数 */

struct JYBG {
    std::string item[JYBG_ITEM_COUNT];
};

/* 获取保定检验报告的电子数据 */
void BaoDing_JYBG(vehicle_inf *p_vehicle_inf)
{
    if (g_TestMode) {
        p_vehicle_inf->BaoDing_JYBG = 0;
        p_vehicle_inf->BaoDing_YQ = 0;
        return;
    }

    DATA_PRINT(LEVEL_INFO, "Start get JYBG from Oracle database...... \n");

    std::time_t t = std::time(NULL);
    std::tm *st = std::localtime(&t);
    char tmpArray[128] = { 0 };
    sprintf(tmpArray, "%d-%02d-%02d", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);

    occi_wrap occi;
    if (!BaoDing_connectOracleCluster(occi)) {
        p_vehicle_inf->BaoDing_JYBG = 3;
        p_vehicle_inf->BaoDing_YQ = 3;
        return;
    }

    /*
    限定时间是为了：
    1. 防止检索到去年的数据
    2. 加快检索速度
    */
    std::string sql;
    sql = "SELECT ";
    sql += "JYLSH,YZZDPD,EZZDPD,SANZZDPD,SIZZDPD,WZZDPD,ZCZDPD,TCZDPD,ZWDPD,ZNDPD,YWDPD,YNDPD,CSBPD,CHPD";
    sql += " FROM \"TRFFPN_APP\".\"VEH_IS_INSRESULT_DETAIL\" WHERE GXSJ >= TO_DATE('";
    sql += std::string(tmpArray);
    sql += "','yyyy-mm-dd') AND LSH = '" + p_vehicle_inf->m_jylsh + "'";

    if (!(occi.createStatement(sql.c_str()) && occi.executeQuery())) {
        DATA_PRINT(LEVEL_ERROR, "createStatement() or executeQuery() fail! \n");
        p_vehicle_inf->BaoDing_JYBG = 1;
        p_vehicle_inf->BaoDing_YQ = 1;
        occi.disconnect();
        return;
    }

    std::vector<std::string> yiqi_result;

    /* 判定仪器数据是否通过 */
    if (occi.NotEndFetch()) {
        yiqi_result.push_back(occi_convertString(occi.getString(1)));
        yiqi_result.push_back(occi_convertString(occi.getString(2)));
        yiqi_result.push_back(occi_convertString(occi.getString(3)));
        yiqi_result.push_back(occi_convertString(occi.getString(4)));
        yiqi_result.push_back(occi_convertString(occi.getString(5)));
        yiqi_result.push_back(occi_convertString(occi.getString(6)));
        yiqi_result.push_back(occi_convertString(occi.getString(7)));
        yiqi_result.push_back(occi_convertString(occi.getString(8)));
        yiqi_result.push_back(occi_convertString(occi.getString(9)));
        yiqi_result.push_back(occi_convertString(occi.getString(10)));
        yiqi_result.push_back(occi_convertString(occi.getString(11)));
        yiqi_result.push_back(occi_convertString(occi.getString(12)));
        yiqi_result.push_back(occi_convertString(occi.getString(13)));
        yiqi_result.push_back(occi_convertString(occi.getString(14)));

        if (yiqi_result[1] != "1") {    /* 一轴 */
            p_vehicle_inf->BaoDing_YQ = 2;
        }

        if (yiqi_result[2] != "1") {    /* 二轴 */
            p_vehicle_inf->BaoDing_YQ = 2;
        }

        if (yiqi_result[6] != "1") {    /* 整车 */
            p_vehicle_inf->BaoDing_YQ = 2;
        }

        if (yiqi_result[8] != "1") {    /* 左外灯 */
            p_vehicle_inf->BaoDing_YQ = 2;
        }

        if (yiqi_result[10] != "1") {    /* 右外灯 */
            p_vehicle_inf->BaoDing_YQ = 2;
        }

        ResultCollection tmp;

        /* 10年以上的车和面包车需要判定“驻车” */
        if (tmp.isTenYears(p_vehicle_inf) || (p_vehicle_inf->m_cllx == "K39")) {
            if (yiqi_result[7] != "1") {
                p_vehicle_inf->BaoDing_YQ = 2;
            }
        }
    } else {
        p_vehicle_inf->BaoDing_YQ = 1;    /* 没有找到数据也是不通过 */
    }

    occi.closeQuery();
    occi.terminateStatement();

    /* 无论主机还是从机，都把这个数据写到主机的数据库 */
    DATA_PRINT(LEVEL_INFO, "Start to insert YiQi result...... \n");
    MySQL_DB db;
    if (db.connect(g_master_IP.c_str(), 6033, "root", getDBPassWord(DBPWD).c_str(), "car_schema")) {
        std::string sql;

        if (yiqi_result.size() == 0) {  /* 没有找到仪器判定结果时，也要把LSH写进表里 */
            sql = "(lsh) VALUES (" + p_vehicle_inf->m_jylsh + ")";
        } else {
            sql = "("
                  "lsh, jylsh, yi_zhou, er_zhou, san_zhou, si_zhou, wu_zhou, zheng_che, zhu_che, zwd, "
                  "znd, ywd, ynd, csb, ch"
                  ")"
                  " VALUES "
                  "(";

            sql += "'" + p_vehicle_inf->m_jylsh + "',";

            for (unsigned int i = 0; i < yiqi_result.size(); i++) {
                sql += "'" + yiqi_result[i] + "'";

                if (i != (yiqi_result.size() - 1)) {
                    sql += ",";
                }
            }

            sql += ")";
        }

        db.insert("instrument_result", sql.c_str());
    }

    db.disconnect();
    DATA_PRINT(LEVEL_INFO, "YiQi result has been inserted into the table \"instrument_result\". \n");

    sql = "SELECT * FROM \"TRFFPN_APP\".\"VEH_IS_INSRESULT_DETAIL_E\" WHERE GXSJ >= TO_DATE('";
    sql += std::string(tmpArray);
    sql += "','yyyy-mm-dd') AND LSH = '" + p_vehicle_inf->m_jylsh + "'";

    if (!(occi.createStatement(sql.c_str()) && occi.executeQuery())) {
        DATA_PRINT(LEVEL_ERROR, "createStatement() or executeQuery() fail! \n");
        p_vehicle_inf->BaoDing_JYBG = 1;
        p_vehicle_inf->BaoDing_YQ = 1;
        occi.disconnect();
        return;
    }

    std::vector<JYBG> jybg;
    bool JGPD = true;
    bool JGPD_exist = false;

    while (occi.NotEndFetch()) {
        JGPD_exist = true;
        JYBG result;

        result.item[0] = occi_convertString(occi.getString(1));
        result.item[1] = occi_convertString(occi.getString(2));
        result.item[2] = occi_convertString(occi.getString(3));

        int tmp;
        occi.getInt(4, tmp);
        result.item[3] = std::to_string(tmp);

        result.item[4] = occi_convertString(occi.getString(5));
        result.item[5] = occi_convertString(occi.getString(6));
        result.item[6] = occi_convertString(occi.getString(7));
        result.item[7] = occi_convertString(occi.getString(8));
        result.item[8] = occi_convertString(occi.getString(9));

        date_t date;
        occi.getDate(10, date);
        char tmpArray[64] = { 0 };
        if (date.month == 0) {
            result.item[9] = "NULL";
        } else {
            sprintf(tmpArray, "%d-%02d-%02d %02d:%02d:%02d",
                    date.year, date.month, date.day, date.hour, date.min, date.sec);
            result.item[9] = tmpArray;
        }

        jybg.push_back(result);

        /*
        源oracle数据库的字段是：YQJGPD
        0--未检
        1--合格
        2--不合格
        3--车辆无此项目
        */
        if ((result.item[7] != "1") && (result.item[7] != "3")) {
            JGPD = false;
        }
    }

    if (JGPD_exist) {
        if (JGPD) {
            p_vehicle_inf->BaoDing_JYBG = 0;
        } else {
            p_vehicle_inf->BaoDing_JYBG = 2;
        }
    } else {
        p_vehicle_inf->BaoDing_JYBG = 1;
    }

    occi.closeQuery();
    occi.terminateStatement();
    occi.disconnect();

    DATA_PRINT(LEVEL_INFO, "JYBG result is %d \n", p_vehicle_inf->BaoDing_JYBG);

    /* 无论主机还是从机，都把这个数据写到主机的数据库 */
    DATA_PRINT(LEVEL_INFO, "Start to insert JYBG result...... \n");
    if (db.connect(g_master_IP.c_str(), 6033, "root", getDBPassWord(DBPWD).c_str(), "car_schema")) {

        std::string sqlString;
        for (unsigned int i = 0; i < jybg.size(); i++) {
            sqlString = "("
                        "lsh, jylsh, jyjgbh, xh, yqjyxm, yqjyjg, yqbzxz, yqjgpd, yqjybz, gxsj"
                        ")"
                        " VALUES "
                        "(";

            for (unsigned int k = 0; k < JYBG_ITEM_COUNT; k++) {
                if (jybg[i].item[k] != "NULL") {    /* 插入NULL值时，不能用单引号括起来 */
                    if (jybg[i].item[k] == "'") {
                        jybg[i].item[k] = "\\'";
                    } else if (jybg[i].item[k] == "\"") {
                        jybg[i].item[k] = "\\\"";
                    }

                    sqlString += "'" + jybg[i].item[k] + "'";
                } else {
                    sqlString += jybg[i].item[k];
                }

                if (k != (JYBG_ITEM_COUNT - 1)) {
                    sqlString += ",";
                }
            }

            sqlString += ")";

            db.insert("inspection_report", sqlString.c_str());
        }
    }

    db.disconnect();

    DATA_PRINT(LEVEL_INFO, "JYBG result has been inserted into the table \"inspection_report\". \n");
}

void getDzbdInformation(vehicle_inf *p_vehicle_inf)
{
    // soap 请求数据
    TmriOutAccessSoapBindingProxy soap_dzbd;
    soap_dzbd.accept_timeout = 30;
    soap_dzbd.connect_timeout = 30;
    soap_dzbd.recv_timeout = 30;
    soap_dzbd.send_timeout = 30;
    char *queryReturn = NULL;
    std::string queryString = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><QueryCondition><hpzl>";
    queryString += p_vehicle_inf->m_hpzl;
    queryString += "</hpzl><hphm>";
    string hphm = p_vehicle_inf->m_fzjg.substr(0,3);
    hphm += p_vehicle_inf->m_hphm;
    hphm = URLEncode(hphm);
    queryString += hphm;
    queryString += "</hphm><clsbdh>";
    queryString += p_vehicle_inf->m_clsbdh;
    queryString += "</clsbdh><jyjgbh>";
    queryString += p_vehicle_inf->m_jyjgbh;
    queryString += "</jyjgbh></QueryCondition></root>";
    DATA_PRINT(LEVEL_INFO, "%s dzbd is querying...... \n  msg:%s \n", g_CheckItem.City.c_str(), queryString.c_str());
    soap_dzbd.queryObjectOut("18", (char *)g_strdzbdjkxlh.c_str(), "18C23", (char *)queryString.c_str(), queryReturn);
    DATA_PRINT(LEVEL_INFO, "%s dzbd receive msg:%s \n", g_CheckItem.City.c_str(), queryReturn);

    // 解析soap请求后返回的xml数据, 并判断
    CMarkup xml;
    xml.SetDoc(queryReturn);
    xml.ResetMainPos();
    if(xml.FindElem("root"))
    {
        xml.IntoElem();
        xml.FindElem("head");
        xml.FindChildElem("code");
        std::string str_code = xml.GetChildData();
        if(str_code.find("1") == string::npos)
        {
            p_vehicle_inf->m_jqxdzbd = 2;
            p_vehicle_inf->m_dzjqxbhgyy = "[未查询到电子保单信息]";
            DATA_PRINT(LEVEL_INFO, "未查询到电子保单信息.\n");
            return;
        }
        else if(xml.FindElem("body"))
        {
            xml.IntoElem();
            xml.FindElem("vehispara");
            xml.FindChildElem("sxrq");
            std::string str_sxrq = xml.GetChildData().substr(0,10);
            xml.ResetChildPos();
            xml.FindChildElem("clsbdh");
            std::string str_clsbdh = xml.GetChildData();
            xml.ResetChildPos();
            xml.FindChildElem("zzrq");
            std::string str_zzrq = xml.GetChildData().substr(0,10);
            std::time_t t = std::time(NULL);
            std::tm *st = std::localtime(&t);
            char tmpArray[128] = { 0 };
            sprintf(tmpArray, "%d-%02d-%02d", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);
            std::string str_CurTime = tmpArray;
            if(p_vehicle_inf->m_clsbdh.find(str_clsbdh) == string::npos)
            {
                p_vehicle_inf->m_jqxdzbd = 3;
                p_vehicle_inf->m_dzjqxbhgyy += "[电子保单车架号不匹配]";
                DATA_PRINT(LEVEL_ERROR, "电子保单车架号不匹配.\n");
            } else {
                if((!str_sxrq.empty()) || (!str_zzrq.empty())) {
                    if(!checkTime(str_sxrq, str_zzrq, str_CurTime)) {
                        p_vehicle_inf->m_jqxdzbd = 3;
                        p_vehicle_inf->m_dzjqxbhgyy += "[电子保单日期不正确]";
                        DATA_PRINT(LEVEL_ERROR, "电子保单日期不正确.\n");
                    } else {
                        p_vehicle_inf->m_jqxdzbd = 1;
                    }
                } else {
                    p_vehicle_inf->m_jqxdzbd = 3;
                    p_vehicle_inf->m_dzjqxbhgyy += "[电子保单无日期信息]";
                    DATA_PRINT(LEVEL_INFO, "电子保单无日期信息.\n");
                }
            }
        }
    }

    // 插入suzhou_dzbd数据库
    std::string str_data = queryReturn;
    MySQL_DB db_dzbd;
    if (db_dzbd.connect(NULL, 6033, "root", getDBPassWord(DBPWD).c_str(), "car_schema")) {
        std::string sqlString;
        sqlString = "("
                    "jylsh, hphm, jyjgbh, clsbdh, hpzl, dzjl, dzyy, hfxx, device_id"
                    ")"
                    " VALUES "
                    "(";
        sqlString += "'" + p_vehicle_inf->m_jylsh + "'";
        sqlString += ",";
        sqlString += "'" + p_vehicle_inf->m_hphm + "'";
        sqlString += ",";
        sqlString += "'" + p_vehicle_inf->m_jyjgbh + "'";
        sqlString += ",";
        sqlString += "'" + p_vehicle_inf->m_clsbdh + "'";
        sqlString += ",";
        sqlString += "'" + p_vehicle_inf->m_hpzl + "'";
        sqlString += ",";
        sqlString += "'" + to_string(p_vehicle_inf->m_jqxdzbd) + "'";
        sqlString += ",";
        sqlString += "'" + p_vehicle_inf->m_dzjqxbhgyy + "'";
        sqlString += ",";
        sqlString += "'" + str_data + "'";
        sqlString += ",";
        sqlString += "'" + to_string(g_device_ID) + "'";
        sqlString += ")";
        DATA_PRINT(LEVEL_DEBUG, "Insert into %s dzbd, data: %s \n", g_CheckItem.City.c_str(), sqlString.c_str());
        db_dzbd.insert("suzhou_dzbd", sqlString.c_str());
        db_dzbd.disconnect();

        // 从机写主机数据库
        if (g_SlaveCount == -1) {
            if (db_dzbd.connect(g_master_IP.c_str(), 6033, "root", getDBPassWord(DBPWD).c_str(), "car_schema")) {
                DATA_PRINT(LEVEL_DEBUG, "Insert into %s dzbd master database, data: %s \n", g_CheckItem.City.c_str(), sqlString.c_str());
                db_dzbd.insert("suzhou_dzbd", sqlString.c_str());
                db_dzbd.disconnect();
            } else {
                DATA_PRINT(LEVEL_ERROR, "Insert into %s dzbd master database not connected\n", g_CheckItem.City.c_str());
            }
        }
    } else {
        DATA_PRINT(LEVEL_ERROR, "Insert into %s dzbd database not connected\n", g_CheckItem.City.c_str());
    }
}

void NINGBO_DZBD(vehicle_inf *v_vehicle_inf)
{
    TmriOutAccessSoapBindingProxy soap_ningbo;
    soap_ningbo.accept_timeout = 30;
    soap_ningbo.connect_timeout = 30;
    soap_ningbo.recv_timeout = 30;
    soap_ningbo.send_timeout = 30;
    char *queryReturn = NULL;
    std::string queryString = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><QueryCondition><hpzl>";
    queryString += v_vehicle_inf->m_hpzl;
    queryString += "</hpzl><hphm>";
    string hphm=v_vehicle_inf->m_fzjg.substr(0,3);
    hphm += v_vehicle_inf->m_hphm;
    hphm = URLEncode(hphm);
    queryString += hphm;
    queryString += "</hphm><clsbdh>";
    queryString += v_vehicle_inf->m_clsbdh;
    queryString += "</clsbdh><jyjgbh>";
    queryString += v_vehicle_inf->m_jyjgbh;
    queryString += "</jyjgbh></QueryCondition></root>";
    DATA_PRINT(LEVEL_INFO, "The ningbo dzbd is querying...... \n  msg:%s \n",queryString.c_str());
    soap_ningbo.queryObjectOut("18", "7F1D090903021704001589CB869D8A878084F19F8E849DADFC98BC9BD5CEDAB2D6C7C4DCC9F3BACBCFB5CDB3A3A8BDD3C8EBBCE0B9DCB0B2C8ABD2AAC7F3A3A9", "18C23", (char *)queryString.c_str(), queryReturn);
    //queryReturn="<?xml version=\"1.0\" encoding=\"GBK\"?><root><head><code>1</code><message>%E6%95%B0%E6%8D%AE%E4%B8%8B%E8%BD%BD%E6%88%90%E5%8A%9F%EF%BC%81</message><rownum>1</rownum></head><body><vehispara id=\"0\"><bxgs>%E4%B8%AD%E5%9B%BD%E5%B9%B3%E5%AE%89%E8%B4%A2%E4%BA%A7%E4%BF%9D%E9%99%A9%E8%82%A1%E4%BB%BD%E6%9C%89%E9%99%90%E5%85%AC%E5%8F%B8</bxgs><sxrq>2018-07-17+00%3A00%3A00.0</sxrq><bbxrsfzmhm>%E6%97%A0</bbxrsfzmhm><jyw></jyw><gxsj>2019-06-10+13%3A38%3A21.0</gxsj><wspzhm></wspzhm><bxgsdm>PAIC</bxgsdm><nsrsbh></nsrsbh><nsr></nsr><hphm>%E6%B5%99BKJ728</hphm><ccsnsqk>1</ccsnsqk><ccsnsje></ccsnsje><ccsnsrq></ccsnsrq><ccsnszzrq></ccsnszzrq><csbj></csbj><jqxtbzt>1</jqxtbzt><ccsnsqsrq></ccsnsqsrq><hpzl>02</hpzl><bbxr>%E6%97%A0</bbxr><bxdh>12904133900454651947</bxdh><clsbdh>LBEHDAEB99Y269150</clsbdh><zzrq>2019-04-17+00%3A00%3A00.0</zzrq></vehispara></body></root>";
    //queryReturn = (char*)URLDecode(queryReturn).c_str();
    //queryReturn = "<?xml version=\"1.0\" encoding=\"GBK\"?><root><head><code>%24E</code><message>%E6%9C%8D%E5%8A%A1%E5%99%A8%E7%AB%AF%E6%8F%90%E7%A4%BA%E4%BF%A1%E6%81%AF%EF%BC%9Ajava.lang.Exception%3A+%E6%9F%A5%E8%AF%A2%E8%AF%B7%E6%B1%82%E5%B7%B2%E5%8F%91%E9%80%81%EF%BC%8C%E8%AF%B7%E7%A1%AE%E8%AE%A4%E4%BF%A1%E6%81%AF%E6%97%A0%E8%AF%AF%E5%90%8E%EF%BC%8C%E7%AD%89%E5%BE%855-10%E7%A7%92%E5%86%8D%E8%AF%95%EF%BC%81+%E5%AF%B9%E6%9C%AA%E6%9F%A5%E8%AF%A2%E4%BA%A4%E5%BC%BA%E9%99%A9%E6%88%96%E8%BD%A6%E8%88%B9%E7%A8%8E%E7%94%B5%E5%AD%90%E4%BF%A1%E6%81%AF%E7%9A%84%2C%E8%AF%B7%E5%91%8A%E7%9F%A5%E8%BD%A6%E4%B8%BB%E6%8F%90%E4%BA%A4%E5%87%AD%E8%AF%81%EF%BC%81</message></head></root>";
    if(queryReturn == NULL)
    {
        DATA_PRINT(LEVEL_INFO, "The ningbo dzbd receive empty \n");
        return;
    }
    DATA_PRINT(LEVEL_INFO, "The ningbo dzbd receive...... \n  msg:%s \n",queryReturn);
    CMarkup xml;
    xml.SetDoc(queryReturn);
    xml.ResetMainPos();
    if(xml.FindElem("root"))
    {
        xml.IntoElem();
        xml.FindElem("head");
        xml.FindChildElem("code");
        string code = xml.GetChildData();
        if(code.find("1") == string::npos)
        {
            v_vehicle_inf->b_jqxdzbd = 2;
            v_vehicle_inf->dzjqxbhgyy = "[未查询到电子报单信息]";
            DATA_PRINT(LEVEL_INFO, "There is no ningbo dzbd receive...... \n");
            return;
        }
        else if(xml.FindElem("body"))
        {
            xml.IntoElem();
            xml.FindElem("vehispara");
            xml.FindChildElem("sxrq");
            string sxrq = xml.GetChildData().substr(0,10);
            xml.ResetChildPos();
            xml.FindChildElem("clsbdh");
            string clsbdh = xml.GetChildData();
            xml.ResetChildPos();
            xml.FindChildElem("zzrq");
            string zzrq =xml.GetChildData().substr(0,10);
            std::time_t t = std::time(NULL);
            std::tm *st = std::localtime(&t);
            char tmpArray[128] = { 0 };
            sprintf(tmpArray, "%d-%02d-%02d", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);
            std::string strCurTime = tmpArray;
            if(v_vehicle_inf->m_clsbdh.find(clsbdh) == string::npos)
            {
                v_vehicle_inf->b_jqxdzbd = 3;
                v_vehicle_inf->dzjqxbhgyy += "[电子保单车架号不匹配]";
            }
            else
            {
                if((!sxrq.empty())||(!zzrq.empty()))
                {
                    if(!checkTime(sxrq,zzrq,strCurTime))
                    {
                        v_vehicle_inf->b_jqxdzbd = 3;
                        v_vehicle_inf->dzjqxbhgyy += "[电子保单日期不正确]";
                    }
                    else
                    {
                        v_vehicle_inf->b_jqxdzbd = 1;
                    }
                }
                else
                {
                    v_vehicle_inf->b_jqxdzbd = 3;
                    v_vehicle_inf->dzjqxbhgyy += "[电子保单无日期信息]";
                }
            }
        }
    }
    string data = queryReturn;
    MySQL_DB db_dzbd;
    if (db_dzbd.connect(NULL, 6033, "root", getDBPassWord(DBPWD).c_str(), "car_schema")) {
        std::string sqlString;
        sqlString = "("
                    "jylsh, hphm, jyjgbh, clsbdh, hpzl, dzjl, dzyy, hfxx, device_id"
                    ")"
                    " VALUES "
                    "(";
        sqlString += "'" + v_vehicle_inf->m_jylsh + "'";
        sqlString += ",";
        sqlString += "'" + v_vehicle_inf->m_hphm + "'";
        sqlString += ",";
        sqlString += "'" + v_vehicle_inf->m_jyjgbh + "'";
        sqlString += ",";
        sqlString += "'" + v_vehicle_inf->m_clsbdh + "'";
        sqlString += ",";
        sqlString += "'" + v_vehicle_inf->m_hpzl + "'";
        sqlString += ",";
        sqlString += "'" + to_string(v_vehicle_inf->b_jqxdzbd) + "'";
        sqlString += ",";
        sqlString += "'" + v_vehicle_inf->dzjqxbhgyy + "'";
        sqlString += ",";
        sqlString += "'" + data + "'";
        sqlString += ",";
        sqlString += "'" + to_string(g_device_ID) + "'";
        sqlString += ")";
        DATA_PRINT(LEVEL_DEBUG, "Insert into ningbo_dzbd, data: %s \n", sqlString.c_str());
        db_dzbd.insert("suzhou_dzbd", sqlString.c_str());
        db_dzbd.disconnect();
        }
    else {
        DATA_PRINT(LEVEL_DEBUG, "Insert into ningbo_dzbd database not connected\n");
    }
    if((g_SlaveCount==-1)&&(g_CheckItem.City==NINGBO)) {
        if (db_dzbd.connect(g_master_IP.c_str(), 6033, "root", getDBPassWord(DBPWD).c_str(), "car_schema")) {
            std::string sqlString;
            sqlString = "("
                        "jylsh, hphm, jyjgbh, clsbdh, hpzl, dzjl, dzyy, hfxx, device_id"
                        ")"
                        " VALUES "
                        "(";
            sqlString += "'" + v_vehicle_inf->m_jylsh + "'";
            sqlString += ",";
            sqlString += "'" + v_vehicle_inf->m_hphm + "'";
            sqlString += ",";
            sqlString += "'" + v_vehicle_inf->m_jyjgbh + "'";
            sqlString += ",";
            sqlString += "'" + v_vehicle_inf->m_clsbdh + "'";
            sqlString += ",";
            sqlString += "'" + v_vehicle_inf->m_hpzl + "'";
            sqlString += ",";
            sqlString += "'" + to_string(v_vehicle_inf->b_jqxdzbd) + "'";
            sqlString += ",";
            sqlString += "'" + v_vehicle_inf->dzjqxbhgyy + "'";
            sqlString += ",";
            sqlString += "'" + data + "'";
            sqlString += ",";
            sqlString += "'" + to_string(g_device_ID) + "'";
            sqlString += ")";
            DATA_PRINT(LEVEL_DEBUG, "Insert into ningbo_dzbd for MASTER, data: %s \n", sqlString.c_str());
            db_dzbd.insert("suzhou_dzbd", sqlString.c_str());
            db_dzbd.disconnect();
            }
        else {
            DATA_PRINT(LEVEL_DEBUG, "Insert into ningbo_dzbd for MASTER database not connected\n");
        }
    }
}

void NINGBO_BLACKLIST(vehicle_inf *p_vehicle_inf)
{
     const char* Ip;
    if (g_SlaveCount == -1) {
        Ip = g_master_IP.c_str();
    }
    else
    {
        Ip = NULL;
    }


        DATA_PRINT(LEVEL_INFO, "Write data into the remote database(%s)...... \n", Ip);
        MySQL_DB db;
        if (db.connect(Ip, 6033, "root", getDBPassWord(DBPWD).c_str(), "car_schema")) {
            /* 准备写入表vehicle_checks的数据 */
            std::string sqlString;
            sqlString = "select clsbdh from  black_list where clsbdh = '";
            sqlString += p_vehicle_inf->m_clsbdh;
            sqlString += "' ";
            MYSQL_RES *result = NULL;
            DATA_PRINT(LEVEL_INFO, "blacklist_sqlString:%s \n",sqlString.c_str());
            result=db.getResult(sqlString.c_str());
            if (result != NULL) {
                if (result->row_count != 0) {
                  p_vehicle_inf->is_black_list =true;
                }
            }
            db.disconnect();
        }
        else
        {
            DATA_PRINT(LEVEL_INFO, "can not connect database(for black list)...... \n");
            return;
        }
}

/* 清理保定FTP下载照片 */
void BaoDing_ClearFtpPic()
{
    std::string FTP_host = "192.168.8.240";
    std::string account = "citic";
    std::string password = "citic";

    DATA_PRINT(LEVEL_INFO, "Start clean BaoDing FTP download-picture...... \n");

    netbuf *conn = NULL;
    if (!FtpConnect(FTP_host.c_str(), &conn)) {
        DATA_PRINT(LEVEL_ERROR, "Can not connect to FTP server: %s \n", FTP_host.c_str());
        return;
    }

    if (!FtpLogin(account.c_str(), password.c_str(), conn)) {
        DATA_PRINT(LEVEL_ERROR, "FtpLogin() failure: %s \n", FtpLastResponse(conn));
        FtpQuit(conn);
        return;
    }

    if (!FtpNlst((BAODING_TXT_DIR + "in_list").c_str(), "/in", conn)) {
        DATA_PRINT(LEVEL_ERROR, "FtpNlst() failure: %s \n", FtpLastResponse(conn));
        FtpQuit(conn);
        return;
    }

    FILE *fp = std::fopen((BAODING_TXT_DIR + "in_list").c_str(), "r");
    if (!fp) {
        DATA_PRINT(LEVEL_ERROR, "fopen failure! \n");
        FtpQuit(conn);
        return;
    }

    char buf[256] = {0};
    while (std::fgets(buf, sizeof(buf), fp) != NULL) {
        /* 这一步是为了去掉换行符，并不多余 */
        char jpg_name[64] = {0};
        std::sscanf(buf, "/in/%s.jpg", jpg_name);
        std::string file_name = "/in/" + std::string(jpg_name);

        if (!FtpDelete(file_name.c_str(), conn)) {
            DATA_PRINT(LEVEL_ERROR, "FtpDelete() failure, path: %s \n", file_name.c_str());
        }
    }

    if (std::ferror(fp)) {
        DATA_PRINT(LEVEL_ERROR, "I/O error when reading!! \n");
    }

    std::fclose(fp);

    FtpQuit(conn);
}

void SUZHOU_DianZiHuanBaoDan(vehicle_inf *p_vehicle_inf)
{
    const char* Ip;
   if (g_SlaveCount == -1) {
       Ip = g_master_IP.c_str();
   }
   else
   {
       Ip = NULL;
   }
       DATA_PRINT(LEVEL_INFO, "Write data into the remote database(%s)...... \n", Ip);
       MySQL_DB db;
       if (db.connect(Ip, 6033, "root", getDBPassWord(DBPWD).c_str(), "car_schema")) {
           /* 准备写入表vehicle_checks的数据 */
           std::string sqlString;
           sqlString = "select id, pass,jcrq from dz_wq where clsbdh = '";
           sqlString += p_vehicle_inf->m_clsbdh;
           sqlString += "' ";
           sqlString += " order by id desc";
           MYSQL_RES *result = NULL;
           MYSQL_ROW row = NULL;
           result=db.getResult(sqlString.c_str());
           row = mysql_fetch_row(result);
           if (row != NULL) {
               p_vehicle_inf->is_dz_wq = true;
               string row_0 = row[1];
               if(row_0 == "1")
               {
                   p_vehicle_inf->dz_wq_pass = true;
               }
               else
               {
                   p_vehicle_inf->dz_wq_pass = false;
               }

               p_vehicle_inf->dz_wqjcrq = row[2];

           } else {
               p_vehicle_inf->is_dz_wq=false;
           }
           DATA_PRINT(LEVEL_INFO, "dz_wq:%s \n",sqlString.c_str());
           db.disconnect();
       }
       else
       {
           DATA_PRINT(LEVEL_INFO, "can not connect database(for dz_wq)...... \n");
           return;
       }
}

/* 结合download_queue，toanalyse_queue，reply_queue这3个对象当前的状态，判定机器是否“忙碌”。 */
bool deviceIsBusy()
{
    unsigned int q1_size = download_queue.Size();
    unsigned int q2_size = toanalyse_queue.Size();
    unsigned int q3_size = reply_queue.Size();
    unsigned int total = q1_size + q2_size + q3_size;

    unsigned int download_max = 2;
    unsigned int per_GPU_max = 2;  /* 设定每个GPU允许存储在toanalyse_queue的数量 */
    unsigned int reply_max = 3;

    unsigned int max = download_max + gpu_numbers * per_GPU_max + reply_max;
    if (total > (max / 2)) {    /* 整体达到最大值的一半，即判定忙碌 */
        DATA_PRINT(LEVEL_INFO, "Device is busy now, details: download=%d, toanalyse=%d, reply=%d \n", q1_size, q2_size, q3_size);
        return true;
    }

    /* 判定每个队列的状态 */
    if ((q1_size > download_max)
            || (q2_size > gpu_numbers * per_GPU_max)
            || (q3_size > reply_max)) {
        DATA_PRINT(LEVEL_INFO, "Device is busy now, details: download=%d, toanalyse=%d, reply=%d \n", q1_size, q2_size, q3_size);
        return true;
    }

    return false;
}

/* 本机IP是否被指定为处理特定车辆的机器 */
bool isTargetDevice()
{
    for (unsigned int i = 0; i < g_CheckItem.JianYanJiGou.size(); i++) {
        if (g_CheckItem.JianYanJiGou[i].assignment_IP == g_localServerIp) {
            return true;
        }
    }

    return false;
}

/* 主机数据分配线程 */
void distribution_thread()
{
    DATA_PRINT(LEVEL_INFO, "distribution_thread running...... \n");

    while (true) {
        vehicle_inf *v_vehicle_inf = NULL;
        v_vehicle_inf = toDistribute_queue.Take();
        DATA_PRINT(LEVEL_INFO, "=======================toDistribute_queue:%d=========================\n", toDistribute_queue.Size());

        if (g_SlaveCount > 0) {
            std::string Target_IP;

            for (unsigned int i = 0; i < g_CheckItem.JianYanJiGou.size(); i++) {
                if (!g_CheckItem.JianYanJiGou[i].assignment_IP.empty()
                        && (g_CheckItem.JianYanJiGou[i].bh == v_vehicle_inf->m_jyjgbh)) {
                    Target_IP = g_CheckItem.JianYanJiGou[i].assignment_IP;
                    break;
                }
            }

            if (!Target_IP.empty()) {
                if (distributeAssignment_IP(v_vehicle_inf, Target_IP)) {
                    continue;
                }
            }

            if (!DistributeData(v_vehicle_inf)) {

                /* 主机判断自身是否忙碌 */
                if (deviceIsBusy()) {
                    toDistribute_queue.RePut(v_vehicle_inf);
                    DATA_PRINT(LEVEL_INFO,
                               "Master itself is too busy, LSH(%s) is put in the toDistribute_queue again. \n\n",
                               v_vehicle_inf->m_jylsh.data());
                } else {
                    recordRevCarInfo(v_vehicle_inf,true);
                    download_queue.Put(v_vehicle_inf);
                }
            }
        } else {
            download_queue.Put(v_vehicle_inf);
        }
    }
}

/* 将车辆信息发送给指定IP */
bool distributeAssignment_IP(vehicle_inf *v_vehicle_inf, std::string assignment_IP)
{
    std::string port;

    /* 通过从机列表，获取该IP对应的端口 */
    for (unsigned int i = 0; i < SlaveList.size(); i++) {
        if (assignment_IP == SlaveList[i].ip) {
            port = SlaveList[i].port;
            break;
        }
    }

    if (port.empty()) {
        DATA_PRINT(LEVEL_ERROR,
                   "Could not send LSH(%s) to IP(%s), no port. \n",
                   v_vehicle_inf->m_jylsh.data(),
                   assignment_IP.data());
        return false;
    }

    HttpClient request;
    char url_temp[256];
    sprintf(url_temp, "http://%s:%s", assignment_IP.c_str(), port.c_str());
    std::string vehicleurl = url_temp;
    vehicleurl += g_requestUri;

    std::string xmldata;
    sprintf(url_temp, "xtlb=%s&jkxlh=%s&jkid=%s&xmlDoc=", VEHICLE_XTLB, g_confJkxlh.c_str(), VEHICLE_JKID);
    xmldata = url_temp;
    xmldata += Prepare_Xml_Data(v_vehicle_inf);
    if (request.InitData(vehicleurl.c_str(), REQUEST_POST_FLAG, HTTP_CONTENT_TYPE_URL_ENCODED, (char *)xmldata.c_str())) {
        request.set_retries_timeout(1, 2);
        request.startHttpClient();
    }

    if (!request.d_success_flag) {
        DATA_PRINT(LEVEL_ERROR, "Target IP(%s) no response! \n", assignment_IP.c_str());
        return false;
    }

    if (request.ResponseData.empty()) {
        DATA_PRINT(LEVEL_ERROR, "Target IP(%s) response is empty! \n", assignment_IP.c_str());
        return false;
    }

    if (analyseSlaveReply(request.ResponseData)) {
        DATA_PRINT(LEVEL_INFO, "LSH(%s) has been distributed to target: %s \n\n", v_vehicle_inf->m_jylsh.data(), assignment_IP.c_str());
        delete v_vehicle_inf;
    } else {
        toDistribute_queue.Put(v_vehicle_inf);
        DATA_PRINT(LEVEL_INFO, "Target(%s) is too busy, LSH(%s) is put in the toDistribute_queue back. \n", assignment_IP.c_str(), v_vehicle_inf->m_jylsh.data());
    }

    return true;
}

/* 通过SOAP接口，发出照片的判定结果 */
void sendPhotoResult(const vehicle_inf *p_vehicle, int zplist_index, std::string data)
{
    int send_count = 5;

    while (send_count != 0) {
        TmriOutAccessSoapBindingProxy soapclient;
        vehicle_inf lsh_vehicle_inf;
        char *writeReturn = NULL;

        soapclient.accept_timeout = 10;
        soapclient.connect_timeout = 10;
        soapclient.recv_timeout = 10;
        soapclient.send_timeout = 10;

        DATA_PRINT(LEVEL_INFO, "Send photo(LSH:%s, ZPZL:%s) result to SOAP server...... \n",
                   p_vehicle->m_jylsh.data(),
                   zplist_index == -1 ? "zplist is empty" : p_vehicle->m_zplist[zplist_index].zptype.data() );
        soapclient.writeObjectOut("18", (char *)g_confJkxlh.c_str(), "18C92", (char *)(data.c_str()), writeReturn);
        if(writeReturn != NULL)
        {
            DATA_PRINT(LEVEL_INFO,"SOAP SERVER has received the result :%s\n" ,(char*)URLDecode(writeReturn).c_str());
        }
        if (writeReturn != NULL) {
            if (Analyse_QueryReturn_Data((char *)URLDecode(writeReturn).c_str(), &lsh_vehicle_inf, 0) < 0) {
                DATA_PRINT(LEVEL_ERROR, "SOAP server response of photo(LSH:%s, ZPZL:%s) result is incorrect! \n",
                           p_vehicle->m_jylsh.data(),
                           zplist_index == -1 ? "zplist is empty" : p_vehicle->m_zplist[zplist_index].zptype.data() );
            } else {
                DATA_PRINT(LEVEL_INFO, "SOAP server has received the photo(LSH:%s, ZPZL:%s) result successfully. \n",
                           p_vehicle->m_jylsh.data(),
                           zplist_index == -1 ? "zplist is empty" : p_vehicle->m_zplist[zplist_index].zptype.data() );
            }

            return;
        }

        DATA_PRINT(LEVEL_ERROR, "SOAP server has no response to photo(LSH:%s, ZPZL:%s) result! \n",
                   p_vehicle->m_jylsh.data(),
                   zplist_index == -1 ? "zplist is empty" : p_vehicle->m_zplist[zplist_index].zptype.data() );

        send_count--;
    }
}

void sendAllPhotoResult(const vehicle_inf *p_vehicle, int zplist_index, std::string data)
{
    UNUSED(p_vehicle);UNUSED(zplist_index);
    int send_count = 2;

    while (send_count != 0) {
        TmriOutAccessSoapBindingProxy soapclient;
        vehicle_inf lsh_vehicle_inf;
        char *writeReturn = NULL;

        soapclient.accept_timeout = 10;
        soapclient.connect_timeout = 10;
        soapclient.recv_timeout = 10;
        soapclient.send_timeout = 10;

        DATA_PRINT(LEVEL_INFO, "Send allphoto result to SOAP server...... \n");
        soapclient.writeObjectOut("18", (char *)g_confJkxlh.c_str(), "18C92", (char *)data.c_str(), writeReturn);

        if (writeReturn != NULL) {
            DATA_PRINT(LEVEL_INFO, "SOAP server has received  result successfully : \n %s \n",(char *)URLDecode(writeReturn).c_str());
        }
        else
        {
            DATA_PRINT(LEVEL_ERROR, "SOAP server's writeReturn is empty\n");
        }
//        if (writeReturn != NULL) {
//            if (Analyse_QueryReturn_Data((char *)URLDecode(writeReturn).c_str(), &lsh_vehicle_inf, 0) < 0) {
//                DATA_PRINT(LEVEL_ERROR, "SOAP server response of photo(LSH:%s, ZPZL:%s) result is incorrect! \n",
//                           p_vehicle->m_jylsh.data(),
//                           zplist_index == -1 ? "zplist is empty" : p_vehicle->m_zplist[zplist_index].zptype.data() );
//            } else {
//                DATA_PRINT(LEVEL_INFO, "SOAP server has received the photo(LSH:%s, ZPZL:%s) result successfully. \n",
//                           p_vehicle->m_jylsh.data(),
//                           zplist_index == -1 ? "zplist is empty" : p_vehicle->m_zplist[zplist_index].zptype.data() );
//            }

//            return;
//        }

//        DATA_PRINT(LEVEL_ERROR, "SOAP server has no response to photo(LSH:%s, ZPZL:%s) result! \n",
//                   p_vehicle->m_jylsh.data(),
//                   zplist_index == -1 ? "zplist is empty" : p_vehicle->m_zplist[zplist_index].zptype.data() );

        send_count--;
    }
}

void TIANJIN_OracleDate(vehicle_inf *p_vehicle_inf)
{
    occi_wrap occi;
    if (!occi.connect("zdsh", "ZDSH", "172.16.99.100:1521/yccy")) {
        DATA_PRINT(LEVEL_ERROR, "Can not connect to Oracle database: 172.16.99.100:1521/yccy \n");
        return;
    }

    DATA_PRINT(LEVEL_INFO, "SELECT FROM  Oracle database: 172.16.99.100:1521/yccy \n");
    std::string sql;
    sql = "SELECT HPHM,CLSBDH FROM \"ZDSH\".\"W_VEH_ZZZB\" "
          "WHERE CLSBDH = '" + p_vehicle_inf->m_clsbdh + "' ";

    if (!(occi.createStatement(sql.c_str()) && occi.executeQuery())) {
        DATA_PRINT(LEVEL_ERROR, "createStatement() or executeQuery() fail, sql statement: %s \n", sql.data());
        occi.disconnect();
        return;
    }
    DATA_PRINT(LEVEL_INFO, "SELECT FROM  Oracle database: 172.16.99.100:1521/yccy \n");
    if(occi.NotEndFetch())
    {
        p_vehicle_inf->is_chepai_off=true;
        DATA_PRINT(LEVEL_INFO, "is_chepai_off  TRUE !!!!!!!!!!!!!!!!!! \n");
    }
    DATA_PRINT(LEVEL_INFO, "Oracle database: 172.16.99.100:1521/yccy  FINISH !!!!!! \n");

}

void videoCheckSerch()
{
    DATA_PRINT(LEVEL_INFO, "videoCheckSerch into the database(localhost)...... \n");
    MySQL_DB db;
    if(db.connect("localhost", 6033, "root", getDBPassWord(DBPWD).c_str(), "car_schema")) {
        //查询待检测数据库号牌号码
        std::string sqlString;
        std::string videoHphm;

//        std::time_t t = std::time(NULL);
//        std::tm *st = std::localtime(&t);
//        char tmpArray[128] = { 0 };
//        sprintf(tmpArray, "%d-%02d-%02d", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday - 1);
//        std::string strCurTime = tmpArray;
//        sqlString = "select hphm from check_video_infos where check_flag != '1' and created >'";
//        sqlString += strCurTime;
//        sqlString += "' order by id desc";


        sqlString = "select hphm from check_video_infos where check_flag != '1' order by id desc";
        MYSQL_RES *result = NULL;
        MYSQL_ROW row = NULL;
        result = db.getResult(sqlString.c_str());
        row = mysql_fetch_row(result);
        if (row != NULL) {
           videoHphm = row[0];
           DATA_PRINT(LEVEL_INFO, "videoCheckSerch查询待检测数据库号牌号码:%s ...... \n" , videoHphm.c_str());
        }
        else
        {
           DATA_PRINT(LEVEL_INFO, "videoCheckSerch查询待检测数据库号牌号码为空 ...... \n");
           db.freeResult(result);
           db.disconnect();
           return;
        }
        db.freeResult(result);
        //第二次查询数据库查询该号码所有视频信息
        result = NULL;
        row = NULL;
        sqlString = "select id , jylsh, jyjgbh, hphm, clsbdh, cllx, spzl, spurl, jcxbh, sxtbh, sjks, sjjs, check_flag from check_video_infos where check_flag != '1' and  hphm = '";
        sqlString += videoHphm;
        sqlString += "' order by id";
        result =db.getResult(sqlString.c_str());
        vehicle_inf * p_vehicle_inf = NULL;
        vector<string> id_list;
        if(result != NULL)
        {
           p_vehicle_inf = new vehicle_inf;
           while ((row = mysql_fetch_row(result)) != NULL) {
               if(p_vehicle_inf->m_jylsh == "无数据") {
                   p_vehicle_inf->m_jylsh = row[1];
               } if(p_vehicle_inf->m_jyjgbh == "无数据") {
                   p_vehicle_inf->m_jyjgbh = row[2];
               } if(p_vehicle_inf->m_hphm == "无数据") {
                   p_vehicle_inf->m_hphm = row[3];
                   p_vehicle_inf->m_hphm = p_vehicle_inf->m_hphm.substr(3,p_vehicle_inf->m_hphm.size());
               } if(p_vehicle_inf->m_clsbdh == "无数据") {
                   p_vehicle_inf->m_clsbdh = row[4];
               } if(p_vehicle_inf->m_cllx == "无数据") {
                   p_vehicle_inf->m_cllx = row[5];
               }
               _video_resource video_info;
               //去重复


               video_info.id = row[0];
               id_list.push_back(video_info.id);
               //video_info.spurl = "ftp://192.168.40.22/HK_bottom083125.mp4"; //for test
               video_info.spurl = row[7];
               if(g_CheckItem.City == YICHUN)
               {
                   video_info.spzl = row[6];
               }
               else
               {
                   video_info.spzl = "V";
                   video_info.spzl += row[6];
               }

               video_info.sptype = video_info.spzl;
               unsigned int k;
               for(k = 0; k < p_vehicle_inf->m_splist.size() ; k++)
               {
                   if(video_info.spzl == p_vehicle_inf->m_splist[k].spzl)
                   {
                       p_vehicle_inf->m_splist[k].id = row[0];
                       //p_vehicle_inf->m_splist[k].spurl = "ftp://192.168.40.22/HK_bottom083125.mp4";//for test
                       p_vehicle_inf->m_splist[k].spurl = row[7];
                       if(g_CheckItem.City == YICHUN)
                       {
                           video_info.spzl = row[6];
                       }
                       else
                       {
                           p_vehicle_inf->m_splist[k].spzl = "V";
                           p_vehicle_inf->m_splist[k].spzl += row[6];
                       }

                       p_vehicle_inf->m_splist[k].sptype = p_vehicle_inf->m_splist[k].spzl;
                       break;
                   }
               }
               if( k == p_vehicle_inf->m_splist.size())
               {
                   p_vehicle_inf->m_splist.push_back(video_info);
               }
           }
           p_vehicle_inf->is_video_check = true;
        }
        db.freeResult(result);

        //第三次查询vehicle_check_id视频结果与主表关联
        result = NULL;
        row = NULL;
        sqlString = "select id ,hphm from vehicle_checks where   hphm = '";
        sqlString += p_vehicle_inf->m_hphm;
        sqlString += "' order by id desc";
        result =db.getResult(sqlString.c_str());
        row = mysql_fetch_row(result);
        if(row != NULL)
        {
            p_vehicle_inf->vehicle_check_video_id = row[0];
        }
        db.freeResult(result);
        //更新数据状态vehicle_checks
        if(p_vehicle_inf->vehicle_check_video_id == "无数据")
        {
           p_vehicle_inf->vehicle_check_video_id = "0";
           DATA_PRINT(LEVEL_INFO, "查询到车辆图片审核信息，不更新视频审核标记，vehicle_check_id 默认设置为1 \n");
        }
        else
        {
           DATA_PRINT(LEVEL_INFO, "未查询到车辆图片审核信息，更新视频审核标记\n");
           sqlString = "SET is_video_check = '1' WHERE id='";
           sqlString += p_vehicle_inf->vehicle_check_video_id;
           sqlString += "'";
           if(!db.update("vehicle_checks",sqlString.c_str()))
           {
               DATA_PRINT(LEVEL_INFO, "vehicle_checks视频审核标记插入失败\n");
           };
        }
        DATA_PRINT(LEVEL_DEBUG, "update into vehicle_checks, data: %s \n", sqlString.c_str());
        //更新数据状态check_video_infos
        for(unsigned k = 0; k < id_list.size(); k++)
        {
            sqlString = "SET check_flag = '1' WHERE id='";
            sqlString += id_list[k];
            sqlString += "'";
            if(!db.update("check_video_infos",sqlString.c_str()))
            {
               DATA_PRINT(LEVEL_INFO, "check_video_infos视频审核标记插入失败\n");
            };
            DATA_PRINT(LEVEL_DEBUG, "update into check_video_infos, data: %s \n", sqlString.c_str());
        }


        download_queue.Put(p_vehicle_inf);//主机测试
        //toDistribute_queue.Put(p_vehicle_inf);//分发测试
        db.disconnect();
    } else {
        db.disconnect();
        DATA_PRINT(LEVEL_ERROR, "database(localhost) for videoCheckSerch failed...... \n");
    }
}

void YICHUN_VideoCheckSerch(vehicle_inf *p_vehicle_inf)
{
    DATA_PRINT(LEVEL_INFO, "yichun videoCheckSerch  the database(master)...... \n");
    MySQL_DB db;
    if(db.connect(g_master_IP.c_str(), 6033, "root", "em-data-9527", "car_schema")) {

        std::string sqlString;
        MYSQL_RES *result = NULL;
        MYSQL_ROW row = NULL;

        //数据库查询该检验流水号所有视频信息
        sqlString = "select id , jylsh, jyjgbh, hphm, clsbdh, cllx, spzl, spurl, jcxbh, sxtbh, sjks, sjjs, check_flag from check_video_infos where jylsh= '";
        sqlString += p_vehicle_inf->m_jylsh2;
        sqlString += "' order by id";
        result =db.getResult(sqlString.c_str());

        if(result != NULL)
        {

           while ((row = mysql_fetch_row(result)) != NULL) {
               _video_resource video_info;
               //去重复
               video_info.id = row[0];

               //video_info.spurl = "ftp://192.168.40.22/HK_bottom083125.mp4"; //for test
               video_info.spurl = row[7];
             //  video_info.spzl = "V";
               video_info.spzl = row[6];
               video_info.sptype = video_info.spzl;
               unsigned int k;
               for(k = 0; k < p_vehicle_inf->m_splist.size() ; k++)
               {
                   if(video_info.spzl == p_vehicle_inf->m_splist[k].spzl)
                   {
                       p_vehicle_inf->m_splist[k].id = row[0];
                       //p_vehicle_inf->m_splist[k].spurl = "ftp://192.168.40.22/HK_bottom083125.mp4";//for test
                       p_vehicle_inf->m_splist[k].spurl = row[7];
                     //  p_vehicle_inf->m_splist[k].spzl = "V";
                       p_vehicle_inf->m_splist[k].spzl = row[6];
                       p_vehicle_inf->m_splist[k].sptype = p_vehicle_inf->m_splist[k].spzl;
                       break;
                   }
               }
               if( k == p_vehicle_inf->m_splist.size())
               {
                   p_vehicle_inf->m_splist.push_back(video_info);
               }
           }
           if(p_vehicle_inf->m_splist.size() > 0)
           {
               p_vehicle_inf->is_video_check_shizhong = true;
               char tmp[32];
               unsigned int size = p_vehicle_inf->m_splist.size();
               itoa(size, tmp, 10);
               p_vehicle_inf->m_spzs = std::string(tmp);
               DATA_PRINT(LEVEL_INFO, "video_check_shizhong:%d, size of splist:%d\n", p_vehicle_inf->is_video_check_shizhong, p_vehicle_inf->m_splist.size());
           }
        }
        db.freeResult(result);
        db.disconnect();

    } else {
        db.disconnect();
        DATA_PRINT(LEVEL_ERROR, "database(localhost) for yichun videoCheckSerch failed...... \n");
    }
}


/*
    将从机收到的车辆信息插入recv_carinfo表中
*/
BOOL recordRevCarInfo(vehicle_inf *pvehicle_inf,BOOL flage)/*flage TRUE为主机  FALSE 为从机*/
{
    DATA_PRINT(LEVEL_INFO,"Salve into recordCarinfo ...\n");

    if(pvehicle_inf == NULL)
    {
        return FALSE;
    }
    std::string sqlString;
    std::string ip;

    sqlString =  "(jylsh,hphm,clsbdh,device_id,IP)";
    sqlString += "VALUES (";
    sqlString += "'"+pvehicle_inf->m_jylsh+"',";
    sqlString += "'"+pvehicle_inf->m_hphm+"',";
    sqlString += "'"+pvehicle_inf->m_clsbdh+"',";
    sqlString += "'"+std::to_string(g_device_ID)+"',";
    sqlString += "'"+g_localServerIp+"'";
    sqlString += ")";

    MySQL_DB db;
    if(db.connect("localhost", 6033, "root", getDBPassWord(DBPWD).c_str(), "car_schema"))
    {
        db.insert("recv_carinfo",sqlString.c_str());
    }
    db.disconnect();
    if(!flage)
    {
        if(db.connect(g_master_IP.c_str(), 6033, "root", getDBPassWord(DBPWD).c_str(), "car_schema"))
        {
            db.insert("recv_carinfo",sqlString.c_str());
        }
        db.disconnect();
    }


    return TRUE;

}


/*
    判别是否未复检
*/
bool isReCheck(string lsh)/*flage TRUE为主机  FALSE 为从机*/
{
    const char* Ip;
    if (g_SlaveCount == -1) {
       Ip = g_master_IP.c_str();
    }
    else
    {
       Ip = NULL;
    }
    MySQL_DB db;
    MYSQL_RES *result = NULL;
    MYSQL_ROW row = NULL;
    string sqlstr;
    if(db.connect(Ip, 6033, "root", getDBPassWord(DBPWD).c_str(), "car_schema"))
    {
        std::time_t t = std::time(NULL);
        std::tm *st = std::localtime(&t);
        char tmpArray[128] = { 0 };
        sprintf(tmpArray, "%d-%02d-%02d", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);
        std::string strCurTime = tmpArray;
        sqlstr = "select jylsh from vehicle_checks where jylsh = '";
        sqlstr += lsh + "' and created_at >'";
        sqlstr += strCurTime;
        sqlstr += "'";
        result=db.getResult(sqlstr.c_str());
        row = mysql_fetch_row(result);
        if (row != NULL) {
            db.freeResult(result);
            db.disconnect();
            return true;
        }
        db.freeResult(result);
        db.disconnect();
        return false;
    }
    else
    {
       db.disconnect();
       DATA_PRINT(LEVEL_ERROR, "database(localhost) for isReCheck failed...... \n");
    }
    return false;
}

std::string is_pass_ShangHai(const vehicle_inf *v_vehicle_inf, int hdzk)
{
    if (v_vehicle_inf->m_syxz != "A") {
        return "-1";
    }

    if (hdzk >= 7) {
        return "-1";
    }

    std::vector<std::string> small_vehicle = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38",
                                              "K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48", "K49"};

    unsigned int i;
    for (i = 0; i < small_vehicle.size(); i++) {
        if (v_vehicle_inf->m_cllx == small_vehicle[i]) {
            break;
        }
    }

    if (i == small_vehicle.size()) {
        return "-1";
    }

    /*
     * 所有车，必须要有的基本照片。
     * 0322：制动工位
     * 0353：灯光工位
     *
     * 上海工位照片只有上面两种，10年以上的车也没有额外的照片。
    */
    std::vector<std::string> basic_list = { // 0203 暂时去掉
        "0111", "0112", "0113", "0157",
        "0201", "0202", "0204", "0209",
        "0322", "0353"
    };

    bool find_4_photo = false;  /* 是否发现了档案照片以外的，结果为4的照片 */

    /* 检查基本照片是否都有，并且都通过 */
    for (unsigned int i = 0; i < basic_list.size(); i++) {
        unsigned int j;

        for (j = 0; j < v_vehicle_inf->m_zplist.size(); j++) {

            /* 找到一张基本照片，需要确认该照片是否通过 */
            if (basic_list[i] == v_vehicle_inf->m_zplist[j].zptype) {
                for (unsigned int k = 0; k < v_vehicle_inf->m_dbbhglist.size(); k++) {
                    if (basic_list[i] == v_vehicle_inf->m_dbbhglist[k].zptype) {
                        if (v_vehicle_inf->m_dbbhglist[k].dbresult == "5") {
                            return "0";
                        } else {
                            find_4_photo = true;
                        }
                    }
                }

                break;
            }
        }

        if (j == v_vehicle_inf->m_zplist.size()) {
            return "0";
        }
    }

    if (find_4_photo) {
        return "4";
    }

    return "1";
}

bool checkTime(string start, string end, string now)
{
    int istart = dataToInt(start);
    int iend = dataToInt(end);
    int inow = dataToInt(now);
    if((inow >= istart)&&(inow <= iend))
    {
        return true;
    }
    return false;
}

int dataToInt(string datatime)
{
    string::iterator it;
    for(it = datatime.begin(); it < datatime.end(); it++)
    {
        if(*it == '-')
        {
            datatime.erase(it);
            it--;
        }
    }
    int dataint = stoi(datatime);
    return dataint;
}

void binzhou_video_check(void *lpParam)
{
    vehicle_inf *pvehicle_inf = (vehicle_inf *)lpParam;
    int i = 0;

    std::vector<std::string> vec_jyjgbh = {"3700000784", "3716000002", "3716000009"};
    for (i = 0; i < vec_jyjgbh.size(); i++)
    {
        DATA_PRINT(LEVEL_INFO, "vec_jyjgbh[i]=%s, pvehicle_inf->m_jyjgbh=%s \n", vec_jyjgbh[i].c_str(), pvehicle_inf->m_jyjgbh.c_str());
        if (vec_jyjgbh[i] == pvehicle_inf->m_jyjgbh)
            break;
    }
    if (i == vec_jyjgbh.size())
    {
        DATA_PRINT(LEVEL_ERROR, "检测机构不在请求视频列表.\n");
        return;
    }
    pvehicle_inf->m_b_ip = true;

    DATA_PRINT(LEVEL_INFO, "开始请求视频地址... ...\n");
    std::map<std::string, std::string> map_list {
        {"京", "&#x4EAC;"}, {"津", "&#x6D25;"}, {"沪", "&#x6CAA;"}, {"渝", "&#x6E1D;"}, {"冀", "&#x5180;"},
        {"豫", "&#x8C6B;"}, {"云", "&#x4E91;"}, {"辽", "&#x8FBD;"}, {"黑", "&#x9ED1;"}, {"湘", "&#x6E58;"},
        {"皖", "&#x7696;"}, {"鲁", "&#x9C81;"}, {"新", "&#x65B0;"}, {"苏", "&#x82CF;"}, {"浙", "&#x6D59;"},
        {"赣", "&#x8D63;"}, {"鄂", "&#x9102;"}, {"桂", "&#x6842;"}, {"甘", "&#x7518;"}, {"晋", "&#x664B;"},
        {"蒙", "&#x8499;"}, {"陕", "&#x9655;"}, {"吉", "&#x5409;"}, {"闽", "&#x95FD;"}, {"贵", "&#x8D35;"},
        {"粤", "&#x7CA4;"}, {"青", "&#x9752;"}, {"藏", "&#x85CF;"}, {"川", "&#x5DDD;"}, {"宁", "&#x5B81;"},
        {"琼", "&#x743C;"},
    };
    char *content_type = "text/xml;charset=utf-8";
    HttpClient client_send;
    std::string str_send = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
    str_send += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">";
    str_send += "<soap:Body><QueryVehicleVideo xmlns=\"http://tempuri.org/\">";
    str_send += "<Xml>";
    str_send += "&lt;?xml version=\"1.0\" encoding=\"utf-8\"?&gt;";
    str_send += "&lt;vehicle&gt;";
    str_send += "&lt;lsh&gt;" + pvehicle_inf->m_jylsh + "&lt;/lsh&gt;";
    str_send += "&lt;jylsh&gt;" + pvehicle_inf->m_jylsh2 + "&lt;/jylsh&gt;";
    str_send += "&lt;clsbdh&gt;" + pvehicle_inf->m_clsbdh + "&lt;/clsbdh&gt;";
    std::string str_fzjg = pvehicle_inf->m_fzjg;
    std::string str_vehicle_province = str_fzjg.substr(0, 3);
    std::string str_province("");
    auto search = map_list.find(str_vehicle_province);
    if (search != map_list.end())
        str_province = search->second;
    std::string str_hphm = str_province + pvehicle_inf->m_hphm;
    DATA_PRINT(LEVEL_INFO, "请求号牌号码=%s\n", pvehicle_inf->m_hphm.c_str());
    str_send += "&lt;hphm&gt;" + str_hphm + "&lt;/hphm&gt;";
    str_send += "&lt;/vehicle&gt;";
    str_send += "</Xml>";
    str_send += "</QueryVehicleVideo></soap:Body></soap:Envelope>";
    std::vector<std::string> vec_ip = {"172.18.253.2:80", "172.18.245.2:80", "172.18.236.2:80"};
    for (i = 0; i < vec_ip.size(); i++)
    {
        std::string default_url("http://");
        default_url += vec_ip[i] + "/ShanghaiEyeControl/ShanghaiEyeControl.asmx";
        DATA_PRINT(LEVEL_INFO, "default_url = %s, i = %d \n", default_url.c_str(), i);
        if (!client_send.init_data(default_url.c_str(), REQUEST_POST_FLAG, content_type, const_cast<char *>(str_send.c_str())))
        {
            i = vec_ip.size();
            DATA_PRINT(LEVEL_ERROR, "video client_send.init_data() error.\n");
        }
        client_send.startHttpClient();
        DATA_PRINT(LEVEL_INFO, "request [%s]\n recv = [%s] \n", default_url.c_str(), client_send.ResponseData.c_str());

        if (client_send.ResponseData.find("&lt;video_path spzl") != std::string::npos)
            break;
    }
    if (vec_ip.size() == i)
    {
        DATA_PRINT(LEVEL_ERROR, "未获取到车辆信息.\n");
        return;
    }

    std::string str_recv = client_send.ResponseData;
    while (str_recv.find("&lt;") != std::string::npos)
    {
        size_t offset = str_recv.find("&lt;");
        str_recv.replace(offset, 4, "<");
    }
    while (str_recv.find("&gt;") != std::string::npos)
    {
        size_t offset = str_recv.find("&gt;");
        str_recv.replace(offset, 4, ">");
    }

    size_t offset = str_recv.find("QueryVehicleVideoResult");
    std::string str_xml = str_recv.substr(offset+1+strlen("QueryVehicleVideoResult"));
    // xml 解析
    get_xml_data(pvehicle_inf, vec_ip, i, str_xml);
    binzhou_download_queue.Put(pvehicle_inf);
    DATA_PRINT(LEVEL_INFO, "下载队列= %d \n", binzhou_download_queue.Size());
    try {
        std::thread *pthread_downvideo = new std::thread(binzhou_download_video);
        pthread_downvideo->detach();
    } catch (const std::system_error& e)
    {
        DATA_PRINT(LEVEL_ERROR, "Create new thread(pthread_downvideo) failure! \n");
        std::cout << "Error code: " << e.code() << ", reason: " << e.what() << std::endl;
    }
}

// pvehicle_inf, vec_ip, index, spzl, xml , "V0111"
void get_video_url(vehicle_inf *pvehicle_inf, std::vector<std::string> vec_ip, int index, std::string tmp, CMarkup& xml, std::string str_video_type)
{
    std::string str_tmp_url;
    _video_resource video_data;

    str_tmp_url = xml.GetData();
    str_tmp_url.erase(0, 1);
    video_data.spzl = str_video_type;
    size_t offset = str_tmp_url.find("127.0.0.1");
    str_tmp_url.replace(offset, 9, vec_ip[index].c_str());
    video_data.spurl = str_tmp_url;
    DATA_PRINT(LEVEL_INFO, "%s spurl = %s\n", tmp.c_str(), str_tmp_url.c_str());
    pvehicle_inf->m_splist.push_back(video_data);
}

void get_xml_data(vehicle_inf *pvehicle_inf, std::vector<std::string> vec_ip, int index, std::string str_xml)
{
    CMarkup xml;
    xml.SetDoc(str_xml);
    xml.ResetPos();

    xml.FindElem("video");
    xml.IntoElem();

    while (xml.FindElem("video_path"))
    {
        std::string tmp = xml.GetAttrib("spzl");
        DATA_PRINT(LEVEL_INFO, "spzl = %s\n", tmp.c_str());
        switch (std::atoi(tmp.c_str())) {
        case 111:
            get_video_url(pvehicle_inf, vec_ip, index, tmp, xml, "V0111");
            break;
        case 112:
            get_video_url(pvehicle_inf, vec_ip, index, tmp, xml, "V0112");
            break;
        case 322:
            get_video_url(pvehicle_inf, vec_ip, index, tmp, xml, "V0322");
            break;
        case 348:
            get_video_url(pvehicle_inf, vec_ip, index, tmp, xml, "V0348");
            break;
        case 321:
            get_video_url(pvehicle_inf, vec_ip, index, tmp, xml, "V0321");
            break;
        case 352:
            get_video_url(pvehicle_inf, vec_ip, index, tmp, xml, "V0352");
            break;
        case 323:
            get_video_url(pvehicle_inf, vec_ip, index, tmp, xml, "V0323");
            break;
        case 344:
            get_video_url(pvehicle_inf, vec_ip, index, tmp, xml, "V0344");
            break;
        case 342:
            get_video_url(pvehicle_inf, vec_ip, index, tmp, xml, "V0342");
            break;
        default:
            DATA_PRINT(LEVEL_INFO, "spzl = %s\n", tmp.c_str());
            break;
        }
    }
}

void binzhou_download_video(void)
{
    DATA_PRINT(LEVEL_INFO, "start video download  ............... \n");
    DATA_PRINT(LEVEL_INFO, "video queue size = %d \n", binzhou_download_queue.Size());
    vehicle_inf * v_vehicle_inf = binzhou_download_queue.Take();
    struct stat st_buf = {};
    stat(g_videoFilePath.c_str(), &st_buf);
    if ((st_buf.st_mode & S_IFMT) != S_IFDIR) {
        mkdir(g_videoFilePath.c_str(), 0777);
        DATA_PRINT(LEVEL_INFO, "生成视频文件夹 [%s] \n", g_videoFilePath.c_str());
    }
    string video_datapath;
    video_datapath = g_videoFilePath;
    std::time_t t = std::time(NULL);
    std::tm *st = std::localtime(&t);
    char tmpArray[128] = { 0 };
    sprintf(tmpArray, "%d-%02d-%02d", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);
    std::string strCurTime = tmpArray;
    video_datapath+=strCurTime;
    video_datapath+="/";
    struct stat st_buf1;
    memset(&st_buf1,0,sizeof(st_buf1));
    stat(video_datapath.c_str(), &st_buf1);
    if ((st_buf1.st_mode & S_IFMT) != S_IFDIR) {
        mkdir(video_datapath.c_str(), 0777);
        DATA_PRINT(LEVEL_INFO, "生成视频当前日期文件夹 [%s] \n", video_datapath.c_str());
    }
    for (unsigned int j = 0; j< v_vehicle_inf->m_splist.size() ;j++)
    {
        v_vehicle_inf->m_splist[j].name =  v_vehicle_inf->m_splist[j].spzl + "_";
        v_vehicle_inf->m_splist[j].name += v_vehicle_inf->m_hphm;
        v_vehicle_inf->m_splist[j].name += "_" + v_vehicle_inf->m_clsbdh;
        if(v_vehicle_inf->m_splist[j].spurl.find(".mp4") != string::npos)
        {
            v_vehicle_inf->m_splist[j].name += ".mp4";
        }
        else if(v_vehicle_inf->m_splist[j].spurl.find(".flv") != string::npos)
        {
            v_vehicle_inf->m_splist[j].name += ".flv";
        }
        else if(v_vehicle_inf->m_splist[j].spurl.find(".avi") != string::npos)
        {
            v_vehicle_inf->m_splist[j].name += ".avi";
        }
        else
        {
            v_vehicle_inf->m_splist[j].name ="";
        }
        v_vehicle_inf->m_splist[j].local_path = video_datapath ;
        v_vehicle_inf->m_splist[j].local_path += v_vehicle_inf->m_splist[j].name;
    }

    DATA_PRINT(LEVEL_INFO, "Into BinZhou View Download \n");
    HttpClient RequestVideo;
    for (int i = 0; i < v_vehicle_inf->m_splist.size(); i++)
    {
        RequestVideo.m_video_filename = v_vehicle_inf->m_splist[i].local_path;
        DATA_PRINT(LEVEL_INFO, "video name = %s, splist size = %d \n", RequestVideo.m_video_filename.c_str(), v_vehicle_inf->m_splist.size());
        if (RequestVideo.InitData(v_vehicle_inf->m_splist[i].spurl.c_str(), REQUEST_GET_FLAG, NULL, NULL))
        {
            RequestVideo.startHttpClient();
        }
    }
download_queue.Put(v_vehicle_inf);
}
