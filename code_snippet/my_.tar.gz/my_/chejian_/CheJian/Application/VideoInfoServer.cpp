#include <thread>
#include <system_error>
#include <vector>
#include "BlockQueue.h"

#include <event2/event.h>
#include <event2/http.h>
#include <event2/buffer.h>
#include <event2/keyvalq_struct.h>
#include <event2/http_struct.h>

#include "trace_log.h"
#include "Markup.h"
#include "http_res_def.h"
#include "MySQL_DB.h"
#include "check_item.h"

extern CheckItem g_CheckItem;
extern std::string g_videoFilePath;
extern std::string g_localServerIp;
extern std::string g_Video_ServerPort;
extern BlockingQueue<video_inf *> video_queue;
std::string URLEncode(const std::string &sIn);
std::string URLDecode(const std::string &sIn);
std::string getMethod(evhttp_cmd_type cmd_type);
std::string video_url_encode(std::string data);

void VideoServerListening_Thread();
void MyHttpServerHandlerForSuZhouVedio(struct evhttp_request *req, void *arg);
void runVideoServerListening();
bool Handler_POST(struct evhttp_request *req);
void send_reply(struct evhttp_request* req, UINT flag);
BOOL Xml_Data(char* xmldata, video_inf * video_inf);


void runVideoServerListening()
{
    //std::thread *p_thread;
    try {
        //p_thread = new std::thread(VideoServerListening_Thread);
        new std::thread(VideoServerListening_Thread);
    } catch (const std::system_error& e) {
        DATA_PRINT(LEVEL_ERROR, "Create \"VideoServerListening_Thread\" failure! \n");
        std::cout << "Error code: " << e.code() << ", reason: " << e.what() << std::endl;
    }
}

void VideoServerListening_Thread()
{
    event_base *base = event_base_new();
    if (base == NULL) {
        DATA_PRINT(LEVEL_ERROR, "VideoInfoServer: event_base_new() failed! \n");
        return;
    }
   /* if(g_CheckItem.City==SUZHOU)
    {
       g_Video_ServerPort="9000";
    } */
    evhttp *video_http_server = evhttp_new(base);
    if (evhttp_bind_socket(video_http_server, g_localServerIp.c_str(), stoi(g_Video_ServerPort)) == -1) {
        DATA_PRINT(LEVEL_ERROR, "VideoInfoServer: evhttp_bind_socket() failed! \n");
        return;
    }
    evhttp_set_gencb(video_http_server, MyHttpServerHandlerForSuZhouVedio, NULL);
    DATA_PRINT(LEVEL_INFO, "HTTP server(VideoInfoServer) listening(%s:%s)...... \n", g_localServerIp.c_str(), g_Video_ServerPort.c_str());
    event_base_dispatch(base);

    DATA_PRINT(LEVEL_ERROR, "HTTP server(VideoInfoServer) thread is over! \n");
}

/* HTTP server 事件回调函数 */
void MyHttpServerHandlerForSuZhouVedio(struct evhttp_request *req, void *arg)
{
    UNUSED(arg);
    evhttp_cmd_type cmd_type = evhttp_request_get_command(req);
    const char *uri = evhttp_request_get_uri(req);

//    DATA_PRINT(LEVEL_DEBUG, "HTTP server(VideoServerListening) received a request(Method:%s, URI:%s) \n",
//               getMethod(cmd_type).c_str(), uri);

    /* 验证URI */
    if (strcmp(VIDEO_QUEST_TEXT, uri) != 0) {
        DATA_PRINT(LEVEL_ERROR, "VideoServerListening: The URI(%s) is undefined! \n", uri);
        return;
    }

    if (cmd_type == EVHTTP_REQ_POST) {
        if(Handler_POST(req))
        {
            send_reply(req,10);
        }
        else
        {
            send_reply(req,0);
        }

    } else {
        DATA_PRINT(LEVEL_ERROR, "VideoServerListening: The Method(%s) is undefined! \n", getMethod(cmd_type).c_str());
    }
}


bool Handler_POST(struct evhttp_request *req)
{
    struct evkeyvalq *headers;
    struct evkeyval *header;

    DATA_PRINT(LEVEL_DEBUG, "Headers: \n");
    headers = evhttp_request_get_input_headers(req);
    for (header = headers->tqh_first; header; header = header->next.tqe_next) {
        DATA_PRINT(LEVEL_DEBUG, "%s: %s\n", header->key, header->value);
    }

    struct evbuffer *buf = evhttp_request_get_input_buffer(req);

    size_t len = evbuffer_get_length(buf);
    char *data = (char *)malloc(len + 1);
    evbuffer_copyout(buf, data, len);
    *(data + len) = 0;

    std::string decodeData = URLDecode(std::string(data));
    video_inf* v_video_inf = new video_inf;
    if(!Xml_Data((char*)decodeData.c_str(),v_video_inf))
    {
        DATA_PRINT(LEVEL_DEBUG, "video xml wrong message\n");
        free(data);
        delete v_video_inf;
        v_video_inf = NULL;
        return false;
    }
    DATA_PRINT(LEVEL_DEBUG, "video xml message pass \n");
        free(data);
        return true;


}

BOOL Xml_Data(char* xmldata, video_inf * video_inf)
{

    CMarkup xml;
    int count;
    xml.SetDoc(xmldata);
    xml.ResetMainPos();
    if (!xml.FindElem())//<root>
        return FALSE;
    xml.IntoElem();
    if (xml.FindElem("head"))
    {
        for (unsigned int i = 0; i < video_inf->item_description.size(); i++)
        {
            //DATA_PRINT(LEVEL_DEBUG, "%d: %s", i, video_inf->item_description[i].name_tag);
            if (xml.FindChildElem(video_inf->item_description[i].name_tag)){
                *(string*)video_inf->item_description[i].value = xml.GetChildData();
                if (i==7)
                {
                    std::string cc = xml.GetChildData();
                    count = atoi(cc.c_str());
                }
            }
            else
            {
                DATA_PRINT(LEVEL_DEBUG, "xml :can't find s%",video_inf->item_description[i].name_tag);
                return FALSE;
            }
            xml.ResetChildPos();
        }
    }
    if (xml.FindElem("body"))
    {
        xml.IntoElem();
        for (int i = 0; i < count; i++)
        {
            _video_resource buf;
            xml.FindElem("video");
            xml.FindChildElem("spzl");
            buf.spzl = xml.GetChildData();
            xml.FindChildElem("spurl");
            std::string video_url= xml.GetChildData();
            video_url=video_url_encode(video_url);
            buf.spurl = video_url;
            buf.local_path = g_videoFilePath;
            std::time_t t = std::time(NULL);
            std::tm *st = std::localtime(&t);
            char tmpArray[128] = { 0 };
            sprintf(tmpArray, "%d-%02d-%02d", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);
            std::string strCurTime = tmpArray;
            buf.local_path+=strCurTime;

#ifdef CHE_JIAN_LINUX
            struct stat st_buf;
            memset(&st_buf,0,sizeof(st_buf));
            stat(buf.local_path.c_str(), &st_buf);
            if ((st_buf.st_mode & S_IFMT) != S_IFDIR) {
                mkdir(buf.local_path.c_str(), 0777);
            }
#else
            if (!PathIsDirectory(buf.local_path.c_str()))
            CreateDirectory(buf.local_path.c_str(), NULL);
#endif
            buf.local_path += "/";
            string urlc = buf.spzl;
            if ((urlc.find("0111")) != std::string::npos) {
                buf.sptype = "0111";
            }
            if ((urlc.find("0112")) != std::string::npos) {
                buf.sptype = "0112";
            }
            if ((urlc.find("0323")) != std::string::npos) {
                buf.sptype = "0323";
            }
            if ((urlc.find("0321")) != std::string::npos) {
                buf.sptype = "0321";
            }
            if ((urlc.find("0352")) != std::string::npos) {
                buf.sptype = "0352";
            }
            if ((urlc.find("0322")) != std::string::npos) {
                buf.sptype = "0322";
            }
            if ((urlc.find("0348")) != std::string::npos) {
                buf.sptype = "0348";
            }
            if ((urlc.find("0351")) != std::string::npos) {
                buf.sptype = "0351";
            }
            if ((urlc.find("0344")) != std::string::npos) {
                buf.sptype = "0344";
            }
            if ((urlc.find("0342")) != std::string::npos) {
                buf.sptype = "0342";
            }
            string video_type;
            if(buf.spurl.find(".flv") != std::string::npos)
            {
                video_type=".flv";
            }
            if(buf.spurl.find(".mp4") != std::string::npos)
            {
                video_type=".mp4";
            }
            if(buf.spurl.find(".avi") != std::string::npos)
            {
                video_type=".avi";
            }

            buf.dzzl = "ftp";
            buf.local_path += buf.sptype + "_" + video_inf->v_hphm + "_" + video_inf->v_jyjgbh + video_type;


            video_inf->v_splist.push_back(buf);
        }
    }
    else
    {
        DATA_PRINT(LEVEL_DEBUG, "xml :can't find body");
        return FALSE;
    }
    if (0 == count)
        return FALSE;
    else
    {
        video_queue.Put(video_inf);
        return TRUE;
    }
    return FALSE;
}


void send_reply(struct evhttp_request* req, UINT flag)
{
    evbuffer* buf = evbuffer_new();
    string ackcode,ackmessage;
    if (!buf)
    {
        if (flag == POST_DATA_OK)evhttp_send_reply(req, HTTP_OK, "OK", NULL);
        else evhttp_send_error(req, HTTP_BADREQUEST, 0);
        return;
    }
    switch (flag)
    {
    case 10:
        ackcode = "01";
        ackmessage = "存储成功";
        break;
    case 0:
        ackcode = "02";
        ackmessage = "重新上传";
        break;

    }

        string testxml = "<?xml version=\"1.0\" encoding=\"GBK\"?>";
        testxml += "<root>";
        testxml += "<res>";
        testxml += ackcode;
        testxml += "</res>";
        testxml += "<message>";
        testxml += ackmessage;
        testxml += "</message>";
        testxml += "</root>";
    evbuffer_add(buf,testxml.c_str(), strlen((char *)testxml.c_str()));
    evhttp_add_header(req->output_headers, "Content-Type", HTTP_CONTENT_TYPE_URL_ENCODED);


    if ((flag == POST_DATA_OK) || (flag == DEVICE_BUSY) || (flag == VIDEO_GET)) {
        evhttp_send_reply(req, HTTP_OK, "OK", buf);
    } else if (flag == WRONG_PATH) {
        evhttp_send_reply(req, HTTP_BADMETHOD, NULL, buf);
    } else {
        evhttp_send_reply(req, HTTP_INTERNAL, NULL, buf);
    }

    evbuffer_free(buf);
}

std::string video_url_encode(std::string data)
{
    std::string::size_type pos1(0);
    while ((pos1 = data.find("\\")) != std::string::npos) {
        data.replace(pos1, 1, "/");
    }
    return data;
}

std::string getMethod(evhttp_cmd_type cmd_type)
{
    std::string method;

    switch (cmd_type) {
        case EVHTTP_REQ_GET:     method = "GET";break;
        case EVHTTP_REQ_POST:    method = "POST"; break;
        case EVHTTP_REQ_HEAD:    method = "HEAD"; break;
        case EVHTTP_REQ_PUT:     method = "PUT"; break;
        case EVHTTP_REQ_DELETE:  method = "DELETE"; break;
        case EVHTTP_REQ_OPTIONS: method = "OPTIONS"; break;
        case EVHTTP_REQ_TRACE:   method = "TRACE"; break;
        case EVHTTP_REQ_CONNECT: method = "CONNECT"; break;
        case EVHTTP_REQ_PATCH:   method = "PATCH"; break;
        default:                 method = "";
    }

    return method;
}
