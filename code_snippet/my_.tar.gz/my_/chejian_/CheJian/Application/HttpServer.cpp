//#include "afx.h"

#include "vehicle_inf.h"
#include "http_res_def.h"
#include "Markup.h"
#include <queue>
#include <event2/event.h> 
#include <event2/buffer.h> 
#include <event2/http.h>
#include <event2/http_struct.h>
#include <event2/keyvalq_struct.h>
#include "BlockQueue.h"
#include "trace_log.h"
#include "HttpServer.h"
#include "stdlib.h"
#include <locale.h> 
#include "MySQL_DB.h"
#include "vehicle_check_service.h"
#include <fstream>
#include "trace_log.h"

BlockingQueue<vehicle_inf *> toanalyse_queue;
BlockingQueue<vehicle_inf *> download_queue;
BlockingQueue<video_inf *> video_queue;
BlockingQueue<vehicle_inf *> reply_queue;
BlockingQueue<vehicle_inf *> record_queue;
BlockingQueue<vehicle_inf *> reply_master_queue;

extern std::string g_videoFilePath;
std::string g_dzjqxbdUri = VHHICLE_DZJQXBD_TEXT;
std::string g_videoUri = DOWNLOAD_VIDEO_DATA;
std::string g_VideoUri = VIDEO_QUEST_TEXT;

/*
 * 目前（2018-10-10）已知SOAP通信出现的两个URI：
 * 1. 临汾车管所：/pnweb/services/TmriOutNewAccess?wsdl
 * 2. 其他车管所：/pnweb/services/TmriOutAccess
 */
std::string g_requestUri = "/pnweb/services/TmriOutAccess";
std::string g_request_get_checkitem = "/checkitem/";
std::string g_request_reply_result = "SendProcessResult";
std::string g_request_get_env_insurance = "EnvMsg";
std::string g_request_get_vin = "cxgquery";
std::string g_request_get_ins_insurance = "InsMsg";
std::string g_localServerIp = LOCAL_HTTPSERVER_IP;
std::string g_localServerPort = LOCAL_HTTPSERVER_PORT;
std::string g_confJkxlh = VEHICLE_JKXLH;
std::string g_localMac;

extern std::string g_master_IP;
extern int g_SlaveCount;

void MyHttpServerHandler(struct evhttp_request* req, void* arg);
void MyHttpServerHandlerForSuZhouVedio(struct evhttp_request *req, void *arg);
//DWORD WINAPI httpserverthread(LPVOID lpParam);
UINT  Analyse_UrlBuf_Data(struct evhttp_request* req, int process_type);
BOOL Analyse_Xml_Data(char* xmldata, vehicle_inf * pvehicle_inf);
//BOOL Video_Xml_Data(char* xmldata, video_inf * video_inf);
std::string UTF8toANSI(char *strUTF8);
std::string ANSItoUTF8(char* strAnsi);
std::string sqlencode(std::string data);
UINT Check_Vehicles_Sys_request(const char* method, const char* xlh, const char* id, const char* lb);
void send_http_post_reply(struct evhttp_request* req, UINT flag);
void recordUnknownRequest(struct evhttp_request *req, std::string method, std::string uri);
bool deviceIsBusy();
void send_checkitem_reply(struct evhttp_request* req);
bool isTargetDevice();

HttpServer::HttpServer()
{
    s_ip = "0.0.0.0";
    s_port = 0;
	base = event_base_new();          
}

HttpServer::~HttpServer()
{
	event_base_free(base);
}

bool HttpServer::startHttpServer(const char* ip, int port, void(*cb)(struct evhttp_request *, void *), void *arg)
{     
	//创建event_base和evhttp     
	http_server = evhttp_new(base);
	if (!http_server) 
    {
        DATA_PRINT(LEVEL_ERROR, "HTTP server evhttp_new() failed! IP:%s, Port:%d \n", ip, port);
		return false;    
    }
	//绑定到指定地址上     
	int ret = evhttp_bind_socket(http_server, ip, port & 0xFFFF);     
	if (ret != 0) 
    {
        DATA_PRINT(LEVEL_ERROR, "HTTP server evhttp_bind_socket() failed! IP:%s, Port:%d \n", ip, port);
		return false;     
	}     
	//设置事件处理函数     
    evhttp_set_gencb(http_server, cb, arg);
	//启动事件循环，当有http请求的时候会调用指定的回调     
    DATA_PRINT(LEVEL_INFO, "HTTP server listening(%s:%d)...... \n", ip, port);
    event_base_dispatch(base);
	/*
	HANDLE m_hThread;
	DWORD dwThread;

	// 创建响应线程，启动线程函数
	m_hThread = ::CreateThread(NULL, 0, httpserverthread, (LPVOID)this, 0, &dwThread);
	if (NULL == m_hThread)
		return FALSE;*/

    evhttp_free(http_server);
	return true; 
} 

bool AnalyseXmlData(char* data)
{
    DATA_PRINT(LEVEL_INFO, "master recv xml=[%s]\n", data);
    CMarkup xml;
    xml.SetDoc(data);
    xml.ResetMainPos();

    xml.FindElem("root");
    xml.IntoElem();

    int type;
    xml.FindElem("code");
    type = atoi(xml.GetData().c_str());

    xml.FindElem("vehicle");
    xml.IntoElem();
    vehicle_inf* vehicle = new vehicle_inf();
    if(type == PHOTO_PROCESS_RESULT)
    {

        DATA_PRINT(LEVEL_INFO, "Received vehicle information, analyse data: \n");
        for (unsigned int i = 0; i < vehicle->item_description.size(); i++)
        {
            if (xml.FindElem(vehicle->item_description[i].name_tag))
            {
                *(static_cast<std::string*>(vehicle->item_description[i].value)) = xml.GetData();
                DATA_PRINT(LEVEL_INFO, "%s: %s\n", vehicle->item_description[i].name_tag, (*(static_cast<std::string*>(vehicle->item_description[i].value))).c_str());
            }
            else
            {
                DATA_PRINT(LEVEL_INFO, "    Missing XML element \"%s\"! \n", vehicle->item_description[i].name_tag);
            }
            xml.ResetMainPos();
            xml.ResetChildPos();
        }
        xml.OutOfElem();

        /*从已发出队列中找接收到的流水号，确认收到信息后将信息删除*/
        if(xml.FindElem("zplist"))
        {
            DATA_PRINT(LEVEL_INFO,"zplist data:\n");
            xml.IntoElem();
            while(xml.FindElem("item"))
            {
                _photo_resource photo_buf;
                xml.IntoElem();
                if(xml.FindElem("zpzl"))
                {
                    photo_buf.zptype = xml.GetData();
                }
                if(xml.FindElem("id"))
                {
                    photo_buf.zpid = xml.GetData();
                    //vehicle->photo_list[index].result = atoi(xml.GetData().c_str());
                }
                if(xml.FindElem("uri"))
                {
                    photo_buf.zpurl = xml.GetData();
                }
                if(xml.FindElem("local_path"))
                {
                    photo_buf.local_path = xml.GetData();
                }
                vehicle->m_zplist.push_back(photo_buf);
                xml.OutOfElem();
                DATA_PRINT(LEVEL_INFO,"zplx:%s  local_path:%s\n",photo_buf.zptype.c_str(),photo_buf.local_path.c_str());
            }
            xml.OutOfElem();
       }
        else {
            DATA_PRINT(LEVEL_INFO,"master analyse slave zplist is empty\n");
            return false;
        }
       if(xml.FindElem("bhglist"))
       {
           DATA_PRINT(LEVEL_INFO,"bhglist data:\n");
           xml.IntoElem();
           while (xml.FindElem("item"))
           {
               xml.IntoElem();
               _dbbhg_list bhglist_buf;
               if(xml.FindElem("id"))
               {
                   bhglist_buf.zpid = xml.GetData();
               }
               if(xml.FindElem("zpzl"))
               {
                   bhglist_buf.zptype = xml.GetData();
               }
               if(xml.FindElem("result"))
               {
                   bhglist_buf.dbresult = xml.GetData();
               }
               if(xml.FindElem("reason"))
               {
                   bhglist_buf.dbbhg_desc = xml.GetData();
               }
               vehicle->m_dbbhglist.push_back(bhglist_buf);
               xml.OutOfElem();
               DATA_PRINT(LEVEL_INFO,"zplx:%s  result:%s\n",bhglist_buf.zptype.c_str(),bhglist_buf.dbresult.c_str());
           }

       }
       else {
           DATA_PRINT(LEVEL_INFO,"master analyse slave bhglist is empty\n");
       }
       xml.OutOfElem();
       if(xml.FindElem("timeinfo"))
       {
           xml.IntoElem();
           if(xml.FindElem("start_total"))
           {
               vehicle->timeRecord.start_total_time = atoll(xml.GetData().c_str());
               DATA_PRINT(LEVEL_INFO,"xml total is %l\n",vehicle->timeRecord.start_total_time);
           }
           if(xml.FindElem("total_no_wait"))
           {
               vehicle->timeRecord.total_no_wait = xml.GetData();
                DATA_PRINT(LEVEL_INFO,"xml total_no_wait is %s\n",vehicle->timeRecord.total_no_wait.c_str());
           }
           if(xml.FindElem("wait_queue"))
           {
               vehicle->timeRecord.wait_queue = xml.GetData();
               DATA_PRINT(LEVEL_INFO,"xml wait_queue is %s\n",vehicle->timeRecord.wait_queue.c_str());
           }
           xml.OutOfElem();
       }
       if(xml.FindElem("picturetime"))
       {
           xml.IntoElem();
           if(xml.FindElem("alldownload"))
           {
               vehicle->timeRecord.picture.AllDownload = xml.GetData();
           }
           if(xml.FindElem("zf"))
           {
               vehicle->timeRecord.picture.process.zf = xml.GetData();
           }
           if(xml.FindElem("abs"))
           {
               vehicle->timeRecord.picture.process.abs = xml.GetData();
           }
           if(xml.FindElem("aqd"))
           {
               vehicle->timeRecord.picture.process.aqd = xml.GetData();
           }
           if(xml.FindElem("cjh"))
           {
               vehicle->timeRecord.picture.process.cjh = xml.GetData();
           }
           if(xml.FindElem("hhp"))
           {
               vehicle->timeRecord.picture.process.hhp = xml.GetData();
           }
           if(xml.FindElem("jly"))
           {
               vehicle->timeRecord.picture.process.jly = xml.GetData();
           }
           if(xml.FindElem("jqx"))
           {
               vehicle->timeRecord.picture.process.jqx = xml.GetData();
           }
           if(xml.FindElem("mhq"))
           {
               vehicle->timeRecord.picture.process.mhq = xml.GetData();
           }
           if(xml.FindElem("qhp"))
           {
               vehicle->timeRecord.picture.process.qhp = xml.GetData();
           }
           if(xml.FindElem("sfz"))
           {
               vehicle->timeRecord.picture.process.sfz = xml.GetData();
           }
           if(xml.FindElem("sqb"))
           {
               vehicle->timeRecord.picture.process.sqb = xml.GetData();
           }
           if(xml.FindElem("wts"))
           {
               vehicle->timeRecord.picture.process.wts = xml.GetData();
           }
           if(xml.FindElem("xsz"))
           {
               vehicle->timeRecord.picture.process.xsz = xml.GetData();
           }
           if(xml.FindElem("ydg"))
           {
               vehicle->timeRecord.picture.process.ydg = xml.GetData();
           }
           if(xml.FindElem("yhf"))
           {
               vehicle->timeRecord.picture.process.yhf = xml.GetData();
           }
           if(xml.FindElem("yjc"))
           {
               vehicle->timeRecord.picture.process.yjc = xml.GetData();
           }
           if(xml.FindElem("yql"))
           {
               vehicle->timeRecord.picture.process.yql = xml.GetData();
           }
           if(xml.FindElem("chgw"))
           {
               vehicle->timeRecord.picture.process.chgw = xml.GetData();
           }
           if(xml.FindElem("clbm"))
           {
               vehicle->timeRecord.picture.process.clbm = xml.GetData();
           }
           if(xml.FindElem("clcm"))
           {
               vehicle->timeRecord.picture.process.clcm = xml.GetData();
           }
           if(xml.FindElem("cyjl"))
           {
               vehicle->timeRecord.picture.process.cyjl = xml.GetData();
           }
           if(xml.FindElem("dchp"))
           {
               vehicle->timeRecord.picture.process.dchp = xml.GetData();
           }
           if(xml.FindElem("dchw"))
           {
               vehicle->timeRecord.picture.process.dchw = xml.GetData();
           }
           if(xml.FindElem("dpjy"))
           {
               vehicle->timeRecord.picture.process.dpjy = xml.GetData();
           }
           if(xml.FindElem("ezzd"))
           {
               vehicle->timeRecord.picture.process.ezzd = xml.GetData();
           }
           if(xml.FindElem("fzzd"))
           {
               vehicle->timeRecord.picture.process.fzzd = xml.GetData();
           }
           if(xml.FindElem("hdzk"))
           {
               vehicle->timeRecord.picture.process.hdzk = xml.GetData();
           }
           if(xml.FindElem("jybg"))
           {
               vehicle->timeRecord.picture.process.jybg = xml.GetData();
           }
           if(xml.FindElem("wqjy"))
           {
               vehicle->timeRecord.picture.process.wqjy = xml.GetData();
           }
           if(xml.FindElem("wszm"))
           {
               vehicle->timeRecord.picture.process.wszm = xml.GetData();
           }
           if(xml.FindElem("wxnb"))
           {
               vehicle->timeRecord.picture.process.wxnb = xml.GetData();
           }
           if(xml.FindElem("yzzd"))
           {
               vehicle->timeRecord.picture.process.yzzd = xml.GetData();
           }
           if(xml.FindElem("zczd"))
           {
               vehicle->timeRecord.picture.process.zczd = xml.GetData();
           }
           if(xml.FindElem("cjhcf"))
           {
               vehicle->timeRecord.picture.process.cjhcf = xml.GetData();
           }

           if(xml.FindElem("cjhyj"))
           {
               vehicle->timeRecord.picture.process.cjhyj = xml.GetData();
           }
           if(xml.FindElem("sfzbk"))
           {
               vehicle->timeRecord.picture.process.sfzbk = xml.GetData();
           }
           if(xml.FindElem("wttzs"))
           {
               vehicle->timeRecord.picture.process.wttzs = xml.GetData();
           }
           if(xml.FindElem("xszbk"))
           {
               vehicle->timeRecord.picture.process.xszbk = xml.GetData();
           }
           if(xml.FindElem("yhfcf"))
           {
               vehicle->timeRecord.picture.process.yhfcf = xml.GetData();
           }
           if(xml.FindElem("zqfcf"))
           {
               vehicle->timeRecord.picture.process.zqfcf = xml.GetData();
           }
           if(xml.FindElem("cjh_ug"))
           {
               vehicle->timeRecord.picture.process.cjh_ug = xml.GetData();
           }
           if(xml.FindElem("dpdtjs"))
           {
               vehicle->timeRecord.picture.process.dpdtjs = xml.GetData();
           }
           if(xml.FindElem("dpdtks"))
           {
               vehicle->timeRecord.picture.process.dpdtks = xml.GetData();
           }
           if(xml.FindElem("jcqxbg"))
           {
               vehicle->timeRecord.picture.process.jcqxbg = xml.GetData();
           }
           if(xml.FindElem("jyb_bk"))
           {
               vehicle->timeRecord.picture.process.jyb_bk = xml.GetData();
           }

           if(xml.FindElem("jyhgzm"))
           {
               vehicle->timeRecord.picture.process.jyhgzm = xml.GetData();
           }
           if(xml.FindElem("chexiang"))
           {
               vehicle->timeRecord.picture.process.chexiang = xml.GetData();
           }
           if(xml.FindElem("waikuocemian"))
           {
               vehicle->timeRecord.picture.process.waikuocemian = xml.GetData();
           }
           if(xml.FindElem("waikuoqianmian"))
           {
               vehicle->timeRecord.picture.process.waikuoqianmian = xml.GetData();
           }
           if(xml.FindElem("isPass"))
           {
               DATA_PRINT(LEVEL_INFO, "master recv ispass=%s, hphm=%s\n", xml.GetData().c_str(), vehicle->m_hphm.c_str());
               vehicle->m_isPass = xml.GetData();
           }
           if(xml.FindElem("deviceId"))
           {
               vehicle->m_deviceId = xml.GetData();
           }
       }
    }
    else {
        DATA_PRINT(LEVEL_ERROR,"analyse slave result is failed!!!\n");
        return false;
    }
    reply_queue.Put(vehicle);//put to soap reply queue
    vehicle = nullptr;
    return true;
}
bool AnalyseSlaveResult(struct evhttp_request* req)
{
    struct evkeyvalq *headers;
    struct evkeyval *header;
    struct evbuffer *buf;
    char* data = nullptr;
    UINT len = 0;

    //UINT check_process_type = 0;

    evhttp_request_get_uri(req);
    evhttp_request_get_evhttp_uri(req);
    DATA_PRINT(LEVEL_DEBUG, "%s\n",evhttp_request_get_uri(req));

    DATA_PRINT(LEVEL_DEBUG, "Headers:\n");
    headers = evhttp_request_get_input_headers(req);
    for (header = headers->tqh_first; header;
        header = header->next.tqe_next) {
        DATA_PRINT(LEVEL_DEBUG, "  %s: %s\n", header->key, header->value);
    }

    //vehicle_inf *v_vehicle_inf = NULL;
    struct evkeyvalq params;
    buf = evhttp_request_get_input_buffer(req);

    len = (UINT)evbuffer_get_length(buf);
    data = (char*)malloc(len + 1);
    if(data == nullptr)
    {
        DATA_PRINT(LEVEL_ERROR,"malloc failed!!!\n");
        return false;
    }
    evbuffer_copyout(buf, data, len);
    *(data + len) = 0;

    evhttp_parse_query_str(data, &params);
    if(!AnalyseXmlData(data))
    {
        DATA_PRINT(LEVEL_ERROR,"AnalyseXmlData is failed!!!\n");
        free(data);
        data = nullptr;
        return false;

    }
    free(data);
    data = nullptr;
    return true;


}
void MyHttpServerHandler(struct evhttp_request *req, void *arg)
{
    UNUSED(arg);
	const char *cmdtype;
	int request_txt_type = 0;

	switch (evhttp_request_get_command(req)) {
    case EVHTTP_REQ_GET: cmdtype = "GET"; break;
    case EVHTTP_REQ_POST: cmdtype = "POST"; break;
    case EVHTTP_REQ_HEAD: cmdtype = "HEAD"; break;
    case EVHTTP_REQ_PUT: cmdtype = "PUT"; break;
    case EVHTTP_REQ_DELETE: cmdtype = "DELETE"; break;
    case EVHTTP_REQ_OPTIONS: cmdtype = "OPTIONS"; break;
    case EVHTTP_REQ_TRACE: cmdtype = "TRACE"; break;
    case EVHTTP_REQ_CONNECT: cmdtype = "CONNECT"; break;
    case EVHTTP_REQ_PATCH: cmdtype = "PATCH"; break;
    default: cmdtype = "unknown"; break;
	}

	//获取请求的URI 
    const char *uri = (char *)evhttp_request_get_uri(req);

    /* 检查请求是否来自授权的IP */
    if (g_master_IP != req->remote_host && g_SlaveCount == -1) {
        DATA_PRINT(LEVEL_ERROR, "HTTP server received a unknown request:\nMethod:%s\nIP:%s,port:%d\nURI:%s\n",
                   cmdtype, req->remote_host, req->remote_port, uri);

        recordUnknownRequest(req, cmdtype, uri);
        //武汉检测站被HTTP攻击后更改 如果不是来自授权的IP 则直接退出无响应
        //evhttp_send_error(req, HTTP_BADREQUEST, NULL);
        return;
    }

    DATA_PRINT(LEVEL_DEBUG, "HTTP server received a request(Method:%s, URI:%s) \n", cmdtype, uri);

    if (strstr(uri, g_requestUri.c_str()) != NULL)
    {
		request_txt_type = VHHICLE_ANALYSE_QUEST;
		UINT result = Analyse_UrlBuf_Data(req, request_txt_type);
		send_http_post_reply(req, result);
		return;
    }
    else if (strstr(uri, g_request_get_checkitem.c_str()) != NULL)
    {
        request_txt_type = GETCHECKITEM;
        send_checkitem_reply(req);
        return;
    }
    else if(strstr(uri,g_request_reply_result.c_str()) != nullptr)
    {
        evbuffer* buf = evbuffer_new();
        if(AnalyseSlaveResult(req))
        {
            evhttp_send_reply(req, HTTP_OK, "OK", buf);
        }
        else
        {
            evhttp_send_reply(req, HTTP_NOTIMPLEMENTED, "analyse slave failed!\n", buf);
        }
        return;
    }
	else 
	{
        DATA_PRINT(LEVEL_ERROR, "The URI(%s) is undefined! \n", uri);
		send_http_post_reply(req, WRONG_PATH);
		return;
	}

//	//回复给客户端
//	unsigned int result = Analyse_UrlBuf_Data(req, request_txt_type);
//	send_http_post_reply(req, result);
}


void send_checkitem_reply(struct evhttp_request* req)
{
    evbuffer* buf = evbuffer_new();

    if (!buf)
    {
        evhttp_send_error(req, HTTP_BADREQUEST, 0);
        return;
    }

    struct evkeyvalq *headers;
    struct evkeyval *header;
    const char *uri;

    uri = evhttp_request_get_uri(req);
    evhttp_request_get_evhttp_uri(req);
    DATA_PRINT(LEVEL_INFO,"%s\n",uri);

    headers = evhttp_request_get_input_headers(req);
    for(header = headers->tqh_first;header;header = header->next.tqe_next )
    {
        DATA_PRINT(LEVEL_INFO,"%s:%s\n",header->key, header->value);

    }
    evhttp_add_header(req->output_headers, "Content-Type", "text/xml");

    std::string filename = "check_item.xml";
    ifstream filestr;
    filebuf* pbuf;
    long size;
    char* buffer;

    filestr.open(filename.c_str(), ios::binary);
    if(!filestr)
    {
        DATA_PRINT(LEVEL_INFO,"check_item can't found!");
        evhttp_send_error(req, HTTP_NOTFOUND, 0);
        return;
    }

    // 获取filestr对应buffer对象的指针
    pbuf = filestr.rdbuf();

    size = pbuf->pubseekoff(0, ios::end, ios::in);
    pbuf->pubseekpos(0, ios::in);

    buffer = new char[size];
    pbuf->sgetn(buffer, size);

    filestr.close();

    //文件内容加入队列
    evbuffer_add(buf, buffer,size);

    evhttp_send_reply(req, HTTP_OK, "OK", buf);
    free(buffer);
    evbuffer_free(buf);
}

void send_http_post_reply(struct evhttp_request* req, UINT flag)
{
	evbuffer* buf = evbuffer_new();
	string ackcode,ackmessage;
	if (!buf)
	{
		if (flag == POST_DATA_OK)evhttp_send_reply(req, HTTP_OK, "OK", NULL);
		else evhttp_send_error(req, HTTP_BADREQUEST, 0);
		return;
	}
	switch (flag)
	{
	case POST_DATA_OK:
		ackcode = "1";
		ackmessage = "收到车检系统复检请求,数据保存成功";
		break;
	case WRONG_JKXLH:		
		ackcode = "0";
		ackmessage = "接口序列号不正确";
		break;
	case WRONG_JKID:
		ackcode = "0";
		ackmessage = "接口ID不正确";
		break;
	case WRONG_XTLB:
		ackcode = "0";
		ackmessage = "系统类别不正确";
		break;
	case WRONG_PATH:
		ackcode = "0";
		ackmessage = "不能识别的请求";
		break;
	case ABNORMAL_KEY:
		ackcode = "0";
		ackmessage = "缺少系统关键字";
		break;
	case WRONG_XMLDATA:
		ackcode = "0";
		ackmessage = "XML数据字段不能识别";
		break;
	case WRONG_XMLDOC:
		ackcode = "0";
		ackmessage = "未识别到xmlDoc字段";
		break;
	case DEVICE_BUSY:
		ackcode = "0";
        ackmessage = "当前设备有积压数据";
		break;
//    case VIDEO_GET:
//        ackcode = "01";
//        ackmessage = "存储成功";
//        break;
//    case VIDEO_LOSS:
//        ackcode = "02";
//        ackmessage = "重新上传";
//        break;

	}

//	if (flag >= 10)
//	{
//		string testxml = "<?xml version=\"1.0\" encoding=\"GBK\"?>";
//		testxml += "<root>";
//		testxml += "<res>";
//		testxml += ackcode;
//		testxml += "</res>";
//		testxml += "<message>";
//	//žùŸÝURIÏÔÊŸ
//		testxml += ackmessage;
//		testxml += "</message>";
//		testxml += "</root>";
//    evbuffer_add(buf,testxml.c_str(), strlen((char *)testxml.c_str()));
//	evhttp_add_header(req->output_headers, "Content-Type", HTTP_CONTENT_TYPE_URL_ENCODED);

//	}
//    else
//    {
        string testxml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
        testxml += "<root>";
        testxml += "<head><code>";
        testxml += ackcode;
        testxml += "</code>";
        testxml += "<message>";
        //根据URI显示
        testxml += ackmessage;
        testxml += "</message></head>";
        testxml += "</root>";
            evbuffer_add(buf, testxml.c_str(), strlen((char *)testxml.c_str()));
            evhttp_add_header(req->output_headers, "Content-Type", HTTP_CONTENT_TYPE_URL_ENCODED);
//    }
	if ((flag == POST_DATA_OK) || (flag == DEVICE_BUSY) || (flag == VIDEO_GET)) {
		evhttp_send_reply(req, HTTP_OK, "OK", buf);
	} else if (flag == WRONG_PATH) {
		evhttp_send_reply(req, HTTP_BADMETHOD, NULL, buf);
	} else {
		evhttp_send_reply(req, HTTP_INTERNAL, NULL, buf);
	}

	evbuffer_free(buf);
}

int HttpServer::run()
{     
	//Windows 平台套接字库的初始化 
#ifdef WIN32     
	WSADATA wsaData;    
	WSAStartup(MAKEWORD(2, 2), &wsaData);
#endif     

    s_ip = g_localServerIp;
    s_port = atoi(g_localServerPort.c_str());
//    if (s_ip == "0.0.0.0")
//	{
//		char    HostName[100];
//		hostent* hname;
//		gethostname(HostName, sizeof(HostName));// 获得本机主机名.
//        hname = gethostbyname(HostName);//根据本机主机名得到本机iprequestHandler
//		s_ip = inet_ntoa(*(struct in_addr *)hname->h_addr_list[0]);//把ip换成字符串形式
//	}

	//启动服务在地址 127.0.0.1:9000 上    
//    DATA_PRINT(LEVEL_DATA, "HTTP server infromation, IP: %s, port: %d \n", s_ip.c_str(), s_port);
    startHttpServer(s_ip.c_str(), s_port, MyHttpServerHandler, NULL);

#ifdef WIN32     
	WSACleanup(); 
#endif     
	return 0;
}


void HttpServer::stop()
{
	event_base_loopexit(base,0);
}

//DWORD WINAPI httpserverthread(LPVOID lpParam)
//{
//	HttpServer *phttpserver = (HttpServer *)lpParam;
//	event_base_dispatch(phttpserver->base);
//	evhttp_free(phttpserver->http_server);
//	return NULL;
//}

#ifdef CHE_JIAN_LINUX

int code_convert(char *from_charset, char *to_charset, char *inbuf, size_t inlen, char *outbuf, size_t outlen)
{
    iconv_t cd;

    char **pin = &inbuf;
    char **pout = &outbuf;

    cd = iconv_open(to_charset, from_charset);
    if (cd==0) {
        return -1;
    }

    memset(outbuf, 0, outlen);
    if (iconv(cd, pin, &inlen, pout, &outlen) == -1) {
        return -1;
    }

    iconv_close(cd);
    return 0;
}

std::string UTF8toANSI(char *strUTF8)
{
//    size_t nLen = strlen(strUTF8) * 4;    /* 4倍长度足够任何编码形式 */
//    char *szBuffer = new char[nLen + 1];
//    code_convert("UTF-8", "ANSI", strUTF8, strlen(strUTF8), szBuffer, nLen);

//    std::string ansistr;
//    ansistr = szBuffer;

//    delete szBuffer;

    std::string ansistr = strUTF8;
    return ansistr;
}

std::string ANSItoUTF8(char* strAnsi)
{
//    size_t nLen = strlen(strAnsi) * 4;    /* 4倍长度足够任何编码形式 */
//    char *szBuffer = new char[nLen + 1];
//    code_convert("ANSI", "UTF-8", strAnsi, strlen(strAnsi), szBuffer, nLen);

//    std::string ansistr;
//    ansistr = szBuffer;

//    delete szBuffer;

    std::string ansistr = strAnsi;
    return ansistr;
}

#else

std::string UTF8toANSI(char *strUTF8)
{
	//获取转换为多字节后需要的缓冲区大小，创建多字节缓冲区
	unsigned int nLen = MultiByteToWideChar(CP_UTF8, NULL, strUTF8, (int)strlen(strUTF8), NULL, NULL);
	wchar_t *wszBuffer = new wchar_t[nLen + 1];
	nLen = MultiByteToWideChar(CP_UTF8, NULL, strUTF8, (int)strlen(strUTF8), wszBuffer, nLen);
	wszBuffer[nLen] = 0;

	nLen = WideCharToMultiByte(CP_ACP, NULL, wszBuffer, (int)wcslen(wszBuffer), NULL, NULL, NULL, NULL);
	char *szBuffer = new char[nLen + 1];
	nLen = WideCharToMultiByte(CP_ACP, NULL, wszBuffer, (int)wcslen(wszBuffer), szBuffer, nLen, NULL, NULL);
	szBuffer[nLen] = 0;

	std::string ansistr;
	ansistr = szBuffer;
	//清理内存
	delete szBuffer;
	delete wszBuffer;
	return ansistr;
}

std::string ANSItoUTF8(char* strAnsi)
{
	//获取转换为宽字节后需要的缓冲区大小，创建宽字节缓冲区，936为简体中文GB2312代码页
	unsigned int nLen = MultiByteToWideChar(CP_ACP, NULL, strAnsi, (int)strlen(strAnsi), NULL, NULL);
	wchar_t *wszBuffer = new wchar_t[nLen + 1];
	nLen = MultiByteToWideChar(CP_ACP, NULL, strAnsi, (int)strlen(strAnsi), wszBuffer, nLen);
	wszBuffer[nLen] = 0;
	//获取转为UTF8多字节后需要的缓冲区大小，创建多字节缓冲区
	nLen = WideCharToMultiByte(CP_UTF8, NULL, wszBuffer, (int)wcslen(wszBuffer), NULL, NULL, NULL, NULL);
	char *szBuffer = new char[nLen + 1];
	nLen = WideCharToMultiByte(CP_UTF8, NULL, wszBuffer, (int)wcslen(wszBuffer), szBuffer, nLen, NULL, NULL);
	szBuffer[nLen] = 0;

	std::string utf8str;
	utf8str = szBuffer;
	//内存清理
	delete wszBuffer;
	delete szBuffer;
	return utf8str;
}

#endif

// 需包含locale、string头文件、使用setlocale函数。
// string转wstring
//std::wstring StringToWstring(const std::string str)
//{
//    if (str.size() == 0) {
//        return std::wstring();
//    }

//	unsigned len = str.size() * 2;// 预留字节数
//	setlocale(LC_CTYPE, "");     //必须调用此函数
//	wchar_t *p = new wchar_t[len];// 申请一段内存存放转换后的字符串
//	mbstowcs(p, str.c_str(), len);// 转换
//	std::wstring str1(p);
//	delete[] p;// 释放申请的内存
//	return str1;
//}

//// wstring转string
//std::string WstringToString(const std::wstring str)
//{
//    if (str.size() == 0) {
//        return std::string();
//    }

//	unsigned len = str.size() * 4;
//	setlocale(LC_CTYPE, "");
//	char *p = new char[len];
//	wcstombs(p, str.c_str(), len);
//	std::string str1(p);
//	delete[] p;
//	return str1;
//}

UINT Check_Vehicles_Sys_request(const char* method, const char* xlh, const char* id, const char* lb)
{
    UNUSED(method);
	if (/*(method == NULL) || */(xlh == NULL) || (id == NULL) || (lb == NULL))
		return ABNORMAL_KEY;
	if (strcmp(xlh, g_confJkxlh.c_str()) != 0)return WRONG_JKXLH;
    if (strcmp(id, VEHICLE_JKID) != 0)return WRONG_JKID;
    if (strcmp(lb, VEHICLE_XTLB) != 0)return WRONG_XTLB;
	/*if (strcmp(method , POST_METHOD_ANALYSE_REQUEST) == 0)return VHHICLE_ANALYSE_QUEST;
	else if (strcmp(method, POST_METHOD_PHOTO_REQUEST) == 0)return DOWNLOAD_PHOTO_DATA;*/
	return POST_DATA_OK;
}

UINT Analyse_UrlBuf_Data(struct evhttp_request* req, int process_type)
{
	struct evkeyvalq *headers;
	struct evkeyval *header;
	struct evbuffer *buf;
	char* data;
	UINT len = 0;

	UINT check_process_type = 0;

    evhttp_request_get_uri(req);
    evhttp_request_get_evhttp_uri(req);
    DATA_PRINT(LEVEL_DEBUG, "%s\n",evhttp_request_get_uri(req));
	//printf("query:%s\n", evhttp_uri_get_query(ev_uri));
	
    DATA_PRINT(LEVEL_DEBUG, "Headers:\n");
	headers = evhttp_request_get_input_headers(req);
	for (header = headers->tqh_first; header;
		header = header->next.tqe_next) {
        DATA_PRINT(LEVEL_DEBUG, "  %s: %s\n", header->key, header->value);
	}
	if (process_type == VHHICLE_ANALYSE_QUEST)
	{
		vehicle_inf *v_vehicle_inf = NULL;
		struct evkeyvalq params;
		buf = evhttp_request_get_input_buffer(req);

		len = (UINT)evbuffer_get_length(buf);
		data = (char*)malloc(len + 1);
		evbuffer_copyout(buf, data, len); 
		*(data + len) = 0;

		evhttp_parse_query_str(data, &params);
        DATA_PRINT(LEVEL_DEBUG, "[解析：method=%s ", evhttp_find_header(&params, "method"));
        DATA_PRINT(LEVEL_DEBUG, "jkxlh=%s ", evhttp_find_header(&params, "jkxlh"));
        DATA_PRINT(LEVEL_DEBUG, "jkid=%s ", evhttp_find_header(&params, "jkid"));
        DATA_PRINT(LEVEL_DEBUG, "xtlb=%s]\n", evhttp_find_header(&params, "xtlb"));
		check_process_type = Check_Vehicles_Sys_request(evhttp_find_header(&params, "method"), evhttp_find_header(&params, "jkxlh"), evhttp_find_header(&params, "jkid"), evhttp_find_header(&params, "xtlb"));
        if (check_process_type != POST_DATA_OK)
		{
			free(data);
			evhttp_clear_headers(&params);
			return check_process_type;
		}
		if (evhttp_find_header(&params, "xmlDoc") == NULL)
		{
			free(data);
			evhttp_clear_headers(&params);
			return WRONG_XMLDOC;
		}
		evhttp_clear_headers(&params);
        DATA_PRINT(LEVEL_DEBUG, "%s\n", UTF8toANSI(data).c_str());

        if (VHHICLE_ANALYSE_QUEST == process_type) {
            v_vehicle_inf = new vehicle_inf;
            //v_vehicle_inf->vehicle_sys_uri = uri;

            if(Analyse_Xml_Data((char *)UTF8toANSI(data).c_str(), v_vehicle_inf)) {

                /* IP已被指定为处理特定车辆的机器，不再判定自身是否忙碌 */
                if ( !isTargetDevice() && deviceIsBusy() ) {
                    DATA_PRINT(LEVEL_INFO, "Slave itself is busy, and has rejected the check request. \n\n");

                    free(data);
                    delete v_vehicle_inf;
                    return DEVICE_BUSY;
                } else {
                    DATA_PRINT(LEVEL_INFO, "Received vehicle check request(lsh:%s) from master. \n\n", v_vehicle_inf->m_jylsh.c_str());
                    recordRevCarInfo(v_vehicle_inf,false);
                    download_queue.Put(v_vehicle_inf);
                }
            } else {
                free(data);
                delete v_vehicle_inf;
                return WRONG_XMLDATA;
            }
        }

        free(data);
        return POST_DATA_OK;
	}

    return WRONG_PATH;
//	if (process_type == VHHICLE_ANALYSE_QUEST_RESULT)
//	{
//		check_process_type = POST_DATA_OK;
//		video_inf *v_video_inf = NULL;
//		struct evkeyvalq params;
//		buf = evhttp_request_get_input_buffer(req);

//		len = (UINT)evbuffer_get_length(buf);
//		data = (char*)malloc(len + 1);
//		evbuffer_copyout(buf, data, len);
//		*(data + len) = 0;

//		evhttp_parse_query_str(data, &params);

//		if (check_process_type != POST_DATA_OK)
//		{
//			free(data);
//			evhttp_clear_headers(&params);
//			return check_process_type;
//		}
//		evhttp_clear_headers(&params);
//        DATA_PRINT(LEVEL_DEBUG, "%s\n", UTF8toANSI(data).c_str());

//		if (VHHICLE_ANALYSE_QUEST_RESULT== process_type)
//		{
//			v_video_inf = new video_inf;
//            if (Video_Xml_Data((char *)UTF8toANSI(data).c_str(), v_video_inf)) {
//                free(data);
//				//delete v_video_inf;
//				return VIDEO_GET;
//			}
//			else
//			{
//				free(data);
//				delete v_video_inf;
//				v_video_inf = NULL;
//				return VIDEO_LOSS;
//			}
//		}

//		free(data);
//		return POST_DATA_OK;
//	}


}

BOOL Analyse_Xml_Data(char* xmldata, vehicle_inf * pvehicle_inf)
{
    CMarkup xml;

    xml.SetDoc(xmldata);
	xml.ResetMainPos();
	if (!xml.FindElem())//<root>
		return FALSE;

	xml.IntoElem();
    if (xml.FindElem("vehispara"))
	{
		xml.IntoElem();
		setlocale(LC_ALL, "chs");
        DATA_PRINT(LEVEL_DEBUG, "[解析]\n");
		for (unsigned int i = 0; i < pvehicle_inf->item_description.size(); i++)
		{
            DATA_PRINT(LEVEL_DEBUG, "%d: %s", i, pvehicle_inf->item_description[i].name_tag);
            if (xml.FindElem(std::string(pvehicle_inf->item_description[i].name_tag))) {
				if (strcmp(pvehicle_inf->item_description[i].name_tag , "dbbhglist") == 0)
				{ 
					_dbbhg_list v_dbhhg_list;
					xml.IntoElem();
                    while (xml.FindElem("item"))
					{
                        if (xml.FindChildElem("zpzl"))
                            v_dbhhg_list.zptype = xml.GetChildData();
                        if (xml.FindChildElem("sm"))
                            v_dbhhg_list.dbbhg_desc = xml.GetChildData();
                        if (xml.FindChildElem("jg"))
                            v_dbhhg_list.dbresult = xml.GetChildData();

						pvehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
					}
                    DATA_PRINT(LEVEL_DEBUG, "\n");

                    for (unsigned int i = 0; i<pvehicle_inf->m_dbbhglist.size(); i++) {
                        DATA_PRINT(LEVEL_DEBUG, "[type=%s sm=%s jg=%s]\n",
                            pvehicle_inf->m_dbbhglist[i].zptype.c_str(),
                            pvehicle_inf->m_dbbhglist[i].dbbhg_desc.c_str(),
                            pvehicle_inf->m_dbbhglist[i].dbresult.c_str());
                    }

					xml.OutOfElem();
				}
				else if (strcmp(pvehicle_inf->item_description[i].name_tag , "zplist") == 0)
				{
					_photo_resource v_photo_resource;
					xml.IntoElem();
                    while (xml.FindElem("item"))
					{
                        if (xml.FindChildElem("zpzl"))
						{
                            unsigned int s = 0;
                            std::string zpzltemp = xml.GetChildData();
                            vector<std::string> zpzl_check = ZPZL_CHECK;
							for (s = 0; s < zpzl_check.size(); s++)
							{
								if (zpzltemp == zpzl_check[s])
									break;
							}
							
                            //if (s < zpzl_check.size())//ignore some photos
                            if (1)
                            {
                                v_photo_resource.zptype = zpzltemp;
								
								if (xml.FindChildElem("zpurl"))
                                    v_photo_resource.zpurl = xml.GetChildData();

                                v_photo_resource.local_path = "TBD";
								pvehicle_inf->m_zplist.push_back(v_photo_resource);
							}
						}
					}

                    DATA_PRINT(LEVEL_DEBUG, "\n");

                    for (unsigned int i = 0; i<pvehicle_inf->m_zplist.size(); i++) {
                        DATA_PRINT(LEVEL_DEBUG, "[zptype=%s url=%s loc=%s]\n",
                            pvehicle_inf->m_zplist[i].zptype.c_str(),
                            pvehicle_inf->m_zplist[i].zpurl.c_str(),
                            pvehicle_inf->m_zplist[i].local_path.c_str());
                    }

					xml.OutOfElem();
				}
				else if (strcmp(pvehicle_inf->item_description[i].name_tag, "splist") == 0)
				{
					_video_resource v_video_resource;
					xml.IntoElem();
                    while (xml.FindElem("item"))
					{
                        if (xml.FindChildElem("sptype"))
                            v_video_resource.sptype = xml.GetChildData();
                        if (xml.FindChildElem("dzzl"))
                            v_video_resource.dzzl = xml.GetChildData();
                        if (xml.FindChildElem("id"))
                            v_video_resource.id = xml.GetChildData();
                        if (xml.FindChildElem("spzl"))
                            v_video_resource.spzl = xml.GetChildData();
                        if (xml.FindChildElem("spurl"))
                            v_video_resource.spurl = xml.GetChildData();
                        v_video_resource.local_path = "TBD";
						pvehicle_inf->m_splist.push_back(v_video_resource);
					}
                    DATA_PRINT(LEVEL_DEBUG, "\n");

                    for (unsigned int i = 0; i<pvehicle_inf->m_splist.size(); i++) {
                        DATA_PRINT(LEVEL_DEBUG, "[sptype=%s dzzl=%s url=%s loc=%s]\n",
                            pvehicle_inf->m_splist[i].sptype.c_str(),
                            pvehicle_inf->m_splist[i].dzzl.c_str(),
                            pvehicle_inf->m_splist[i].spurl.c_str(),
                            pvehicle_inf->m_splist[i].local_path.c_str());
                    }

					xml.OutOfElem();
				}
				else if (strcmp(pvehicle_inf->item_description[i].name_tag , "ckdbzplist") == 0)
				{
					_photo_resource v_photo_resource;
					xml.IntoElem();
                    while (xml.FindElem("item"))
					{
                        if (xml.FindChildElem("zpzl"))
                            v_photo_resource.zptype = xml.GetChildData();
                        if (xml.FindChildElem("zpurl"))
                            v_photo_resource.zpurl = xml.GetChildData();

						pvehicle_inf->m_ckdbzplist.push_back(v_photo_resource);
					}
                    DATA_PRINT(LEVEL_DEBUG, "\n");

                    for (unsigned int i = 0; i<pvehicle_inf->m_ckdbzplist.size(); i++) {
                        DATA_PRINT(LEVEL_DEBUG, "[ckzptype=%s url=%s loc=%s]\n",
                            pvehicle_inf->m_ckdbzplist[i].zptype.c_str(),
                            pvehicle_inf->m_ckdbzplist[i].zpurl.c_str(),
                            pvehicle_inf->m_ckdbzplist[i].local_path.c_str());
                    }

					xml.OutOfElem();
				}
				else  //other basic inf:
				{
                    *(std::string *)(pvehicle_inf->item_description[i].value) = xml.GetData();
                    DATA_PRINT(LEVEL_DEBUG, " %s=%s\n", pvehicle_inf->item_description[i].name_desc,
                        (*(std::string *)(pvehicle_inf->item_description[i].value)).c_str());
				}
			}
			else
				DATA_PRINT(LEVEL_DEBUG, " no found\n");

			xml.ResetMainPos();
			xml.ResetChildPos();
		}
        if(xml.FindElem("video_check"))
        {
           pvehicle_inf->is_video_check = true;
        }

        return TRUE;
	}
	return FALSE;
}


//BOOL Video_Xml_Data(char* xmldata, video_inf * video_inf)
//{

//    CMarkup xml;
//    int count;
//    xml.SetDoc(xmldata);
//    xml.ResetMainPos();
//    if (!xml.FindElem())//<root>
//        return FALSE;
//    xml.IntoElem();
//    if (xml.FindElem("head"))
//    {
//        for (unsigned int i = 0; i < video_inf->item_description.size(); i++)
//        {
//            //DATA_PRINT(LEVEL_DEBUG, "%d: %s", i, video_inf->item_description[i].name_tag);
//            if (xml.FindChildElem(video_inf->item_description[i].name_tag)){
//                *(string*)video_inf->item_description[i].value = xml.GetChildData();
//                if (i==7)
//                {
//                    std:string cc = xml.GetChildData();
//                    count = atoi(cc.c_str());
//                }
//            }
//            xml.ResetChildPos();
//        }
//    }
//    if (xml.FindElem("body"))
//    {
//        xml.IntoElem();
//        for (int i = 0; i < count; i++)
//        {
//            _video_resource buf;
//            xml.FindElem("video");
//            xml.FindChildElem("spzl");
//            buf.spzl = xml.GetChildData();
//            xml.FindChildElem("spurl");
//            std::string video_url= xml.GetChildData();
//            video_url=sqlencode(video_url);
//            buf.spurl = video_url;
//            buf.local_path = g_videoFilePath;
//            std::time_t t = std::time(NULL);
//            std::tm *st = std::localtime(&t);
//            char tmpArray[128] = { 0 };
//            sprintf(tmpArray, "%d-%02d-%02d", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);
//            std::string strCurTime = tmpArray;
//            buf.local_path+=strCurTime;

//#ifdef CHE_JIAN_LINUX
//            struct stat st_buf = {0};
//            stat(buf.local_path.c_str(), &st_buf);
//            if ((st_buf.st_mode & S_IFMT) != S_IFDIR) {
//                mkdir(buf.local_path.c_str(), 0777);
//            }
//#else
//            if (!PathIsDirectory(buf.local_path.c_str()))
//            CreateDirectory(buf.local_path.c_str(), NULL);
//#endif
//            buf.local_path += "/";
//            string urlc = buf.spzl;
//            if ((urlc.find("0111")) != std::string::npos) {
//                buf.sptype = "0111";
//            }
//            if ((urlc.find("0112")) != std::string::npos) {
//                buf.sptype = "0112";
//            }
//            if ((urlc.find("0323")) != std::string::npos) {
//                buf.sptype = "0323";
//            }
//            if ((urlc.find("0321")) != std::string::npos) {
//                buf.sptype = "0321";
//            }
//            if ((urlc.find("0352")) != std::string::npos) {
//                buf.sptype = "0352";
//            }
//            if ((urlc.find("0322")) != std::string::npos) {
//                buf.sptype = "0322";
//            }
//            if ((urlc.find("0348")) != std::string::npos) {
//                buf.sptype = "0348";
//            }
//            if ((urlc.find("0351")) != std::string::npos) {
//                buf.sptype = "0351";
//            }
//            if ((urlc.find("0344")) != std::string::npos) {
//                buf.sptype = "0344";
//            }
//            if ((urlc.find("0342")) != std::string::npos) {
//                buf.sptype = "0342";
//            }
		
//            buf.dzzl = "ftp";
//            buf.local_path += buf.spzl + "_" + video_inf->v_hphm + "_" + video_inf->v_jyjgbh + ".MP4";


//            video_inf->v_splist.push_back(buf);
//        }
//    }
//    if (0 == count)
//        return FALSE;
//    else
//    {
//        video_queue.Put(video_inf);
//        return TRUE;
//    }
//    return FALSE;
//}

//std::string sqlencode(std::string data)
//{
////    std::string::size_type pos(0);
////    if ((pos = data.find("苏")) != std::string::npos) {
////        data.replace(pos, 2, "%e8%8b%8f");
////    }
//    std::string::size_type pos1(0);
//    while ((pos1 = data.find("\\")) != std::string::npos) {
//        data.replace(pos1, 1, "/");
//    }
//    return data;
//}

/* 将未知IP的请求记录数据库中 */
void recordUnknownRequest(struct evhttp_request *req, std::string method, std::string uri)
{
    std::string port;

    try {
        port = std::to_string(req->remote_port);
    } catch (const std::exception &e) {
        DATA_PRINT(LEVEL_ERROR, "Exception! std::to_string() \n");
        DATA_PRINT(LEVEL_ERROR, "Exception cause: %s \n", e.what());
        port = "unknown";
    }

    MySQL_DB db;
    if (db.connect(NULL, 6033, "root", getDBPassWord(DBPWD).c_str(), "car_schema")) {
        std::string sql;

        sql = "(IP, port, method, URI) VALUES (";
        sql += "'" + std::string(req->remote_host) + "',";
        sql += "'" + port + "',";
        sql += "'" + method + "',";
        sql += "'" + uri + "')";

        db.insert("unknown_request", sql.c_str());
    }

    db.disconnect();
}
