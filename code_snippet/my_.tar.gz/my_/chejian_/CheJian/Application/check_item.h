#ifndef _CHECK_ITEM_
#define _CHECK_ITEM_

#include <vector>
#include <string>

struct p_ZuoQianFang {
	bool ChePai;
	bool CheBiao;
	bool SanJiaoJia;
    bool CheShenFanGuangBiaoShi;
    bool ZuoCePenTu;
    bool ZuoCeFangHu;
	bool GaiZhuang;
    bool DangAn;
	bool ShuiYinRiQi;
    bool FangXiang;
    bool CheShenYanSe;
};

struct p_ZuoFang {
    bool ChePai;
    bool GaiZhuang;
    bool GuangGao;
    bool ShuiYinRiQi;
    bool CheShenYanSe;
};

struct p_YouHouFang {
	bool ChePai;
	bool CheBiao;
	bool SanJiaoJia;
    bool HouBuCheShenFanGuangBiaoShi;
    bool YouCeCheShenFanGuangBiaoShi;
    bool LanBanGaoDu;
    bool CheLiangWeiBuBiaoZhiBan;
    bool HouXiaFangHu;
    bool YouCeFangHu;
    bool HouBuPenTu;
    bool GaiZhuang;
	bool ShuiYinRiQi;
    bool PaiQiKong;
    bool FangXiang;
    bool CheShenYanSe;
};

struct p_CheJiaHao {
	bool CheJiaHao;
	bool ShuiYinRiQi;
	bool TaYinMo;
    bool DangAn;
    bool BaoDing_FTP;
    bool JiLuBiaoZiMo;
    bool YuanJing;
    bool b_nanjing_vin;
};

struct p_ZuoQianLunTaiGuiGeXingHaoZhaoPian {
    bool GuiGeXingHao;
};
struct p_LunTaiWenLiJinZhao {
    bool LunTaiWenLiShenDu;
};

struct p_AnQuanDai {
	bool AnQuanDai;
	bool ShuiYinRiQi;
};

struct p_XingShiZheng {
	bool CheJiaHao;
	bool ChePai;
	bool BianHao;
	bool FaZhengRiQi;
    bool BeiMian;
    bool ShenFenZheng;
    bool TianJin;
    bool CheLiang;
};

struct p_XingShiZhengBeiMian {
    bool ZhuYe;
    bool FuYe;
    bool ShenFenZheng;
    bool YouXiaoQi;
};

struct p_JiaoQiangXian {
	bool FuBen;
	bool ChePai;
    bool ChaoJian;
	bool CheJiaHao;
	bool YouXiaoQi;
	bool GongZhang;
	bool CheChuanShui;
	bool DianZiBaoDan;
    bool FaDongJiHao;
    bool ShenZhenDianZiBaoDan;
    bool SuZhouYinZhang;
};

struct p_CheChuanShui {
	bool CheJiaHao;
	bool RiQi;
};

struct p_JianYanBaoGao {
	bool CheJiaHao;
	bool ChePai;
    bool HaoPaiZhongLei;
	bool QianMing;
	bool YinZhang;
	bool JieLun;
	bool ShuJuXiang;
    bool YinZhang_MA;
    bool QueRenZhang;
    bool CheLiangType;       // 车辆类型和检测类型是否匹配（南宁）
    bool JianYanRiQi;
};
struct p_JianYanBiaoBeiMian {
    bool JianYanBiaoBeiMian;
    bool WaiGuan;
    bool YinChe;
    bool DiPan;
};
struct p_JianCeQuXianBaoGao{
    bool QuXianBaoGao;
    bool ChePai;
    bool YinZhang;
};
struct p_CheJiaHaoUG{
    bool CheJiaHao;
};
struct p_CheLiangMingPai{
    bool CheJiaHao;
    bool FaDongJiHao;
    bool FaDongJiPaiLiang;
    bool ZhiZaoNianYue;
};

// +{{ xeast 2018-06-23 for ning bo
struct p_JianYanBaoGao_YiQi {
    bool YiQi;              //is "yiqi"
    bool HongZhang;         //if 'hongzhang' exist
    bool JieLun;            //if 'jianyanjielun' pass
    bool ChePai;            //is 'chepai' correct
    bool CheJiaHao;         //is 'chejiahao' correct
    bool QianMing;
    bool YinZhang_MA;
};

struct p_JianYanBaoGao_RenGong{
    bool ChaYanJieLun;
    bool ChePai;
    bool WaiGuanQianZi;
    bool YinCheQianZi;
    bool DiPanQianZi;
    bool QianMing;          //签名
};

struct p_WeiTuoShu {
    bool WeiTuoShu; //is weituoshu
    bool HongZhang; //if 'hongzhang' exist
    bool ShenFenZheng; // if ShenFenZheng exist
};

struct p_WeiTuoTongZhiShu {
    bool WeiTuoTongZhiShu; //is weituotongzhishu
    bool ChePai;
    bool CheJiaHao;
    bool YinZhang; //is 'yinzhang' exist
};

struct p_WanShuiZhengMing {
    bool CheJiaHao;
    bool ChePai;
    bool CheChuanShui;
    bool SuoShuRiQi;
    bool JianCeRiQi;
    bool BaoXianDan;
};
// }}

struct p_ShenQingBiao {
	bool ShouJi_BenRen;
	bool ShouJi_DaiLi;
	bool ChePai;
    bool is_CheLiangType;       // 车辆类型和检测类型是否匹配（重庆）
    bool is_YouBian;            // 邮编号码（重庆）
    bool is_DiZhi;              // 地址是否填写（重庆）
    bool CheJiaHao;
	bool QianMing;
    bool YinZhang;
    bool XingMing;
    bool HaoPaiZhongLei;
    bool JianYanHeGeBiaoZhi;
};

struct p_WeiQiJianYan {
	bool JieLun;
	bool ChePai;
	bool CheJiaHao;
	bool YinZhang;
	bool QianMing;
    bool YinZhang_MA;
    bool DianZiBaoGao;
    bool PiZhunRen;
    bool CaoZuoYuan;
    bool JiaShiYuan;
    bool ShenHeYuan;
    bool JianCeShiJian;
    bool DianZiBiaoGe;
    bool FaDongJiBianHao;
    bool YouXiaoQi;
};

struct p_GaoZhiShu {
    bool GaoZhiShu;
    bool HongZhang;
    bool QianMing;
};

struct p_RongQueShouLi
{
    bool DuiGou;
    bool QianMing;
};

struct p_ZuoDengGuang {
	bool ZuoQianDeng;
	bool YouQianDeng;
	bool ChePai;
	bool QianMian;
    bool ShuiYinRiQi;
};

struct p_YouDengGuang {
	bool ZuoQianDeng;
	bool YouQianDeng;
	bool ChePai;
	bool QianMian;
    bool ShuiYinRiQi;
};

struct p_YiZhouZhiDong {
	bool QianLun;
	bool ChePai;
    bool ShuiYinRiQi;
};

struct p_ErZhouZhiDong {
	bool HouLun;
	bool ChePai;
    bool ShuiYinRiQi;
};

struct p_ZhuCheZhiDong {
	bool ChePai;
    bool CheLun;
    bool ShuiYinRiQi;
};

struct p_DiPanDongTaiKaiShi {
	bool ChePai;
    bool ChePaiQueDing;
	bool YiDong;
	bool ShuiYinRiQi;
    bool BiaoZhi;
    bool CheWei;
};

struct p_DiPanDongTaiJieShu {
	bool ChePai;
	bool YiDong;
	bool ShuiYinRiQi;
    bool BiaoZhi;
    bool CheTou;
};

struct p_DiPanBuJian {
	bool GongWei;
	bool ChePai;
    bool ShuiYinRiQi;
    bool Ren;
};

struct p_ChaYanJiLu {
	bool JianYanBiao;
    bool ChaYanXinXi;
	bool ChePai;
	bool CheJiaHao;
    bool ChaYanJieLun;
    bool ChaYanQianZi;
	bool WaiGuanQianZi;
	bool YinCheQianZi;
	bool DiPanQianZi;
    bool HongZhang;
};

struct p_MieHuoQi {
	bool MieHuoQi;
	bool YaLiBiao;
};

struct p_YingJiChui {
	bool YingJiChui;
};

struct p_JiLuYi {
	bool JiLuYi;
	bool RenZheng;
	bool PingMu;
};
struct p_ShenFenZheng {
    bool ShenFenZheng;
    bool XingMing;
};

struct p_ShenFenZhengBeiMian {
    bool ShenFenZheng;
    bool YouXiaoQi;
};


struct p_ZuoQianLun {
	bool LunTai;
};

struct p_HeDingZaiKe {
    bool HeDingZaiKe;
};


struct p_YouQianLun {
	bool LunTai;
};

struct p_QianHaoPaiTeXie{

    bool luosi;
    bool chepai;
};
struct p_HouHaoPaiTeXie{

    bool luosi;
    bool chepai;
};
struct p_QianLunZhaoPian {
    bool b_chepai;
};
struct p_HouLunZhaoPian {
    bool b_chepai;
};

struct p_CheXiang {
    bool GaiZhuang;
    bool FengDing;
    bool ZuoWei;
    bool CheLiangLeiXing;
    bool JiaoDu;
};

struct p_HouPaiCheXiang {
    bool AnQuanDai;
};

struct p_CeHuaGongWei {
    bool ChePai;
};

struct p_WaiKuoQianMian {
    bool ChePai;
};

struct p_WaiKuoCeMian {
    bool ChePai;
};

struct p_QianHaoPai {
    bool ChePai;
    bool ShuiYinRiQi;
};
struct p_HouHaoPai {
    bool ChePai;
    bool ShuiYinRiQi;
};

struct p_DaCheHaoPai {
    bool ChePai;
};

struct p_WeiXiangNeiBu {
    bool GaiZhuang;
};
struct p_FuZhuZhiDong {
    bool FuZhuZhiDong;
};
struct p_CheLiangCeMian {
    bool CheLiangCeMian;
    bool ShuiYinRiQi;
};
struct p_CheLiangBeiMian {
    bool CheLiangBeiMian;
    bool ChePai;
    bool CheBiao;
    bool SanJiaoJia;
    bool XiaBuFangHu;
    bool WeiBuBiaoZhi;
    bool CheShenFanGuangBiaoShi;
    bool PenTuHaoMa;
    bool ShuiYinRiQi;
    bool WeiDeng;
};
struct p_ABS {
    bool ABS;
};

/*26张照片(实际处理25张，车船税会合并在其他照片中)  */
struct CheckPicture {
    p_ZuoQianFang		 ZuoQianFang;
    p_ZuoFang            ZuoFang;
    p_YouHouFang		 YouHouFang;
	p_CheJiaHao			 CheJiaHao;
    p_ZuoQianLunTaiGuiGeXingHaoZhaoPian ZuoQianLunTaiGuiGeXingHaoZhaoPian;
    p_LunTaiWenLiJinZhao LunTaiWenLiJinZhao;
	p_AnQuanDai			 AnQuanDai;
	p_XingShiZheng		 XingShiZheng;
    p_XingShiZhengBeiMian XingShiZhengBeiMian;
	p_JiaoQiangXian		 JiaoQiangXian;
	p_CheChuanShui		 CheChuanShui;
	p_JianYanBaoGao		 JianYanBaoGao;
    p_JianYanBiaoBeiMian JianYanBiaoBeiMian;
    // +{{ xeast 2018-06-23 for ning bo
    p_JianYanBaoGao_YiQi JianYanBaoGao_YiQi;
    p_JianYanBaoGao_RenGong JianYanBaoGao_RenGong;
    p_WeiTuoShu          WeiTuoShu;
    p_WeiTuoTongZhiShu   WeiTuoTongZhiShu;
    p_WanShuiZhengMing   WanShuiZhengMing;
    p_GaoZhiShu          GaoZhiShu;
    p_RongQueShouLi      RongQueShouLi;
    // }}

    p_ShenQingBiao		 ShenQingBiao;
	p_WeiQiJianYan		 WeiQiJianYan;
    p_WeiQiJianYan		 WeiQiJianYan2;
	p_ZuoDengGuang		 ZuoDengGuang;
	p_YouDengGuang		 YouDengGuang;
	p_YiZhouZhiDong		 YiZhouZhiDong;
	p_ErZhouZhiDong		 ErZhouZhiDong;
	p_ZhuCheZhiDong		 ZhuCheZhiDong;
	p_DiPanDongTaiKaiShi DiPanDongTaiKaiShi;
	p_DiPanDongTaiJieShu DiPanDongTaiJieShu;
	p_DiPanBuJian		 DiPanBuJian;
	p_ChaYanJiLu		 ChaYanJiLu;
	p_MieHuoQi			 MieHuoQi;
	p_YingJiChui		 YingJiChui;
	p_JiLuYi			 JiLuYi;
    p_ShenFenZheng	     ShenFenZheng;
    p_ShenFenZhengBeiMian ShenFenZhengBeiMian;
	p_ZuoQianLun		 ZuoQianLun;
	p_YouQianLun		 YouQianLun;
    p_CheXiang           CheXiang;
    p_HouPaiCheXiang     HouPaiCheXiang;
    p_HouPaiCheXiang     HouPaiCheXiang2;
    p_CeHuaGongWei       CeHuaGongWei;
    p_WaiKuoQianMian     WaiKuoQianMian;
    p_WaiKuoCeMian       WaiKuoCeMian;
    p_QianHaoPai         QianHaoPai;
    p_HouHaoPai          HouHaoPai;
    p_DaCheHaoPai        DaCheHaoPai;
    p_WeiXiangNeiBu      WeiXiangNeiBu;
    p_FuZhuZhiDong       FuZhuZhiDong;
    p_ABS                ABS;
    p_CheLiangCeMian     CheLiangCeMian;
    p_CheLiangBeiMian    CheLiangBeiMian;
    p_HeDingZaiKe        HeDingZaiKe;
    p_JianCeQuXianBaoGao JianCeQuXianBaoGao;
    p_CheJiaHaoUG        CheJiaHaoUG;
    p_CheLiangMingPai    CheLiangMingPai;
    p_QianHaoPaiTeXie    QianHaoPaiTeXie;
    p_HouHaoPaiTeXie     HouHaoPaiTeXie;
    p_QianLunZhaoPian    QianLunZhaoPian;
    p_HouLunZhaoPian     HouLunZhaoPian;
};

struct v_ZuoQianFang {
	bool ChePai;
};

struct v_YouHouFang {
	bool ChePai;
};

//struct v_PingBanZhiDong {
//	bool ChePai;
//	bool PingBan;
//	bool WeiDeng;
//	bool Ren;
//};

struct v_YiZhouZhiDong{
	bool ChePai;
	bool QianLun;
	bool WeiDeng;
	bool Ren;
};

struct v_ErZhouZhiDong {
	bool ChePai;
	bool HouLun;
	bool WeiDeng;
	bool Ren;
};

struct v_ZuoDengGuang {
	bool ChePai;
	bool QianDaDeng;
	bool Ren;
	bool CeShiYi;
};

struct v_YouDengGuang {
	bool ChePai;
	bool QianDaDeng;
	bool Ren;
	bool CeShiYi;
};

struct v_DongTaiGongWei_1 {
	bool ChePai;
	bool WeiYi;
};

struct v_DongTaiGongWei_2 {
	bool ChePai;
	bool WeiYi;
};

struct v_DiPanGongWei {
	bool Ren;
};

struct v_ZhuCheZhiDong {
    bool ChePai;
    bool HouLun;
    bool TaiQi;
    bool WeiDeng;
    bool Ren;
};

//struct v_ZhuCheZhiDong_GunTong {
//	bool ChePai;
//	bool HouLun;
//	bool TaiQi;
//	bool Ren;
//};

//struct v_ZhuCheZhiDong_PingBan {
//	bool ChePai;
//	bool CheLun;
//	bool WeiDeng;
//	bool Ren;
//};

/* 11个视频 */
struct CheckVideo {
	v_ZuoQianFang			ZuoQianFang;
	v_YouHouFang			YouHouFang;
	v_YiZhouZhiDong			YiZhouZhiDong;
	v_ErZhouZhiDong			ErZhouZhiDong;
	v_ZuoDengGuang			ZuoDengGuang;
	v_YouDengGuang			YouDengGuang;
	v_DongTaiGongWei_1		DongTaiGongWei_1;
	v_DongTaiGongWei_2		DongTaiGongWei_2;
	v_DiPanGongWei			DiPanGongWei;
    v_ZhuCheZhiDong         ZhuCheZhiDong;

};

struct GongZuoShiJian {
	int KaiShi = 0;
	int JieShu = 24;
};

struct DownloadVideo {
	bool soapflag;
	bool dlflag;
    bool shizhongshenheflag = false;
};

struct t_JianYanJiGou {
	std::string bh;
    std::string assignment_IP;  /* 检验机构指定IP */
};

struct CheckItem {
    std::string City;
    int ZhuCongYiZhi;
	GongZuoShiJian ShiJian;
	std::vector<std::string> JianYanLeiBie;
	std::vector<std::string> ShiYongXingZhi;
	std::vector<std::string> CheLiangZhongLei;
	std::vector<t_JianYanJiGou> JianYanJiGou;
	CheckPicture picture;
	CheckVideo video;
	DownloadVideo dlvideo;
};

extern CheckItem g_CheckItem;

/* 定义城市编码，用于区分不同城市的定制功能 */
#define BAODING     "1306"  /* 保定 */
#define SUZHOU      "3205"  /* 苏州 */
#define QINGHAI     "6300"  /* 青海 */
#define NINGBO      "3302"  /* 宁波 */
#define WUHAN       "4201"  /* 武汉 */
#define CHONGQING   "5000"  /* 重庆 */
#define NANNING     "4501"  /* 南宁 */
#define LINYI       "3713"  /* 临沂 */
#define SHENZHEN    "4403"  /* 深圳 */
#define NANCHANG    "3601"  /* 南昌 */
#define HULUNBEIER  "1507"  /* 呼伦贝尔 */
#define TIANJIN     "1200"  /* 天津 */
#define HENGSHUI    "1311"  /* 衡水 */
#define ANSHUN      "5204"  /* 安顺 */
#define PUTIAN      "3503"  /* 莆田 */
#define ZHOUKOU     "4116"  /* 周口 */
#define QIANDONGNAN "5226"  /* 黔东南 */
#define NANJING     "3201"  /* 南京 */
#define XUZHOU      "3203"  /* 徐州 */
#define FOSHAN      "4406"  /* 佛山 */
#define ZHAOTONG    "5306"  /* 昭通 */
#define LIANYUNGANG "3207"  /* 连云港 */
#define SHANGRAO    "3611"  /* 上饶 */
#define LINFEN      "1410"  /* 临汾 */
#define FUZHOU      "3501"  /* 福州 */
#define HUZHOU      "3305"  /* 湖州 */
#define GUIGANG     "4508"  /* 贵港 */
#define YUEYANG     "4306"  /* 岳阳 */
#define ZHANGJIAJIE "4308"  /* 张家界 */
#define JIUJIANG    "3604"
#define JIAOZUO     "4108"  /* 焦作 */
#define SHANGHAI    "3100"  /* 上海 */
#define XIAN        "6101"  /* 西安 */
#define XIANGYANG   "4206"  /* 襄阳 */
#define FUZHOU2     "3610"  /* 抚州 */
#define NANCHONG    "5113"  /* 南充 */
#define LIANGSHAN   "5134"  /* 凉山 */
#define YICHUN      "3609"  /* 宜春 */
#define NANPING     "3507"  /* 南平 */
#define DAQING      "2306"  /* 大庆 */
#define ZHONGSHAN   "4420"  /* 中山 */
#define DEZHOU      "3714"  /* 德州 */
#define TAIYUAN     "1401"  /* 太原 */
#define NANYANG     "4113"  /* 南阳*/
#define QUZHOU      "3308"  /* 衢州*/
#define XINYU       "3605"
#define DONGGUAN    "4419"  /* 东莞*/
#define YULIN       "4509"  /* 玉林*/
#define JIAXING     "3304"  /* 嘉兴*/
#define LAIBIN      "4514"  /* 来宾*/
#define BINZHOU     "3716"  /* 滨州 */
#define LANGFANG    "1310"  /* 廊坊*/
#define XIANNING    "4212"  /* 咸宁*/
#define ZAOZHANG    "3704"  /* 枣庄*/
#define QingDao     "3702"  /* 青岛*/
#endif	//_CHECK_ITEM_
