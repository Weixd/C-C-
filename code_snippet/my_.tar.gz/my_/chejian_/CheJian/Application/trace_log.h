#ifndef TRACE_LOG_H
#define TRACE_LOG_H

#include <cstdio>
#include <stdint.h>
#include <iostream>
#include "glog/logging.h"
#include "./helper/DateTime.h"
#include "string.h"
#define LEVEL_ERROR          1	/* 程序运行中的错误信息 */
#define LEVEL_INFO           2	/* 程序正常运行中的必要流程信息（Release版本的程序请在配置文件中使用这个等级） */
#define LEVEL_DEBUG          3	/* 程序开发调试过程中的信息 */

extern unsigned int g_debug_level;

//#define DATA_PRINT(level, ...) do {if (level <= g_debug_level) printf(__VA_ARGS__); } while(0)
//#define DATA_PRINT(level, ...) ( (level <= g_debug_level) ? printf(__VA_ARGS__) : NULL )

#define DATA_PRINT(lever, ...) \
{\
    DateTime dt;\
    std::string dtStr="["+dt.ToDateTimeString()+"]";\
    char gbuf[1024*16]={0};\
    sprintf(gbuf,dtStr.c_str());\
    snprintf(gbuf+dtStr.length(), 1024*16-dtStr.length(), __VA_ARGS__);\
    if(lever <= g_debug_level)\
        printf(gbuf);\
    if(lever == LEVEL_ERROR)\
        LOG(ERROR) << (gbuf+dtStr.length());\
    else if(lever == LEVEL_INFO)\
        LOG(INFO) << (gbuf+dtStr.length());\
    else if(lever == LEVEL_DEBUG)\
        LOG(WARNING) << (gbuf+dtStr.length());\
}

#define TRYCATCH(x,N)         \
if (g_debug_level <= 4){try{x;}catch (exception e){TRACE_PRINT(LEVEL_ERROR, "----------------------Crash!!!-------------------\n");N++;}} \
else{x;}

#ifdef CHE_JIAN_LINUX
    #include <sys/stat.h>

    /* inet_ntoa函数需要 */
    #include <sys/socket.h>
    #include <netinet/in.h>
    #include <arpa/inet.h>

    #include <iconv.h>

    /* access函数需要 */
    #include <unistd.h>

    typedef unsigned int    UINT;
    typedef unsigned char	UINT8;
    typedef int             BOOL;
    typedef unsigned char   BYTE;

    /* 由于目前调用itoa的时候，都是10进制，所以radix被省略 */
    #define itoa(number, array, radix) sprintf(array, "%d", number)

    #ifndef FALSE
        #define FALSE 0
    #endif

    #ifndef TRUE
        #define TRUE 1
    #endif

#endif

#ifdef CHE_JIAN_LINUX
    #define TRACE_PRINT(level, fmt, ...) \
        ((level<=g_debug_level) ? printf("%s(%d)-<%s>:" fmt, __FILE__, __LINE__, __FUNCTION__, ##__VA_ARGS__) : NULL)
#else

    /* Linux系统不能同时使用printf和wprintf，目前暂定Linux只使用printf  */
    #define WDATA_PRINT(level, ...) ((level<=g_debug_level) ? wprintf(__VA_ARGS__) : NULL)

    #define TRACE_PRINT(level,fmt, ...) \
        ((level<=g_debug_level) ? printf("%s(%d)-<%s>:"##fmt, __FILE__, __LINE__, __FUNCTION__, ##__VA_ARGS__) : NULL)
#endif

void getVehicleCheck();
void getCheckItem();
void getCheckItemData(std::string strPath);


//void DATA_PRINT(unsigned int lever, const char* fmt, ...);



#define DBPWD "ju3eizd1;57?"
std::string getDBPassWord(std::string passWord);
std::string setPassWord(std::string passWord);

#endif
