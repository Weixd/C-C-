/*
		所有判定项（包括照片和视频）的相关处理时间统计。
*/

#pragma once

#ifndef _TIME_RECORD_
#define _TIME_RECORD_

#include <string>
#include <chrono>
#include <vector>
#include "AlgProcess/base/baseglobal.h"

class pic_classItem {
public:
    PicType type; //对应字段名称
    std::string dbtype; //数据库对应类型生成sql，需要符合数据语法

    std::string desc; // 描述
    std::string *value; //值地址
};

/* 每种照片的算法处理时间（共52种） */
class p_picture_process {
  public:
	std::string xsz;
	std::string sqb;
	std::string jqx;
	std::string jybg;
	std::string cyjl;
	std::string zqf;
    std::string zf;
    std::string yhf;
	std::string cjh;
	std::string aqd;
	std::string zdg;
	std::string ydg;
	std::string yzzd;
	std::string ezzd;
	std::string zczd;
	std::string dpdtks;
	std::string dpdtjs;
	std::string dpjy;
	std::string wqjy;
	std::string mhq;
	std::string yjc;
	std::string jly;
	std::string zql;
	std::string yql;
    std::string xszbk;
    std::string jyb_bk;
    std::string wts;
    std::string zqfcf;
    std::string yhfcf;
    std::string cjhcf;
    std::string wszm;
    std::string wttzs;
    std::string jyhgzm;
    std::string hdzk;
    std::string dchw;
    std::string sfz;
    std::string sfzbk;
    std::string jcqxbg;
    std::string chexiang;
    std::string cjh_ug;
    std::string chgw;
    std::string waikuoqianmian;
    std::string waikuocemian;
    std::string wxnb;
    std::string fzzd;
    std::string abs;
    std::string clcm;
    std::string cjhyj;
    std::string qhp;
    std::string hhp;
    std::string clbm;
    std::string dchp;
    std::string hpls;
    std::string qltzp;
    std::string hltzp;

    std::vector<pic_classItem> ItemList = {
        { e0201,"","行驶证", &xsz},
        { e0202,"","申请表", &sqb},
        { e0203,"","交强险", &jqx},
        { e0204,"","记录报告", &jybg},
        { e0205,"","查验记录", &cyjl},
        { e0111,"","左前方", &zqf},
        { e0175,"","左方", &zf},
        { e0112,"","右后方", &yhf},
        { e0113,"","车架号", &cjh},
        { e0157,"","安全带", &aqd},
        { e0321,"","左灯光", &zdg},
        { e0352,"","右灯光", &ydg},
        { e0322,"","一轴制动", &yzzd},
        { e0348,"","二轴制动", &ezzd},
        { e0351,"","驻车制动", &zczd},
        { e0344,"","底盘动态开始", &dpdtks},
        { e0342,"","底盘动态结束", &dpdtjs},
        { e0323,"","地盘检验", &dpjy},
        { e0209,"","尾气检验", &wqjy},
        { eNULL,"","图片类型", &mhq},
        { eNULL,"","图片类型", &yjc},
        { eNULL,"","图片类型", &jly},
        { e0136,"","左轮胎规格", &zql},
        { e0156,"","右轮胎规格", &yql},
        { eNULL,"","图片类型", &xszbk},
        { eNULL,"","图片类型", &jyb_bk},
        { eNULL,"","图片类型", &wts},
        { eNULL,"","图片类型", &zqfcf},
        { eNULL,"","图片类型", &yhfcf},
        { eNULL,"","图片类型", &cjhcf},
        { e0206,"","完税证明", &wszm},
        { eNULL,"","图片类型", &wttzs},
        { eNULL,"","图片类型", &jyhgzm},
        { eNULL,"","图片类型", &hdzk},
        { eNULL,"","图片类型", &dchw},
        { eNULL,"","图片类型", &sfz},
        { eNULL,"","图片类型", &sfzbk},
        { eNULL,"","图片类型", &jcqxbg},
        { eNULL,"","图片类型", &chexiang},
        { eNULL,"","图片类型", &cjh_ug},
        { eNULL,"","图片类型", &chgw},
        { eNULL,"","图片类型", &waikuoqianmian},
        { eNULL,"","图片类型", &waikuocemian},
        { eNULL,"","图片类型", &wxnb},
        { eNULL,"","图片类型", &fzzd},
        { eNULL,"","图片类型", &abs},
        { eNULL,"","图片类型", &clcm},
        { eNULL,"","图片类型", &cjhyj},
        { e0167,"","车前方", &qhp},
        { e0168,"","车后方", &hhp},
        { eNULL,"","图片类型", &clbm},
        { eNULL,"","图片类型", &dchp},
        { eNULL,"","图片类型", &hpls},
    };
};

/* 每种照片的结果返回响应时间（共23种） */
struct p_picture_response {
	std::string xsz;
	std::string sqb;
	std::string jqx;
	std::string jybg;
	std::string cyjl;
	std::string zqf;
	std::string yhf;
	std::string cjh;
	std::string aqd;
	std::string zdg;
	std::string ydg;
	std::string yzzd;
	std::string ezzd;
	std::string zczd;
	std::string dpdtks;
	std::string dpdtjs;
	std::string dpjy;
	std::string wqjy;
	std::string mhq;
	std::string yjc;
	std::string jly;
	std::string zql;
	std::string yql;
};

/* 每种视频下载时间 */
struct p_video_download {
	std::string video_1;	//FixMe,视频种类需要以后扩充
};

/* 每种视频预处理时间（从文件系统读取文件，转换为mat的时间） */
struct p_video_pre {
	std::string video_1;	//FixMe,视频种类需要以后扩充
};

/* 每种视频算法处理时间 */
struct p_video_process {
	std::string zqf;	
	std::string yhf;
	std::string pbzd;
	std::string yzzd;
	std::string ezzd;
	std::string zdg;
	std::string ydg;
	std::string dp;
    std::string dtks;
    std::string dtjs;
    std::string glzc;
	std::string pbzc;
};

/* 每种视频结果返回响应时间 */
struct p_video_response {
	std::string video_1;	//FixMe,视频种类需要以后扩充
};

struct p_picture_time {
	std::string AllDownload;
	p_picture_process process;
	p_picture_response response;
};

struct p_video_time {
	p_video_download download;
	p_video_pre pre;
	p_video_process process;
	p_video_response response;
};

class TimeRecord {
public:
	std::string total;
	std::string total_no_wait;
	std::string wait_queue;
    long long start_total_time;
    long long end_total_time;

	p_picture_time picture;
	p_video_time video;

public:
	TimeRecord();
	~TimeRecord();

	void startTime();			/* 开始计时 */
	void endTime();				/* 结束计时 */
	std::string getTime();		/* 获得时间(单位：ms) */

    long long getCurrentTime();
	void startTime_total();			/* 开始计时 */
	void endTime_total();			/* 结束计时 */
    long long getTime_total();	/* 获得时间(单位：ms) */


public:
	std::chrono::time_point<std::chrono::system_clock> start;
	std::chrono::time_point<std::chrono::system_clock> end;

	std::chrono::time_point<std::chrono::system_clock> start_total;
	std::chrono::time_point<std::chrono::system_clock> end_total;
};

#endif	//	_TIME_RECORD_
