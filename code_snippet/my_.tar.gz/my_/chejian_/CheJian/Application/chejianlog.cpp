#include "trace_log.h"
#include <stdio.h>
#include <time.h>
#include <stddef.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

//void DATA_PRINT(unsigned int lever, const char* fmt, ...)
//{
//    DateTime dt;
//    char gbuf[1024*16]={0};
//    sprintf(gbuf,"[%s]",dt.ToDateTimeString().c_str());
//    size_t size= strlen(gbuf);

//    va_list ap;
//    va_start(ap, fmt);
//    vsnprintf(gbuf + size,1024*16-size, fmt, ap);
//    va_end(ap);

//    if(lever <= g_debug_level)
//        printf("%s",gbuf);
//    if(lever == LEVEL_ERROR)
//        LOG(ERROR) << (gbuf+size);
//    else if(lever == LEVEL_INFO)
//        LOG(INFO) << (gbuf+size);
//    else if(lever == LEVEL_DEBUG)
//        LOG(WARNING) << (gbuf+size);
//}

//void TRACE_PRINT(const char *file,int line,const char *fun,unsigned int lever, const char* fmt, ...)
//{
//    if(lever<=g_debug_level){
//        char gbuf[1024*16]={0};;
//        va_list ap;
//        va_start(ap, fmt);
//        vsnprintf(gbuf,1024*16, fmt, ap);
//        va_end(ap);
//        printf("%s(%d)-<%s>:%s",file,line,fun,gbuf);
//    }
//}

char _key[10] = {5,8,6,1,8,6,3,4,2};

std::string setPassWord(std::string passWord)
{
    char pwd[1024] = {0};
    char outPwd[1024] = {0};

    sprintf(pwd,"%s",passWord.c_str());
    unsigned int pwdLen = strlen(pwd);

    for (unsigned int i = 0; i < pwdLen; i++) {
        char subKey = _key[i%10];

        if(128 - pwd[i] > subKey)
        {
            outPwd[i] = pwd[i] + subKey;
        }
        else
        {
            outPwd[i] = subKey;
        }
    }
    return outPwd;
}

std::string getDBPassWord(std::string passWord)
{
    char pwd[1024] = {0};
    char outPwd[1024] = {0};

    sprintf(pwd,"%s",passWord.c_str());
    unsigned int pwdLen = strlen(pwd);

    for (unsigned int i = 0; i < pwdLen; i++) {
        char subKey = _key[i%10];

        if(subKey + pwd[i] <= 128)
        {
            outPwd[i] = pwd[i] - subKey;
        }
        else
        {
            outPwd[i] = pwd[i];
        }
    }
    return outPwd;
}
