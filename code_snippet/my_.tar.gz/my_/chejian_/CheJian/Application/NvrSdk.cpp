//#include "Afx.h"
#ifndef NO_NVR
#include "NvrSdk.h"

//#include "ConfigFunc.h"

static	bool		bCfgLoaded = false;

DWORD g_ChansIndex[MAX_CHANNUM_V30+1] ;


CNvrSdk::CNvrSdk()
{
	m_nRecType = 0xff;
	m_nFileProperty = 0xff;
	m_iCurChanIndex = -1;

	memset(&m_StartSearchTime, 0, sizeof(NET_DVR_TIME));
	memset(&m_StopSearchTime, 0, sizeof(NET_DVR_TIME));
	m_callbackGf = NULL;
	m_callbackDw = NULL;
	m_IsDownloading = false;
	m_lDownloadHandle = -1;
	m_strSavedFile = "";
	m_bIsLogin = false;
	m_MaxDwlTime_S = 5;

	for (int i = 0; i <= MAX_CHANNUM_V30; i++)
	{
		g_ChansIndex[i] = -1;
	}
}


CNvrSdk::~CNvrSdk()
{
	StopDownload();
	NET_DVR_Logout_V30(m_struDeviceInfo.lLoginID);
	NET_DVR_Cleanup();
	bCfgLoaded = false;
}

CNvrSdk *CNvrSdk::getInstance()
{
	static	CNvrSdk	instance;
	if (!bCfgLoaded)
	{
		bCfgLoaded = NET_DVR_Init();
	}
	return &instance;
}

bool CNvrSdk::init()
{
    return true;
}

//void CNvrSdk::zlog(const char *date, const char *time, const char *file, const int line, const char *func, const char *str)
//{
//#ifdef Z_DEBUG
//	FILE *fp = NULL;
//#ifdef _WIN32
//	fopen_s(&fp, "log.log", "a+");
//#else
//	fopen("log.log", "a+");
//#endif
//    fprintf(fp, "%s | %s | %s | %d | %s | %s\n", date, time, file, line, func, str);
//	fclose(fp);
//#else
//	(void)str;
//#endif	// end Z_DEBUG
//}

bool CNvrSdk::DoLogin()
{
	//读取配置文件
	char szServer[20] = { 0 };
	char szPwd[20] = { 0 };
	char szPort[10] = { 0 };
	char szUser[20] = { 0 };
	//InitNvrServer(szServer, szPwd, szPort, szUser);
	if (strlen(szServer) <= 0)
		return false;
	int nPort = atoi(szPort);
	return DoLogin(szServer,szPwd, nPort,szUser);
}

bool CNvrSdk::DoLogin(char *szServer, char *szPwd, const int &nPort, char *szUser)
{
	NET_DVR_DEVICEINFO_V30 DeviceInfoTmp;
	memset(&DeviceInfoTmp, 0, sizeof(NET_DVR_DEVICEINFO_V30));
	LONG lLoginID = NET_DVR_Login_V30(szServer, nPort, szUser, szPwd, &DeviceInfoTmp);
	if (lLoginID == -1)
	{
		//MessageBox(NULL,"Login to Device failed!\n","Nvr",1);
		char strMsg[256] = { 0 };
		sprintf_s(strMsg, "st==NET_DVR_Login_V30 failed! Error code:%d", NET_DVR_GetLastError());
		//OutputDebugString(strMsg);
		m_bIsLogin = false;
		return false;
	}
	m_struDeviceInfo.lLoginID = lLoginID;
	m_struDeviceInfo.iDeviceChanNum = DeviceInfoTmp.byChanNum;
	m_struDeviceInfo.iIPChanNum = DeviceInfoTmp.byIPChanNum;
	m_struDeviceInfo.iStartChan = DeviceInfoTmp.byStartChan;
	m_bIsLogin = true;
	if (m_bIsLogin)
	{
		DoGetDeviceResoureCfg();
		CreateDeviceTree();
	}
	return true;
}

int CNvrSdk::FindVideo(const int &iCurChanIndex, const NET_DVR_TIME &StartSearchTime, const NET_DVR_TIME &StopSearchTime, const int &nRecType, const int &nFileProperty)
{
	if (!m_bIsLogin)
	{
		m_bIsLogin = DoLogin();
		if (!m_bIsLogin)
			return -3;
	}
	
	return FindVideo(iCurChanIndex, m_struDeviceInfo.lLoginID ,StartSearchTime,StopSearchTime,nRecType, nFileProperty);
}

int CNvrSdk::FindVideo(const int &iCurChanIndex, const LONG &LoginID, const NET_DVR_TIME &StartSearchTime, const NET_DVR_TIME &StopSearchTime, const int &nRecType, const int &nFileProperty)
{
	g_vecFileInfo.clear();

	int nIndex = GetSelectIndex(iCurChanIndex);

	int iCurChannel = m_struDeviceInfo.struChanInfo[nIndex].iChanIndex;

	NET_DVR_FILECOND   FileCond;
	FileCond.dwFileType = nRecType;
	FileCond.dwIsLocked = nFileProperty;
	FileCond.dwUseCardNo = 0;
	if (nIndex == -1)   //未选中通道
	{
		//MessageBox(NULL,"请选择一个通道","Nvr",1);
		return -2;
	}
	FileCond.lChannel = iCurChannel;
	memcpy(&FileCond.struStartTime, &StartSearchTime, sizeof(NET_DVR_TIME));
	memcpy(&FileCond.struStopTime, &StopSearchTime, sizeof(NET_DVR_TIME));

	//	LONG hFindHandle = NET_DVR_FindFile_V30(g_struDevInfo[g_iCurDevIndex].lLoginID,&FileCond);
	LONG hFindHandle = NET_DVR_FindFile_V30(LoginID, &FileCond);
	if (-1 == hFindHandle)
	{
		return -1;
	}
	else
	{
		NET_DVR_FINDDATA_V30 FindData;  //查找到的文件信息
		int ret = NET_DVR_FindNextFile_V30(hFindHandle, &FindData);
		while (ret > 0)
		{
			if (NET_DVR_FILE_EXCEPTION == ret)
			{
				return 0;//超时
			}
			else if (NET_DVR_FILE_NOFIND == ret)
			{
				return 2;//没有录像文件

			}
			else if (NET_DVR_NOMOREFILE == ret)   //查找结束
			{
				break;
			}
			else if (NET_DVR_ISFINDING == ret)  //正在查找
			{
				ret = NET_DVR_FindNextFile_V30(hFindHandle, &FindData);
				Sleep(5);
			}
			else if (NET_DVR_FILE_SUCCESS == ret)  //获取文件信息成功
			{
				//保存文件信息
				g_vecFileInfo.push_back(FindData);
				ret = NET_DVR_FindNextFile_V30(hFindHandle, &FindData);
			}
		}
		//关闭查找，释放句柄
		NET_DVR_FindClose_V30(hFindHandle);
	}
	return 1;
}

//void RemoteFileSearchThread(void* pParam)
DWORD WINAPI RemoteFileSearchThread(void* pParam)
{
	CNvrSdk *pNvr = (CNvrSdk*)pParam;
	int ns = pNvr->FindVideo(pNvr->GetChanIndex(),*(pNvr->GetStartSearchTime()), *(pNvr->GetStopSearchTime()), pNvr->GetRecType(), pNvr->GetFileProperty());
	if (pNvr->m_callbackGf)
		pNvr->m_callbackGf(ns, pNvr->GetVideo());
	return 0;
}

//void RemoteFileDownThread(void* pParam)
DWORD WINAPI RemoteFileDownThread(void* pParam)
{
	CNvrSdk *pNvr = (CNvrSdk*)pParam;
	UINT MaxDuration_ms = pNvr->m_MaxDwlTime_S * 100;
	int ns;
	while (MaxDuration_ms--)
	{
		DWORD pos;
		pos = NET_DVR_GetDownloadPos(pNvr->m_lDownloadHandle);
		if (pos == 100)
		{
			ns = 1;
			break;
		}
		else if (pos >= 200)
		{
			ns = 0;
			break;
		}
		Sleep(10);
	}
	NET_DVR_StopGetFile(pNvr->m_lDownloadHandle);
	pNvr->m_IsDownloading = false;
	pNvr->m_lDownloadHandle = -1;
	pNvr->m_callbackDw(ns, pNvr->GetSaveFile(), pNvr->GetParam());
	pNvr->m_IsDownloading = false;
	return 0;
}

int CNvrSdk::FindVideoRsync(const int &iCurChanIndex, const NET_DVR_TIME &StartSearchTime, const NET_DVR_TIME &StopSearchTime, const int &nRecType, const int &nFileProperty, OnGetFile callback)
{
	//设置类的成员变量
	m_iCurChanIndex = iCurChanIndex;
	m_nRecType = nRecType;
	m_nFileProperty = nFileProperty;
	m_callbackGf = callback;
	memcpy(&m_StartSearchTime, &StartSearchTime, sizeof(NET_DVR_TIME));
	memcpy(&m_StopSearchTime, &StopSearchTime, sizeof(NET_DVR_TIME));

	//启动查找文件线程
	//HANDLE ThreadHandle = (HANDLE)_beginthread(RemoteFileSearchThread, 0, (void*)this);//debug版本会崩溃
	HANDLE ThreadHandle = ::CreateThread(NULL, 0, RemoteFileSearchThread, (LPVOID)this, 0, NULL);
	CloseHandle(ThreadHandle);
	return 0;
}

int CNvrSdk::DownloadVideo(const char *pFileName, const char *pSaveDir, OnDownloadFile callbackDw, LPVOID pParam, const char *pSaveFileName)
{
	//正在下载
	if (m_IsDownloading)
		return 0;
	string SavedFileName = pSaveDir;
	if (SavedFileName.substr(SavedFileName.length() - 1, 1) != "\\")
	{
		SavedFileName += "\\";
	}
	if (pSaveFileName)
	{
		SavedFileName += pSaveFileName;
	}
	else
	{
		SavedFileName += pFileName;
	}
	if (!strstr(SavedFileName.c_str(), "."))
		SavedFileName += ".mp4";

	m_lDownloadHandle = NET_DVR_GetFileByName(m_struDeviceInfo.lLoginID, (char*)pFileName, (char*)SavedFileName.c_str());

	if (m_lDownloadHandle >= 0)
	{
		NET_DVR_PlayBackControl(m_lDownloadHandle, NET_DVR_PLAYSTART, 0, NULL);
		m_IsDownloading = true;
		//SetTimer(DOWNSTATE_TIMER, 100, NULL); 定时器下载
		//启动线程下载
		m_strSavedFile = SavedFileName;
		m_callbackDw = callbackDw;
		m_pParam = pParam;
		//HANDLE ThreadHandle = (HANDLE)_beginthread(RemoteFileDownThread, 0, (void*)this);//debug版本会崩溃
		HANDLE ThreadHandle = ::CreateThread(NULL, 0, RemoteFileDownThread, (LPVOID)this, 0, NULL);
		CloseHandle(ThreadHandle);
	}
	else
	{
		return -1;
	}
	return 1;
}

void CNvrSdk::StopDownload()
{
	if (m_IsDownloading)
	{
		NET_DVR_StopGetFile(m_lDownloadHandle);
		m_lDownloadHandle = -1;
		m_IsDownloading = false;
		m_callbackDw = NULL;
	}
}

void CNvrSdk::SetFileType(const int &nRecType, const int &nFileProperty)
{
	m_nRecType = nRecType;
	m_nFileProperty = nFileProperty;
}

void CNvrSdk::SetChanelIndex(const int &iCurChanIndex)
{
	m_iCurChanIndex = iCurChanIndex;
}

LPNET_DVR_TIME CNvrSdk::GetStartSearchTime()
{ 
	return &m_StartSearchTime; 
}
LPNET_DVR_TIME CNvrSdk::GetStopSearchTime()
{ 
	return &m_StopSearchTime; 
}
int CNvrSdk::GetRecType()
{ 
	return m_nRecType; 
}
int CNvrSdk::GetFileProperty()
{ 
	return m_nFileProperty;
}
int CNvrSdk::GetChanIndex()
{
	return m_iCurChanIndex;
}

vector <NET_DVR_FINDDATA_V30> *CNvrSdk::GetVideo()
{ 
	return &g_vecFileInfo; 
}

const char *CNvrSdk::GetSaveFile()
{
	return m_strSavedFile.c_str();
}

//获取通道信息
void CNvrSdk::DoGetDeviceResoureCfg()
{
	NET_DVR_IPPARACFG_V40 IpAccessCfg;
	memset(&IpAccessCfg, 0, sizeof(IpAccessCfg));
	DWORD  dwReturned;

	m_struDeviceInfo.bIPRet = NET_DVR_GetDVRConfig(m_struDeviceInfo.lLoginID, NET_DVR_GET_IPPARACFG_V40, 0, &IpAccessCfg, sizeof(NET_DVR_IPPARACFG_V40), &dwReturned);

	int i;
	if (!m_struDeviceInfo.bIPRet)   //不支持ip接入,9000以下设备不支持禁用模拟通道
	{
		for (i = 0; i < MAX_ANALOG_CHANNUM; i++)
		{
			if (i < m_struDeviceInfo.iDeviceChanNum)
			{
				sprintf_s(m_struDeviceInfo.struChanInfo[i].chChanName, "camera%d", i + m_struDeviceInfo.iStartChan);
				m_struDeviceInfo.struChanInfo[i].iChanIndex = i + m_struDeviceInfo.iStartChan;  //通道号
				m_struDeviceInfo.struChanInfo[i].bEnable = TRUE;

			}
			else
			{
				m_struDeviceInfo.struChanInfo[i].iChanIndex = -1;
				m_struDeviceInfo.struChanInfo[i].bEnable = FALSE;
				sprintf_s(m_struDeviceInfo.struChanInfo[i].chChanName, "");
			}
		}
	}
	else        //支持IP接入，9000设备
	{
		for (i = 0; i < MAX_ANALOG_CHANNUM; i++)  //模拟通道
		{
			if (i < m_struDeviceInfo.iDeviceChanNum)
			{
				sprintf_s(m_struDeviceInfo.struChanInfo[i].chChanName, "camera%d", i + m_struDeviceInfo.iStartChan);
				m_struDeviceInfo.struChanInfo[i].iChanIndex = i + m_struDeviceInfo.iStartChan;
				if (IpAccessCfg.byAnalogChanEnable[i])
				{
					m_struDeviceInfo.struChanInfo[i].bEnable = TRUE;
				}
				else
				{
					m_struDeviceInfo.struChanInfo[i].bEnable = FALSE;
				}

			}
			else//clear the state of other channel
			{
				m_struDeviceInfo.struChanInfo[i].iChanIndex = -1;
				m_struDeviceInfo.struChanInfo[i].bEnable = FALSE;
				sprintf_s(m_struDeviceInfo.struChanInfo[i].chChanName, "");
			}
		}

		//数字通道
		for (i = 0; i < MAX_IP_CHANNEL; i++)
		{
			if (IpAccessCfg.struStreamMode[i].uGetStream.struChanInfo.byEnable)  //ip通道在线
			{
				m_struDeviceInfo.struChanInfo[i + MAX_ANALOG_CHANNUM].bEnable = TRUE;
				m_struDeviceInfo.struChanInfo[i + MAX_ANALOG_CHANNUM].iChanIndex = IpAccessCfg.dwStartDChan + i;
				sprintf_s(m_struDeviceInfo.struChanInfo[i + MAX_ANALOG_CHANNUM].chChanName, "IP Camera %d", i + 1);

			}
			else
			{
				m_struDeviceInfo.struChanInfo[i + MAX_ANALOG_CHANNUM].bEnable = FALSE;
				m_struDeviceInfo.struChanInfo[i + MAX_ANALOG_CHANNUM].iChanIndex = -1;
			}
		}


	}
}

void CNvrSdk::CreateDeviceTree()
{
	g_ChansIndex[0] = DEVICETYPE * 1000;
	for (int i = 0; i < MAX_CHANNUM_V30; i++)
	{
		if (m_struDeviceInfo.struChanInfo[i].bEnable)  //通道有效，插入通道树
		{
			g_ChansIndex[i + 1] = CHANNELTYPE * 1000 + i;
		}
	}
}

int CNvrSdk::GetSelectIndex(const int &nIndex)
{
	int nCount = 0;
	DWORD itemData = -1;
	for (int i = 0; i < MAX_CHANNUM_V30; i++)
	{
		if (m_struDeviceInfo.struChanInfo[i].bEnable)  //通道有效，插入通道树
		{
			if (nCount == nIndex)
			{
				itemData = g_ChansIndex[i + 1];
				break;
			}
			++nCount;
		}
	}

	int itype = itemData / 1000;    //
	int iIndex = itemData % 1000;
	switch (itype)
	{
	case DEVICETYPE:
		return -1;
		break;
	case CHANNELTYPE:
		return iIndex;
		break;
	default:
		break;
	}
	return 0;
}

LPVOID CNvrSdk::GetParam()
{
	return m_pParam;
}

#endif
