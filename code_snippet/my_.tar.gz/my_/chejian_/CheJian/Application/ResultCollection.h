#pragma once

#include "vehicle_inf.h"
#include "large_vehicle_api.hpp"
#include "trace_log.h"

/* 车型 */
class VehicleType {
public:
    VehicleType(std::string name_CHS, std::string name_ENG) : name_CHS(name_CHS), name_ENG(name_ENG) {}

    std::string name_CHS;
    std::string name_ENG;
};

/* 车标 */
class VehicleLogo {
public:
    std::string name_CHS;
    std::string name_ENG;
    std::vector<VehicleType> TypeList;
};

/* 南京电子数据 */
class electronic_data {
public:
    std::string m_vin;
    std::string m_licenseno;
    bool        m_b_indate;
    std::string m_start_date;
    std::string m_end_date;
};

/*
 *	算法处理结果汇总
 */
class ResultCollection {

public:
	ResultCollection();
	~ResultCollection();
    std::string doAnalyse(vehicle_inf *p_vehicle_inf);
    void NoAnalyse_RenGong(vehicle_inf *p_vehicle_inf, std::string reason);		/* 强制将所有照片和视频标记为“建议人工”，需要传入原因 */
    std::string formatingDate(std::string date ,unsigned int index = 0);
    std::string formatingTime(std::string date);
    bool isTenYears(const vehicle_inf *p_vehicle_inf);
    bool isYingYun(const vehicle_inf *p_vehicle_inf);    //判断是否为营运车辆
    static void initLogoList();
    bool isLogo(std::string strLogo, std::string strClpp);
    void CompareLogo(std::string strPicPath, std::string strLogo);
public:
	/* 照片结果 */
	Xingshizheng_ImgOutMsg		XingShiZheng;		/* 0201：机动车行驶证 */
    Xingshizheng_ImgOutMsg		XingShiZhengBeiMian;/* 0299：机动车行驶证back */
	Shenqingdan_ImgOutMsg		ShenQingDan;		/* 0202：机动车牌证申请表 */
    Baodan_ImgOutMsg            BaoDan;             /* 0203：机动车交通事故责任强制保险凭证 */
    Baodan_ImgOutMsg            ZhongShanWanShui;   /* 0206：中山完税证明,实际调用保单数据 */
    electronic_data             nanjing_elec_data;
	Jianyanbaogao_ImgOutMsg		JianYanBaoGao;		/* 0204：机动车安全技术检验报告单 */
    Wanshuizhengming_ImgOutMsg  WanShuiZhengMing;   //0206-车船税纳税或者免税证明
    Baodan_ImgOutMsg            WanShuiBaoDan;      //0206-衡水\天津完税保单
    Weituotongzhishu_ImgOutMsg  WeiTuoHeGeTongZhiShu;//0207- 委托核发检验合格标志通知书
    Shenfenzheng_ImgOutMsg      ShenFenZheng;
    Shenfenzheng_ImgOutMsg      ShenFenZhengBeiMian;
    Quxianbaogao_ImgOutMsg      QuXianBaoGao;       /* 0213：机动车制动检测曲线报告（黔东南） */
    Jianyanbaogao_yiqi_ImgOutMsg JianYanBiao_YiQi;  /* 0297(宁波) 0213(重庆）: 机动车安全技术检验表(仪器检验)*/
    Jianyanbiao_ImgOutMsg       JianYanBiao_RenGong;  /* 0297(宁波) 0213(重庆）: 机动车安全技术检验表(仪器检验)*/
    Jianyanbiaoback_ImgOutMsg   JianYanBiaoBeiMian; /* 0298: 机动车安全技术检验表(back for宁波)*/
    weituoshu_ImgOutMsg         WeiTuoShu;          /* 0208: 委托书*/
    Weixianggaizhuang_ImgOutMsg WeiXiangNeiBu;
    Cheliang_ImgOutMsg          ZuoQianFang;		/* 0111：车辆左前方斜视45度照片 */
    Dipandongtai_ImgOutMsg      ZuoQianFangChuFa;   /* 0390：车辆左前方触发照片 */
    Dipandongtai_ImgOutMsg      YouHouFangChuFa;    /* 0391：车辆右后方触发照片 */
    Dipandongtai_ImgOutMsg      CheJiaHaoChuFa;     /* 0392：车辆右后方触发照片 */
    Huoche_ImgOutMsg            HuoChe_ZuoQianFang; /* 0111：大车左前方斜视45度照片 */
    Cheliang_ImgOutMsg          ZuoFang;            /* 0175：车辆左方照片 */
    Cheliang_ImgOutMsg          YouHouFang;         /* 0112：车辆右后方斜视45度照片 */
    Chemenpentu_ImgOutMsg       JiaoLianCheYouHouFang; /*教练车*/
    Huoche_ImgOutMsg            HuoChe_YouHouFang;  /* 0112：大车右后方斜视45度照片 */
    Cheliang_ImgOutMsg          CeMian;             /* 0114：车辆右侧面照片 */
    Cheliang_ImgOutMsg          QianHaoPai;         /* 0167：前号牌照片*/
    Cheliang_ImgOutMsg          HouHaoPai;         /* 0168：后号牌照片*/
    Cheliang_ImgOutMsg          BeiMian;            /* 0158：车辆背面照片 */
    Light_ImgOutMsg             LightBeiMian;       /* 车辆背面尾灯专用 */
    Huoche_ImgOutMsg            HuoChe_ZhengHouFang;/* 0158：大车正后方照片 */
    Chejiahao_ImgOutMsg         CheJiaHao;          /* 0113：车辆识别代号照片 */
    Chejiahao_ImgOutMsg         CheJiaHaoYuanJing;  /* 0150：车辆识别代号远景照片 */
    Anquandai_ImgOutMsg         AnQuanDai;          /* 0157：驾驶人座椅汽车安全带 */
    Light_ImgOutMsg             ZuoDengGuangGongWei;	/* 0321：左灯光工位照片 */
    Light_ImgOutMsg             YouDengGuangGongWei;    /* 0352：右灯光工位照片 */
    Zhidong_ImgOutMsg           ZhuCheZhiDong;		/* 0351：驻车制动工位照片 */
   // Zhidong_ImgOutMsg           PoDaoZhiDong;		/* 0345：坡道制动工位照片 */
    Dipan_ImgOutMsg             PoDaoZhiDong;		/* 0345：坡道制动工位照片 */
    Light_ImgOutMsg             Light_ZhuCheZhiDong;/* 0351：驻车制动工位照片灯光 */
    Jianyanbiao_ImgOutMsg		ChaYanJiLu;         /* 0205：机动车查验记录表 */
    Huanbaodan_ImgOutMsg		WuRanWu;            /* 0265(武汉)，0210(苏州)，0209(吉安),0212(保定)：污染物检测报告 */
    Huanbaodan_ImgOutMsg		WuRanWu2;            /* 0265(武汉)，0210(苏州)，0209(吉安),0212(保定)：污染物检测报告 */
	Dipandongtai_ImgOutMsg		DiPanDongTai;		/* 0344：底盘动态检验开始照片，0342：底盘动态检验结束照片 */
    Dipan_ImgOutMsg             DiPan;              /* 0323：底盘检验照片 */
    Zhidong_ImgOutMsg           YiZhouZhiDongGongWei;/* 0322：一轴制动工位照片*/
    Zhidong_ImgOutMsg           ErZhouZhiDongGongWei;/* 0348：二轴制动工位照片*/
    Light_ImgOutMsg             Light_YiZhouZhiDongGongWei;/* 0322：一轴制动工位照片左右灯状态 */
    Light_ImgOutMsg             Light_ErZhouZhiDongGongWei;/* 0348：二轴制动工位照片左右灯状态 */
    Miehuoqi_ImgOutMsg          MieHuoQi;			/* 0116：灭火器 */
	Yingjichui_ImgOutMsg		YingJiChui;			/* 0117：应急锤 */
    Xingchejiluyi_ImgOutMsg		JiLuYi;				/* 0118：行驶记录装置 */
    FuzhuzhidongSign_ImgOutMsg	FuZhuZhiDong;		/* 0130：辅助制动 */
    ABSSign_ImgOutMsg           ABS;				/* 0134：ABS */
    Luntaiguige_ImgOutMsg       ZuoQianLun;			/* 0136：左前轮胎规格型号 */
    Chemenpentu_ImgOutMsg       HeDingZaiKe;        /* 0135：核定载客人数(南昌) */
    Chemenpentu_ImgOutMsg       CheLiangCeMian;     /* 0114:核定载客人数(抚州车辆侧面核定载客功能)*/
    Luntaiguige_ImgOutMsg       YouQianLun;			/* 0154：右前轮胎规格型号 */
    Luntaihuawen_ImgOutMsg      DaCheYiLun;         /* 04 05：  大车一轮胎花纹 */
    Luntaihuawen_ImgOutMsg      DaCheErLun;         /* 06 07：  大车二轮胎花纹 */
    Luntaihuawen_ImgOutMsg      DaCheSanLun;		/* 08 09：  大车三轮胎花纹 */
    Huochexiang_ImgOutMsg       HuoCheXiang;        /* 0115：车厢内部照片（货车） */
    Kechexiang_ImgOutMsg        KeCheXiang;         /* 0115：车厢内部照片（客车） */
    Kechexiang_ImgOutMsg        HouPaiCheXiang;   /* 0166：车厢内部照片（客车） */
    Kechexiang_ImgOutMsg        HouPaiCheXiang2;  /* 0164：车厢内部照片（客车） */
  //  Huoche_ImgOutMsg            CeHuaGongWei;       /* 0353：侧滑工位照片 */
    Zhidong_ImgOutMsg           CeHuaGongWei; /* 0353：来宾侧滑工位 */
    Huoche_ImgOutMsg            WaiKuoQianMian;     /* 0360：外廓尺寸自动测量前面照片 */
    Huoche_ImgOutMsg            WaiKuoCeMian;       /* 0361：外廓尺寸自动测量侧面照片 */
    Huoche_ImgOutMsg            DaCheHaoPai;        /* 0170：大车号牌 */
    Baodan_ImgOutMsg            AnShunBaoDan;             /* 0210：安顺交强险保单2*/
    Jianyanhege_ImgOutMsg       JianYanHeGe;        /* 0212:机动车检验合格证明(南京独有) */
    Chejiahao_underglass_OutMsg CheJiaHaoUG;        /* 0120 - 连云港玻璃下车架号 */
    Mingpai_OutMsg              CheLiangMingPai;    /* 0114 -  */
    Bolitouguanglv_ImgOutMsg    BoLiTouGuangLv;     /* 0168 - 西安玻璃透光率 */
    Yingyezhizhao_ImgOutMsg     YingYeZhiZhao;
    Jiludan_ImgOutMsg           LuShiJiLuDan;       /* 0299: 路试记录单*/
    Dipandongtai_ImgOutMsg      LuShiKaiShi;
    Dipandongtai_ImgOutMsg      LuShiJieShu;
    Gaozhishu_ImgOutMsg         GaoZhiShu;          /* 0206 - 告知书 */
    Rongqueshouli_ImgOutMsg     RongQueShouLi;      /* 0206 - 容缺受理 */
    Luntaihuawen_ImgOutMsg      QianLunTaiHuaWen;   /*0150: 德州前轮胎花纹*/
    Luntaihuawen_ImgOutMsg      HouLunTaiHuaWen;    /*0151: 德州后轮胎花纹*/
    Luntaihuawen_ImgOutMsg      QianLunTaiZhaoPian; /* 前轮胎照片*/
    Luntaihuawen_ImgOutMsg      HouLunTaiZhaoPian;  /* 后轮胎照片*/
    Haopai_ImgOutMsg            QianHaoPaiTeXie;
    Haopai_ImgOutMsg            HouHaoPaiTeXie;

    Waikuochicun_ImgOutMsg      WaiKuoChiCunJiLuDan;/*0298:昭通机动车外廓尺寸仪器设备记录单*/
    Zhaotong_fanguangbiaoshi_ImgOutMsg FangGuangBiaoShi; /*0190:昭通反光标识检测数据*/

    Haopai_ImgOutMsg            HaoPaiLuoSi;


	Cheliang_VideoOutMsg		V_ZuoQianFang;		//exist[0]
	Cheliang_VideoOutMsg		V_YouHouFang;		//exist[1]
    Zhidong_VideoOutMsg			V_YiZhouZhiDong;	//exist[2]
    Zhidong_VideoOutMsg			V_ErZhouZhiDong;	//exist[3]
	Light_VideoOutMsg			V_ZuoDengGuang;		//exist[4]
	Light_VideoOutMsg			V_YouDengGuang;		//exist[5]
	Dipan_VideoOutMsg			V_DiPan;			//exist[6]
    Zhidong_VideoOutMsg         V_ZhuCheZhiDong;		//exist[7]
    Dipandongtai_VideoOutMsg    V_DiPanDongTaiKaiShi;
    Dipandongtai_VideoOutMsg    V_DiPanDongTaiJieShu;

    Light_VideoOutMsg			V_DengGuang;
    Dipandongtai_VideoOutMsg    V_DiPanDongTai;
	/* 参考照片 */
	bool						ZuoQianFang_A;		/* A：左前方档案照片 */
	bool						TaYinMo_J;			/* J：拓印膜档案照片 */
    //WeidengVideo_ImgOutMsg		WeiDeng;			/* B：制动工位 */
    int                         suzhou_compareType;

	BOOL						IsNewVehicle;
	BOOL						Found_CheBiao;
	int							DiPanGongWei_Video;	/* “底盘工位”视频是否通过，用来判定“底盘部件”照片*/
    bool                        hdzk;               /* “核定载客”是否是有效数字 */
    bool                        ZhuChe_ChePai = false;  /* 驻车制动与一二轴关联车牌判定 */

    //水印时间
    bool                        bZuoQianFangShuiYinRiQi = false;
    bool                        bYouHouFangShuiYinRiQi = false;
    bool                        bCheJiaHaoShuiYinRiQi = false;
    bool                        bAnQuanDaiShuiYinRiQi = false;
    bool                        bZuoDengGuangShuiYinRiQi = false;
    bool                        bYouDengGuangShuiYinRiQi = false;
    bool                        bYiZhouShuiYinRiQi = false;
    bool                        bErZhouShuiYinRiQi = false;
    bool                        bDiPanDongTaiKsShuiYinRiQi = false;
     bool                       bDiPanDongTaiJsShuiYinRiQi = false;
    bool                        bDiPanShuiYinRiQi = false;
    bool                        bZhuCheZhiDongShuiYinRiQi = false;
private:
	void doAnalyse_XingShiZheng(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_XingShiZhengBeiMian(vehicle_inf *p_vehicle_inf, int i);
	void doAnalyse_ShenQingDan(vehicle_inf *p_vehicle_inf, int i);
	void doAnalyse_BaoDan(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_ZhongShanWanShui(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_AnShunBaoDan(vehicle_inf *p_vehicle_inf, int i);
	void doAnalyse_JianYanBaoGao(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_NaMianShuiZhengMing(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_HeGeTongZhiShu(vehicle_inf *p_vehicle_inf, int i);
    // +{{ xeast 20180628
    void doAnalyse_JianYanbiao_RenGong(vehicle_inf *p_vehicle_inf, int i);
    // }}
    // +{{ xeast 20180623
    void doAnalyse_JianYanbiao_YiQi(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_JianYanbiaoBeiMian(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_WeiTuoShu(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_GaoZhiShu(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_RongQueShouLi(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_QuXianBaoGao(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_CheJiaHaoYuanJing(vehicle_inf *p_vehicle_inf, int i);
    // }}
	void doAnalyse_WaiGuan(vehicle_inf *p_vehicle_inf, unsigned int zuo, unsigned int you);				/* 外观处理包含左前和右后 */
    void doAnalyse_zqf_yhf_cjh_cf(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_ZuoYou(vehicle_inf *p_vehicle_inf, bool IsLeft, int i);	/* 单独处理左前或右后 */
	void doAnalyse_CheJiaHao(vehicle_inf *p_vehicle_inf, int i);
	void doAnalyse_AnQuanDai(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_CheJiaHaoUG(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_CheLiangMingPai(vehicle_inf *p_vehicle_inf,int i);
	void doAnalyse_DengGuangGongWie(vehicle_inf *p_vehicle_inf, int zuo, int you);
    void doAnalyse_DengGuangGongWie_YiChun(vehicle_inf *p_vehicle_inf, int zuo, int you);
    void doAnalyse_DaCheLunTaiHuaWen(vehicle_inf *p_vehicle_inf, int i, std::string type);
    void doAnalyse_xi_an_photo(vehicle_inf *p_vehicle_inf, int i, std::string type);
    void doAnalyse_ChaYanJiLu(vehicle_inf *p_vehicle_inf, int i , bool ningbo);
    void doAnalyse_glass_transmittance(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_WuRanWu(vehicle_inf *p_vehicle_inf, int i, int j);
	void doAnalyse_ZhiDongGongWei(vehicle_inf *p_vehicle_inf, int YiZhou, int ErZhou);
	void doAnalyse_DiPanDongTai(vehicle_inf *p_vehicle_inf, int start, int end);
	void doAnalyse_DiPan(vehicle_inf *p_vehicle_inf, int i);
	void doAnalyse_ZhuCheZhiDong(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_PoDaoZhiDong(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_QianHouLunTaiZhaoPian(vehicle_inf *p_vehicle_inf, int i, bool b_qianlun);
    void doAnalyse_MieHuoQi(vehicle_inf *p_vehicle_inf, int i);
	void doAnalyse_YingJiChui(vehicle_inf *p_vehicle_inf, int i);
	void doAnalyse_JiLuYi(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_RouXingBiaoQian(vehicle_inf *p_vehicle_inf, int i);
	void doAnalyse_ZuoQianLun(vehicle_inf *p_vehicle_inf, int i);
	void doAnalyse_YouQianLun(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_CheXiang(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_HouPaiCheXiang(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_HouPaiCheXiang2(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_CeHuaGongWei(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_WaiKuoQianMian(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_WaiKuoCeMian(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_DaCheHaoPai(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_WeiXiangNeiBu(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_ShenFenZheng(vehicle_inf *p_vehicle_inf,int i);
    void doAnalyse_ShenFenZhengBeiMian(vehicle_inf *p_vehicle_inf,int i);
    void doAnalyse_FuZhuZhiDong(vehicle_inf *p_vehicle_inf,int i);
    void doAnalyse_ABS(vehicle_inf *p_vehicle_inf,int i);
    void doAnalyse_CheLiangCeMian(vehicle_inf *p_vehicle_inf,int i);
    void doAnalyse_CheLiangCeMian2(vehicle_inf *p_vehicle_inf,int i);
    void doAnalyse_CheLiangBeiMian(vehicle_inf *p_vehicle_inf,int i);
    void doAnalyse_QianHaoPai(vehicle_inf *p_vehicle_inf,int i);
    void doAnalyse_HouHaoPai(vehicle_inf *p_vehicle_inf,int i);
    void doAnalyse_JianYanHeGeZhengMing(vehicle_inf *p_vehicle_inf,int i);
    void doAnalyse_YingYeZhiZhao(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_YingYeZhiZhao_YiChun(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_WuRanWu_SuZhou(vehicle_inf *p_vehicle_inf, int WeiQi_1, int WeiQi_2);
    void doAnalyse_WuRanWu_QingHai(vehicle_inf *p_vehicle_inf, int WeiQi_1, int WeiQi_2);
    void doAnalyse_WuRanWu_XianNing(vehicle_inf *p_vehicle_inf, int index1, int index2);
    void doAnalyse_WuRanWu_BinZhou(vehicle_inf *p_vehicle_inf, int index1, int index2);
    void doAnalyse_LuShiJiLuDan(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_LuShiKaiShi(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_LuShiJieShu(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_QianLunTaiHuaWen(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_HouLunTaiHuaWen(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_WaiKuoChiCunJiLuDan(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_FanGuangBiaoShi(vehicle_inf *p_vehicle_inf, int i);

	void doAnalyse_V_ZuoQianFang(vehicle_inf *p_vehicle_inf, int i);
	void doAnalyse_V_YouHouFang(vehicle_inf *p_vehicle_inf, int i);
	void doAnalyse_V_YiZhouZhiDong(vehicle_inf *p_vehicle_inf, int i);
	void doAnalyse_V_ErZhouZhiDong(vehicle_inf *p_vehicle_inf, int i);
	void doAnalyse_V_ZuoDengGuang(vehicle_inf *p_vehicle_inf, int i);
	void doAnalyse_V_YouDengGuang(vehicle_inf *p_vehicle_inf, int i);
	void doAnalyse_V_DiPan(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_V_ZhuCheZhiDong(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_HeDingZaiKe(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_QianHaoPaiTeXie(vehicle_inf *pvehicle_inf,int i);
    void doAnalyse_HouHaoPaiTeXie(vehicle_inf *p_vehicle_inf,int i);
    void doAnalyse_LiChengBiaoDuShu(vehicle_inf *p_vehicle_inf,int i);          /*zhongshan*/
    void doAnalyse_KeShiQuBoLi(vehicle_inf *p_vehicle_inf,int i);
	void doAnalyse_Others(vehicle_inf *p_vehicle_inf, bool IsPicture, int i);	/* 无法处理的图片或视频 */
    void doAnalyse_V_DengGuang(vehicle_inf *p_vehicle_inf, int i);
    void doAnalyse_V_DiPanDongTai(vehicle_inf *p_vehicle_inf, int i);

	std::string makeConclusion(const vehicle_inf *p_vehicle_inf);
    bool compareDate(std::string kssj, std::string PictureDate);
	int isMobileNumber(std::string number);
	bool BaoDanRiQi(const vehicle_inf *p_vehicle_inf);							

private:
	unsigned int dbbhgs;
    static std::vector<VehicleLogo> logo_list;
    static unsigned int logo_sum;
    static unsigned int logo_pass;

};
//照片类型编码
typedef struct ZhaoPianCode
{
  std::string ZuoQianFang;
  std::string ZuoFang;
  std::string YouHouFang;
  std::string CheJiaHao;
  std::string AnQuanDai;
  std::string XingShiZheng;
  std::string XingShiZhengBeiMian;
  std::string JiaoQiangXian;
  std::string JianYanBaoGao;
  std::string JianYanBaoGao_YiQi;
  std::string JianYanBaoGao_RenGong;
  std::string WeiTuoShu;
  std::string ShenQingBiao;
  std::string WeiQiJianYan;
  std::string WeiQiJianYan2;
  std::string ZuoDengGuang;
  std::string YouDengGuang;
  std::string YiZhouZhiDong;
  std::string ErZhouZhiDong;
  std::string ZhuCheZhiDong;
  std::string DiPanDongTaiKaiShi;
  std::string DiPanDongTaiJieShu;
  std::string DiPanBuJian;
  std::string ChaYanJiLu;
  std::string QianHaoPai;
  std::string HouHaoPai;
  std::string ShenFenZheng;
  std::string ShenFenZhengBeiMian;
  std::string JianYanBiaoBeiMian;
  std::string WanShuiZhengMing;
  std::string WeiTuoTongZhiShu;
  std::string MieHuoQi;
  std::string YingJiChui;
  std::string JiLuYi;
  std::string ZuoQianLun;
  std::string YouQianLun;
  std::string CheXiang;
  std::string HouPaiCheXiang;
  std::string HouPaiCheXiang2;
  std::string CeHuaGongWei;
  std::string WaiKuoQianMian;
  std::string WaiKuoCeMian;
  std::string DaCheHaoPai;
  std::string WeiXiangNeiBu;
  std::string FuZhuZhiDong;
  std::string ABS;
  std::string CheLiangCeMian;
  std::string CheLiangBeiMian;
  std::string HeDingZaiKe;
  std::string JianCeQuXianBaoGao;
  std::string CheJiaHaoUG;
  std::string CheLiangMingPai;
  std::string GaoZhiShu;
  std::string RongQueShouLi;
  std::string QianHaoPaiTeXie;
  std::string HouHaoPaiTeXie;
  std::string QianLunZhaoPian;
  std::string HouLunZhaoPian;
}_ZhaoPianZL;

