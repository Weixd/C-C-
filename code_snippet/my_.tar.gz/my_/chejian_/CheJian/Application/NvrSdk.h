#ifndef __NVRSDK_H__
#define __NVRSDK_H__

#include "GeneralDef.h"
#include <vector>

#ifdef _EXPORT_NVRSDK_API_
#define _EXPORT_NVRSDK_API_   __declspec(dllexport)
#else
#define _EXPORT_NVRSDK_API_   __declspec(dllimport)
#endif

using namespace std;

//#define ZLOG(str) CNvrSdk::getInstance()->zlog(__DATE__, __TIME__, __FILE__, __LINE__, __FUNCTION__, str);

typedef void(*OnGetFile)(int &ns,vector <NET_DVR_FINDDATA_V30> *);											//查找文件的回调函数
typedef void(*OnDownloadFile)(int &ns, const char*, LPVOID pParam);									//下载文件的回调函数

class _EXPORT_NVRSDK_API_ CNvrSdk
{
public:
	
	~CNvrSdk();

	static CNvrSdk *getInstance();
	bool DoLogin();
	void SetFileType(const int &nRecType = 0xff, const int &nFileProperty = 0xff);
	void SetChanelIndex(const int &iCurChanIndex);
	bool DoLogin(char *szServer, char *szPwd, const int &nPort = 8000, char *szUser = "admin");

	//同步查找
	int FindVideo(const int &iCurChanIndex, const NET_DVR_TIME &StartSearchTime, const NET_DVR_TIME &StopSearchTime, const int &nRecType = 0xff, const int &nFileProperty = 0xff);
	vector <NET_DVR_FINDDATA_V30> *GetVideo();
	//异步查找
	int FindVideoRsync(const int &iCurChanIndex, const NET_DVR_TIME &StartSearchTime, const NET_DVR_TIME &StopSearchTime, const int &nRecType, const int &nFileProperty, OnGetFile callback);

	int DownloadVideo(const char *pFileName, const char *pSaveDir, OnDownloadFile callbackDw, LPVOID pParam, const char *pSaveFileName = NULL);
	void StopDownload();

	//int nRecType;        //录像类型，0xff－全部；0－定时录像；1－移动侦测；2－报警触发；3-报警|移动侦测；4－报警&移动侦测；5－命令触发；6－手动录像
	//int nFileProperty;   //文件属性，0－正常文件；1－锁定文件；0xff表示所有文件
	int FindVideo(const int &iCurChanIndex, const LONG &LoginID, const NET_DVR_TIME &StartSearchTime, const NET_DVR_TIME &StopSearchTime, const int &nRecType = 0xff, const int &nFileProperty = 0xff);
	LPNET_DVR_TIME GetStartSearchTime();
	LPNET_DVR_TIME GetStopSearchTime();
	int GetRecType();
	int GetFileProperty();
	int GetChanIndex();
	const char *GetSaveFile();
	LPVOID GetParam();
protected:
	//void zlog(const char *date, const char *time, const char *file, const int line, const char *func, const char* str);
	void DoGetDeviceResoureCfg();
	void CreateDeviceTree();
	int GetSelectIndex(const int &nIndex);

private:
	CNvrSdk();

	bool init();
public:
	OnGetFile m_callbackGf;
	OnDownloadFile m_callbackDw;
	bool      m_IsDownloading;
	LONG m_lDownloadHandle;
	UINT   m_MaxDwlTime_S;
private:
	LOCAL_DEVICE_INFO m_struDeviceInfo;
	vector <NET_DVR_FINDDATA_V30> g_vecFileInfo;
	int m_nRecType;
	int m_nFileProperty;
	int m_iCurChanIndex;
	NET_DVR_TIME m_StartSearchTime;
	NET_DVR_TIME m_StopSearchTime;
	string m_strSavedFile;
	LPVOID m_pParam;
	bool m_bIsLogin;
};

#endif		// __NVRSDK_H__
