#ifndef VEHICLE_CHECK_SERVICE_H
#define VEHICLE_CHECK_SERVICE_H

#include "vehicle_inf.h"
#include "HttpServer.h"
#include "HttpClient.h"
#include <thread>
#include "MultiCast.h"
#include "./helper/HttpServerM.h"
#include "./helper/TelnetServer.h"
#include <string>

#define  MULTICAST_IP  "224.1.2.1"
#define  MULTICAST_PORT  8888
#define  MULTICAST_LOCAL_PORT 8888
#define PHOTO_PROCESS_RESULT 6

class SlaveInfo
{
public:
    std::string ip;
    std::string port;
};

class vehicle_check_service
{
public:
    std::thread *m_Request_hThread;
    std::thread *m_Analyse_hThread;
    std::thread *m_Download_hThread;
    std::thread *m_DB_BackUp_hThread;
    std::thread *m_DB_Video_Thread;
    std::thread *m_Reply_hThread;
    std::thread *m_Record_hThread;
    std::thread *m_Reply_master_hThread;
#ifdef APPLY_MULTICAST
    MultiCast m_mc;
    HttpServerM m_verServ;
#endif

#ifdef APPLY_TELNET_SERV
    TelnetServer m_ts;
#endif

public:
	HttpServer m_httpserver;
	HttpClient m_httpclient;

	vehicle_check_service();
	~vehicle_check_service();
	void start();
	void stop();
    void startAlgorithm();
    int startOtherModules();
    int data_request();
    void check_master();
    void check_slave();
};
#endif
