#ifndef _MAKE_LIC_
typedef unsigned char       BYTE;
typedef unsigned long       DWORD;

typedef struct
{
	DWORD dwYear;        //��
	DWORD dwMonth;       //��
	DWORD dwDay;         //��
	DWORD dwHour;        //ʱ
	DWORD dwMinute;      //��
	DWORD dwSecond;      //��
} LIC_TIME, *LPLIC_TIME;

typedef struct
{
	LIC_TIME tStart;
	LIC_TIME tEnd;
	LIC_TIME tCur;
	char szMachineID[64];
	char szMachineSN[20];
	char szVersion[20];
	char szLicID[20];
} LicDara, *LPLicDara;


void MakeLic(char *szFile, char *buffer, int len);
void MakeLic(char *szFile, LicDara &ld);
void ReadLic(char *szFile, LicDara &ld);

#endif
