#include "MySQL_DB.h"
#include "vehicle_inf.h"

extern std::string UTF8toANSI(char *strUTF8);
extern std::string g_videoFilePath;

MySQL_DB::MySQL_DB()
{
}

MySQL_DB::~MySQL_DB()
{
}

bool MySQL_DB::connect(const char *host, unsigned int port, const char *user, const char *passwd, const char *db)
{
	if (host == NULL) {
		DATA_PRINT(LEVEL_DEBUG, "Try to establish connection with localhost:%d@%s DataBase: %s \n", port, user, db);
	} else {
		DATA_PRINT(LEVEL_DEBUG, "Try to establish connection with %s:%d@%s DataBase: %s \n", host, port, user, db);
	}

	if (mysql_thread_init() != 0) {
		DATA_PRINT(LEVEL_ERROR, "mysql_thread_init() failed! \n");
		return false;
	}

	if (mysql_init(&mysql) == NULL) {
		DATA_PRINT(LEVEL_ERROR, "mysql_init() failed! \n");
		return false;
	}

    /*
        指定本次连接的编码方式（取决于编译器对字符串的编码存储方式）
        VS:gbk
        gcc:utf8
    */
    if (mysql_options(&mysql, MYSQL_SET_CHARSET_NAME, "utf8") != 0) {
		DATA_PRINT(LEVEL_ERROR, "mysql_options(MYSQL_SET_CHARSET_NAME) failed! \n");
		return false;
	}

	if (mysql_real_connect(&mysql, host, user, passwd, db, port, NULL, 0) == NULL) {
		DATA_PRINT(LEVEL_ERROR, "mysql_real_connect() failed! \n");
		DATA_PRINT(LEVEL_ERROR, "Reason: %s \n", mysql_error(&mysql));
		return false;
	}

	DATA_PRINT(LEVEL_DEBUG, "Database connection is successful. \n");
	return true;
}

void MySQL_DB::disconnect()
{
	mysql_close(&mysql);
	mysql_thread_end();
	
	DATA_PRINT(LEVEL_DEBUG, "Disconnected with the database. \n");
}

bool MySQL_DB::createTable(const char *name, const char *format)
{
	std::string sqlString = "CREATE TABLE IF NOT EXISTS";

	sqlString = sqlString + " " + name + " " + format;
	if (mysql_query(&mysql, sqlString.c_str()) != 0) {
        DATA_PRINT(LEVEL_ERROR, "createTable() failed! \n");
		DATA_PRINT(LEVEL_ERROR, "Reason: %s \n", mysql_error(&mysql));
        DATA_PRINT(LEVEL_ERROR, "Statements: %s \n", sqlString.c_str());
		return false;
	}

	return true;
}

bool MySQL_DB::dropTable(const char *name)
{
	std::string sqlString = "DROP TABLE";

	sqlString = sqlString + " " + name;
	if (mysql_query(&mysql, sqlString.c_str()) != 0) {
        DATA_PRINT(LEVEL_ERROR, "dropTable() failed! \n");
        DATA_PRINT(LEVEL_ERROR, "Reason: %s \n", mysql_error(&mysql));
        DATA_PRINT(LEVEL_ERROR, "Statements: %s \n", sqlString.c_str());
		return false;
	} 

	return true;
}

bool MySQL_DB::insert(const char *tableName, const char *valueFormat)
{
	std::string sqlString = "INSERT INTO";
	
	sqlString = sqlString + " " + tableName + " " + valueFormat;
	if (mysql_query(&mysql, sqlString.c_str()) != 0) {
        DATA_PRINT(LEVEL_ERROR, "insert() failed! \n");
        DATA_PRINT(LEVEL_ERROR, "Reason: %s \n", mysql_error(&mysql));
        DATA_PRINT(LEVEL_ERROR, "Statements: %s \n", sqlString.c_str());
		return false;
	}

	return true;
}

bool MySQL_DB::select(const char *tableName, const char *format)
{
	std::string sqlString = "SELECT";

	sqlString = sqlString + " " + format + " " + "FROM" + " " + tableName;
	if (mysql_query(&mysql, sqlString.c_str()) != 0) {
		DATA_PRINT(LEVEL_ERROR, "mysql_query() select failed! \n");
		return false;
	} else {
		MYSQL_RES *result = NULL;
		result = mysql_store_result(&mysql);

		/* 打印表头 */
		unsigned int fieldCount = mysql_num_fields(result);
		MYSQL_FIELD *field = NULL;
		for (unsigned int i = 0; i < fieldCount; i++) {
			field = mysql_fetch_field_direct(result, i);
			DATA_PRINT(LEVEL_DEBUG, "%s \t\t", field->name);
		}
		DATA_PRINT(LEVEL_DEBUG, "\n");

		/* 打印所有行 */
		MYSQL_ROW row = NULL;
		while ((row = mysql_fetch_row(result)) != NULL) {
			for (unsigned int i = 0; i < fieldCount; i++) {
				DATA_PRINT(LEVEL_DEBUG, "%s \t\t", (row[i] ? row[i] : NULL));
			}
			DATA_PRINT(LEVEL_DEBUG, "\n");
		}

		mysql_free_result(result);
	}

	return true;
}

unsigned long MySQL_DB::getLastID()
{
	if (mysql_query(&mysql, "SELECT LAST_INSERT_ID()") != 0) {
        DATA_PRINT(LEVEL_ERROR, "getLastID() failed! \n");
        DATA_PRINT(LEVEL_ERROR, "Reason: %s \n", mysql_error(&mysql));
		return 0;
	}

	MYSQL_RES *result = NULL;
	result = mysql_store_result(&mysql);
    if (result == NULL) {
        DATA_PRINT(LEVEL_ERROR, "getLastID() failed! \n");
        DATA_PRINT(LEVEL_ERROR, "Reason: mysql_store_result() failed! \n");
        return 0;
    }

	MYSQL_ROW row = NULL;
	row = mysql_fetch_row(result);
	if (row == NULL) {
        DATA_PRINT(LEVEL_ERROR, "getLastID() failed! \n");
        DATA_PRINT(LEVEL_ERROR, "Reason: mysql_fetch_row() failed! \n");
        mysql_free_result(result);
		return 0;
	}

	if (row[0] == NULL) {
        DATA_PRINT(LEVEL_ERROR, "getLastID() failed! \n");
        DATA_PRINT(LEVEL_ERROR, "Reason: no data! \n");
        mysql_free_result(result);
		return 0;
	}

	std::string tmp;
	tmp = row[0];
	unsigned long ret = std::stoul(tmp);
    mysql_free_result(result);
	return ret;
}

bool MySQL_DB::createDB(const char *name)
{
	std::string sqlString = "CREATE DATABASE IF NOT EXISTS ";
	sqlString += name;
	if (0 != mysql_query(&mysql, sqlString.c_str())) {
        DATA_PRINT(LEVEL_ERROR, "createDB() failed! \n");
        DATA_PRINT(LEVEL_ERROR, "Reason: %s \n", mysql_error(&mysql));
        DATA_PRINT(LEVEL_ERROR, "Statements: %s \n", sqlString.c_str());
		return false;
	}

	return true;
}

bool MySQL_DB::selectDB(const char *name)
{
	if (mysql_select_db(&mysql, name) != 0) {
        DATA_PRINT(LEVEL_ERROR, "selectDB() failed! \n");
        DATA_PRINT(LEVEL_ERROR, "Reason: %s \n", mysql_error(&mysql));
		return false;
	}

	return true;
}

MYSQL_RES *MySQL_DB::getResult(const char *SqlStatement)
{
	if (mysql_query(&mysql, SqlStatement) != 0) {
        DATA_PRINT(LEVEL_ERROR, "getResult() failed! \n");
        DATA_PRINT(LEVEL_ERROR, "Reason: %s \n", mysql_error(&mysql));
        DATA_PRINT(LEVEL_ERROR, "Statements: %s \n", SqlStatement);
		return NULL;
	} else {
		MYSQL_RES *result = NULL;
		result = mysql_store_result(&mysql);
		return result;
	}
}

void MySQL_DB::freeResult(MYSQL_RES *result) 
{
	mysql_free_result(result);
}

bool MySQL_DB::getVideoMsg(const char *tableName, const char *format, const char * term, vehicle_inf * vehicle_inf)
{
    std::string sqlString = "SELECT";
    sqlString = sqlString + " " + format + " " + "FROM" + " " + tableName + " " + "WHERE" + " " + term + " " + "and jylsh!=" + "'无数据'" + " order by id";// + " LIMIT 10"
    if (mysql_query(&mysql, sqlString.c_str()) != 0)
    {
        return false;
    } else
    {
        MYSQL_RES *result = NULL;
        result = mysql_store_result(&mysql);
        unsigned int fieldGCount = mysql_num_fields(result);
        //MYSQL_FIELD *field = NULL;
        MYSQL_ROW row = NULL;
        while ((row = mysql_fetch_row(result)) != NULL)
        {
            for (unsigned int j = 0; j < fieldGCount; j++)
            {
                _video_resource video_data;
                std::string data(row[j]);
                if (j == 0)
                {
                    video_data.sptype = data;
                } else if (j == 1)
                {
                    video_data.spurl = data;
                    std::string cc = data;
                    cc = UTF8toANSI((char *)cc.c_str());
                    cc = sqlencode(cc);
                    video_data.spurl = cc.c_str();
                    video_data.local_path = g_videoFilePath;

                    std::time_t t = std::time(NULL);
                    std::tm *st = std::localtime(&t);
                    char tmpArray[128] = { 0 };
                    sprintf(tmpArray, "%d-%02d-%02d", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);
                    std::string strCurTime = tmpArray;
                    video_data.local_path+=strCurTime;
#ifdef CHE_JIAN_LINUX
                    struct stat st_buf;
                    memset(&st_buf,0,sizeof(st_buf));
                    stat(video_data.local_path.c_str(), &st_buf);
                    if ((st_buf.st_mode & S_IFMT) != S_IFDIR) {
                        mkdir(video_data.local_path.c_str(), 0777);
                    }
#else
                    if (!PathIsDirectory(spdata.local_path.c_str()))
                    CreateDirectory(spdata.local_path.c_str(), NULL);
#endif
                    video_data.local_path += "/";

                    string urlc = video_data.spurl;
                    if ((urlc.find("0322")) != std::string::npos) {
                        video_data.spzl = "0322";
                    }
                    if ((urlc.find("0348")) != std::string::npos) {
                        video_data.spzl = "0348";
                    }
                    if ((urlc.find("0111")) != std::string::npos) {
                        video_data.spzl = "0111";
                    }
                    if ((urlc.find("0112")) != std::string::npos) {
                        video_data.spzl = "0112";
                    }
                    if ((urlc.find("0323")) != std::string::npos) {
                        video_data.spzl = "0323";
                    }
                    if ((urlc.find("0321")) != std::string::npos) {
                        video_data.spzl = "0321";
                    }
                    if ((urlc.find("0321")) != std::string::npos) {
                        video_data.spzl = "0352";
                    }
                    if ((urlc.find("0344")) != std::string::npos) {
                        video_data.spzl = "0344";
                    }
                    if ((urlc.find("0342")) != std::string::npos) {
                        video_data.spzl = "0342";
                    }
                    if ((urlc.find("0351")) != std::string::npos) {
                        video_data.spzl = "0351";
                    }
                    video_data.dzzl = "ftp";
                    video_data.local_path += video_data.spzl + "_" + vehicle_inf->m_hphm + "_" + vehicle_inf->m_jyjgbh + ".MP4";
                }
                vehicle_inf->m_splist.push_back(video_data);
            }
        }
        mysql_free_result(result);
    }
    return TRUE;
}

std::string MySQL_DB::sqlencode(std::string data)
{
    std::string::size_type pos(0);
    if ((pos = data.find("苏")) != std::string::npos) {
        data.replace(pos, 2, "%e8%8b%8f");
    }
    std::string::size_type pos1(0);
    while ((pos1 = data.find("\\")) != std::string::npos) {
        data.replace(pos1, 1, "/");
    }
    return data;
}

unsigned int MySQL_DB::getErrorNumber()
{
	return mysql_errno(&mysql);
}

bool MySQL_DB::update(const char *tableName, const char *valueFormat)
{
	std::string sqlString = "UPDATE";

	sqlString = sqlString + " " + tableName + " " + valueFormat;
	if (mysql_query(&mysql, sqlString.c_str()) != 0) {
        DATA_PRINT(LEVEL_ERROR, "update() failed! \n");
		DATA_PRINT(LEVEL_ERROR, "Reason: %s \n", mysql_error(&mysql));
        DATA_PRINT(LEVEL_ERROR, "Statements: %s \n", sqlString.c_str());
		return false;
	}

	return true;
}

bool MySQL_DB::alterTable(const char *tableName, const char *format)
{
	std::string sqlString = "ALTER TABLE";

	sqlString = sqlString + " " + tableName + " " + format;
	if (mysql_query(&mysql, sqlString.c_str()) != 0) {
        DATA_PRINT(LEVEL_ERROR, "alterTable() failed! \n");
        DATA_PRINT(LEVEL_ERROR, "Reason: %s \n", mysql_error(&mysql));
        DATA_PRINT(LEVEL_ERROR, "Statements: %s \n", sqlString.c_str());
		return false;
	}

	return true;
}
