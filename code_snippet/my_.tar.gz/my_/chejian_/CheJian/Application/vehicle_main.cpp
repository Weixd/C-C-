#include <net/if.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include <cstring>
#include <map>
#include <iostream>
#include <fstream>
#include <stdio.h>
#include "nvml.h"
#include <time.h>
#include <stdio.h>
#include "./helper/GlogHelper.h"
#include "des_encrypt.h"
//#include <shellapi.h >

//#include "vehicle_check.h"
#include "check_item.h"
#include "vehicle_check_service.h"
#include "trace_log.h"
#include "arithmetic_app_def.h"
#include "Markup.h"
#include "http_res_def.h"
#include "MySQL_DB.h"
#include "ResultCollection.h"
#include "MakeLic.h"
#include "MultiCast.h"
#include "./helper/TextTable.h"
#include "large_vehicle_api.hpp"
#include "LocalPicTest.h"
#include "Ftp_download.h"
#include "AlgProcess/base/basetool.h"
#include "soapStub.h"


#define JGBH_NUM 128
#define NVML_DEVICE_UUID_BUFFER_SIZE 80
#define ETH_NAME    "enp3s0"
#define NEED_MANUAL "4"

CheckItem g_CheckItem;
extern std::string g_requestUri;
extern std::string g_remoteServerIp;
extern std::vector<std::string> g_vec_remote_server_ip;
extern char *g_remoteServerIp_Char;
extern std::string g_remoteServerPort;
std::string g_SOAP_ServerPort = "9080";
std::string g_Video_ServerPort = "9010";
std::string g_ftp_UserPas = "cscgs:cscgs";
bool g_group_response = false;
unsigned int g_device_ID = 0;
std::string g_master_IP;	/* 从机记录主机的IP */
std::string g_jqxbd_result;	/* 电子交强险保单的审核返回值 */
std::string g_soap_token;	/* 电子交强险保单服务器登录的token */
std::string LocalMac;
std::string g_version="1.0.1";
unsigned int g_DownloadLimit = 3;
std::string g_QueryNumber = "10";
unsigned int g_QueryInterval = 30;
std::string g_strdzbdjkxlh;
bool g_Interface = false;
bool g_3rdInterface = false;
extern std::string g_localServerIp;
extern std::string g_localMac;
extern std::string g_localServerPort;
extern std::string g_photoUri;
extern std::string g_photoFilePath;
extern std::string g_videoFilePath;
extern std::string g_confJkxlh;
extern int g_b_ret ; // 南京电子数据交强险结果
int g_photoKeepMonths=6;
int g_videoKeepDays=7;
int g_diskPreserveSizeG=50;
//extern std::string g_clzl;
unsigned int g_debug_level = 0;
int g_SlaveCount = 0;
std::vector<SlaveInfo> SlaveList;
std::vector<std::string> SYXZ_List;  /*  车辆“使用性质”表 */
//std::string g_demo_path = "d:\\Demo_Photo\\";
std::string g_demo_path = "/home/CheJian_Photo/Demo_Photo/";
extern std::string g_nvr_dwl_duration;
//std::string g_keep_video_file = "0";
std::string g_keep_video_file = "1";
extern string formatFileNameLunTai(std::string name);
extern std::string b64Decode(const char* Data, int DataByte);

/* SOAP接口通信相关的两个参数 */
std::string g_cjbh = "";  /* 场景编号 */
std::string g_zdbs = "";  /* 终端标识 */

std::string g_dwjgdm = "";  /* 机构代码*/
int g_timelimit = 0;    /* 搜索时间限制天数*/
bool newSoapInterface = false;
std::string  ns1_queryObjectOut ="ns1:queryObjectOut";
std::string  ns1_queryObjectOutResponse="ns1:queryObjectOutResponse";
std::string  queryObjectOutResponse="queryObjectOutResponse";
std::string  queryObjectOut="queryObjectOut";
std::string  ns1_writeObjectOut="ns1:writeObjectOut";
std::string  ns1_writeObjectOutResponse="ns1:writeObjectOutResponse";
std::string  writeObjectOutResponse="writeObjectOutResponse";
std::string  writeObjectOut="writeObjectOut"; /* soap接口字符串 用于控制新旧接口*/


//int sanjiaojiafirstIsexist = 0;//0：左前方和右后方图片都没开始识别
//1: 其中一张图片没有三角架
//2：其中一张图片有三角架

int process_photo(vehicle_inf *pvehicle_inf, LargeVehicleApi *alg);
void vehicle_check_xsz(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_xsz_back(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_jqx(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_zs_jqx(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);  // 0206 - 中山完税证明，调用交强险函数
void vehicle_check_jqx2(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_jybg(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_jyb_back(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
// +{{ xeast 2018-06-23 for ning bo
void vehicle_check_jyb_yq(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result, char * code); // 检验表(仪器部分）
void vehicle_check_jyb_rg(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result, char * code); // 检验表(rengong部分）
void vehicle_check_wts(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
// }}
void vehicle_check_zqf(vehicle_inf * pvehicle_inf, UINT index, int DangAn_Index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_zqf_yhf_cjh_cf(vehicle_inf *, UINT, LargeVehicleApi *, ResultCollection &);
void vehicle_check_aqd(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_cjh(vehicle_inf * pvehicle_inf, UINT index, UINT TaYinMo_Index, int JiLuBiaoZiMo_Index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_cjh_ug(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
//void vehicle_check_dengguang(vehicle_inf * pvehicle_inf, UINT index, ResultCollection &result);
void vehicle_check_sqb(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_yhf(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_jcjlb(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result, char * code);
void vehicle_check_ccs_or_ms(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result); // 车船税或者免税image process
void vehicle_check_hgbztzs(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result); //委托核发检验合格标志通知书
//void vehicle_check_jdjbq(vehicle_inf *pvehicle_inf, UINT index, ResultCollection &result);  // 警灯警报器
//void vehicle_check_zcdjzs(vehicle_inf *pvehicle_inf, UINT index, ResultCollection &result);  // 注册登记证书(重庆）
//void vehicle_check_gcccchgz_and_dphgz(vehicle_inf *pvehicle_inf, UINT index, ResultCollection &result);  // 国产机动车整车出厂合格证和底盘合格证
//void vehicle_check_lsjyjld(vehicle_inf *pvehicle_inf, UINT index, ResultCollection &result);  // 路试检验记录单
bool fun_in_date(std::string start_date, std::string end_date);
bool nanjing_wrw(vehicle_inf * pvehicle_inf, std::string check_type);
bool nanjing_jqx(vehicle_inf * pvehicle_inf, ResultCollection &result);
void set_result_wrw(ResultCollection &, bool);
void vehicle_check_wrw(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_wrw2(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_wrw_tianjin(vehicle_inf * pvehicle_inf, int index1, int index2, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_zd(vehicle_inf * pvehicle_inf, int YiZhou_Index, int ErZhou_Index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_DiPanDongTai(vehicle_inf *pvehicle_inf, int KaiShi, int JieShu, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_DiPan(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_dggw(vehicle_inf * pvehicle_inf, int zuo, int you, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_ZhuCheZhiDong(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_PoDaoZhiDong(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_MieHuoQi(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_YingJiChui(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_JiLuYi(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_zql(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_yql(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_ltgg(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_dchw(vehicle_inf *pvehicle_inf, UINT u_zuo, UINT u_you, LargeVehicleApi *alg, ResultCollection &result, std::string where);
void vehicle_check_CheXiang(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_HouPaiCheXiang(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_HouPaiCheXiang2(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_CeHuaGongWei(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_WaiKuoQianMian(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_WaiKuoCeMian(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_wxnb(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_sfz_back(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_sfz(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_jcqxbg(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_hdzk(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_fzzd(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_xian(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_QianHouLunZhaoPian(vehicle_inf *, UINT, LargeVehicleApi *, ResultCollection &, bool);
void vehicle_check_abs(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_glass_transmittance(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_clcm(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
//vehicle_check_clcm2 车辆侧面核定载客判定
void vehicle_check_clcm2(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_cjhyj(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_clbm(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_qhp(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_hhp(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_dchp(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_clmp(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void NanJing_jyhgzm(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void process_LuShiJiLuDan(vehicle_inf *pvehicle_inf, int index, LargeVehicleApi *alg, ResultCollection &result);
void process_LuShiKaiShi(vehicle_inf *pvehicle_inf, int index, LargeVehicleApi *alg, ResultCollection &result);
void process_LuShiJieShu(vehicle_inf *pvehicle_inf, int index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_GaoZhiShu(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_RongQueShouLi(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_QianLunTaiHuaWen(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_HouLunTaiHuaWen(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_hpls(vehicle_inf *pvehicle_inf,UINT index,LargeVehicleApi *alg,ResultCollection &result,bool IsQianHaoPai);
void vehicle_check_WaiKuoChiCunJiLuDan(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_FanGuangBiaoShi(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_hpls(vehicle_inf *pvehicle_inf,UINT index,LargeVehicleApi *alg,ResultCollection &result);


void vehicle_videocheck_zqf(vehicle_inf * pvehicle_inf, int index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_videocheck_yhf(vehicle_inf * pvehicle_inf, int index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_videocheck_zd(vehicle_inf *pvehicle_inf, int YiZhou_Index, int ErZhou_Index, int flag, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_videocheck_zdggw(vehicle_inf * pvehicle_inf, int index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_videocheck_ydggw(vehicle_inf * pvehicle_inf, int index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_videocheck_dp(vehicle_inf *pvehicle_inf, int index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_videocheck_dpdtks(vehicle_inf *pvehicle_inf, int index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_videocheck_dpdtjs(vehicle_inf *pvehicle_inf, int index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_videocheck_zczd(vehicle_inf *pvehicle_inf, int index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_check_if_ten_year(vehicle_inf *pvehicle_inf, ResultCollection &result);
void vehicle_videocheck_dggw(vehicle_inf * pvehicle_inf, int index, LargeVehicleApi *alg, ResultCollection &result);
void vehicle_videocheck_dpdt(vehicle_inf *pvehicle_inf, int index, LargeVehicleApi *alg, ResultCollection &result);

std::string get_ip();
void get_mac(char * mac_a);
bool GetAdapterInfo(int adapter_num, string &mac_addr);
bool DatabaseManagement();
bool check_licence();
void check_version();
BOOL GetCheckItemXML( );
bool get_zhaotong_vin_image(vehicle_inf *pvehicle_inf, std::string &);

void processYingYeZhiZhao(vehicle_inf *pvehicle_inf, int index, LargeVehicleApi *alg, ResultCollection &result);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//void * model_test = NULL;
//void * table_test = NULL;
void get_current_data(std::string& str_cur_date);

vector<std::string> confirm_lsh;
struct DEMO_data
{
    bool zqf;
    cv::Rect zqf_Cheliang_chepai;
    cv::Rect zqf_Cheliang_chebiao;
    cv::Rect zqf_Cheliang_sanjiaojia;
    cv::Rect zqf_Cheliang_refit;
    bool zqf_Cheliang_b_ori_waiguan;
    bool zqf_Cheliang_b_chepai;
    bool zqf_Cheliang_b_chebiao;
    bool zqf_Cheliang_b_sanjiaojia;

    bool yhf;
    cv::Rect yhf_Cheliang_chepai;//车牌位置
    cv::Rect yhf_Cheliang_chebiao;//车标位置
    cv::Rect yhf_Cheliang_sanjiaojia;//三角架的位置
    cv::Rect yhf_Cheliang_refit;
    bool yhf_Cheliang_b_ori_waiguan;
    bool yhf_Cheliang_b_chepai;
    bool yhf_Cheliang_b_chebiao;
    bool yhf_Cheliang_b_sanjiaojia;

    bool aqd;
    cv::Rect Anquandai_r;//安全带坐标
    bool Anquandai_b_anquandai;
    bool cjh;
    cv::Rect Chejiahao_r;//车架号位置
    bool Chejiahao_b_pic_quality;
    bool Chejiahao_b_chejiahao;

    bool bd;
    cv::Rect Baodan_hongzhan;//红章位置
    cv::Rect Baodan_roi;//检测车牌 车架号辅助区域
    cv::Rect Baodan_chechuanshui;//车船税区域
    cv::Rect Baodan_chepai;//车牌位置
    cv::Rect Baodan_chejiahao;//车架号位置
    cv::Rect Baodan_start_riqi;//开始日期字符串位置
    cv::Rect Baodan_end_riqi;//结束日期字符串位置
    cv::Rect Baodan_fuben;//副本字符框
    bool Baodan_b_pic_quality;
    bool Baodan_b_baodan;
    bool Baodan_b_riqi;
    bool Baodan_b_fuben;
    bool Baodan_b_chechuanshui;

    bool xsz;
    cv::Rect  Xingshizheng_xingshizheng; //行驶证主页 坐标系：m
    cv::Rect  Xingshizheng_xingshizheng_fuye;//行驶证副页 坐标系：m
    cv::Rect  Xingshizheng_chepai;// 车牌矩形框坐标 坐标系：m_xingshizheng
    cv::Rect  Xingshizheng_chejiahao;
    cv::Rect  Xingshizheng_fazhengriqi;
    cv::Rect  Xingshizheng_chepai_fuye;//7.24
    cv::Rect  Xingshizheng_danganhao_fuye;//
    cv::Rect  Xingshizheng_tiaoxingma_fuye;//
    bool Xingshizheng_b_pic_quality;
    bool Xingshizheng_b_xingshizheng;
    bool Xingshizheng_b_fazhengriqi; //7.24
    bool Xingshizheng_b_danganhao;             //is 'danganhao' correct
    bool Xingshizheng_b_tiaoxingma;            //is 'tiaoxingma' correct

    bool jybg;
    cv::Rect Jianyanbaogao_auxiliary;//对应Mat m_rotate ，车牌 车架号所在大区域扩充后的图像矩形框
    cv::Rect Jianyanbaogao_compare;//对应Mat m_rotate，比对内容所在大区域
    cv::Rect Jianyanbaogao_qianming;//签名区域
    cv::Rect Jianyanbaogao_hongzhang;//对应Mat m_rotate 的红章矩形框坐标
    cv::Rect Jianyanbaogao_jianyanjielun;//检验结论区域
    cv::Rect Jianyanbaogao_chejiahao;//车架号矩形框坐标，相对于图像：Mat m_auxiliary
    cv::Rect Jianyanbaogao_chepai;//车牌矩形框坐标，相对于图像：Mat m_auxiliary
    bool Jianyanbaogao_b_pic_quality;
    bool Jianyanbaogao_b_jianyanbaogao;
    bool Jianyanbaogao_b_qianming;
    bool Jianyanbaogao_b_hongzhang;
    bool Jianyanbaogao_b_jianyanjielun;
    bool Jianyanbaogao_b_jianyan_info;


    bool sqb;     //9.4
    cv::Rect Shenqingdan_chepai;
    cv::Rect Shenqingdan_qianming;
    cv::Rect Shenqingdan_telephone;
    std::string Shenqingdan_s_telephone;//电话号
    bool Shenqingdan_b_pic_quality;   //图片质量
    bool Shenqingdan_b_chepai;        //手写车牌号码比对是否正确
    bool Shenqingdan_b_qianming;   //申请表是否合格


    bool hbd;
    cv::Rect Huanbaodan_table;        //location of table roi
    cv::Rect Huanbaodan_chepai;       //location of 'chepai'
    cv::Rect Huanbaodan_chejiahao;    //location of 'chejiahao'
    cv::Rect Huanbaodan_yinzhang;     //location of 'yinzhang'
    cv::Rect Huanbaodan_qianzi;       //location of 'qianzi'
    cv::Rect Huanbaodan_jiancejielun; //location of 'jianyanjielun'
    bool Huanbaodan_b_jiancejielun;     //if 'jiancejielun' pass
    bool Huanbaodan_b_chepai;           //is 'chepai' correct
    bool Huanbaodan_b_chejiahao;        //is 'chejiahao' correct
    bool Huanbaodan_b_yinzhang;         //if 'yinzhang' exist
    bool Huanbaodan_b_qianzi;

    bool jyb;
    cv::Rect Jianyanbiao_table;
    cv::Rect Jianyanbiao_rect1;    //签名123
    cv::Rect Jianyanbiao_rect2;
    cv::Rect Jianyanbiao_rect3;
    bool Jianyanbiao_b_jianyanbiao;    //检验表是否合格
    bool Jianyanbiao_b_waiguan_sign;    //外观签名是否存在
    bool Jianyanbiao_b_yinche_sign;    //引车签名是否存在
    bool Jianyanbiao_b_dipan_sign;    //底盘签名是否存在

    bool zd;
    cv::Rect Zhidong_chepai;    //车牌位置
    cv::Rect Zhidong_chepai_2;    //车牌位置
    bool Zhidong_b_zhidong;     //一轴二轴/平板制动是否合格
    bool Zhidong_b_chepai;      //车牌比对是否正确


    bool dggw;
    cv::Rect Dengguang_chepai;  //location of 'chepai' in image no.1
    cv::Rect Dengguang_leftRt;    //左灯位置
    cv::Rect Dengguang_rightRt;    //右灯位置
    cv::Rect Dengguang_chepai_2;  //location of 'chepai' in image no.1
    cv::Rect Dengguang_leftRt_2;    //左灯位置
    cv::Rect Dengguang_rightRt_2;    //右灯位置
    bool Dengguang_b_light_on;    //制动尾灯是否亮起
    bool Dengguang_b_chepai;

    bool dpdt;
    cv::Rect Dipandongtai_chepai_1;        //车牌位置1
    cv::Rect Dipandongtai_chepai_2;        //车牌位置2
    bool Dipandongtai_b_move;        //车辆是否发生位移
    bool Dipandongtai_b_chepai;        //车牌号码
    string Dipandongtai_date_stamp;        //水印日期

    bool dp;
    cv::Rect Dipan_chepai;            //车牌位置
    bool Dipan_b_dipan;            //车辆底盘是否在工位上
    bool Dipan_b_chepai;            //车牌比对是否正确
    string Dipan_date_stamp;           //水印日期
};
std::string demo_sqlString, demo_sqlString0;
DEMO_data demo_data;
void cvRect2CString(cv::Rect cube, std::string &zifu)
{
    zifu = std::to_string(cube.x);
    zifu += ".";
    zifu += std::to_string(cube.y);
    zifu += ".";
    zifu += std::to_string(cube.width);
    zifu += ".";
    zifu += std::to_string(cube.height);
}
std::string GetVersion(std::string ver)
{
    std::string monthes[] =
    {
        "Jan",
        "Feb",
        "Mar",
        "Apr",
        "May",
        "Jun",
        "Jul",
        "Aug",
        "Sep",
        "Oct",
        "Nov",
        "Dec",
    };

    std::string dateStr = __DATE__;

    int year = atoi(dateStr.substr(dateStr.length() - 4).c_str());

    int month = 0;
    for(int i = 0; i < 12; i++)
    {
        if(dateStr.find(monthes[i]) != std::string::npos)
        {
            month = i + 1;
            break;
        }
    }

    std::string dayStr = dateStr.substr(4, 2);
    int day = atoi(dayStr.c_str());

    std::string timeStr = __TIME__;

    std::string hourStr = timeStr.substr(0, 2);
    int hour = atoi(hourStr.c_str());
    std::string minuStr = timeStr.substr(3, 2);
    int minu = atoi(minuStr.c_str());
    std::string secStr = timeStr.substr(6, 2);
    int sec = atoi(secStr.c_str());

    char version[64]={0};
    sprintf(version, "%s_%04d-%02d-%02d %02d:%02d:%02d",ver.c_str(), year, month, day, hour,minu,sec);

    return version;
}

vehicle_check_service g_service;
CLocalPicTest g_localPicTest;
/* 测试模式启动时，所有根据车管所要求增加的第三方接口全部关闭 */
bool g_TestMode = false;



#define SOFT_VERSION "3.203.1"


#define ALGPROCESS_TEST 0

#include "AlgProcess/Test/ChejianTest.h"
#include "AlgProcess/webserver/webserver.h"
//void BaoDing_FTP_Download(vehicle_inf *p_vehicle_inf);
//void http_requset_get_bdpic_cbwyd();
BlockingQueue<vehicle_inf *> binzhou_download_queue;

int main(int argc, char *argv[])
{
    setVersion(SOFT_VERSION);

#if ALGPROCESS_TEST
    return PicProcessBaseClassTest();
#endif

    if ((argc > 1) && (std::string(argv[1]) == "-mv"))
    {
        std::string rootPath = "..";
        if(argc > 2)
             rootPath = argv[2];
        makeUpdateReleaseTar(rootPath,SOFT_VERSION);
        return EXIT_SUCCESS;
    }

    if ((argc == 2) && (std::string(argv[1]) == "-v"))
    {
        std::string alg_version;
        LargeVehicleApi::algorithm_version(alg_version);

        printf("Version: %s\n", GetVersion(SOFT_VERSION).c_str());
        printf("alg_Version: %s\n", alg_version.c_str());
        return EXIT_SUCCESS;
    }

    if ((argc == 2) && (std::string(argv[1]) == "-t")) {
//        vehicle_inf v_vehicle_inf;
//        v_vehicle_inf.m_clsbdh="LJVN83G84GT000033";
//        BaoDing_FTP_Download(&v_vehicle_inf);
        g_TestMode = true;
        DATA_PRINT(LEVEL_INFO, "Run in test mode! \n");
    }

    mysql_library_init(0, NULL, NULL);
    ResultCollection::initLogoList();
  //  ResultCollection result;
   // bool bLogo = result.isLogo("众泰","ZotYE");
    //DATA_PRINT(LEVEL_INFO, "logo:%d\n", bLogo);

    if ((argc == 2) && (std::string(argv[1]) == "-d"))
    {
        MultiCast mc;
        TextTable t('-', '|', '-');
        std::string udpIp;
        char HostName[100];
        hostent* hname;
        gethostname(HostName, sizeof(HostName));// 获得本机主机名.
        hname = gethostbyname(HostName);//根据本机主机名得到本机ip
        udpIp = inet_ntoa(*(struct in_addr *)hname->h_addr_list[0]);//把ip换成字符串形式

        bool ret=mc.Start(NULL, (char*)udpIp.c_str(), MULTICAST_LOCAL_PORT, (char *)MULTICAST_IP, MULTICAST_PORT, MultiCast::OnRecv,false,true);
        if(!ret)
            std::cout << "start multicast faliled! local ip:" << udpIp << ",multicast ip:" << MULTICAST_IP << std::endl;

        while(ret)
        {
            {
                std::lock_guard<std::mutex> lg(mc.cjClntsMutex_);
                std::cout << "\033[0;0H\033[2J";
                t._rows.clear();
                t.add("设备号");
                t.add("   版本号   ");
                t.add("     IP地址     ");
                t.add("下载N");
                t.add("分析N");
                t.add("视频N");
                t.add("写回N");
                t.endOfRow();
                for (auto& c : mc.cjClnts_)
                {
                    t.add(std::to_string(c.second.devId));
                    t.add(c.second.ver);
                    t.add(c.second.ip);
                    t.add(std::to_string(c.second.downloadQueueSize));
                    t.add(std::to_string(c.second.analyseQueueSize));
                    t.add(std::to_string(c.second.videoQueueSize));
                    t.add(std::to_string(c.second.replyQueueSize));
                    t.endOfRow();
                }
                std::cout << t;
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(1000));
        }
        return EXIT_SUCCESS;
    }
    if((argc == 3) && (std::string(argv[1]) == "-x"))
    {
        getVehicleCheck();
        getCheckItem();
        g_localPicTest.TestLocalFile(std::string(argv[2]));
        return EXIT_SUCCESS;
    }
    if((argc == 5) && (std::string(argv[1]) == "-x"))
    {
        getVehicleCheck();
        getCheckItemData(std::string(argv[4]));
        g_localPicTest.TestLocalFile(std::string(argv[2]));
        return EXIT_SUCCESS;
    }
    GLogHelper glog;
    glog.SetStdLevel(GLogHelper::FATAL);
    glog.SetMaxLogSizeMb(20);
    glog.SetPreservLogFileNum(50);

    // mac address

    char *this_mac=new char[6];
    get_mac(this_mac);
    char macBuf[64]={0};
    sprintf(macBuf,"%02x:%02x:%02x:%02x:%02x:%02x", this_mac[0]&0xff, this_mac[1]&0xff, this_mac[2]&0xff, this_mac[3]&0xff, this_mac[4]&0xff, this_mac[5]&0xff);
    LocalMac=macBuf;
    DATA_PRINT(LEVEL_INFO,"mac is : %s,\n",LocalMac.c_str());
    delete this_mac;

    /* licence compare uuid */
#ifndef CLOSE_LICENCE
    if(!check_licence())
    {
        return -1;
    }
#endif

    getVehicleCheck();
    getCheckItem();

    /*增加主从机CheckItem文件检测*/
    if(g_SlaveCount == -1 && g_CheckItem.ZhuCongYiZhi == 1)
    {
        if(!GetCheckItemXML())
        {
            return -1;
        }
    }
    if (!g_TestMode) {
        if (g_CheckItem.City == SUZHOU) {
            /* 由于苏州不是所有机器都开启这个接口，因此在判断城市编号后，还要判定开关文件是否存在 */
            if (access("Interface", F_OK) == 0) {
                g_Interface = true;
            } else {
                g_Interface = false;
            }
            /* 由于苏州不是所有机器都开启这个接口，因此在判断城市编号后，还要判定开关文件是否存在，暂时只有217机器开启该接口 */
            if (access("3rdInterface.xml", F_OK) == 0) {
                g_3rdInterface = true;
            } else {
                g_3rdInterface = false;
            }
        }
    }


    DATA_PRINT(LEVEL_INFO, "g_Interface:%d \ng_3rdInterface:%d \n", g_Interface, g_3rdInterface);
    if (!DatabaseManagement()) {
        return EXIT_FAILURE;
    }


    check_version();

    g_service.start();

    DATA_PRINT(LEVEL_INFO, "Vehicle_Check Server crash!!! \n");
    return 0;
}

BOOL GetCheckItemXML( )
{
    HttpClient RequestGetXML;

    char requestUri[100];
    BOOL isSame = TRUE;
    memset(requestUri,'\0',sizeof(requestUri));
    sprintf(requestUri,"http://%s:9000/checkitem/",g_master_IP.c_str());

    if (RequestGetXML.InitData(requestUri,REQUEST_GET_FLAG,NULL,NULL))
    {
        RequestGetXML.startHttpClient();
    }

    FILE *fp = NULL;
    char cmd[1024];
    memset(cmd,'\0',sizeof(cmd));
    sprintf(cmd,"diff -wtB check_item.xml checkitemhost.xml");

    if((fp = popen(cmd, "r")) != NULL)
    {
        if(fgets(cmd,sizeof(cmd),fp) != NULL)
        {
            DATA_PRINT(LEVEL_INFO,"check_item 与主机配置不相符\n");
            cout<<cmd<<endl;
            while(fgets(cmd,sizeof(cmd),fp) != NULL)
            {
                cout<<cmd<<endl;
            }
            isSame = FALSE;
        }
    }
    memset(cmd,'\0',sizeof(cmd));
    sprintf(cmd,"rm -r checkitemhost.xml");
    fp = popen(cmd,"w");

    return isSame;

}
std::string get_ip()
{
    int                 sockfd;
    struct sockaddr_in  sin;
    struct ifreq        ifr;

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd == -1) {
        perror("socket error");
        exit(1);
    }
    strncpy(ifr.ifr_name, ETH_NAME, IFNAMSIZ);      //Interface name

    if (ioctl(sockfd, SIOCGIFADDR, &ifr) == 0) {    //SIOCGIFADDR 获取interface address
        memcpy(&sin, &ifr.ifr_addr, sizeof(ifr.ifr_addr));
        return inet_ntoa(sin.sin_addr);
    }
    return "0.0.0.0";
}

void get_mac(char * mac_a)
{
    int                 sockfd;
    struct ifreq        ifr;

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd == -1) {
        perror("socket error");
        exit(1);
    }
    strncpy(ifr.ifr_name, ETH_NAME, IFNAMSIZ);      //Interface name

    if (ioctl(sockfd, SIOCGIFHWADDR, &ifr) == 0) {  //SIOCGIFHWADDR 获取hardware address
        memcpy(mac_a, ifr.ifr_hwaddr.sa_data, 6);
    }
}

std::string LeftString(std::string str, unsigned int count)
{
    if (count >= str.length()) {
        return str;
    } else {
        return str.substr(0, count);
    }
}

std::string RightString(std::string str, unsigned int count)
{
    if (count >= str.length()) {
        return str;
    } else {
        return str.substr(str.length() - count, count);
    }
}

void getVehicleCheck()
{
    std::string conf_name = "vehicle_check.xml";
    if(baseTool::fileIsExist("/opt/vehicle/program/CheJianConfig/vehicle_check.xml"))
    {
        conf_name = "/opt/vehicle/program/CheJianConfig/vehicle_check.xml";
    }

    CMarkup xml;
    xml.Load(conf_name);
    xml.ResetMainPos();

    if (xml.FindElem("config"))
    {
        if (xml.FindChildElem("trace_level"))
        {
            g_debug_level = atoi(xml.GetChildData().c_str());
            DATA_PRINT(LEVEL_INFO, "%s=%d\n", xml.GetChildTagName().c_str(), g_debug_level);
        }
        if (xml.FindChildElem("device_ID"))
        {
            g_device_ID = atoi(xml.GetChildData().c_str());
            DATA_PRINT(LEVEL_INFO, "%s=%d\n", xml.GetChildTagName().c_str(), g_device_ID);
        }
        if (xml.FindChildElem("requestUri"))
        {
            g_requestUri = xml.GetChildData();
            DATA_PRINT(LEVEL_INFO, "%s=%s\n", xml.GetChildTagName().c_str(), g_requestUri.c_str());
        }
        if (xml.FindChildElem("cjbh"))
        {
            g_cjbh = xml.GetChildData();
            DATA_PRINT(LEVEL_INFO, "%s=%s\n", xml.GetChildTagName().c_str(), g_cjbh.c_str());
        }
        if (xml.FindChildElem("zdbs"))
        {
            g_zdbs = xml.GetChildData();
            DATA_PRINT(LEVEL_INFO, "%s=%s\n", xml.GetChildTagName().c_str(), g_zdbs.c_str());
        }
        if (xml.FindChildElem("dwjgdm"))
        {
            g_dwjgdm = xml.GetChildData();
            DATA_PRINT(LEVEL_INFO, "%s=%s\n", xml.GetChildTagName().c_str(), g_dwjgdm.c_str());
        }
        if (xml.FindChildElem("newSoapInterface"))
        {
            std::string buf = xml.GetChildData();
            DATA_PRINT(LEVEL_INFO, "%s=%s\n", xml.GetChildTagName().c_str(), buf.c_str());
            if(buf.find("1")!=std::string::npos)
            {
                newSoapInterface = true;
                ns1_queryObjectOut = "ns1:queryObjectOutNew";
                ns1_queryObjectOutResponse = "ns1:queryObjectOutNewResponse";
                queryObjectOutResponse = "queryObjectOutNewResponse";
                queryObjectOut = "queryObjectOutNew";
                ns1_writeObjectOut = "ns1:writeObjectOutNew";
                ns1_writeObjectOutResponse = "ns1:writeObjectOutNewResponse";
                writeObjectOutResponse = "writeObjectOutNewResponse";
                writeObjectOut = "writeObjectOutNew";
            }
        }
        if (xml.FindChildElem("Group_Response"))
        {
            string group_response = xml.GetChildData();
            if(group_response.find("1") == std::string::npos)
            {
                g_group_response = false;
            }
            else
            {
                g_group_response = true;
            }
            DATA_PRINT(LEVEL_INFO, "%s=%s\n", xml.GetChildTagName().c_str(), group_response.c_str());
        }
        if (xml.FindChildElem("timelimit"))
        {
            std::string timecount;
            timecount = xml.GetChildData();
            if(!timecount.empty())
            {
                g_timelimit= stoi(timecount);
            }
            DATA_PRINT(LEVEL_INFO, "%s=%d\n", xml.GetChildTagName().c_str(), g_timelimit);
        }
        if (xml.FindChildElem("remoteServerIp"))
        {
            xml.IntoElem();
            while (xml.FindChildElem("childRemoteServerIp"))
            {
                std::string tmp_remote_server_ip = xml.GetChildData();
                if (!tmp_remote_server_ip.empty()) {
                    g_vec_remote_server_ip.push_back(tmp_remote_server_ip);
                }
            }
            xml.OutOfElem();

            g_remoteServerIp = xml.GetChildData();
            if (g_remoteServerIp.empty()) {
                g_remoteServerIp = g_vec_remote_server_ip.at(0);
            }
            g_remoteServerIp_Char = (char *)g_remoteServerIp.c_str();
            DATA_PRINT(LEVEL_INFO, "%s=%s\n", xml.GetChildTagName().c_str(), g_remoteServerIp.c_str());
        }
        if (xml.FindChildElem("MacIP"))
        {
            g_localMac = xml.GetChildData();
            DATA_PRINT(LEVEL_INFO, "%s=%s\n", xml.GetChildTagName().c_str(), g_localMac.c_str());
        }
        if (xml.FindChildElem("remoteServerPort"))
        {
            g_remoteServerPort = xml.GetChildData();
            DATA_PRINT(LEVEL_INFO, "%s=%s\n", xml.GetChildTagName().c_str(), g_remoteServerPort.c_str());
        }
        if (xml.FindChildElem("SOAP_ServerPort"))
        {
            g_SOAP_ServerPort = xml.GetChildData();
            DATA_PRINT(LEVEL_INFO, "%s=%s\n", xml.GetChildTagName().c_str(), g_SOAP_ServerPort.c_str());
        }
        if (xml.FindChildElem("Video_ServerPort"))
        {
            g_Video_ServerPort = xml.GetChildData();
            DATA_PRINT(LEVEL_INFO, "%s=%s\n", xml.GetChildTagName().c_str(), g_Video_ServerPort.c_str());
        }
        if (xml.FindChildElem("Ftp_UserPass"))
        {
            g_ftp_UserPas = xml.GetChildData();
            DATA_PRINT(LEVEL_INFO, "%s=%s\n", xml.GetChildTagName().c_str(), g_ftp_UserPas.c_str());
        }
        if (xml.FindChildElem("localServerIp"))
        {
            g_localServerIp = xml.GetChildData();
            if(g_localServerIp.empty())
            {
                g_localServerIp="0.0.0.0";
            }
            if(g_localServerIp.find(".") == std::string::npos)
            {
                DATA_PRINT(LEVEL_INFO, "localServerIp 配置错误!! \n");
                exit(1);
            }
            DATA_PRINT(LEVEL_INFO, "%s=%s\n", xml.GetChildTagName().c_str(), g_localServerIp.c_str());
        }
        else
        {
            g_localServerIp = "0.0.0.0";
            DATA_PRINT(LEVEL_INFO, "%s=%s\n", xml.GetChildTagName().c_str(), g_localServerIp.c_str());
        }
        if (xml.FindChildElem("localServerPort"))
        {
            g_localServerPort = xml.GetChildData();
            DATA_PRINT(LEVEL_INFO, "%s=%s\n", xml.GetChildTagName().c_str(), g_localServerPort.c_str());
        }
        if (xml.FindChildElem("SlaveCount"))
        {
            /*
                g_SlaveCount含义:
                -1：表示本机器是从机，接收主机分发的车检请求。
                0：表示本机器独立运行。
                >0：表示本机器是主机，下游从机的数量是g_SlaveCount。
            */
            g_SlaveCount = atoi(xml.GetChildData().c_str());
            DATA_PRINT(LEVEL_INFO, "%s=%d\n", xml.GetChildTagName().c_str(), g_SlaveCount);

            if (xml.FindChildElem("master")) {
                xml.IntoElem();

                if (xml.FindChildElem("IP")) {
                    g_master_IP = xml.GetChildData();
                }

                xml.OutOfElem();
            }

            for (int i = 0; i < g_SlaveCount; i++) {
                if (xml.FindChildElem("slave")) {
                    xml.IntoElem();

                    SlaveInfo tmp;
                    if (xml.FindChildElem("IP")) {
                        tmp.ip = xml.GetChildData();
                    }

                    if (xml.FindChildElem("port")) {
                        tmp.port = xml.GetChildData();
                    }

                    SlaveList.push_back(tmp);
                    xml.OutOfElem();
                }
            }

            for (unsigned int i = 0; i < SlaveList.size(); i++) {
                DATA_PRINT(LEVEL_INFO, "slave%d(IP:%s, port:%s) \n", i, SlaveList[i].ip.c_str(), SlaveList[i].port.c_str());
            }
        }
        if (xml.FindChildElem("photoUri"))
        {
            g_photoUri = xml.GetChildData();
            DATA_PRINT(LEVEL_INFO, "%s=%s\n", xml.GetChildTagName().c_str(), g_photoUri.c_str());
        }
        if (xml.FindChildElem("photoFilePath"))
        {
            g_photoFilePath = xml.GetChildData();
            DATA_PRINT(LEVEL_INFO, "%s=%s\n", xml.GetChildTagName().c_str(), g_photoFilePath.c_str());
        }
        if (xml.FindChildElem("videoFilePath"))
        {
            g_videoFilePath = xml.GetChildData();
            DATA_PRINT(LEVEL_INFO, "%s=%s\n", xml.GetChildTagName().c_str(), g_videoFilePath.c_str());
        }
        if (xml.FindChildElem("PhotoKeepMonths"))
        {
            g_photoKeepMonths = atoi(xml.GetChildData().c_str());
            DATA_PRINT(LEVEL_INFO, "%s=%d\n", xml.GetChildTagName().c_str(), g_photoKeepMonths);
        }
        if (xml.FindChildElem("VideoKeepDays"))
        {
            g_videoKeepDays = atoi(xml.GetChildData().c_str());
            DATA_PRINT(LEVEL_INFO, "%s=%d\n", xml.GetChildTagName().c_str(), g_videoKeepDays);
        }
        if (xml.FindChildElem("DiskPreserveSizeG"))
        {
            g_diskPreserveSizeG = atoi(xml.GetChildData().c_str());
            DATA_PRINT(LEVEL_INFO, "%s=%d\n", xml.GetChildTagName().c_str(), g_diskPreserveSizeG);
        }
        if (xml.FindChildElem("confJkxlh"))
        {
            g_confJkxlh = xml.GetChildData();
            DATA_PRINT(LEVEL_INFO, "%s=%s\n", xml.GetChildTagName().c_str(), g_confJkxlh.c_str());
        }
        if (xml.FindChildElem("demo_path"))
        {
            g_demo_path = xml.GetChildData();
            DATA_PRINT(LEVEL_INFO, "%s=%s\n", xml.GetChildTagName().c_str(), g_demo_path.c_str());
        }
        if (xml.FindChildElem("NvrDwlDuration"))
        {
            g_nvr_dwl_duration = xml.GetChildData();
            DATA_PRINT(LEVEL_INFO, "%s=%s\n", xml.GetChildTagName().c_str(), g_nvr_dwl_duration.c_str());
        }
        if (xml.FindChildElem("KeepVideoFile"))
        {
            g_keep_video_file = xml.GetChildData();
            DATA_PRINT(LEVEL_INFO, "%s=%s\n", xml.GetChildTagName().c_str(), g_keep_video_file.c_str());
        }
        if (xml.FindChildElem("version"))
        {
            g_version = xml.GetChildData();
            DATA_PRINT(LEVEL_INFO, "%s=%s\n", xml.GetChildTagName().c_str(), g_version.c_str());
        }
        g_version = SOFT_VERSION;
        if (xml.FindChildElem("DownloadLimit"))
        {
            g_DownloadLimit = atoi(xml.GetChildData().c_str());
            DATA_PRINT(LEVEL_INFO, "%s=%d\n", xml.GetChildTagName().c_str(), g_DownloadLimit);
        }

        if (xml.FindChildElem("QueryNumber"))
        {
            g_QueryNumber = xml.GetChildData();
            DATA_PRINT(LEVEL_INFO, "%s=%s\n", xml.GetChildTagName().c_str(), g_QueryNumber.c_str());
        }

        if (xml.FindChildElem("QueryInterval"))
        {
            g_QueryInterval = atoi(xml.GetChildData().c_str());
            DATA_PRINT(LEVEL_INFO, "%s=%d\n", xml.GetChildTagName().c_str(), g_QueryInterval);
        }

        if (xml.FindChildElem("dzbdJkxlh")) // 获取电子保单序列号
        {
            g_strdzbdjkxlh = xml.GetChildData();
            DATA_PRINT(LEVEL_INFO, "%s=%s\n", xml.GetChildTagName().c_str(), g_strdzbdjkxlh.c_str());
        }
    }
    else
    {
        //char debug_level_str[8];
        //itoa(g_debug_level, debug_level_str, 10);
        xml.SetDoc("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n");
        xml.AddElem("config");
        xml.IntoElem();
        xml.AddElem("trace_level", g_debug_level);
        xml.AddElem("requestUri", g_requestUri);
        xml.AddElem("remoteServerIp", g_remoteServerIp);
        xml.AddElem("remoteServerPort", g_remoteServerPort);
        xml.AddElem("SOAP_ServerPort", g_SOAP_ServerPort);
        xml.AddElem("localServerIp", g_localServerIp);
        xml.AddElem("localServerPort", g_localServerPort);

        xml.AddElem("SlaveCount", g_SlaveCount);
        xml.AddElem("slave");
        xml.IntoElem();
        xml.AddElem("IP", "192.168.0.1");
        xml.AddElem("port", "9000");
        xml.OutOfElem();

        xml.AddElem("photoUri", g_photoUri);
        xml.AddElem("photoFilePath", g_photoFilePath);
        xml.AddElem("videoFilePath", g_videoFilePath);
        xml.AddElem("confJkxlh", g_confJkxlh);
        xml.AddElem("demo_path", g_demo_path);
        xml.AddElem("NvrDwlDuration", g_nvr_dwl_duration);
        xml.AddElem("KeepVideoFile", g_keep_video_file);
        xml.AddElem("syxz_check");
        xml.IntoElem();
        xml.AddElem("syxz", "A");
        xml.OutOfElem();

        xml.OutOfElem();
        xml.Save(conf_name);
    }
}

void checkElement(CMarkup &xml, std::vector<std::string> level, std::string element)
{
    if (!xml.FindElem(element)) {
        DATA_PRINT(LEVEL_ERROR, "读取配置文件check_item.xml失败！ \n");
        std::string reason = "原因: 没有节点“";

        for (unsigned int i = 0; i < level.size(); i++) {
            reason += level[i] + "/";
        }

        reason += element;

        DATA_PRINT(LEVEL_ERROR, "%s” \n", reason.data());
        exit(EXIT_FAILURE);
    }
}

BOOL AnalyseData( std::string source_data,std::string second_data,std::string first_data,CMarkup xml,std::vector< std::string > &error_item )
{
    if( xml.FindChildElem(source_data) ){
        if(xml.GetChildData() != "on" && xml.GetChildData() != "off" ){
            char tmp[100];
            memset(tmp,'\0',sizeof(tmp));
            sprintf(tmp,"%s---->%s---->%s配置错误 \n",first_data.c_str(),second_data.c_str(),source_data.c_str());
            error_item.push_back(tmp);

        }else{
            if( xml.GetChildData() == "on" ){
                return true;
            }


        }return false;
    }else{
       char tmp[100];
       memset(tmp,'\0',sizeof(tmp));
       sprintf(tmp,"%s----->%s---->%s未配置 \n",first_data.c_str(),second_data.c_str(),source_data.c_str());
       error_item.push_back(tmp);
       return false;
    }


}
extern _ZhaoPianZL ZhaoPianZL;
/* 从配置文件(check_item.xml)获取车检软件处理范围（使用性质，车辆种类，照片类型）*/
void getCheckItem()
{
    std::string on = "on";
    std::string number = "number";
    CMarkup xml;
    std::vector<std::string> level;
    //错误信息vector
    std::vector< std::string > error_item;

    std::string conf_name = "check_item.xml";
    if(baseTool::fileIsExist("/opt/vehicle/program/CheJianConfig/check_item.xml"))
    {
        conf_name = "/opt/vehicle/program/CheJianConfig/check_item.xml";
    }

    //check_item中第一个节点字段
    std::set< std::string > first_item = {

        "City","GongZuoShiJian","JianYanLeiBie",
        "ShiYongXingZhi","CheLiangZhongLei","JianYanJiGou",
        "ZhaoPian","ShiPin","SuzhouVideo","ZhuCongYiZhi"
    };

    //照片审核二级字段
    std::set< std::string > zhaopian_item = {
        "ZuoQianFang","ZuoFang","YouHouFang",
        "CheJiaHao","AnQuanDai",
        "XingShiZheng","XingShiZhengBeiMian",
        "JiaoQiangXian","JianYanBaoGao","JianYanBaoGao_YiQi",
        "JianYanBaoGao_RenGong","WeiTuoShu",
        "ShenQingBiao","WeiQiJianYan","WeiQiJianYan2","ZuoDengGuang",
        "YouDengGuang","YiZhouZhiDong","ErZhouZhiDong",
        "ZhuCheZhiDong","DiPanDongTaiKaiShi","DiPanDongTaiJieShu",
        "DiPanBuJian","ChaYanJiLu","QianHaoPai",
        "HouHaoPai","ShenFenZheng","ShenFenZhengBeiMian",
        "JianYanBiaoBeiMian","WanShuiZhengMing","WeiTuoTongZhiShu",
        "MieHuoQi","YingJiChui","JiLuYi",
        "ZuoQianLun","YouQianLun","CheXiang",
        "CeHuaGongWei","WaiKuoQianMian","WaiKuoCeMian",
        "DaCheHaoPai","WeiXiangNeiBu","FuZhuZhiDong",
        "ABS","CheLiangCeMian","CheLiangBeiMian",
        "HeDingZaiKe","JianCeQuXianBaoGao","CheJiaHaoUG","CheLiangMingPai",
        "GaoZhiShu","RongQueShouLi","QianChePaiTeXie","HouChePaiTeXie",
        "QianLunZhaoPian","HouLunZhaoPian"
    };
    //视频审核二级字段
    std::set< std::string > shipin_item = {
        "ZuoQianFang","YouHouFang","YiZhouZhiDong",
        "ErZhouZhiDong","ZuoDengGuang","YouDengGuang",
        "DongTaiGongWei_1","DongTaiGongWei_2","DiPanGongWei",
        "ZhuCheZhiDong"
    };
    //苏州视频审核二级字段
    std::set< std::string > suzhouvideo_item = {
        "SpaoConnect","Download","V_CheLiangZuoQianFang",
        "V_CheLiangYouHouFang","V_YiZhouZhiDong","V_ErZhouZhiDong",
        "V_ZuoDengGuang","V_YouDengGuang",
        "V_DiPan","V_ZhuCheZhiDong"
    };
    if (!xml.Load(conf_name.c_str())) {
        DATA_PRINT(LEVEL_ERROR, "读取配置文件check_item.xml失败！ \n");
        DATA_PRINT(LEVEL_ERROR, "原因: %s \n", xml.GetError().data());
        exit(EXIT_FAILURE);
    }

//    checkElement(xml, level, "Items");
//    xml.IntoElem();
//    level.push_back("Items");

//    checkElement(xml, level, "City");
//    g_CheckItem.City = xml.GetData();


//To be continue......



    if (xml.FindElem("Items")) {
        xml.IntoElem();

        if (xml.FindElem("City")) {
            first_item.erase("City");
            g_CheckItem.City = xml.GetData();
            if( "8100" < g_CheckItem.City || g_CheckItem.City < "1100" ){
                error_item.push_back("城市代码配置错误 \n");
            }
        }
        if (xml.FindElem("ZhuCongYiZhi"))
        {
            first_item.erase("ZhuCongYiZhi");
            g_CheckItem.ZhuCongYiZhi = atoi(xml.GetData().c_str());
            if(g_CheckItem.ZhuCongYiZhi != 0 && g_CheckItem.ZhuCongYiZhi != 1)
            {
                error_item.push_back("主从一致配置错误\n");
            }
        }
        if (xml.FindElem("GongZuoShiJian")) {
            first_item.erase("GongZuoShiJian");
            if (xml.FindChildElem("KaiShi")) {
                g_CheckItem.ShiJian.KaiShi = atoi(xml.GetChildData().c_str());
                if( g_CheckItem.ShiJian.KaiShi > 23 || g_CheckItem.ShiJian.KaiShi < 0){
                    error_item.push_back("开始时间配置错误\n");
                }
            }

            if (xml.FindChildElem("JieShu")) {
                g_CheckItem.ShiJian.JieShu = atoi(xml.GetChildData().c_str());
                if( g_CheckItem.ShiJian.JieShu > 24 || g_CheckItem.ShiJian.JieShu < 1 ){
                    error_item.push_back("结束时间配置错误\n");
                }
            }
        }
        if (xml.FindElem("JianYanLeiBie")) {
            first_item.erase("JianYanLeiBie");
            while (xml.FindChildElem("LeiBie")) {
                std::string tmp = xml.GetChildData();
                if( tmp < "01" || tmp > "04" ){
                    error_item.push_back("检验类别配置错误\n");
                }
                g_CheckItem.JianYanLeiBie.push_back(tmp);
            }
        }

        if (xml.FindElem("ShiYongXingZhi")) {
            first_item.erase("ShiYongXingZhi");
            while (xml.FindChildElem("XingZhi")) {
                std::string tmp= xml.GetChildData();
                 if( tmp.length() == 1){
                    if( tmp < "A" || tmp > "Z" ){
                        error_item.push_back("使用性质配置错误\n");
                    }

                }else if( tmp.length() > 1 ){
                    error_item.push_back("使用性质配置错误\n");
                }
                g_CheckItem.ShiYongXingZhi.push_back(tmp);
            }
        }

        if (xml.FindElem("CheLiangZhongLei")) {
            first_item.erase("CheLiangZhongLei");
            std::string clzl = xml.GetData();
            vector<std::string> mid_check;
            vector<std::string> qczl_check;
            int ipose = 0;
            int inums = 0;
//            int count = 0;
            std::string strTemp = clzl;
            std::string strRight;
            while (ipose != -1)
            {
                ipose = strTemp.find(",");
                if (ipose == -1)
                {
                    break;
                }
                strRight = strTemp.substr(ipose + 1, strTemp.size());
                strTemp = strRight;
                inums++;
            }
            if (inums == 0)
            {  
                if(!clzl.empty())
                {
//                    count = 1;
                    qczl_check.push_back((clzl));
                }
            }
            else
            {
//                count = inums + 1;
//                std::string* pStrSplit;
//                pStrSplit = new std::string[count];
                strTemp = clzl;
                std::string strLeft;
                for (int i = 0; i < inums; i++)
                {
                    ipose = strTemp.find(",");
                    strLeft = strTemp.substr(0,ipose);
                    strRight = strTemp.substr(ipose + 1, strTemp.size());
                    strTemp = strRight;
                    if( strLeft.length() != 3 ){
                        error_item.push_back("车辆种类配置错误\n");
                    }
                    else{
                        if( strLeft[0] > 'Z' || strLeft[0] < 'A'){
                            error_item.push_back("车辆种类配置错误\n");
                        }else if( strLeft[1] < '0' || strLeft[1] > '9' || strLeft[2] < '0' || strLeft[2] > '9' ){
                            error_item.push_back("车辆种类配置错误\n");
                        }

                    }
                    mid_check.push_back(strLeft);
                }
                mid_check.push_back(strTemp);
                qczl_check = mid_check;
            }

            for (unsigned int i = 0; i < qczl_check.size(); i++) {
                std::string tmp = qczl_check[i];
                g_CheckItem.CheLiangZhongLei.push_back(std::string(tmp));
            }
        }

        if (xml.FindElem("JianYanJiGou")) {
            first_item.erase("JianYanJiGou");
            while (xml.FindChildElem("BianHao")) {
                t_JianYanJiGou JYJG;
                JYJG.bh = xml.GetChildData();
                JYJG.assignment_IP = xml.GetChildAttrib("assignment_IP");
                g_CheckItem.JianYanJiGou.push_back(JYJG);
            }
        }

        if (xml.FindElem("ZhaoPian")) {
            first_item.erase("ZhaoPian");

            xml.IntoElem();

            if (xml.FindElem("ZuoQianFang")) {
                zhaopian_item.erase("ZuoQianFang");
                ZhaoPianZL.ZuoQianFang = xml.GetAttrib(number);
                g_CheckItem.picture.ZuoQianFang.ChePai = AnalyseData("ChePai","ZuoQianFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZuoQianFang.CheBiao = AnalyseData("CheBiao","ZuoQianFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZuoQianFang.SanJiaoJia = AnalyseData("SanJiaoJia","ZuoQianFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZuoQianFang.CheShenFanGuangBiaoShi = AnalyseData("CheShenFanGuangBiaoShi","ZuoQianFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZuoQianFang.ZuoCePenTu = AnalyseData("ZuoCePenTu","ZuoQianFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZuoQianFang.ZuoCeFangHu = AnalyseData("ZuoCeFangHu","ZuoQianFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZuoQianFang.GaiZhuang = AnalyseData("GaiZhuang","ZuoQianFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZuoQianFang.DangAn = AnalyseData("DangAn","ZuoQianFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZuoQianFang.ShuiYinRiQi = AnalyseData("ShuiYinRiQi","ZuoQianFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZuoQianFang.FangXiang = AnalyseData("FangXiang","ZuoQianFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZuoQianFang.CheShenYanSe = AnalyseData("CheShenYanSe", "ZuoQianFang", "ZhaoPian",xml, error_item);
            }

            if (xml.FindElem("ZuoFang")) {
                zhaopian_item.erase("ZuoFang");
                ZhaoPianZL.ZuoFang = xml.GetAttrib(number);
                g_CheckItem.picture.ZuoFang.ChePai = AnalyseData("ChePai","ZuoFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZuoFang.GaiZhuang = AnalyseData("GaiZhuang","ZuoFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZuoFang.GuangGao = AnalyseData("GuangGao","ZuoFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZuoFang.CheShenYanSe = AnalyseData("CheShenYanSe", "ZuoFang","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("YouHouFang")) {
                zhaopian_item.erase("YouHouFang");
                ZhaoPianZL.YouHouFang = xml.GetAttrib(number);
                g_CheckItem.picture.YouHouFang.ChePai = AnalyseData("ChePai","YouHouFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouHouFang.CheBiao = AnalyseData("CheBiao","YouHouFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouHouFang.SanJiaoJia = AnalyseData("SanJiaoJia","YouHouFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouHouFang.HouBuCheShenFanGuangBiaoShi = AnalyseData("HouBuCheShenFanGuangBiaoShi","YouHouFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouHouFang.YouCeCheShenFanGuangBiaoShi = AnalyseData("YouCeCheShenFanGuangBiaoShi","YouHouFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouHouFang.LanBanGaoDu = AnalyseData("LanBanGaoDu","YouHouFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouHouFang.CheLiangWeiBuBiaoZhiBan = AnalyseData("CheLiangWeiBuBiaoZhiBan","YouHouFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouHouFang.HouXiaFangHu = AnalyseData("HouXiaFangHu","YouHouFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouHouFang.YouCeFangHu = AnalyseData("YouCeFangHu","YouHouFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouHouFang.HouBuPenTu = AnalyseData("HouBuPenTu","YouHouFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouHouFang.GaiZhuang = AnalyseData("GaiZhuang","YouHouFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouHouFang.ShuiYinRiQi = AnalyseData("ShuiYinRiQi","YouHouFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouHouFang.PaiQiKong = AnalyseData("PaiQiKong","YouHouFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouHouFang.FangXiang = AnalyseData("FangXiang","YouHouFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouHouFang.CheShenYanSe = AnalyseData("CheShenYanSe", "YouHouFang","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("CheJiaHao")) {
                zhaopian_item.erase("CheJiaHao");
                ZhaoPianZL.CheJiaHao = xml.GetAttrib(number);
                g_CheckItem.picture.CheJiaHao.CheJiaHao = AnalyseData("CheJiaHao","CheJiaHao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheJiaHao.ShuiYinRiQi = AnalyseData("ShuiYinRiQi","CheJiaHao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheJiaHao.TaYinMo = AnalyseData("TaYinMo","CheJiaHao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheJiaHao.DangAn = AnalyseData("DangAn","CheJiaHao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheJiaHao.BaoDing_FTP = AnalyseData("BaoDing_FTP","CheJiaHao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheJiaHao.JiLuBiaoZiMo = AnalyseData("JiLuBiaoZiMo","CheJiaHao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheJiaHao.YuanJing = AnalyseData("YuanJing","CheJiaHao","ZhaoPian",xml,error_item);
                if (NANJING == g_CheckItem.City)
                    g_CheckItem.picture.CheJiaHao.b_nanjing_vin = AnalyseData("NanJingVin", "CheJiaHao", "ZhaoPian", xml, error_item);
            }
            if (xml.FindElem("AnQuanDai")) {
                zhaopian_item.erase("AnQuanDai");
                ZhaoPianZL.AnQuanDai = xml.GetAttrib(number);
                g_CheckItem.picture.AnQuanDai.AnQuanDai = AnalyseData("AnQuanDai","AnQuanDai","ZhaoPian",xml,error_item);
                g_CheckItem.picture.AnQuanDai.ShuiYinRiQi = AnalyseData("ShuiYinRiQi","AnQuanDai","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("XingShiZheng")) {
                zhaopian_item.erase("XingShiZheng");
                ZhaoPianZL.XingShiZheng = xml.GetAttrib(number);
                g_CheckItem.picture.XingShiZheng.CheJiaHao = AnalyseData("CheJiaHao","XingShiZheng","ZhaoPian",xml,error_item);
                g_CheckItem.picture.XingShiZheng.ChePai = AnalyseData("ChePai","XingShiZheng","ZhaoPian",xml,error_item);
                g_CheckItem.picture.XingShiZheng.BianHao = AnalyseData("BianHao","XingShiZheng","ZhaoPian",xml,error_item);
                g_CheckItem.picture.XingShiZheng.FaZhengRiQi = AnalyseData("FaZhengRiQi","XingShiZheng","ZhaoPian",xml,error_item);
                g_CheckItem.picture.XingShiZheng.BeiMian = AnalyseData("BeiMian","XingShiZheng","ZhaoPian",xml,error_item);
                g_CheckItem.picture.XingShiZheng.ShenFenZheng = AnalyseData("ShenFenZheng","XingShiZheng","ZhaoPian",xml,error_item);
                g_CheckItem.picture.XingShiZheng.TianJin = AnalyseData("TianJin","XingShiZheng","ZhaoPian",xml,error_item);
                g_CheckItem.picture.XingShiZheng.CheLiang = AnalyseData("CheLiang","XingShiZheng","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("XingShiZhengBeiMian")) {
                zhaopian_item.erase("XingShiZhengBeiMian");
                ZhaoPianZL.XingShiZhengBeiMian = xml.GetAttrib(number);
                g_CheckItem.picture.XingShiZhengBeiMian.ZhuYe = AnalyseData("ZhuYe","XingShiZhengBeiMian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.XingShiZhengBeiMian.FuYe = AnalyseData("FuYe","XingShiZhengBeiMian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.XingShiZhengBeiMian.ShenFenZheng = AnalyseData("ShenFenZheng","XingShiZhengBeiMian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.XingShiZhengBeiMian.YouXiaoQi = AnalyseData("YouXiaoQi","XingShiZhengBeiMian","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("JiaoQiangXian")) {
                zhaopian_item.erase("JiaoQiangXian");
                ZhaoPianZL.JiaoQiangXian = xml.GetAttrib(number);
                g_CheckItem.picture.JiaoQiangXian.FuBen = AnalyseData("FuBen","JiaoQiangXian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JiaoQiangXian.ChePai = AnalyseData("ChePai","JiaoQiangXian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JiaoQiangXian.ChaoJian = AnalyseData("ChaoJian","JiaoQiangXian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JiaoQiangXian.CheJiaHao = AnalyseData("CheJiaHao","JiaoQiangXian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JiaoQiangXian.YouXiaoQi = AnalyseData("YouXiaoQi","JiaoQiangXian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JiaoQiangXian.GongZhang = AnalyseData("GongZhang","JiaoQiangXian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JiaoQiangXian.CheChuanShui = AnalyseData("CheChuanShui","JiaoQiangXian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JiaoQiangXian.DianZiBaoDan = AnalyseData("DianZiBaoDan","JiaoQiangXian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JiaoQiangXian.FaDongJiHao = AnalyseData("FaDongJiHao","JiaoQiangXian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JiaoQiangXian.ShenZhenDianZiBaoDan = AnalyseData("ShenZhenDianZiBaoDan","JiaoQiangXian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JiaoQiangXian.SuZhouYinZhang = AnalyseData("SuZhouYinZhang","JiaoQiangXian","ZhaoPian",xml,error_item);

            }

            if (xml.FindElem("JianYanBaoGao")) {
                zhaopian_item.erase("JianYanBaoGao");
                ZhaoPianZL.JianYanBaoGao = xml.GetAttrib(number);
                g_CheckItem.picture.JianYanBaoGao.CheJiaHao = AnalyseData("CheJiaHao","JianYanBaoGao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao.ChePai = AnalyseData("ChePai","JianYanBaoGao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao.QianMing = AnalyseData("QianMing","JianYanBaoGao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao.YinZhang = AnalyseData("YinZhang","JianYanBaoGao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao.JieLun = AnalyseData("JieLun","JianYanBaoGao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao.ShuJuXiang = AnalyseData("ShuJuXiang","JianYanBaoGao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao.YinZhang_MA = AnalyseData("YinZhang_MA","JianYanBaoGao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao.QueRenZhang = AnalyseData("QueRenZhang","JianYanBaoGao","ZhaoPian",xml,error_item);
                // ++{{ xeast 2018-06-15 for nan ning
                g_CheckItem.picture.JianYanBaoGao.HaoPaiZhongLei = AnalyseData("HaoPaiZhongLei","JianYanBaoGao","ZhaoPian",xml,error_item);
                // }}
            }

            // ++{{ xeast 2018-06-23 for ning bo
            if (xml.FindElem("JianYanBaoGao_YiQi")) {
                zhaopian_item.erase("JianYanBaoGao_YiQi");
                ZhaoPianZL.JianYanBaoGao_YiQi = xml.GetAttrib(number);
                g_CheckItem.picture.JianYanBaoGao_YiQi.YiQi = AnalyseData("YiQi","JianYanBaoGao_YiQi","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao_YiQi.HongZhang = AnalyseData("HongZhang","JianYanBaoGao_YiQi","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao_YiQi.JieLun = AnalyseData("JieLun","JianYanBaoGao_YiQi","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao_YiQi.ChePai = AnalyseData("ChePai","JianYanBaoGao_YiQi","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao_YiQi.CheJiaHao = AnalyseData("CheJiaHao","JianYanBaoGao_YiQi","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao_YiQi.QianMing = AnalyseData("QianMing","JianYanBaoGao_YiQi","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao_YiQi.YinZhang_MA = AnalyseData("YinZhang_MA","JianYanBaoGao_YiQi","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("JianYanBaoGao_RenGong")) {
                zhaopian_item.erase("JianYanBaoGao_RenGong");
                ZhaoPianZL.JianYanBaoGao_RenGong = xml.GetAttrib(number);
                g_CheckItem.picture.JianYanBaoGao_RenGong.ChePai = AnalyseData("ChePai","JianYanBaoGao_RenGong","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao_RenGong.ChaYanJieLun = AnalyseData("ChaYanJieLun","JianYanBaoGao_RenGong","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao_RenGong.DiPanQianZi = AnalyseData("DiPanQianZi","JianYanBaoGao_RenGong","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao_RenGong.WaiGuanQianZi = AnalyseData("WaiGuanQianZi","JianYanBaoGao_RenGong","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao_RenGong.YinCheQianZi = AnalyseData("YinCheQianZi","JianYanBaoGao_RenGong","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("WeiTuoShu")) {
                zhaopian_item.erase("WeiTuoShu");
                ZhaoPianZL.WeiTuoShu = xml.GetAttrib(number);
                g_CheckItem.picture.WeiTuoShu.WeiTuoShu = AnalyseData("WeiTuoShu","WeiTuoShu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiTuoShu.HongZhang = AnalyseData("HongZhang","WeiTuoShu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiTuoShu.ShenFenZheng = AnalyseData("ShenFenZheng","WeiTuoShu","ZhaoPian",xml,error_item);
            }
            // }}

            if (xml.FindElem("ShenQingBiao")) {
                zhaopian_item.erase("ShenQingBiao");
                ZhaoPianZL.ShenQingBiao = xml.GetAttrib(number);
                g_CheckItem.picture.ShenQingBiao.ShouJi_BenRen = AnalyseData("ShouJi_BenRen","ShenQingBiao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ShenQingBiao.ShouJi_DaiLi = AnalyseData("ShouJi_DaiLi","ShenQingBiao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ShenQingBiao.ChePai = AnalyseData("ChePai","ShenQingBiao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ShenQingBiao.is_CheLiangType = AnalyseData("is_CheLiangType","ShenQingBiao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ShenQingBiao.is_YouBian = AnalyseData("is_YouBian","ShenQingBiao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ShenQingBiao.is_DiZhi = AnalyseData("is_DiZhi","ShenQingBiao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ShenQingBiao.CheJiaHao = AnalyseData("CheJiaHao","ShenQingBiao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ShenQingBiao.QianMing = AnalyseData("QianMing","ShenQingBiao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ShenQingBiao.YinZhang = AnalyseData("YinZhang","ShenQingBiao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ShenQingBiao.XingMing = AnalyseData("XingMing","ShenQingBiao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ShenQingBiao.JianYanHeGeBiaoZhi = AnalyseData("JianYanHeGeBiaoZhi","ShenQingBiao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ShenQingBiao.HaoPaiZhongLei = AnalyseData("HaoPaiZhongLei","ShenQingBiao","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("WeiQiJianYan")) {
                zhaopian_item.erase("WeiQiJianYan");
                ZhaoPianZL.WeiQiJianYan = xml.GetAttrib(number);
                g_CheckItem.picture.WeiQiJianYan.JieLun = AnalyseData("JieLun","WeiQiJianYan","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan.ChePai = AnalyseData("ChePai","WeiQiJianYan","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan.CheJiaHao = AnalyseData("CheJiaHao","WeiQiJianYan","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan.YinZhang = AnalyseData("YinZhang","WeiQiJianYan","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan.QianMing = AnalyseData("QianMing","WeiQiJianYan","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan.YinZhang_MA = AnalyseData("YinZhang_MA","WeiQiJianYan","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan.DianZiBaoGao = AnalyseData("DianZiBaoGao","WeiQiJianYan","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan.CaoZuoYuan = AnalyseData("CaoZuoYuan","WeiQiJianYan","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan.JiaShiYuan = AnalyseData("JiaShiYuan","WeiQiJianYan","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan.PiZhunRen = AnalyseData("PiZhunRen","WeiQiJianYan","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan.ShenHeYuan = AnalyseData("ShenHeYuan","WeiQiJianYan","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan.JianCeShiJian = AnalyseData("JianCeShiJian","WeiQiJianYan","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan.DianZiBiaoGe = AnalyseData("DianZiBiaoGe","WeiQiJianYan","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan.YouXiaoQi = AnalyseData("YouXiaoQi","WeiQiJianYan","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan.FaDongJiBianHao = AnalyseData("FaDongJiBianHao","WeiQiJianYan","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("ZuoDengGuang")) {
                zhaopian_item.erase("ZuoDengGuang");
                ZhaoPianZL.ZuoDengGuang = xml.GetAttrib(number);
                g_CheckItem.picture.ZuoDengGuang.ZuoQianDeng = AnalyseData("ZuoQianDeng","ZuoDengGuang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZuoDengGuang.YouQianDeng = AnalyseData("YouQianDeng","ZuoDengGuang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZuoDengGuang.ChePai = AnalyseData("ChePai","ZuoDengGuang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZuoDengGuang.QianMian = AnalyseData("QianMian","ZuoDengGuang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZuoDengGuang.ShuiYinRiQi = AnalyseData("ShuiYinRiQi","ZuoDengGuang","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("YouDengGuang")) {
                zhaopian_item.erase("YouDengGuang");
                ZhaoPianZL.YouDengGuang = xml.GetAttrib(number);
                g_CheckItem.picture.YouDengGuang.ZuoQianDeng = AnalyseData("ZuoQianDeng","YouDengGuang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouDengGuang.YouQianDeng = AnalyseData("YouQianDeng","YouDengGuang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouDengGuang.ChePai = AnalyseData("ChePai","YouDengGuang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouDengGuang.QianMian = AnalyseData("QianMian","YouDengGuang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouDengGuang.ShuiYinRiQi = AnalyseData("ShuiYinRiQi","YouDengGuang","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("YiZhouZhiDong")) {
                zhaopian_item.erase("YiZhouZhiDong");
                ZhaoPianZL.YiZhouZhiDong = xml.GetAttrib(number);
                g_CheckItem.picture.YiZhouZhiDong.QianLun = AnalyseData("QianLun","YiZhouZhiDong","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YiZhouZhiDong.ChePai = AnalyseData("ChePai","YiZhouZhiDong","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YiZhouZhiDong.ShuiYinRiQi = AnalyseData("ShuiYinRiQi","YiZhouZhiDong","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("ErZhouZhiDong")) {
                zhaopian_item.erase("ErZhouZhiDong");
                ZhaoPianZL.ErZhouZhiDong = xml.GetAttrib(number);
                g_CheckItem.picture.ErZhouZhiDong.HouLun = AnalyseData("HouLun","ErZhouZhiDong","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ErZhouZhiDong.ChePai = AnalyseData("ChePai","ErZhouZhiDong","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ErZhouZhiDong.ShuiYinRiQi = AnalyseData("ShuiYinRiQi","ErZhouZhiDong","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("ZhuCheZhiDong")) {
                zhaopian_item.erase("ZhuCheZhiDong");
                ZhaoPianZL.ZhuCheZhiDong = xml.GetAttrib(number);
                g_CheckItem.picture.ZhuCheZhiDong.ChePai = AnalyseData("ChePai","ZhuCheZhiDong","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZhuCheZhiDong.CheLun = AnalyseData("CheLun","ZhuCheZhiDong","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZhuCheZhiDong.ShuiYinRiQi = AnalyseData("ShuiYinRiQi","ZhuCheZhiDong","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("DiPanDongTaiKaiShi")) {
                zhaopian_item.erase("DiPanDongTaiKaiShi");
                ZhaoPianZL.DiPanDongTaiKaiShi = xml.GetAttrib(number);
                g_CheckItem.picture.DiPanDongTaiKaiShi.ChePai = AnalyseData("ChePai","DiPanDongTaiKaiShi","ZhaoPian",xml,error_item);
                g_CheckItem.picture.DiPanDongTaiKaiShi.ChePaiQueDing = AnalyseData("ChePaiQueDing","DiPanDongTaiKaiShi","ZhaoPian",xml,error_item);
                g_CheckItem.picture.DiPanDongTaiKaiShi.YiDong = AnalyseData("YiDong","DiPanDongTaiKaiShi","ZhaoPian",xml,error_item);
                g_CheckItem.picture.DiPanDongTaiKaiShi.ShuiYinRiQi = AnalyseData("ShuiYinRiQi","DiPanDongTaiKaiShi","ZhaoPian",xml,error_item);
                g_CheckItem.picture.DiPanDongTaiKaiShi.BiaoZhi = AnalyseData("BiaoZhi","DiPanDongTaiKaiShi","ZhaoPian",xml,error_item);
                g_CheckItem.picture.DiPanDongTaiKaiShi.CheWei = AnalyseData("CheWei","DiPanDongTaiKaiShi","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("DiPanDongTaiJieShu")) {
                zhaopian_item.erase("DiPanDongTaiJieShu");
                ZhaoPianZL.DiPanDongTaiJieShu = xml.GetAttrib(number);
                g_CheckItem.picture.DiPanDongTaiJieShu.ChePai = AnalyseData("ChePai","DiPanDongTaiJieShu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.DiPanDongTaiJieShu.YiDong = AnalyseData("YiDong","DiPanDongTaiJieShu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.DiPanDongTaiJieShu.ShuiYinRiQi = AnalyseData("ShuiYinRiQi","DiPanDongTaiJieShu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.DiPanDongTaiJieShu.BiaoZhi = AnalyseData("BiaoZhi","DiPanDongTaiJieShu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.DiPanDongTaiJieShu.CheTou = AnalyseData("CheTou","DiPanDongTaiJieShu","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("DiPanBuJian")) {
                zhaopian_item.erase("DiPanBuJian");
                ZhaoPianZL.DiPanBuJian = xml.GetAttrib(number);
                g_CheckItem.picture.DiPanBuJian.GongWei = AnalyseData("GongWei","DiPanBuJian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.DiPanBuJian.ChePai = AnalyseData("ChePai","DiPanBuJian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.DiPanBuJian.ShuiYinRiQi = AnalyseData("ShuiYinRiQi","DiPanBuJian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.DiPanBuJian.Ren = AnalyseData("Ren","DiPanBuJian","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("ChaYanJiLu")) {
                zhaopian_item.erase("ChaYanJiLu");
                ZhaoPianZL.ChaYanJiLu = xml.GetAttrib(number);
                g_CheckItem.picture.ChaYanJiLu.JianYanBiao = AnalyseData("JianYanBiao","ChaYanJiLu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ChaYanJiLu.ChaYanXinXi = AnalyseData("ChaYanXinXi","ChaYanJiLu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ChaYanJiLu.ChePai = AnalyseData("ChePai","ChaYanJiLu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ChaYanJiLu.CheJiaHao = AnalyseData("CheJiaHao","ChaYanJiLu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ChaYanJiLu.ChaYanJieLun = AnalyseData("ChaYanJieLun","ChaYanJiLu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ChaYanJiLu.ChaYanQianZi = AnalyseData("ChaYanQianZi","ChaYanJiLu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ChaYanJiLu.WaiGuanQianZi = AnalyseData("WaiGuanQianZi","ChaYanJiLu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ChaYanJiLu.YinCheQianZi = AnalyseData("YinCheQianZi","ChaYanJiLu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ChaYanJiLu.DiPanQianZi = AnalyseData("DiPanQianZi","ChaYanJiLu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ChaYanJiLu.HongZhang = AnalyseData("HongZhang","ChaYanJiLu","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("QianHaoPai")) {
                zhaopian_item.erase("QianHaoPai");
                ZhaoPianZL.QianHaoPai = xml.GetAttrib(number);
                g_CheckItem.picture.QianHaoPai.ChePai = AnalyseData("ChePai","QianHaoPai","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("HouHaoPai")) {
                zhaopian_item.erase("HouHaoPai");
                ZhaoPianZL.HouHaoPai = xml.GetAttrib(number);
                g_CheckItem.picture.HouHaoPai.ChePai = AnalyseData("ChePai","HouHaoPai","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("ShenFenZheng")) {
                zhaopian_item.erase("ShenFenZheng");
                ZhaoPianZL.ShenFenZheng = xml.GetAttrib(number);
                g_CheckItem.picture.ShenFenZheng.ShenFenZheng = AnalyseData("ShenFenZheng","ShenFenZheng","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ShenFenZheng.XingMing = AnalyseData("XingMing","ShenFenZheng","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("ShenFenZhengBeiMian")) {
                zhaopian_item.erase("ShenFenZhengBeiMian");
                ZhaoPianZL.ShenFenZhengBeiMian = xml.GetAttrib(number);
                g_CheckItem.picture.ShenFenZhengBeiMian.ShenFenZheng = AnalyseData("ShenFenZheng","ShenFenZhengBeiMian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ShenFenZhengBeiMian.YouXiaoQi = AnalyseData("YouXiaoQi","ShenFenZhengBeiMian","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("JianYanBiaoBeiMian")) {
                zhaopian_item.erase("JianYanBiaoBeiMian");
                ZhaoPianZL.JianYanBiaoBeiMian = xml.GetAttrib(number);
                g_CheckItem.picture.JianYanBiaoBeiMian.JianYanBiaoBeiMian = AnalyseData("JianYanBiaoBeiMian","JianYanBiaoBeiMian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBiaoBeiMian.DiPan = AnalyseData("DiPan","JianYanBiaoBeiMian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBiaoBeiMian.WaiGuan = AnalyseData("WaiGuan","JianYanBiaoBeiMian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBiaoBeiMian.YinChe = AnalyseData("YinChe","JianYanBiaoBeiMian","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("WanShuiZhengMing")) {
                zhaopian_item.erase("WanShuiZhengMing");
                ZhaoPianZL.WanShuiZhengMing = xml.GetAttrib(number);
                g_CheckItem.picture.WanShuiZhengMing.CheJiaHao = AnalyseData("CheJiaHao","WanShuiZhengMing","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WanShuiZhengMing.ChePai = AnalyseData("ChePai","WanShuiZhengMing","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WanShuiZhengMing.CheChuanShui = AnalyseData("CheChuanShui","WanShuiZhengMing","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WanShuiZhengMing.SuoShuRiQi = AnalyseData("SuoShuRiQi","WanShuiZhengMing","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WanShuiZhengMing.JianCeRiQi = AnalyseData("JianCeRiQi","WanShuiZhengMing","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WanShuiZhengMing.BaoXianDan = AnalyseData("BaoXianDan","WanShuiZhengMing","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("WeiTuoTongZhiShu")) {
                zhaopian_item.erase("WeiTuoTongZhiShu");
                ZhaoPianZL.WeiTuoTongZhiShu = xml.GetAttrib(number);
                g_CheckItem.picture.WeiTuoTongZhiShu.WeiTuoTongZhiShu = AnalyseData("WeiTuoTongZhiShu","WeiTuoTongZhiShu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiTuoTongZhiShu.ChePai = AnalyseData("ChePai","WeiTuoTongZhiShu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiTuoTongZhiShu.CheJiaHao = AnalyseData("CheJiaHao","WeiTuoTongZhiShu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiTuoTongZhiShu.YinZhang = AnalyseData("YinZhang","WeiTuoTongZhiShu","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("MieHuoQi")) {
                zhaopian_item.erase("MieHuoQi");
                ZhaoPianZL.MieHuoQi = xml.GetAttrib(number);
                g_CheckItem.picture.MieHuoQi.MieHuoQi = AnalyseData("MieHuoQi","MieHuoQi","ZhaoPian",xml,error_item);
                g_CheckItem.picture.MieHuoQi.YaLiBiao = AnalyseData("YaLiBiao","MieHuoQi","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("YingJiChui")) {
                zhaopian_item.erase("YingJiChui");
                ZhaoPianZL.YingJiChui = xml.GetAttrib(number);
                g_CheckItem.picture.YingJiChui.YingJiChui = AnalyseData("YingJiChui","YingJiChui","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("JiLuYi")) {
                zhaopian_item.erase("JiLuYi");
                ZhaoPianZL.JiLuYi = xml.GetAttrib(number);
                g_CheckItem.picture.JiLuYi.JiLuYi = AnalyseData("JiLuYi","JiLuYi","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JiLuYi.RenZheng = AnalyseData("RenZheng","JiLuYi","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JiLuYi.PingMu = AnalyseData("PingMu","JiLuYi","ZhaoPian",xml,error_item);
            }


            if (xml.FindElem("ZuoQianLun")) {
                zhaopian_item.erase("ZuoQianLun");
                ZhaoPianZL.ZuoQianLun = xml.GetAttrib(number);
                g_CheckItem.picture.ZuoQianLun.LunTai = AnalyseData("LunTai","ZuoQianLun","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("YouQianLun")) {
                zhaopian_item.erase("YouQianLun");
                ZhaoPianZL.YouQianLun = xml.GetAttrib(number);
                g_CheckItem.picture.YouQianLun.LunTai = AnalyseData("LunTai","YouQianLun","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("CheXiang")) {
                zhaopian_item.erase("CheXiang");
                ZhaoPianZL.CheXiang = xml.GetAttrib(number);
                g_CheckItem.picture.CheXiang.GaiZhuang = AnalyseData("GaiZhuang","CheXiang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheXiang.FengDing = AnalyseData("FengDing","CheXiang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheXiang.ZuoWei = AnalyseData("ZuoWei","CheXiang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheXiang.CheLiangLeiXing = AnalyseData("CheLiangLeiXing","CheXiang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheXiang.JiaoDu = AnalyseData("JiaoDu","CheXiang","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("CeHuaGongWei")) {
                zhaopian_item.erase("CeHuaGongWei");
                ZhaoPianZL.CeHuaGongWei = xml.GetAttrib(number);
                g_CheckItem.picture.CeHuaGongWei.ChePai = AnalyseData("ChePai","CeHuaGongWei","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("WaiKuoQianMian")) {
                zhaopian_item.erase("WaiKuoQianMian");
                ZhaoPianZL.WaiKuoQianMian = xml.GetAttrib(number);
                g_CheckItem.picture.WaiKuoQianMian.ChePai = AnalyseData("ChePai","WaiKuoQianMian","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("WaiKuoCeMian")) {
                zhaopian_item.erase("WaiKuoCeMian");
                ZhaoPianZL.WaiKuoCeMian = xml.GetAttrib(number);
                g_CheckItem.picture.WaiKuoCeMian.ChePai = AnalyseData("ChePai","WaiKuoCeMian","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("DaCheHaoPai")) {
                zhaopian_item.erase("DaCheHaoPai");
                ZhaoPianZL.DaCheHaoPai = xml.GetAttrib(number);
                g_CheckItem.picture.DaCheHaoPai.ChePai = AnalyseData("ChePai","DaCheHaoPai","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("WeiXiangNeiBu")) {
                zhaopian_item.erase("WeiXiangNeiBu");
                ZhaoPianZL.WeiXiangNeiBu = xml.GetAttrib(number);
                g_CheckItem.picture.WeiXiangNeiBu.GaiZhuang = AnalyseData("GaiZhuang","WeiXiangNeiBu","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("FuZhuZhiDong")) {
                zhaopian_item.erase("FuZhuZhiDong");
                ZhaoPianZL.FuZhuZhiDong = xml.GetAttrib(number);
                g_CheckItem.picture.FuZhuZhiDong.FuZhuZhiDong = AnalyseData("FuZhuZhiDong","FuZhuZhiDong","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("ABS")) {
                zhaopian_item.erase("ABS");
                ZhaoPianZL.ABS = xml.GetAttrib(number);
                g_CheckItem.picture.ABS.ABS = AnalyseData("ABS","ABS","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("CheLiangCeMian")) {   
                zhaopian_item.erase("CheLiangCeMian");
                ZhaoPianZL.CheLiangCeMian = xml.GetAttrib(number);
                g_CheckItem.picture.CheLiangCeMian.CheLiangCeMian = AnalyseData("CheLiangCeMian","CheLiangCeMian","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("CheLiangBeiMian")) {
                zhaopian_item.erase("CheLiangBeiMian");
                ZhaoPianZL.CheLiangBeiMian = xml.GetAttrib(number);
                g_CheckItem.picture.CheLiangBeiMian.CheLiangBeiMian = AnalyseData("CheLiangBeiMian","CheLiangBeiMian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheLiangBeiMian.ChePai = AnalyseData("ChePai","CheLiangBeiMian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheLiangBeiMian.CheBiao = AnalyseData("CheBiao","CheLiangBeiMian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheLiangBeiMian.SanJiaoJia = AnalyseData("SanJiaoJia","CheLiangBeiMian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheLiangBeiMian.XiaBuFangHu = AnalyseData("XiaBuFangHu","CheLiangBeiMian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheLiangBeiMian.WeiBuBiaoZhi = AnalyseData("WeiBuBiaoZhi","CheLiangBeiMian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheLiangBeiMian.CheShenFanGuangBiaoShi = AnalyseData("CheShenFanGuangBiaoShi","CheLiangBeiMian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheLiangBeiMian.PenTuHaoMa = AnalyseData("PenTuHaoMa","CheLiangBeiMian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheLiangBeiMian.WeiDeng = AnalyseData("WeiDeng", "CheLiangBeiMian", "ZhaoPian", xml, error_item);
            }

            if (xml.FindElem("HeDingZaiKe")) {
                zhaopian_item.erase("HeDingZaiKe");
                ZhaoPianZL.HeDingZaiKe = xml.GetAttrib(number);
                g_CheckItem.picture.HeDingZaiKe.HeDingZaiKe = AnalyseData("HeDingZaiKe","HeDingZaiKe","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("JianCeQuXianBaoGao")) {
                zhaopian_item.erase("JianCeQuXianBaoGao");
                ZhaoPianZL.JianCeQuXianBaoGao = xml.GetAttrib(number);
                g_CheckItem.picture.JianCeQuXianBaoGao.QuXianBaoGao = AnalyseData("QuXianBaoGao","JianCeQuXianBaoGao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianCeQuXianBaoGao.ChePai = AnalyseData("ChePai","JianCeQuXianBaoGao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianCeQuXianBaoGao.YinZhang = AnalyseData("YinZhang","JianCeQuXianBaoGao","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("CheJiaHaoUG")) {
                zhaopian_item.erase("CheJiaHaoUG");
                ZhaoPianZL.CheJiaHaoUG = xml.GetAttrib(number);
                g_CheckItem.picture.CheJiaHaoUG.CheJiaHao = AnalyseData("CheJiaHao","CheJiaHaoUG","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("CheLiangMingPai")) {
                zhaopian_item.erase("CheLiangMingPai");
                ZhaoPianZL.CheLiangMingPai = xml.GetAttrib(number);
                g_CheckItem.picture.CheLiangMingPai.CheJiaHao = AnalyseData("CheJiaHao","CheLiangMingPai","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheLiangMingPai.FaDongJiHao = AnalyseData("FaDongJiHao","CheLiangMingPai","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheLiangMingPai.FaDongJiPaiLiang = AnalyseData("FaDongJiPaiLiang","CheLiangMingPai","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheLiangMingPai.ZhiZaoNianYue = AnalyseData("ZhiZaoNianYue","CheLiangMingPai","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("HouPaiCheXiang")) {
                zhaopian_item.erase("HouPaiCheXiang");
                ZhaoPianZL.HouPaiCheXiang = xml.GetAttrib(number);
                g_CheckItem.picture.HouPaiCheXiang.AnQuanDai = AnalyseData("AnQuanDai","HouPaiCheXiang","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("HouPaiCheXiang2")) {
                zhaopian_item.erase("HouPaiCheXiang2");
                ZhaoPianZL.HouPaiCheXiang2 = xml.GetAttrib(number);
                g_CheckItem.picture.HouPaiCheXiang2.AnQuanDai = AnalyseData("AnQuanDai","HouPaiCheXiang2","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("WeiQiJianYan2")) {
                zhaopian_item.erase("WeiQiJianYan2");
                ZhaoPianZL.WeiQiJianYan2 = xml.GetAttrib(number);
                g_CheckItem.picture.WeiQiJianYan2.JieLun = AnalyseData("JieLun","WeiQiJianYan2","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan2.ChePai = AnalyseData("ChePai","WeiQiJianYan2","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan2.CheJiaHao = AnalyseData("CheJiaHao","WeiQiJianYan2","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan2.YinZhang = AnalyseData("YinZhang","WeiQiJianYan2","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan2.QianMing = AnalyseData("QianMing","WeiQiJianYan2","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan2.YinZhang_MA = AnalyseData("YinZhang_MA","WeiQiJianYan2","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan2.DianZiBaoGao = AnalyseData("DianZiBaoGao","WeiQiJianYan2","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan2.CaoZuoYuan = AnalyseData("CaoZuoYuan","WeiQiJianYan2","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan2.JiaShiYuan = AnalyseData("JiaShiYuan","WeiQiJianYan2","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan2.PiZhunRen = AnalyseData("PiZhunRen","WeiQiJianYan2","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan2.ShenHeYuan = AnalyseData("ShenHeYuan","WeiQiJianYan2","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan2.JianCeShiJian = AnalyseData("JianCeShiJian","WeiQiJianYan2","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan2.DianZiBiaoGe = AnalyseData("DianZiBiaoGe","WeiQiJianYan2","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan2.YouXiaoQi = AnalyseData("YouXiaoQi","WeiQiJianYan2","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan2.FaDongJiBianHao = AnalyseData("FaDongJiBianHao","WeiQiJianYan2","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("GaoZhiShu")) {
                zhaopian_item.erase("GaoZhiShu");
                ZhaoPianZL.GaoZhiShu = xml.GetAttrib(number);
                g_CheckItem.picture.GaoZhiShu.GaoZhiShu = AnalyseData("GaoZhiShu","GaoZhiShu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.GaoZhiShu.HongZhang = AnalyseData("HongZhang","GaoZhiShu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.GaoZhiShu.QianMing = AnalyseData("QianMing","GaoZhiShu","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("RongQueShouLi")) {
                zhaopian_item.erase("RongQueShouLi");
                ZhaoPianZL.RongQueShouLi = xml.GetAttrib(number);
                g_CheckItem.picture.RongQueShouLi.DuiGou = AnalyseData("DuiGou","RongQueShouLi","ZhaoPian",xml,error_item);
                g_CheckItem.picture.RongQueShouLi.QianMing = AnalyseData("QianMing","RongQueShouLi","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("QianChePaiTeXie")) {
                zhaopian_item.erase("QianChePaiTeXie");
                ZhaoPianZL.QianHaoPaiTeXie = xml.GetAttrib(number);
                g_CheckItem.picture.QianHaoPaiTeXie.chepai = AnalyseData("ChePai","QianChePaiTeXie","ZhaoPian",xml,error_item);
                g_CheckItem.picture.QianHaoPaiTeXie.luosi = AnalyseData("LuoSi","QianChePaiTeXie","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("HouChePaiTeXie")) {
                zhaopian_item.erase("HouChePaiTeXie");
                ZhaoPianZL.HouHaoPaiTeXie = xml.GetAttrib(number);
                g_CheckItem.picture.HouHaoPaiTeXie.chepai = AnalyseData("ChePai","HouChePaiTeXie","ZhaoPian",xml,error_item);
                g_CheckItem.picture.HouHaoPaiTeXie.luosi = AnalyseData("LuoSi","HouChePaiTeXie","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("QianLunZhaoPian")) {
                zhaopian_item.erase("QianLunZhaoPian");
                ZhaoPianZL.QianLunZhaoPian = xml.GetAttrib(number);
                g_CheckItem.picture.QianLunZhaoPian.b_chepai = AnalyseData("ChePai", "QianLunZhaoPian", "ZhaoPian", xml, error_item);
            }
            if (xml.FindElem("HouLunZhaoPian")) {
                zhaopian_item.erase("HouLunZhaoPian");
                ZhaoPianZL.HouLunZhaoPian = xml.GetAttrib(number);
                g_CheckItem.picture.HouLunZhaoPian.b_chepai = AnalyseData("ChePai", "HouLunZhaoPian", "ZhaoPian", xml, error_item);
            }
            xml.OutOfElem();
        }

        if (xml.FindElem("ShiPin")) {
            first_item.erase("ShiPin");
            xml.IntoElem();

            if (xml.FindElem("ZuoQianFang")) {
                shipin_item.erase("ZuoQianFang");
                g_CheckItem.video.ZuoQianFang.ChePai = AnalyseData("ChePai","ZuoQianFang","ShiPin",xml,error_item);

            }

            if (xml.FindElem("YouHouFang")) {
                shipin_item.erase("YouHouFang");
                g_CheckItem.video.YouHouFang.ChePai = AnalyseData("ChePai","YouHouFang","ShiPin",xml,error_item);

            }

            if (xml.FindElem("YiZhouZhiDong")) {
                shipin_item.erase("YiZhouZhiDong");

                g_CheckItem.video.YiZhouZhiDong.ChePai = AnalyseData("ChePai","YiZhouZhiDong","ShiPin",xml,error_item);
                g_CheckItem.video.YiZhouZhiDong.QianLun = AnalyseData("QianLun","YiZhouZhiDong","ShiPin",xml,error_item);
                g_CheckItem.video.YiZhouZhiDong.WeiDeng = AnalyseData("WeiDeng","YiZhouZhiDong","ShiPin",xml,error_item);
                g_CheckItem.video.YiZhouZhiDong.Ren = AnalyseData("Ren","YiZhouZhiDong","ShiPin",xml,error_item);

            }

            if (xml.FindElem("ErZhouZhiDong")) {
                shipin_item.erase("ErZhouZhiDong");
                g_CheckItem.video.ErZhouZhiDong.ChePai = AnalyseData("ChePai","ErZhouZhiDong","ShiPin",xml,error_item);
                g_CheckItem.video.ErZhouZhiDong.HouLun = AnalyseData("HouLun","ErZhouZhiDong","ShiPin",xml,error_item);
                g_CheckItem.video.ErZhouZhiDong.WeiDeng = AnalyseData("WeiDeng","ErZhouZhiDong","ShiPin",xml,error_item);
                g_CheckItem.video.ErZhouZhiDong.Ren = AnalyseData("Ren","ErZhouZhiDong","ShiPin",xml,error_item);

            }

            if (xml.FindElem("ZuoDengGuang")) {
                shipin_item.erase("ZuoDengGuang");
                g_CheckItem.video.ZuoDengGuang.ChePai = AnalyseData("ChePai","ZuoDengGuang","ShiPin",xml,error_item);
                g_CheckItem.video.ZuoDengGuang.QianDaDeng = AnalyseData("QianDaDeng","ZuoDengGuang","ShiPin",xml,error_item);
                g_CheckItem.video.ZuoDengGuang.Ren = AnalyseData("Ren","ZuoDengGuang","ShiPin",xml,error_item);
                g_CheckItem.video.ZuoDengGuang.CeShiYi = AnalyseData("CeShiYi","ZuoDengGuang","ShiPin",xml,error_item);

            }

            if (xml.FindElem("YouDengGuang")) {
                shipin_item.erase("YouDengGuang");

                g_CheckItem.video.YouDengGuang.ChePai = AnalyseData("ChePai","YouDengGuang","ShiPin",xml,error_item);
                g_CheckItem.video.YouDengGuang.QianDaDeng = AnalyseData("QianDaDeng","YouDengGuang","ShiPin",xml,error_item);
                g_CheckItem.video.YouDengGuang.Ren = AnalyseData("Ren","YouDengGuang","ShiPin",xml,error_item);
                g_CheckItem.video.YouDengGuang.CeShiYi = AnalyseData("CeShiYi","YouDengGuang","ShiPin",xml,error_item);

            }

            if (xml.FindElem("DongTaiGongWei_1")) {
                shipin_item.erase("DongTaiGongWei_1");
                g_CheckItem.video.DongTaiGongWei_1.ChePai = AnalyseData("ChePai","DongTaiGongWei_1","ShiPin",xml,error_item);
                g_CheckItem.video.DongTaiGongWei_1.WeiYi = AnalyseData("WeiYi","DongTaiGongWei_1","ShiPin",xml,error_item);

            }

            if (xml.FindElem("DongTaiGongWei_2")) {
                shipin_item.erase("DongTaiGongWei_2");
                g_CheckItem.video.DongTaiGongWei_2.ChePai = AnalyseData("ChePai","DongTaiGongWei_2","ShiPin",xml,error_item);
                g_CheckItem.video.DongTaiGongWei_2.WeiYi = AnalyseData("WeiYi","DongTaiGongWei_2","ShiPin",xml,error_item);

            }

            if (xml.FindElem("DiPanGongWei")) {
                shipin_item.erase("DiPanGongWei");
                g_CheckItem.video.DiPanGongWei.Ren = AnalyseData("Ren","DiPanGongWei","ShiPin",xml,error_item);

            }

            if (xml.FindElem("ZhuCheZhiDong")) {
                shipin_item.erase("ZhuCheZhiDong");
                g_CheckItem.video.ZhuCheZhiDong.ChePai = AnalyseData("ChePai","ZhuCheZhiDong","ShiPin",xml,error_item);
                g_CheckItem.video.ZhuCheZhiDong.HouLun = AnalyseData("HouLun","ZhuCheZhiDong","ShiPin",xml,error_item);
                g_CheckItem.video.ZhuCheZhiDong.TaiQi = AnalyseData("TaiQi","ZhuCheZhiDong","ShiPin",xml,error_item);
                g_CheckItem.video.ZhuCheZhiDong.Ren = AnalyseData("Ren","ZhuCheZhiDong","ShiPin",xml,error_item);
                g_CheckItem.video.ZhuCheZhiDong.WeiDeng = AnalyseData("WeiDeng","ZhuCheZhiDong","ShiPin",xml,error_item);

            }

            xml.OutOfElem();
        }

        if (xml.FindElem("SuzhouVideo")){
            first_item.erase("SuzhouVideo");
            xml.IntoElem();
            if (xml.FindElem("SpaoConnect")) {
                suzhouvideo_item.erase("SpaoConnect");
                g_CheckItem.dlvideo.soapflag = AnalyseData("soapflag","SpaoConnect","SuzhouVideo",xml,error_item);
            }
            if (xml.FindElem("Download")) {
                suzhouvideo_item.erase("Download");
                g_CheckItem.dlvideo.dlflag = AnalyseData("dlflag","Download","SuzhouVideo",xml,error_item);
            }
            if(xml.FindElem("YiChunDownload")){
                if(xml.FindChildElem("ShiZhongShenHe"))
                {
                    if(xml.GetChildData() == "on")
                    {
                        g_CheckItem.dlvideo.shizhongshenheflag = true;
                    }
                    else
                    {
                        g_CheckItem.dlvideo.shizhongshenheflag = false;
                    }
                }
            }

            if (xml.FindElem("V_CheLiangZuoQianFang")) {
                suzhouvideo_item.erase("V_CheLiangZuoQianFang");
                g_CheckItem.video.ZuoQianFang.ChePai = AnalyseData("ChePai","V_CheLiangZuoQianFang","SuzhouVideo",xml,error_item);

            }
            if (xml.FindElem("V_CheLiangYouHouFang")) {
                suzhouvideo_item.erase("V_CheLiangYouHouFang");
                g_CheckItem.video.YouHouFang.ChePai = AnalyseData("ChePai","V_CheLiangYouHouFang","SuzhouVideo",xml,error_item);

            }
            if (xml.FindElem("V_YiZhouZhiDong")) {
                suzhouvideo_item.erase("V_YiZhouZhiDong");
                g_CheckItem.video.YiZhouZhiDong.ChePai = AnalyseData("ChePai","V_YiZhouZhiDong","SuzhouVideo",xml,error_item);
                g_CheckItem.video.YiZhouZhiDong.QianLun = AnalyseData("QianLun","V_YiZhouZhiDong","SuzhouVideo",xml,error_item);
                g_CheckItem.video.YiZhouZhiDong.WeiDeng = AnalyseData("WeiDeng","V_YiZhouZhiDong","SuzhouVideo",xml,error_item);
                g_CheckItem.video.YiZhouZhiDong.Ren = AnalyseData("Ren","V_YiZhouZhiDong","SuzhouVideo",xml,error_item);

            }
            if (xml.FindElem("V_ErZhouZhiDong")) {
                suzhouvideo_item.erase("V_ErZhouZhiDong");
                g_CheckItem.video.ErZhouZhiDong.ChePai = AnalyseData("ChePai","V_ErZhouZhiDong","SuzhouVideo",xml,error_item);
                g_CheckItem.video.ErZhouZhiDong.HouLun = AnalyseData("HouLun","V_ErZhouZhiDong","SuzhouVideo",xml,error_item);
                g_CheckItem.video.ErZhouZhiDong.WeiDeng = AnalyseData("WeiDeng","V_ErZhouZhiDong","SuzhouVideo",xml,error_item);
                g_CheckItem.video.ErZhouZhiDong.Ren = AnalyseData("Ren","V_ErZhouZhiDong","SuzhouVideo",xml,error_item);
            }
            if (xml.FindElem("V_ZuoDengGuang")) {
                suzhouvideo_item.erase("V_ZuoDengGuang");
                g_CheckItem.video.ZuoDengGuang.ChePai = AnalyseData("ChePai","V_ZuoDengGuang","SuzhouVideo",xml,error_item);
                g_CheckItem.video.ZuoDengGuang.CeShiYi = AnalyseData("CeShiYi","V_ZuoDengGuang","SuzhouVideo",xml,error_item);
                g_CheckItem.video.ZuoDengGuang.QianDaDeng = AnalyseData("QianDaDeng","V_ZuoDengGuang","SuzhouVideo",xml,error_item);
                g_CheckItem.video.ZuoDengGuang.Ren = AnalyseData("Ren","V_ZuoDengGuang","SuzhouVideo",xml,error_item);

            }
            if (xml.FindElem("V_YouDengGuang")) {
                suzhouvideo_item.erase("V_YouDengGuang");
                g_CheckItem.video.YouDengGuang.ChePai = AnalyseData("ChePai","V_YouDengGuang","SuzhouVideo",xml,error_item);
                g_CheckItem.video.YouDengGuang.CeShiYi = AnalyseData("CeShiYi","V_YouDengGuang","SuzhouVideo",xml,error_item);
                g_CheckItem.video.YouDengGuang.QianDaDeng = AnalyseData("QianDaDeng","V_YouDengGuang","SuzhouVideo",xml,error_item);
                g_CheckItem.video.YouDengGuang.Ren = AnalyseData("Ren","V_YouDengGuang","SuzhouVideo",xml,error_item);

            }
            if (xml.FindElem("V_DiPan")) {
                suzhouvideo_item.erase("V_DiPan");
                g_CheckItem.video.DiPanGongWei.Ren = AnalyseData("Ren","V_DiPan","SuzhouVideo",xml,error_item);

            }
            if (xml.FindElem("V_ZhuCheZhiDong")) {
                suzhouvideo_item.erase("V_ZhuCheZhiDong");
                g_CheckItem.video.ZhuCheZhiDong.ChePai = AnalyseData("ChePai","V_ZhuCheZhiDong","SuzhouVideo",xml,error_item);
                g_CheckItem.video.ZhuCheZhiDong.HouLun = AnalyseData("HouLun","V_ZhuCheZhiDong","SuzhouVideo",xml,error_item);
                g_CheckItem.video.ZhuCheZhiDong.TaiQi = AnalyseData("TaiQi","V_ZhuCheZhiDong","SuzhouVideo",xml,error_item);
                g_CheckItem.video.ZhuCheZhiDong.Ren = AnalyseData("Ren","V_ZhuCheZhiDong","SuzhouVideo",xml,error_item);
                g_CheckItem.video.ZhuCheZhiDong.WeiDeng = AnalyseData("WeiDeng","V_ZhuCheZhiDong","SuzhouVideo",xml,error_item);

            }
        }
        xml.OutOfElem();   
    }
    //判断各级字段是否存在，如一级字段不存在，则不提示此二级字段
    std::set< std::string > ::iterator it;
    //unsigned int size = first_item.size();
    if( first_item.size() || zhaopian_item.size() || shipin_item.size() || suzhouvideo_item.size() || error_item.size() ){
        DATA_PRINT(LEVEL_ERROR, "读取配置文件check_item.xml失败！ \n");
        if( first_item.size() ){
            for(it = first_item.begin();it != first_item.end();++it){
                DATA_PRINT(LEVEL_ERROR, "原因: %s 未配置\n", (*it).c_str());
            }
        }
        if( zhaopian_item.size() && (first_item.find("ZhaoPian") != first_item.end() ) ? false : true){
            for(it = zhaopian_item.begin();it != zhaopian_item.end();++it){
                DATA_PRINT(LEVEL_ERROR, "原因: ZhaoPian----->%s未配置 \n", (*it).c_str());
            }
        }
        if( shipin_item.size() && (first_item.find("ShiPin") != first_item.end() ) ? false : true ){
            for(it = shipin_item.begin();it != shipin_item.end();++it){
                DATA_PRINT(LEVEL_ERROR, "原因: ShiPin----->%s未配置 \n", (*it).c_str());
            }
        }
        if( suzhouvideo_item.size() && (first_item.find("SuzhouVideo") != first_item.end() ) ? false : true){
            for(it = suzhouvideo_item.begin();it != suzhouvideo_item.end();++it){
                DATA_PRINT(LEVEL_ERROR, "原因: SuzhouVideo----->%s未配置 \n", (*it).c_str());
            }
        }
        if( error_item.size() ){
            for( unsigned int i = 0; i < error_item.size(); i++ ){
                DATA_PRINT(LEVEL_ERROR, "原因: %s", error_item[i].c_str());
            }
        }
        exit(EXIT_FAILURE);
    }

}

void getCheckItemData(std::string strPath)
{
    std::string on = "on";
    std::string number = "number";
    CMarkup xml;
    std::vector<std::string> level;
    //错误信息vector
    std::vector< std::string > error_item;
    //check_item中第一个节点字段
    std::set< std::string > first_item = {

        "City","GongZuoShiJian","JianYanLeiBie",
        "ShiYongXingZhi","CheLiangZhongLei","JianYanJiGou",
        "ZhaoPian","ShiPin","SuzhouVideo"
    };

    //照片审核二级字段
    std::set< std::string > zhaopian_item = {
        "ZuoQianFang","ZuoFang","YouHouFang",
        "CheJiaHao","AnQuanDai",
        "XingShiZheng","XingShiZhengBeiMian",
        "JiaoQiangXian","JianYanBaoGao","JianYanBaoGao_YiQi",
        "JianYanBaoGao_RenGong","WeiTuoShu",
        "ShenQingBiao","WeiQiJianYan","ZuoDengGuang",
        "YouDengGuang","YiZhouZhiDong","ErZhouZhiDong",
        "ZhuCheZhiDong","DiPanDongTaiKaiShi","DiPanDongTaiJieShu",
        "DiPanBuJian","ChaYanJiLu","QianHaoPai",
        "HouHaoPai","ShenFenZheng","ShenFenZhengBeiMian",
        "JianYanBiaoBeiMian","WanShuiZhengMing","WeiTuoTongZhiShu",
        "MieHuoQi","YingJiChui","JiLuYi",
        "ZuoQianLun","YouQianLun","CheXiang",
        "CeHuaGongWei","WaiKuoQianMian","WaiKuoCeMian",
        "DaCheHaoPai","WeiXiangNeiBu","FuZhuZhiDong",
        "ABS","CheLiangCeMian","CheLiangBeiMian",
        "HeDingZaiKe","JianCeQuXianBaoGao","CheJiaHaoUG",
        "GaoZhiShu","RongQueShouLi"

    };
    //视频审核二级字段
    std::set< std::string > shipin_item = {
        "ZuoQianFang","YouHouFang","YiZhouZhiDong",
        "ErZhouZhiDong","ZuoDengGuang","YouDengGuang",
        "DongTaiGongWei_1","DongTaiGongWei_2","DiPanGongWei",
        "ZhuCheZhiDong_GunTong","ZhuCheZhiDong_PingBan"
    };
    //苏州视频审核二级字段
    std::set< std::string > suzhouvideo_item = {
        "SpaoConnect","Download","V_CheLiangZuoQianFang",
        "V_CheLiangYouHouFang","V_YiZhouZhiDong","V_ErZhouZhiDong",
        "V_PingBanZhiDong","V_ZuoDengGuang","V_YouDengGuang",
        "V_DiPan","V_GunLunZhuChe","V_PingBanZhuChe"
    };
    if (!xml.Load(strPath)) {
        DATA_PRINT(LEVEL_ERROR, "读取配置文件check_item.xml失败！ \n");
        DATA_PRINT(LEVEL_ERROR, "原因: %s \n", xml.GetError().data());
        exit(EXIT_FAILURE);
    }

//    checkElement(xml, level, "Items");
//    xml.IntoElem();
//    level.push_back("Items");

//    checkElement(xml, level, "City");
//    g_CheckItem.City = xml.GetData();


//To be continue......



    if (xml.FindElem("Items")) {
        xml.IntoElem();

        if (xml.FindElem("City")) {
            first_item.erase("City");
            g_CheckItem.City = xml.GetData();
            if( "8100" < g_CheckItem.City || g_CheckItem.City < "1100" ){
                error_item.push_back("城市代码配置错误 \n");
            }
        }

        if (xml.FindElem("GongZuoShiJian")) {
            first_item.erase("GongZuoShiJian");
            if (xml.FindChildElem("KaiShi")) {
                g_CheckItem.ShiJian.KaiShi = atoi(xml.GetChildData().c_str());
                if( g_CheckItem.ShiJian.KaiShi > 23 || g_CheckItem.ShiJian.KaiShi < 0){
                    error_item.push_back("开始时间配置错误\n");
                }
            }

            if (xml.FindChildElem("JieShu")) {
                g_CheckItem.ShiJian.JieShu = atoi(xml.GetChildData().c_str());
                if( g_CheckItem.ShiJian.JieShu > 24 || g_CheckItem.ShiJian.JieShu < 1 ){
                    error_item.push_back("结束时间配置错误\n");
                }
            }
        }

        if (xml.FindElem("JianYanLeiBie")) {
            first_item.erase("JianYanLeiBie");
            while (xml.FindChildElem("LeiBie")) {
                std::string tmp = xml.GetChildData();
                if( tmp < "01" || tmp > "04" ){
                    error_item.push_back("检验类别配置错误\n");
                }
                g_CheckItem.JianYanLeiBie.push_back(tmp);
            }
        }

        if (xml.FindElem("ShiYongXingZhi")) {
            first_item.erase("ShiYongXingZhi");
            while (xml.FindChildElem("XingZhi")) {
                std::string tmp= xml.GetChildData();
                 if( tmp.length() == 1){
                    if( tmp < "A" || tmp > "Z" ){
                        error_item.push_back("使用性质配置错误\n");
                    }

                }else if( tmp.length() > 1 ){
                    error_item.push_back("使用性质配置错误\n");
                }
                g_CheckItem.ShiYongXingZhi.push_back(tmp);
            }
        }

        if (xml.FindElem("CheLiangZhongLei")) {
            first_item.erase("CheLiangZhongLei");
            std::string clzl = xml.GetData();
            vector<std::string> mid_check;
            vector<std::string> qczl_check;
            int ipose = 0;
            int inums = 0;
//            int count = 0;
            std::string strTemp = clzl;
            std::string strRight;
            while (ipose != -1)
            {
                ipose = strTemp.find(",");
                if (ipose == -1)
                {
                    break;
                }
                strRight = strTemp.substr(ipose + 1, strTemp.size());
                strTemp = strRight;
                inums++;
            }
            if (inums == 0)
            {
                if(!clzl.empty())
                {
//                    count = 1;
                    qczl_check.push_back((clzl));
                }
            }
            else
            {
//                count = inums + 1;
//                std::string* pStrSplit;
//                pStrSplit = new std::string[count];
                strTemp = clzl;
                std::string strLeft;
                for (int i = 0; i < inums; i++)
                {
                    ipose = strTemp.find(",");
                    strLeft = strTemp.substr(0,ipose);
                    strRight = strTemp.substr(ipose + 1, strTemp.size());
                    strTemp = strRight;
                    if( strLeft.length() != 3 ){
                        error_item.push_back("车辆种类配置错误\n");
                    }
                    else{
                        if( strLeft[0] > 'Z' || strLeft[0] < 'A'){
                            error_item.push_back("车辆种类配置错误\n");
                        }else if( strLeft[1] < '0' || strLeft[1] > '9' || strLeft[2] < '0' || strLeft[2] > '9' ){
                            error_item.push_back("车辆种类配置错误\n");
                        }

                    }
                    mid_check.push_back(strLeft);
                }
                mid_check.push_back(strTemp);
                qczl_check = mid_check;
            }

            for (unsigned int i = 0; i < qczl_check.size(); i++) {
                std::string tmp = qczl_check[i];
                g_CheckItem.CheLiangZhongLei.push_back(std::string(tmp));
            }
        }

        if (xml.FindElem("JianYanJiGou")) {
            first_item.erase("JianYanJiGou");
            while (xml.FindChildElem("BianHao")) {
                t_JianYanJiGou JYJG;
                JYJG.bh = xml.GetChildData();
                JYJG.assignment_IP = xml.GetChildAttrib("assignment_IP");
                g_CheckItem.JianYanJiGou.push_back(JYJG);
            }
        }

        if (xml.FindElem("ZhaoPian")) {
            first_item.erase("ZhaoPian");

            xml.IntoElem();

            if (xml.FindElem("ZuoQianFang")) {
                zhaopian_item.erase("ZuoQianFang");
                ZhaoPianZL.ZuoQianFang = xml.GetAttrib(number);
                g_CheckItem.picture.ZuoQianFang.ChePai = AnalyseData("ChePai","ZuoQianFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZuoQianFang.CheBiao = AnalyseData("CheBiao","ZuoQianFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZuoQianFang.SanJiaoJia = AnalyseData("SanJiaoJia","ZuoQianFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZuoQianFang.CheShenFanGuangBiaoShi = AnalyseData("CheShenFanGuangBiaoShi","ZuoQianFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZuoQianFang.ZuoCePenTu = AnalyseData("ZuoCePenTu","ZuoQianFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZuoQianFang.ZuoCeFangHu = AnalyseData("ZuoCeFangHu","ZuoQianFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZuoQianFang.GaiZhuang = AnalyseData("GaiZhuang","ZuoQianFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZuoQianFang.ShuiYinRiQi = AnalyseData("ShuiYinRiQi","ZuoQianFang","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("ZuoFang")) {
                zhaopian_item.erase("ZuoFang");
                ZhaoPianZL.ZuoFang = xml.GetAttrib(number);
                g_CheckItem.picture.ZuoFang.ChePai = AnalyseData("ChePai","ZuoFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZuoFang.GaiZhuang = AnalyseData("GaiZhuang","ZuoFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZuoFang.GuangGao = AnalyseData("GuangGao","ZuoFang","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("YouHouFang")) {
                zhaopian_item.erase("YouHouFang");
                ZhaoPianZL.YouHouFang = xml.GetAttrib(number);
                g_CheckItem.picture.YouHouFang.ChePai = AnalyseData("ChePai","YouHouFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouHouFang.CheBiao = AnalyseData("CheBiao","YouHouFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouHouFang.SanJiaoJia = AnalyseData("SanJiaoJia","YouHouFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouHouFang.HouBuCheShenFanGuangBiaoShi = AnalyseData("HouBuCheShenFanGuangBiaoShi","YouHouFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouHouFang.YouCeCheShenFanGuangBiaoShi = AnalyseData("YouCeCheShenFanGuangBiaoShi","YouHouFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouHouFang.LanBanGaoDu = AnalyseData("LanBanGaoDu","YouHouFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouHouFang.CheLiangWeiBuBiaoZhiBan = AnalyseData("CheLiangWeiBuBiaoZhiBan","YouHouFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouHouFang.HouXiaFangHu = AnalyseData("HouXiaFangHu","YouHouFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouHouFang.YouCeFangHu = AnalyseData("YouCeFangHu","YouHouFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouHouFang.HouBuPenTu = AnalyseData("HouBuPenTu","YouHouFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouHouFang.GaiZhuang = AnalyseData("GaiZhuang","YouHouFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouHouFang.ShuiYinRiQi = AnalyseData("ShuiYinRiQi","YouHouFang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouHouFang.PaiQiKong = AnalyseData("PaiQiKong","YouHouFang","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("CheJiaHao")) {
                zhaopian_item.erase("CheJiaHao");
                ZhaoPianZL.CheJiaHao = xml.GetAttrib(number);
                g_CheckItem.picture.CheJiaHao.CheJiaHao = AnalyseData("CheJiaHao","CheJiaHao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheJiaHao.ShuiYinRiQi = AnalyseData("ShuiYinRiQi","CheJiaHao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheJiaHao.TaYinMo = AnalyseData("TaYinMo","CheJiaHao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheJiaHao.BaoDing_FTP = AnalyseData("BaoDing_FTP","CheJiaHao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheJiaHao.JiLuBiaoZiMo = AnalyseData("JiLuBiaoZiMo","CheJiaHao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheJiaHao.YuanJing = AnalyseData("YuanJing","CheJiaHao","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("AnQuanDai")) {
                zhaopian_item.erase("AnQuanDai");
                ZhaoPianZL.AnQuanDai = xml.GetAttrib(number);
                g_CheckItem.picture.AnQuanDai.AnQuanDai = AnalyseData("AnQuanDai","AnQuanDai","ZhaoPian",xml,error_item);
                g_CheckItem.picture.AnQuanDai.ShuiYinRiQi = AnalyseData("ShuiYinRiQi","AnQuanDai","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("XingShiZheng")) {
                zhaopian_item.erase("XingShiZheng");
                ZhaoPianZL.XingShiZheng = xml.GetAttrib(number);
                g_CheckItem.picture.XingShiZheng.CheJiaHao = AnalyseData("CheJiaHao","XingShiZheng","ZhaoPian",xml,error_item);
                g_CheckItem.picture.XingShiZheng.ChePai = AnalyseData("ChePai","XingShiZheng","ZhaoPian",xml,error_item);
                g_CheckItem.picture.XingShiZheng.BianHao = AnalyseData("BianHao","XingShiZheng","ZhaoPian",xml,error_item);
                g_CheckItem.picture.XingShiZheng.FaZhengRiQi = AnalyseData("FaZhengRiQi","XingShiZheng","ZhaoPian",xml,error_item);
                g_CheckItem.picture.XingShiZheng.BeiMian = AnalyseData("BeiMian","XingShiZheng","ZhaoPian",xml,error_item);
                g_CheckItem.picture.XingShiZheng.ShenFenZheng = AnalyseData("ShenFenZheng","XingShiZheng","ZhaoPian",xml,error_item);
                g_CheckItem.picture.XingShiZheng.TianJin = AnalyseData("TianJin","XingShiZheng","ZhaoPian",xml,error_item);
                g_CheckItem.picture.XingShiZheng.CheLiang = AnalyseData("CheLiang","XingShiZheng","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("XingShiZhengBeiMian")) {
                zhaopian_item.erase("XingShiZhengBeiMian");
                ZhaoPianZL.XingShiZhengBeiMian = xml.GetAttrib(number);
                g_CheckItem.picture.XingShiZhengBeiMian.ZhuYe = AnalyseData("ZhuYe","XingShiZhengBeiMian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.XingShiZhengBeiMian.FuYe = AnalyseData("FuYe","XingShiZhengBeiMian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.XingShiZhengBeiMian.ShenFenZheng = AnalyseData("ShenFenZheng","XingShiZhengBeiMian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.XingShiZhengBeiMian.YouXiaoQi = AnalyseData("YouXiaoQi","XingShiZhengBeiMian","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("JiaoQiangXian")) {
                zhaopian_item.erase("JiaoQiangXian");
                ZhaoPianZL.JiaoQiangXian = xml.GetAttrib(number);
                g_CheckItem.picture.JiaoQiangXian.FuBen = AnalyseData("FuBen","JiaoQiangXian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JiaoQiangXian.ChePai = AnalyseData("ChePai","JiaoQiangXian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JiaoQiangXian.ChaoJian = AnalyseData("ChaoJian","JiaoQiangXian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JiaoQiangXian.CheJiaHao = AnalyseData("CheJiaHao","JiaoQiangXian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JiaoQiangXian.YouXiaoQi = AnalyseData("YouXiaoQi","JiaoQiangXian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JiaoQiangXian.GongZhang = AnalyseData("GongZhang","JiaoQiangXian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JiaoQiangXian.CheChuanShui = AnalyseData("CheChuanShui","JiaoQiangXian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JiaoQiangXian.DianZiBaoDan = AnalyseData("DianZiBaoDan","JiaoQiangXian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JiaoQiangXian.FaDongJiHao = AnalyseData("FaDongJiHao","JiaoQiangXian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JiaoQiangXian.ShenZhenDianZiBaoDan = AnalyseData("ShenZhenDianZiBaoDan","JiaoQiangXian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JiaoQiangXian.SuZhouYinZhang = AnalyseData("SuZhouYinZhang","JiaoQiangXian","ZhaoPian",xml,error_item);

            }

            if (xml.FindElem("JianYanBaoGao")) {
                zhaopian_item.erase("JianYanBaoGao");
                ZhaoPianZL.JianYanBaoGao = xml.GetAttrib(number);
                g_CheckItem.picture.JianYanBaoGao.CheJiaHao = AnalyseData("CheJiaHao","JianYanBaoGao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao.ChePai = AnalyseData("ChePai","JianYanBaoGao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao.QianMing = AnalyseData("QianMing","JianYanBaoGao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao.YinZhang = AnalyseData("YinZhang","JianYanBaoGao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao.JieLun = AnalyseData("JieLun","JianYanBaoGao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao.ShuJuXiang = AnalyseData("ShuJuXiang","JianYanBaoGao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao.YinZhang_MA = AnalyseData("YinZhang_MA","JianYanBaoGao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao.QueRenZhang = AnalyseData("QueRenZhang","JianYanBaoGao","ZhaoPian",xml,error_item);
                // ++{{ xeast 2018-06-15 for nan ning
                g_CheckItem.picture.JianYanBaoGao.HaoPaiZhongLei = AnalyseData("HaoPaiZhongLei","JianYanBaoGao","ZhaoPian",xml,error_item);
                // }}
            }

            // ++{{ xeast 2018-06-23 for ning bo
            if (xml.FindElem("JianYanBaoGao_YiQi")) {
                zhaopian_item.erase("JianYanBaoGao_YiQi");
                ZhaoPianZL.JianYanBaoGao_YiQi = xml.GetAttrib(number);
                g_CheckItem.picture.JianYanBaoGao_YiQi.YiQi = AnalyseData("YiQi","JianYanBaoGao_YiQi","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao_YiQi.HongZhang = AnalyseData("HongZhang","JianYanBaoGao_YiQi","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao_YiQi.JieLun = AnalyseData("JieLun","JianYanBaoGao_YiQi","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao_YiQi.ChePai = AnalyseData("ChePai","JianYanBaoGao_YiQi","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao_YiQi.CheJiaHao = AnalyseData("CheJiaHao","JianYanBaoGao_YiQi","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao_YiQi.QianMing = AnalyseData("QianMing","JianYanBaoGao_YiQi","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao_YiQi.YinZhang_MA = AnalyseData("YinZhang_MA","JianYanBaoGao_YiQi","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("JianYanBaoGao_RenGong")) {
                zhaopian_item.erase("JianYanBaoGao_RenGong");
                ZhaoPianZL.JianYanBaoGao_RenGong = xml.GetAttrib(number);
                g_CheckItem.picture.JianYanBaoGao_RenGong.ChePai = AnalyseData("ChePai","JianYanBaoGao_RenGong","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao_RenGong.ChaYanJieLun = AnalyseData("ChaYanJieLun","JianYanBaoGao_RenGong","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao_RenGong.DiPanQianZi = AnalyseData("DiPanQianZi","JianYanBaoGao_RenGong","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao_RenGong.WaiGuanQianZi = AnalyseData("WaiGuanQianZi","JianYanBaoGao_RenGong","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBaoGao_RenGong.YinCheQianZi = AnalyseData("YinCheQianZi","JianYanBaoGao_RenGong","ZhaoPian",xml,error_item);
             }

            if (xml.FindElem("WeiTuoShu")) {
                zhaopian_item.erase("WeiTuoShu");
                ZhaoPianZL.WeiTuoShu = xml.GetAttrib(number);
                g_CheckItem.picture.WeiTuoShu.WeiTuoShu = AnalyseData("WeiTuoShu","WeiTuoShu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiTuoShu.HongZhang = AnalyseData("HongZhang","WeiTuoShu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiTuoShu.ShenFenZheng = AnalyseData("ShenFenZheng","WeiTuoShu","ZhaoPian",xml,error_item);
            }
            // }}

            if (xml.FindElem("ShenQingBiao")) {
                zhaopian_item.erase("ShenQingBiao");
                ZhaoPianZL.ShenQingBiao = xml.GetAttrib(number);
                g_CheckItem.picture.ShenQingBiao.ShouJi_BenRen = AnalyseData("ShouJi_BenRen","ShenQingBiao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ShenQingBiao.ShouJi_DaiLi = AnalyseData("ShouJi_DaiLi","ShenQingBiao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ShenQingBiao.ChePai = AnalyseData("ChePai","ShenQingBiao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ShenQingBiao.is_CheLiangType = AnalyseData("is_CheLiangType","ShenQingBiao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ShenQingBiao.is_YouBian = AnalyseData("is_YouBian","ShenQingBiao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ShenQingBiao.is_DiZhi = AnalyseData("is_DiZhi","ShenQingBiao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ShenQingBiao.CheJiaHao = AnalyseData("CheJiaHao","ShenQingBiao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ShenQingBiao.QianMing = AnalyseData("QianMing","ShenQingBiao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ShenQingBiao.YinZhang = AnalyseData("YinZhang","ShenQingBiao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ShenQingBiao.XingMing = AnalyseData("XingMing","ShenQingBiao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ShenQingBiao.JianYanHeGeBiaoZhi = AnalyseData("JianYanHeGeBiaoZhi","ShenQingBiao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ShenQingBiao.HaoPaiZhongLei = AnalyseData("HaoPaiZhongLei","ShenQingBiao","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("WeiQiJianYan")) {
                zhaopian_item.erase("WeiQiJianYan");
                ZhaoPianZL.WeiQiJianYan = xml.GetAttrib(number);
                g_CheckItem.picture.WeiQiJianYan.JieLun = AnalyseData("JieLun","WeiQiJianYan","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan.ChePai = AnalyseData("ChePai","WeiQiJianYan","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan.CheJiaHao = AnalyseData("CheJiaHao","WeiQiJianYan","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan.YinZhang = AnalyseData("YinZhang","WeiQiJianYan","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan.QianMing = AnalyseData("QianMing","WeiQiJianYan","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan.YinZhang_MA = AnalyseData("YinZhang_MA","WeiQiJianYan","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan.DianZiBaoGao = AnalyseData("DianZiBaoGao","WeiQiJianYan","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan.CaoZuoYuan = AnalyseData("CaoZuoYuan","WeiQiJianYan","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan.JiaShiYuan = AnalyseData("JiaShiYuan","WeiQiJianYan","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan.PiZhunRen = AnalyseData("PiZhunRen","WeiQiJianYan","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan.ShenHeYuan = AnalyseData("ShenHeYuan","WeiQiJianYan","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan.JianCeShiJian = AnalyseData("JianCeShiJian","WeiQiJianYan","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan.DianZiBiaoGe = AnalyseData("DianZiBiaoGe","WeiQiJianYan","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan.YouXiaoQi = AnalyseData("YouXiaoQi","WeiQiJianYan","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan.FaDongJiBianHao = AnalyseData("FaDongJiBianHao","WeiQiJianYan","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("ZuoDengGuang")) {
                zhaopian_item.erase("ZuoDengGuang");
                ZhaoPianZL.ZuoDengGuang = xml.GetAttrib(number);
                g_CheckItem.picture.ZuoDengGuang.ZuoQianDeng = AnalyseData("ZuoQianDeng","ZuoDengGuang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZuoDengGuang.YouQianDeng = AnalyseData("YouQianDeng","ZuoDengGuang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZuoDengGuang.ChePai = AnalyseData("ChePai","ZuoDengGuang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZuoDengGuang.QianMian = AnalyseData("QianMian","ZuoDengGuang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZuoDengGuang.ShuiYinRiQi = AnalyseData("ShuiYinRiQi","ZuoDengGuang","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("YouDengGuang")) {
                zhaopian_item.erase("YouDengGuang");
                ZhaoPianZL.YouDengGuang = xml.GetAttrib(number);
                g_CheckItem.picture.YouDengGuang.ZuoQianDeng = AnalyseData("ZuoQianDeng","YouDengGuang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouDengGuang.YouQianDeng = AnalyseData("YouQianDeng","YouDengGuang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouDengGuang.ChePai = AnalyseData("ChePai","YouDengGuang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouDengGuang.QianMian = AnalyseData("QianMian","YouDengGuang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YouDengGuang.ShuiYinRiQi = AnalyseData("ShuiYinRiQi","YouDengGuang","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("YiZhouZhiDong")) {
                zhaopian_item.erase("YiZhouZhiDong");
                ZhaoPianZL.YiZhouZhiDong = xml.GetAttrib(number);
                g_CheckItem.picture.YiZhouZhiDong.QianLun = AnalyseData("QianLun","YiZhouZhiDong","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YiZhouZhiDong.ChePai = AnalyseData("ChePai","YiZhouZhiDong","ZhaoPian",xml,error_item);
                g_CheckItem.picture.YiZhouZhiDong.ShuiYinRiQi = AnalyseData("ShuiYinRiQi","YiZhouZhiDong","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("ErZhouZhiDong")) {
                zhaopian_item.erase("ErZhouZhiDong");
                ZhaoPianZL.ErZhouZhiDong = xml.GetAttrib(number);
                g_CheckItem.picture.ErZhouZhiDong.HouLun = AnalyseData("HouLun","ErZhouZhiDong","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ErZhouZhiDong.ChePai = AnalyseData("ChePai","ErZhouZhiDong","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ErZhouZhiDong.ShuiYinRiQi = AnalyseData("ShuiYinRiQi","ErZhouZhiDong","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("ZhuCheZhiDong")) {
                zhaopian_item.erase("ZhuCheZhiDong");
                ZhaoPianZL.ZhuCheZhiDong = xml.GetAttrib(number);
                g_CheckItem.picture.ZhuCheZhiDong.ChePai = AnalyseData("ChePai","ZhuCheZhiDong","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZhuCheZhiDong.CheLun = AnalyseData("CheLun","ZhuCheZhiDong","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ZhuCheZhiDong.ShuiYinRiQi = AnalyseData("ShuiYinRiQi","ZhuCheZhiDong","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("DiPanDongTaiKaiShi")) {
                zhaopian_item.erase("DiPanDongTaiKaiShi");
                ZhaoPianZL.DiPanDongTaiKaiShi = xml.GetAttrib(number);
                g_CheckItem.picture.DiPanDongTaiKaiShi.ChePai = AnalyseData("ChePai","DiPanDongTaiKaiShi","ZhaoPian",xml,error_item);
                g_CheckItem.picture.DiPanDongTaiKaiShi.ChePaiQueDing = AnalyseData("ChePaiQueDing","DiPanDongTaiKaiShi","ZhaoPian",xml,error_item);
                g_CheckItem.picture.DiPanDongTaiKaiShi.YiDong = AnalyseData("YiDong","DiPanDongTaiKaiShi","ZhaoPian",xml,error_item);
                g_CheckItem.picture.DiPanDongTaiKaiShi.ShuiYinRiQi = AnalyseData("ShuiYinRiQi","DiPanDongTaiKaiShi","ZhaoPian",xml,error_item);
                g_CheckItem.picture.DiPanDongTaiKaiShi.BiaoZhi = AnalyseData("BiaoZhi","DiPanDongTaiKaiShi","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("DiPanDongTaiJieShu")) {
                zhaopian_item.erase("DiPanDongTaiJieShu");
                ZhaoPianZL.DiPanDongTaiJieShu = xml.GetAttrib(number);
                g_CheckItem.picture.DiPanDongTaiJieShu.ChePai = AnalyseData("ChePai","DiPanDongTaiJieShu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.DiPanDongTaiJieShu.YiDong = AnalyseData("YiDong","DiPanDongTaiJieShu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.DiPanDongTaiJieShu.ShuiYinRiQi = AnalyseData("ShuiYinRiQi","DiPanDongTaiJieShu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.DiPanDongTaiJieShu.BiaoZhi = AnalyseData("BiaoZhi","DiPanDongTaiJieShu","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("DiPanBuJian")) {
                zhaopian_item.erase("DiPanBuJian");
                ZhaoPianZL.DiPanBuJian = xml.GetAttrib(number);
                g_CheckItem.picture.DiPanBuJian.GongWei = AnalyseData("GongWei","DiPanBuJian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.DiPanBuJian.ChePai = AnalyseData("ChePai","DiPanBuJian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.DiPanBuJian.ShuiYinRiQi = AnalyseData("ShuiYinRiQi","DiPanBuJian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.DiPanBuJian.Ren = AnalyseData("Ren","DiPanBuJian","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("ChaYanJiLu")) {
                zhaopian_item.erase("ChaYanJiLu");
                ZhaoPianZL.ChaYanJiLu = xml.GetAttrib(number);
                g_CheckItem.picture.ChaYanJiLu.JianYanBiao = AnalyseData("JianYanBiao","ChaYanJiLu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ChaYanJiLu.ChaYanXinXi = AnalyseData("ChaYanXinXi","ChaYanJiLu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ChaYanJiLu.ChePai = AnalyseData("ChePai","ChaYanJiLu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ChaYanJiLu.CheJiaHao = AnalyseData("CheJiaHao","ChaYanJiLu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ChaYanJiLu.ChaYanJieLun = AnalyseData("ChaYanJieLun","ChaYanJiLu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ChaYanJiLu.ChaYanQianZi = AnalyseData("ChaYanQianZi","ChaYanJiLu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ChaYanJiLu.WaiGuanQianZi = AnalyseData("WaiGuanQianZi","ChaYanJiLu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ChaYanJiLu.YinCheQianZi = AnalyseData("YinCheQianZi","ChaYanJiLu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ChaYanJiLu.DiPanQianZi = AnalyseData("DiPanQianZi","ChaYanJiLu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ChaYanJiLu.HongZhang = AnalyseData("HongZhang","ChaYanJiLu","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("QianHaoPai")) {
                zhaopian_item.erase("QianHaoPai");
                ZhaoPianZL.QianHaoPai = xml.GetAttrib(number);
                g_CheckItem.picture.QianHaoPai.ChePai = AnalyseData("ChePai","QianHaoPai","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("HouHaoPai")) {
                zhaopian_item.erase("HouHaoPai");
                ZhaoPianZL.HouHaoPai = xml.GetAttrib(number);
                g_CheckItem.picture.HouHaoPai.ChePai = AnalyseData("ChePai","HouHaoPai","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("ShenFenZheng")) {
                zhaopian_item.erase("ShenFenZheng");
                ZhaoPianZL.ShenFenZheng = xml.GetAttrib(number);
                g_CheckItem.picture.ShenFenZheng.ShenFenZheng = AnalyseData("ShenFenZheng","ShenFenZheng","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("ShenFenZhengBeiMian")) {
                zhaopian_item.erase("ShenFenZhengBeiMian");
                ZhaoPianZL.ShenFenZhengBeiMian = xml.GetAttrib(number);
                g_CheckItem.picture.ShenFenZhengBeiMian.ShenFenZheng = AnalyseData("ShenFenZheng","ShenFenZhengBeiMian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.ShenFenZhengBeiMian.YouXiaoQi = AnalyseData("YouXiaoQi","ShenFenZhengBeiMian","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("JianYanBiaoBeiMian")) {
                zhaopian_item.erase("JianYanBiaoBeiMian");
                ZhaoPianZL.JianYanBiaoBeiMian = xml.GetAttrib(number);
                g_CheckItem.picture.JianYanBiaoBeiMian.JianYanBiaoBeiMian = AnalyseData("JianYanBiaoBeiMian","JianYanBiaoBeiMian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBiaoBeiMian.DiPan = AnalyseData("DiPan","JianYanBiaoBeiMian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBiaoBeiMian.WaiGuan = AnalyseData("WaiGuan","JianYanBiaoBeiMian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianYanBiaoBeiMian.YinChe = AnalyseData("YinChe","JianYanBiaoBeiMian","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("WanShuiZhengMing")) {
                zhaopian_item.erase("WanShuiZhengMing");
                ZhaoPianZL.WanShuiZhengMing = xml.GetAttrib(number);
                g_CheckItem.picture.WanShuiZhengMing.CheJiaHao = AnalyseData("CheJiaHao","WanShuiZhengMing","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WanShuiZhengMing.ChePai = AnalyseData("ChePai","WanShuiZhengMing","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WanShuiZhengMing.CheChuanShui = AnalyseData("CheChuanShui","WanShuiZhengMing","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WanShuiZhengMing.SuoShuRiQi = AnalyseData("SuoShuRiQi","WanShuiZhengMing","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WanShuiZhengMing.JianCeRiQi = AnalyseData("JianCeRiQi","WanShuiZhengMing","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WanShuiZhengMing.BaoXianDan = AnalyseData("BaoXianDan","WanShuiZhengMing","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("WeiTuoTongZhiShu")) {
                zhaopian_item.erase("WeiTuoTongZhiShu");
                ZhaoPianZL.WeiTuoTongZhiShu = xml.GetAttrib(number);
                g_CheckItem.picture.WeiTuoTongZhiShu.WeiTuoTongZhiShu = AnalyseData("WeiTuoTongZhiShu","WeiTuoTongZhiShu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiTuoTongZhiShu.ChePai = AnalyseData("ChePai","WeiTuoTongZhiShu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiTuoTongZhiShu.CheJiaHao = AnalyseData("CheJiaHao","WeiTuoTongZhiShu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiTuoTongZhiShu.YinZhang = AnalyseData("YinZhang","WeiTuoTongZhiShu","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("MieHuoQi")) {
                zhaopian_item.erase("MieHuoQi");
                ZhaoPianZL.MieHuoQi = xml.GetAttrib(number);
                g_CheckItem.picture.MieHuoQi.MieHuoQi = AnalyseData("MieHuoQi","MieHuoQi","ZhaoPian",xml,error_item);
                g_CheckItem.picture.MieHuoQi.YaLiBiao = AnalyseData("YaLiBiao","MieHuoQi","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("YingJiChui")) {
                zhaopian_item.erase("YingJiChui");
                ZhaoPianZL.YingJiChui = xml.GetAttrib(number);
                g_CheckItem.picture.YingJiChui.YingJiChui = AnalyseData("YingJiChui","YingJiChui","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("JiLuYi")) {
                zhaopian_item.erase("JiLuYi");
                ZhaoPianZL.JiLuYi = xml.GetAttrib(number);
                g_CheckItem.picture.JiLuYi.JiLuYi = AnalyseData("JiLuYi","JiLuYi","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JiLuYi.RenZheng = AnalyseData("RenZheng","JiLuYi","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JiLuYi.PingMu = AnalyseData("PingMu","JiLuYi","ZhaoPian",xml,error_item);
            }


            if (xml.FindElem("ZuoQianLun")) {
                zhaopian_item.erase("ZuoQianLun");
                ZhaoPianZL.ZuoQianLun = xml.GetAttrib(number);
                g_CheckItem.picture.ZuoQianLun.LunTai = AnalyseData("LunTai","ZuoQianLun","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("YouQianLun")) {
                zhaopian_item.erase("YouQianLun");
                ZhaoPianZL.YouQianLun = xml.GetAttrib(number);
                g_CheckItem.picture.YouQianLun.LunTai = AnalyseData("LunTai","YouQianLun","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("CheXiang")) {
                zhaopian_item.erase("CheXiang");
                ZhaoPianZL.CheXiang = xml.GetAttrib(number);
                g_CheckItem.picture.CheXiang.GaiZhuang = AnalyseData("GaiZhuang","CheXiang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheXiang.FengDing = AnalyseData("FengDing","CheXiang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheXiang.ZuoWei = AnalyseData("ZuoWei","CheXiang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheXiang.CheLiangLeiXing = AnalyseData("CheLiangLeiXing","CheXiang","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheXiang.JiaoDu = AnalyseData("JiaoDu","CheXiang","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("CeHuaGongWei")) {
                zhaopian_item.erase("CeHuaGongWei");
                ZhaoPianZL.CeHuaGongWei = xml.GetAttrib(number);
                g_CheckItem.picture.CeHuaGongWei.ChePai = AnalyseData("ChePai","CeHuaGongWei","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("WaiKuoQianMian")) {
                zhaopian_item.erase("WaiKuoQianMian");
                ZhaoPianZL.WaiKuoQianMian = xml.GetAttrib(number);
                g_CheckItem.picture.WaiKuoQianMian.ChePai = AnalyseData("ChePai","WaiKuoQianMian","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("WaiKuoCeMian")) {
                zhaopian_item.erase("WaiKuoCeMian");
                ZhaoPianZL.WaiKuoCeMian = xml.GetAttrib(number);
                g_CheckItem.picture.WaiKuoCeMian.ChePai = AnalyseData("ChePai","WaiKuoCeMian","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("DaCheHaoPai")) {
                zhaopian_item.erase("DaCheHaoPai");
                ZhaoPianZL.DaCheHaoPai = xml.GetAttrib(number);
                g_CheckItem.picture.DaCheHaoPai.ChePai = AnalyseData("ChePai","DaCheHaoPai","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("WeiXiangNeiBu")) {
                zhaopian_item.erase("WeiXiangNeiBu");
                ZhaoPianZL.WeiXiangNeiBu = xml.GetAttrib(number);
                g_CheckItem.picture.WeiXiangNeiBu.GaiZhuang = AnalyseData("GaiZhuang","WeiXiangNeiBu","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("FuZhuZhiDong")) {
                zhaopian_item.erase("FuZhuZhiDong");
                ZhaoPianZL.FuZhuZhiDong = xml.GetAttrib(number);
                g_CheckItem.picture.FuZhuZhiDong.FuZhuZhiDong = AnalyseData("FuZhuZhiDong","FuZhuZhiDong","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("ABS")) {
                zhaopian_item.erase("ABS");
                ZhaoPianZL.ABS = xml.GetAttrib(number);
                g_CheckItem.picture.ABS.ABS = AnalyseData("ABS","ABS","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("CheLiangCeMian")) {
                zhaopian_item.erase("CheLiangCeMian");
                ZhaoPianZL.CheLiangCeMian = xml.GetAttrib(number);
                g_CheckItem.picture.CheLiangCeMian.CheLiangCeMian = AnalyseData("CheLiangCeMian","CheLiangCeMian","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("CheLiangBeiMian")) {
                zhaopian_item.erase("CheLiangBeiMian");
                ZhaoPianZL.CheLiangBeiMian = xml.GetAttrib(number);
                g_CheckItem.picture.CheLiangBeiMian.CheLiangBeiMian = AnalyseData("CheLiangBeiMian","CheLiangBeiMian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheLiangBeiMian.ChePai = AnalyseData("ChePai","CheLiangBeiMian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheLiangBeiMian.CheBiao = AnalyseData("CheBiao","CheLiangBeiMian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheLiangBeiMian.SanJiaoJia = AnalyseData("SanJiaoJia","CheLiangBeiMian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheLiangBeiMian.XiaBuFangHu = AnalyseData("XiaBuFangHu","CheLiangBeiMian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheLiangBeiMian.WeiBuBiaoZhi = AnalyseData("WeiBuBiaoZhi","CheLiangBeiMian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheLiangBeiMian.CheShenFanGuangBiaoShi = AnalyseData("CheShenFanGuangBiaoShi","CheLiangBeiMian","ZhaoPian",xml,error_item);
                g_CheckItem.picture.CheLiangBeiMian.PenTuHaoMa = AnalyseData("PenTuHaoMa","CheLiangBeiMian","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("HeDingZaiKe")) {
                zhaopian_item.erase("HeDingZaiKe");
                ZhaoPianZL.HeDingZaiKe = xml.GetAttrib(number);
                g_CheckItem.picture.HeDingZaiKe.HeDingZaiKe = AnalyseData("HeDingZaiKe","HeDingZaiKe","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("JianCeQuXianBaoGao")) {
                zhaopian_item.erase("JianCeQuXianBaoGao");
                ZhaoPianZL.JianCeQuXianBaoGao = xml.GetAttrib(number);
                g_CheckItem.picture.JianCeQuXianBaoGao.QuXianBaoGao = AnalyseData("QuXianBaoGao","JianCeQuXianBaoGao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianCeQuXianBaoGao.ChePai = AnalyseData("ChePai","JianCeQuXianBaoGao","ZhaoPian",xml,error_item);
                g_CheckItem.picture.JianCeQuXianBaoGao.YinZhang = AnalyseData("YinZhang","JianCeQuXianBaoGao","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("CheJiaHaoUG")) {
                zhaopian_item.erase("CheJiaHaoUG");
                ZhaoPianZL.CheJiaHaoUG = xml.GetAttrib(number);
                g_CheckItem.picture.CheJiaHaoUG.CheJiaHao = AnalyseData("CheJiaHao","CheJiaHaoUG","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("HouPaiCheXiang")) {
                zhaopian_item.erase("HouPaiCheXiang");
                ZhaoPianZL.HouPaiCheXiang = xml.GetAttrib(number);
                g_CheckItem.picture.HouPaiCheXiang.AnQuanDai = AnalyseData("AnQuanDai","HouPaiCheXiang","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("HouPaiCheXiang2")) {
                zhaopian_item.erase("HouPaiCheXiang2");
                ZhaoPianZL.HouPaiCheXiang2 = xml.GetAttrib(number);
                g_CheckItem.picture.HouPaiCheXiang2.AnQuanDai = AnalyseData("AnQuanDai","HouPaiCheXiang2","ZhaoPian",xml,error_item);
            }

            if (xml.FindElem("WeiQiJianYan2")) {
                zhaopian_item.erase("WeiQiJianYan2");
                ZhaoPianZL.WeiQiJianYan2 = xml.GetAttrib(number);
                string cc=ZhaoPianZL.WeiQiJianYan2;
                g_CheckItem.picture.WeiQiJianYan2.JieLun = AnalyseData("JieLun","WeiQiJianYan2","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan2.ChePai = AnalyseData("ChePai","WeiQiJianYan2","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan2.CheJiaHao = AnalyseData("CheJiaHao","WeiQiJianYan2","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan2.YinZhang = AnalyseData("YinZhang","WeiQiJianYan2","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan2.QianMing = AnalyseData("QianMing","WeiQiJianYan2","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan2.YinZhang_MA = AnalyseData("YinZhang_MA","WeiQiJianYan2","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan2.DianZiBaoGao = AnalyseData("DianZiBaoGao","WeiQiJianYan2","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan2.CaoZuoYuan = AnalyseData("CaoZuoYuan","WeiQiJianYan2","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan2.JiaShiYuan = AnalyseData("JiaShiYuan","WeiQiJianYan2","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan2.PiZhunRen = AnalyseData("PiZhunRen","WeiQiJianYan2","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan2.ShenHeYuan = AnalyseData("ShenHeYuan","WeiQiJianYan2","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan2.JianCeShiJian = AnalyseData("JianCeShiJian","WeiQiJianYan2","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan2.DianZiBiaoGe = AnalyseData("DianZiBiaoGe","WeiQiJianYan2","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan2.YouXiaoQi = AnalyseData("YouXiaoQi","WeiQiJianYan2","ZhaoPian",xml,error_item);
                g_CheckItem.picture.WeiQiJianYan2.FaDongJiBianHao = AnalyseData("FaDongJiBianHao","WeiQiJianYan2","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("GaoZhiShu")) {
                zhaopian_item.erase("GaoZhiShu");
                ZhaoPianZL.GaoZhiShu = xml.GetAttrib(number);
                g_CheckItem.picture.GaoZhiShu.GaoZhiShu = AnalyseData("GaoZhiShu","GaoZhiShu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.GaoZhiShu.HongZhang = AnalyseData("HongZhang","GaoZhiShu","ZhaoPian",xml,error_item);
                g_CheckItem.picture.GaoZhiShu.QianMing = AnalyseData("HongZhang","GaoZhiShu","ZhaoPian",xml,error_item);
            }
            if (xml.FindElem("RongQueShouLi")) {
                zhaopian_item.erase("RongQueShouLi");
                ZhaoPianZL.RongQueShouLi = xml.GetAttrib(number);
                g_CheckItem.picture.RongQueShouLi.DuiGou = AnalyseData("DuiGou","RongQueShouLi","ZhaoPian",xml,error_item);
                g_CheckItem.picture.RongQueShouLi.QianMing = AnalyseData("DuiGou","RongQueShouLi","ZhaoPian",xml,error_item);
            }
            xml.OutOfElem();
        }

        if (xml.FindElem("ShiPin")) {
            first_item.erase("ShiPin");
            xml.IntoElem();

            if (xml.FindElem("ZuoQianFang")) {
                shipin_item.erase("ZuoQianFang");
                g_CheckItem.video.ZuoQianFang.ChePai = AnalyseData("ChePai","ZuoQianFang","ShiPin",xml,error_item);

            }

            if (xml.FindElem("YouHouFang")) {
                shipin_item.erase("YouHouFang");
                g_CheckItem.video.YouHouFang.ChePai = AnalyseData("ChePai","YouHouFang","ShiPin",xml,error_item);

            }

            if (xml.FindElem("YiZhouZhiDong")) {
                shipin_item.erase("YiZhouZhiDong");

                g_CheckItem.video.YiZhouZhiDong.ChePai = AnalyseData("ChePai","YiZhouZhiDong","ShiPin",xml,error_item);
                g_CheckItem.video.YiZhouZhiDong.QianLun = AnalyseData("QianLun","YiZhouZhiDong","ShiPin",xml,error_item);
                g_CheckItem.video.YiZhouZhiDong.WeiDeng = AnalyseData("WeiDeng","YiZhouZhiDong","ShiPin",xml,error_item);
                g_CheckItem.video.YiZhouZhiDong.Ren = AnalyseData("Ren","YiZhouZhiDong","ShiPin",xml,error_item);

            }

            if (xml.FindElem("ErZhouZhiDong")) {
                shipin_item.erase("ErZhouZhiDong");
                g_CheckItem.video.ErZhouZhiDong.ChePai = AnalyseData("ChePai","ErZhouZhiDong","ShiPin",xml,error_item);
                g_CheckItem.video.ErZhouZhiDong.HouLun = AnalyseData("HouLun","ErZhouZhiDong","ShiPin",xml,error_item);
                g_CheckItem.video.ErZhouZhiDong.WeiDeng = AnalyseData("WeiDeng","ErZhouZhiDong","ShiPin",xml,error_item);
                g_CheckItem.video.ErZhouZhiDong.Ren = AnalyseData("Ren","ErZhouZhiDong","ShiPin",xml,error_item);

            }

            if (xml.FindElem("ZuoDengGuang")) {
                shipin_item.erase("ZuoDengGuang");
                g_CheckItem.video.ZuoDengGuang.ChePai = AnalyseData("ChePai","ZuoDengGuang","ShiPin",xml,error_item);
                g_CheckItem.video.ZuoDengGuang.QianDaDeng = AnalyseData("QianDaDeng","ZuoDengGuang","ShiPin",xml,error_item);
                g_CheckItem.video.ZuoDengGuang.Ren = AnalyseData("Ren","ZuoDengGuang","ShiPin",xml,error_item);
                g_CheckItem.video.ZuoDengGuang.CeShiYi = AnalyseData("CeShiYi","ZuoDengGuang","ShiPin",xml,error_item);

            }

            if (xml.FindElem("YouDengGuang")) {
                shipin_item.erase("YouDengGuang");

                g_CheckItem.video.YouDengGuang.ChePai = AnalyseData("ChePai","YouDengGuang","ShiPin",xml,error_item);
                g_CheckItem.video.YouDengGuang.QianDaDeng = AnalyseData("QianDaDeng","YouDengGuang","ShiPin",xml,error_item);
                g_CheckItem.video.YouDengGuang.Ren = AnalyseData("Ren","YouDengGuang","ShiPin",xml,error_item);
                g_CheckItem.video.YouDengGuang.CeShiYi = AnalyseData("CeShiYi","YouDengGuang","ShiPin",xml,error_item);

            }

            if (xml.FindElem("DongTaiGongWei_1")) {
                shipin_item.erase("DongTaiGongWei_1");
                g_CheckItem.video.DongTaiGongWei_1.ChePai = AnalyseData("ChePai","DongTaiGongWei_1","ShiPin",xml,error_item);
                g_CheckItem.video.DongTaiGongWei_1.WeiYi = AnalyseData("WeiYi","DongTaiGongWei_1","ShiPin",xml,error_item);

            }

            if (xml.FindElem("DongTaiGongWei_2")) {
                shipin_item.erase("DongTaiGongWei_2");
                g_CheckItem.video.DongTaiGongWei_2.ChePai = AnalyseData("ChePai","DongTaiGongWei_2","ShiPin",xml,error_item);
                g_CheckItem.video.DongTaiGongWei_2.WeiYi = AnalyseData("WeiYi","DongTaiGongWei_2","ShiPin",xml,error_item);

            }

            if (xml.FindElem("DiPanGongWei")) {
                shipin_item.erase("DiPanGongWei");
                g_CheckItem.video.DiPanGongWei.Ren = AnalyseData("Ren","DiPanGongWei","ShiPin",xml,error_item);

            }

            if (xml.FindElem("V_ZhuCheZhiDong")) {
                suzhouvideo_item.erase("V_ZhuCheZhiDong");
                g_CheckItem.video.ZhuCheZhiDong.ChePai = AnalyseData("ChePai","ZhuCheZhiDong","SuzhouVideo",xml,error_item);
                g_CheckItem.video.ZhuCheZhiDong.HouLun = AnalyseData("HouLun","ZhuCheZhiDong","SuzhouVideo",xml,error_item);
                g_CheckItem.video.ZhuCheZhiDong.TaiQi = AnalyseData("TaiQi","ZhuCheZhiDong","SuzhouVideo",xml,error_item);
                g_CheckItem.video.ZhuCheZhiDong.Ren = AnalyseData("Ren","ZhuCheZhiDong","SuzhouVideo",xml,error_item);
                g_CheckItem.video.ZhuCheZhiDong.WeiDeng = AnalyseData("WeiDeng","ZhuCheZhiDong","SuzhouVideo",xml,error_item);

            }

            xml.OutOfElem();
        }

        if (xml.FindElem("SuzhouVideo")){
            first_item.erase("SuzhouVideo");
            xml.IntoElem();
            if (xml.FindElem("SpaoConnect")) {
                suzhouvideo_item.erase("SpaoConnect");
                g_CheckItem.dlvideo.soapflag = AnalyseData("soapflag","SpaoConnect","SuzhouVideo",xml,error_item);
            }
            if (xml.FindElem("Download")) {
                suzhouvideo_item.erase("Download");
                g_CheckItem.dlvideo.dlflag = AnalyseData("dlflag","Download","SuzhouVideo",xml,error_item);
            }
            if (xml.FindElem("V_CheLiangZuoQianFang")) {
                suzhouvideo_item.erase("V_CheLiangZuoQianFang");
                g_CheckItem.video.ZuoQianFang.ChePai = AnalyseData("ChePai","V_CheLiangZuoQianFang","SuzhouVideo",xml,error_item);

            }
            if (xml.FindElem("V_CheLiangYouHouFang")) {
                suzhouvideo_item.erase("V_CheLiangYouHouFang");
                g_CheckItem.video.YouHouFang.ChePai = AnalyseData("ChePai","V_CheLiangYouHouFang","SuzhouVideo",xml,error_item);

            }
            if (xml.FindElem("V_YiZhouZhiDong")) {
                suzhouvideo_item.erase("V_YiZhouZhiDong");
                g_CheckItem.video.YiZhouZhiDong.ChePai = AnalyseData("ChePai","V_YiZhouZhiDong","SuzhouVideo",xml,error_item);
                g_CheckItem.video.YiZhouZhiDong.QianLun = AnalyseData("QianLun","V_YiZhouZhiDong","SuzhouVideo",xml,error_item);
                g_CheckItem.video.YiZhouZhiDong.WeiDeng = AnalyseData("WeiDeng","V_YiZhouZhiDong","SuzhouVideo",xml,error_item);
                g_CheckItem.video.YiZhouZhiDong.Ren = AnalyseData("Ren","V_YiZhouZhiDong","SuzhouVideo",xml,error_item);

            }
            if (xml.FindElem("V_ErZhouZhiDong")) {
                suzhouvideo_item.erase("V_ErZhouZhiDong");
                g_CheckItem.video.ErZhouZhiDong.ChePai = AnalyseData("ChePai","V_ErZhouZhiDong","SuzhouVideo",xml,error_item);
                g_CheckItem.video.ErZhouZhiDong.HouLun = AnalyseData("HouLun","V_ErZhouZhiDong","SuzhouVideo",xml,error_item);
                g_CheckItem.video.ErZhouZhiDong.WeiDeng = AnalyseData("WeiDeng","V_ErZhouZhiDong","SuzhouVideo",xml,error_item);
                g_CheckItem.video.ErZhouZhiDong.Ren = AnalyseData("Ren","V_ErZhouZhiDong","SuzhouVideo",xml,error_item);

            }
            if (xml.FindElem("V_ZuoDengGuang")) {
                suzhouvideo_item.erase("V_ZuoDengGuang");
                g_CheckItem.video.ZuoDengGuang.ChePai = AnalyseData("ChePai","V_ZuoDengGuang","SuzhouVideo",xml,error_item);
                g_CheckItem.video.ZuoDengGuang.CeShiYi = AnalyseData("CeShiYi","V_ZuoDengGuang","SuzhouVideo",xml,error_item);
                g_CheckItem.video.ZuoDengGuang.QianDaDeng = AnalyseData("QianDaDeng","V_ZuoDengGuang","SuzhouVideo",xml,error_item);
                g_CheckItem.video.ZuoDengGuang.Ren = AnalyseData("Ren","V_ZuoDengGuang","SuzhouVideo",xml,error_item);

            }
            if (xml.FindElem("V_YouDengGuang")) {
                suzhouvideo_item.erase("V_YouDengGuang");
                g_CheckItem.video.YouDengGuang.ChePai = AnalyseData("ChePai","V_YouDengGuang","SuzhouVideo",xml,error_item);
                g_CheckItem.video.YouDengGuang.CeShiYi = AnalyseData("CeShiYi","V_YouDengGuang","SuzhouVideo",xml,error_item);
                g_CheckItem.video.YouDengGuang.QianDaDeng = AnalyseData("QianDaDeng","V_YouDengGuang","SuzhouVideo",xml,error_item);
                g_CheckItem.video.YouDengGuang.Ren = AnalyseData("Ren","V_YouDengGuang","SuzhouVideo",xml,error_item);

            }
            if (xml.FindElem("V_DiPan")) {
                suzhouvideo_item.erase("V_DiPan");
                g_CheckItem.video.DiPanGongWei.Ren = AnalyseData("Ren","V_DiPan","SuzhouVideo",xml,error_item);

            }
            if (xml.FindElem("V_ZhuCheZhiDong")) {
                suzhouvideo_item.erase("V_ZhuCheZhiDong");
                g_CheckItem.video.ZhuCheZhiDong.ChePai = AnalyseData("ChePai","ZhuCheZhiDong","SuzhouVideo",xml,error_item);
                g_CheckItem.video.ZhuCheZhiDong.HouLun = AnalyseData("HouLun","ZhuCheZhiDong","SuzhouVideo",xml,error_item);
                g_CheckItem.video.ZhuCheZhiDong.TaiQi = AnalyseData("TaiQi","ZhuCheZhiDong","SuzhouVideo",xml,error_item);
                g_CheckItem.video.ZhuCheZhiDong.Ren = AnalyseData("Ren","ZhuCheZhiDong","SuzhouVideo",xml,error_item);
                g_CheckItem.video.ZhuCheZhiDong.WeiDeng = AnalyseData("WeiDeng","ZhuCheZhiDong","SuzhouVideo",xml,error_item);

            }


        }
        xml.OutOfElem();
    }
    //判断各级字段是否存在，如一级字段不存在，则不提示此二级字段
    std::set< std::string > ::iterator it;
    //unsigned int size = first_item.size();
    if( first_item.size() || zhaopian_item.size() || shipin_item.size() || suzhouvideo_item.size() || error_item.size() ){
        DATA_PRINT(LEVEL_ERROR, "读取配置文件check_item.xml失败！ \n");
        if( first_item.size() ){
            for(it = first_item.begin();it != first_item.end();++it){
                DATA_PRINT(LEVEL_ERROR, "原因: %s 未配置\n", (*it).c_str());
            }
        }
        if( zhaopian_item.size() && (first_item.find("ZhaoPian") != first_item.end() ) ? false : true){
            for(it = zhaopian_item.begin();it != zhaopian_item.end();++it){
                DATA_PRINT(LEVEL_ERROR, "原因: ZhaoPian----->%s未配置 \n", (*it).c_str());
            }
        }
        if( shipin_item.size() && (first_item.find("ShiPin") != first_item.end() ) ? false : true ){
            for(it = shipin_item.begin();it != shipin_item.end();++it){
                DATA_PRINT(LEVEL_ERROR, "原因: ShiPin----->%s未配置 \n", (*it).c_str());
            }
        }
        if( suzhouvideo_item.size() && (first_item.find("SuzhouVideo") != first_item.end() ) ? false : true){
            for(it = suzhouvideo_item.begin();it != suzhouvideo_item.end();++it){
                DATA_PRINT(LEVEL_ERROR, "原因: SuzhouVideo----->%s未配置 \n", (*it).c_str());
            }
        }
        if( error_item.size() ){
            for( unsigned int i = 0; i < error_item.size(); i++ ){
                DATA_PRINT(LEVEL_ERROR, "原因: %s", error_item[i].c_str());
            }
        }
        exit(EXIT_FAILURE);
    }

}
std::vector<_photo_resource> zplist_buf;
/*过滤特殊城市照片列表*/
void filter_zplist(vehicle_inf *pvehicle_inf)
{
    /*
     * 九江特殊需求:
       检验车辆类型以‘Z’和‘Q’开头的车辆以下照片
       行驶证、申请表、交强险、检验报告、尾气单
    */
    if(g_CheckItem.City == JIUJIANG)
    {
        std::vector<_photo_resource> zplist_buf;
        std::string cllx = pvehicle_inf->m_cllx;
        zplist_buf.clear();
        if(cllx.substr(0,1) == "Z" || cllx.substr(0,1) == "Q")
        {
            for(size_t count = 0;count < pvehicle_inf->m_zplist.size();count++)
            {
                std::string zplx = pvehicle_inf->m_zplist[count].zptype;
                if( zplx == ZhaoPianZL.XingShiZheng  ||
                    zplx == ZhaoPianZL.ShenQingBiao  ||
                    zplx == ZhaoPianZL.JiaoQiangXian ||
                    zplx == ZhaoPianZL.JianYanBaoGao ||
                    zplx == ZhaoPianZL.WeiQiJianYan  ||
                    zplx == ZhaoPianZL.WeiQiJianYan2 )
                {
                    zplist_buf.push_back(pvehicle_inf->m_zplist[count]);
                }
                else
                {
                    _dbbhg_list bhglist_buf;
                    bhglist_buf.zpid = pvehicle_inf->m_zplist[count].zpid;
                    bhglist_buf.zptype = pvehicle_inf->m_zplist[count].zptype;
                    bhglist_buf.dbresult = NEED_MANUAL;
                    bhglist_buf.dbbhg_desc = "无法处理的照片类型";
                    pvehicle_inf->m_dbbhglist.push_back(bhglist_buf);
                    zplist_buf.push_back(pvehicle_inf->m_zplist[count]);
                }
            }
            pvehicle_inf->m_zplist.clear();
            pvehicle_inf->m_zplist = zplist_buf;

        }
    }

    if(g_CheckItem.City == ANSHUN)
    {
        std::vector<_photo_resource> zplist_buf;
        std::string cllx = pvehicle_inf->m_cllx;
        zplist_buf.clear();
        if(cllx.substr(0,1) == "Z" || cllx.substr(0,1) == "Q"|| cllx.substr(0,1) == "H")
        {
            for(size_t count = 0;count < pvehicle_inf->m_zplist.size();count++)
            {
                std::string zplx = pvehicle_inf->m_zplist[count].zptype;
                if( zplx == ZhaoPianZL.CheJiaHao)
                {
                    zplist_buf.push_back(pvehicle_inf->m_zplist[count]);
                }
                else
                {
                    _dbbhg_list bhglist_buf;
                    bhglist_buf.zpid = pvehicle_inf->m_zplist[count].zpid;
                    bhglist_buf.zptype = pvehicle_inf->m_zplist[count].zptype;
                    bhglist_buf.dbresult = NEED_MANUAL;
                    bhglist_buf.dbbhg_desc = "无法处理的照片类型";
                    pvehicle_inf->m_dbbhglist.push_back(bhglist_buf);
                    zplist_buf.push_back(pvehicle_inf->m_zplist[count]);
                }
            }
            pvehicle_inf->m_zplist.clear();
            pvehicle_inf->m_zplist = zplist_buf;

        }
    }


}

void add_zplist(vehicle_inf* pvehicle_inf)
{
    if(g_CheckItem.City == JIUJIANG)
    {
        for(size_t count = 0;count < zplist_buf.size();count++)
        {
            pvehicle_inf->m_zplist.push_back(zplist_buf[count]);
        }
    }
    if(g_CheckItem.City == ANSHUN)
    {
        for(size_t count = 0;count < zplist_buf.size();count++)
        {
            pvehicle_inf->m_zplist.push_back(zplist_buf[count]);
        }
    }

}
int process_photo(vehicle_inf *pvehicle_inf, LargeVehicleApi *alg)
{
    ResultCollection result;
    pvehicle_inf->m_dbbhgs = "0";

#ifdef DEMO_TEST
    memset(&demo_data, 0, sizeof(demo_data));  //7.13结构体初始化
    std::string lshbuf = pvehicle_inf->m_jylsh;
    demo_sqlString0 = "";
    demo_sqlString = "";
#endif
    extern _ZhaoPianZL ZhaoPianZL;
    if(!pvehicle_inf->is_video_check)
    {
        /* 如果“检验机构”不在处理范围内，则跳过算法，直接回复结果“建议人工” */
        unsigned int k;
        std::string jyjgbh = pvehicle_inf->m_jyjgbh;
        for (k = 0; k < g_CheckItem.JianYanJiGou.size(); k++) {
            if (jyjgbh == g_CheckItem.JianYanJiGou[k].bh) {
                DATA_PRINT(LEVEL_INFO, "jyjgbh:%s,g_CheckItem.JianYanJiGou[k].bh:%s\n",jyjgbh,g_CheckItem.JianYanJiGou[k].bh);
                break;
            }
        }
        if ((k == g_CheckItem.JianYanJiGou.size()) && (g_CheckItem.JianYanJiGou.size() != 0)) {
            result.NoAnalyse_RenGong(pvehicle_inf, "检验机构不在软件处理范围内");
            DATA_PRINT(LEVEL_INFO, "\"检验机构\"不在软件处理范围内，跳过算法处理。 \n");
            return 0;
        }

        /*
        如果指定检验机构指定的从机无法处理，则由其他机器填写“该机器通信异常”。
        这种情况比较特殊，因此要放在其他原因的前面。
        */
        std::string assignment_IP;
        for (unsigned int i = 0; i < g_CheckItem.JianYanJiGou.size(); i++) {
            if (g_CheckItem.JianYanJiGou[i].bh == jyjgbh) {
                assignment_IP = g_CheckItem.JianYanJiGou[i].assignment_IP;
                break;
            }
        }
        if ( (!assignment_IP.empty()) && (assignment_IP != g_localServerIp) ) {
            result.NoAnalyse_RenGong(pvehicle_inf, "指定的机器(IP:" + assignment_IP + ")没有在线，无法处理");
            DATA_PRINT(LEVEL_ERROR, "Target(%s) machine is not online, could not process vehicle info(lsh:%s, jyjgbh:%s)! \n",
                       assignment_IP.data(), pvehicle_inf->m_jylsh.data(), pvehicle_inf->m_jyjgbh.data());
            return 0;
        }

        /* 如果“检验类别”不在处理范围内，则跳过算法，直接回复结果“建议人工” */
        std::string _jylb = pvehicle_inf->m_jylb;
        for (k = 0; k < g_CheckItem.JianYanLeiBie.size(); k++) {
            if (_jylb == g_CheckItem.JianYanLeiBie[k]) {
                break;
            }
        }
        if ((k == g_CheckItem.JianYanLeiBie.size()) && (g_CheckItem.JianYanLeiBie.size() != 0)) {
            result.NoAnalyse_RenGong(pvehicle_inf, "检验类别不在软件处理范围内");
            DATA_PRINT(LEVEL_INFO, "\"检验类别\"不在软件处理范围内，跳过算法处理。 \n");
            return 0;
        }

        /* 如果“使用性质”不在处理范围内，则跳过算法，直接回复结果“建议人工” */
        std::string syxz = pvehicle_inf->m_syxz;
        for (k = 0; k < g_CheckItem.ShiYongXingZhi.size(); k++) {
            if (syxz == g_CheckItem.ShiYongXingZhi[k]) {
                break;
            }
        }
        if ((k == g_CheckItem.ShiYongXingZhi.size()) && (g_CheckItem.ShiYongXingZhi.size() != 0)) {
            result.NoAnalyse_RenGong(pvehicle_inf, "使用性质不在软件处理范围");
            DATA_PRINT(LEVEL_INFO, "\"使用性质\"不在软件处理范围内，跳过算法处理。 \n");
            return 0;
        }

        /* 如果“车辆类型”不在处理范围内，则跳过算法，直接回复结果“建议人工” */
        std::string cllx = pvehicle_inf->m_cllx;
        if(g_CheckItem.CheLiangZhongLei.size() != 0)
        {
            for (k = 0; k < g_CheckItem.CheLiangZhongLei.size(); k++) {
                if (cllx == g_CheckItem.CheLiangZhongLei[k]) {
                    break;
                }

                if ((g_CheckItem.CheLiangZhongLei[k].size() == 3) && (g_CheckItem.CheLiangZhongLei[k].at(2) == '0')) {
                    if (cllx.size() >= 2) {
                        if (g_CheckItem.CheLiangZhongLei[k].substr(0, 2) == cllx.substr(0, 2)) {
                            break;
                        }
                    }
                }
            }
            if ((k == g_CheckItem.CheLiangZhongLei.size()) && (g_CheckItem.CheLiangZhongLei.size() != 0)) {
                result.NoAnalyse_RenGong(pvehicle_inf, std::string("车辆类型不在软件处理范围内"));
                DATA_PRINT(LEVEL_INFO, "\"车辆类型\"不在软件处理范围内，跳过算法处理。 \n");
                return 0;
            }
        }
    }
    else
    {
        DATA_PRINT(LEVEL_INFO, "视频检查处理中........ \n");
    }
    //添加城市特殊过滤处理
    filter_zplist(pvehicle_inf);


    int i_jylb;
    std::string jylb = pvehicle_inf->m_jylb;
    if (jylb == "00")
    {
        pvehicle_inf->is_new_vehicle = TRUE;
        i_jylb = 0; //注册登记检验（新车）
    }
    else if (jylb == "01")
    {
        pvehicle_inf->is_new_vehicle = FALSE;
        i_jylb = 1;//在用车检验
    }
    else if (jylb == "02")
    {
        pvehicle_inf->is_new_vehicle = FALSE;
        i_jylb = 2;//临时检验
    }
    else if (jylb == "03")
    {
        pvehicle_inf->is_new_vehicle = FALSE;
        i_jylb = 3;//特殊检验（对肇事车和特殊用车的检验）
    }
    else if (jylb == "04")
    {
        pvehicle_inf->is_new_vehicle = FALSE;
        i_jylb = 4;//在用车检验（非定检）
    }
    else
    {
        if (pvehicle_inf->m_hphm.length() <= 5)
        {
            if (pvehicle_inf->m_clsbdh.find(pvehicle_inf->m_hphm) != std::string::npos)
                pvehicle_inf->is_new_vehicle = TRUE;
        }
        else
        {
            if (pvehicle_inf->m_clsbdh.length() > 8) //should be 15
            {
                std::string str_clsbdh = RightString(pvehicle_inf->m_clsbdh, 8);
                if (str_clsbdh.find(RightString(pvehicle_inf->m_hphm, 5)) != std::string::npos)
                    pvehicle_inf->is_new_vehicle = TRUE;
                else if (str_clsbdh.find(LeftString(pvehicle_inf->m_hphm, 5)) != std::string::npos)
                    pvehicle_inf->is_new_vehicle = TRUE;
            }
        }
    }
    (void)i_jylb;

    if(g_CheckItem.City == TIANJIN)
    {
        result.IsNewVehicle = (pvehicle_inf->is_new_vehicle)||(pvehicle_inf->is_chepai_off);
        if(result.IsNewVehicle)
        {
            DATA_PRINT(LEVEL_INFO, "TIANJIN .... 号牌不检测!!!!!!\n");
        }
        else
        {
            DATA_PRINT(LEVEL_INFO, "TIANJIN .... 号牌需要检测!!!!!!\n");
        }
    }
    else
    {
        result.IsNewVehicle = pvehicle_inf->is_new_vehicle;
    }
    bool DengGuangPictureProcessed = false;	/*  左灯光和右灯光是否已处理 */

    /*
     * wrwhm 污染物 （尾气）
     * jyb  检验表
     * jyb_yq   检验表(仪器部分)
    */
    std::string wrwhm("0209"), jyb_yq, jyb_rg("0212"), bxd("0203"), wts("0208"), xsz_bk("0299"), mszm("0206") , dchp("0164"), cyjlb("0205"),jlb_bk("0298"),qxjcbg("0213"),cjhyj,hhp("0168"),jybg("0204"),jqx2;

    std::string jyhgzm; /* 检验合格证明 */

    for (unsigned int i = 0; i < pvehicle_inf->m_zplist.size(); i++)
    {
        DATA_PRINT(LEVEL_INFO, "[zptype=%s loc=%s]\n", pvehicle_inf->m_zplist[i].zptype.c_str(), pvehicle_inf->m_zplist[i].local_path.c_str());

        if (pvehicle_inf->m_zplist[i].local_path == "TBD")
        {
            DATA_PRINT(LEVEL_INFO, "ID为%s的照片未获取成功\n", pvehicle_inf->m_zplist[i].zpid.c_str());
            continue;
        }

        // +{{ xeast 2018-06-27 majorization city code
        if(g_CheckItem.City == CHONGQING) {
            jyb_yq= std::string("0213");
            qxjcbg = "";
            wrwhm = std::string("0258");
            jyb_rg = std::string ("0212");
        } else if(g_CheckItem.City == WUHAN) {
            wrwhm = std::string("0265");
        } else if(g_CheckItem.City == SUZHOU) {
            wrwhm = std::string("0210");
        } else if(g_CheckItem.City == BAODING) {
            wrwhm = std::string("0212");
            jyb_rg = std::string("");
        } else if(g_CheckItem.City == NINGBO) {
            jyb_yq = std::string("0297");
            xsz_bk = std::string("0299");
        } else if (g_CheckItem.City == NANNING) {
            wrwhm = std::string("0224");
            wts = std::string("0222");
            bxd = "";
            dchp = "";
            jyb_rg = std::string("0227");
            xsz_bk = std::string("0203");
        } else if (g_CheckItem.City == QINGHAI) {
            wrwhm = std::string("0290");
        } else if (g_CheckItem.City == SHENZHEN) {
            wrwhm = std::string("0209");
            jyb_rg = std::string("0259");
            xsz_bk = std::string("0261");
        } else if (g_CheckItem.City == HULUNBEIER) {
            wrwhm = std::string("0209");
            xsz_bk = std::string("0206");
            mszm = std::string("0210");
        } else if (g_CheckItem.City == TIANJIN) {
            wrwhm = std::string("0210");
            mszm = std::string("0206");
            xsz_bk = std::string("0209");
            cjhyj = std::string ("0168");
            hhp = "";
        } else if (g_CheckItem.City == ZHOUKOU) {
            wrwhm = std::string("0298");
            xsz_bk = std::string("0296");
            jlb_bk = "";
        } else if (g_CheckItem.City == HENGSHUI) {
            wrwhm = std::string("0213");
            qxjcbg = "";
            xsz_bk = std::string("0214");
        } else if (g_CheckItem.City == ANSHUN) {
            xsz_bk= std::string("0214");
            jyb_rg = std::string("0297");
            jyb_yq = std::string("0204");
            jybg = std::string("0254");
            jqx2 = std::string("0210");
        } else if (g_CheckItem.City == PUTIAN) {
            cyjlb = "";
            xsz_bk = std::string("0205");
            wrwhm = std::string("0213");
            qxjcbg = "";
            jyb_rg = std::string("0209");
            jyb_yq = std::string("0210");
        } else if (g_CheckItem.City == XUZHOU) {
            wrwhm = "0206";
            mszm = "";
        } else if (g_CheckItem.City == FOSHAN) {
            bxd = "0203";
            xsz_bk = "0256";
            wts = "0208";
            jyb_yq = "0258";
            wrwhm = "0297";
        } else if (g_CheckItem.City == ZHAOTONG) {
            xsz_bk = "0261";
        } else if (g_CheckItem.City == NANJING) {
            jyhgzm= "0212";
        } else if (g_CheckItem.City == FUZHOU2) {
            xsz_bk = "0213";
            wrwhm = "0298";
            wts = "0207";
        }
        else {
            ;
        }
        // }}

        try {
             vehicle_check_if_ten_year(pvehicle_inf, result);//tenyear

            if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.XingShiZheng)//0201 - 机动车行驶证
            {
                if (!pvehicle_inf->is_new_vehicle) {
                    vehicle_check_xsz(pvehicle_inf, i, alg, result);
                }
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.ShenQingBiao) //0202-机动车牌证申请表
            {
                vehicle_check_sqb(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.JiaoQiangXian)//0203-机动车交通事故责任强制保险凭证
            {
                vehicle_check_jqx(pvehicle_inf, i, alg, result);
            }
            else if ((pvehicle_inf->m_zplist[i].zptype=="0206")&&(g_CheckItem.City==ZHONGSHAN)) // 中山车船税或完税证明为交强险单,所以调用交强处理险函数
            {
                vehicle_check_zs_jqx(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.JianYanBaoGao) // 机动车安全技术检验报告单
            {
                vehicle_check_jybg(pvehicle_inf, i, alg, result);
            }
            else if(pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.ChaYanJiLu )   //0205-机动车查验记录表
            {
                vehicle_check_jcjlb(pvehicle_inf, i, alg, result, (char *)"0205");
            }
            else if(pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.WanShuiZhengMing)//0206-车船税纳税或者免税证明
            {
                vehicle_check_ccs_or_ms(pvehicle_inf, i, alg, result);
            }
            else if(pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.WeiTuoTongZhiShu)//0207- 委托核发检验合格标志通知书
            {
                vehicle_check_hgbztzs(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == jyhgzm) // 南京的0212照片，是检测站出具的“机动车检验合格证明”。
            {
                NanJing_jyhgzm(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.WeiTuoShu)  // 委托书
            {
                vehicle_check_wts(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.ShenFenZheng)  // 0215 - 身份证（正面）（深圳）
            {
                vehicle_check_sfz(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == jqx2)  // 0210 - 安顺交强险2
            {
                vehicle_check_jqx2(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.JianCeQuXianBaoGao)  // 0213 -机动车制动检测曲线报告（黔东南）
            {
                vehicle_check_jcqxbg(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.ShenFenZhengBeiMian)  // 0216 - 身份证（反面） （深圳）
            {
                vehicle_check_sfz_back(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.JianYanBaoGao_RenGong) // 机动车安全技术检验表(人工检验表)
            {
                vehicle_check_jyb_rg(pvehicle_inf, i, alg, result, (char *)jyb_rg.c_str());
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.JianYanBaoGao_YiQi) // 机动车安全技术检验表（仪器部分)
            {
                vehicle_check_jyb_yq(pvehicle_inf, i, alg, result, (char *)jyb_yq.c_str());
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.WeiQiJianYan)  // 按城市区分 -污染物检测报告
            {
                if(g_CheckItem.City == TIANJIN)
                {
                    int index_j;
                    unsigned int j;
                    for (j = 0; j < pvehicle_inf->m_zplist.size(); j++) {
                        if ((pvehicle_inf->m_zplist[j].zptype == ZhaoPianZL.WeiQiJianYan2) && (pvehicle_inf->m_zplist[j].local_path != "TBD")) {
                            index_j = j;
                            break;
                        }
                    }

                    if (j == pvehicle_inf->m_zplist.size()) {
                        index_j = -1;
                    }
                    vehicle_check_wrw_tianjin(pvehicle_inf, i, index_j, alg, result);

                }
                else
                {
                    vehicle_check_wrw(pvehicle_inf, i, alg, result);
                }

            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.WeiQiJianYan2)  // 按城市区分 -污染物检测报告
            {
                vehicle_check_wrw2(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.JianYanBiaoBeiMian)  // 0298 - 查验记录表反面 （宁波）
            {
                vehicle_check_jyb_back(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.XingShiZhengBeiMian)  // 行驶证反面
            {
                vehicle_check_xsz_back(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.ZuoDengGuang)//0321-左灯光工位照片
            {
                if (!DengGuangPictureProcessed) {
                    int index_j;
                    unsigned int j;
                    for (j = 0; j < pvehicle_inf->m_zplist.size(); j++) {
                        if ((pvehicle_inf->m_zplist[j].zptype == "0352") && (pvehicle_inf->m_zplist[j].local_path != "TBD")) {
                            index_j = j;
                            break;
                        }
                    }

                    if (j == pvehicle_inf->m_zplist.size()) {
                        index_j = -1;
                    }

                    DengGuangPictureProcessed = true;
                    vehicle_check_dggw(pvehicle_inf, i, index_j, alg, result);
                }
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.ZhuCheZhiDong)//0351 - 驻车制动工位照片
            {
                vehicle_check_ZhuCheZhiDong(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.YouDengGuang)//0352-右灯光工位照片
            {
                if (!DengGuangPictureProcessed) {
                    int index_j;
                    unsigned int j;
                    for (j = 0; j < pvehicle_inf->m_zplist.size(); j++) {
                        if ((pvehicle_inf->m_zplist[j].zptype == "0321") && (pvehicle_inf->m_zplist[j].local_path != "TBD")) {
                            index_j = j;
                            break;
                        }
                    }

                    if (j == pvehicle_inf->m_zplist.size()) {
                        index_j = -1;
                    }

                    DengGuangPictureProcessed = true;
                    vehicle_check_dggw(pvehicle_inf, index_j, i, alg, result);
                }
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.YiZhouZhiDong)//0322-一轴制动工位照片
            {
                if(g_CheckItem.City==QINGHAI)
                {
                    int index_j;
                    unsigned int j;
                    for (j = 0; j < pvehicle_inf->m_zplist.size(); j++) {
                        if ((pvehicle_inf->m_zplist[j].zptype == "0348") && (pvehicle_inf->m_zplist[j].local_path != "TBD")) {
                            index_j = j;
                            break;
                        }
                    }

                    if (j == pvehicle_inf->m_zplist.size()) {
                        index_j = i;
                    }

                    vehicle_check_zd(pvehicle_inf, i, index_j, alg, result);
                }
                else
                {
                    int index_j;
                    unsigned int j;
                    for (j = 0; j < pvehicle_inf->m_zplist.size(); j++) {
                        if ((pvehicle_inf->m_zplist[j].zptype == "0348") && (pvehicle_inf->m_zplist[j].local_path != "TBD")) {
                            index_j = j;
                            break;
                        }
                    }

                    if (j == pvehicle_inf->m_zplist.size()) {
                        index_j = -1;
                    }

                    vehicle_check_zd(pvehicle_inf, i, index_j, alg, result);
                }
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.WeiXiangNeiBu) // 0101 - 尾箱内部
            {
                vehicle_check_wxnb(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.ZuoQianFang) //0111 - 车辆左前方斜视45度照片
            {
                int index_j = -1;
                unsigned int j = 0;
                if (g_CheckItem.picture.ZuoQianFang.GaiZhuang) {
                    /* 查询档案照片*/
                    for (j = 0; j < pvehicle_inf->m_zplist.size(); j++) {
                        if ((pvehicle_inf->m_zplist[j].zptype == "A") && (pvehicle_inf->m_zplist[j].local_path != "TBD")) {
                            index_j = j;
                            break;
                        }
                    }

                    if (j == pvehicle_inf->m_zplist.size()) {
                        index_j = -1;
                    }
                }

                if (g_CheckItem.City == SUZHOU) {
                    for (unsigned int i = 0; i < pvehicle_inf->m_zplist.size(); i++) {
                        if (pvehicle_inf->m_zplist[i].zptype == "A_HIS") {
                            index_j = i;
                        }
                    }
                }

                if (index_j != -1) {
                    result.ZuoQianFang_A = true;
                }

                vehicle_check_zqf(pvehicle_inf, i, index_j, alg, result);
            }
            else if ((pvehicle_inf->m_zplist[i].zptype == "0390") && (g_CheckItem.City == FOSHAN)) //0390 - 车辆左前触发照片（佛山用2018-12-27）
            {
                // 暂时只检测车牌，和左前方拍摄时间10s检测后面看需求
                vehicle_check_zqf_yhf_cjh_cf(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.ZuoFang) //0175 - 车辆左方照片(安顺)
            {
                int index_j = -1;
                unsigned int j = 0;
                if (g_CheckItem.picture.ZuoFang.GaiZhuang) {
                    /* 查询档案照片*/
                    for (j = 0; j < pvehicle_inf->m_zplist.size(); j++) {
                        if ((pvehicle_inf->m_zplist[j].zptype == "A") && (pvehicle_inf->m_zplist[j].local_path != "TBD")) {
                            index_j = j;
                            break;
                        }
                    }

                    if (j == pvehicle_inf->m_zplist.size()) {
                        index_j = -1;
                    }
                }

                if (index_j != -1) {
                    result.ZuoQianFang_A = true;
                }

                vehicle_check_zqf(pvehicle_inf, i, index_j, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.YouHouFang) //0112-车辆右后方斜视45度照片
            {
                vehicle_check_yhf(pvehicle_inf, i, alg, result);
            }
            else if ((pvehicle_inf->m_zplist[i].zptype == "0391") && (g_CheckItem.City == FOSHAN)) //0391 - 车辆右后触发照片（佛山用2018-12-27）
            {
                // 暂时只检测车牌，和右后方拍摄时间10s检测后面看需求
                vehicle_check_zqf_yhf_cjh_cf(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.CheJiaHao)//0113-车辆识别代号照片
            {
                unsigned int j = 0;
                unsigned int k = 0;
                int index_j = -1;
                int index_k = -1;

                if(g_CheckItem.City == SUZHOU)
                {
                    result.suzhou_compareType = 1;
                }

                if (g_CheckItem.picture.CheJiaHao.TaYinMo) {
                    /* 查询“拓印膜”档案照片 */
                    for (j = 0; j < pvehicle_inf->m_zplist.size(); j++) {
                        if ((pvehicle_inf->m_zplist[j].zptype == "J") && (pvehicle_inf->m_zplist[j].local_path != "TBD")) {
                            index_j = j;
                            break;
                        }
                    }

                    if (j == pvehicle_inf->m_zplist.size()) {
                        index_j = -1;
                    }
                }

                if (index_j != -1) {
                    result.TaYinMo_J = true;
                    if(g_CheckItem.City == SUZHOU)
                    {
                        result.suzhou_compareType = 0;
                    }
                }

                if (g_CheckItem.picture.CheJiaHao.JiLuBiaoZiMo) {
                    /* 查询“拓印膜”档案照片 */
                    for (k = 0; k < pvehicle_inf->m_zplist.size(); k++) {
                        if ((pvehicle_inf->m_zplist[k].zptype == "0205") && (pvehicle_inf->m_zplist[k].local_path != "TBD")) {
                            index_k = k;
                            break;
                        }
                    }

                    if (k == pvehicle_inf->m_zplist.size()) {
                        index_k = -1;
                    }
                }

                if (g_CheckItem.City == SUZHOU) {
                    for (unsigned int i = 0; i < pvehicle_inf->m_zplist.size(); i++) {
                        if (pvehicle_inf->m_zplist[i].zptype == "J_HIS") {
                            index_j = i;
                            result.TaYinMo_J = true;
                            if(g_CheckItem.City == SUZHOU)
                            {
                                result.suzhou_compareType = 1;
                            }
                        }
                    }
                }

                vehicle_check_cjh(pvehicle_inf, i, index_j, index_k, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.ZuoQianLun)//0136-左前轮规格型号
            {
                vehicle_check_zql(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.QianHaoPai)//0129-前号牌特写照片
            {
                int j = -1;
                vehicle_check_zqf(pvehicle_inf, i, j, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.HouHaoPai)//0131-后号牌特写照片
            {
                int j = -1;
                vehicle_check_zqf(pvehicle_inf, i, j, alg, result);
            }
            else if ((pvehicle_inf->m_zplist[i].zptype == "0392") && (g_CheckItem.City == FOSHAN)) //0392 - 车架号触发照片（佛山用2018-12-27）
            {
                // 暂时只检测车牌，和车架号拍摄时间10s检测后面看需求
                vehicle_check_zqf_yhf_cjh_cf(pvehicle_inf, i, alg, result);
            }
            else if((g_CheckItem.City == FUZHOU2) && (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.CheLiangCeMian))
            {
                vehicle_check_clcm2(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.CheLiangCeMian)	// - 车辆侧面 (南昌)
            {
                vehicle_check_clcm(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.GaoZhiShu)	//0206 - 告知书
            {
                vehicle_check_GaoZhiShu(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.RongQueShouLi)	//0206 - 告知书
            {
                vehicle_check_RongQueShouLi(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.CheLiangMingPai)	// - 车辆名牌 (连云港)
            {
                DATA_PRINT(LEVEL_INFO, " - 车辆铭牌 (连云港)\n");
                vehicle_check_clmp(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.CheJiaHaoUG)	//0120 - 玻璃下车架号 (连云港)
            {
                vehicle_check_cjh_ug(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == cjhyj)	//0168-车架号远景(天津)
            {
                vehicle_check_cjhyj(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.CheLiangBeiMian)	//0158 - 车辆正后方照片
            {
                vehicle_check_clbm(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.QianHaoPai)	//0167-车辆正前方牌照(安顺)
            {
                vehicle_check_qhp(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.HouHaoPai)	//0168-车辆正后方牌照(安顺)
            {
                vehicle_check_hhp(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.DaCheHaoPai)	//0170-车牌(南宁)0164(上饶)
            {
                vehicle_check_dchp(pvehicle_inf, i, alg, result);
            }
            else if(pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.QianHaoPaiTeXie)
            {
                vehicle_check_hpls(pvehicle_inf, i, alg, result,true);
            }
            else if(pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.HouHaoPaiTeXie)
            {
                vehicle_check_hpls(pvehicle_inf, i, alg, result,false);
            }
         /* 0115-车厢内部照片
            0116-灭火器照片
            0117-应急锤照片
            0127-急救箱
            0118-行驶记录装置照片*/
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.AnQuanDai)//0157 - 驾驶人座椅汽车安全带
            {
                vehicle_check_aqd(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.DiPanDongTaiKaiShi)//0344 - 底盘动态检验开始照片
            {
                int index;
                unsigned int j;
                for (j = 0; j < pvehicle_inf->m_zplist.size(); j++) {
                    if ((pvehicle_inf->m_zplist[j].zptype == "0342") && (pvehicle_inf->m_zplist[j].local_path != "TBD")) {
                        index = j;
                        break;
                    }
                }

                if (j == pvehicle_inf->m_zplist.size()) {
                    index = -1;
                }

                vehicle_check_DiPanDongTai(pvehicle_inf, i, index, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.DiPanBuJian)	//0323 - 底盘检验照片
            {
                vehicle_check_DiPan(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.MieHuoQi)	//0116 - 灭火器照片
            {
                vehicle_check_MieHuoQi(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.YingJiChui)	//0117 - 应急锤照片
            {
                vehicle_check_YingJiChui(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.JiLuYi)	//0118 - 行驶记录装置照片
            {
                vehicle_check_JiLuYi(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.HeDingZaiKe)	//0135 - 核定载客人数(南昌)
            {
                vehicle_check_hdzk(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.YouQianLun)	//0154 - 右前轮胎规格型号
            {
                vehicle_check_yql(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.CheXiang)    //0115 - 车厢内部照片 //0166 0164zjj
            {
                vehicle_check_CheXiang(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.HouPaiCheXiang)    //0166 - 车厢内部照片
            {
                vehicle_check_HouPaiCheXiang(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.HouPaiCheXiang2)    //0164 - 车厢内部照片
            {
                vehicle_check_HouPaiCheXiang2(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.CeHuaGongWei)    //0353 - 侧滑工位照片
            {
                vehicle_check_CeHuaGongWei(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.WaiKuoQianMian)    //0360 - 外廓尺寸自动测量前面照片//张家界大车背面（张家界大车背面>3500kg检测防护栏）
            {
                vehicle_check_WaiKuoQianMian(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.WaiKuoCeMian)    //0361 - 外廓尺寸自动测量侧面照片//张家界大车侧面（张家界大车背面>3500kg检测防护栏）
            {
                vehicle_check_WaiKuoCeMian(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.FuZhuZhiDong)    //0130-辅助制动装置
            {
                vehicle_check_fzzd(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == "0210" && g_CheckItem.City == NANCHONG) { // 南充： 0210- 营业执照
                processYingYeZhiZhao(pvehicle_inf, i, alg, result);
            }
            else if(pvehicle_inf->m_zplist[i].zptype == "0214" && g_CheckItem.City == YICHUN) { //宜春： 0214- 营业执照
                processYingYeZhiZhao(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.ABS)    //0134-防抱死制动装置自检状态灯
            {
                vehicle_check_abs(pvehicle_inf, i, alg, result);
            }
            // 小车轮胎规格和车厢内部
            else if (pvehicle_inf->m_zplist[i].zptype=="01") // 01-车厢内部调用
            {
                vehicle_check_wxnb(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == "02") // 02-左前轮规格型号
            {
                vehicle_check_zql(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == "03") // 03-右前轮规格型号
            {
                vehicle_check_yql(pvehicle_inf, i, alg, result);
            }
            // 大车轮胎花纹处理 3rd
            else if (pvehicle_inf->m_zplist[i].zptype == "04" )	// 04 - 大车左一轮胎花纹
            {
                // 05 - 查找大车右一轮胎花纹
                unsigned int j = 0;
                for (; j < pvehicle_inf->m_zplist.size(); j++) {
                    if ( pvehicle_inf->m_zplist[j].zptype == "05") {
                        break;
                    }
                }
                vehicle_check_dchw(pvehicle_inf, i, j, alg, result, "04");
            }
            else if ( pvehicle_inf->m_zplist[i].zptype == "06" )	//06 - 大车左二轮胎花纹
            {
                // 07 - 查找大车右二轮胎花纹
                unsigned int j = 0;
                for (; j < pvehicle_inf->m_zplist.size(); j++) {
                    if ( pvehicle_inf->m_zplist[j].zptype == "07" ) {
                        break;
                    }
                }
                vehicle_check_dchw(pvehicle_inf, i, j, alg, result, "06");
            }
            else if ( pvehicle_inf->m_zplist[i].zptype == "08" )	//08 - 大车左三轮胎花纹
            {
                // 07 - 查找大车右三轮胎花纹
                unsigned int j = 0;
                for (; j < pvehicle_inf->m_zplist.size(); j++) {
                    if ( pvehicle_inf->m_zplist[j].zptype == "09" ) {
                        break;
                    }
                }
                vehicle_check_dchw(pvehicle_inf, i, j, alg, result, "08");
            }
            else if(pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.QianLunZhaoPian)
            {
                vehicle_check_QianHouLunZhaoPian(pvehicle_inf, i, alg, result, true);
            }
            else if(pvehicle_inf->m_zplist[i].zptype == ZhaoPianZL.HouLunZhaoPian)
            {
                vehicle_check_QianHouLunZhaoPian(pvehicle_inf, i, alg, result, false);
            } else if (g_CheckItem.City == QINGHAI && pvehicle_inf->m_zplist[i].zptype == "0299") {
                process_LuShiJiLuDan(pvehicle_inf, i, alg, result);
            } else if (g_CheckItem.City == QINGHAI && pvehicle_inf->m_zplist[i].zptype == "0341") {
                process_LuShiKaiShi(pvehicle_inf, i, alg, result);
            } else if (g_CheckItem.City == QINGHAI && pvehicle_inf->m_zplist[i].zptype == "0345") {
                process_LuShiJieShu(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == "0150" && g_CheckItem.City == DEZHOU)
            {
                vehicle_check_QianLunTaiHuaWen(pvehicle_inf, i, alg, result);
            }
            else if (pvehicle_inf->m_zplist[i].zptype == "0151" && g_CheckItem.City == DEZHOU)
            {
                vehicle_check_HouLunTaiHuaWen(pvehicle_inf, i, alg, result);
            }
            else if(g_CheckItem.City == ZHAOTONG && pvehicle_inf->m_zplist[i].zptype == "0298")
            {
                vehicle_check_WaiKuoChiCunJiLuDan(pvehicle_inf, i, alg, result);
            }
            else if(g_CheckItem.City == ZHAOTONG && pvehicle_inf->m_zplist[i].zptype == "0190")
            {
                vehicle_check_FanGuangBiaoShi(pvehicle_inf, i, alg, result);
            }
            /*			0134-防抱死制动装置自检状态灯
            0132-发动机舱自动灭火装置
            0133-前轮盘式制动器
            0136-左前轮胎规格型号
            0154-右前轮胎规格型号
            0155-左后轮胎规格型号
            0156-右后轮胎规格型号
            0135-残疾车操纵辅助装置
            0140-教练车副制动踏板
            0163-危险货物运输车标志
            0126-校车停车指示标志牌照片
            0128-校车标志灯照片
            0138-校车、卧铺客车的车内外录像监控系统
            0139-校车的辅助倒车装置
            0159-校车标牌（前）正面照片
            0160-校车标牌（前）反面照片
            0161-校车标牌（后）正面照片
            0321-左灯光工位照片
            0352-右灯光工位照片
            0322 - 一轴制动工位照片
            0348 - 二轴制动工位照片
            0349 - 三轴制动工位照片
            0350 - 四轴制动工位照片
            0354 - 五轴制动工位照片
            0351 - 驻车制动工位照片
            0347 - 车速表工位照片
            0353 - 侧滑工位照片
            0341 - 路试行车制动开始照片
            0343 - 路试行车制动结束照片
            0345 - 路试坡度驻车制动照片
            0344 - 底盘动态检验开始照片
            0342 - 底盘动态检验结束照片
            0323 - 底盘检验照片
            0356 - 一轴加载制动工位照片
            0357 - 二轴加载制动工位照片
            0358 - 三轴加载制动工位照片
            0359 - 四轴加载制动工位照片
            0360 - 外廓尺寸自动测量前面照片
            0361 - 外廓尺寸自动测量侧面照片
            0362 - 整备质量测量左前45度照片
            0363 - 整备质量测量右后45度照片
            */
            else
            {
                DATA_PRINT(LEVEL_INFO, "照片类型不在软件处理范围内:%s \n", pvehicle_inf->m_zplist[i].zptype.c_str());
            }
        }
        catch (exception e)
        {
            DATA_PRINT(LEVEL_ERROR, "Photo exception! (type=%s) (path=%s) \n",
                       pvehicle_inf->m_zplist[i].zptype.c_str(), pvehicle_inf->m_zplist[i].local_path.c_str());

            DATA_PRINT(LEVEL_ERROR, "Exception cause: %s \n", e.what());

            std::string v_filename = pvehicle_inf->m_zplist[i].local_path;
            cv::Mat crashfile = cv::imread(v_filename.c_str());
            v_filename += "_crash.jpg";
            imwrite(v_filename.c_str(), crashfile);

            DATA_PRINT(LEVEL_ERROR, "Photo(%s) has been saved! \n", v_filename.c_str());
        }
    }

    for (unsigned int i = 0; i < pvehicle_inf->m_splist.size(); i++){
        if(pvehicle_inf->m_splist[i].spzl == "V0111")
        {
            vehicle_videocheck_zqf(pvehicle_inf, i, alg, result);
        }
        else if(pvehicle_inf->m_splist[i].spzl == "V0112")
        {
            vehicle_videocheck_yhf(pvehicle_inf, i, alg, result);
        }
        else if(pvehicle_inf->m_splist[i].spzl == "V0322")
        {
            unsigned int k;
            for(k = 0;k < pvehicle_inf->m_splist.size();k++)
            {
                if(pvehicle_inf->m_splist[k].spzl == "V0348")
                {
                    vehicle_videocheck_zd(pvehicle_inf, i, k, 1, alg, result);
                    break;
                }
            }
            if(k == pvehicle_inf->m_splist.size())
            {
                k = -1;
                vehicle_videocheck_zd(pvehicle_inf, i, k, 1, alg, result);
            }
        }
        else if(pvehicle_inf->m_splist[i].spzl == "V0321")
        {
            vehicle_videocheck_zdggw(pvehicle_inf, i, alg, result);
        }
        else if(pvehicle_inf->m_splist[i].spzl == "V0352")
        {
            vehicle_videocheck_ydggw(pvehicle_inf, i, alg, result);
        }
        else if(pvehicle_inf->m_splist[i].spzl == "V0323")
        {
            vehicle_videocheck_dp(pvehicle_inf, i, alg, result);
        }
        else if (pvehicle_inf->m_splist[i].spzl == "V0344")
        {
            vehicle_videocheck_dpdtks(pvehicle_inf, i, alg, result);
        }
        else if (pvehicle_inf->m_splist[i].spzl == "V0342")
        {
            vehicle_videocheck_dpdtjs(pvehicle_inf, i, alg, result);
        }
        else if (pvehicle_inf->m_splist[i].spzl == "V0351")
        {
            vehicle_videocheck_zczd(pvehicle_inf, i, alg, result);
        }

       if(g_CheckItem.City == YICHUN)
       {
          if(pvehicle_inf->m_splist[i].spzl.find("F1") != string::npos)
          {
              DATA_PRINT(LEVEL_INFO, "vehicle_videocheck_zqf spzl:%s, path:%s\n", pvehicle_inf->m_splist[i].spzl.c_str(), pvehicle_inf->m_splist[i].local_path.c_str());
              vehicle_videocheck_zqf(pvehicle_inf, i, alg, result);
          }
          else if(pvehicle_inf->m_splist[i].spzl.find("F2") != string::npos)
          {
              DATA_PRINT(LEVEL_INFO, "vehicle_videocheck_yhf spzl:%s, path:%s\n", pvehicle_inf->m_splist[i].spzl.c_str(), pvehicle_inf->m_splist[i].local_path.c_str());
              vehicle_videocheck_yhf(pvehicle_inf, i, alg, result);
          }
          else if(pvehicle_inf->m_splist[i].spzl.find("B") != string::npos && pvehicle_inf->m_splist[i].spzl.find("B1") == string::npos)
          {//yi zhou
              unsigned int k;
              for(k = 0;k < pvehicle_inf->m_splist.size();k++)
              {
                  if(pvehicle_inf->m_splist[i].spzl.find("B1") != string::npos)
                  {//er zhou
                      vehicle_videocheck_zd(pvehicle_inf, i, k, 1, alg, result);
                      break;
                  }
              }
              if(k == pvehicle_inf->m_splist.size())
              {
                  k = -1;
                  vehicle_videocheck_zd(pvehicle_inf, i, k, 1, alg, result);
              }
          }
          else if(pvehicle_inf->m_splist[i].spzl.find("H") != string::npos)
          {
               DATA_PRINT(LEVEL_INFO, "vehicle_videocheck_dggw spzl:%s, path:%s\n", pvehicle_inf->m_splist[i].spzl.c_str(), pvehicle_inf->m_splist[i].local_path.c_str());
               vehicle_videocheck_dggw(pvehicle_inf, i, alg, result);
          }
          else if(pvehicle_inf->m_splist[i].spzl.find("DC") != string::npos)
          {
               DATA_PRINT(LEVEL_INFO, "vehicle_videocheck_dpdt spzl:%s, path:%s\n", pvehicle_inf->m_splist[i].spzl.c_str(), pvehicle_inf->m_splist[i].local_path.c_str());
               vehicle_videocheck_dpdt(pvehicle_inf, i, alg, result);
          }
          else if(pvehicle_inf->m_splist[i].spzl.find("C") != string::npos || pvehicle_inf->m_splist[i].spzl.find("C1") != string::npos)
          {
               DATA_PRINT(LEVEL_INFO, "vehicle_videocheck_dp spzl:%s, path:%s\n", pvehicle_inf->m_splist[i].spzl.c_str(), pvehicle_inf->m_splist[i].local_path.c_str());
               vehicle_videocheck_dp(pvehicle_inf, i, alg, result);
          }
          else if(pvehicle_inf->m_splist[i].spzl.find("B0") != string::npos)
          {
              DATA_PRINT(LEVEL_INFO, "vehicle_videocheck_zczd spzl:%s, path:%s\n", pvehicle_inf->m_splist[i].spzl.c_str(), pvehicle_inf->m_splist[i].local_path.c_str());
              vehicle_videocheck_zczd(pvehicle_inf, i, alg, result);
          }
       }

//        string urlc = pvehicle_inf->m_splist[i].spurl;
//        if (urlc.find("HK_brake1") != -1){	//平板制动
//            int j=-1;
//            int flag = 0;
//            vehicle_videocheck_zd(pvehicle_inf, i, j, flag, alg, result);
//        }
//        if (urlc.find("YW_brake1") != -1){    //一二轴制动
//            int k;
//            for (k = 0; k<pvehicle_inf->m_splist.size();k++)
//            {
//                string::size_type idxc;
//                string urlcc = pvehicle_inf->m_splist[k].spurl;
//                if ((idxc = urlcc.find("YW_brake2")) != std::string::npos)
//                    break;
//                if (pvehicle_inf->m_splist.size() == k){
//                    k = -1;
//                }
//            }
//            int flag = 1;
//            vehicle_videocheck_zd(pvehicle_inf, i, k, flag, alg, result);
//        }
//        if (urlc.find("lightlfar") != -1){	//左灯光
//            vehicle_videocheck_zdggw(pvehicle_inf, i, alg, result);
//        }
//        if (urlc.find("lightrfar")!= -1){	//右灯光
//            vehicle_videocheck_ydggw(pvehicle_inf, i, alg, result);
//        }
//        if (urlc.find("leftfront") != -1){	//左前
//            vehicle_videocheck_zqf(pvehicle_inf, i, alg, result);
//        }
//        if (urlc.find("rightback") != -1){	//右后
//            vehicle_videocheck_yhf(pvehicle_inf, i, alg, result);
//        }
//        if (urlc.find("bottom") != -1){	//底盘
//            vehicle_videocheck_dp(pvehicle_inf, i, alg, result);
//        }
//        if (urlc.find("YW_breakh") != -1){	//滚筒驻车
//            vehicle_videocheck_glzczd(pvehicle_inf, i, alg, result);
//        }
//        if (urlc.find("HK_brakeh") != -1){	//平板驻车
//            vehicle_videocheck_pbzczd(pvehicle_inf, i, alg, result);
//        }

    }

#ifdef DEMO_TEST
    //SQL语句生成
    //			demo_sqlString0.Empty();
    //			demo_sqlString.Empty();
    demo_sqlString = "";
    demo_sqlString0 = "("
                      "vehicle_check_id, lsh,"
                      "zqf_Cheliang_chepai,zqf_Cheliang_chebiao, zqf_Cheliang_sanjiaojia, zqf_Cheliang_tiehua,zqf_Cheliang_b_ori_waiguan, zqf_Cheliang_b_chepai, zqf_Cheliang_b_chebiao, zqf_Cheliang_b_sanjiaojia,"
                      "yhf_Cheliang_chepai, yhf_Cheliang_chebiao,yhf_Cheliang_sanjiaojia, yhf_Cheliang_tiehua, yhf_Cheliang_b_ori_waiguan, yhf_Cheliang_b_chepai, yhf_Cheliang_b_chebiao, yhf_Cheliang_b_sanjiaojia,"
                      "Anquandai_r, Anquandai_b_anquandai, Chejiahao_r, Chejiahao_b_pic_quality, Chejiahao_b_chejiahao, "
                      "Baodan_hongzhan, Baodan_roi, Baodan_chechuanshui, Baodan_chepai, Baodan_chejiahao,"
                      "Baodan_start_riqi, Baodan_end_riqi, Baodan_fuben,"
                      "Baodan_b_pic_quality,Baodan_b_baodan,Baodan_b_riqi, Baodan_b_fuben,Baodan_b_chechuanshui,"
                      "Xingshizheng_xingshizheng,Xingshizheng_xingshizheng_fuye,Xingshizheng_chepai,Xingshizheng_chejiahao,Xingshizheng_fazhengriqi,"
                      "Xingshizheng_chepai_fuye,Xingshizheng_danganhao_fuye,Xingshizheng_tiaoxingma_fuye,"
                      "Xingshizheng_b_pic_quality,Xingshizheng_b_xingshizheng,Xingshizheng_b_fazhengriqi,"
                      "Xingshizheng_b_danganhao,Xingshizheng_b_tiaoxingma,"
                      "Jianyanbaogao_hongzhang,Jianyanbaogao_auxiliary,Jianyanbaogao_compare,"
                      "Jianyanbaogao_qianming,Jianyanbaogao_jianyanjielun,Jianyanbaogao_chejiahao,Jianyanbaogao_chepai,"
                      "Jianyanbaogao_b_pic_quality,Jianyanbaogao_b_jianyanbaogao,Jianyanbaogao_b_qianming,Jianyanbaogao_b_hongzhang,Jianyanbaogao_b_jianyanjielun,Jianyanbaogao_b_jianyan_info,"
                      "Shenqingdan_chepai,Shenqingdan_qianming,Shenqingdan_telephone,Shenqingdan_s_telephone,Shenqingdan_b_pic_quality,Shenqingdan_b_chepai,Shenqingdan_b_qianming,"
                      "Huanbaodan_table,Huanbaodan_chepai,Huanbaodan_chejiahao,Huanbaodan_yinzhang,Huanbaodan_qianzi,Huanbaodan_jiancejielun,"
                      "Huanbaodan_b_jiancejielun,Huanbaodan_b_chepai,Huanbaodan_b_chejiahao,Huanbaodan_b_yinzhang,Huanbaodan_b_qianzi,"
                      "Jianyanbiao_table,Jianyanbiao_rect1,Jianyanbiao_rect2,Jianyanbiao_rect3,Jianyanbiao_b_jianyanbiao,Jianyanbiao_b_waiguan_sign,Jianyanbiao_b_yinche_sign,Jianyanbiao_b_dipan_sign,"
                      "Dengguang_chepai,Dengguang_leftRt,Dengguang_rightRt,Dengguang_chepai_2,Dengguang_leftRt_2,Dengguang_rightRt_2,Dengguang_b_light_on,Dengguang_b_chepai,"
                      "Zhidong_chepai,Zhidong_chepai_2,Zhidong_b_zhidong,Zhidong_b_chepai,"
                      "Dipandongtai_chepai_1,Dipandongtai_chepai_2,Dipandongtai_b_move,Dipandongtai_b_chepai,Dipandongtai_date_stamp,"
                      "Dipan_chepai,Dipan_b_dipan,Dipan_b_chepai,Dipan_date_stamp,conclusion"
                      ")"
                      " VALUES "
                      "(";
    if (demo_data.zqf)//左前方图片信息
    {
        std::string demoCSbuffer;
        cvRect2CString(demo_data.zqf_Cheliang_chepai, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;//1
        demo_sqlString += "',";
        //demoCSbuffer.Empty();
        cvRect2CString(demo_data.zqf_Cheliang_chebiao, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;//2
        demo_sqlString += "',";
        //demoCSbuffer.Empty();
        cvRect2CString(demo_data.zqf_Cheliang_sanjiaojia, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;//3
        demo_sqlString += "',";
        //demoCSbuffer.Empty();
        cvRect2CString(demo_data.zqf_Cheliang_refit, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;//4
        demo_sqlString += "',";
        //demoCSbuffer.Empty();
        if (demo_data.zqf_Cheliang_b_ori_waiguan)
        {
            demo_sqlString += "'1',";//5
        }
        else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.zqf_Cheliang_b_chepai)
        {
            demo_sqlString += "'1',";//6
        }
        else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.zqf_Cheliang_b_chebiao)
        {
            demo_sqlString += "'1',";//7
        }
        else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.zqf_Cheliang_b_sanjiaojia)
        {
            demo_sqlString += "'1',";
        } else
        {
            demo_sqlString += "'0',";
        }
    }
    else
    {
        demo_sqlString += "' ',' ',' ',' ',' ',' ',' ',' ',";
    }
    if (demo_data.yhf)//右后方图片信息
    {
        std::string demoCSbuffer;
        cvRect2CString(demo_data.yhf_Cheliang_chepai, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        //			demoCSbuffer.Empty();
        cvRect2CString(demo_data.yhf_Cheliang_chebiao, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        //			demoCSbuffer.Empty();
        cvRect2CString(demo_data.yhf_Cheliang_sanjiaojia, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        //			demoCSbuffer.Empty();
        cvRect2CString(demo_data.yhf_Cheliang_refit, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        //			demoCSbuffer.Empty();
        if (demo_data.yhf_Cheliang_b_ori_waiguan)
        {
            demo_sqlString += "'1',";
        }
        else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.yhf_Cheliang_b_chepai)
        {
            demo_sqlString += "'1',";
        }
        else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.yhf_Cheliang_b_chebiao)
        {
            demo_sqlString += "'1',";//14
        }
        else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.yhf_Cheliang_b_sanjiaojia)
        {
            demo_sqlString += "'1',";
        } else
        {
            demo_sqlString += "'0',";
        }
    }
    else
    {
        demo_sqlString += "' ',' ',' ',' ',' ',' ',' ',' ',";
    }
    if (demo_data.aqd)//安全带
    {
        std::string demoCSbuffer;
        cvRect2CString(demo_data.Anquandai_r, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        //			demoCSbuffer.Empty();
        if (demo_data.Anquandai_b_anquandai)
        {
            demo_sqlString += "'1',";
        } else
        {
            demo_sqlString += "'0',";
        }
    }
    else
    {
        demo_sqlString += "' ',' ',";
    }
    if (demo_data.cjh)//车架号
    {
        std::string demoCSbuffer;
        cvRect2CString(demo_data.Chejiahao_r, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        //			demoCSbuffer.Empty();
        if (demo_data.Chejiahao_b_pic_quality)
        {
            demo_sqlString += "'1',";
        }
        else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.Chejiahao_b_chejiahao)
        {
            demo_sqlString += "'1',";//19
        }
        else
        {
            demo_sqlString += "'0',";
        }
    }
    else
    {
        demo_sqlString += "' ',' ',' ',";
    }
    if (demo_data.bd)//保单
    {
        std::string demoCSbuffer;
        cvRect2CString(demo_data.Baodan_hongzhan, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        //			demoCSbuffer.Empty();
        cvRect2CString(demo_data.Baodan_roi, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        //			demoCSbuffer.Empty();
        cvRect2CString(demo_data.Baodan_chechuanshui, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        //			demoCSbuffer.Empty();
        cvRect2CString(demo_data.Baodan_chepai, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        //			demoCSbuffer.Empty();
        cvRect2CString(demo_data.Baodan_chejiahao, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        //			demoCSbuffer.Empty();
        cvRect2CString(demo_data.Baodan_start_riqi, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        //			demoCSbuffer.Empty();
        cvRect2CString(demo_data.Baodan_end_riqi, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        //			demoCSbuffer.Empty();
        cvRect2CString(demo_data.Baodan_fuben, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;//27
        demo_sqlString += "',";
        //			demoCSbuffer.Empty();
        if (demo_data.Baodan_b_pic_quality)
        {
            demo_sqlString += "'1',";
        }
        else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.Baodan_b_baodan)
        {
            demo_sqlString += "'1',";
        }
        else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.Baodan_b_riqi)
        {
            demo_sqlString += "'1',";
        }
        else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.Baodan_b_fuben)
        {
            demo_sqlString += "'1',";//31
        }
        else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.Baodan_b_chechuanshui)
        {
            demo_sqlString += "'1',";//31
        }
        else
        {
            demo_sqlString += "'0',";
        }
    }
    else
    {
        demo_sqlString += "' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',";
    }
    if (demo_data.xsz)//行驶证
    {
        std::string demoCSbuffer;
        cvRect2CString(demo_data.Xingshizheng_xingshizheng, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        //			demoCSbuffer.Empty();
        cvRect2CString(demo_data.Xingshizheng_xingshizheng_fuye, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        //			demoCSbuffer.Empty();
        cvRect2CString(demo_data.Xingshizheng_chepai, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        //			demoCSbuffer.Empty();
        cvRect2CString(demo_data.Xingshizheng_chejiahao, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        //			demoCSbuffer.Empty();
        cvRect2CString(demo_data.Xingshizheng_fazhengriqi, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        //			demoCSbuffer.Empty();
        cvRect2CString(demo_data.Xingshizheng_chepai_fuye, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        //			demoCSbuffer.Empty();
        cvRect2CString(demo_data.Xingshizheng_danganhao_fuye, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        //			demoCSbuffer.Empty();
        cvRect2CString(demo_data.Xingshizheng_tiaoxingma_fuye, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        //			demoCSbuffer.Empty();
        if (demo_data.Xingshizheng_b_pic_quality)
        {
            demo_sqlString += "'1',";
        }
        else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.Xingshizheng_b_xingshizheng)
        {
            demo_sqlString += "'1',";
        }
        else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.Xingshizheng_b_fazhengriqi)//
        {
            demo_sqlString += "'1',";
        }
        else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.Xingshizheng_b_danganhao)//   7.24展示屏蔽
        {
            demo_sqlString += "'1',";
        }
        else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.Xingshizheng_b_tiaoxingma)//   7.24展示屏蔽
        {
            demo_sqlString += "'1',";
        }
        else
        {
            demo_sqlString += "'0',";
        }
    }
    else
    {
        demo_sqlString += "' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',";
    }
    if (demo_data.jybg)//检验报告
    {
        std::string demoCSbuffer;
        cvRect2CString(demo_data.Jianyanbaogao_hongzhang, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        //			demoCSbuffer.Empty();
        cvRect2CString(demo_data.Jianyanbaogao_auxiliary, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        //			demoCSbuffer.Empty();
        cvRect2CString(demo_data.Jianyanbaogao_compare, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        //			demoCSbuffer.Empty();
        cvRect2CString(demo_data.Jianyanbaogao_qianming, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        //			demoCSbuffer.Empty();
        cvRect2CString(demo_data.Jianyanbaogao_jianyanjielun, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        //			demoCSbuffer.Empty();
        cvRect2CString(demo_data.Jianyanbaogao_chejiahao, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        //			demoCSbuffer.Empty();
        cvRect2CString(demo_data.Jianyanbaogao_chepai, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        //			demoCSbuffer.Empty();
        if (demo_data.Jianyanbaogao_b_pic_quality)
        {
            demo_sqlString += "'1',";
        }
        else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.Jianyanbaogao_b_jianyanbaogao)
        {
            demo_sqlString += "'1',";
        }
        else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.Jianyanbaogao_b_qianming)
        {
            demo_sqlString += "'1',";//46
        }
        else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.Jianyanbaogao_b_hongzhang)
        {
            demo_sqlString += "'1',";
        }
        else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.Jianyanbaogao_b_jianyanjielun)
        {
            demo_sqlString += "'1',";
        }
        else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.Jianyanbaogao_b_jianyan_info)
        {
            demo_sqlString += "'1',";//46
        } else
        {
            demo_sqlString += "'0',";
        }
    }
    else
    {
        demo_sqlString += "' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',";
    }
    if (demo_data.sqb)//申请表
    {
        std::string demoCSbuffer;
        cvRect2CString(demo_data.Shenqingdan_chepai, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        cvRect2CString(demo_data.Shenqingdan_qianming, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        cvRect2CString(demo_data.Shenqingdan_telephone, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        demoCSbuffer = demo_data.Shenqingdan_s_telephone;
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        if (demo_data.Shenqingdan_b_pic_quality)
        {
            demo_sqlString += "'1',";
        }
        else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.Shenqingdan_b_chepai)
        {
            demo_sqlString += "'1',";
        }
        else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.Shenqingdan_b_qianming)
        {
            demo_sqlString += "'1',";
        }
        else
        {
            demo_sqlString += "'0',";
        }
    }
    else
    {
        demo_sqlString += "' ',' ',' ',' ',' ',' ',' ',";
    }
    if (demo_data.hbd)//环保单
    {
        std::string demoCSbuffer;
        cvRect2CString(demo_data.Huanbaodan_table, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        cvRect2CString(demo_data.Huanbaodan_chepai, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        cvRect2CString(demo_data.Huanbaodan_chejiahao, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        cvRect2CString(demo_data.Huanbaodan_yinzhang, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        cvRect2CString(demo_data.Huanbaodan_qianzi, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        cvRect2CString(demo_data.Huanbaodan_jiancejielun, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";

        if (demo_data.Huanbaodan_b_jiancejielun)
        {
            demo_sqlString += "'1',";
        } else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.Huanbaodan_b_chepai)
        {
            demo_sqlString += "'1',";
        } else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.Huanbaodan_b_chejiahao)
        {
            demo_sqlString += "'1',";
        } else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.Huanbaodan_b_yinzhang)
        {
            demo_sqlString += "'1',";
        } else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.Huanbaodan_b_qianzi)
        {
            demo_sqlString += "'1',";
        } else
        {
            demo_sqlString += "'0',";
        }
    } else
    {
        demo_sqlString += "' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',";
    }
    if (demo_data.jyb)//检查记录表
    {
        std::string demoCSbuffer;
        cvRect2CString(demo_data.Jianyanbiao_table, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        cvRect2CString(demo_data.Jianyanbiao_rect1, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        cvRect2CString(demo_data.Jianyanbiao_rect2, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        cvRect2CString(demo_data.Jianyanbiao_rect3, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        if (demo_data.Jianyanbiao_b_jianyanbiao)
        {
            demo_sqlString += "'1',";
        }
        else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.Jianyanbiao_b_waiguan_sign)
        {
            demo_sqlString += "'1',";
        }
        else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.Jianyanbiao_b_yinche_sign)
        {
            demo_sqlString += "'1',";
        }
        else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.Jianyanbiao_b_dipan_sign)
        {
            demo_sqlString += "'1',";
        }
        else
        {
            demo_sqlString += "'0',";
        }
    } else
    {
        demo_sqlString += "' ',' ',' ',' ',' ',' ',' ',' ',";
    }
    if (demo_data.dggw)//灯光工位
    {
        std::string demoCSbuffer;
        cvRect2CString(demo_data.Dengguang_chepai, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        cvRect2CString(demo_data.Dengguang_leftRt, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        cvRect2CString(demo_data.Dengguang_rightRt, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        cvRect2CString(demo_data.Dengguang_chepai_2, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        cvRect2CString(demo_data.Dengguang_leftRt_2, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        cvRect2CString(demo_data.Dengguang_rightRt_2, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        if (demo_data.Dengguang_b_light_on)
        {
            demo_sqlString += "'1',";
        }
        else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.Dengguang_b_chepai)
        {
            demo_sqlString += "'1',";
        }
        else
        {
            demo_sqlString += "'0',";
        }
    }
    else
    {
        demo_sqlString += "' ',' ',' ',' ',' ',' ',' ',' ',";
    }
    if (demo_data.zd)//制动
    {
        std::string demoCSbuffer;
        cvRect2CString(demo_data.Zhidong_chepai, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        cvRect2CString(demo_data.Zhidong_chepai_2, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        if (demo_data.Zhidong_b_zhidong)
        {
            demo_sqlString += "'1',";
        }
        else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.Zhidong_b_chepai)
        {
            demo_sqlString += "'1',";
        }
        else
        {
            demo_sqlString += "'0',";
        }
    } else
    {
        demo_sqlString += "' ',' ',' ',' ',";
    }
    if (demo_data.dpdt)//底盘动态
    {
        std::string demoCSbuffer;
        cvRect2CString(demo_data.Dipandongtai_chepai_1, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        cvRect2CString(demo_data.Dipandongtai_chepai_2, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        if (demo_data.Dipandongtai_b_move)
        {
            demo_sqlString += "'1',";
        }
        else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.Dipandongtai_b_chepai)
        {
            demo_sqlString += "'1',";
        }
        else
        {
            demo_sqlString += "'0',";
        }
        demo_sqlString += "'";
        demo_sqlString += demo_data.Dipandongtai_date_stamp;
        demo_sqlString += "',";
    } else
    {
        demo_sqlString += "' ',' ',' ',' ',' ',";
    }
    if (demo_data.dp)//底盘
    {

        std::string demoCSbuffer;
        cvRect2CString(demo_data.Dipan_chepai, demoCSbuffer);
        demo_sqlString += "'";
        demo_sqlString += demoCSbuffer;
        demo_sqlString += "',";
        if (demo_data.Dipan_b_dipan)
        {
            demo_sqlString += "'1',";
        }
        else
        {
            demo_sqlString += "'0',";
        }
        if (demo_data.Dipan_b_chepai)
        {
            demo_sqlString += "'1',";
        }
        else
        {
            demo_sqlString += "'0',";
        }
        demo_sqlString += "'";
        demo_sqlString += demo_data.Dipan_date_stamp;
        demo_sqlString += "',";
    } else
    {
        demo_sqlString += "' ',' ',' ',' ',";
    }

#endif
    for (unsigned int i = 0; i < pvehicle_inf->m_splist.size(); i++)
    {
        DATA_PRINT(LEVEL_INFO, "[sptype=%s url=%s loc=%s]\n",
                   pvehicle_inf->m_splist[i].sptype.c_str(),
                   pvehicle_inf->m_splist[i].spurl.c_str(),
                   pvehicle_inf->m_splist[i].local_path.c_str());

        if (pvehicle_inf->m_splist[i].local_path == "TBD")
        {
            DATA_PRINT(LEVEL_ERROR, "种类为%s的视频未获取成功\n", pvehicle_inf->m_splist[i].dzzl.c_str());

            continue;
        }


        /*
        B-制动工位
        H-灯光工位
        DC-动态底盘工位
        A1-侧滑工位
        C1-底盘工位
        S1-速度工位
        R-路试工位
        M1-外廓测量工位
        F1-外观工位
        L-轮重工位
        Z-称重工位
        */
    }

    std::string tmpString = result.doAnalyse(pvehicle_inf);
    add_zplist(pvehicle_inf);

#ifdef DEMO_TEST
    demo_sqlString += "'";
    demo_sqlString += tmpString;
    demo_sqlString += "'";
    demo_sqlString += ")";

    pvehicle_inf->demo_sqlString0 = demo_sqlString0;
    pvehicle_inf->demo_sqlString = demo_sqlString;
#endif

    pvehicle_inf->AlgorithmCheck = true;
    return 0;
}

void fun_get_car_type(vehicle_inf* pvehicle_inf, std::string &car_type)
{
    if (pvehicle_inf->m_cllx.compare("K30") == 0) {
        car_type = "小型客车";
    } else if (pvehicle_inf->m_cllx.compare("K31") == 0){
        car_type = "小型普通客车";
    } else if (pvehicle_inf->m_cllx.compare("K32") == 0){
        car_type = "小型越野客车";
    } else if (pvehicle_inf->m_cllx.compare("K33") == 0){
        car_type = "小型轿车";
    } else if (pvehicle_inf->m_cllx.compare("K34") == 0){
        car_type = "小型专用客车";
    } else if (pvehicle_inf->m_cllx.compare("K40") == 0){
        car_type = "微型客车";
    } else if (pvehicle_inf->m_cllx.compare("K41") == 0){
        car_type = "微型普通客车";
    } else if (pvehicle_inf->m_cllx.compare("K42") == 0){
        car_type = "微型越野客车";
    } else if (pvehicle_inf->m_cllx.compare("K43") == 0){
        car_type = "微型轿车";
    }
}

void vehicle_check_xsz(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!(g_CheckItem.picture.XingShiZheng.CheJiaHao
          || g_CheckItem.picture.XingShiZheng.ChePai
          || g_CheckItem.picture.XingShiZheng.BianHao
          || g_CheckItem.picture.XingShiZheng.FaZhengRiQi)) {
        DATA_PRINT(LEVEL_INFO, "xsz(0201) has been skipped. \n");
        return;
    }

    std::string CheJiaHao = g_CheckItem.picture.XingShiZheng.CheJiaHao ? pvehicle_inf->m_clsbdh : "";
    std::string ChePai = g_CheckItem.picture.XingShiZheng.ChePai ? pvehicle_inf->m_hphm : "";
    std::string BianHao = g_CheckItem.picture.XingShiZheng.BianHao ? pvehicle_inf->m_xszbh : "";
    std::string FaZhengRiQi = g_CheckItem.picture.XingShiZheng.FaZhengRiQi ? pvehicle_inf->m_fzrq : "";
    std::string QiangZhiBaoFeiRiQi = pvehicle_inf->m_qzbfqz;
    std::string DangAnHao = "";	/* 档案号暂时没有 */
    std::string ZhuCeRiQi = result.formatingDate(pvehicle_inf->m_ccdjrq);

    FaZhengRiQi = result.formatingDate(FaZhengRiQi);
    QiangZhiBaoFeiRiQi= result.formatingDate(QiangZhiBaoFeiRiQi);
    Xingshizheng_ImgOutMsg xszdata;
    cv::Mat m = cv::imread(pvehicle_inf->m_zplist[index].local_path);

    if (g_CheckItem.City == NANCHONG) {
        std::string str_car_type;
        fun_get_car_type(pvehicle_inf, str_car_type);

        pvehicle_inf->timeRecord.startTime();
        alg->xingshizheng_api_process(m, ChePai, CheJiaHao, FaZhengRiQi, DangAnHao, BianHao, str_car_type, pvehicle_inf->m_hdzk,QiangZhiBaoFeiRiQi, ZhuCeRiQi, xszdata);
        pvehicle_inf->timeRecord.endTime();
        pvehicle_inf->timeRecord.picture.process.xsz = pvehicle_inf->timeRecord.getTime();
    } else {
        pvehicle_inf->timeRecord.startTime();
        alg->xingshizheng_api_process(m, ChePai, CheJiaHao, FaZhengRiQi, DangAnHao, BianHao, "", "",QiangZhiBaoFeiRiQi, ZhuCeRiQi, xszdata);
        pvehicle_inf->timeRecord.endTime();
        pvehicle_inf->timeRecord.picture.process.xsz = pvehicle_inf->timeRecord.getTime();
    }

    result.XingShiZheng = xszdata;

#ifdef DEMO_TEST
    {
        string path = pvehicle_inf->m_zplist[index].demo_local_path;
        path += "_1.jpg";
        cv::Mat m_save = m.clone();
        cv::rectangle(m_save, xszdata.r_xingshizheng, cv::Scalar(0, 0, 255), 3);
        cv::rectangle(m_save, xszdata.r_xingshizheng_fuye, cv::Scalar(0, 0, 255), 3);
        cv::imwrite(path, m_save);

        //if (!xszdata.b_xingshizheng) {
        //path = WstringToString(pvehicle_inf->m_zplist[index].demo_local_path);
        //path += "_0.jpg";
        //m_save = m.clone();
        //cv::imwrite(path, m_save);
        //}

        //7.13修改演示内容
        demo_data.xsz = true;
        string path1 = pvehicle_inf->m_zplist[index].demo_local_path;
        path1 += "_xsz_1.jpg"; //经过n*90度初步旋转后的图像
        cv::Mat mx = xszdata.m;
        if (mx.empty())
        {
            mx = m.clone();
            cv::imwrite(path1, mx);
        }
        else
        {
            cv::imwrite(path1, mx);
        }
        demo_data.Xingshizheng_xingshizheng = xszdata.r_xingshizheng;
        demo_data.Xingshizheng_xingshizheng_fuye = xszdata.r_xingshizheng_fuye;


        cv::Mat mxx = xszdata.m_xingshizheng;
        string path2 = pvehicle_inf->m_zplist[index].demo_local_path;
        path2 += "_xsz_2.jpg";//车牌，车架号识别时 旋转后的图片
        cv::imwrite(path2, mxx);

        demo_data.Xingshizheng_chepai = xszdata.r_chepai;
        demo_data.Xingshizheng_chejiahao = xszdata.r_chejiahao;
        demo_data.Xingshizheng_fazhengriqi = xszdata.r_fazhengriqi;

        demo_data.Xingshizheng_b_pic_quality = xszdata.b_pic_quality;
        demo_data.Xingshizheng_b_xingshizheng = xszdata.b_xingshizheng;
        demo_data.Xingshizheng_b_fazhengriqi = xszdata.b_fazhengriqi;
        demo_data.Xingshizheng_b_danganhao = xszdata.b_danganhao;
        demo_data.Xingshizheng_b_tiaoxingma = xszdata.b_tiaoxingma;


        cv::Mat mxxfy = xszdata.m_xingshizheng_fuye;
        string path3 = pvehicle_inf->m_zplist[index].demo_local_path;
        path3 += "_xsz_3.jpg";//副页图片图片
        cv::imwrite(path3, mxxfy);

        demo_data.Xingshizheng_chepai_fuye = xszdata.r_chepai_fuye;
        demo_data.Xingshizheng_danganhao_fuye = xszdata.r_danganhao_fuye;
        demo_data.Xingshizheng_tiaoxingma_fuye = xszdata.r_tiaoxingma_fuye;

    }
#endif
}

void vehicle_check_xsz_back(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!g_CheckItem.picture.XingShiZheng.BeiMian) {
        DATA_PRINT(LEVEL_INFO, "xsz(0299) has been skipped. \n");
        return;
    }

    std::string CheJiaHao = g_CheckItem.picture.XingShiZheng.CheJiaHao ? pvehicle_inf->m_clsbdh : "";
    std::string ChePai = g_CheckItem.picture.XingShiZheng.ChePai ? pvehicle_inf->m_hphm : "";
    std::string BianHao = g_CheckItem.picture.XingShiZheng.BianHao ? pvehicle_inf->m_xszbh : "";
    std::string FaZhengRiQi = g_CheckItem.picture.XingShiZheng.FaZhengRiQi ? pvehicle_inf->m_fzrq : "";
    std::string DangAnHao = "";	/* 档案号暂时没有 */
    std::string QiangZhiBaoFeiRiQi = pvehicle_inf->m_qzbfqz;

    FaZhengRiQi = result.formatingDate(FaZhengRiQi);

    Xingshizheng_ImgOutMsg xszdata;
    cv::Mat m = cv::imread(pvehicle_inf->m_zplist[index].local_path);

    pvehicle_inf->timeRecord.startTime();
    alg->xingshizheng_api_process(m, ChePai, CheJiaHao, FaZhengRiQi, DangAnHao, BianHao, "", "",QiangZhiBaoFeiRiQi, "", xszdata);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.xszbk = pvehicle_inf->timeRecord.getTime();

    result.XingShiZhengBeiMian = xszdata;
}

/*
 *      南京交强险逻辑变更1： 电子数据通过或纸质保单数据通过，交强险算通过
 *      南京交强险逻辑变更2： 电子数据通过并且纸质保单数据通过，交强险算通过
 *      南京交强险逻辑变更3： 电子数据通过或且纸质保单数据通过，交强险算通过
 *      南京交强险逻辑变更4： 先查看电子数据里面是否有在有效期内的保单，有的话跟纸质保单比对一致，再跟基本信息也一致，就给通过
 *                         如果电子保单没有在有效期内的数据直接看纸质保单，纸质保单与基本信息一致，也给通过
 * -->  南京交强险逻辑变更5： 先查看是否有电子数据，如果有，只看电子数据结果；
 *                         如果没有，以纸质保单为准；
 *      南京交强险逻辑变更6：
 * 1. 优先比对电子保单，如果电子保单通过了，就判定0203照片为通过，不看纸质的结果。如果电子保单不通过（或者电子保单没查到），那就判定纸质保单，如果纸质通过就算通过，如果纸质不通过，就写明原因。不通过原因里面写明纸质和电子哪些地方不通过。
 * 2. 算法判定为“图片信息不规范”时，结果从未知改成不通过。
*/
bool nanjing_jqx(vehicle_inf * pvehicle_inf, ResultCollection &result)
{
    HttpClient client;
    std::string request = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
    request += "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" ";
    request += "xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">";
    request += "<soap:Body>";
    request += "<GetInsMsg xmlns=\"http://impl.webservice.store.com/\">";
    request += "<arg0 xmlns=\"\">" + g_localServerIp + "</arg0>";
    request += "<arg1 xmlns=\"\">" + g_localMac + "</arg1>";
    request += "<arg2 xmlns=\"\">" + pvehicle_inf->m_clsbdh + "</arg2>";
    request += "</GetInsMsg></soap:Body></soap:Envelope>";
    DATA_PRINT(LEVEL_INFO, "request string is: [%s] \n", request.c_str());

    if (client.InitData("http://11.1.0.240:8080/InsMsg/InsMsg?wsdl", REQUEST_POST_FLAG, (char *)HTTP_CONTENT_TYPE_TEXT_XML, (char *)request.c_str())) {
        client.startHttpClient();
        if (client.ResponseData.find("成功") != std::string::npos) { // get data succeed
            DATA_PRINT(LEVEL_INFO, "GetInsMsg response succeed info: [%s] \n", client.ResponseData.c_str());
            std::string::size_type n;

            if ((n= client.ResponseData.find(",vin:")) != std::string::npos) { // find vin
                std::string begin_of_vin = client.ResponseData.substr(n+strlen(",vin:"));
                std::string::size_type tmp_symbol = begin_of_vin.find_first_of(",");
                std::string result_vin = begin_of_vin.substr(0, tmp_symbol);
                result.nanjing_elec_data.m_vin = result_vin;
            } else {
                DATA_PRINT(LEVEL_ERROR, "GetInsMsg response NOT find the string \"vin:\". \n");
                return false;
            }

            {
                if ((n=client.ResponseData.find("effectivedate:")) != std::string::npos) { // find start date
                    std::string tmp_start_date = client.ResponseData.substr(n+strlen("effectivedate:"));
                    std::string::size_type tmp_symbol = tmp_start_date.find_first_of(",");
                    result.nanjing_elec_data.m_start_date = tmp_start_date.substr(0, tmp_symbol);
                    DATA_PRINT(LEVEL_INFO, "GetInsMsg start date [%s]. \n", result.nanjing_elec_data.m_start_date.c_str());
                } else {
                    DATA_PRINT(LEVEL_ERROR, "GetInsMsg response NOT find the string has \"effectivedate:\". \n");
                    return false;
                }

                if ((n=client.ResponseData.find("expiredate:")) != std::string::npos) { // find end date
                    std::string tmp_end_date = client.ResponseData.substr(n+strlen("expiredate:"));
                    std::string::size_type tmp_symbol = tmp_end_date.find_first_of(",");
                    result.nanjing_elec_data.m_end_date = tmp_end_date.substr(0, tmp_symbol);
                    DATA_PRINT(LEVEL_INFO, "GetInsMsg end date [%s]. \n", result.nanjing_elec_data.m_end_date.c_str());
                } else {
                    DATA_PRINT(LEVEL_ERROR, "GetInsMsg response NOT find the string has \"expiredate:\". \n");
                    return false;
                }
                // compare date
//                result.nanjing_elec_data.m_b_indate = fun_in_date(result.nanjing_elec_data.m_start_date, result.nanjing_elec_data.m_end_date);
            }

            if ((n=client.ResponseData.find("licenseno:")) != std::string::npos) {
                std::string tmp_hphm = client.ResponseData.substr(n+strlen("licenseno:"));
                std::string::size_type tmp_symbol = tmp_hphm.find_first_of(",");
                std::string result_hphm = tmp_hphm.substr(0, tmp_symbol);
                result.nanjing_elec_data.m_licenseno = result_hphm;
            } else {
                DATA_PRINT(LEVEL_ERROR, "GetInsMsg response NOT find the string has \"licenseno:\". \n");
                return false;
            }
        } else {// 获取电子数据保险单失败
            DATA_PRINT(LEVEL_ERROR, "GetInsMsg response failed info: [%s] \n", client.ResponseData.c_str());
            return false;
        }
    } else { // httpclient 初始化失败
        DATA_PRINT(LEVEL_ERROR, "GetInsMsg init httpclient failed. \n");
        return false;
    }

    return true;
}

void vehicle_check_jqx(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!(g_CheckItem.picture.JiaoQiangXian.ChePai
          || g_CheckItem.picture.JiaoQiangXian.CheJiaHao
          || g_CheckItem.picture.JiaoQiangXian.YouXiaoQi
          || g_CheckItem.picture.JiaoQiangXian.CheChuanShui
          || g_CheckItem.picture.JiaoQiangXian.DianZiBaoDan
          || g_CheckItem.picture.JiaoQiangXian.FaDongJiHao
          || g_CheckItem.picture.JiaoQiangXian.FuBen
          || g_CheckItem.picture.JiaoQiangXian.GongZhang)) {
        DATA_PRINT(LEVEL_INFO, "jqx(0203) has been skipped. \n");
        return;
    }

    if ((g_CheckItem.City == NANJING) && (!g_TestMode)) {  // 从 11.1.0.240:8080/InsMsg/InsMsg?wsdl 获取数据
        g_b_ret = nanjing_jqx(pvehicle_inf, result);
    }

    std::string ChePai = g_CheckItem.picture.JiaoQiangXian.ChePai ? pvehicle_inf->m_hphm : "";
    std::string CheJiaHao = g_CheckItem.picture.JiaoQiangXian.CheJiaHao ? pvehicle_inf->m_clsbdh : "";
    std::string sxrq = g_CheckItem.picture.JiaoQiangXian.YouXiaoQi ? pvehicle_inf->m_sxrq : "";
    std::string zzrq = g_CheckItem.picture.JiaoQiangXian.YouXiaoQi ? pvehicle_inf->m_zzrq : "";

    sxrq = result.formatingDate(sxrq);
    zzrq = result.formatingDate(zzrq);

    std::string jssj;
    std::time_t t = std::time(NULL);
    std::tm *st = std::localtime(&t);
    char tmpArray[128] = { 0 };
    if ((g_CheckItem.City==BAODING) || (g_CheckItem.City==XIAN) || (g_CheckItem.City == TAIYUAN) || (g_CheckItem.City == XUZHOU)) {
        if(!g_TestMode)
        {
            sprintf(tmpArray, "%d%02d%02d", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);
            jssj = tmpArray;
        }
        else
        {
            jssj = result.formatingDate(pvehicle_inf->m_jssj);
        }

    } else if ((g_CheckItem.City == ANSHUN)) {
        if(st->tm_mon >= 11)
        {
            sprintf(tmpArray, "%d%02d%02d", st->tm_year + 1901, st->tm_mon - 10, st->tm_mday);
        }
        else
        {
            sprintf(tmpArray, "%d%02d%02d", st->tm_year + 1900, st->tm_mon + 2, st->tm_mday);
        }
        jssj = tmpArray;
    }else if(g_CheckItem.City == JIUJIANG){
        jssj = result.formatingDate(pvehicle_inf->m_zzrq);
    }
    else {
        jssj = result.formatingDate(pvehicle_inf->m_jssj);
    }

    Baodan_ImgOutMsg jqxdata;
    cv::Mat m = cv::imread(pvehicle_inf->m_zplist[index].local_path);

    pvehicle_inf->timeRecord.startTime();
    if ((pvehicle_inf->m_cllx.substr(0, 2)=="M1") ||
            (pvehicle_inf->m_cllx.substr(0, 2)=="M2") ||
            (pvehicle_inf->m_cllx.substr(0, 2)=="N1")) {
        alg->baodan_api_process(m, ChePai, CheJiaHao,jssj, pvehicle_inf->m_fdjh, 0, jqxdata);
    } else {

        int hdzks = baseTool::str2Int(pvehicle_inf->m_hdzk);
        string fdjh=pvehicle_inf->m_fdjh;
        alg->baodan_api_process(m, ChePai, CheJiaHao,jssj, pvehicle_inf->m_fdjh, hdzks, jqxdata);
    }
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.jqx = pvehicle_inf->timeRecord.getTime();

    if ((!jqxdata.b_riqi) && (g_CheckItem.City == FOSHAN)) {
        char tmp_month[128] = { 0 };
        sprintf(tmp_month, "%02d", st->tm_mon + 4);
        int n_tmp_month = atoi(tmp_month);
        if (n_tmp_month+4 > 12) {
            sprintf(tmpArray, "%d%02d%02d", st->tm_year+1901, st->tm_mon-8, st->tm_mday);
            jssj = tmpArray;
        } else {
            sprintf(tmpArray, "%d%02d%02d", st->tm_year+1900, st->tm_mon+4, st->tm_mday);
            jssj = tmpArray;
        }
        int hdzks = baseTool::str2Int(pvehicle_inf->m_hdzk);
        pvehicle_inf->timeRecord.startTime();
        alg->baodan_api_process(m, ChePai, CheJiaHao, sxrq, pvehicle_inf->m_fdjh, hdzks, jqxdata);
        pvehicle_inf->timeRecord.endTime();
        pvehicle_inf->timeRecord.picture.process.jqx = pvehicle_inf->timeRecord.getTime();
    }

    if((!jqxdata.b_riqi) && (g_CheckItem.City == FUZHOU2))
    {//抚州提前保险区间7天内检测，算通过
       char tmp_year[128] = {0};
       sprintf(tmp_year, "%d", st->tm_year + 1900);
       char tmp_month[128] = {0};
       sprintf(tmp_month, "%02d", st->tm_mon +1);
       char tmp_day[128] = {0};
       sprintf(tmp_day, "%02d", st->tm_mday);
       int year = std::stoi(tmp_year);
       int month = std::stoi(tmp_month);
       int day = std::stoi(tmp_day);

       day += 7;

       if (month == 12) {
           if (day > 31) {
               day -= 31;
               month = 1;
               year += 1;
           }
       } else if (month == 1
                  || month == 3
                  || month == 5
                  || month == 7
                  || month == 8
                  || month == 10) {

           if (day > 31) {
               day -= 31;
               month += 1;
           }

       } else if (month == 2) {
           /* 闰年:能被400整除,或者能被4整除但不能被100整除 */
           if ((year % 400 == 0) || ( (year % 4 == 0) && (year % 100 != 0) )) {
               if (day > 29) {
                   day -= 29;
                   month += 1;
               }
           } else {
               if (day > 28) {
                   day -= 28;
                   month += 1;
               }
           }
       } else {
           if (day > 30) {
               day -= 30;
               month += 1;
           }
       }

       char tmpArray[64] = { 0 };
       sprintf(tmpArray, "%d%02d%02d", year, month, day);
       jssj = tmpArray;

       int hdzks = baseTool::str2Int(pvehicle_inf->m_hdzk);
       pvehicle_inf->timeRecord.startTime();
       alg->baodan_api_process(m, ChePai, CheJiaHao, jssj, pvehicle_inf->m_fdjh, hdzks, jqxdata);
       pvehicle_inf->timeRecord.endTime();
       pvehicle_inf->timeRecord.picture.process.jqx = pvehicle_inf->timeRecord.getTime();
    }

    if ((!jqxdata.b_chechuanshui) && (g_CheckItem.City==JIAOZUO)) {
        if (g_CheckItem.picture.JiaoQiangXian.CheChuanShui) {
            for (unsigned int n_tmp = 0; n_tmp < pvehicle_inf->m_zplist.size(); n_tmp++)
            {
                if (pvehicle_inf->m_zplist[n_tmp].zptype == ZhaoPianZL.WanShuiZhengMing) {
                    jqxdata.b_chechuanshui = true;
                }
            }
        }
    }

    result.BaoDan = jqxdata;

#ifdef DEMO_TEST
    {
        string path = pvehicle_inf->m_zplist[index].demo_local_path;
        if (pvehicle_inf->m_sxrq.length() > 10)
        {
            path += "_";
            path += LeftString(pvehicle_inf->m_sxrq, 10);
        }
        if (pvehicle_inf->m_zzrq.length() > 10)
        {
            path += "_";
            path += LeftString(pvehicle_inf->m_zzrq, 10);
        }
        cv::Mat m_save = m.clone();
        if (jqxdata.b_baodan)
        {
            path += "_1.jpg";
            cv::rectangle(m_save, jqxdata.r_chejiahao, cv::Scalar(0, 0, 255), 3);
            cv::rectangle(m_save, jqxdata.r_chepai, cv::Scalar(0, 0, 255), 3);
            cv::rectangle(m_save, jqxdata.r_hongzhang, cv::Scalar(0, 0, 255), 3);
            cv::imwrite(path, m_save);
        }

        //7.13修改演示内容
        demo_data.bd = true;
        string path1 = pvehicle_inf->m_zplist[index].demo_local_path;
        path1 += "_bd_1.jpg"; //经过n*90度初步旋转后的图像
        cv::Mat mb = jqxdata.m;
        if (mb.empty())
        {
            mb = m.clone();
            cv::imwrite(path1, mb);
        }
        else
        {
            cv::imwrite(path1, mb);
        }
        demo_data.Baodan_hongzhan = jqxdata.r_hongzhang;
        demo_data.Baodan_roi = jqxdata.r_roi;
        demo_data.Baodan_chechuanshui = jqxdata.r_chechuanshui; //

        cv::Mat mbr = jqxdata.m_roi;
        string path2 = pvehicle_inf->m_zplist[index].demo_local_path;
        path2 += "_bd_2.jpg";//车牌，车架号识别时 旋转后的图片
        cv::imwrite(path2, mbr);

        demo_data.Baodan_chepai = jqxdata.r_chepai;
        demo_data.Baodan_chejiahao = jqxdata.r_chejiahao;
        demo_data.Baodan_start_riqi = jqxdata.r_start_riqi;
        demo_data.Baodan_end_riqi = jqxdata.r_end_riqi;

        cv::Mat mbf = jqxdata.m_fuben;
        string path3 = pvehicle_inf->m_zplist[index].demo_local_path;
        path3 += "_bd_3.jpg";//精修过的比对内容图像，包括字符定位框
        cv::imwrite(path3, mbf);

        demo_data.Baodan_fuben = jqxdata.r_fuben;

        demo_data.Baodan_b_pic_quality = jqxdata.b_pic_quality;
                                                                                                                                                                                                                                                                                                                                                                        demo_data.Baodan_b_baodan = true;
        demo_data.Baodan_b_riqi = jqxdata.b_riqi;
        demo_data.Baodan_b_fuben = jqxdata.b_fuben;
        demo_data.Baodan_b_chechuanshui = jqxdata.b_chechuanshui;

        cv::Mat mbtb = jqxdata.m_table;
        string path4 = pvehicle_inf->m_zplist[index].demo_local_path;
        path4 += "_bd_4.jpg";//精修过的比对内容图像，包括字符定位框
        cv::imwrite(path4, mbtb);

    }
#endif

#if 0
    _jqx_data *jqxdata = new(_jqx_data);
    CString name_desc[] = { "号牌", "车辆类型", "使用性质", "发动机号", "车辆识别代号", "保险生效日期", "保险截止", "公安留存","公章","不明" };
    jqxdata->hphm = ((std::string)pvehicle_inf->m_hphm).GetString();
    jqxdata->clsbdh = ((std::string)pvehicle_inf->m_clsbdh).GetString();
    jqxdata->sxrq = ((std::string)pvehicle_inf->m_sxrq).GetString();
    jqxdata->zzrq = ((std::string)pvehicle_inf->m_zzrq).GetString();
    UINT bhgs = atoi((std::string)pvehicle_inf->m_dbbhgs);
    cv::Mat im = cv::imread(((std::string)pvehicle_inf->m_zplist[index].local_path).GetString());//baodan
    ((DocParser*)table_test)->initilaize(*jqxdata);
    ((DocParser*)table_test)->process(im, 1);//baodan
    if (!((DocParser*)table_test)->result_jqx(jqxdata))
    {
        for (int i = 0; i < jqxdata->check_result.size(); i++)
        {
            if (jqxdata->check_result[i] == 1) continue;
            char num[10];
            _dbbhg_list v_dbhhg_list;
            bhgs++;
            itoa(bhgs, num, 10);
            pvehicle_inf->m_dbbhgs = num;
            v_dbhhg_list.zpid = pvehicle_inf->m_zplist[index].zpid;
            v_dbhhg_list.zptype = pvehicle_inf->m_zplist[index].zptype;
            v_dbhhg_list.dbbhg_desc = "交强险照片中(";
            v_dbhhg_list.dbbhg_desc += name_desc[(i<=8)?i:9];
            v_dbhhg_list.dbbhg_desc += ")项未能比对成功";
            v_dbhhg_list.dbresult = "4";
            pvehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        }
    }

    delete jqxdata;
#endif

}

void vehicle_check_zs_jqx(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!(g_CheckItem.picture.JiaoQiangXian.ChePai
          || g_CheckItem.picture.JiaoQiangXian.CheJiaHao
          || g_CheckItem.picture.JiaoQiangXian.YouXiaoQi
          || g_CheckItem.picture.JiaoQiangXian.CheChuanShui
          || g_CheckItem.picture.JiaoQiangXian.DianZiBaoDan
          || g_CheckItem.picture.JiaoQiangXian.FaDongJiHao
          || g_CheckItem.picture.JiaoQiangXian.FuBen
          || g_CheckItem.picture.JiaoQiangXian.GongZhang)) {
        DATA_PRINT(LEVEL_INFO, "中山完税证明 has been skipped. \n");
        return;
    }

    std::string ChePai = g_CheckItem.picture.JiaoQiangXian.ChePai ? pvehicle_inf->m_hphm : "";
    std::string CheJiaHao = g_CheckItem.picture.JiaoQiangXian.CheJiaHao ? pvehicle_inf->m_clsbdh : "";
    std::string sxrq = g_CheckItem.picture.JiaoQiangXian.YouXiaoQi ? pvehicle_inf->m_sxrq : "";
    std::string zzrq = g_CheckItem.picture.JiaoQiangXian.YouXiaoQi ? pvehicle_inf->m_zzrq : "";
    sxrq = result.formatingDate(sxrq);
    zzrq = result.formatingDate(zzrq);

    std::string jssj;
    //std::time_t t = std::time(NULL);
    //std::tm *st = std::localtime(&t);
    //char tmpArray[128] = { 0 };
    jssj = result.formatingDate(pvehicle_inf->m_jssj);

    Baodan_ImgOutMsg jqxdata;
    cv::Mat m = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    int hdzks = baseTool::str2Int(pvehicle_inf->m_hdzk);
    pvehicle_inf->timeRecord.startTime();
    alg->baodan_api_process(m, ChePai, CheJiaHao, jssj, pvehicle_inf->m_fdjh, hdzks, jqxdata);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.jqx = pvehicle_inf->timeRecord.getTime();

    result.ZhongShanWanShui = jqxdata;
}

void vehicle_check_jqx2(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{

    if (!(g_CheckItem.picture.JiaoQiangXian.ChePai
          || g_CheckItem.picture.JiaoQiangXian.CheJiaHao
          || g_CheckItem.picture.JiaoQiangXian.YouXiaoQi
          || g_CheckItem.picture.JiaoQiangXian.CheChuanShui
          || g_CheckItem.picture.JiaoQiangXian.DianZiBaoDan
          || g_CheckItem.picture.JiaoQiangXian.FaDongJiHao
          || g_CheckItem.picture.JiaoQiangXian.FuBen
          || g_CheckItem.picture.JiaoQiangXian.GongZhang)) {
        DATA_PRINT(LEVEL_INFO, "jqx(0210) has been skipped. \n");
        return;
    }

    std::string ChePai = g_CheckItem.picture.JiaoQiangXian.ChePai ? pvehicle_inf->m_hphm : "";
    std::string CheJiaHao = g_CheckItem.picture.JiaoQiangXian.CheJiaHao ? pvehicle_inf->m_clsbdh : "";
    std::string sxrq = g_CheckItem.picture.JiaoQiangXian.YouXiaoQi ? pvehicle_inf->m_sxrq : "";
    std::string zzrq = g_CheckItem.picture.JiaoQiangXian.YouXiaoQi ? pvehicle_inf->m_zzrq : "";

    sxrq = result.formatingDate(sxrq);
    zzrq = result.formatingDate(zzrq);

    std::string zzrq_add;   /* 0203保单终止日期增加一天的日期 */
    if (!zzrq.empty()) {

        try {
            int year = std::stoi(zzrq.substr(0, 4));
            int month = std::stoi(zzrq.substr(4, 2));
            int day = std::stoi(zzrq.substr(6, 2));

            day += 1;

            if (month == 12) {
                if (day > 31) {
                    day = 1;
                    month = 1;
                    year += 1;
                }
            } else if (month == 1
                       || month == 3
                       || month == 5
                       || month == 7
                       || month == 8
                       || month == 10) {

                if (day > 31) {
                    day = 1;
                    month += 1;
                }

            } else if (month == 2) {
                /* 闰年:能被400整除,或者能被4整除但不能被100整除 */
                if ((year % 400 == 0) || ( (year % 4 == 0) && (year % 100 != 0) )) {
                    if (day > 29) {
                        day = 1;
                        month += 1;
                    }
                } else {
                    if (day > 28) {
                        day = 1;
                        month += 1;
                    }
                }
            } else {
                if (day > 30) {
                    day = 1;
                    month += 1;
                }
            }

            char tmpArray[64] = { 0 };
            sprintf(tmpArray, "%d%02d%02d", year, month, day);
            zzrq_add = tmpArray;
        } catch (const std::exception &e) {
            std::cout << "Error: " << e.what() << std::endl;
            DATA_PRINT(LEVEL_ERROR, "ZZRQ error: %s \n", zzrq.data());
        }

    }

    std::string jssj;

    if (g_CheckItem.City == ANSHUN) {
        std::time_t t = std::time(NULL);
        std::tm *st = std::localtime(&t);
        char tmpArray[128] = { 0 };
        if(st->tm_mon >= 11)
        {
            sprintf(tmpArray, "%d%02d%02d", st->tm_year + 1901, st->tm_mon - 10, st->tm_mday);
        }
        else
        {
            sprintf(tmpArray, "%d%02d%02d", st->tm_year + 1900, st->tm_mon + 2, st->tm_mday);
        }
        jssj = tmpArray;
    }
    else
    {
            jssj = result.formatingDate(pvehicle_inf->m_jssj);
    }



    Baodan_ImgOutMsg jqxdata;
    cv::Mat m = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    int hdzks = baseTool::str2Int(pvehicle_inf->m_hdzk);
    pvehicle_inf->timeRecord.startTime();
    alg->baodan_api_process(m, ChePai, CheJiaHao, zzrq_add, pvehicle_inf->m_fdjh, hdzks, jqxdata);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.jqx = pvehicle_inf->timeRecord.getTime();

    result.AnShunBaoDan = jqxdata;
    if(jqxdata.b_riqi)
    {
       result.BaoDan.b_riqi = true;
    }

}

void vehicle_check_jybg(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!(g_CheckItem.picture.JianYanBaoGao.CheJiaHao
           || g_CheckItem.picture.JianYanBaoGao.ChePai
          || g_CheckItem.picture.JianYanBaoGao.JieLun
          || g_CheckItem.picture.JianYanBaoGao.QianMing
          || g_CheckItem.picture.JianYanBaoGao.ShuJuXiang
          || g_CheckItem.picture.JianYanBaoGao.YinZhang
          || g_CheckItem.picture.JianYanBaoGao.YinZhang_MA)) {
        DATA_PRINT(LEVEL_INFO, "jybg(0204) has been skipped. \n");
        return;
    }

    std::string CheJiaHao = g_CheckItem.picture.JianYanBaoGao.CheJiaHao ? pvehicle_inf->m_clsbdh : "";
    std::string ChePai = g_CheckItem.picture.JianYanBaoGao.ChePai ? pvehicle_inf->m_hphm : "";
    std::string CheLiangZhongLei = g_CheckItem.picture.JianYanBaoGao.HaoPaiZhongLei ? pvehicle_inf->m_cllx : "";
    std::string JianYanRiQi = g_CheckItem.picture.JianYanBaoGao.JianYanRiQi ? pvehicle_inf->m_jssj : "";
    Jianyanbaogao_ImgOutMsg jybgdata;
    cv::Mat m = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    pvehicle_inf->timeRecord.startTime();
    alg->jianyanbaogao_api_process(m, ChePai, CheJiaHao, JianYanRiQi, jybgdata);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.jybg = pvehicle_inf->timeRecord.getTime();

    result.JianYanBaoGao = jybgdata;

#ifdef DEMO_TEST
    {
        string path = pvehicle_inf->m_zplist[index].demo_local_path;
        path += "_1.jpg";
        cv::Mat m_save = m.clone();
        cv::rectangle(m_save, jybgdata.r_chepai, cv::Scalar(0, 0, 255), 3);
        cv::rectangle(m_save, jybgdata.r_chejiahao, cv::Scalar(0, 0, 255), 3);
        cv::imwrite(path, m_save);

        //if (!jybgdata.b_jianyanbaogao) {
        //path = WstringToString(pvehicle_inf->m_zplist[index].demo_local_path);
        //path += "_0.jpg";
        //m_save = m.clone();
        //cv::imwrite(path, m_save);
        //}

        //7.13修改演示内容
        demo_data.jybg = true;
        string path1 = pvehicle_inf->m_zplist[index].demo_local_path;
        path1 += "_jybg_1.jpg"; //经过n*90度初步旋转后的图像
        cv::Mat mjr = jybgdata.m_rotate;
        if (mjr.empty())
        {
            mjr = m.clone();
            cv::imwrite(path1, mjr);
        }
        else
        {
            cv::imwrite(path1, mjr);
        }

        demo_data.Jianyanbaogao_hongzhang = jybgdata.r_hongzhang;
        demo_data.Jianyanbaogao_auxiliary = jybgdata.r_auxiliary;
        demo_data.Jianyanbaogao_compare = jybgdata.r_compare;
        demo_data.Jianyanbaogao_qianming = jybgdata.r_qianming;
        demo_data.Jianyanbaogao_jianyanjielun = jybgdata.r_jianyanjielun;

        cv::Mat mja = jybgdata.m_auxiliary;
        string path2 = pvehicle_inf->m_zplist[index].demo_local_path;
        path2 += "_jybg_2.jpg";//车牌，车架号识别时 旋转后的图片
        cv::imwrite(path2, mja);

        demo_data.Jianyanbaogao_chejiahao = jybgdata.r_chejiahao;
        demo_data.Jianyanbaogao_chepai = jybgdata.r_chepai;

        cv::Mat mjc = jybgdata.m_compare;
        string path3 = pvehicle_inf->m_zplist[index].demo_local_path;
        path3 += "_jybg_3.jpg";//精修过的比对内容图像，包括字符定位框
        cv::imwrite(path3, mjc);

        demo_data.Jianyanbaogao_b_pic_quality = jybgdata.b_pic_quality;
        demo_data.Jianyanbaogao_b_jianyanbaogao = jybgdata.b_jianyanbaogao;
        demo_data.Jianyanbaogao_b_qianming = jybgdata.b_qianming;
        demo_data.Jianyanbaogao_b_hongzhang = jybgdata.b_hongzhang;
        demo_data.Jianyanbaogao_b_jianyanjielun = jybgdata.b_jianyanjielun;
        demo_data.Jianyanbaogao_b_jianyan_info = jybgdata.b_jianyan_info;

        cv::Mat mtc = jybgdata.m_table;
        string path4 = pvehicle_inf->m_zplist[index].demo_local_path;
        path4 += "_jybg_4.jpg";//精修过的比对内容图像，包括字符定位框
        cv::imwrite(path4, mtc);//信息表格
        //输出是否通过  jybgdata.b_jianyanbaogao  jybgdata.b_jianyan_info
    }
#endif
}

void vehicle_check_jyb_back(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if(g_CheckItem.City==NINGBO) {
        pvehicle_inf->is_beimian=true;
    }
    if (!(g_CheckItem.picture.JianYanBiaoBeiMian.JianYanBiaoBeiMian
          || g_CheckItem.picture.JianYanBiaoBeiMian.DiPan
          || g_CheckItem.picture.JianYanBiaoBeiMian.WaiGuan
          || g_CheckItem.picture.JianYanBiaoBeiMian.YinChe)) {
        DATA_PRINT(LEVEL_INFO, "jybbm(0298) has been skipped. \n");
        return;
    }
    cv::Mat m = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    Jianyanbiaoback_ImgOutMsg  out;
    pvehicle_inf->timeRecord.startTime();
    alg->jianyanbiaoback_api_process(m, out);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.jyb_bk = pvehicle_inf->timeRecord.getTime();
    result.JianYanBiaoBeiMian = out;
}

void vehicle_check_jyb_rg(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result, char * code)
{
    if (!(g_CheckItem.picture.JianYanBaoGao_RenGong.ChePai ||
          g_CheckItem.picture.JianYanBaoGao_RenGong.ChaYanJieLun ||
          g_CheckItem.picture.JianYanBaoGao_RenGong.DiPanQianZi ||
          g_CheckItem.picture.JianYanBaoGao_RenGong.WaiGuanQianZi ||
          g_CheckItem.picture.JianYanBaoGao_RenGong.YinCheQianZi )) {
        DATA_PRINT(LEVEL_INFO, "jyb_rg(%s) has been skipped. \n", code);
        return;
    }    

    std::string CheJiaHao = pvehicle_inf->m_clsbdh;
    std::string ChePai = g_CheckItem.picture.ChaYanJiLu.ChePai ? pvehicle_inf->m_hphm : "";

    std::time_t t = std::time(NULL);
    std::tm *st = std::localtime(&t);
    char tmpArray[64] = { 0 };
    sprintf(tmpArray, "%d%02d%02d", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);
    std::string Today = tmpArray;

    Jianyanbiao_ImgOutMsg out_msg;
    cv::Mat m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path);

    pvehicle_inf->timeRecord.startTime();
    alg->jianyanbiao_api_process(m1, ChePai, CheJiaHao, Today, out_msg);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.cyjl = pvehicle_inf->timeRecord.getTime();

    result.JianYanBiao_RenGong = out_msg;

}

void vehicle_check_jyb_yq(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result, char * code)
{
    if (!(g_CheckItem.picture.JianYanBaoGao_YiQi.YiQi ||
          g_CheckItem.picture.JianYanBaoGao_YiQi.HongZhang ||
          g_CheckItem.picture.JianYanBaoGao_YiQi.JieLun ||
          g_CheckItem.picture.JianYanBaoGao_YiQi.ChePai ||
          g_CheckItem.picture.JianYanBaoGao_YiQi.CheJiaHao )) {
        DATA_PRINT(LEVEL_INFO, "jyb_yq(%s) has been skipped. \n", code);
        return;
    }

    std::string CheJiaHao = g_CheckItem.picture.JianYanBaoGao_YiQi.CheJiaHao ? pvehicle_inf->m_clsbdh : "";
    std::string ChePai = g_CheckItem.picture.JianYanBaoGao_YiQi.ChePai ? pvehicle_inf->m_hphm : "";

    Jianyanbaogao_yiqi_ImgOutMsg jyb_yq_data;
    cv::Mat m = cv::imread(pvehicle_inf->m_zplist[index].local_path);

    pvehicle_inf->timeRecord.startTime();
    alg->jianyanbaogao_yiqi_api_process(m, ChePai, CheJiaHao, jyb_yq_data);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.jybg = pvehicle_inf->timeRecord.getTime();

    result.JianYanBiao_YiQi = jyb_yq_data;
}

void vehicle_check_wts(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if((g_CheckItem.City==NINGBO) || (NANNING==g_CheckItem.City)) {
        pvehicle_inf->is_waisheng=true;
    }
    if (!(g_CheckItem.picture.WeiTuoShu.WeiTuoShu ||
          g_CheckItem.picture.WeiTuoShu.HongZhang )) {
        if ((g_CheckItem.City==FOSHAN) && (!g_CheckItem.picture.WeiTuoShu.ShenFenZheng)) {
            DATA_PRINT(LEVEL_INFO, "FoShan_wts(0208) has been skipped. \n");
            return;
        } else {
            DATA_PRINT(LEVEL_INFO, "nb_wts(0000) has been skipped. \n");
            return;
        }
    }

    weituoshu_ImgOutMsg wts_data;
    cv::Mat m = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    pvehicle_inf->timeRecord.startTime();
    alg->weituoshu_api_process(m, wts_data);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.wts = pvehicle_inf->timeRecord.getTime();

    result.WeiTuoShu = wts_data; // weituoshu
}

void vehicle_check_sqb(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!(g_CheckItem.picture.ShenQingBiao.ChePai
          || g_CheckItem.picture.ShenQingBiao.ShouJi_BenRen
          || g_CheckItem.picture.ShenQingBiao.ShouJi_DaiLi
          || g_CheckItem.picture.ShenQingBiao.QianMing
          || g_CheckItem.picture.ShenQingBiao.CheJiaHao
          || g_CheckItem.picture.ShenQingBiao.JianYanHeGeBiaoZhi)) {
        DATA_PRINT(LEVEL_INFO, "sqb(0202) has been skipped. \n");
        return;
    }

    //std::string CheJiaHao = g_CheckItem.picture.ShenQingBiao.CheJiaHao ? pvehicle_inf->m_clsbdh: "";
    std::string ChePai = g_CheckItem.picture.ShenQingBiao.ChePai ? pvehicle_inf->m_hphm : "";
    std::string CheJiaHao = g_CheckItem.picture.ShenQingBiao.CheJiaHao ? pvehicle_inf->m_clsbdh : "";
    std::string chepai_type = g_CheckItem.picture.ShenQingBiao.is_CheLiangType ? pvehicle_inf->m_hpzl : "";

    Shenqingdan_ImgOutMsg sqbdata;
    cv::Mat m = cv::imread(pvehicle_inf->m_zplist[index].local_path);

    pvehicle_inf->timeRecord.startTime();
    //((LargeVehicleApi *)model_test)->shenqingbiao_api_process(m, ChePai, CheJiaHao, sqbdata);
    alg->shenqingbiao_api_process(m, ChePai, CheJiaHao, chepai_type, sqbdata);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.sqb = pvehicle_inf->timeRecord.getTime();

    result.ShenQingDan = sqbdata;

#ifdef DEMO_TEST
    {
        string path = pvehicle_inf->m_zplist[index].demo_local_path;
        path += "_1.jpg";
        cv::Mat m_save = m.clone();
        //cv::rectangle(m_save, sqbdata.r_chepai, cv::Scalar(0, 0, 255), 3);
        cv::imwrite(path, m_save);

        //if (!sqbdata.b_shenqingdan) {
        //path = WstringToString(pvehicle_inf->m_zplist[index].demo_local_path);
        //path += "_0.jpg";
        //m_save = m.clone();
        //cv::imwrite(path, m_save);
        //}

        cv::Mat msd = sqbdata.m_table;
        string path1 = pvehicle_inf->m_zplist[index].demo_local_path;
        path1 += "_sqd_1.jpg";//精修过的比对内容图像，包括字符定位框
        cv::imwrite(path1, msd);

        demo_data.sqb = true;
        cv::Mat msr = sqbdata.m_rotate;    //9.4
        string path2 = pvehicle_inf->m_zplist[index].demo_local_path;
        path2 += "_sqd_2.jpg";//旋转好的图片
        if (msr.empty())
        {
            msr = m.clone();
            cv::imwrite(path2, msr);
        } else
        {
            cv::imwrite(path2, msr);
        }

        demo_data.Shenqingdan_chepai = sqbdata.r_chepai;      //车牌位置
        demo_data.Shenqingdan_qianming = sqbdata.r_qianming;
        demo_data.Shenqingdan_telephone = sqbdata.r_telephone_suoyouren;

        //demo_data.Shenqingdan_s_telephone = sqbdata.telephone_suoyouren;

        demo_data.Shenqingdan_b_pic_quality = sqbdata.b_pic_quality;
        demo_data.Shenqingdan_b_qianming = sqbdata.b_qianming;
        demo_data.Shenqingdan_b_chepai = sqbdata.b_chepai;
    }
#endif
}

void vehicle_check_zqf(vehicle_inf * pvehicle_inf, UINT index, int DangAn_Index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (pvehicle_inf->m_zplist[index].zptype == ZhaoPianZL.ZuoFang) {
        if (!(g_CheckItem.picture.ZuoFang.GaiZhuang)) {
            DATA_PRINT(LEVEL_INFO, "ZuoFang has been skipped. \n");
            return;
        }
        std::string ChePai = g_CheckItem.picture.ZuoFang.ChePai ? pvehicle_inf->m_hphm : "";
        std::string JieShuShiJian = g_CheckItem.picture.ZuoFang.ShuiYinRiQi ? pvehicle_inf->m_jssj : "";
        JieShuShiJian=result.formatingDate(JieShuShiJian);
        cv::Mat DangAn_mat;
        if (DangAn_Index != -1) {
            DangAn_mat = cv::imread(pvehicle_inf->m_zplist[DangAn_Index].local_path);
        }
        cv::Mat m = cv::imread(pvehicle_inf->m_zplist[index].local_path);

        vector<cv::Mat> empty;
        Cheliang_ImgOutMsg out_msg_ce_mian;
        pvehicle_inf->timeRecord.startTime();
        alg->cheliang_api_process(m, DangAn_mat, empty ,ChePai,pvehicle_inf->m_cllx,pvehicle_inf->m_csys, eOtherType, out_msg_ce_mian);
        pvehicle_inf->timeRecord.endTime();
        pvehicle_inf->timeRecord.picture.process.zf = pvehicle_inf->timeRecord.getTime();

        #ifdef LOGO_YINGSHEBIAO
        out_msg_ce_mian.b_chebiao = result.isLogo(out_msg_ce_mian.logo, pvehicle_inf->m_clpp1);
        pvehicle_inf->m_strZuoFangCheBiao = out_msg_ce_mian.logo;
        DATA_PRINT(LEVEL_INFO, "ZuoFang path:%s, logo:%s, clpp:%s, b_chebiao:%d\n", pvehicle_inf->m_zplist[index].local_path, out_msg_ce_mian.logo.c_str(), pvehicle_inf->m_clpp1.c_str(), out_msg_ce_mian.b_chebiao);
        #endif
        result.ZuoFang = out_msg_ce_mian;

    } else if (pvehicle_inf->m_zplist[index].zptype == ZhaoPianZL.QianHaoPai) { // 前号牌特写
        if (!(g_CheckItem.picture.QianHaoPai.ChePai || g_CheckItem.picture.QianHaoPai.ShuiYinRiQi)) {
            DATA_PRINT(LEVEL_INFO, "QianHaoPai has been skipped. \n");
            return;
        }

        std::string ChePai = g_CheckItem.picture.QianHaoPai.ChePai ? pvehicle_inf->m_hphm : "";
        std::string JieShuShiJian = g_CheckItem.picture.QianHaoPai.ShuiYinRiQi ? pvehicle_inf->m_jssj : "";
        JieShuShiJian = result.formatingDate(JieShuShiJian);

        cv::Mat mat_qian;
        mat_qian = cv::imread(pvehicle_inf->m_zplist[index].local_path);
        vector<cv::Mat> empty;
        Cheliang_ImgOutMsg out_msg_qian_haopai;
        pvehicle_inf->timeRecord.startTime();
        alg->cheliang_api_process(mat_qian, mat_qian,empty ,ChePai,pvehicle_inf->m_cllx,pvehicle_inf->m_csys,eOtherType, out_msg_qian_haopai);
        pvehicle_inf->timeRecord.endTime();
        pvehicle_inf->timeRecord.picture.process.qhp = pvehicle_inf->timeRecord.getTime();

        result.QianHaoPai = out_msg_qian_haopai;
    } else if (pvehicle_inf->m_zplist[index].zptype == ZhaoPianZL.HouHaoPai) { // 后号牌特写
        if (!(g_CheckItem.picture.HouHaoPai.ChePai || g_CheckItem.picture.HouHaoPai.ShuiYinRiQi)) {
            DATA_PRINT(LEVEL_INFO, "HouHaoPai has been skipped. \n");
            return;
        }

        std::string ChePai = g_CheckItem.picture.QianHaoPai.ChePai ? pvehicle_inf->m_hphm : "";
        std::string JieShuShiJian = g_CheckItem.picture.QianHaoPai.ShuiYinRiQi ? pvehicle_inf->m_jssj : "";
        JieShuShiJian = result.formatingDate(JieShuShiJian);

        cv::Mat mat_hou;
        mat_hou = cv::imread(pvehicle_inf->m_zplist[index].local_path);
        vector<cv::Mat> empty;
        Cheliang_ImgOutMsg out_msg_Hou_haopai;
        pvehicle_inf->timeRecord.startTime();
        alg->cheliang_api_process(mat_hou, mat_hou,empty ,ChePai,pvehicle_inf->m_cllx,pvehicle_inf->m_csys,eOtherType, out_msg_Hou_haopai);
        pvehicle_inf->timeRecord.endTime();
        pvehicle_inf->timeRecord.picture.process.hhp = pvehicle_inf->timeRecord.getTime();

        result.HouHaoPai = out_msg_Hou_haopai;
    } else {
        if (!(g_CheckItem.picture.ZuoQianFang.ChePai
              || g_CheckItem.picture.ZuoQianFang.CheBiao
              || g_CheckItem.picture.ZuoQianFang.GaiZhuang
              || g_CheckItem.picture.ZuoQianFang.SanJiaoJia
              || g_CheckItem.picture.ZuoQianFang.ShuiYinRiQi)) {
            DATA_PRINT(LEVEL_INFO, "zqf(0111) has been skipped. \n");
            return;
        }

        std::string ChePai = g_CheckItem.picture.ZuoQianFang.ChePai ? pvehicle_inf->m_hphm : "";
        std::string JieShuShiJian = g_CheckItem.picture.ZuoQianFang.ShuiYinRiQi ? pvehicle_inf->m_jssj : "";
        JieShuShiJian=result.formatingDate(JieShuShiJian);
        ELogoType CheBiao;
        if (g_CheckItem.picture.ZuoQianFang.CheBiao) {
            unsigned int logo_index;

            BOOL b_found = FALSE;
            for (logo_index = 0; (logo_index < logo_data.size()) && (!b_found); logo_index++) {
                for (unsigned int name_index = 0; (name_index < logo_data[logo_index].matchname.size()) && (!b_found); name_index++)
                {
                    if (pvehicle_inf->m_clpp1.find(logo_data[logo_index].matchname[name_index]) == std::string::npos)
                    {
                        continue;
                    }
                    else
                    {
                        b_found = TRUE;
                        //DATA_PRINT(LEVEL_DEBUG, "检索到车标%d-%s\n", logo_data[logo_index].logoindex, WstringToString(logo_data[logo_index].matchname[0]).c_str());
                        break;
                    }
                }

                if (b_found) {
                    break;
                }
            }

            result.Found_CheBiao = b_found;
            if (logo_index != logo_data.size()) {
                CheBiao = logo_data[logo_index].logoindex;
            } else {
                CheBiao = logo_data[0].logoindex;	/* Èç¹û³µ±êÎŽŒìË÷µœ£¬ÔòŽ«ÈëµÚÒ»žö³µ±ê */
            }
        } else {
            CheBiao = logo_data[0].logoindex;	/* Èç¹û²»Œì²é³µ±ê£¬ÔòŽ«ÈëµÚÒ»žö³µ±ê¡££šŽŠÀíœá¹ûÊ±£¬»áºöÂÔ³µ±ê£¬ËùÒÔŽ«Ê²ÃŽ¶Œ¿ÉÒÔ£© */
        }
        (void)CheBiao;
        cv::Mat DangAn_mat;
        if (DangAn_Index != -1) {
            DangAn_mat = cv::imread(pvehicle_inf->m_zplist[DangAn_Index].local_path);
        }

        cv::Mat m = cv::imread(pvehicle_inf->m_zplist[index].local_path);

#ifdef DEMO_TEST
    {
        string pathA = pvehicle_inf->m_zplist[index].demo_local_path;
        pathA += "_zqf_A.jpg";
        if (DangAn_mat.empty())
        {
            DangAn_mat = m.clone();
            cv::imwrite(pathA, DangAn_mat);
        }
        else
        {
            cv::imwrite(pathA, DangAn_mat);
        }
    }
#endif
        // 区分大小车接口
        if ((pvehicle_inf->m_cllx.substr(0, 2)=="K3") || (pvehicle_inf->m_cllx.substr(0, 2)=="K4")) { // 小车
            Cheliang_ImgOutMsg zqfdata;
            vector<cv::Mat> empty;
            empty.push_back(m);
            pvehicle_inf->timeRecord.startTime();
            alg->cheliang_api_process(m, DangAn_mat,empty ,ChePai,pvehicle_inf->m_cllx,pvehicle_inf->m_csys,eFRONTLEFT,zqfdata);
            alg->shuiyin_riqi_api_process(m, JieShuShiJian, result.bZuoQianFangShuiYinRiQi);
            pvehicle_inf->timeRecord.endTime();
            pvehicle_inf->timeRecord.picture.process.zqf = pvehicle_inf->timeRecord.getTime();
            #ifdef LOGO_YINGSHEBIAO
            zqfdata.b_chebiao = result.isLogo(zqfdata.logo, pvehicle_inf->m_clpp1);
            pvehicle_inf->m_strZqfCheBiao = zqfdata.logo;
            DATA_PRINT(LEVEL_INFO, "ZuoQianFang path:%s, logo:%s, clpp:%s, b_chebiao:%d\n", pvehicle_inf->m_zplist[index].local_path.c_str(), zqfdata.logo.c_str(), pvehicle_inf->m_clpp1.c_str(), zqfdata.b_chebiao);
            #endif
            result.ZuoQianFang = zqfdata;
        } else { // 大车
            Huoche_ImgOutMsg zqfout;
            pvehicle_inf->timeRecord.startTime();
            alg->huoche_api_process(m, ChePai, eFRONTLEFT, zqfout);
            pvehicle_inf->timeRecord.endTime();
            pvehicle_inf->timeRecord.picture.process.zqf = pvehicle_inf->timeRecord.getTime();
            #ifdef LOGO_YINGSHEBIAO
            zqfout.b_chebiao = result.isLogo(zqfout.logo, pvehicle_inf->m_clpp1);
            pvehicle_inf->m_strZqfCheBiao = zqfout.logo;
            DATA_PRINT(LEVEL_INFO, "HuoChe_ZuoQianFang path:%s, logo:%s, clpp:%s, b_chebiao:%d\n", pvehicle_inf->m_zplist[index].local_path.c_str(), zqfout.logo.c_str(), pvehicle_inf->m_clpp1.c_str(), zqfout.b_chebiao);
            #endif
            result.HuoChe_ZuoQianFang = zqfout;
        }
#ifdef DEMO_TEST
    {
        string path = pvehicle_inf->m_zplist[index].demo_local_path;
        path += "_1.jpg";
        cv::Mat m_save = m.clone();
        if (zqfdata.b_sanjiaojia == true)
        {
            cv::rectangle(m_save, zqfdata.r_sanjiaojia, cv::Scalar(0, 0, 255), 3);
        }
        cv::rectangle(m_save, zqfdata.r_chebiao, cv::Scalar(0, 0, 255), 3);
        cv::rectangle(m_save, zqfdata.r_chepai, cv::Scalar(0, 0, 255), 3);
        cv::imwrite(path, m_save);

        //if (bhgs != record_bhgs) {
        //	path = (CStringA)pvehicle_inf->m_zplist[index].demo_local_path;
        //	path += "_0.jpg";
        //	m_save = m.clone();
        //	cv::imwrite(path, m_save);
        //}

        demo_data.zqf = true;
        string path1 = pvehicle_inf->m_zplist[index].demo_local_path;
        path1 += "_zqf_1.jpg"; //旋转后的原图
        cv::Mat mzc = zqfdata.m;
        if (mzc.empty())
        {
            mzc = m.clone();
            cv::imwrite(path1, mzc);
        }
        else
        {
            cv::imwrite(path1, mzc);
        }
        demo_data.zqf_Cheliang_chepai = zqfdata.r_chepai;
        demo_data.zqf_Cheliang_chebiao = zqfdata.r_chebiao;
        demo_data.zqf_Cheliang_sanjiaojia = zqfdata.r_sanjiaojia;

        string path2 = pvehicle_inf->m_zplist[index].demo_local_path;
        path2 += "_zqf_2.jpg"; //color map
        cv::Mat mzcc = zqfdata.m_mask;
        //		cv::imshow("aaa", mzcc);
        cv::imwrite(path2, mzcc);
        //		waitKey(0);

        string path3 = pvehicle_inf->m_zplist[index].demo_local_path;
        path3 += "_zqf_3.jpg"; //车辆外观图
        cv::Mat mzcw = zqfdata.m_waiguan;
        cv::imwrite(path3, mzcw);

        demo_data.zqf_Cheliang_refit = zqfdata.r_refit;

        demo_data.zqf_Cheliang_b_ori_waiguan = zqfdata.b_ori_waiguan;
        demo_data.zqf_Cheliang_b_chepai = zqfdata.b_chepai;
        demo_data.zqf_Cheliang_b_chebiao = zqfdata.b_chebiao;
        demo_data.zqf_Cheliang_b_sanjiaojia = zqfdata.b_sanjiaojia;
    }
#endif
    }
}

void vehicle_check_zqf_yhf_cjh_cf(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    cv::Mat m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    cv::Mat m2 = cv::imread(pvehicle_inf->m_zplist[index].local_path);

    std::string chepai = pvehicle_inf->m_hphm;
    std::string jieshushijian = pvehicle_inf->m_jssj;
    jieshushijian = result.formatingDate(jieshushijian);
    Dipandongtai_ImgOutMsg img_out;

    if (pvehicle_inf->m_zplist[index].zptype == "0390") {           // 左前方触发照片
        //alg->cheliang_api_process(m, empty_mat, chepai, eFRONTLEFT, jieshushijian, img_out);
        pvehicle_inf->timeRecord.startTime();
        alg->dipandongtai_api_process(m1, m2, chepai, img_out);
        pvehicle_inf->timeRecord.endTime();
        pvehicle_inf->timeRecord.picture.process.zqfcf = pvehicle_inf->timeRecord.getTime();

        result.ZuoQianFangChuFa = img_out;
        DATA_PRINT(LEVEL_INFO, "finish zqfcf(0390) function.\n");
    } else if (pvehicle_inf->m_zplist[index].zptype == "0391") {    // 右后方触发照片
        //alg->cheliang_api_process(m, empty_mat, chepai, eBACKRIGHT, jieshushijian, img_out);
        pvehicle_inf->timeRecord.startTime();
        alg->dipandongtai_api_process(m1, m2, chepai, img_out);
        pvehicle_inf->timeRecord.endTime();
        pvehicle_inf->timeRecord.picture.process.yhfcf = pvehicle_inf->timeRecord.getTime();

        result.YouHouFangChuFa = img_out;
        DATA_PRINT(LEVEL_INFO, "finish zqfcf(0391) function.\n");
    } else if (pvehicle_inf->m_zplist[index].zptype == "0392") {   // 车架号触发照片
        //alg->cheliang_api_process(m, empty_mat, chepai, eBACKRIGHT, jieshushijian, img_out);
        pvehicle_inf->timeRecord.startTime();
        alg->dipandongtai_api_process(m1, m2, chepai, img_out);
        pvehicle_inf->timeRecord.endTime();
        pvehicle_inf->timeRecord.picture.process.cjhcf = pvehicle_inf->timeRecord.getTime();

        result.CheJiaHaoChuFa = img_out;
        DATA_PRINT(LEVEL_INFO, "finish cjhcf(0392) function.\n");
    } else {
        ;
    }
}

void vehicle_check_yhf(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!(g_CheckItem.picture.YouHouFang.ChePai
          || g_CheckItem.picture.YouHouFang.CheBiao
          || g_CheckItem.picture.YouHouFang.GaiZhuang
          || g_CheckItem.picture.YouHouFang.SanJiaoJia
          || g_CheckItem.picture.YouHouFang.ShuiYinRiQi)) {
        DATA_PRINT(LEVEL_INFO, "yhf(0111) has been skipped. \n");
        return;
    }

    std::string ChePai = g_CheckItem.picture.YouHouFang.ChePai ? pvehicle_inf->m_hphm : "";
    std::string JieShuShiJian = g_CheckItem.picture.YouHouFang.ShuiYinRiQi ? pvehicle_inf->m_jssj : "";
    JieShuShiJian=result.formatingDate(JieShuShiJian);
    // 区分大小车接口
    if ((pvehicle_inf->m_cllx.substr(0, 2)=="K3") || (pvehicle_inf->m_cllx.substr(0, 2)=="K4")) { // 小车
        ELogoType CheBiao;
        if (g_CheckItem.picture.YouHouFang.CheBiao) {
            unsigned int logo_index;
            BOOL b_found = FALSE;
            for (logo_index = 0; (logo_index < logo_data.size()) && (!b_found); logo_index++)
            {
                for (unsigned int name_index = 0; (name_index < logo_data[logo_index].matchname.size()) && (!b_found); name_index++)
                {
                    if (pvehicle_inf->m_clpp1.find(logo_data[logo_index].matchname[name_index]) == std::string::npos)
                    {
                        continue;
                    }
                    else
                    {
                        b_found = TRUE;
                        DATA_PRINT(LEVEL_DEBUG, "检索到车标%d-%s\n",
                                   logo_data[logo_index].logoindex, logo_data[logo_index].matchname[0].c_str());
                        break;
                    }
                }
                if (b_found)break;
            }

            result.Found_CheBiao = b_found;
            if (logo_index != logo_data.size()) {
                CheBiao = logo_data[logo_index].logoindex;
            } else {
                CheBiao = logo_data[0].logoindex;	/* 如果车标未检索到，则传入第一个车标 */
            }
        }
        else
        {
            CheBiao = logo_data[0].logoindex;	/* 如果不检查车标，则传入第一个车标。（处理结果时，会忽略车标，所以传什么都可以） */
        }
        (void)CheBiao;

        cv::Mat m_empty;	/* 右后方档案照片固定传入空mat */
        cv::Mat m = cv::imread(pvehicle_inf->m_zplist[index].local_path);
        vector<cv::Mat> empty;
        Cheliang_ImgOutMsg yhfdata;

        pvehicle_inf->timeRecord.startTime();

        //((LargeVehicleApi *)model_test)->cheliang_api_process(m, m_empty, ChePai, CheBiao, zqfdata);
        alg->cheliang_api_process(m, m_empty,empty ,ChePai,pvehicle_inf->m_cllx,pvehicle_inf->m_csys,eBACKRIGHT, yhfdata);
        alg->shuiyin_riqi_api_process(m, JieShuShiJian, result.bYouHouFangShuiYinRiQi);
        pvehicle_inf->timeRecord.endTime();
        pvehicle_inf->timeRecord.picture.process.yhf = pvehicle_inf->timeRecord.getTime();

        if(pvehicle_inf->m_syxz == "N")
        {
            Chemenpentu_ImgOutMsg out_msg;
            std::string ZaiKeShu = pvehicle_inf->m_hdzk;
            std::string ZongZhiLiang = pvehicle_inf->m_zzl;
            std::string LanBanGaoDu = pvehicle_inf->m_hxnbgd;
            alg->chemenpentu_api_process(m, ZongZhiLiang, LanBanGaoDu, ZaiKeShu, atoi(g_CheckItem.City.c_str()), out_msg);
            result.JiaoLianCheYouHouFang = out_msg;
        }

#ifdef LOGO_YINGSHEBIAO
        yhfdata.b_chebiao = result.isLogo(yhfdata.logo, pvehicle_inf->m_clpp1);
        pvehicle_inf->m_strYhfCheBiao = yhfdata.logo;
        DATA_PRINT(LEVEL_INFO, "YouHouFang path:%s, logo:%s, clpp:%s, b_chebiao:%d\n", pvehicle_inf->m_zplist[index].local_path.c_str(), yhfdata.logo.c_str(), pvehicle_inf->m_clpp1.c_str(), yhfdata.b_chebiao);
#endif
        result.YouHouFang = yhfdata;
    } else { // 大车
        cv::Mat m = cv::imread(pvehicle_inf->m_zplist[index].local_path);

        Huoche_ImgOutMsg yhfout;
        pvehicle_inf->timeRecord.startTime();
        alg->huoche_api_process(m, ChePai, eBACKRIGHT, yhfout, std::atoi(pvehicle_inf->m_cwkg.c_str())); // fix me 最后一个参数传入栏板高度，目前传入的不是，只是为了保证代码的完整性
        pvehicle_inf->timeRecord.endTime();
        pvehicle_inf->timeRecord.picture.process.zqf = pvehicle_inf->timeRecord.getTime();
#ifdef LOGO_YINGSHEBIAO
        yhfout.b_chebiao = result.isLogo(yhfout.logo, pvehicle_inf->m_clpp1);
        pvehicle_inf->m_strYhfCheBiao = yhfout.logo;
        DATA_PRINT(LEVEL_INFO, "HuoChe_YouHouFang path:%s, logo:%s, clpp:%s, b_chebiao:%d\n", pvehicle_inf->m_zplist[index].local_path.c_str(), yhfout.logo.c_str(), pvehicle_inf->m_clpp1.c_str(), yhfout.b_chebiao);
#endif
        result.HuoChe_YouHouFang = yhfout;
    }

#ifdef DEMO_TEST
    {
        string path = pvehicle_inf->m_zplist[index].demo_local_path;
        path += "_1.jpg";
        cv::Mat m_save = m.clone();
        if (yhfdata.b_sanjiaojia)
        {
            cv::rectangle(m_save, yhfdata.r_sanjiaojia, cv::Scalar(0, 0, 255), 3);
        }
        cv::rectangle(m_save, yhfdata.r_chebiao, cv::Scalar(0, 0, 255), 3);
        cv::rectangle(m_save, yhfdata.r_chepai, cv::Scalar(0, 0, 255), 3);

        cv::imwrite(path, m_save);

        //if (bhgs != record_bhgs) {
        //path = WstringToString(pvehicle_inf->m_zplist[index].demo_local_path);
        //path += "_0.jpg";
        //m_save = m.clone();
        //cv::imwrite(path, m_save);
        //}

        demo_data.yhf = true;
        string path1 = pvehicle_inf->m_zplist[index].demo_local_path;
        path1 += "_yhf_1.jpg"; //旋转后的原图
        cv::Mat myc = yhfdata.m;
        if (myc.empty())
        {
            myc = m.clone();
            cv::imwrite(path1, myc);
        }
        else
        {
            cv::imwrite(path1, myc);
        }
        demo_data.yhf_Cheliang_chepai = yhfdata.r_chepai;
        demo_data.yhf_Cheliang_chebiao = yhfdata.r_chebiao;
        demo_data.yhf_Cheliang_sanjiaojia = yhfdata.r_sanjiaojia;

        string path2 = pvehicle_inf->m_zplist[index].demo_local_path;
        path2 += "_yhf_2.jpg"; //color map
        cv::Mat mycc = yhfdata.m_mask;
        cv::imwrite(path2, mycc);

        string path3 = pvehicle_inf->m_zplist[index].demo_local_path;
        path3 += "_yhf_3.jpg"; //车辆外观图
        cv::Mat mycw = yhfdata.m_waiguan;
        cv::imwrite(path3, mycw);

        demo_data.yhf_Cheliang_refit = yhfdata.r_refit;

        demo_data.yhf_Cheliang_b_ori_waiguan = yhfdata.b_ori_waiguan;
        demo_data.yhf_Cheliang_b_chepai = yhfdata.b_chepai;
        demo_data.yhf_Cheliang_b_chebiao = yhfdata.b_chebiao;
        demo_data.yhf_Cheliang_b_sanjiaojia = yhfdata.b_sanjiaojia;
    }
#endif
}

bool get_zhaotong_vin_image(vehicle_inf *pvehicle_inf, std::string &path)
{
    std::string str_retval, str_code, str_message, str_b64value;
    str_retval.clear();
    HttpClient client;
    std::string request = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
    request += "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">";
    request += "<soapenv:Body>";
    request += "<ns1:writeObjectOut soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:ns1=\"http://endpoint.axis.rm.tmri.com\">";
    request += "<xtip xsi:type=\"xsd:string\">192.168.20.233</xtip>";
    request += "<sqm xsi:type=\"xsd:string\">345</sqm>";
    request += "<frame xsi:type=\"xsd:string\">11</frame>";
    request += "</ns1:writeObjectOut></soapenv:Body></soapenv:Envelope>";
    DATA_PRINT(LEVEL_INFO, "request string is: [%s] \n", request.c_str());

    const char *url = "http://192.168.41.240:8080/rminf/services/RmOutAccess?wsdl";
    if (client.InitData(url, REQUEST_POST_FLAG, (char *)"text/xml;charset=UTF-8", (char *)request.c_str())) {
        client.startHttpClient();
        try {
//            DATA_PRINT(LEVEL_INFO, "recv: [%s] \n\n", client.ResponseData.c_str());
            CMarkup xml;
            std::string data = client.ResponseData;
            xml.SetDoc(data);
            xml.ResetMainPos();
            if (xml.FindElem("soap:Envelope")) {
                xml.IntoElem();
                if (xml.FindElem("soap:Body")) {
                    xml.IntoElem();
                    if (xml.FindElem("ns2:writeObjectOutResponse")) {
                        if (xml.FindChildElem("return")) {
                            str_retval = xml.GetChildData();
                            DATA_PRINT(LEVEL_INFO, "返回值 \n%s\n", xml.GetChildData().c_str());
                        }
                    }
                }
            }

            if (!str_retval.empty()) {
                xml.SetDoc(str_retval);
                xml.ResetMainPos();
                if (xml.FindElem("root")) {
                    xml.IntoElem();
                    if (xml.FindElem("head")) {
                        if (xml.FindChildElem("code")) {
                            str_code = xml.GetChildData();
                        }
                        if (xml.FindChildElem("message")) {
                            str_message = xml.GetChildData();
                        }
                        if (xml.FindChildElem("value")) {
                            str_b64value = xml.GetChildData();
                        }
                        DATA_PRINT(LEVEL_INFO, "str_code=[%s]\nstr_message=[%s]\nstr_b64value=[%s]\n",
                                   str_code.c_str(), str_message.c_str(), str_b64value.c_str());
                    }
                }
            } else {
                DATA_PRINT(LEVEL_ERROR, "recv null \n");
            }

            if (str_code != "200") {
                DATA_PRINT(LEVEL_ERROR, "获取VIN照片错误. \n");
                return false;
            }

            if (str_b64value.empty()) {
                DATA_PRINT(LEVEL_ERROR, "照片错误. \n");
                return false;
            }

            std::string str_tmp/*("data:image/png;base64,")*/;
            str_tmp += str_b64value;
            size_t tt = str_tmp.size();
            std::string str_image = b64Decode(str_tmp.c_str(), tt);

            std::time_t t = std::time(NULL);
            std::tm *st = std::localtime(&t);
            char tmpArray[128] = { 0 };
            sprintf(tmpArray, "%d-%02d-%02d", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);
            std::string time = tmpArray;
            std::string str_name("/opt/vehicle/vehicle_photo/");
            str_name += time + "/";
            str_name += pvehicle_inf->m_clsbdh + ".jpg";
            path = str_name;

            FILE * fp = NULL;
            fp = fopen(str_name.c_str(), "w");
            if(fp == NULL) {
                DATA_PRINT(LEVEL_ERROR, "创建车架号照片文件失败.\n");
                return false;
            }
            size_t l = str_image.size();
            fwrite(str_image.c_str(), 1, l, fp);
            fflush(fp);
            fclose(fp);
            return true;
        } catch (const exception &e) {
            DATA_PRINT(LEVEL_ERROR, "Error %s\n", e.what());
            return false;
        }
    } else { // httpclient 初始化失败
        DATA_PRINT(LEVEL_ERROR, "GetInsMsg init httpclient failed. \n");
        return false;
    }
}

void get_current_data(std::string& str_cur_date)
{
    std::time_t t = std::time(NULL);
    std::tm *st = std::localtime(&t);

    char cur_date[64] = {0};
    sprintf(cur_date, "%d%02d%02d", st->tm_year+1900, st->tm_mon+1, st->tm_mday);
    str_cur_date = std::string(cur_date);
}

bool get_nanjing_vin_image(vehicle_inf *pvehicle_inf, std::string &path)
{
    std::string str_request = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
    str_request += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">";
    str_request += "<soap:Body>";
    str_request += "<querytj xmlns=\"http://tempuri.org/\">";
    const std::string str_key("85642523");
    std::string str_date("");
    get_current_data(str_date);
    std::string str_yzm = des_encrypt(str_date, str_key);

    str_request += "<yzm>" + str_yzm + "</yzm>";
    str_request += "<xmldoc1>" + pvehicle_inf->m_clsbdh + "</xmldoc1>";
    str_request += "<xmldoc2></xmldoc2>";
    str_request += "<type>shyk</type>";
    str_request += "</querytj></soap:Body></soap:Envelope>";
    DATA_PRINT(LEVEL_INFO, "get_nanjing_vin_image request string is: [%s] \n", str_request.c_str());

    HttpClient client;
    const char *url = "http://11.1.0.131:80/webserv/cxgquery.asmx";
    char *content_type = "text/xml; charset=utf-8";
    char *soap_action = "\"http://tempuri.org/querytj\"";
    client.init_data(url, REQUEST_POST_FLAG, content_type, (char *)str_request.c_str(), soap_action);
    client.startHttpClient();
   /* client.m_photo_filename =  "/opt/vehicle/vehicle_photo/";
    client.m_photo_filename += pvehicle_inf->m_clsbdh;
    client.m_photo_filename += ".txt";
    DATA_PRINT(LEVEL_INFO, "get_nanjing_vin_image filename:%s\n",  client.m_photo_filename.c_str());
    client.Save_PhotoData_To_LocalFile((unsigned char *)client.ResponseData.c_str(), strlen(client.ResponseData.c_str())); */
    DATA_PRINT(LEVEL_INFO, "get_nanjing_vin_image recv: %s\n", client.ResponseData.c_str());
    if(strlen(client.ResponseData.c_str()) > 0)
    {
        try {
            CMarkup xml;
            std::string data = client.ResponseData;
            std::string strQuerytjResult;
            xml.SetDoc(data);
            xml.ResetMainPos();
            if (xml.FindElem("soap:Envelope")) {
                xml.IntoElem();
                if (xml.FindElem("soap:Body")) {
                     xml.IntoElem();
                    if (xml.FindElem("querytjResponse")) {
                        xml.IntoElem();
                        if (xml.FindElem("querytjResult")) {
                            strQuerytjResult = xml.GetData();
                        }
                    }
                }
            }

            while (strQuerytjResult.find("&lt;") != std::string::npos)
             {
                 size_t offset = strQuerytjResult.find("&lt;");
                 strQuerytjResult.replace(offset, 4, "<");
             }
             while (strQuerytjResult.find("&gt;") != std::string::npos)
             {
                 size_t offset = strQuerytjResult.find("&gt;");
                 strQuerytjResult.replace(offset, 4, ">");
             }
            std::string strImg;

            if (!strQuerytjResult.empty()) {
                xml.SetDoc(strQuerytjResult);
                xml.ResetMainPos();

            if (xml.FindElem("root")) {
                xml.IntoElem();
                if(xml.FindElem("body"))
                {
                   xml.IntoElem();
                   while (xml.FindElem("img")) {
                       if(strlen(xml.GetData().c_str()) > 0)
                       {
                           strImg = xml.GetData();
                       }
                    }
                }
             }

            } else {
                DATA_PRINT(LEVEL_INFO, "recv img data null \n");
            }

            if (strImg.empty()) {
                DATA_PRINT(LEVEL_INFO, "照片错误. \n");
                return false;
            }

            std::string str_tmp;
            str_tmp += strImg;
            size_t tt = str_tmp.size();
            std::string str_image = b64Decode(str_tmp.c_str(), tt);


            std::string str_name = g_photoFilePath;
            std::time_t t = std::time(NULL);
            std::tm *st = std::localtime(&t);
            char tmpArray[128] = { 0 };
            sprintf(tmpArray, "%d-%02d-%02d", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);
            std::string strCurTime = tmpArray;
            str_name += strCurTime;

            struct stat st_buf = {};
            stat(str_name.c_str(), &st_buf);
            if ((st_buf.st_mode & S_IFMT) != S_IFDIR) {
                mkdir(str_name.c_str(), 0777);
            }
            str_name += "/";
            str_name += pvehicle_inf->m_clsbdh + ".jpg";
            path = str_name;


            FILE * fp = NULL;
            fp = fopen(str_name.c_str(), "w");
            if(fp == NULL) {
                DATA_PRINT(LEVEL_INFO, "创建查验表照片文件失败.\n");
                return false;
            }
            size_t l = str_image.size();
            fwrite(str_image.c_str(), 1, l, fp);
            fflush(fp);
            fclose(fp);
            return true;
        } catch (const exception &e) {
            DATA_PRINT(LEVEL_ERROR, "Error %s\n", e.what());
            return false;
        }
    }

}

void vehicle_check_cjh(vehicle_inf *pvehicle_inf, UINT index, UINT TaYinMo_Index, int JiLuBiaoZiMo_Index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!(g_CheckItem.picture.CheJiaHao.BaoDing_FTP
          || g_CheckItem.picture.CheJiaHao.CheJiaHao
          || g_CheckItem.picture.CheJiaHao.JiLuBiaoZiMo
          || g_CheckItem.picture.CheJiaHao.ShuiYinRiQi
          || g_CheckItem.picture.CheJiaHao.TaYinMo)) {
        DATA_PRINT(LEVEL_INFO, "cjh(0113) has been skipped. \n");
        return;
    }

    std::string CheJiaHao = g_CheckItem.picture.CheJiaHao.CheJiaHao ? pvehicle_inf->m_clsbdh : "";
    std::string ShuiYinRiQi = g_CheckItem.picture.CheJiaHao.ShuiYinRiQi ? pvehicle_inf->m_jssj : "";
    ShuiYinRiQi = result.formatingDate(ShuiYinRiQi);
    Chejiahao_ImgOutMsg cjhdata;
    Chejiahao_ImgOutMsg jlbzmdata;
    cv::Mat m = cv::imread(pvehicle_inf->m_zplist[index].local_path);

    cv::Mat m2;
    cv::Mat m3;
    std::string str_path("");
    if ((ZHAOTONG == g_CheckItem.City) && (!g_TestMode))
    {
        if (get_zhaotong_vin_image(pvehicle_inf, str_path))
        {
            DATA_PRINT(LEVEL_INFO, "get_zhaotong_vin_image success. \n");
            m2 = cv::imread(str_path);
        }
    }
    else if ((NANJING == g_CheckItem.City) && (!g_TestMode) && (g_CheckItem.picture.CheJiaHao.b_nanjing_vin))
    {
        if (get_nanjing_vin_image(pvehicle_inf, str_path))
        {
            DATA_PRINT(LEVEL_INFO, "get_nanjing_vin_image success. \n");
            m2 = cv::imread(str_path);
        }
    }
    else
    {
        int n_TaYinMo_Index = (int)TaYinMo_Index;
        if (n_TaYinMo_Index != -1) {
            m2 = cv::imread(pvehicle_inf->m_zplist[TaYinMo_Index].local_path);
        }

        if (g_CheckItem.picture.CheJiaHao.BaoDing_FTP) {
            if (pvehicle_inf->BaoDing_J_FTP != "TBD") {
                m2 = cv::imread(pvehicle_inf->BaoDing_J_FTP);
                result.TaYinMo_J = true;
            } else {
                result.TaYinMo_J = false;
            }
        }
    }
    pvehicle_inf->timeRecord.startTime();
    if(g_CheckItem.City == SUZHOU)
    {
        alg->chejiaohao_api_process(m, m2, CheJiaHao,"", cjhdata,result.suzhou_compareType);
        alg->shuiyin_riqi_api_process(m, ShuiYinRiQi, result.bCheJiaHaoShuiYinRiQi);
    }
    else
    {
        alg->chejiaohao_api_process(m, m2, CheJiaHao,"", cjhdata);
        alg->shuiyin_riqi_api_process(m, ShuiYinRiQi, result.bCheJiaHaoShuiYinRiQi);
    }
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.cjh = pvehicle_inf->timeRecord.getTime();

     if(g_CheckItem.picture.CheJiaHao.JiLuBiaoZiMo)
     {
         if(JiLuBiaoZiMo_Index!=-1)
         {
               m3=cv::imread(pvehicle_inf->m_zplist[JiLuBiaoZiMo_Index].local_path);
               if(pvehicle_inf->m_zplist[JiLuBiaoZiMo_Index].local_path!="TBD")
               {
                  alg->chejiaohao_api_process(m, m3, CheJiaHao,"", jlbzmdata);
                  alg->shuiyin_riqi_api_process(m, ShuiYinRiQi, result.bCheJiaHaoShuiYinRiQi);
               }
               else
               {
                   jlbzmdata.b_chejiahao=true;
               }

         }
         else
         {
             jlbzmdata.b_chejiahao=true;
         }
         cjhdata.b_chejiahao= cjhdata.b_chejiahao&&jlbzmdata.b_chejiahao;
     }

    result.CheJiaHao = cjhdata;

#ifdef DEMO_TEST
    {
        string path = pvehicle_inf->m_zplist[index].demo_local_path;
        path += "_1.jpg";
        cv::Mat m_save = cjhdata.m.clone();
        if (!cjhdata.b_chejiahao)
        {
            m_save = m.clone();
        }
        cv::rectangle(m_save, cjhdata.r, cv::Scalar(0, 0, 255), 3);

        cv::imwrite(path, m_save);

        //if (!cjhdata.b_chejiahao) {
        //path = WstringToString(pvehicle_inf->m_zplist[index].demo_local_path);
        //path += "_0.jpg";
        //m_save = m.clone();
        //cv::imwrite(path, m_save);
        //}

        //7.13修改演示内容
        demo_data.cjh = true;
        string path1 = pvehicle_inf->m_zplist[index].demo_local_path;
        path1 += "_cjh_1.jpg"; //旋转后的原图
        cv::Mat mc = cjhdata.m;
        if (mc.empty())
        {
            mc = m.clone();
            cv::imwrite(path1, mc);
        }
        else
        {
            cv::imwrite(path1, mc);
        }
        demo_data.Chejiahao_r = cjhdata.r;

        cv::Mat mcr = cjhdata.roi_m;
        string path2 = pvehicle_inf->m_zplist[index].demo_local_path;
        path2 += "_cjh_2.jpg";//车架号roi图
        cv::imwrite(path2, mcr);

        string path3 = pvehicle_inf->m_zplist[index].demo_local_path;
        path3 += "_cjh_3.jpg";//红框标记后，车架号roi图
        int point = 0 , width = 0, height;
        for (vector<cv::Rect>::iterator i = (cjhdata.rect).begin(); i != (cjhdata.rect).end(); ++i)
        {
            width += (*i).width;
            if(height <(*i).height)
                height = (*i).height;
        }
        cv::Mat  mcrb;
        cv::Size size(width,height);
        mcrb.create(size, CV_MAKETYPE(cjhdata.roi_m.depth(), 3));
        mcrb = Scalar::all(0);
//        for (vector<cv::Rect>::iterator i = (cjhdata.rect).begin(); i != (cjhdata.rect).end(); ++i)
//        {
//            cv::Mat buffer ,buffer2;
//            buffer2 = cjhdata.roi_m.clone();
//            cv::rectangle(buffer2, *i, cv::Scalar(0, 0, 255), 3);
//            buffer = buffer2(*i);
//            buffer.copyTo(mcrb(Rect(point, 0, (*i).width, (*i).height)));
//            point += (*i).width;
//            //cv::rectangle(mcr, *i, cv::Scalar(0, 0, 255), 3);
//        }
        for (int  i =0; i < cjhdata.rect.size(); i++)
        {
            cv::Mat buffer ,buffer2;
            buffer2 = cjhdata.roi_m.clone();
            cv::rectangle(buffer2, cjhdata.rect[i], cv::Scalar(0, 0, 255), 3);
            buffer=buffer2(cjhdata.rect[i]).clone();
            buffer.copyTo(mcrb(Rect(point, 0, cjhdata.rect[i].width, cjhdata.rect[i].height)));
            point += cjhdata.rect[i].width;
            //cv::rectangle(mcr, *i, cv::Scalar(0, 0, 255), 3);
        }

        cv::imwrite(path3, mcrb);
        demo_data.Chejiahao_b_pic_quality = cjhdata.b_pic_quality;
        demo_data.Chejiahao_b_chejiahao = cjhdata.b_chejiahao;
        //输出是否通过     bool b_chejiahao;
    }
#endif
}

void vehicle_check_aqd(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!(g_CheckItem.picture.AnQuanDai.AnQuanDai
          || g_CheckItem.picture.AnQuanDai.ShuiYinRiQi)) {
        DATA_PRINT(LEVEL_INFO, "aqd(0157) has been skipped. \n");
        return;
    }
    std::string ShuiYinRiQi = g_CheckItem.picture.AnQuanDai.ShuiYinRiQi ? pvehicle_inf->m_jssj : "";
    ShuiYinRiQi = result.formatingDate(ShuiYinRiQi);
    Anquandai_ImgOutMsg aqddata;
    cv::Mat m = cv::imread(pvehicle_inf->m_zplist[index].local_path);

    pvehicle_inf->timeRecord.startTime();
    alg->anquandai_api_process(m, aqddata);
    alg->shuiyin_riqi_api_process(m, ShuiYinRiQi, result.bAnQuanDaiShuiYinRiQi);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.aqd = pvehicle_inf->timeRecord.getTime();

    result.AnQuanDai = aqddata;

#ifdef DEMO_TEST
    {
        string path = pvehicle_inf->m_zplist[index].demo_local_path;
        path += "_1.jpg";
        cv::Mat m_save = m.clone();
        if (aqddata.b_anquandai)
        {
            cv::rectangle(m_save, aqddata.r, cv::Scalar(0, 0, 255), 3);
        }

        cv::imwrite(path, m_save);

        //if (aqddata.score < atof(g_aqd_score.c_str())) {
        //path = WstringToString(pvehicle_inf->m_zplist[index].demo_local_path);
        //path += "_0.jpg";
        //m_save = m.clone();
        //cv::imwrite(path, m_save);
        //}

        demo_data.aqd = true;
        cv::Mat ma = aqddata.m;
        string path1 = pvehicle_inf->m_zplist[index].demo_local_path;
        path1 += "_aqd_1.jpg";//安全带照片
        if (ma.empty())
        {
            ma = m.clone();
            cv::imwrite(path1, ma);
        }
        else
        {
            cv::imwrite(path1, ma);
        }
        demo_data.Anquandai_r = aqddata.r;
        demo_data.Anquandai_b_anquandai = aqddata.b_anquandai;
    }
#endif
}

void vehicle_check_jcjlb(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result, char *code)
{
    if (!(g_CheckItem.picture.ChaYanJiLu.ChaYanJieLun
          || g_CheckItem.picture.ChaYanJiLu.ChaYanQianZi
          || g_CheckItem.picture.ChaYanJiLu.ChaYanXinXi
          || g_CheckItem.picture.ChaYanJiLu.CheJiaHao
          || g_CheckItem.picture.ChaYanJiLu.ChePai
          || g_CheckItem.picture.ChaYanJiLu.DiPanQianZi
          || g_CheckItem.picture.ChaYanJiLu.JianYanBiao
          || g_CheckItem.picture.ChaYanJiLu.WaiGuanQianZi
          || g_CheckItem.picture.ChaYanJiLu.YinCheQianZi)) {
        DATA_PRINT(LEVEL_INFO, "cyjlb(%s) has been skipped. \n", code);
        return;
    }

    std::string CheJiaHao = g_CheckItem.picture.ChaYanJiLu.CheJiaHao ? pvehicle_inf->m_clsbdh : "";
    std::string ChePai = g_CheckItem.picture.ChaYanJiLu.ChePai ? pvehicle_inf->m_hphm : "";

    std::time_t t = std::time(NULL);
    std::tm *st = std::localtime(&t);
    char tmpArray[64] = { 0 };
    sprintf(tmpArray, "%d%02d%02d", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);
    std::string Today = tmpArray;

    Jianyanbiao_ImgOutMsg out_msg;
    cv::Mat m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path);

    pvehicle_inf->timeRecord.startTime();
    alg->jianyanbiao_api_process(m1, ChePai, CheJiaHao, Today, out_msg);
    //((LargeVehicleApi *)model_test)->jianyanbiao_api_process(m1, out_msg);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.cyjl = pvehicle_inf->timeRecord.getTime();

    result.ChaYanJiLu = out_msg;

#ifdef DEMO_TEST
    {
        demo_data.jyb = true;
        string path1 = pvehicle_inf->m_zplist[index].demo_local_path;
        path1 += "_jyb_1.jpg";
        cv::Mat jybr = jybdata.m_rotate;
        if (jybr.empty())
        {
            jybr = m1.clone();
            cv::imwrite(path1, jybr);
        } else
        {
            cv::imwrite(path1, jybr);
        }
        demo_data.Jianyanbiao_table = jybdata.r_table;

        string path2 = pvehicle_inf->m_zplist[index].demo_local_path;
        path2 += "_jyb_2.jpg";
        cv::Mat jybt = jybdata.m_table;
        cv::imwrite(path2, jybt); //表格图片
        demo_data.Jianyanbiao_rect1 = jybdata.rect[0];
        demo_data.Jianyanbiao_rect2 = jybdata.rect[1];
        demo_data.Jianyanbiao_rect3 = jybdata.rect[2];

        demo_data.Jianyanbiao_b_jianyanbiao = jybdata.b_jianyanbiao;
        demo_data.Jianyanbiao_b_waiguan_sign = jybdata.b_waiguan_sign;
        demo_data.Jianyanbiao_b_yinche_sign = jybdata.b_yinche_sign;
        demo_data.Jianyanbiao_b_dipan_sign = jybdata.b_dipan_sign;
    }
#endif
}

void vehicle_check_ccs_or_ms(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
//    if (!g_CheckItem.picture.WanShuiZhengMing.CheJiaHao) {
//        DATA_PRINT(LEVEL_INFO, "ccs_or_ms(0206) has been skipped. \n");
//        return;
//    }

    std::string CheJiaHao = g_CheckItem.picture.WanShuiZhengMing.CheJiaHao ? pvehicle_inf->m_clsbdh : "";
    std::string ChePai = g_CheckItem.picture.WanShuiZhengMing.ChePai ? pvehicle_inf->m_clpp1 : "";
    std::string JianCeRiQi = g_CheckItem.picture.WanShuiZhengMing.JianCeRiQi ? result.formatingDate(pvehicle_inf->m_jssj) : "";
    std::string sxrq = pvehicle_inf->m_sxrq;
    std::string zzrq = pvehicle_inf->m_zzrq;
    Wanshuizhengming_ImgOutMsg out_msg;
    cv::Mat m = cv::imread(pvehicle_inf->m_zplist[index].local_path);

    pvehicle_inf->timeRecord.startTime();
    alg->wanshuizhengming_api_process(m, ChePai, CheJiaHao, JianCeRiQi, out_msg);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.wszm = pvehicle_inf->timeRecord.getTime();

    result.WanShuiZhengMing = out_msg;
    if ( (g_CheckItem.City == HENGSHUI) ||
         (g_CheckItem.City == TIANJIN) ||
         (g_CheckItem.City == FOSHAN) ||
         (g_CheckItem.City == JIAOZUO) ||
         (g_CheckItem.City == SHENZHEN))
    {
        if(g_CheckItem.picture.WanShuiZhengMing.BaoXianDan)
        {
            if(!out_msg.b_chechuanshui)
            {
                Baodan_ImgOutMsg out_msg1;
                int hdzks = baseTool::str2Int(pvehicle_inf->m_hdzk);
                alg->baodan_api_process(m, ChePai, CheJiaHao, "", pvehicle_inf->m_fdjh, hdzks, out_msg1);
                result.WanShuiBaoDan = out_msg1;
            }
        }
    }

}

void vehicle_check_hgbztzs(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if(g_CheckItem.City==NINGBO) {
        pvehicle_inf->is_waisheng=true;
    }
    if (!(g_CheckItem.picture.WeiTuoTongZhiShu.CheJiaHao
          || g_CheckItem.picture.WeiTuoTongZhiShu.ChePai)) {
        DATA_PRINT(LEVEL_INFO, "hgbztzs(0207) has been skipped. \n");
        return;
    }

    std::string CheJiaHao = g_CheckItem.picture.WeiTuoTongZhiShu.CheJiaHao ? pvehicle_inf->m_clsbdh : "";
    std::string ChePai = g_CheckItem.picture.WeiTuoTongZhiShu.ChePai ? pvehicle_inf->m_hphm : "";

    Weituotongzhishu_ImgOutMsg out_msg;
    cv::Mat m = cv::imread(pvehicle_inf->m_zplist[index].local_path);

    pvehicle_inf->timeRecord.startTime();
    alg->weituotongzhishu_api_process(m, ChePai, CheJiaHao,out_msg);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.wttzs = pvehicle_inf->timeRecord.getTime();

    result.WeiTuoHeGeTongZhiShu = out_msg;
}

/* 0212:机动车检验合格证明(南京独有) */
void NanJing_jyhgzm(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    std::string RiQi = result.formatingDate(pvehicle_inf->m_jssj);

    Jianyanhege_ImgOutMsg out_msg;
    cv::Mat m = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    pvehicle_inf->timeRecord.startTime();
    alg->jianyanhege_api_process(m, pvehicle_inf->m_hphm, pvehicle_inf->m_clsbdh, RiQi, out_msg);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.jyhgzm = pvehicle_inf->timeRecord.getTime();

    result.JianYanHeGe = out_msg;
}

/* 制动性能路试记录单 */
void process_LuShiJiLuDan(vehicle_inf *pvehicle_inf, int index, LargeVehicleApi *alg, ResultCollection &result)
{
    Jiludan_ImgOutMsg out_msg;
    cv::Mat m = cv::imread(pvehicle_inf->m_zplist[index].local_path);

    alg->jiludan_api_process(m, out_msg);
    result.LuShiJiLuDan = out_msg;
}

/* 路试制动开始 */
void process_LuShiKaiShi(vehicle_inf *pvehicle_inf, int index, LargeVehicleApi *alg, ResultCollection &result)
{
    Dipandongtai_ImgOutMsg out_msg;
    cv::Mat m = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    //std::string ShuiYi;

    alg->dipandongtai_api_process(m, m, pvehicle_inf->m_hphm, out_msg);
    result.LuShiKaiShi = out_msg;
}

/* 路试制动结束 */
void process_LuShiJieShu(vehicle_inf *pvehicle_inf, int index, LargeVehicleApi *alg, ResultCollection &result)
{
    Dipandongtai_ImgOutMsg out_msg;
    cv::Mat m = cv::imread(pvehicle_inf->m_zplist[index].local_path);


    alg->dipandongtai_api_process(m, m, pvehicle_inf->m_hphm, out_msg);
    result.LuShiJieShu = out_msg;
}

bool nanjing_wrw(vehicle_inf * pvehicle_inf, std::string check_type)
{
    bool b_ret_env = false, b_tag_no = false, b_vin = false;
    HttpClient client;

    std::string request, basestr, data, report_type, padding("</GetEnvMsg></soap:Body></soap:Envelope>");
    {
        basestr = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
        basestr += "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" ";
        basestr += "xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">";
        basestr += "<soap:Body>";
        basestr += "<GetEnvMsg xmlns=\"http://impl.webservice.store.com/\">";
        data = "<ip xmlns=\"\">" + g_localServerIp + "</ip>";
        data += "<mac xmlns=\"\">" + g_localMac + "</mac>";
        data += "<cjh xmlns=\"\">" + pvehicle_inf->m_clsbdh + "</cjh>";
        report_type = "<bglx xmlns=\"\">" + check_type + "</bglx>";
        request = basestr + data + report_type + padding;
    }
    DATA_PRINT(LEVEL_INFO, " Check type [ %s ] request string is: [%s] \n", check_type.c_str(), request.c_str());

    if (client.InitData("http://11.1.0.192:8080/EnvMsg/EnvMsg?wsdl", REQUEST_POST_FLAG, (char *)HTTP_CONTENT_TYPE_TEXT_XML, (char *)request.c_str())) {
        client.startHttpClient();
        if (client.ResponseData.find("成功") != std::string::npos) { // get data succeed
            DATA_PRINT(LEVEL_INFO, "[%s] response succeed info: [%s] \n", check_type.c_str(), client.ResponseData.c_str());
            std::string::size_type n;

            std::string str_find_passed, str_find_tag_no, str_find_vin;
            if (check_type.find("LUG") != std::string::npos) {
                str_find_passed = ",passed:";
                str_find_tag_no = ",vehicle_tag_no:";
                str_find_vin = ",undercarriage_no:";
            } else {
                str_find_passed = ",PASSED:";
                str_find_tag_no = ",VEHICLE_TAG_NO:";
                str_find_vin = ",UNDERCARRIAGE_NO:";
            }
            if ((n= client.ResponseData.find(str_find_passed)) != std::string::npos) { // find environment result
                std::string result_of_passed = client.ResponseData.substr(n+str_find_passed.size(), 1);
                if((result_of_passed.compare("Y")==0) || (result_of_passed.compare("y")==0)) { // 环保单结果通过
                    DATA_PRINT(LEVEL_INFO, "[%s] 环保单结果 [%s]. \n", check_type.c_str(), result_of_passed.c_str());
                    b_ret_env = true;
                } else {
                    DATA_PRINT(LEVEL_ERROR, "[%s] 环保单结果 [%s]. \n", check_type.c_str(), result_of_passed.c_str());
                }
            } else {
                DATA_PRINT(LEVEL_ERROR, "[%s] response NOT find the string has \"%s\". \n", check_type.c_str(), str_find_passed.c_str());
            }

            if ((n=client.ResponseData.find(str_find_tag_no)) != std::string::npos) { // find tag_no
                std::string tmp_tag_no = client.ResponseData.substr(n+str_find_tag_no.size());
                n = tmp_tag_no.find_first_of(",");
                std::string tag_no = tmp_tag_no.substr(0, n);
                if (tag_no.find(pvehicle_inf->m_hphm) != std::string::npos) {
                    DATA_PRINT(LEVEL_INFO, "[%s] 车牌号 [%s]. \n", check_type.c_str(), tag_no.c_str());
                    b_tag_no = true;
                } else {
                    DATA_PRINT(LEVEL_ERROR, "[%s] 车牌号 [%s]. \n", check_type.c_str(), tag_no.c_str());
                }
            } else {
                DATA_PRINT(LEVEL_ERROR, "[%s] response NOT find the string has \"%s\". \n", check_type.c_str(), str_find_tag_no.c_str());
            }

            if ((n=client.ResponseData.find(str_find_vin)) != std::string::npos) {
                std::string tmp_vin = client.ResponseData.substr(n+str_find_vin.size());
                n = tmp_vin.find_first_of(",");
                std::string vin = tmp_vin.substr(0, n);
                if (vin.find(pvehicle_inf->m_clsbdh) != std::string::npos) {
                    DATA_PRINT(LEVEL_INFO, "[%s] 车架号 [%s]. \n", check_type.c_str(), vin.c_str());
                    b_vin = true;
                } else {
                    DATA_PRINT(LEVEL_ERROR, "[%s] 车架号 [%s]. \n", check_type.c_str(), vin.c_str());
                }
            } else {
                DATA_PRINT(LEVEL_ERROR, "[%s] response NOT find the string has \"%s\". \n", check_type.c_str(), str_find_vin.c_str());
            }
        } else {            // 返回结果没有成功字段
            DATA_PRINT(LEVEL_INFO, "%s response failed info: [%s] \n", check_type.c_str(), client.ResponseData.c_str());
            return false;
        }
    } else {        // httpclient 初始化失败
        DATA_PRINT(LEVEL_ERROR, "[%s] init httpclient failed. \n", check_type.c_str());
        return false;
    }
    return (b_ret_env && b_tag_no && b_vin);
}

void set_result_wrw(ResultCollection &result, bool b_val)
{
    if (b_val) {
        result.WuRanWu.b_jiancejielun = true;
        result.WuRanWu.b_jiancejielun = true;
        result.WuRanWu.b_chepai = true;
        result.WuRanWu.b_chejiahao = true;
        result.WuRanWu.b_yinzhang = true;
        result.WuRanWu.b_qianzi = true;
        result.WuRanWu.b_MA = true;
        result.WuRanWu.b_qianzi_caozuoyuan = true;
        result.WuRanWu.b_qianzi_jiashiyuan = true;
        result.WuRanWu.b_qianzi_shenheyuan = true;
        result.WuRanWu.b_qianzi_pizhunren = true;
        result.WuRanWu.b_riqi_shijian = true;
        result.WuRanWu.b_huanbaodan = true;
        result.WuRanWu.b_dianzibiaoge = true;
        result.WuRanWu.b_valid_date = true;
        result.WuRanWu.b_engine_num = true;
    } else {
        result.WuRanWu.b_jiancejielun = false;
        result.WuRanWu.b_jiancejielun = false;
        result.WuRanWu.b_chepai = false;
        result.WuRanWu.b_chejiahao = false;
        result.WuRanWu.b_yinzhang = false;
        result.WuRanWu.b_qianzi = false;
        result.WuRanWu.b_MA = false;
        result.WuRanWu.b_qianzi_caozuoyuan = false;
        result.WuRanWu.b_qianzi_jiashiyuan = false;
        result.WuRanWu.b_qianzi_shenheyuan = false;
        result.WuRanWu.b_qianzi_pizhunren = false;
        result.WuRanWu.b_riqi_shijian = false;
        result.WuRanWu.b_huanbaodan = false;
        result.WuRanWu.b_dianzibiaoge = false;
        result.WuRanWu.b_valid_date = false;
        result.WuRanWu.b_engine_num = false;
    }
}

void vehicle_check_wrw(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!(g_CheckItem.picture.WeiQiJianYan.CheJiaHao
          || g_CheckItem.picture.WeiQiJianYan.ChePai
          || g_CheckItem.picture.WeiQiJianYan.JieLun
          || g_CheckItem.picture.WeiQiJianYan.QianMing
          || g_CheckItem.picture.WeiQiJianYan.YinZhang
          || g_CheckItem.picture.WeiQiJianYan.YinZhang_MA)) {
        DATA_PRINT(LEVEL_INFO, "wqjy has been skipped. \n");
        return;
    }

    bool b_open = true; // 控制电子保单开启
    if ((g_CheckItem.City == NANJING) && (!g_TestMode) && (b_open)) {  // 从 11.1.0.240:8080/EnvMsg?wsdl 获取数据
        std::string str_asm("ASM");
        std::string str_idle("IDLE");
        std::string str_filt("FILT");
        std::string str_lug("LUG");
        bool b_asm_ret = false, b_idle_ret = false, b_filt_ret = false, b_lug_ret = false, b_electronic_data = true;

        b_asm_ret = nanjing_wrw(pvehicle_inf, str_asm);
        if (!b_asm_ret) {
            DATA_PRINT(LEVEL_ERROR, "asm failed. \n");
            b_idle_ret = nanjing_wrw(pvehicle_inf, str_idle);
            if (!b_idle_ret) {
                DATA_PRINT(LEVEL_ERROR, "idle failed. \n");
                b_filt_ret = nanjing_wrw(pvehicle_inf, str_filt);
                if (!b_filt_ret) {
                    DATA_PRINT(LEVEL_ERROR, "filt failed. \n");
                    b_lug_ret = nanjing_wrw(pvehicle_inf, str_lug);
                    if (!b_lug_ret) {
                        DATA_PRINT(LEVEL_ERROR, "lug failed. \n");
                        b_electronic_data = false;
                    }
                }
            }
        }

        if (b_electronic_data) {
            set_result_wrw(result, b_electronic_data);
            DATA_PRINT(LEVEL_INFO, "跳过环保单图片检测，使用电子数据. \n");
            return;
        }
    }

    std::string CheJiaHao = g_CheckItem.picture.WeiQiJianYan.CheJiaHao ? pvehicle_inf->m_clsbdh : "";
    std::string ChePai = g_CheckItem.picture.WeiQiJianYan.ChePai ? pvehicle_inf->m_hphm : "";
    //std::string shijian1 = g_CheckItem.picture.WeiQiJianYan.JianCeShiJian ? pvehicle_inf->dz_wqjcrq : "";
    std::string shijian1 = g_CheckItem.picture.WeiQiJianYan.JianCeShiJian ? pvehicle_inf->dz_wqjcrq : "";
    std::string fadongjixinghao = g_CheckItem.picture.WeiQiJianYan.FaDongJiBianHao ? pvehicle_inf->m_fdjxh : "";
    std::string jssj = "";
    std::string RiQi = result.formatingDate(shijian1);
    vector<std::string> ShiJian;
    std::string time = result.formatingTime(shijian1);
    ShiJian.push_back(time);

    DATA_PRINT(LEVEL_INFO, "dz_wqjcrq = %s.%s \n",RiQi.c_str(),time.c_str());
    if( g_CheckItem.picture.WeiQiJianYan.YouXiaoQi)
    {
        std::time_t t = std::time(NULL);
        std::tm *st = std::localtime(&t);
        char tmpArray[128] = { 0 };
        sprintf(tmpArray, "%d%02d%02d", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);
        jssj = tmpArray;
    }
    Huanbaodan_ImgOutMsg out_msg;
    cv::Mat m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path); 
    cv::Mat m2;
    pvehicle_inf->timeRecord.startTime();
    alg->huanbaodan_api_process(m1, m2, ChePai, CheJiaHao, RiQi, ShiJian, jssj, fadongjixinghao, pvehicle_inf->m_clxh, out_msg);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.wqjy = pvehicle_inf->timeRecord.getTime();

    result.WuRanWu = out_msg;

    Huanbaodan_ImgOutMsg hbddata = out_msg; //9.4
    //cv::Mat m = cv::imread(WstringToString(pvehicle_inf->m_zplist[index].local_path));

#ifdef DEMO_TEST
    {
        demo_data.hbd = true;
        string path1 = pvehicle_inf->m_zplist[index].demo_local_path;
        path1 += "_hbd_1.jpg";
        cv::Mat hbdr = hbddata.m_rotate;
        if (hbdr.empty())
        {
            hbdr = m1.clone();
            cv::imwrite(path1, hbdr);
        } else
        {
            cv::imwrite(path1, hbdr);
        }
        demo_data.Huanbaodan_table = hbddata.r_table;
        demo_data.Huanbaodan_chepai = hbddata.r_chepai;
        demo_data.Huanbaodan_chejiahao = hbddata.r_chejiahao;
        demo_data.Huanbaodan_yinzhang = hbddata.r_yinzhang;
        demo_data.Huanbaodan_qianzi = hbddata.r_qianzi;

        string path2 = pvehicle_inf->m_zplist[index].demo_local_path;
        path2 += "_hbd_2.jpg";
        cv::Mat hbdt = hbddata.m_table;
        cv::imwrite(path2, hbdt); //表格
        demo_data.Huanbaodan_jiancejielun = hbddata.r_jiancejielun;

        demo_data.Huanbaodan_b_jiancejielun = hbddata.b_jiancejielun;
        demo_data.Huanbaodan_b_chepai = hbddata.b_chepai;
        demo_data.Huanbaodan_b_chejiahao = hbddata.b_chejiahao;
        demo_data.Huanbaodan_b_yinzhang = hbddata.b_yinzhang;
        demo_data.Huanbaodan_b_qianzi = hbddata.b_qianzi;

    }
#endif
}

void vehicle_check_wrw2(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if(g_CheckItem.City == TIANJIN)
    {/*天津的2张环保单放在同一个接口中判定*/
        return;
    }
    if (!(g_CheckItem.picture.WeiQiJianYan2.CheJiaHao
          || g_CheckItem.picture.WeiQiJianYan2.ChePai
          || g_CheckItem.picture.WeiQiJianYan2.JieLun
          || g_CheckItem.picture.WeiQiJianYan2.QianMing
          || g_CheckItem.picture.WeiQiJianYan2.YinZhang
          || g_CheckItem.picture.WeiQiJianYan2.YinZhang_MA)) {
        DATA_PRINT(LEVEL_INFO, "wqjy has been skipped. \n");
        return;
    }
    std::string CheJiaHao = g_CheckItem.picture.WeiQiJianYan2.CheJiaHao ? pvehicle_inf->m_clsbdh : "";
    std::string ChePai = g_CheckItem.picture.WeiQiJianYan2.ChePai ? pvehicle_inf->m_hphm : "";
    //std::string shijian1 = g_CheckItem.picture.WeiQiJianYan2.JianCeShiJian ? pvehicle_inf->dz_wqjcrq : "";
    std::string shijian1 = g_CheckItem.picture.WeiQiJianYan2.JianCeShiJian ? pvehicle_inf->dz_wqjcrq : "";
    std::string fadongjixinghao = g_CheckItem.picture.WeiQiJianYan2.FaDongJiBianHao ? pvehicle_inf->m_fdjxh : "";
    std::string jssj = "";
    std::string RiQi = result.formatingDate(shijian1);
    vector<std::string> ShiJian;
    std::string time = result.formatingTime(shijian1);
    ShiJian.push_back(time);

    DATA_PRINT(LEVEL_INFO, "dz_wqjcrq = %s.%s \n",RiQi.c_str(),time.c_str());
    if( g_CheckItem.picture.WeiQiJianYan2.YouXiaoQi)
    {
        std::time_t t = std::time(NULL);
        std::tm *st = std::localtime(&t);
        char tmpArray[128] = { 0 };
        sprintf(tmpArray, "%d%02d%02d", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);
        jssj = tmpArray;
    }
    Huanbaodan_ImgOutMsg out_msg;
    cv::Mat m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    cv::Mat m2;
    pvehicle_inf->timeRecord.startTime();
    alg->huanbaodan_api_process(m1, m2, ChePai, CheJiaHao, RiQi, ShiJian, jssj, fadongjixinghao, pvehicle_inf->m_clxh, out_msg);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.wqjy = pvehicle_inf->timeRecord.getTime();

    result.WuRanWu2 = out_msg;

    Huanbaodan_ImgOutMsg hbddata = out_msg; //9.4
}

void vehicle_check_wrw_tianjin(vehicle_inf *pvehicle_inf, int index1, int index2, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!(g_CheckItem.picture.WeiQiJianYan.CheJiaHao
          || g_CheckItem.picture.WeiQiJianYan.ChePai
          || g_CheckItem.picture.WeiQiJianYan.JieLun
          || g_CheckItem.picture.WeiQiJianYan.QianMing
          || g_CheckItem.picture.WeiQiJianYan.YinZhang
          || g_CheckItem.picture.WeiQiJianYan.YinZhang_MA
          || g_CheckItem.picture.WeiQiJianYan2.CheJiaHao
          || g_CheckItem.picture.WeiQiJianYan2.ChePai
          || g_CheckItem.picture.WeiQiJianYan2.JieLun
          || g_CheckItem.picture.WeiQiJianYan2.QianMing
          || g_CheckItem.picture.WeiQiJianYan2.YinZhang
          || g_CheckItem.picture.WeiQiJianYan2.YinZhang_MA)) {
        DATA_PRINT(LEVEL_INFO, "wqjy has been skipped. \n");
        return;
    }
    std::string CheJiaHao = g_CheckItem.picture.WeiQiJianYan.CheJiaHao ? pvehicle_inf->m_clsbdh : "";
    std::string ChePai = g_CheckItem.picture.WeiQiJianYan.ChePai ? pvehicle_inf->m_hphm : "";
    //std::string shijian1 = g_CheckItem.picture.WeiQiJianYan2.JianCeShiJian ? pvehicle_inf->dz_wqjcrq : "";
    std::string shijian1 = g_CheckItem.picture.WeiQiJianYan.JianCeShiJian ? pvehicle_inf->dz_wqjcrq : "";
    std::string fadongjixinghao = g_CheckItem.picture.WeiQiJianYan.FaDongJiBianHao ? pvehicle_inf->m_fdjxh : "";
    std::string jssj = "";
    std::string RiQi = result.formatingDate(shijian1);
    vector<std::string> ShiJian;
    std::string time = result.formatingTime(shijian1);
    ShiJian.push_back(time);

    DATA_PRINT(LEVEL_INFO, "dz_wqjcrq = %s.%s \n",RiQi.c_str(),time.c_str());
    if( g_CheckItem.picture.WeiQiJianYan.YouXiaoQi)
    {
        std::time_t t = std::time(NULL);
        std::tm *st = std::localtime(&t);
        char tmpArray[128] = { 0 };
        sprintf(tmpArray, "%d%02d%02d", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);
        jssj = tmpArray;
    }
    Huanbaodan_ImgOutMsg out_msg;
    cv::Mat m1,m2;
    m1 = cv::imread(pvehicle_inf->m_zplist[index1].local_path);
    if(index2 != -1)
    {
        m2 = cv::imread(pvehicle_inf->m_zplist[index2].local_path);
    }
    pvehicle_inf->timeRecord.startTime();
    alg->huanbaodan_api_process(m1, m2, ChePai, CheJiaHao, RiQi, ShiJian, jssj, fadongjixinghao, pvehicle_inf->m_clxh, out_msg);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.wqjy = pvehicle_inf->timeRecord.getTime();

    result.WuRanWu  = out_msg;
    result.WuRanWu2 = out_msg;

}

void vehicle_check_dggw(vehicle_inf * pvehicle_inf, int zuo, int you, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!(g_CheckItem.picture.ZuoDengGuang.ChePai
          || g_CheckItem.picture.ZuoDengGuang.QianMian
          || g_CheckItem.picture.ZuoDengGuang.YouQianDeng
          || g_CheckItem.picture.ZuoDengGuang.ShuiYinRiQi
          || g_CheckItem.picture.ZuoDengGuang.ZuoQianDeng)) {
        DATA_PRINT(LEVEL_INFO, "dggw(left) has been skipped. \n");
        return;
    }

    if (!(g_CheckItem.picture.YouDengGuang.ChePai
          || g_CheckItem.picture.YouDengGuang.QianMian
          || g_CheckItem.picture.YouDengGuang.YouQianDeng
          || g_CheckItem.picture.YouDengGuang.ShuiYinRiQi
          || g_CheckItem.picture.YouDengGuang.ZuoQianDeng)) {
        DATA_PRINT(LEVEL_INFO, "dggw(right) has been skipped. \n");
        return;
    }

    std::string ChePai = "";
    ChePai = pvehicle_inf->m_hphm;
    std::string ShuiYinRiQi = pvehicle_inf->m_jssj;
    ShuiYinRiQi = result.formatingDate(ShuiYinRiQi);
    cv::Mat m1;
    cv::Mat m2;

    if ((zuo != -1) && (you != -1)) {
        m1 = cv::imread(pvehicle_inf->m_zplist[zuo].local_path);
        m2 = cv::imread(pvehicle_inf->m_zplist[you].local_path);
    } else if (zuo != -1) {
        m1 = m2 = cv::imread(pvehicle_inf->m_zplist[zuo].local_path);
    } else if (you != -1) {
        m1 = m2 = cv::imread(pvehicle_inf->m_zplist[you].local_path);
    }

    /*
    南京方面要求不审核“右灯光”，因此：
    1. 如果没有左灯光照片，则直接跳过，不调用算法
    2. 如果有左灯光照片，则无论是否还有右灯光照片，传入算法的都是两个相同的左灯光照片
    */
    if (g_CheckItem.City == NANJING) {
        if (zuo == -1) {
            return;
        } else {
            m2 = m1;
        }
    }




    if(zuo != -1)
    {
        Light_ImgOutMsg out_msg;
        pvehicle_inf->timeRecord.startTime();
        alg->light_api_process(m1, ChePai, out_msg);
        alg->shuiyin_riqi_api_process(m1, ShuiYinRiQi, result.bZuoDengGuangShuiYinRiQi);
        pvehicle_inf->timeRecord.endTime();
        pvehicle_inf->timeRecord.picture.process.zdg = pvehicle_inf->timeRecord.getTime();
        result.ZuoDengGuangGongWei = out_msg;
    }

    if(you != -1)
    {
        Light_ImgOutMsg out_msg2;
        pvehicle_inf->timeRecord.startTime();
        alg->light_api_process(m2, ChePai, out_msg2);
        alg->shuiyin_riqi_api_process(m2, ShuiYinRiQi, result.bYouDengGuangShuiYinRiQi);
        pvehicle_inf->timeRecord.endTime();
        pvehicle_inf->timeRecord.picture.process.ydg = pvehicle_inf->timeRecord.getTime();
        result.YouDengGuangGongWei = out_msg2;
    }

    //Light_ImgOutMsg dgdata = out_msg; //9.4

#ifdef DEMO_TEST
    {
        demo_data.dggw = true;
        if (zuo != -1)
        {
            string path1 = pvehicle_inf->m_zplist[zuo].demo_local_path;
            path1 += "_dg_1.jpg";

            cv::Mat zdt = dgdata.img1;
            if (zdt.empty())
            {
                zdt = m1.clone();
                cv::imwrite(path1, zdt);
            } else
            {
                cv::imwrite(path1, zdt);
            }
        }
        demo_data.Dengguang_chepai = dgdata.r_chepai_1;
        demo_data.Dengguang_leftRt = dgdata.r_leftRt_1;
        demo_data.Dengguang_rightRt = dgdata.r_rightRt_1;
        if (you != -1)
        {
            string path2 = pvehicle_inf->m_zplist[you].demo_local_path;
            path2 += "_dg_2.jpg";
            cv::Mat zdt2 = dgdata.img2;
            if (zdt2.empty())
            {
                zdt2 = m1.clone();
                cv::imwrite(path2, zdt2);
            } else
            {
                cv::imwrite(path2, zdt2);
            }
        }
        demo_data.Dengguang_chepai_2 = dgdata.r_chepai_1;
        demo_data.Dengguang_leftRt_2 = dgdata.r_leftRt_1;
        demo_data.Dengguang_rightRt_2 = dgdata.r_rightRt_1;

        demo_data.Dengguang_b_light_on = dgdata.b_light_on;
        demo_data.Dengguang_b_chepai = dgdata.b_chepai;

    }
#endif
}

void vehicle_check_zd(vehicle_inf *pvehicle_inf, int YiZhou_Index, int ErZhou_Index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!(g_CheckItem.picture.YiZhouZhiDong.ChePai
          || g_CheckItem.picture.YiZhouZhiDong.QianLun
          || g_CheckItem.picture.YiZhouZhiDong.ShuiYinRiQi)) {
        DATA_PRINT(LEVEL_INFO, "yzzd(0322) has been skipped. \n");
        return;
    }

    if (!(g_CheckItem.picture.ErZhouZhiDong.ChePai
          || g_CheckItem.picture.ErZhouZhiDong.HouLun
          || g_CheckItem.picture.ErZhouZhiDong.ShuiYinRiQi)) {
        DATA_PRINT(LEVEL_INFO, "ezzd(0348) has been skipped. \n");
        return;
    }

    //上海只有一轴制动照片, 平板制动也只有一轴照片
  //  if ((ErZhou_Index==-1) && (g_CheckItem.City!=SHANGHAI)) {	/* 制动目前（09-05）算法必须要两张照片  */
    //    return;
    //}

    /* 由于一轴二轴制动使用同一个API，所以读取配置时，只读取一轴或二轴都可以*/
    std::string ChePai = pvehicle_inf->m_hphm;
    std::string ShuiYinRiQi = pvehicle_inf->m_jssj;
    ShuiYinRiQi = result.formatingDate(ShuiYinRiQi);
    Zhidong_ImgOutMsg zhidong_out_msg1;
    Zhidong_ImgOutMsg zhidong_out_msg2;
    Light_ImgOutMsg   light_out_msg1;
    Light_ImgOutMsg   light_out_msg2;
    cv::Mat m1 = cv::imread(pvehicle_inf->m_zplist[YiZhou_Index].local_path);
    cv::Mat m2;
    if((g_CheckItem.City!=SHANGHAI)&&(ErZhou_Index!=-1)) {
        m2 = cv::imread(pvehicle_inf->m_zplist[ErZhou_Index].local_path);
    }
    else if( (g_CheckItem.City != SHANGHAI) && (ErZhou_Index == -1))
    {
        m2 = cv::imread(pvehicle_inf->m_zplist[YiZhou_Index].local_path);
    }


    std::string jyjg = pvehicle_inf->m_jyjgbh;
    std::string alg_version;
    //bool zhuche=true;
    int CarKind = 1;
    if(pvehicle_inf->m_cllx.substr(0, 2) == "K3" || pvehicle_inf->m_cllx.substr(0, 2) == "K4")
    {
        CarKind = 1;
    }
    else if(pvehicle_inf->m_cllx.substr(0, 1) == "M")
    {
        CarKind = 3;
    }
    else
    {
        CarKind = 2;
    }
    // 算法检测一二轴制动信息（其他城市)
    int flg = 1;
    alg->algorithm_version(alg_version);
    if (g_CheckItem.City!=SHANGHAI) {
        if(YiZhou_Index != -1)
        {
            pvehicle_inf->timeRecord.startTime();
            alg->zhidong_api_process(m1, ChePai, flg, 1, CarKind, zhidong_out_msg1);
            alg->shuiyin_riqi_api_process(m1, ShuiYinRiQi, result.bYiZhouShuiYinRiQi);
            pvehicle_inf->timeRecord.endTime();
            pvehicle_inf->timeRecord.picture.process.yzzd = pvehicle_inf->timeRecord.getTime();
        }
        if(ErZhou_Index != -1)
        {
            pvehicle_inf->timeRecord.startTime();
            alg->zhidong_api_process(m2, ChePai, flg, 2, CarKind, zhidong_out_msg2);
            alg->shuiyin_riqi_api_process(m2, ShuiYinRiQi, result.bErZhouShuiYinRiQi);
            pvehicle_inf->timeRecord.endTime();
            pvehicle_inf->timeRecord.picture.process.ezzd = pvehicle_inf->timeRecord.getTime();
        }

    } else { // 算法一二轴判定，上海只有一轴照片
        if(YiZhou_Index != -1)
        {
            pvehicle_inf->timeRecord.startTime();
            alg->zhidong_api_process(m1, ChePai, flg, 1, CarKind, zhidong_out_msg1);
            alg->shuiyin_riqi_api_process(m1, ShuiYinRiQi, result.bYiZhouShuiYinRiQi);
            pvehicle_inf->timeRecord.endTime();
            pvehicle_inf->timeRecord.picture.process.yzzd = pvehicle_inf->timeRecord.getTime();
        }
    }


    // 算法检测一二轴制动工位刹车灯信息(南京）
    if (g_CheckItem.City == NANJING || g_CheckItem.City == JIUJIANG || g_CheckItem.City == TAIYUAN) {
        if(YiZhou_Index != -1)
        {
            alg->light_api_process(m1 , ChePai, light_out_msg1);
            result.Light_YiZhouZhiDongGongWei = light_out_msg1;
        }
        if(ErZhou_Index != -1)
        {
            alg->light_api_process(m2, ChePai, light_out_msg2);
            result.Light_ErZhouZhiDongGongWei = light_out_msg2;
        }
    }

    result.YiZhouZhiDongGongWei = zhidong_out_msg1;
    result.ErZhouZhiDongGongWei = zhidong_out_msg2;

   // Zhidong_ImgOutMsg zddata = zhidong_out_msg;
#ifdef DEMO_TEST
    {
        demo_data.zd = true;
        string path1 = pvehicle_inf->m_zplist[YiZhou_Index].demo_local_path;
        path1 += "_zd_1.jpg";

        cv::Mat zdi = zddata.img1;
        if (zdi.empty())
        {
            zdi = m1.clone();
            cv::imwrite(path1, zdi);
        } else
        {
            cv::imwrite(path1, zdi);
        } //原图1
        demo_data.Zhidong_chepai = zddata.r_chepai_1;

        string path2 = pvehicle_inf->m_zplist[ErZhou_Index].demo_local_path;
        path2 += "_zd_2.jpg";
        cv::Mat zdii = zddata.img2;
        if (zdii.empty())
        {
            zdii = m2.clone();
            cv::imwrite(path2, zdii);
        } else
        {
            cv::imwrite(path2, zdii);
        } //原图2
        demo_data.Zhidong_chepai = zddata.r_chepai_1;
        demo_data.Zhidong_chepai_2 = zddata.r_chepai_2;
        demo_data.Zhidong_b_zhidong = zddata.b_zhidong;
        demo_data.Zhidong_b_chepai = zddata.b_chepai;

    }
#endif
}

void vehicle_check_DiPanDongTai(vehicle_inf *pvehicle_inf, int KaiShi, int JieShu, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!(g_CheckItem.picture.DiPanDongTaiKaiShi.ChePai
          || g_CheckItem.picture.DiPanDongTaiKaiShi.ChePaiQueDing
          || g_CheckItem.picture.DiPanDongTaiKaiShi.ShuiYinRiQi
          || g_CheckItem.picture.DiPanDongTaiKaiShi.YiDong)) {
        DATA_PRINT(LEVEL_INFO, "dpdtks(0344) has been skipped. \n");
        return;
    }

    if (!(g_CheckItem.picture.DiPanDongTaiJieShu.ChePai
          || g_CheckItem.picture.DiPanDongTaiJieShu.ShuiYinRiQi
          || g_CheckItem.picture.DiPanDongTaiJieShu.YiDong)) {
        DATA_PRINT(LEVEL_INFO, "dpdtjs(0342) has been skipped. \n");
        return;
    }

    if (JieShu == -1) {
        return;	/*底盘动态检测逻辑要求必须两张照片*/
    }

    std::string ChePai = pvehicle_inf->m_hphm;
    std::string ShuiYinRiQi = pvehicle_inf->m_jssj;
    ShuiYinRiQi = result.formatingDate(ShuiYinRiQi);
    Dipandongtai_ImgOutMsg out_msg;
    cv::Mat m1 = cv::imread(pvehicle_inf->m_zplist[KaiShi].local_path);
    cv::Mat m2 = cv::imread(pvehicle_inf->m_zplist[JieShu].local_path);

    pvehicle_inf->timeRecord.startTime();
    alg->dipandongtai_api_process(m1, m2, ChePai, out_msg);
    alg->shuiyin_riqi_api_process(m1, ShuiYinRiQi, result.bDiPanDongTaiKsShuiYinRiQi);
    alg->shuiyin_riqi_api_process(m2, ShuiYinRiQi, result.bDiPanDongTaiJsShuiYinRiQi);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.dpdtks = pvehicle_inf->timeRecord.getTime();

    result.DiPanDongTai = out_msg;

    Dipandongtai_ImgOutMsg dpdtdata = out_msg; //9.4
#ifdef DEMO_TEST
    {
        demo_data.dpdt = true;
        string path1 = pvehicle_inf->m_zplist[KaiShi].demo_local_path;
        path1 += "_dpdt_1.jpg";
        cv::Mat dpdtm1 = dpdtdata.m1;
        if (dpdtm1.empty())
        {
            dpdtm1 = m1.clone();
            cv::imwrite(path1, dpdtm1);
        } else
        {
            cv::imwrite(path1, dpdtm1);
        } //Ô­ÍŒ1
        demo_data.Dipandongtai_chepai_1 = dpdtdata.r_chepai_1;

        string path2 = pvehicle_inf->m_zplist[JieShu].demo_local_path;
        path2 += "_dpdt_2.jpg";
        cv::Mat dpdtm2 = dpdtdata.m2;
        if (dpdtm2.empty())
        {
            dpdtm2 = m2.clone();
            cv::imwrite(path2, dpdtm2);
        } else
        {
            cv::imwrite(path2, dpdtm2);
        }
        demo_data.Dipandongtai_chepai_2 = dpdtdata.r_chepai_2;

        demo_data.Dipandongtai_b_move = dpdtdata.b_move;
        demo_data.Dipandongtai_b_chepai =dpdtdata.b_chepai1||dpdtdata.b_chepai2;

        //demo_data.Dipandongtai_date_stamp = dpdtdata.date_stamp;
    }
#endif
}

void vehicle_check_DiPan(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!(g_CheckItem.picture.DiPanBuJian.ChePai
          || g_CheckItem.picture.DiPanBuJian.GongWei
          || g_CheckItem.picture.DiPanBuJian.Ren
          || g_CheckItem.picture.DiPanBuJian.ShuiYinRiQi)) {
        DATA_PRINT(LEVEL_INFO, "dpbj(0323) has been skipped. \n");
        return;
    }

    std::string ChePai = g_CheckItem.picture.DiPanBuJian.ChePai ? pvehicle_inf->m_hphm : "";
    std::string ShuiYinRiQi = g_CheckItem.picture.DiPanBuJian.ShuiYinRiQi ? pvehicle_inf->m_jssj : "";
    ShuiYinRiQi = result.formatingDate(ShuiYinRiQi);
    Dipan_ImgOutMsg out_msg;
    cv::Mat m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path);

    pvehicle_inf->timeRecord.startTime();
    alg->dipan_api_process(m1, ChePai, out_msg);
    alg->shuiyin_riqi_api_process(m1, ShuiYinRiQi, result.bDiPanShuiYinRiQi);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.dpjy = pvehicle_inf->timeRecord.getTime();

    result.DiPan = out_msg;

    Dipan_ImgOutMsg dpdata = out_msg; //9.4

#ifdef DEMO_TEST
    {
        demo_data.dp = true;
        string path1 = pvehicle_inf->m_zplist[index].demo_local_path;
        path1 += "_dp_1.jpg";
        cv::Mat dpm = dpdata.m;
        if (dpm.empty())
        {
            dpm = m1.clone();
            cv::imwrite(path1, dpm);
        } else
        {
            cv::imwrite(path1, dpm);
        } //原图1
        demo_data.Dipan_chepai = dpdata.r_chepai;

        demo_data.Dipan_b_dipan = dpdata.b_dipan;
        demo_data.Dipan_b_chepai = dpdata.b_chepai;
        //demo_data.Dipan_date_stamp = dpdata.date_stamp;

    }
#endif
}

void vehicle_check_ZhuCheZhiDong(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!g_CheckItem.picture.ZhuCheZhiDong.ChePai) {
        DATA_PRINT(LEVEL_INFO, "zczd(0351) has been skipped. \n");
        return;
    }

    std::string ChePai = pvehicle_inf->m_hphm;
    std::string jyjg= pvehicle_inf->m_jyjgbh;
    std::string ShuiYinRiQi= pvehicle_inf->m_jssj;
    ShuiYinRiQi = result.formatingDate(ShuiYinRiQi);
    int CarKind = 1;
    if(pvehicle_inf->m_cllx.substr(0, 2) == "K3" || pvehicle_inf->m_cllx.substr(0, 2) == "K4")
    {
        CarKind = 1;
    }
    else if(pvehicle_inf->m_cllx.substr(0, 1) == "M")
    {
        CarKind = 3;
    }
    else
    {
        CarKind = 2;
    }
    Zhidong_ImgOutMsg out_msg;
    Light_ImgOutMsg   light_out_msg;
    std::string alg_version;
    cv::Mat m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path);
  //  cv::Mat m2 = m1;
    int flg = 2;
    pvehicle_inf->timeRecord.startTime();
    alg->zhidong_api_process(m1, ChePai, flg, 2, CarKind, out_msg);
    alg->shuiyin_riqi_api_process(m1, ShuiYinRiQi, result.bZhuCheZhiDongShuiYinRiQi);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.zczd = pvehicle_inf->timeRecord.getTime();
    // 算法检测驻车制动工位刹车灯信息(南京）
    if ((g_CheckItem.City==NANJING) || (g_CheckItem.City==XIAN) || (g_CheckItem.City == FUZHOU2) || (g_CheckItem.City == TAIYUAN) ||(g_CheckItem.City == QingDao)) {
        pvehicle_inf->timeRecord.startTime();
        alg->light_api_process(m1, ChePai, light_out_msg);
        alg->algorithm_version(alg_version);
        pvehicle_inf->timeRecord.endTime();
     //   pvehicle_inf->timeRecord.picture.process.yzzd = pvehicle_inf->timeRecord.getTime();
        result.Light_ZhuCheZhiDong = light_out_msg;
    }

    result.ZhuCheZhiDong = out_msg;
}

void vehicle_check_PoDaoZhiDong(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    std::string ChePai = pvehicle_inf->m_hphm;
    std::string jyjg= pvehicle_inf->m_jyjgbh;
    std::string ShuiYinRiQi= pvehicle_inf->m_jssj;
    ShuiYinRiQi = result.formatingDate(ShuiYinRiQi);
    Dipan_ImgOutMsg out_msg;
    cv::Mat m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    cv::Mat m2 = m1;
//    bool zhuche =false;
//    int CarKind = 1;
//    if(pvehicle_inf->m_cllx.substr(0, 2) == "K3" || pvehicle_inf->m_cllx.substr(0, 2) == "K4")
//    {
//        CarKind = 1;
//    }
//    else if(pvehicle_inf->m_cllx.substr(0, 1) == "M")
//    {
//        CarKind = 2;
//    }
//    else
//    {
//        CarKind = 3;
//    }
    pvehicle_inf->timeRecord.startTime();
   // alg->zhidong_api_process(m1, m2, ChePai, zhuche, CarKind, ShuiYinRiQi, out_msg);
    alg->dipan_api_process(m1, ChePai, out_msg);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.zczd = pvehicle_inf->timeRecord.getTime();

    result.PoDaoZhiDong = out_msg;
}

void vehicle_check_GaoZhiShu(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    Gaozhishu_ImgOutMsg out_msg;
    cv::Mat m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    alg->gaozhishu_api_process(m1, out_msg);
    result.GaoZhiShu = out_msg;
}

void vehicle_check_RongQueShouLi(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    Rongqueshouli_ImgOutMsg out_msg;
    cv::Mat m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    alg->rongqueshouli_api_process(m1, out_msg);
    result.RongQueShouLi = out_msg;
}

void vehicle_check_MieHuoQi(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!(g_CheckItem.picture.MieHuoQi.MieHuoQi
          || g_CheckItem.picture.MieHuoQi.YaLiBiao)) {
        DATA_PRINT(LEVEL_INFO, "mhq(0116) has been skipped. \n");
        return;
    }

    Miehuoqi_ImgOutMsg out_msg;
    cv::Mat m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    pvehicle_inf->timeRecord.startTime();
    alg->miehuoqi_api_process(m1, out_msg);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.mhq = pvehicle_inf->timeRecord.getTime();

    result.MieHuoQi = out_msg;
}

void vehicle_check_YingJiChui(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!g_CheckItem.picture.YingJiChui.YingJiChui) {
        DATA_PRINT(LEVEL_INFO, "yjc(0117) has been skipped. \n");
        return;
    }

    Yingjichui_ImgOutMsg out_msg;
    cv::Mat m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    pvehicle_inf->timeRecord.startTime();
    alg->yingjichui_api_process(m1, out_msg);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.yjc = pvehicle_inf->timeRecord.getTime();

    result.YingJiChui = out_msg;
}

void vehicle_check_JiLuYi(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!(g_CheckItem.picture.JiLuYi.JiLuYi
          || g_CheckItem.picture.JiLuYi.PingMu
          || g_CheckItem.picture.JiLuYi.RenZheng)) {
        DATA_PRINT(LEVEL_INFO, "jly(0118) has been skipped. \n");
        return;
    }

    Xingchejiluyi_ImgOutMsg out_msg;
    cv::Mat m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    pvehicle_inf->timeRecord.startTime();
    alg->xingchejiluyi_api_process(m1, out_msg);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.jly = pvehicle_inf->timeRecord.getTime();

    result.JiLuYi = out_msg;
}

void vehicle_check_zql(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!g_CheckItem.picture.ZuoQianLun.LunTai) {
        DATA_PRINT(LEVEL_INFO, "zql(0136) has been skipped. \n");
        return;
    }

    Luntaiguige_ImgOutMsg out_msg;
    cv::Mat m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    pvehicle_inf->timeRecord.startTime();
    string ltgg_buf = formatFileNameLunTai(pvehicle_inf->m_ltgg);
    alg->luntaiguige_api_process(m1, ltgg_buf, out_msg);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.zql = pvehicle_inf->timeRecord.getTime();

    result.ZuoQianLun = out_msg;
}


void vehicle_check_hdzk(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    //张家界0167核定载客总质量
    if(g_CheckItem.City!=ZHANGJIAJIE)
    {
        if (pvehicle_inf->m_cllx.find("K39") == std::string::npos) {
            DATA_PRINT(LEVEL_INFO, "hdzk(0135) has been skipped. \n");
            return;
        }

        if (!g_CheckItem.picture.HeDingZaiKe.HeDingZaiKe) {
            DATA_PRINT(LEVEL_INFO, "hdzk(0135) has been skipped. \n");
            return;
        }
    }
    std::string ZaiKeShu = pvehicle_inf->m_hdzk;
    std::string ZongZhiLiang = pvehicle_inf->m_zzl;
    std::string LanBanGaoDu = pvehicle_inf->m_hxnbgd;
    Chemenpentu_ImgOutMsg out_msg;
    cv::Mat m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    pvehicle_inf->timeRecord.startTime();
    alg->chemenpentu_api_process(m1, ZongZhiLiang, LanBanGaoDu,ZaiKeShu, atoi(g_CheckItem.City.c_str()), out_msg);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.hdzk = pvehicle_inf->timeRecord.getTime();

    result.HeDingZaiKe = out_msg;
}

void vehicle_check_yql(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!g_CheckItem.picture.YouQianLun.LunTai) {
        DATA_PRINT(LEVEL_INFO, "yql(0154) has been skipped. \n");
        return;
    }

    Luntaiguige_ImgOutMsg out_msg;
    cv::Mat m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    pvehicle_inf->timeRecord.startTime();
    alg->luntaiguige_api_process(m1,pvehicle_inf->m_ltgg, out_msg);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.yql = pvehicle_inf->timeRecord.getTime();

    result.YouQianLun = out_msg;
}

void vehicle_check_ltgg(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    (void)pvehicle_inf;(void)index;(void)alg;(void)result;
}

void vehicle_check_dchw(vehicle_inf *pvehicle_inf, UINT u_zuo, UINT u_you, LargeVehicleApi *alg, ResultCollection &result, std::string where)
{
    Luntaihuawen_ImgOutMsg out_msg;
    cv::Mat m1 = cv::imread(pvehicle_inf->m_zplist[u_zuo].local_path);
    cv::Mat m2 = cv::imread(pvehicle_inf->m_zplist[u_you].local_path);
    std::string str_chepai = pvehicle_inf->m_hphm;
    pvehicle_inf->timeRecord.startTime();
    alg->luntaihuawen_api_process(m1, m2, str_chepai, out_msg);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.dchw = pvehicle_inf->timeRecord.getTime();

    if( (where.compare("04")==0) || (where.compare("05")==0) || (where.compare("4")==0) || (where.compare("5")==0) ) {
        result.DaCheYiLun = out_msg;
    } else if( (where.compare("06")==0) || (where.compare("07")==0) || (where.compare("6")==0) || (where.compare("7")==0) ) {
        result.DaCheErLun = out_msg;
    } else if( (where.compare("08")==0) || (where.compare("09")==0) || (where.compare("8")==0) || (where.compare("9")==0) ) {
        result.DaCheSanLun = out_msg;
    }
}

void vehicle_check_sfz(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!g_CheckItem.picture.ShenFenZheng.ShenFenZheng) {
        DATA_PRINT(LEVEL_INFO, "sfz(0215) has been skipped. \n");
        return;
    }
    std::string XingMing;
    Shenfenzheng_ImgOutMsg out_msg;
    cv::Mat m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    pvehicle_inf->timeRecord.startTime();
    alg->shenfenzheng_api_process(m1,out_msg,XingMing);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.sfz = pvehicle_inf->timeRecord.getTime();
    result.ShenFenZheng = out_msg;
}

void vehicle_check_sfz_back(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!(g_CheckItem.picture.ShenFenZhengBeiMian.ShenFenZheng
          || g_CheckItem.picture.ShenFenZhengBeiMian.YouXiaoQi)) {
        DATA_PRINT(LEVEL_INFO, "sfz_back has been skipped. \n");
        return;
    }
    std::string XingMing;
    Shenfenzheng_ImgOutMsg out_msg;
    cv::Mat m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    pvehicle_inf->timeRecord.startTime();
    alg->shenfenzheng_api_process(m1,out_msg,XingMing);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.sfzbk = pvehicle_inf->timeRecord.getTime();

    result.ShenFenZhengBeiMian = out_msg;
}

void vehicle_check_jcqxbg(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!(g_CheckItem.picture.JianCeQuXianBaoGao.YinZhang
          || g_CheckItem.picture.JianCeQuXianBaoGao.ChePai
          || g_CheckItem.picture.JianCeQuXianBaoGao.QuXianBaoGao))
    {
        DATA_PRINT(LEVEL_INFO, "jcqxbg(0213) has been skipped. \n");
        return;
    }
    std::string ChePai = g_CheckItem.picture.JianCeQuXianBaoGao.ChePai ? pvehicle_inf->m_hphm : "";

    Quxianbaogao_ImgOutMsg out_msg;
    cv::Mat m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    pvehicle_inf->timeRecord.startTime();
    alg->quxianbaogao_api_process(m1, ChePai, out_msg);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.jcqxbg = pvehicle_inf->timeRecord.getTime();

    result.QuXianBaoGao = out_msg;
}

void vehicle_check_CheXiang(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!(g_CheckItem.picture.CheXiang.FengDing
          || g_CheckItem.picture.CheXiang.GaiZhuang
          || g_CheckItem.picture.CheXiang.ZuoWei
          || g_CheckItem.picture.CheXiang.CheLiangLeiXing
          || g_CheckItem.picture.CheXiang.JiaoDu)) {
        DATA_PRINT(LEVEL_INFO, "cx(0115) has been skipped. \n");
        return;
    }
    std::string CheLiangLeiXing = g_CheckItem.picture.CheXiang.CheLiangLeiXing ? pvehicle_inf->m_cllx : "";
    cv::Mat m = cv::imread(pvehicle_inf->m_zplist[index].local_path);

    if (pvehicle_inf->m_cllx.substr(0, 1) == "H") {           /* 货车 */
        Huochexiang_ImgOutMsg out;
        alg->huochexiang_api_process(m, CheLiangLeiXing, out);
        result.HuoCheXiang = out;
    } else if (pvehicle_inf->m_cllx.substr(0, 1) == "K") {    /* 客车 */
        if (pvehicle_inf->m_hdzk == "无数据") {
            result.hdzk = false;
            return;
        }

        int hdzk;

        try {
            hdzk = baseTool::str2Int(pvehicle_inf->m_hdzk);
        } catch (const std::exception &e) {
            DATA_PRINT(LEVEL_ERROR, "Exception! std::stoi() \n");
            DATA_PRINT(LEVEL_ERROR, "Exception cause: %s \n", e.what());
            DATA_PRINT(LEVEL_ERROR, "hazk:%s \n", pvehicle_inf->m_hdzk.c_str());
            result.hdzk = false;
            return;
        }

        Kechexiang_ImgOutMsg out;
        pvehicle_inf->timeRecord.startTime();
        alg->kechexiang_api_process(m, hdzk, out);
        pvehicle_inf->timeRecord.endTime();
        pvehicle_inf->timeRecord.picture.process.chexiang = pvehicle_inf->timeRecord.getTime();
        result.KeCheXiang = out;
        result.hdzk = true;
    }
}

void vehicle_check_HouPaiCheXiang(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!g_CheckItem.picture.HouPaiCheXiang.AnQuanDai) {
        DATA_PRINT(LEVEL_INFO, "cx(0166) has been skipped. \n");
        return;
    }
    std::string m_hdzk = pvehicle_inf->m_hdzk;
    int hdzk = baseTool::str2Int(m_hdzk);
    cv::Mat m = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    Kechexiang_ImgOutMsg out;
    pvehicle_inf->timeRecord.startTime();
    alg->kechexiang_api_process(m, hdzk, out);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.chexiang = pvehicle_inf->timeRecord.getTime();
    result.HouPaiCheXiang = out;
}

void vehicle_check_HouPaiCheXiang2(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!g_CheckItem.picture.HouPaiCheXiang2.AnQuanDai) {
        DATA_PRINT(LEVEL_INFO, "cx(0164) has been skipped. \n");
        return;
    }
    std::string m_hdzk = pvehicle_inf->m_hdzk;
    int hdzk = baseTool::str2Int(m_hdzk);
    cv::Mat m = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    Kechexiang_ImgOutMsg out;
    pvehicle_inf->timeRecord.startTime();
    alg->kechexiang_api_process(m, hdzk, out);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.chexiang = pvehicle_inf->timeRecord.getTime();
    result.HouPaiCheXiang2 = out;
}

void vehicle_check_cjh_ug(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!g_CheckItem.picture.CheJiaHaoUG.CheJiaHao) {
        DATA_PRINT(LEVEL_INFO, "cjhug(0120) has been skipped. \n");
        return;
    }
    std::string CheJiaHao = g_CheckItem.picture.CheJiaHaoUG.CheJiaHao ? pvehicle_inf->m_clsbdh : "";
    cv::Mat m = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    Chejiahao_underglass_OutMsg out;
    pvehicle_inf->timeRecord.startTime();
    alg->chejiahao_underglass_api_process(m, CheJiaHao, out);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.cjh_ug = pvehicle_inf->timeRecord.getTime();
    result.CheJiaHaoUG = out;
}

void vehicle_check_clmp(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!g_CheckItem.picture.CheLiangMingPai.CheJiaHao
            || g_CheckItem.picture.CheLiangMingPai.FaDongJiHao
            || g_CheckItem.picture.CheLiangMingPai.FaDongJiPaiLiang
            || g_CheckItem.picture.CheLiangMingPai.ZhiZaoNianYue) {
        DATA_PRINT(LEVEL_INFO, "clmp() has been skipped. \n");
        return;
    }
    Mingpai_Input input_msg;
    input_msg.ans_chejiahao = g_CheckItem.picture.CheLiangMingPai.CheJiaHao ? pvehicle_inf->m_clsbdh : "";
    input_msg.ans_cheliangpinpai = pvehicle_inf->m_clpp1;
    input_msg.ans_cheliangxinghao = pvehicle_inf->m_clxh;
    input_msg.ans_fadongjixinghao = pvehicle_inf->m_fdjxh;
    input_msg.ans_hedingzaike = pvehicle_inf->m_hdzk;
    input_msg.ans_pailiang = pvehicle_inf->m_pl;
    input_msg.ans_zhizaochangmingcheng = pvehicle_inf->m_zzcmc;
    input_msg.ans_zhizaoguo = pvehicle_inf->m_zzg;
    input_msg.ans_zhizaoriqi = pvehicle_inf->m_zzrq;
    input_msg.ans_zongzhiliang = pvehicle_inf->m_zzl;
    input_msg.img_src = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    Mingpai_OutMsg out;
    pvehicle_inf->timeRecord.startTime();
    DATA_PRINT(LEVEL_INFO, " -sfa\n");
    alg->mingpai_api_process(input_msg, out);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.cjh_ug = pvehicle_inf->timeRecord.getTime();
    result.CheLiangMingPai = out;
}

void vehicle_check_CeHuaGongWei(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!g_CheckItem.picture.CeHuaGongWei.ChePai) {
        DATA_PRINT(LEVEL_INFO, "chgw(0353) has been skipped. \n");
        return;
    }

    std::string ChePai = g_CheckItem.picture.CeHuaGongWei.ChePai ? pvehicle_inf->m_hphm : "";
    cv::Mat m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path);



    Zhidong_ImgOutMsg out;
    std::string ShuiYinRiQi = pvehicle_inf->m_jssj;

   int nflag = 3;
   int CarKind = 1;
   if(pvehicle_inf->m_cllx.substr(0, 2) == "K3" || pvehicle_inf->m_cllx.substr(0, 2) == "K4")
    {
        CarKind = 1;
    }
    else if(pvehicle_inf->m_cllx.substr(0, 1) == "M")
    {
        CarKind = 3;
    }
    else
    {
        CarKind = 2;
    }
    pvehicle_inf->timeRecord.startTime();
    alg->zhidong_api_process(m1, ChePai, nflag, 1, CarKind, out);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.chgw = pvehicle_inf->timeRecord.getTime();
    result.CeHuaGongWei=out;
}

void vehicle_check_WaiKuoQianMian(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!g_CheckItem.picture.WaiKuoQianMian.ChePai) {
        DATA_PRINT(LEVEL_INFO, "wkqm(0301) has been skipped. \n");
        return;
    }

    cv::Mat m1, m2;
    m1 = m2 = cv::imread(pvehicle_inf->m_zplist[index].local_path);

    Huoche_ImgOutMsg out;
    pvehicle_inf->timeRecord.startTime();
    if(g_CheckItem.City==ZHANGJIAJIE)
    {
        alg->huoche_api_process( m1, pvehicle_inf->m_hphm,eBACKFORWARD,out);
    }
    else
    {
        alg->huoche_api_process( m1, pvehicle_inf->m_hphm,eOtherType,out);
    }
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.waikuoqianmian= pvehicle_inf->timeRecord.getTime();
    result.WaiKuoQianMian = out;
}

void vehicle_check_WaiKuoCeMian(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!g_CheckItem.picture.WaiKuoCeMian.ChePai) {
        DATA_PRINT(LEVEL_INFO, "wkcm(0302) has been skipped. \n");
        return;
    }

    cv::Mat m1, m2;
    m1 = m2 = cv::imread(pvehicle_inf->m_zplist[index].local_path);

    Huoche_ImgOutMsg out;
    pvehicle_inf->timeRecord.startTime();
    if(g_CheckItem.City==ZHANGJIAJIE)
    {
        alg->huoche_api_process( m1, pvehicle_inf->m_hphm,eBACKRIGHT,out);
    }
    else
    {
        alg->huoche_api_process( m1, pvehicle_inf->m_hphm,eOtherType,out);
    }
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.waikuocemian = pvehicle_inf->timeRecord.getTime();
    result.WaiKuoCeMian = out;
}

void vehicle_check_wxnb(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!g_CheckItem.picture.WeiXiangNeiBu.GaiZhuang) {
        DATA_PRINT(LEVEL_INFO, "wxnb(0101) has been skipped. \n");
        return;
    }
    std::string ChePai = pvehicle_inf->m_hphm ;
    cv::Mat m1 ;
    m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    Weixianggaizhuang_ImgOutMsg out;
    pvehicle_inf->timeRecord.startTime();
    alg->weixianggaizhuang_api_process(m1, ChePai,out);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.wxnb = pvehicle_inf->timeRecord.getTime();

    result.WeiXiangNeiBu = out;
}

void vehicle_check_fzzd(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!g_CheckItem.picture.FuZhuZhiDong.FuZhuZhiDong) {
        DATA_PRINT(LEVEL_INFO, "fzzd(0130) has been skipped. \n");
        return;
    }

    cv::Mat m1 ;
    m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    FuzhuzhidongSign_ImgOutMsg out;
    pvehicle_inf->timeRecord.startTime();
    alg->fuzhuzhidongsign_api_process(m1, out);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.fzzd = pvehicle_inf->timeRecord.getTime();
    result.FuZhuZhiDong = out;
}

void vehicle_check_xian(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    (void)pvehicle_inf;(void)index;(void)alg;(void)result;
}

// 最后一个参数: true - 前轮照片  false - 后轮照片
void vehicle_check_QianHouLunZhaoPian(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result, bool b_qianlunzhaopian)
{
    if (b_qianlunzhaopian) {
        if (!g_CheckItem.picture.QianLunZhaoPian.b_chepai) {
            DATA_PRINT(LEVEL_INFO, "QianLunZhaoPian has been skipped. \n");
            return;
        }
    } else {
        if (!g_CheckItem.picture.HouLunZhaoPian.b_chepai) {
            DATA_PRINT(LEVEL_INFO, "HouLunZhaoPian has been skipped. \n");
            return;
        }
    }

    cv::Mat m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    Luntaihuawen_ImgOutMsg out_msg;
    std::string str_chepai = pvehicle_inf->m_hphm;
    pvehicle_inf->timeRecord.startTime();
    alg->luntaihuawen_api_process(m1, m1, str_chepai, out_msg);
    pvehicle_inf->timeRecord.endTime();

    if (b_qianlunzhaopian) {
        pvehicle_inf->timeRecord.picture.process.qltzp = pvehicle_inf->timeRecord.getTime();
        result.QianLunTaiZhaoPian = out_msg;
    } else {
        pvehicle_inf->timeRecord.picture.process.hltzp = pvehicle_inf->timeRecord.getTime();
        result.HouLunTaiZhaoPian = out_msg;
    }
}

void vehicle_check_abs(vehicle_inf * pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!g_CheckItem.picture.ABS.ABS) {
        DATA_PRINT(LEVEL_INFO, "abs(0134) has been skipped. \n");
        return;
    }

    cv::Mat m1 ;
    m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    ABSSign_ImgOutMsg  out;
    pvehicle_inf->timeRecord.startTime();
    alg->abssign_api_process(m1, out);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.abs = pvehicle_inf->timeRecord.getTime();
    result.ABS = out;
}

void vehicle_check_glass_transmittance(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    Bolitouguanglv_ImgOutMsg out_msg;
    cv::Mat img = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    std::string chepai_answner = pvehicle_inf->m_hphm;

    pvehicle_inf->timeRecord.startTime();
    alg->bolitouguanglv_api_process(img, chepai_answner, out_msg);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.abs = pvehicle_inf->timeRecord.getTime();
    result.BoLiTouGuangLv = out_msg;
}

void vehicle_check_clcm(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!g_CheckItem.picture.CheLiangCeMian.CheLiangCeMian) {
        DATA_PRINT(LEVEL_INFO, "clcm() has been skipped. \n");
        return;
    }
    std::string ChePai = g_CheckItem.picture.CheLiangCeMian.CheLiangCeMian ? pvehicle_inf->m_hphm : "";
    std::string ShuiYinRiQi = g_CheckItem.picture.CheLiangCeMian.ShuiYinRiQi ? pvehicle_inf->m_jssj : "";
    ShuiYinRiQi = result.formatingDate(ShuiYinRiQi);
    cv::Mat m1 ;
    m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    Cheliang_ImgOutMsg  cmdata;
    vector<cv::Mat> empty;
    pvehicle_inf->timeRecord.startTime();
    alg->cheliang_api_process(m1, m1, empty ,ChePai,pvehicle_inf->m_cllx,pvehicle_inf->m_csys,eOtherType, cmdata);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.clcm = pvehicle_inf->timeRecord.getTime();
    result.CeMian = cmdata;
}

void vehicle_check_clcm2(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!g_CheckItem.picture.CheLiangCeMian.CheLiangCeMian) {
        DATA_PRINT(LEVEL_INFO, "clcm2() has been skipped. \n");
        return;
    }
    if (pvehicle_inf->m_cllx.find("K39") == std::string::npos && pvehicle_inf->m_cllx.find("K31") == std::string::npos) {
        DATA_PRINT(LEVEL_INFO, "clcm has been skipped. \n");
        return;
    }

    std::string ZaiKeShu = pvehicle_inf->m_hdzk;
    std::string ZongZhiLiang = pvehicle_inf->m_zzl;
    std::string LanBanGaoDu = pvehicle_inf->m_hxnbgd;
    Chemenpentu_ImgOutMsg out_msg;
    cv::Mat m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    pvehicle_inf->timeRecord.startTime();
    alg->chemenpentu_api_process(m1, ZongZhiLiang, LanBanGaoDu,ZaiKeShu, atoi(g_CheckItem.City.c_str()), out_msg);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.clcm = pvehicle_inf->timeRecord.getTime();

    result.CheLiangCeMian = out_msg;
}

void vehicle_check_cjhyj(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!g_CheckItem.picture.CheJiaHao.YuanJing) {
        DATA_PRINT(LEVEL_INFO, "cjhyj(0168) has been skipped. \n");
        return;
    }
    std::string CheJiaHao = g_CheckItem.picture.CheJiaHao.YuanJing ? pvehicle_inf->m_clsbdh : "";
    std::string ShuiYinRiQi = g_CheckItem.picture.CheJiaHao.ShuiYinRiQi ? pvehicle_inf->m_jssj : "";
    ShuiYinRiQi = result.formatingDate(ShuiYinRiQi);
    cv::Mat m1 ;
    m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    Chejiahao_ImgOutMsg  out_msg;
    pvehicle_inf->timeRecord.startTime();
    alg->chejiaohao_api_process(m1, m1, CheJiaHao, "", out_msg);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.cjhyj = pvehicle_inf->timeRecord.getTime();
    result.CheJiaHaoYuanJing = out_msg;
}
void vehicle_check_hpls(vehicle_inf *pvehicle_inf,UINT index,LargeVehicleApi *alg,ResultCollection &result,bool IsQianHaoPai)
{
    cv::Mat m1;
    m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    std::string ChePai = g_CheckItem.picture.QianHaoPaiTeXie.chepai ? pvehicle_inf->m_hphm : "";
    Haopai_ImgOutMsg out_msg;
    pvehicle_inf->timeRecord.startTime();
    alg->haopai_api_process(m1, ChePai, out_msg);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.hpls = pvehicle_inf->timeRecord.getTime();
    if(IsQianHaoPai)
    {
        result.QianHaoPaiTeXie = out_msg;
    }
    else
    {
        result.HouHaoPaiTeXie = out_msg;
    }
}
void vehicle_check_qhp(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!g_CheckItem.picture.QianHaoPai.ChePai) {
        DATA_PRINT(LEVEL_INFO, "qhp(0167) has been skipped. \n");
        return;
    }
    std::string ChePai = g_CheckItem.picture.QianHaoPai.ChePai ? pvehicle_inf->m_hphm : "";
    std::string ShuiYinRiQi = g_CheckItem.picture.QianHaoPai.ShuiYinRiQi ? pvehicle_inf->m_jssj : "";
    ShuiYinRiQi = result.formatingDate(ShuiYinRiQi);
    cv::Mat m1 ;
    m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    Cheliang_ImgOutMsg  cmdata;
    vector<cv::Mat> empty;
    pvehicle_inf->timeRecord.startTime();
    alg->cheliang_api_process(m1, m1, empty ,ChePai,pvehicle_inf->m_cllx,pvehicle_inf->m_csys,eOtherType, cmdata);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.qhp = pvehicle_inf->timeRecord.getTime();
    result.QianHaoPai = cmdata;
}
void vehicle_check_hhp(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!g_CheckItem.picture.HouHaoPai.ChePai) {
        DATA_PRINT(LEVEL_INFO, "hhp(0168) has been skipped. \n");
        return;
    }
    std::string ChePai = g_CheckItem.picture.HouHaoPai.ChePai ? pvehicle_inf->m_hphm : "";
    std::string ShuiYinRiQi = g_CheckItem.picture.HouHaoPai.ShuiYinRiQi ? pvehicle_inf->m_jssj : "";
    ShuiYinRiQi = result.formatingDate(ShuiYinRiQi);
    cv::Mat m1 ;
    m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    Cheliang_ImgOutMsg  cmdata;
    vector<cv::Mat> empty;
    pvehicle_inf->timeRecord.startTime();
    alg->cheliang_api_process(m1, m1, empty ,ChePai,pvehicle_inf->m_cllx,pvehicle_inf->m_csys,eOtherType, cmdata);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.hhp = pvehicle_inf->timeRecord.getTime();
    result.HouHaoPai = cmdata;
}


void vehicle_check_clbm(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!g_CheckItem.picture.CheLiangBeiMian.CheLiangBeiMian) {
        DATA_PRINT(LEVEL_INFO, "clbm(0158) has been skipped. \n");
        return;
    }
    std::string ChePai = g_CheckItem.picture.CheLiangBeiMian.ChePai ? pvehicle_inf->m_hphm : "";
    std::string ShuiYinRiQi = g_CheckItem.picture.CheLiangBeiMian.ShuiYinRiQi ? pvehicle_inf->m_jssj : "";
    ShuiYinRiQi = result.formatingDate(ShuiYinRiQi);
    // 区分大小车接口
    if ((pvehicle_inf->m_cllx.substr(0, 2)=="K3") || (pvehicle_inf->m_cllx.substr(0, 2)=="K4")) { // 小车
        cv::Mat m1;
        m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path);
        Cheliang_ImgOutMsg  bmdata;
        vector<cv::Mat> empty;
        pvehicle_inf->timeRecord.startTime();
        alg->cheliang_api_process(m1, m1, empty ,ChePai,pvehicle_inf->m_cllx,pvehicle_inf->m_csys, eBACKFORWARD,bmdata);
        pvehicle_inf->timeRecord.endTime();
        pvehicle_inf->timeRecord.picture.process.clbm = pvehicle_inf->timeRecord.getTime();

        result.BeiMian = bmdata;

        if (g_CheckItem.picture.CheLiangBeiMian.WeiDeng) {  // 添加车辆背面尾灯检测 调用算法灯光API
            Light_ImgOutMsg light_out;
            pvehicle_inf->timeRecord.startTime();
            alg->light_api_process(m1, ChePai, light_out);
            pvehicle_inf->timeRecord.endTime();
            pvehicle_inf->timeRecord.picture.process.zdg = pvehicle_inf->timeRecord.getTime();

            result.LightBeiMian = light_out;
        }
    } else { // 大车
        cv::Mat m1;
        m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path);
        Huoche_ImgOutMsg out;
        pvehicle_inf->timeRecord.startTime();
        alg->huoche_api_process(m1, ChePai, eBACKFORWARD, out);
        pvehicle_inf->timeRecord.endTime();
        pvehicle_inf->timeRecord.picture.process.clbm = pvehicle_inf->timeRecord.getTime();
        result.HuoChe_ZhengHouFang = out;
    }
}
void vehicle_check_dchp(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    if (!g_CheckItem.picture.DaCheHaoPai.ChePai) {
        DATA_PRINT(LEVEL_INFO, "dchp(0170) has been skipped. \n");
        return;
    }
    std::string ChePai = g_CheckItem.picture.DaCheHaoPai.ChePai ? pvehicle_inf->m_hphm : "";
    cv::Mat m1 ;
    m1 = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    Huoche_ImgOutMsg  out_msg;
    pvehicle_inf->timeRecord.startTime();
    alg->huoche_api_process(m1, ChePai, eOtherType, out_msg);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.picture.process.dchp = pvehicle_inf->timeRecord.getTime();

    result.DaCheHaoPai = out_msg;
}

void vehicle_videocheck_zqf(vehicle_inf * pvehicle_inf, int index, LargeVehicleApi *alg, ResultCollection &result)
{
    Cheliang_VideoOutMsg out_msg;
    std::string Path = pvehicle_inf->m_splist[index].local_path;
    std::string ChePai = pvehicle_inf->m_hphm;
    std::string Syxz = pvehicle_inf->m_syxz;
    std::string Cllx = pvehicle_inf->m_cllx;
    pvehicle_inf->timeRecord.startTime();
    alg->cheliang_video_api_process(Path ,ChePai,Cllx,Syxz, out_msg);
    pvehicle_inf->m_b_zqf_checked = true;
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.video.process.zqf = pvehicle_inf->timeRecord.getTime();
    result.V_ZuoQianFang = out_msg;
    auto pos = Path.find_last_of(".");
    string jpg_name;
    if(pos != std::string::npos)
    {
        jpg_name = Path;
        jpg_name.replace(pos,jpg_name.size(),".jpg");
    }
    if(!out_msg.img.empty())
    {
        imwrite(jpg_name,out_msg.img);
    }
}

void vehicle_videocheck_yhf(vehicle_inf * pvehicle_inf, int index, LargeVehicleApi *alg, ResultCollection &result)
{
    Cheliang_VideoOutMsg out_msg;
    std::string Path = pvehicle_inf->m_splist[index].local_path;
    std::string ChePai = pvehicle_inf->m_hphm;
    std::string Syxz = pvehicle_inf->m_syxz;
    std::string Cllx = pvehicle_inf->m_cllx;
    pvehicle_inf->timeRecord.startTime();
    alg->cheliang_video_api_process(Path, ChePai,Cllx,Syxz, out_msg);
    pvehicle_inf->m_b_yhf_checked = true;
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.video.process.yhf = pvehicle_inf->timeRecord.getTime();
    result.V_YouHouFang = out_msg;
    auto pos = Path.find_last_of(".");
    string jpg_name;
    if(pos != std::string::npos)
    {
        jpg_name = Path;
        jpg_name.replace(pos,jpg_name.size(),".jpg");
    }
    if(!out_msg.img.empty())
    {
        imwrite(jpg_name,out_msg.img);
    }
}

void vehicle_videocheck_zd(vehicle_inf *pvehicle_inf, int YiZhou_Index, int ErZhou_Index, int flag, LargeVehicleApi *alg, ResultCollection &result)
{
    (void)flag;
    std::string ChePai = pvehicle_inf->m_hphm;
    std::string Cllx = pvehicle_inf->m_jyjgbh;
    std::string Syxz = pvehicle_inf->m_jyjgbh;
    Zhidong_VideoOutMsg out_msg1;
    Zhidong_VideoOutMsg out_msg2;

    if (YiZhou_Index == -1){
        return;
    }
    else{
        std::string Path1 = pvehicle_inf->m_splist[YiZhou_Index].local_path;
        pvehicle_inf->timeRecord.startTime();
        alg->zhidong_video_api_process(Path1, ChePai, true, true ,Cllx, Syxz, out_msg1);
        pvehicle_inf->m_b_yz_checked = true;
        pvehicle_inf->timeRecord.endTime();
        pvehicle_inf->timeRecord.video.process.yzzd = pvehicle_inf->timeRecord.getTime();
        result.V_YiZhouZhiDong = out_msg1;
        auto pos = Path1.find_last_of(".");
        string jpg_name;
        if(pos != std::string::npos)
        {
            jpg_name = Path1;
            jpg_name.replace(pos,jpg_name.size(),".jpg");
        }
        if(!out_msg1.img_show.empty())
        {
            imwrite(jpg_name,out_msg1.img_show);
        }
    }
    if (ErZhou_Index == -1){
        return;
    }
    else{
        std::string Path2 = pvehicle_inf->m_splist[ErZhou_Index].local_path;
        pvehicle_inf->timeRecord.startTime();
        alg->zhidong_video_api_process(Path2, ChePai, true, true ,Cllx, Syxz, out_msg2);
        pvehicle_inf->m_b_ez_checked = true;
        pvehicle_inf->timeRecord.endTime();
        pvehicle_inf->timeRecord.video.process.yzzd = pvehicle_inf->timeRecord.getTime();
        result.V_ErZhouZhiDong = out_msg2;
        auto pos = Path2.find_last_of(".");
        string jpg_name;
        if(pos != std::string::npos)
        {
            jpg_name = Path2;
            jpg_name.replace(pos,jpg_name.size(),".jpg");
        }
        if(!out_msg2.img_show.empty())
        {
            imwrite(jpg_name,out_msg2.img_show);
        }
    }

}

void vehicle_videocheck_zdggw(vehicle_inf * pvehicle_inf, int index, LargeVehicleApi *alg, ResultCollection &result)
{
    Light_VideoOutMsg out_msg;
    std::string ChePai = pvehicle_inf->m_hphm;
    std::string Syxz = pvehicle_inf->m_syxz;
    std::string Cllx = pvehicle_inf->m_cllx;
    std::string Path = pvehicle_inf->m_splist[index].local_path;
    pvehicle_inf->timeRecord.startTime();
    alg->light_video_api_process(Path, ChePai, Cllx,Syxz, out_msg);
    pvehicle_inf->m_b_zdg_checked = true;
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.video.process.zdg = pvehicle_inf->timeRecord.getTime();
    result.V_ZuoDengGuang = out_msg;
    auto pos = Path.find_last_of(".");
    string jpg_name;
    if(pos != std::string::npos)
    {
        jpg_name = Path;
        jpg_name.replace(pos,jpg_name.size(),".jpg");
    }
    if(!out_msg.img_show.empty())
    {
        imwrite(jpg_name,out_msg.img_show);
    }
}

void vehicle_videocheck_ydggw(vehicle_inf * pvehicle_inf, int index, LargeVehicleApi *alg, ResultCollection &result)
{
    Light_VideoOutMsg out_msg;
    std::string ChePai = pvehicle_inf->m_hphm;
    std::string Syxz = pvehicle_inf->m_syxz;
    std::string Cllx = pvehicle_inf->m_cllx;
    std::string Path = pvehicle_inf->m_splist[index].local_path;
    pvehicle_inf->timeRecord.startTime();
    alg->light_video_api_process(Path, ChePai,Cllx,Syxz, out_msg);
    pvehicle_inf->m_b_ydg_checked = true;
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.video.process.ydg = pvehicle_inf->timeRecord.getTime();
    result.V_YouDengGuang = out_msg;
    auto pos = Path.find_last_of(".");
    string jpg_name;
    if(pos != std::string::npos)
    {
        jpg_name = Path;
        jpg_name.replace(pos,jpg_name.size(),".jpg");
    }
    if(!out_msg.img_show.empty())
    {
        imwrite(jpg_name,out_msg.img_show);
    }
}

void vehicle_videocheck_dp(vehicle_inf *pvehicle_inf, int index, LargeVehicleApi *alg, ResultCollection &result)
{
    Dipan_VideoOutMsg out_msg;
    std::string Path = pvehicle_inf->m_splist[index].local_path;
    std::string Syxz = pvehicle_inf->m_syxz;
    std::string Cllx = pvehicle_inf->m_cllx;
    pvehicle_inf->timeRecord.startTime();
    alg->dipan_video_api_process(Path, Cllx,Syxz, out_msg);
    pvehicle_inf->m_b_dp_checked = true;
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.video.process.dp = pvehicle_inf->timeRecord.getTime();
    result.V_DiPan = out_msg;
    auto pos = Path.find_last_of(".");
    string jpg_name;
    if(pos != std::string::npos)
    {
        jpg_name = Path;
        jpg_name.replace(pos,jpg_name.size(),".jpg");
    }
    if(!out_msg.img.empty())
    {
        imwrite(jpg_name,out_msg.img);
    }
}

void vehicle_videocheck_dpdtks(vehicle_inf *pvehicle_inf, int index, LargeVehicleApi *alg, ResultCollection &result)
{
    Dipandongtai_VideoOutMsg out_msg;
    std::string Path = pvehicle_inf->m_splist[index].local_path;
    std::string ChePai = pvehicle_inf->m_hphm;
    std::string Cllx = pvehicle_inf->m_cllx;
    std::string Syxz = pvehicle_inf->m_syxz;
    pvehicle_inf->timeRecord.startTime();
    alg->dipandongtai_video_api_process(Path, ChePai, Cllx, Syxz, out_msg);
    pvehicle_inf->m_b_dtks_checked = true;
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.video.process.dtks = pvehicle_inf->timeRecord.getTime();
    result.V_DiPanDongTaiKaiShi = out_msg;
    auto pos = Path.find_last_of(".");
    string jpg_name;
    if(pos != std::string::npos)
    {
        jpg_name = Path;
        jpg_name.replace(pos,jpg_name.size(),".jpg");
    }
    if(!out_msg.img.empty())
    {
        imwrite(jpg_name,out_msg.img);
    }
}

void vehicle_videocheck_dpdtjs(vehicle_inf *pvehicle_inf, int index, LargeVehicleApi *alg, ResultCollection &result)
{
    Dipandongtai_VideoOutMsg out_msg;
    std::string Path = pvehicle_inf->m_splist[index].local_path;
    std::string ChePai = pvehicle_inf->m_hphm;
    std::string Cllx = pvehicle_inf->m_cllx;
    std::string Syxz = pvehicle_inf->m_syxz;
    pvehicle_inf->timeRecord.startTime();
    alg->dipandongtai_video_api_process(Path, ChePai, Cllx, Syxz, out_msg);
    pvehicle_inf->m_b_dtjs_checked = true;
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.video.process.dtjs = pvehicle_inf->timeRecord.getTime();
    result.V_DiPanDongTaiJieShu = out_msg;
    auto pos = Path.find_last_of(".");
    string jpg_name;
    if(pos != std::string::npos)
    {
        jpg_name = Path;
        jpg_name.replace(pos,jpg_name.size(),".jpg");
    }
    if(!out_msg.img.empty())
    {
        imwrite(jpg_name,out_msg.img);
    }
}

void vehicle_videocheck_zczd(vehicle_inf *pvehicle_inf, int index, LargeVehicleApi *alg, ResultCollection &result)
{
    Zhidong_VideoOutMsg out_msg;
    std::string ChePai = pvehicle_inf->m_hphm;
    std::string Path = pvehicle_inf->m_splist[index].local_path;
    std::string Syxz = pvehicle_inf->m_syxz;
    std::string Cllx = pvehicle_inf->m_cllx;
    pvehicle_inf->timeRecord.startTime();
    alg->zhidong_video_api_process(Path, ChePai,false,true,Cllx,Syxz, out_msg);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.video.process.pbzc = pvehicle_inf->timeRecord.getTime();
    result.V_ZhuCheZhiDong = out_msg;
    pvehicle_inf->m_b_zczd_checked = true;
    auto pos = Path.find_last_of(".");
    string jpg_name;
    if(pos != std::string::npos)
    {
        jpg_name = Path;
        jpg_name.replace(pos,jpg_name.size(),".jpg");
    }
    if(!out_msg.img_show.empty())
    {
        imwrite(jpg_name,out_msg.img_show);
    }
}

void vehicle_videocheck_dggw(vehicle_inf *pvehicle_inf, int index, LargeVehicleApi *alg, ResultCollection &result)
{
    Light_VideoOutMsg out_msg;
    std::string ChePai = pvehicle_inf->m_hphm;
    std::string Syxz = pvehicle_inf->m_syxz;
    std::string Cllx = pvehicle_inf->m_cllx;
    std::string Path = pvehicle_inf->m_splist[index].local_path;
    pvehicle_inf->timeRecord.startTime();
    alg->light_video_api_process(Path, ChePai,Cllx,Syxz, out_msg);
    pvehicle_inf->timeRecord.endTime();
    pvehicle_inf->timeRecord.video.process.ydg = pvehicle_inf->timeRecord.getTime();
    result.V_DengGuang = out_msg;
    pvehicle_inf->m_b_dggw_checked = true;
    auto pos = Path.find_last_of(".");
    string jpg_name;
    if(pos != std::string::npos)
    {
        jpg_name = Path;
        jpg_name.replace(pos,jpg_name.size(),".jpg");
    }
    if(!out_msg.img_show.empty())
    {
        imwrite(jpg_name,out_msg.img_show);
    }
}

void vehicle_videocheck_dpdt(vehicle_inf *pvehicle_inf, int index, LargeVehicleApi *alg, ResultCollection &result)
{
    Dipandongtai_VideoOutMsg out_msg;
    std::string ChePai = pvehicle_inf->m_hphm;
    std::string Syxz = pvehicle_inf->m_syxz;
    std::string Cllx = pvehicle_inf->m_cllx;
    std::string Path = pvehicle_inf->m_splist[index].local_path;

    alg->dipandongtai_video_api_process(Path, ChePai,Cllx,Syxz, out_msg);

    result.V_DiPanDongTai = out_msg;
    pvehicle_inf->m_b_dpdt_checked = true;
    auto pos = Path.find_last_of(".");
    string jpg_name;
    if(pos != std::string::npos)
    {
        jpg_name = Path;
        jpg_name.replace(pos,jpg_name.size(),".jpg");
    }
    if(!out_msg.img.empty())
    {
        imwrite(jpg_name,out_msg.img);
    }
}
//void vehicle_videocheck_pbzczd(vehicle_inf *pvehicle_inf, int index, LargeVehicleApi *alg, ResultCollection &result)
//{
//    result.Video_Exist[7] = true;//zhuche pingban
//    PlatePark_VideoOutMsg out_msg;
//    out_msg.b_chepai = out_msg.b_human_clear = out_msg.b_light_on = out_msg.b_on_plate = true;
//    std::string ChePai = pvehicle_inf->m_hphm;
//    std::string Path = pvehicle_inf->m_splist[index].local_path;
//    std::string jyjg = pvehicle_inf->m_jyjgbh;
//    EVehInspectStation JiGouBianHao;
//    for (int c = 0; c < JGBH_NUM; c++)
//    {
//        if (jyjgsz[c].jgbh.find(jyjg) != -1)
//        {
//            JiGouBianHao = jyjgsz[c].ejgbh;
//            break;
//        }
//        JiGouBianHao=e3200000011;
//    }
//    pvehicle_inf->timeRecord.startTime();
//    alg->platePark_video_api_process(Path, ChePai, ePLATEPARK, JiGouBianHao, out_msg);
//    pvehicle_inf->timeRecord.endTime();
//    pvehicle_inf->timeRecord.video.process.pbzc = pvehicle_inf->timeRecord.getTime();
//    result.V_PingBanZhuChe = out_msg;
//}

//void vehicle_videocheck_glzczd(vehicle_inf *pvehicle_inf, int index, LargeVehicleApi *alg, ResultCollection &result)
//{
//    result.Video_Exist[8] = true;//zhuche gunlun
//    RollerPark_VideoOutMsg out_msg;
//    out_msg.b_bounce_up = out_msg.b_chepai = out_msg.b_human_clear = out_msg.b_roller_on = true;
//    std::string ChePai = pvehicle_inf->m_hphm;
//    std::string Path = pvehicle_inf->m_splist[index].local_path;
//    std::string jyjg = pvehicle_inf->m_jyjgbh;
//    EVehInspectStation JiGouBianHao;
//    for (int c = 0; c < JGBH_NUM; c++)
//    {
//        if (jyjgsz[c].jgbh.find(jyjg) != -1)
//        {
//            JiGouBianHao = jyjgsz[c].ejgbh;
//            break;
//        }
//        JiGouBianHao=e3200000011;
//    }
//    pvehicle_inf->timeRecord.startTime();
//    alg->rollerPark_video_api_process(Path, ChePai, ePLATEPARK, JiGouBianHao, out_msg);
//    pvehicle_inf->timeRecord.endTime();
//    pvehicle_inf->timeRecord.video.process.pbzc = pvehicle_inf->timeRecord.getTime();
//    result.V_GunLunZhuChe = out_msg;
//}

void processYingYeZhiZhao(vehicle_inf *pvehicle_inf, int index, LargeVehicleApi *alg, ResultCollection &result)
{
    Yingyezhizhao_ImgOutMsg out_msg;
    cv::Mat m = cv::imread(pvehicle_inf->m_zplist[index].local_path);

    alg->yingyezhizhao_api_process(m, out_msg);
    result.YingYeZhiZhao = out_msg;
}

void vehicle_check_QianLunTaiHuaWen(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    Luntaihuawen_ImgOutMsg out_msg;
    cv::Mat m = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    std::string str_chepai = pvehicle_inf->m_hphm;
    alg->luntaihuawen_api_process(m, m, str_chepai, out_msg);
    result.QianLunTaiHuaWen = out_msg;
}

void vehicle_check_HouLunTaiHuaWen(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    Luntaihuawen_ImgOutMsg out_msg;
    cv::Mat m = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    std::string str_chepai = pvehicle_inf->m_hphm;
    alg->luntaihuawen_api_process(m, m, str_chepai, out_msg);
    result.HouLunTaiHuaWen = out_msg;
}


void vehicle_check_WaiKuoChiCunJiLuDan(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
     Waikuochicun_ImgOutMsg out_msg;
     cv::Mat m = cv::imread(pvehicle_inf->m_zplist[index].local_path);
     std::string ChePai = pvehicle_inf->m_hphm;
     std::string CheJiaHao = pvehicle_inf->m_clsbdh;
     alg-> waikuochicun_api_process(m, ChePai, CheJiaHao, out_msg);
     result.WaiKuoChiCunJiLuDan = out_msg;
}

void vehicle_check_FanGuangBiaoShi(vehicle_inf *pvehicle_inf, UINT index, LargeVehicleApi *alg, ResultCollection &result)
{
    Zhaotong_fanguangbiaoshi_ImgOutMsg out_msg;
    cv::Mat m = cv::imread(pvehicle_inf->m_zplist[index].local_path);
    std::string ChePai = pvehicle_inf->m_hphm;
    alg->zhaotong_fanguangbiaoshi_api_process(m, ChePai, out_msg);
    result.FangGuangBiaoShi = out_msg;
}

void vehicle_check_if_ten_year(vehicle_inf *pvehicle_inf, ResultCollection &result)
{
    std::string ChuChangRiQi = pvehicle_inf->m_ccrq;
    if(ChuChangRiQi!=""&&ChuChangRiQi!="无数据")
    {
        ChuChangRiQi = result.formatingDate(ChuChangRiQi);
        ChuChangRiQi=ChuChangRiQi.substr(0,4);
    }
    else
    {
        pvehicle_inf->ten_year= false;
        return;
    }
    int year;
    try {
         year=stoi(ChuChangRiQi);
    } catch (const std::exception &e) {
        DATA_PRINT(LEVEL_ERROR, "Exception! std::stoi() \n");
        DATA_PRINT(LEVEL_ERROR, "Exception cause: %s \n", e.what());
        pvehicle_inf->ten_year= false;
        return ;
    }
    std::time_t t = std::time(NULL);
    std::tm *st = std::localtime(&t);
    int year_now =(st->tm_year+1900);
    if(year_now-year>=10)
        pvehicle_inf->ten_year= true;
    else
        pvehicle_inf->ten_year= false;
}

bool check_licence()
{
    nvmlReturn_t result;//uuid
    unsigned int device_count;
    char *uuidc=(char*)malloc(65);

    // First initialize NVML library
    result = nvmlInit();
    if (NVML_SUCCESS != result)
    {
        printf("Failed to initialize NVML: %s\n", nvmlErrorString(result));

        printf("Press ENTER to continue...\n");
        getchar();
        return false;
    }

    result = nvmlDeviceGetCount(&device_count);
    if (NVML_SUCCESS != result)
    {
        printf("Failed to query device count: %s\n", nvmlErrorString(result));
        return false;
    }
    printf("Found %d device%s\n\n", device_count, device_count != 1 ? "s" : "");

    printf("Listing devices:\n");

    unsigned int lg=64;
    nvmlDevice_t device;
    result = nvmlDeviceGetHandleByIndex(0, &device);
    if(NVML_SUCCESS!=result)
    {
        printf("not find device\n");
        return false;
    }

    result= nvmlDeviceGetUUID (device, uuidc, lg);
    if(NVML_SUCCESS!=result)
    {
        printf("Failed to get uuid \n");
        return false;
    }
    std::string uuid=uuidc;
    free(uuidc);

    std::string conf_name = "lic.lic";
    if(baseTool::fileIsExist("/opt/vehicle/program/CheJianConfig/lic.lic"))
    {
        conf_name = "/opt/vehicle/program/CheJianConfig/lic.lic";
    }

    FILE *findlic=fopen(conf_name.c_str(),"r");
    if(findlic==NULL)
    {
        printf("license request failed for feature !\n");
        return false;
    }
    fclose(findlic);

    LicDara rld,tld;
    ReadLic((char *)"lic.lic",rld);

    strcpy(tld.szMachineID,uuid.c_str());
    time_t* mptr_currentSeconds=new time_t;
    time(mptr_currentSeconds);
    struct tm *current_time = localtime(mptr_currentSeconds);  //日历时间转化为本地时间

    tld.tCur.dwYear = current_time->tm_year+1900;
    tld.tCur.dwMonth = current_time->tm_mon+1;
    tld.tCur.dwDay = current_time->tm_mday;
    tld.tCur.dwHour = current_time->tm_hour;
    tld.tCur.dwMinute = current_time->tm_min;
    tld.tCur.dwSecond = current_time->tm_sec;
    std::string SID;
    SID=rld.szMachineID;
    if(rld.tStart.dwYear>tld.tCur.dwYear)
    {
        printf("license request failed for feature !\n");
        return false;
    }else if(rld.tStart.dwYear==tld.tCur.dwYear)
    {
        if(rld.tStart.dwMonth>tld.tCur.dwMonth)
        {
            printf("license request failed for feature !\n");
            return false;
        }else if(rld.tStart.dwMonth==tld.tCur.dwMonth)
        {
            if(rld.tStart.dwDay>tld.tCur.dwDay)
            {
                printf("license request failed for feature !\n");
                return false;
            }
        }
    }
    if(rld.tEnd.dwYear<tld.tCur.dwYear)
    {
        printf("license request failed for feature !\n");
        return false;
    }else if(rld.tEnd.dwYear==tld.tCur.dwYear)
    {
        if(rld.tEnd.dwMonth<tld.tCur.dwMonth)
        {
            printf("license request failed for feature !\n");
            return false;
        }
        else if(rld.tEnd.dwMonth==tld.tCur.dwMonth)   //0517
        {
            if(rld.tEnd.dwDay<tld.tCur.dwDay)
            {
                printf("license request failed for feature !\n");
                return false;
            }
        }
    }
    if(SID.compare(uuid)==0)
    {
        printf("Lic pass:\n");
        return true;
    }
    else
    {
        printf("license request failed for feature !\n");
        return false;
    }
}
/*
功能：获取算法config文件配置城市代码
*/
std::string get_alg_city()
{
    std::string strbuf;
    std::string city_code;
    std::ifstream readfile;

    unsigned int row_number = 0;

    readfile.open("../model/configure.txt",ios::in);
    if(!readfile)
    {
       DATA_PRINT(LEVEL_INFO, "The alg_configure file open error\n");
    }

    while(getline(readfile,strbuf))
    {
        if( row_number == 13)
        {
             city_code = strbuf.substr(0,4);
        }
        row_number++;
    }


    readfile.close();

  return city_code;
}


void check_version()
{
       std::string alg_version;
       std::string prog_version=SOFT_VERSION;
       std::string alg_city = get_alg_city();
       LargeVehicleApi::algorithm_version(alg_version);
       MySQL_DB db_version;
       if (db_version.connect(NULL, 6033, "root", getDBPassWord(DBPWD).c_str(), "car_schema")) {
           std::string version1,version2,city1,city2;
           std::string sqlStringW= "(prog_version,prog_city, alg_version,alg_city) VALUES (";
           sqlStringW +="'"+prog_version+"',";
           sqlStringW +="'"+g_CheckItem.City+"',";
           sqlStringW +="'"+alg_version+"',";
           sqlStringW +="'"+alg_city +"')";
           if (db_version.selectDB("car_schema")) {
               std::string sqlString = "SELECT prog_version, prog_city,alg_version,alg_city FROM software_version order by create_time desc";
               MYSQL_RES *result = NULL;
               result=db_version.getResult(sqlString.c_str());
               if (result != NULL)
               {
                   if (result->row_count != 0) {
                       MYSQL_ROW row = NULL;
                       row = mysql_fetch_row(result);
                       try {
                           version1 = (row[0] == NULL)? " ":row[0];
                           city1    = (row[1] == NULL)? " ":row[1];
                           version2 = (row[2] == NULL)? " ":row[2];
                           city2    = (row[3] == NULL)? " ":row[3];
                       } catch (const std::exception &e) {
                           std::cout << "Error: " << e.what() << std::endl;
                       }
                       db_version.freeResult(result);
                       if((version1!=prog_version)||(version2!=alg_version)||(city1!=g_CheckItem.City)||(city2!=alg_city))
                       {
                            db_version.insert("software_version", sqlStringW.c_str());
                       }
                   } else {
                           db_version.insert("software_version", sqlStringW.c_str());
                   }
               }
           } else {
                   DATA_PRINT(LEVEL_INFO, "The database car_schema does not exist\n");
           }
           db_version.disconnect();
       }
}

void test_photo()
{
    LargeVehicleApi alg_api(true, 0, 4420, EProjectType::eJianYanType);
    cv::Mat m1 = cv::imread("0131_TBD490_LGWED2A37AE017646");

    Haopai_ImgOutMsg out_msg;
    alg_api.haopai_api_process(m1, "TBD490", out_msg);
}
