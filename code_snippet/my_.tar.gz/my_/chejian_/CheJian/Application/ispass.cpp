#include <time.h>
#include "ispass.h"

isPass::isPass(const vehicle_inf * p_vehicle_inf,CheckItem item ,bool is_ten_year)
{
    i_vehicle_inf = p_vehicle_inf;
    city_code = item.City;
    tenyear_flag = is_ten_year;
}

isPass::~isPass()
{

}


string isPass::returnIsPass()//is_pass判决逻辑
{
    initArray();

    if(!isSmallCar())
    {
        return "-1";
    }
    if(!i_vehicle_inf->AlgorithmCheck)
    {
        return "-1";
    }

    all_list=common;
    if(!special.empty())
    {
       all_list.insert(all_list.end(),special.begin(),special.end());
    }
    if(tenyear_flag)
    {
       all_list.insert(all_list.end(),common_tenyear.begin(),common_tenyear.end());
       if(!special_tenyear.empty())
       {
          all_list.insert(all_list.end(),special_tenyear.begin(),special_tenyear.end());
       }
    }
    if(!isInProvince())
    {
        if(!out_province_only.empty())
        {
            all_list.insert(all_list.end(),out_province_only.begin(),out_province_only.end());
        }
    }
    else
    {
        if(!province_only.empty())
        {
            all_list.insert(all_list.end(),province_only.begin(),province_only.end());
        }
    }

    if(!other_photo.empty())
    {
        if(city_code == NINGBO)
        {
            if(i_vehicle_inf->is_beimian)
            {
                all_list.insert(all_list.end(),other_photo.begin(),other_photo.end());
            }
        }
    }


    if(!complete(all_list,i_vehicle_inf->m_zplist))
    {
        return "0";
    }

    return unqualified(all_list,i_vehicle_inf->m_dbbhglist);

}
void isPass::initArray()//根据城市代码初始化数组
{
    small_vehicle = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38",
                     "K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48", "K49"};
    if(city_code == TIANJIN) //天津不检测一二轴，左右灯光，驻车制动
    {
        common= {"0111", "0112", "0113", "0157",
                 "0201", "0202", "0203", "0204"};
        common_tenyear = {"0344", "0351", "0342"};
    }
    else if((city_code == GUIGANG)||(city_code==ZHANGJIAJIE)||(city_code==YUEYANG))//贵港 张家界 岳阳无牌证申请表
    {
        common= {"0111", "0112", "0113", "0157",
                 "0201", "0203", "0204",
                 "0321", "0352", "0322", "0348" };
        common_tenyear = {"0344", "0351","0342", "0323"};
    }
    else if(city_code == JIUJIANG)
    {
        common = {"0111", "0112", "0113", "0190",
                 "0201", "0202", "0203", "0204", "0205",
                 "0321", "0322", "0348",  "0352"};
        common_tenyear = {"0344", "0351","0342", "0323"};
    }
    else if(city_code == NANJING)
    {
        common = {"0111", "0112", "0113", "0157",
                 "0201", "0202", "0203", "0204", "0205", "0209",
                 "0321", "0352", "0322", "0348"};
        common_tenyear = {"0344", "0351","0342", "0323"};
    }
    else if(city_code == DAQING)
    {
        common = {"0111", "0112", "0113", "0157",
                  "0201", "0203", "0204", "0205", "0209",
                  "0321", "0352", "0322", "0348"};
        common_tenyear = {"0344", "0351","0342", "0323"};
    }
    else if(city_code == TAIYUAN)
    {/*太原不上传0344底盘动态开始照片、0342底盘动态结束照片*/
        common= {"0111", "0112", "0113", "0157",
                 "0201", "0202", "0203", "0204",
                 "0321", "0352", "0322", "0348" };
        common_tenyear = {"0351", "0323"};
    }
    else if(city_code==QUZHOU)
    {/*衢州无安全带牌证申请表*/
        common= {"0111", "0112", "0113",
                 "0201", "0203", "0204",
                 "0321", "0352", "0322", "0348" };
        common_tenyear = {"0344", "0351","0342", "0323"};
    }
    else if(city_code == FUZHOU2)
    {
        common= {"0111", "0112", "0113", "0157",
                 "0201", "0202", "0203", "0204", "0209", "0210",
                 "0321", "0352", "0322", "0348" };
        common_tenyear = {"0351", "0323"};
    }
    else
    {
        common= {"0111", "0112", "0113", "0157",
                 "0201", "0202", "0203", "0204",
                 "0321", "0352", "0322", "0348" };
        common_tenyear = {"0344", "0351","0342", "0323"};
    }

    if(city_code == TIANJIN)
    {
        //天津不检测　完税证明，一二轴，灯光工位，驻车制动
        //special = {"0168", "0209", "0210"}; //专用上传照片 10年以下
        special = {"0168", "0209", "0210"}; //专用上传照片 10年以下
        special_tenyear = {};//专用上传照片十年以上
        //out_province_only = {"0206"};
        out_province_only = {};
        province_only = {};
        city_for_short = "津";
        other_photo ={};
    }

    if(city_code == NINGBO)
    {
        special = { "0205", "0209", "0297",  "0299",}; //专用上传照片 10年以下
        special_tenyear = {};//专用上传照片十年以上
        out_province_only = {};
        province_only = {"0207", "0208"};
        city_for_short = "浙";
        other_photo = {"0298"};
    }

    if(city_code == GUIGANG)
    {
        special = { "0205", "0210", "0297" }; //专用上传照片 10年以下
        special_tenyear = {};//专用上传照片十年以上
        out_province_only = {};
        province_only = {};
        city_for_short = "桂";
        other_photo = {};
    }

    if(city_code == ZHANGJIAJIE)
    {
        //special = { "0214", "0205", "0158" }; //专用上传照片 10年以下
        //special = {"0205", "0158" }; //专用上传照片 10年以下
        special = {"0214", "0209", "0210", "0158" }; //专用上传照片 10年以下
        special_tenyear = {};//专用上传照片十年以上
        out_province_only = {};
        province_only = {};
        city_for_short = "湘";
        other_photo = {};
    }

    if(city_code == YUEYANG)
    {
        //special = { "0115" }; //专用上传照片 10年以下
        special = {};
        special_tenyear = {};//专用上传照片十年以上
        out_province_only = {};
        province_only = {};
        city_for_short = "湘";
        other_photo = {};
    }

    if(city_code == NANJING)
    {
        special = { "0212" }; //专用上传照片 10年以下
        special_tenyear = {};//专用上传照片十年以上
        out_province_only = {};
        province_only = {};
        city_for_short = "苏";
        other_photo = {};
    }

    if (XIAN == city_code) {
        special = { "0225" };
        special_tenyear = {};//专用上传照片十年以上
        out_province_only = {};
        province_only = {};
        city_for_short = "陕";
        other_photo = {};
    }
}
bool isPass::complete(vector<string> type_array,vector<_photo_resource> photo_list )//照片列表是否包含全部类型
{
    unsigned int i,j;
    for(i = 0;i < type_array.size();i++)
    {
        for(j =0;j < photo_list.size(); j++)
        {
            if(type_array[i] == photo_list[j].zptype)
            {
                break;
            }
        }
        if(city_code == ZHONGSHAN && "0203" == type_array[i])
        {
            continue;
        }
        if(city_code == DEZHOU && "0203" == type_array[i])
        {
            continue;
        }
        if(city_code == ZAOZHANG && "0203" == type_array[i])
        {
            continue;
        }

        if(j == photo_list.size())
        {
            return false;
        }
    }
    return true;
}
string isPass::unqualified(vector<string> type_array,vector<_dbbhg_list> unqualified_list)   //是否有不合格照片
{
    unsigned int i,j;
    string result = "1";
    for(i = 0; i < unqualified_list.size() ;i++)
    {
        for(j = 0;j < type_array.size(); j++)
        {
            if(type_array[j] == unqualified_list[i].zptype)
            {
                if(unqualified_list[i].dbresult == "5")
                {
                    result= "0";
                    return result;
                }
                if(unqualified_list[i].dbresult == "4")
                {
                    result = "4";
                }
            }
        }
    }
    return result;
}
bool isPass::isInProvince()
{
    if(i_vehicle_inf->m_fzjg.find(city_for_short)==string::npos)
    {
        return false;
    }
    return true;
}
bool isPass::isSmallCar()
{
    for(unsigned int i = 0;i < small_vehicle.size() ;i++)
    {
        if(small_vehicle[i] == i_vehicle_inf->m_cllx)
        {
            return true;
        }
    }
    return false;
}

