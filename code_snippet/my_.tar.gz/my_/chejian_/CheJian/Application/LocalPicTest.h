#ifndef LOCALPICTEST_H
#define LOCALPICTEST_H

#include <string>
#include <vector>
using namespace std;
#include "check_item.h"
typedef struct tagTestResult
{
   string category;
   string path;
   string result;
   string reason;
   string logo;

}TTestResult;
typedef std::vector<TTestResult> vecTestResult;


class CLocalPicTest
{
public:
    CLocalPicTest();
    ~CLocalPicTest();
    void GetFilesName(string strDir);
    void TestLocalFile(string strDir);
    void WriteResult();
    string Compute0111();
    string Compute0112();
    string Compute0113();
    string Compute0157();
    string Compute0201();
    string Compute0202();
    string Compute0203();
    string Compute0204();
    string Compute0205();
    string Compute0206();
    string ComputeHuanBaoDan();
    string Compute0321();
    string Compute0352();
    string Compute0322();
    string Compute0348();
public:
    static void DataAnalyseThread();
private:

};

#endif // LOCALPICTEST_H
