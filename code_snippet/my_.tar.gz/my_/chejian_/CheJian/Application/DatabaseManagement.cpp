#include "MySQL_DB.h"

#include <iostream>
#include "Application/check_item.h"
extern CheckItem g_CheckItem;

/* 下划线后面的数字就是数据库版本，数据库版本数字必须连续使用。 */
bool updateDatabase_1(MySQL_DB &db);
bool updateDatabase_2(MySQL_DB &db);
bool updateDatabase_3(MySQL_DB &db);
bool updateDatabase_4(MySQL_DB &db);
bool updateDatabase_5(MySQL_DB &db);
bool updateDatabase_6(MySQL_DB &db);
bool updateDatabase_7(MySQL_DB &db);
bool updateDatabase_8(MySQL_DB &db);
bool updateDatabase_9(MySQL_DB &db);
bool updateDatabase_10(MySQL_DB &db);
bool updateDatabase_11(MySQL_DB &db);
bool updateDatabase_12(MySQL_DB &db);
bool updateDatabase_13(MySQL_DB &db);
bool updateDatabase_14(MySQL_DB &db);
bool updateDatabase_15(MySQL_DB &db);
bool updateDatabase_16(MySQL_DB &db);
bool updateDatabase_17(MySQL_DB &db);
bool updateDatabase_18(MySQL_DB &db);
bool updateDatabase_19(MySQL_DB &db);
bool updateDatabase_20(MySQL_DB &db);
bool updateDatabase_21(MySQL_DB &db);
bool updateDatabase_22(MySQL_DB &db);
bool updateDatabase_23(MySQL_DB &db);
bool updateDatabase_24(MySQL_DB &db);
bool updateDatabase_25(MySQL_DB & db);
bool updateDatabase_26(MySQL_DB & db);

typedef bool (*updateDatabase_X)(MySQL_DB &db);

static std::vector<updateDatabase_X> updateDatabase_List;

bool DatabaseManagement()
{
    DATA_PRINT(LEVEL_INFO, "开始检查数据库版本...... \n");
    DATA_PRINT(LEVEL_INFO, "请勿终止程序或者操作数据库！\n");

    bool ret = true;
    unsigned int version = 0;

    MySQL_DB db;

    if (db.connect(NULL, 6033, "root", getDBPassWord(DBPWD).c_str(), NULL)) {
        if (db.selectDB("car_schema")) {
            std::string sqlString = "SELECT version FROM database_version";

            MYSQL_RES *result = db.getResult(sqlString.c_str());
            if (result != NULL) {
                MYSQL_ROW row = NULL;
                row = mysql_fetch_row(result);

                try {
                    version = std::stoi(row[0]);
                } catch (const std::exception &e) {
                    std::cout << "Error: " << e.what() << std::endl;
                    ret = false;
                }

                db.freeResult(result);
            } else {
                ret = false;
            }
        } else {
            if (db.getErrorNumber() == ER_BAD_DB_ERROR) {	/* 如果数据库不存在，则创建新的数据库 */
                version = 0;
                DATA_PRINT(LEVEL_INFO, "The database \"car_schema\" does not exist, ready to create a new database. \n");
            } else {
                ret = false;
            }
        }
    } else {
        ret = false;
    }

    if (ret) {
        /* 加载数据库所有版本的升级函数 */
        updateDatabase_List.push_back(updateDatabase_1);
        updateDatabase_List.push_back(updateDatabase_2);
        updateDatabase_List.push_back(updateDatabase_3);
        updateDatabase_List.push_back(updateDatabase_4);
        updateDatabase_List.push_back(updateDatabase_5);
        updateDatabase_List.push_back(updateDatabase_6);
        updateDatabase_List.push_back(updateDatabase_7);
        updateDatabase_List.push_back(updateDatabase_8);
        updateDatabase_List.push_back(updateDatabase_9);
        updateDatabase_List.push_back(updateDatabase_10);
        updateDatabase_List.push_back(updateDatabase_11);
        updateDatabase_List.push_back(updateDatabase_12);
        updateDatabase_List.push_back(updateDatabase_13);
        updateDatabase_List.push_back(updateDatabase_14);
        updateDatabase_List.push_back(updateDatabase_15);
        updateDatabase_List.push_back(updateDatabase_16);
        updateDatabase_List.push_back(updateDatabase_17);
        updateDatabase_List.push_back(updateDatabase_18);
        updateDatabase_List.push_back(updateDatabase_19);
        updateDatabase_List.push_back(updateDatabase_20);
        updateDatabase_List.push_back(updateDatabase_21);
        updateDatabase_List.push_back(updateDatabase_22);
        updateDatabase_List.push_back(updateDatabase_23);
        updateDatabase_List.push_back(updateDatabase_24);
        updateDatabase_List.push_back(updateDatabase_25);
        updateDatabase_List.push_back(updateDatabase_26);

        if (version < updateDatabase_List.size()) {
            /* 执行升级过程 */
            for (unsigned int i = version; i < updateDatabase_List.size(); i++) {
                if (!updateDatabase_List[i](db)) {  /* 任何一个版本的程序升级失败，都不能再进行下一个版本的升级操作 */
                    ret = false;
                    break;
                }
            }
        } else if (version == updateDatabase_List.size()) {
            DATA_PRINT(LEVEL_INFO,
                       "The current version of the database is [%d], which is the latest version and does not need to be updated. \n",
                       version);
        } else {
            ret = false;
            DATA_PRINT(LEVEL_ERROR,
                       "数据库版本异常！当前程序维护版本：%d，实际获取版本：%d \n",
                       updateDatabase_List.size(), version);
        }
    }

    db.disconnect();

    DATA_PRINT(LEVEL_INFO, "数据库版本检查%s \n", ret ? "完毕。" : "发现错误！");
    return ret;
}

/*
数据库版本：1

内容：
创建数据库和所有表。
*/
bool updateDatabase_1(MySQL_DB &db)
{
    DATA_PRINT(LEVEL_INFO, "Start updating the database to version [1] ...... \n");

    if (!db.createDB("car_schema")) {
        return false;
    }

    db.selectDB("car_schema");

    std::string sqlString = "(";
    sqlString += "id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT '主键',";
    sqlString += "jylsh VARCHAR(64) COMMENT '检验流水号',";			/* 1 */
    sqlString += "jyjgbh VARCHAR(64) COMMENT '检验机构编号',";		/* 2 */
    sqlString += "jylb VARCHAR(64) COMMENT '检验类别',";				/* 3 */
    sqlString += "hpzl VARCHAR(64) COMMENT '号牌种类',";				/* 4 */
    sqlString += "hphm VARCHAR(64) COMMENT '号牌号码',";				/* 5 */
    sqlString += "clsbdh VARCHAR(64) COMMENT '车辆识别代号',";		/* 6 */
    sqlString += "syr VARCHAR(256) COMMENT '机动车所有人',";			/* 7 */
    sqlString += "sjhm VARCHAR(64) COMMENT '手机号码',";				/* 8 */
    sqlString += "sxrq VARCHAR(64) COMMENT '保险生效日期',";			/* 9 */
    sqlString += "zzrq VARCHAR(64) COMMENT '保险终止日期',";			/* 10 */
    sqlString += "cllx VARCHAR(64) COMMENT '车辆类型',";				/* 11 */
    sqlString += "syxz VARCHAR(64) COMMENT '使用性质',";				/* 12 */
    sqlString += "zbzl VARCHAR(64) COMMENT '整备质量',";				/* 13 */
    sqlString += "kssj VARCHAR(64) COMMENT '检验过程开始时间',";		/* 14 */
    sqlString += "jssj VARCHAR(64) COMMENT '检验项目结束时间',";		/* 15 */
    sqlString += "fdjh VARCHAR(64) COMMENT '发动机/电动机号码',";		/* 16 */
    sqlString += "clpp VARCHAR(64) COMMENT '车辆品牌',";				/* 17 */
    sqlString += "clxh VARCHAR(64) COMMENT '车辆型号',";				/* 18 */
    sqlString += "ccdjrq VARCHAR(64) COMMENT '初次登记日期',";		/* 19 */
    sqlString += "ccrq VARCHAR(64) COMMENT '出厂日期',";				/* 20 */
    sqlString += "wgjcjyy VARCHAR(64) COMMENT '车辆外观检验员',";		/* 21 */
    sqlString += "xszbh VARCHAR(64) COMMENT '行驶证编号',";			/* 22 */
    sqlString += "fzrq VARCHAR(64) COMMENT '行驶证发证日期',";        /* 23 */
    sqlString += "rlzl VARCHAR(64) COMMENT '燃料种类',";				/* 24 */
    sqlString += "zpzs VARCHAR(64) COMMENT '需要比对的照片总数',";     /* 25 */
    sqlString += "ckbdzplist TEXT COMMENT '参考比对的照片列表',";		/* 26 */
    sqlString += "zplist TEXT COMMENT '需要比对的照片列表',";			/* 27 */
    sqlString += "spzs VARCHAR(64) COMMENT '需要比对的视频总数',";	    /* 28 */
    sqlString += "splist TEXT COMMENT '需要比对的视频列表',";			/* 29 */
    sqlString += "bdbhgs INT UNSIGNED COMMENT '对比不合格数',";		/* 30 */
    sqlString += "bdbhglist TEXT COMMENT '对比不符合明细',";			/* 31 */
    sqlString += "csys VARCHAR(64) COMMENT '车身颜色',";				/* 32 */
    sqlString += "pl VARCHAR(64) COMMENT '排量',";					/* 33 */
    sqlString += "gl VARCHAR(64) COMMENT '功率',";					/* 34 */
    sqlString += "zxxs VARCHAR(64) COMMENT '转向形式',";				/* 35 */
    sqlString += "cwkc VARCHAR(64) COMMENT '车外廓长',";				/* 36 */
    sqlString += "cwkk VARCHAR(64) COMMENT '车外廓宽',";				/* 37 */
    sqlString += "cwkg VARCHAR(64) COMMENT '车外廓高',";				/* 38 */
    sqlString += "hxnbcd VARCHAR(64) COMMENT '货箱内部长度',";		/* 39 */
    sqlString += "hxnbkd VARCHAR(64) COMMENT '货箱内部宽度',";		/* 40 */
    sqlString += "hxnbgd VARCHAR(64) COMMENT '货箱内部高度',";		/* 41 */
    sqlString += "gbthps VARCHAR(64) COMMENT '钢板弹簧片数',";		/* 42 */
    sqlString += "zs VARCHAR(64) COMMENT '轴数',";					/* 43 */
    sqlString += "zj VARCHAR(64) COMMENT '轴距',";					/* 44 */
    sqlString += "qlj VARCHAR(64) COMMENT '前轮距',";				/* 45 */
    sqlString += "hlj VARCHAR(64) COMMENT '后轮距',";				/* 46 */
    sqlString += "ltgg VARCHAR(128) COMMENT '轮胎规格',";			    /* 47 */
    sqlString += "lts VARCHAR(64) COMMENT '轮胎数',";				/* 48 */
    sqlString += "zzl VARCHAR(64) COMMENT '总质量',";				/* 49 */
    sqlString += "hdzzl VARCHAR(64) COMMENT '核定载质量',";			/* 50 */
    sqlString += "hdzk VARCHAR(64) COMMENT '核定载客',";				/* 51 */
    sqlString += "zqyzl VARCHAR(64) COMMENT '准牵引质量',";			/* 52 */
    sqlString += "qpzk VARCHAR(64) COMMENT '驾驶室前排载客人数',";	    /* 53 */
    sqlString += "hpzk VARCHAR(64) COMMENT '驾驶室后排载客人数',";	    /* 54 */
    sqlString += "clyt VARCHAR(64) COMMENT '车辆用途',";				/* 55 */
    sqlString += "ytsx VARCHAR(64) COMMENT '用途属性',";				/* 56 */
    sqlString += "sfxny VARCHAR(64) COMMENT '是否新能源汽车',";		/* 57 */
    sqlString += "xnyzl VARCHAR(64) COMMENT '新能源种类',";			/* 58 */
    sqlString += "device_id INT UNSIGNED COMMENT '设备ID',";
    sqlString += "created_at DATETIME COMMENT '本行创建时间',";
    sqlString += "KEY `index_hphm` (`hphm`),";
    sqlString += "KEY `index_created_at` (`created_at`)";
    sqlString += ")";
    if (!db.createTable("vehicle_checks", sqlString.c_str())) {
        return false;
    }

    sqlString = "(";
    sqlString += "id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT '主键',";
    sqlString += "vehicle_check_id INT UNSIGNED NOT NULL COMMENT '外键，连接vehicle_checks的主键',";
    sqlString += "category VARCHAR(128) COMMENT '类型',";
    sqlString += "name VARCHAR(128) COMMENT '文件名',";
    sqlString += "result INT UNSIGNED COMMENT '检测结果',";
    sqlString += "reason VARCHAR(128) COMMENT '原因',";
    sqlString += "created_at DATETIME COMMENT '本行创建时间',";
    sqlString += "CONSTRAINT `link_vehicle` FOREIGN KEY (`vehicle_check_id`) REFERENCES `vehicle_checks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,";
    sqlString += "KEY `index_of_report` (`created_at`,`category`,`result`)";
    sqlString += ")";
    if (!db.createTable("check_infos", sqlString.c_str())) {
        return false;
    }

    sqlString = "(";
    sqlString += "id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT '主键',";
    sqlString += "vehicle_check_id INT UNSIGNED NOT NULL COMMENT '外键，连接vehicle_checks的主键',";
    sqlString += "video1_download INT UNSIGNED COMMENT '视频1下载时间',";	//FixMe, 需要修改和补充
    sqlString += "xsz_process INT UNSIGNED COMMENT '行驶证',";
    sqlString += "sqb_process INT UNSIGNED COMMENT '牌证申请表',";
    sqlString += "jqx_process INT UNSIGNED COMMENT '交强险',";
    sqlString += "jybg_process INT UNSIGNED COMMENT '检验报告',";
    sqlString += "cyjl_process INT UNSIGNED COMMENT '查验记录',";
    sqlString += "zqf_process INT UNSIGNED COMMENT '左前方',";
    sqlString += "yhf_process INT UNSIGNED COMMENT '右后方',";
    sqlString += "cjh_process INT UNSIGNED COMMENT '车架号',";
    sqlString += "aqd_process INT UNSIGNED COMMENT '安全带',";
    sqlString += "zdg_process INT UNSIGNED COMMENT '左灯光',";
    sqlString += "ydg_process INT UNSIGNED COMMENT '右灯光',";
    sqlString += "yzzd_process INT UNSIGNED COMMENT '一轴制动',";
    sqlString += "ezzd_process INT UNSIGNED COMMENT '二轴制动',";
    sqlString += "zczd_process INT UNSIGNED COMMENT '驻车制动',";
    sqlString += "dpdtks_process INT UNSIGNED COMMENT '底盘动态开始',";
    sqlString += "dpdtjs_process INT UNSIGNED COMMENT '底盘动态结束',";
    sqlString += "dpjy_process INT UNSIGNED COMMENT '底盘检验',";
    sqlString += "wqjy_process INT UNSIGNED COMMENT '尾气检验',";
    sqlString += "mhq_process INT UNSIGNED COMMENT '灭火器',";
    sqlString += "yjc_process INT UNSIGNED COMMENT '应急锤',";
    sqlString += "jly_process INT UNSIGNED COMMENT '行驶记录仪',";
    sqlString += "zql_process INT UNSIGNED COMMENT '左前轮',";
    sqlString += "zhl_process INT UNSIGNED COMMENT '左后轮',";
    sqlString += "yql_process INT UNSIGNED COMMENT '右前轮',";
    sqlString += "yhl_process INT UNSIGNED COMMENT '右后轮',";
    sqlString += "zqf_v_process INT UNSIGNED COMMENT '左前方-视频',";
    sqlString += "yhf_v_process INT UNSIGNED COMMENT '右后方-视频',";
    sqlString += "pbzd_v_process INT UNSIGNED COMMENT '平板制动-视频',";
    sqlString += "yzzd_v_process INT UNSIGNED COMMENT '一轴制动-视频',";
    sqlString += "ezzd_v_process INT UNSIGNED COMMENT '二轴制动-视频',";
    sqlString += "zdg_v_process INT UNSIGNED COMMENT '左灯光-视频',";
    sqlString += "ydg_v_process INT UNSIGNED COMMENT '右灯光-视频',";
    sqlString += "dp_v_process INT UNSIGNED COMMENT '底盘-视频',";
    sqlString += "glzc_v_process INT UNSIGNED COMMENT '滚筒驻车-视频',";
    sqlString += "pbzc_v_process INT UNSIGNED COMMENT '平板驻车-视频',";
    sqlString += "video1_pre INT UNSIGNED COMMENT '视频1预处理',";	//FixMe, 需要修改和补充
    sqlString += "video1_process INT UNSIGNED COMMENT '视频1',";		//FixMe, 需要修改和补充

    sqlString += "xsz_response INT UNSIGNED COMMENT '行驶证',";
    sqlString += "sqb_response INT UNSIGNED COMMENT '牌证申请表',";
    sqlString += "jqx_response INT UNSIGNED COMMENT '交强险',";
    sqlString += "jybg_response INT UNSIGNED COMMENT '检验报告',";
    sqlString += "cyjl_response INT UNSIGNED COMMENT '查验记录',";
    sqlString += "zqf_response INT UNSIGNED COMMENT '左前方',";
    sqlString += "yhf_response INT UNSIGNED COMMENT '右后方',";
    sqlString += "cjh_response INT UNSIGNED COMMENT '车架号',";
    sqlString += "aqd_response INT UNSIGNED COMMENT '安全带',";
    sqlString += "zdg_response INT UNSIGNED COMMENT '左灯光',";
    sqlString += "ydg_response INT UNSIGNED COMMENT '右灯光',";
    sqlString += "yzzd_response INT UNSIGNED COMMENT '一轴制动',";
    sqlString += "ezzd_response INT UNSIGNED COMMENT '二轴制动',";
    sqlString += "zczd_response INT UNSIGNED COMMENT '驻车制动',";
    sqlString += "dpdtks_response INT UNSIGNED COMMENT '底盘动态开始',";
    sqlString += "dpdtjs_response INT UNSIGNED COMMENT '底盘动态结束',";
    sqlString += "dpjy_response INT UNSIGNED COMMENT '底盘检验',";
    sqlString += "wqjy_response INT UNSIGNED COMMENT '尾气检验',";
    sqlString += "mhq_response INT UNSIGNED COMMENT '灭火器',";
    sqlString += "yjc_response INT UNSIGNED COMMENT '应急锤',";
    sqlString += "jly_response INT UNSIGNED COMMENT '行驶记录仪',";
    sqlString += "zql_response INT UNSIGNED COMMENT '左前轮',";
    sqlString += "zhl_response INT UNSIGNED COMMENT '左后轮',";
    sqlString += "yql_response INT UNSIGNED COMMENT '右前轮',";
    sqlString += "yhl_response INT UNSIGNED COMMENT '右后轮',";

    sqlString += "video1_response INT UNSIGNED COMMENT '视频1',";		//FixMe, 需要修改和补充
    sqlString += "picture_download INT UNSIGNED COMMENT '所有照片下载时间',";
    sqlString += "algorithm_total INT UNSIGNED COMMENT '算法处理的总时间',";
    sqlString += "total INT UNSIGNED COMMENT '总时间',";
    sqlString += "wait_queue INT UNSIGNED COMMENT '等待队列的时间',";
    sqlString += "total_no_wait INT UNSIGNED COMMENT '总时间（不包括等待队列的时间）',";
    sqlString += "device_id INT UNSIGNED COMMENT '设备ID',";
    sqlString += "created_at DATETIME COMMENT '本行创建时间',";
    sqlString += "CONSTRAINT `link_vehicle_1` FOREIGN KEY (`vehicle_check_id`) REFERENCES `vehicle_checks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE";
    sqlString += ")";
    if (!db.createTable("time_infos", sqlString.c_str())) {
        return false;
    }

    sqlString = "(";
    sqlString += "id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT '主键',";
    sqlString += "version INT UNSIGNED COMMENT '数据库版本'";
    sqlString += ")";
    if (!db.createTable("database_version", sqlString.c_str())) {
        return false;
    }

    sqlString = "(";
    sqlString += "info_id INT NOT NULL AUTO_INCREMENT,";
    sqlString += "device_id INT(10) NOT NULL,";
    sqlString += "ip VARCHAR(40) NOT NULL,";
    sqlString += "login_time DATETIME,";
    sqlString += "logout_time DATETIME,";
    sqlString += "PRIMARY KEY(info_id)";
    sqlString += ")";
    if (!db.createTable("client_login_info", sqlString.c_str())) {
        return false;
    }

    if (!db.insert("database_version", "(version) VALUES (0)")) {
        return false;
    }

    /* 更新当前数据库版本 */
    if (!db.update("database_version", "SET version='1' WHERE id='1'")) {
        return false;
    }

    DATA_PRINT(LEVEL_INFO, "The update of version [1] has been completed. \n");
    return true;
}

/*
数据库版本：2

内容：
表vehicle_checks增加两个字段station_status和center_status。
*/
bool updateDatabase_2(MySQL_DB &db)
{
    DATA_PRINT(LEVEL_INFO, "Start updating the database to version [2] ...... \n");

    std::string sqlString;
    sqlString += "ADD COLUMN `station_status` INT(10) UNSIGNED NULL DEFAULT 0 COMMENT '检测站确认状态' AFTER `xnyzl`,";
    sqlString += "ADD COLUMN `center_status` INT(10) UNSIGNED NULL DEFAULT 0 COMMENT '监管中心确认状态' AFTER `station_status`";

    if (!db.alterTable("vehicle_checks", sqlString.c_str())) {
        return false;
    }

    /* 更新当前数据库版本 */
    if (!db.update("database_version", "SET version='2' WHERE id='1'")) {
        return false;
    }

    DATA_PRINT(LEVEL_INFO, "The update of version [2] has been completed. \n");
    return true;
}

/*
数据库版本：3

内容：
新增两张表vehicle_checks_demo_test和check_video_infos
*/
bool updateDatabase_3(MySQL_DB &db)
{
    DATA_PRINT(LEVEL_INFO, "Start updating the database to version [3] ...... \n");

    std::string sqlString =
            "("
            "`id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',"
            "`vehicle_check_id` int(10) unsigned NOT NULL COMMENT '索引id',"
            "`lsh` varchar(64) DEFAULT NULL COMMENT '流水号',"
            "`zqf_Cheliang_chepai` varchar(64) DEFAULT NULL COMMENT '左前方车牌位置',"
            "`zqf_Cheliang_chebiao` varchar(64) DEFAULT NULL COMMENT '左前方车标位置',"
            "`zqf_Cheliang_sanjiaojia` varchar(64) DEFAULT NULL COMMENT '左前方三脚架的位置',"
            "`zqf_Cheliang_tiehua` varchar(64) DEFAULT NULL COMMENT '左前方贴画位置',"
            "`zqf_Cheliang_b_ori_waiguan` varchar(64) DEFAULT NULL COMMENT '左前方外观判定',"
            "`zqf_Cheliang_b_chepai` varchar(64) DEFAULT NULL COMMENT '左前方车牌判定',"
            "`zqf_Cheliang_b_chebiao` varchar(64) DEFAULT NULL COMMENT '左前方车标判定',"
            "`zqf_Cheliang_b_sanjiaojia` varchar(64) DEFAULT NULL COMMENT '左前方三脚架判定',"
            "`yhf_Cheliang_chepai` varchar(64) DEFAULT NULL COMMENT '右后方车牌位置',"
            "`yhf_Cheliang_chebiao` varchar(64) DEFAULT NULL COMMENT '右后方车标位置',"
            "`yhf_Cheliang_sanjiaojia` varchar(64) DEFAULT NULL COMMENT '右后方三脚架的位置',"
            "`yhf_Cheliang_tiehua` varchar(64) DEFAULT NULL COMMENT '右后方贴画位置',"
            "`yhf_Cheliang_b_ori_waiguan` varchar(64) DEFAULT NULL COMMENT '右后方外观判定',"
            "`yhf_Cheliang_b_chepai` varchar(64) DEFAULT NULL COMMENT '右后方车牌判定',"
            "`yhf_Cheliang_b_chebiao` varchar(64) DEFAULT NULL COMMENT '右后方车标判定',"
            "`yhf_Cheliang_b_sanjiaojia` varchar(64) DEFAULT NULL COMMENT '右后方三脚架判定',"
            "`Anquandai_r` varchar(64) DEFAULT NULL COMMENT '安全带坐标',"
            "`Anquandai_b_anquandai` varchar(64) DEFAULT NULL COMMENT '安全带判定',"
            "`Chejiahao_r` varchar(64) DEFAULT NULL COMMENT '车架号位置',"
            "`Chejiahao_b_pic_quality` varchar(64) DEFAULT NULL COMMENT '车架号比对质量',"
            "`Chejiahao_b_chejiahao` varchar(64) DEFAULT NULL COMMENT '车架号检验判定',"
            "`Baodan_hongzhan` varchar(64) DEFAULT NULL COMMENT '红章位置',"
            "`Baodan_roi` varchar(64) DEFAULT NULL COMMENT '检测车牌 车架号辅助区域',"
            "`Baodan_chechuanshui` varchar(64) DEFAULT NULL COMMENT '车船税区域',"
            "`Baodan_chepai` varchar(64) DEFAULT NULL COMMENT '车牌位置',"
            "`Baodan_chejiahao` varchar(64) DEFAULT NULL COMMENT '车架号位置',"
            "`Baodan_start_riqi` varchar(64) DEFAULT NULL COMMENT '开始日期字符串位置',"
            "`Baodan_end_riqi` varchar(64) DEFAULT NULL COMMENT '结束日期字符串位置',"
            "`Baodan_fuben` varchar(64) DEFAULT NULL COMMENT '副本字符框',"
            "`Baodan_b_pic_quality` varchar(64) DEFAULT NULL COMMENT '保单图片质量',"
            "`Baodan_b_baodan` varchar(64) DEFAULT NULL COMMENT '保单检测判定',"
            "`Baodan_b_riqi` varchar(64) DEFAULT NULL COMMENT '保单日期检测判定',"
            "`Baodan_b_fuben` varchar(64) DEFAULT NULL COMMENT '保单副本检测判定',"
            "`Baodan_b_chechuanshui` varchar(64) DEFAULT NULL COMMENT '车船税判定',"
            "`Xingshizheng_xingshizheng` varchar(64) DEFAULT NULL COMMENT '行驶证主页 坐标系',"
            "`Xingshizheng_xingshizheng_fuye` varchar(64) DEFAULT NULL COMMENT '行驶证副页 坐标系',"
            "`Xingshizheng_chepai` varchar(64) DEFAULT NULL COMMENT '车牌矩形框坐标',"
            "`Xingshizheng_chejiahao` varchar(64) DEFAULT NULL COMMENT '车驾号矩形框坐标',"
            "`Xingshizheng_fazhengriqi` varchar(64) DEFAULT NULL COMMENT '车驾号矩形框坐标',"
            "`Xingshizheng_chepai_fuye` varchar(64) DEFAULT NULL COMMENT '行驶证副页 坐标系',"
            "`Xingshizheng_danganhao_fuye` varchar(64) DEFAULT NULL COMMENT '车牌矩形框坐标',"
            "`Xingshizheng_tiaoxingma_fuye` varchar(64) DEFAULT NULL COMMENT '车驾号矩形框坐标',"
            "`Xingshizheng_b_pic_quality` varchar(64) DEFAULT NULL COMMENT '车架号图片清晰度判定',"
            "`Xingshizheng_b_xingshizheng` varchar(64) DEFAULT NULL COMMENT '行驶证判定',"
            "`Xingshizheng_b_fazhengriqi` varchar(64) DEFAULT NULL COMMENT '发证日期',"
            "`Xingshizheng_b_danganhao` varchar(64) DEFAULT NULL COMMENT '档案号',"
            "`Xingshizheng_b_tiaoxingma` varchar(64) DEFAULT NULL COMMENT '条形码',"
            "`Jianyanbaogao_hongzhang` varchar(64) DEFAULT NULL COMMENT '的红章矩形框坐标',"
            "`Jianyanbaogao_auxiliary` varchar(64) DEFAULT NULL COMMENT '车牌车架号所在大区域扩充后的图像矩形框',"
            "`Jianyanbaogao_compare` varchar(64) DEFAULT NULL COMMENT '比对内容所在大区域',"
            "`Jianyanbaogao_qianming` varchar(64) DEFAULT NULL COMMENT '签名区域',"
            "`Jianyanbaogao_jianyanjielun` varchar(64) DEFAULT NULL COMMENT '检验结论区域',"
            "`Jianyanbaogao_chejiahao` varchar(64) DEFAULT NULL COMMENT '车架号矩形框坐标',"
            "`Jianyanbaogao_chepai` varchar(64) DEFAULT NULL COMMENT '车牌矩形框坐标',"
            "`Jianyanbaogao_b_pic_quality` varchar(64) DEFAULT NULL COMMENT '检验报告图片质量',"
            "`Jianyanbaogao_b_jianyanbaogao` varchar(64) DEFAULT NULL COMMENT '检验报告判定',"
            "`Jianyanbaogao_b_qianming` varchar(64) DEFAULT NULL COMMENT '签名判定',"
            "`Jianyanbaogao_b_hongzhang` varchar(64) DEFAULT NULL COMMENT '红章判定',"
            "`Jianyanbaogao_b_jianyanjielun` varchar(64) DEFAULT NULL COMMENT '检验结论判定',"
            "`Jianyanbaogao_b_jianyan_info` varchar(64) DEFAULT NULL COMMENT '检验信息判定',"
            "`Shenqingdan_chepai` varchar(64) DEFAULT NULL COMMENT '申请单车牌',"
            "`Shenqingdan_qianming` varchar(64) DEFAULT NULL COMMENT '申请单签名',"
            "`Shenqingdan_telephone` varchar(64) DEFAULT NULL COMMENT '申请单电话',"
            "`Shenqingdan_s_telephone` varchar(64) DEFAULT NULL COMMENT '申请单电话',"
            "`Shenqingdan_b_pic_quality` varchar(64) DEFAULT NULL COMMENT '图片质量判定',"
            "`Shenqingdan_b_chepai` varchar(64) DEFAULT NULL COMMENT '申请表车牌号判定',"
            "`Shenqingdan_b_qianming` varchar(64) DEFAULT NULL COMMENT '申请表签名判定',"
            "`Huanbaodan_table` varchar(64) DEFAULT NULL COMMENT '环保单图片的表格位置',"
            "`Huanbaodan_chepai` varchar(64) DEFAULT NULL COMMENT '环保单图片的车牌位置',"
            "`Huanbaodan_chejiahao` varchar(64) DEFAULT NULL COMMENT '环保单图片的车架号位置',"
            "`Huanbaodan_yinzhang` varchar(64) DEFAULT NULL COMMENT '环保单图片的印章位置',"
            "`Huanbaodan_qianzi` varchar(64) DEFAULT NULL COMMENT '环保单图片的签字位置',"
            "`Huanbaodan_jiancejielun` varchar(64) DEFAULT NULL COMMENT '环保单图片的检测结论位置',"
            "`Huanbaodan_b_jiancejielun` varchar(64) DEFAULT NULL COMMENT '环保单图片检测结论合格',"
            "`Huanbaodan_b_chepai` varchar(64) DEFAULT NULL COMMENT '环保单车牌检查合格',"
            "`Huanbaodan_b_chejiahao` varchar(64) DEFAULT NULL COMMENT '环保单图片车架号合格',"
            "`Huanbaodan_b_yinzhang` varchar(64) DEFAULT NULL COMMENT '环保单印章检查合格',"
            "`Huanbaodan_b_qianzi` varchar(64) DEFAULT NULL COMMENT '环保单签字检查合格',"
            "`Jianyanbiao_table` varchar(64) DEFAULT NULL COMMENT '检验表表格',"
            "`Jianyanbiao_rect1` varchar(64) DEFAULT NULL COMMENT '签名1',"
            "`Jianyanbiao_rect2` varchar(64) DEFAULT NULL COMMENT '签名2',"
            "`Jianyanbiao_rect3` varchar(64) DEFAULT NULL COMMENT '签名3',"
            "`Jianyanbiao_b_jianyanbiao` varchar(64) DEFAULT NULL COMMENT '检验表是否合格',"
            "`Jianyanbiao_b_waiguan_sign` varchar(64) DEFAULT NULL COMMENT '外观签名是否存在',"
            "`Jianyanbiao_b_yinche_sign` varchar(64) DEFAULT NULL COMMENT '引车签名是否存在',"
            "`Jianyanbiao_b_dipan_sign` varchar(64) DEFAULT NULL COMMENT '底盘签名是否存在',"
            "`Dengguang_chepai` varchar(64) DEFAULT NULL COMMENT '车牌位置',"
            "`Dengguang_leftRt` varchar(64) DEFAULT NULL COMMENT '右灯位置',"
            "`Dengguang_rightRt` varchar(64) DEFAULT NULL COMMENT '左灯位置',"
            "`Dengguang_chepai_2` varchar(64) DEFAULT NULL COMMENT '车牌2位置',"
            "`Dengguang_leftRt_2` varchar(64) DEFAULT NULL COMMENT '左灯2位置',"
            "`Dengguang_rightRt_2` varchar(64) DEFAULT NULL COMMENT '右灯2位置',"
            "`Dengguang_b_light_on` varchar(64) DEFAULT NULL COMMENT '制动尾灯是否亮起',"
            "`Dengguang_b_chepai` varchar(64) DEFAULT NULL COMMENT '制动尾灯是否亮起',"
            "`Zhidong_chepai` varchar(64) DEFAULT NULL COMMENT '车牌位置',"
            "`Zhidong_chepai_2` varchar(64) DEFAULT NULL COMMENT '车牌2位置',"
            "`Zhidong_b_zhidong` varchar(64) DEFAULT NULL COMMENT '一轴二轴/平板制动是否合格',"
            "`Zhidong_b_chepai` varchar(64) DEFAULT NULL COMMENT '车牌比对是否正确',"
            "`Dipandongtai_chepai_1` varchar(64) DEFAULT NULL COMMENT '车牌位置1',"
            "`Dipandongtai_chepai_2` varchar(64) DEFAULT NULL COMMENT '车牌位置2',"
            "`Dipandongtai_b_move` varchar(64) DEFAULT NULL COMMENT '车辆是否发生位移',"
            "`Dipandongtai_b_chepai` varchar(64) DEFAULT NULL COMMENT '车牌检测',"
            "`Dipandongtai_date_stamp` varchar(128) DEFAULT NULL COMMENT '水印日期',"
            "`Dipan_chepai` varchar(64) DEFAULT NULL COMMENT '车牌位置',"
            "`Dipan_b_dipan` varchar(64) DEFAULT NULL COMMENT '车辆底盘是否在工位上',"
            "`Dipan_b_chepai` varchar(64) DEFAULT NULL COMMENT '车牌比对是否正确',"
            "`Dipan_date_stamp` varchar(128) DEFAULT NULL COMMENT '水印日期',"
            "`conclusion` varchar(256) DEFAULT NULL COMMENT '检验结论',"
            "PRIMARY KEY (`id`),"
            "KEY `link_vehicle_check` (`vehicle_check_id`),"
            "CONSTRAINT `link_vehicle_check` FOREIGN KEY (`vehicle_check_id`) REFERENCES `vehicle_checks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE"
            ")";

    if (!db.createTable("vehicle_checks_demo_test", sqlString.c_str())) {
        return false;
    }

    sqlString =
            "("
            "`id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',"
            "`jylsh` varchar(64) DEFAULT NULL COMMENT '检验流水号',"
            "`jyjgbh` varchar(64) DEFAULT NULL COMMENT '检验机构编号',"
            "`hphm` varchar(64) DEFAULT NULL COMMENT '号牌号码',"
            "`clsbdh` varchar(64) DEFAULT NULL COMMENT '车辆识别代号',"
            "`cllx` varchar(64) DEFAULT NULL COMMENT '车辆类型',"
            "`spzl` varchar(64) DEFAULT NULL COMMENT '视频种类',"
            "`spurl` varchar(256) DEFAULT NULL COMMENT '视频URL',"
            "`jcxbh` varchar(64) DEFAULT NULL COMMENT '检测线编号',"
            "`sxtbh` varchar(64) DEFAULT NULL COMMENT '摄像头编号',"
            "`sjks` varchar(64) DEFAULT NULL COMMENT '时间开始',"
            "`sjjs` varchar(64) DEFAULT NULL COMMENT '时间结束',"
            "PRIMARY KEY (`id`)"
            ")";

    if (!db.createTable("check_video_infos", sqlString.c_str())) {
        return false;
    }

    /* 更新当前数据库版本 */
    if (!db.update("database_version", "SET version='3' WHERE id='1'")) {
        return false;
    }

    DATA_PRINT(LEVEL_INFO, "The update of version [3] has been completed. \n");
    return true;
}

/*
数据库版本：4

内容：
表vehicle_checks增加字段is_pass
*/
bool updateDatabase_4(MySQL_DB &db)
{
    DATA_PRINT(LEVEL_INFO, "Start updating the database to version [4] ...... \n");

    std::string sqlString;
    sqlString += "ADD COLUMN `is_pass` INT(10) COMMENT '是否全部通过' AFTER `center_status`";

    if (!db.alterTable("vehicle_checks", sqlString.c_str())) {
        return false;
    }

    /* 更新当前数据库版本 */
    if (!db.update("database_version", "SET version='4' WHERE id='1'")) {
        return false;
    }

    DATA_PRINT(LEVEL_INFO, "The update of version [4] has been completed. \n");
    return true;
}

/*
数据库版本：5

内容：
针对苏州，增加电子尾气信息的记录表dz_wq。
*/
bool updateDatabase_5(MySQL_DB &db)
{
    DATA_PRINT(LEVEL_INFO, "Start updating the database to version [5] ...... \n");

    std::string sqlString;

    sqlString =
            "("
            "`id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',"
            "`hphm` varchar(32) NOT NULL COMMENT '号牌号码',"
            "`clsbdh` varchar(64) NOT NULL COMMENT '车辆识别代号',"
            "`jcrq` DATETIME NOT NULL COMMENT '检测日期',"
            "`jczmc` varchar(128) NOT NULL COMMENT '检测站名称',"
            "`jcbgbh` varchar(64) NOT NULL COMMENT '检测报告编号（或检测报告流水号）',"
            "`pass` int(10) unsigned NOT NULL COMMENT '通过1，不通过0',"
            "`created_at` DATETIME NOT NULL DEFAULT NOW() COMMENT '本行创建时间',"
            "PRIMARY KEY (`id`),"
            "KEY `index_of_search` (`clsbdh`,`hphm`)"
            ")";

    if (!db.createTable("dz_wq", sqlString.c_str())) {
        return false;
    }

    /* 更新当前数据库版本 */
    if (!db.update("database_version", "SET version='5' WHERE id='1'")) {
        return false;
    }

    DATA_PRINT(LEVEL_INFO, "The update of version [5] has been completed. \n");
    return true;
}

/*
数据库版本：6

内容：
针对保定的功能，增加3张新的表：
1. manual_pass：人工检验通过
2. manual_fail：人工检验不通过
3. inspection_report：检验报告
*/
bool updateDatabase_6(MySQL_DB &db)
{
    DATA_PRINT(LEVEL_INFO, "Start updating the database to version [6] ...... \n");

    std::string sqlString;

    sqlString =
            "("
            "`id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',"
            "`lsh` varchar(32) COMMENT '流水号',"
            "`jylsh` varchar(32) COMMENT '检验流水号',"
            "`jcxdh` varchar(32) COMMENT '检测线代号',"
            "`xh` varchar(32) COMMENT '机动车序号',"
            "`glbm` varchar(32) COMMENT '管理部门',"
            "`hphm` varchar(32) COMMENT '号牌号码',"
            "`hpzl` varchar(32) COMMENT '号牌种类',"
            "`clsbdh` varchar(32) COMMENT '车辆识别代号',"
            "`jyrq` DATETIME COMMENT '检验日期',"
            "`cyrq` DATETIME COMMENT '审核日期',"
            "`cyry` varchar(32) COMMENT '审核人员',"
            "`ztbj` varchar(32) COMMENT '状态标记',"
            "`gxrq` DATETIME COMMENT '更新日期',"
            "`jyjgbh` varchar(32) COMMENT '安检机构编号',"
            "`jczcyy` varchar(32) COMMENT '检测站查验员 身份证明号码',"
            "`fzjg` varchar(32) COMMENT '发证机关（或委托机关）',"
            "`jyw` varchar(1024) COMMENT '校验位',"
            "`azdm` varchar(32) COMMENT '检验监管系统安装点代码',"
            "`jylb` varchar(32) COMMENT '检验类别',"
            "`create_time` DATETIME NOT NULL DEFAULT NOW() COMMENT '本行创建时间',"
            "PRIMARY KEY (`id`)"
            ")";

    if (!db.createTable("manual_pass", sqlString.c_str())) {
        return false;
    }

    sqlString =
            "("
            "`id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',"
            "`lsh` varchar(32) COMMENT '流水号',"
            "`jylsh` varchar(32) COMMENT '检验流水号',"
            "`jcxdh` varchar(32) COMMENT '检测线代号',"
            "`xh` varchar(32) COMMENT '机动车序号',"
            "`glbm` varchar(32) COMMENT '管理部门',"
            "`hphm` varchar(32) COMMENT '号牌号码',"
            "`hpzl` varchar(32) COMMENT '号牌种类',"
            "`clsbdh` varchar(32) COMMENT '车辆识别代号',"
            "`jyrq` DATETIME COMMENT '检验日期',"
            "`msxx` varchar(512) COMMENT '描述信息 查验审核未通过具体原因',"
            "`cyrq` DATETIME COMMENT '审核日期',"
            "`cyry` varchar(32) COMMENT '审核人员',"
            "`hqbj` varchar(32) COMMENT '获取标记',"
            "`hqsj` DATETIME COMMENT '获取时间',"
            "`jyjgbh` varchar(32) COMMENT '安检机构编号',"
            "`fzjg` varchar(32) COMMENT '发证机关（或委托机关）',"
            "`jyw` varchar(1024) COMMENT '校验位',"
            "`wtgyy` varchar(256) COMMENT '未通过原因',"
            "`create_time` DATETIME NOT NULL DEFAULT NOW() COMMENT '本行创建时间',"
            "PRIMARY KEY (`id`)"
            ")";

    if (!db.createTable("manual_fail", sqlString.c_str())) {
        return false;
    }

    sqlString =
            "("
            "`id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',"
            "`lsh` varchar(32) COMMENT '流水号',"
            "`jylsh` varchar(32) COMMENT '检验流水号',"
            "`jyjgbh` varchar(32) COMMENT '检验机构编号',"
            "`xh` int(10) COMMENT '序号',"
            "`yqjyxm` varchar(256) COMMENT '检验项目',"
            "`yqjyjg` varchar(1024) COMMENT '检验结果',"
            "`yqbzxz` varchar(1024) COMMENT '标准限值',"
            "`yqjgpd` varchar(32) COMMENT '结果判定',"
            "`yqjybz` varchar(1024) COMMENT '备注',"
            "`gxsj` DATETIME COMMENT '更新时间',"
            "`create_time` DATETIME NOT NULL DEFAULT NOW() COMMENT '本行创建时间',"
            "PRIMARY KEY (`id`)"
            ")";

    if (!db.createTable("inspection_report", sqlString.c_str())) {
        return false;
    }

    /* 更新当前数据库版本 */
    if (!db.update("database_version", "SET version='6' WHERE id='1'")) {
        return false;
    }

    DATA_PRINT(LEVEL_INFO, "The update of version [6] has been completed. \n");
    return true;
}

/*
数据库版本：7

内容：
针对SOAP接口的新增车辆信息字段，增加表vehicle_checks的字段
*/
bool updateDatabase_7(MySQL_DB &db)
{
    DATA_PRINT(LEVEL_INFO, "Start updating the database to version [7] ...... \n");

    std::string sqlString;
    sqlString += "ADD COLUMN `yxqz` varchar(32) COMMENT '检验有效期止' AFTER `xnyzl`,";
    sqlString += "ADD COLUMN `fzjg` varchar(32) COMMENT '发证机关' AFTER `yxqz`,";
    sqlString += "ADD COLUMN `hbdbqk` varchar(128) COMMENT '环保达标情况' AFTER `fzjg`,";
    sqlString += "ADD COLUMN `qzbfqz` varchar(32) COMMENT '强制报废期止' AFTER `hbdbqk`,";
    sqlString += "ADD COLUMN `xzqh` varchar(32) COMMENT '管理辖区' AFTER `qzbfqz`,";
    sqlString += "ADD COLUMN `gcjk` varchar(32) COMMENT '国产/进口' AFTER `xzqh`,";
    sqlString += "ADD COLUMN `dybj` varchar(128) COMMENT '抵押标记' AFTER `gcjk`,";
    sqlString += "ADD COLUMN `zzg` varchar(32) COMMENT '制造国' AFTER `dybj`,";
    sqlString += "ADD COLUMN `clpp2` varchar(32) COMMENT '英文品牌' AFTER `zzg`,";
    sqlString += "ADD COLUMN `jyhgbzbh` varchar(32) COMMENT '检验合格标志' AFTER `clpp2`,";
    sqlString += "ADD COLUMN `sfmj` varchar(32) COMMENT '是否免检' AFTER `jyhgbzbh`,";
    sqlString += "ADD COLUMN `zt` varchar(32) COMMENT '机动车状态' AFTER `sfmj`,";
    sqlString += "ADD COLUMN `djrq` varchar(32) COMMENT '最近定检日期' AFTER `zt`,";
    sqlString += "ADD COLUMN `zsxzqh` varchar(32) COMMENT '住所地址行政区划' AFTER `djrq`,";
    sqlString += "ADD COLUMN `zzxzqh` varchar(32) COMMENT '联系地址行政区划' AFTER `zsxzqh`,";
    sqlString += "ADD COLUMN `fdjxh` varchar(64) COMMENT '发动机型号' AFTER `zzxzqh`,";
    sqlString += "ADD COLUMN `sgcssbwqk` varchar(2048) COMMENT '事故车损伤部位情况' AFTER `fdjxh`,";
    sqlString += "ADD COLUMN `bmjyy` varchar(2048) COMMENT '不免检原因' AFTER `sgcssbwqk`,";
    sqlString += "ADD COLUMN `glbm` varchar(32) COMMENT '管理部门' AFTER `bmjyy`,";
    sqlString += "ADD COLUMN `zzcmc` varchar(64) COMMENT '制造厂名称' AFTER `glbm`,";
    sqlString += "ADD COLUMN `jylsh2` varchar(32) COMMENT '检验流水号(real)' AFTER `zzcmc`";

    if (!db.alterTable("vehicle_checks", sqlString.c_str())) {
        return false;
    }

    /* 更新当前数据库版本 */
    if (!db.update("database_version", "SET version='7' WHERE id='1'")) {
        return false;
    }

    DATA_PRINT(LEVEL_INFO, "The update of version [7] has been completed. \n");
    return true;
}

/*
数据库版本：8

内容：
针对保定仪器检验结果数据，新增表instrument_result
*/
bool updateDatabase_8(MySQL_DB &db)
{
    DATA_PRINT(LEVEL_INFO, "Start updating the database to version [8] ...... \n");

    std::string sqlString;

    sqlString =
            "("
            "`id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',"
            "`lsh` varchar(32) COMMENT '流水号',"
            "`jylsh` varchar(32) COMMENT '检验流水号',"
            "`yi_zhou` varchar(2) COMMENT '一轴',"
            "`er_zhou` varchar(2) COMMENT '二轴',"
            "`san_zhou` varchar(2) COMMENT '三轴',"
            "`si_zhou` varchar(2) COMMENT '四轴',"
            "`wu_zhou` varchar(2) COMMENT '五轴',"
            "`zheng_che` varchar(2) COMMENT '整车',"
            "`zhu_che` varchar(2) COMMENT '驻车',"
            "`zwd` varchar(2) COMMENT '左外灯',"
            "`znd` varchar(2) COMMENT '左内灯',"
            "`ynd` varchar(2) COMMENT '右内灯',"
            "`ywd` varchar(2) COMMENT '右外灯',"
            "`csb` varchar(2) COMMENT '车速表',"
            "`ch` varchar(2) COMMENT '侧滑',"
            "`create_time` DATETIME NOT NULL DEFAULT NOW() COMMENT '本行创建时间',"
            "PRIMARY KEY (`id`)"
            ")";

    if (!db.createTable("instrument_result", sqlString.c_str())) {
        return false;
    }

    /* 更新当前数据库版本 */
    if (!db.update("database_version", "SET version='8' WHERE id='1'")) {
        return false;
    }

    DATA_PRINT(LEVEL_INFO, "The update of version [8] has been completed. \n");
    return true;
}


/*
数据库版本：9

内容：
苏州电子保单结果判定，新增表suzhou_dzbd
*/
bool updateDatabase_9(MySQL_DB &db)
{
    DATA_PRINT(LEVEL_INFO, "Start updating the database to version [9] ...... \n");

    std::string sqlString;

    sqlString =
            "("
            "`id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',"
            "`jylsh` varchar(32) COMMENT '检验流水号',"
            "`hphm` varchar(32) COMMENT '号牌号码',"
            "`jyjgbh` varchar(32) COMMENT '检验机构编号',"
            "`clsbdh` varchar(32) COMMENT '车辆识别代号',"
            "`hpzl` varchar(32) COMMENT '号牌种类',"
            "`dzjl` varchar(32) COMMENT '电子结论',"
            "`dzyy` varchar(32) COMMENT '电子原因',"
            "`hfxx` varchar(512) COMMENT '回复信息',"
            "`create_time` DATETIME NOT NULL DEFAULT NOW() COMMENT '本行创建时间',"
            "PRIMARY KEY (`id`)"
            ")";

    if (!db.createTable("suzhou_dzbd", sqlString.c_str())) {
        return false;
    }

    /* 更新当前数据库版本 */
    if (!db.update("database_version", "SET version='9' WHERE id='1'")) {
        return false;
    }

    DATA_PRINT(LEVEL_INFO, "The update of version [9] has been completed. \n");
    return true;
}

/*
数据库版本：10

内容：
根据保定新增功能，增加3张表：
1. manual_summary人工审核结果汇总
2. manual_fail_detail人工审核不通过详细
3. machine_manual机器和人工结果对比
*/
bool updateDatabase_10(MySQL_DB &db)
{
    DATA_PRINT(LEVEL_INFO, "Start updating the database to version [10] ...... \n");

    std::string sqlString;

    sqlString =
            "("
            "`id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',"
            "`lsh` varchar(32) COMMENT '流水号',"
            "`xsz` int(10) unsigned NOT NULL COMMENT '机动车行驶证',"
            "`sqb` int(10) unsigned NOT NULL COMMENT '机动车牌证申请表',"
            "`jqx` int(10) unsigned NOT NULL COMMENT '机动车交通事故责任强制保险凭证',"
            "`jybg` int(10) unsigned NOT NULL COMMENT '机动车安全技术检验报告单',"
            "`zqf` int(10) unsigned NOT NULL COMMENT '车辆左前方斜视45度照片',"
            "`yhf` int(10) unsigned NOT NULL COMMENT '车辆右后方斜视45度照片',"
            "`cjh` int(10) unsigned NOT NULL COMMENT '车辆识别代号照片',"
            "`aqd` int(10) unsigned NOT NULL COMMENT '驾驶人座椅汽车安全带',"
            "`zdg` int(10) unsigned NOT NULL COMMENT '左灯光工位照片',"
            "`ydg` int(10) unsigned NOT NULL COMMENT '右灯光工位照片',"
            "`zczd` int(10) unsigned NOT NULL COMMENT '驻车制动工位照片',"
            "`cyjl` int(10) unsigned NOT NULL COMMENT '机动车查验记录表',"
            "`wrw` int(10) unsigned NOT NULL COMMENT '污染物检测报告',"
            "`dpjy` int(10) unsigned NOT NULL COMMENT '底盘检验照片',"
            "`yzzd` int(10) unsigned NOT NULL COMMENT '一轴制动工位照片',"
            "`ezzd` int(10) unsigned NOT NULL COMMENT '二轴制动工位照片',"
            "`result` int(10) unsigned NOT NULL COMMENT '审核结果',"
            "`shry` varchar(64) COMMENT '审核人员姓名',"
            "`sjjg` varchar(128) COMMENT '审核人员所属上级机构',"
            "`manual_time` DATETIME COMMENT '人工审核时间',"
            "`create_time` DATETIME NOT NULL DEFAULT NOW() COMMENT '本行创建时间',"
            "KEY `index_lsh` (`lsh`),"
            "PRIMARY KEY (`id`)"
            ")";

    if (!db.createTable("manual_summary", sqlString.c_str())) {
        return false;
    }

    sqlString =
            "("
            "id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT '主键',"
            "manual_summary_id INT UNSIGNED NOT NULL COMMENT '外键，连接manual_summary的主键',"
            "`picture_code` int(10) unsigned NOT NULL COMMENT '六位未通过照片代码',"
            "`create_time` DATETIME NOT NULL DEFAULT NOW() COMMENT '本行创建时间',"
            "CONSTRAINT `link_manual_summary` FOREIGN KEY (`manual_summary_id`) REFERENCES `manual_summary` (`id`) ON DELETE CASCADE ON UPDATE CASCADE"
            ")";

    if (!db.createTable("manual_fail_detail", sqlString.c_str())) {
        return false;
    }

    /*
        说明：下面表里的照片结果有4种值：
        0--机器通过，人工通过
        1--机器通过，人工不过
        2--机器不过，人工通过
        3--机器不过，人工不过
    */
    sqlString =
            "("
            "id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT '主键',"
            "`lsh` varchar(32) COMMENT '流水号',"
            "`xsz` int(10) unsigned NOT NULL COMMENT '机动车行驶证',"
            "`sqb` int(10) unsigned NOT NULL COMMENT '机动车牌证申请表',"
            "`jqx` int(10) unsigned NOT NULL COMMENT '机动车交通事故责任强制保险凭证',"
            "`jybg` int(10) unsigned NOT NULL COMMENT '机动车安全技术检验报告单',"
            "`zqf` int(10) unsigned NOT NULL COMMENT '车辆左前方斜视45度照片',"
            "`yhf` int(10) unsigned NOT NULL COMMENT '车辆右后方斜视45度照片',"
            "`cjh` int(10) unsigned NOT NULL COMMENT '车辆识别代号照片',"
            "`aqd` int(10) unsigned NOT NULL COMMENT '驾驶人座椅汽车安全带',"
            "`zdg` int(10) unsigned NOT NULL COMMENT '左灯光工位照片',"
            "`ydg` int(10) unsigned NOT NULL COMMENT '右灯光工位照片',"
            "`zczd` int(10) unsigned NOT NULL COMMENT '驻车制动工位照片',"
            "`cyjl` int(10) unsigned NOT NULL COMMENT '机动车查验记录表',"
            "`wrw` int(10) unsigned NOT NULL COMMENT '污染物检测报告',"
            "`dpjy` int(10) unsigned NOT NULL COMMENT '底盘检验照片',"
            "`yzzd` int(10) unsigned NOT NULL COMMENT '一轴制动工位照片',"
            "`ezzd` int(10) unsigned NOT NULL COMMENT '二轴制动工位照片',"
            "`manual_time` DATETIME COMMENT '人工审核时间',"
            "`create_time` DATETIME NOT NULL DEFAULT NOW() COMMENT '本行创建时间'"
            ")";

    if (!db.createTable("machine_manual", sqlString.c_str())) {
        return false;
    }

    /* 更新当前数据库版本 */
    if (!db.update("database_version", "SET version='10' WHERE id='1'")) {
        return false;
    }

    DATA_PRINT(LEVEL_INFO, "The update of version [10] has been completed. \n");
    return true;
}

/*
数据库版本：11

内容：
表manual_fail_detail的字段picture_code由int改为varchar
*/
bool updateDatabase_11(MySQL_DB &db)
{
    DATA_PRINT(LEVEL_INFO, "Start updating the database to version [11] ...... \n");

    std::string sqlString;
    sqlString = "CHANGE COLUMN `picture_code` `picture_code` VARCHAR(16) NOT NULL COMMENT '六位未通过照片代码'";

    if (!db.alterTable("manual_fail_detail", sqlString.c_str())) {
        return false;
    }

    /* 更新当前数据库版本 */
    if (!db.update("database_version", "SET version='11' WHERE id='1'")) {
        return false;
    }

    DATA_PRINT(LEVEL_INFO, "The update of version [11] has been completed. \n");
    return true;
}

/*
数据库版本：12

内容：
表machine_manual增加两个字段
shry,审核人员
glbm,管理部门
*/
bool updateDatabase_12(MySQL_DB &db)
{
    DATA_PRINT(LEVEL_INFO, "Start updating the database to version [12] ...... \n");

    std::string sqlString;
    sqlString += "ADD COLUMN `shry` varchar(32) COMMENT '审核人员' AFTER `ezzd`,";
    sqlString += "ADD COLUMN `glbm` varchar(32) COMMENT '管理部门' AFTER `shry`";

    if (!db.alterTable("machine_manual", sqlString.c_str())) {
        return false;
    }

    /* 更新当前数据库版本 */
    if (!db.update("database_version", "SET version='12' WHERE id='1'")) {
        return false;
    }

    DATA_PRINT(LEVEL_INFO, "The update of version [12] has been completed. \n");
    return true;
}

/*
数据库版本：13

内容：
表machine_manual增加一个外键，连接到vehicle_checks的主键
*/
bool updateDatabase_13(MySQL_DB &db)
{
    DATA_PRINT(LEVEL_INFO, "Start updating the database to version [13] ...... \n");

    std::string sqlString;
    sqlString = "ADD COLUMN `vehicle_check_id` INT(10) UNSIGNED COMMENT '外键，连接vehicle_checks的主键' AFTER `id`";

    if (!db.alterTable("machine_manual", sqlString.c_str())) {
        return false;
    }

    sqlString = "ADD CONSTRAINT `link_vehicle_checks` FOREIGN KEY (`vehicle_check_id`) "
                "REFERENCES `car_schema`.`vehicle_checks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE";

    if (!db.alterTable("machine_manual", sqlString.c_str())) {
        return false;
    }

    /* 更新当前数据库版本 */
    if (!db.update("database_version", "SET version='13' WHERE id='1'")) {
        return false;
    }

    DATA_PRINT(LEVEL_INFO, "The update of version [13] has been completed. \n");
    return true;
}

/*
数据库版本：14

内容：
增加表unknown_request
用于记录未知IP发来的HTTP请求
*/
bool updateDatabase_14(MySQL_DB &db)
{
    DATA_PRINT(LEVEL_INFO, "Start updating the database to version [14] ...... \n");

    std::string sqlString;

    sqlString =
            "("
            "id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT '主键',"
            "`IP` varchar(32) COMMENT 'IP地址',"
            "`port` varchar(32) COMMENT '端口',"
            "`method` varchar(32) COMMENT '请求方法',"
            "`URI` varchar(512) COMMENT 'URI',"
            "`create_time` DATETIME NOT NULL DEFAULT NOW() COMMENT '本行创建时间'"
            ")";

    if (!db.createTable("unknown_request", sqlString.c_str())) {
        return false;
    }

    /* 更新当前数据库版本 */
    if (!db.update("database_version", "SET version='14' WHERE id='1'")) {
        return false;
    }

    DATA_PRINT(LEVEL_INFO, "The update of version [14] has been completed. \n");
    return true;
}

/*
数据库版本：15

内容：
增加表software_version
用于记录当前软件/算法版本
*/

bool updateDatabase_15(MySQL_DB &db)
{
    DATA_PRINT(LEVEL_INFO, "Start updating the database to version [15] ...... \n");

    std::string sqlString;

    sqlString = "("
            "`id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',"
            "`prog_version` varchar(64) COMMENT '当前程序版本',"
            "`alg_version` varchar(64) COMMENT '当前算法版本',"
            "`create_time` DATETIME NOT NULL DEFAULT NOW() COMMENT '本行创建时间',"
            "PRIMARY KEY (`id`)"
            ")";

    if (!db.createTable("software_version", sqlString.c_str())) {
        return false;
    }

    /* 更新当前数据库版本 */
    if (!db.update("database_version", "SET version='15' WHERE id='1'")) {
        return false;
    }

    DATA_PRINT(LEVEL_INFO, "The update of version [15] has been completed. \n");
    return true;

}

/*
数据库版本：16

内容：
增加表black_list
*/
bool updateDatabase_16(MySQL_DB &db)
{
    DATA_PRINT(LEVEL_INFO, "Start updating the database to version [16] ...... \n");

    std::string sqlString;

    sqlString = "("
            "`id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',"
            "`hphm` varchar(64) COMMENT '号牌号码',"
            "`clsbdh` varchar(64) COMMENT '车辆识别代号',"
            "`create_time` DATETIME NOT NULL DEFAULT NOW() COMMENT '本行创建时间',"
            "PRIMARY KEY (`id`)"
            ")";

    if (!db.createTable("black_list", sqlString.c_str())) {
        return false;
    }

    /* 更新当前数据库版本 */
    if (!db.update("database_version", "SET version='16' WHERE id='1'")) {
        return false;
    }

    DATA_PRINT(LEVEL_INFO, "The update of version [16] has been completed. \n");
    return true;

}

/*
数据库版本：17

内容：
表suzhou_dzbd增加字段device_id.
*/
bool updateDatabase_17(MySQL_DB &db)
{
    DATA_PRINT(LEVEL_INFO, "Start updating the database to version [17]...... \n");

    std::string sqlString;
    sqlString += "ADD COLUMN `device_id` INT(10) UNSIGNED COMMENT '设备ID' AFTER `hfxx`";

    if (!db.alterTable("suzhou_dzbd", sqlString.c_str())) {
        return false;
    }

    /* 更新当前数据库版本 */
    if (!db.update("database_version", "SET version='17' WHERE id='1'")) {
        return false;
    }

    DATA_PRINT(LEVEL_INFO, "The update of version [17] has been completed. \n");
    return true;
}


/*
数据库版本：18

内容：
增加表 suzhou_3rd_general_info 第三方上传的轮胎基本信息.
增加表 suzhou_3rd_photo_info 第三方上传的轮胎基本信息.
*/
bool updateDatabase_18(MySQL_DB &db)
{
    DATA_PRINT(LEVEL_INFO, "Start updating the database to version [18] ...... \n");

    std::string sqlString = "(";
    sqlString += "id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT '主键',";  /* 1 */
    sqlString += "lsh VARCHAR(64) COMMENT '流水号',";                            /* 2 */
    sqlString += "jylsh VARCHAR(64) COMMENT '检验流水号',";               /* 3 */
    sqlString += "cllx VARCHAR(64) COMMENT '车辆类型',";                  /* 4 */
    sqlString += "hphm VARCHAR(64) COMMENT '号牌号码',";                  /* 5 */ // 号牌号码(带汉字，完整车牌，例如：苏E12345)
    sqlString += "sbdh VARCHAR(64) COMMENT '识别代号',";                  /* 6 */
    sqlString += "hdzk VARCHAR(64) COMMENT '核定载客',";                  /* 7 */
    sqlString += "ltgg VARCHAR(128) COMMENT '轮胎规格',";                 /* 8 */
    sqlString += "lts VARCHAR(64) COMMENT '轮胎数',";                     /* 9 */
    sqlString += "created_at DATETIME COMMENT '本行创建时间',";
    sqlString += "KEY `index_lsh` (`lsh`)";
    sqlString += ")";
    if (!db.createTable("suzhou_3rd_general_info", sqlString.c_str())) {
        return false;
    }

    sqlString = "(";
    sqlString += "id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT '主键',";  /* 1 */
    sqlString += "lsh VARCHAR(128) COMMENT '流水号',";                               /* 2 */
    sqlString += "zpzl VARCHAR(32) COMMENT '照片种类',";                    /* 3 */
    sqlString += "zplj VARCHAR(128) COMMENT '照片路径',";                   /* 4 */
    sqlString += "result INT(10) UNSIGNED NULL DEFAULT 0 COMMENT '结果',"; /* 5 */
    sqlString += "reason VARCHAR(128) COMMENT '照片结果描述',";              /* 6 */
    sqlString += "created_at DATETIME COMMENT '本行创建时间',";              /* 7 */
    sqlString += "KEY `index_lsh` (`lsh`)";
    sqlString += ")";
    if (!db.createTable("suzhou_3rd_photo_info", sqlString.c_str())) {
        return false;
    }

    /* 更新当前数据库版本 */
    if (!db.update("database_version", "SET version='18' WHERE id='1'")) {
        return false;
    }

    DATA_PRINT(LEVEL_INFO, "The update of version [18] has been completed. \n");
    return true;
}

/*
数据库版本：19

内容：
表check_infos的字段name长度由128增加到256
*/
bool updateDatabase_19(MySQL_DB &db)
{
    DATA_PRINT(LEVEL_INFO, "Start updating the database to version [19]...... \n");

    std::string sqlString;
    sqlString += "CHANGE COLUMN `name` `name` VARCHAR(256) NULL DEFAULT NULL COMMENT '文件名'";

    if (!db.alterTable("check_infos", sqlString.c_str())) {
        return false;
    }

    /* 更新当前数据库版本 */
    if (!db.update("database_version", "SET version='19' WHERE id='1'")) {
        return false;
    }

    DATA_PRINT(LEVEL_INFO, "The update of version [19] has been completed. \n");
    return true;
}

/*
数据库版本：20

内容：
表software_version增加字段prog_city，alg_city
*/

bool updateDatabase_20(MySQL_DB &db)
{
     DATA_PRINT(LEVEL_INFO, "Start updating the database to version [20]...... \n");

     std::string sqlString;
     sqlString += "ADD COLUMN `prog_city` VARCHAR(10) COMMENT '软件城市代码' AFTER `prog_version`,";
     sqlString += "ADD COLUMN `alg_city`  VARCHAR(10) COMMENT '算法城市代码' AFTER `alg_version`";

     if (!db.alterTable("software_version", sqlString.c_str())) {
         return false;
     }

     /* 更新当前数据库版本 */
     if (!db.update("database_version", "SET version='20' WHERE id='1'")) {
         return false;
     }

     DATA_PRINT(LEVEL_INFO, "The update of version [20] has been completed. \n");
     return true;
}

/*
数据库版本：21

内容：
增加苏州外地车历史照片表suzhou_history_photo
*/
bool updateDatabase_21(MySQL_DB &db)
{
    DATA_PRINT(LEVEL_INFO, "Start updating the database to version [21]...... \n");

    std::string sqlString;
    sqlString = "(";
    sqlString += "id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT '主键',";
    sqlString += "lsh VARCHAR(32) COMMENT '流水号',";
    sqlString += "jylb VARCHAR(32) COMMENT '检验类别',";
    sqlString += "syxz VARCHAR(32) COMMENT '使用性质',";
    sqlString += "clsbdh VARCHAR(32) COMMENT '车辆识别代号',";
    sqlString += "fzjg VARCHAR(32) COMMENT '发证机构',";
    sqlString += "hphm VARCHAR(32) COMMENT '号牌号码',";
    sqlString += "hpzl VARCHAR(32) COMMENT '号牌种类',";
    sqlString += "clpp1 VARCHAR(64) COMMENT '中文品牌',";
    sqlString += "clxh VARCHAR(128) COMMENT '车辆型号',";
    sqlString += "cllx VARCHAR(32) COMMENT '车辆类型',";
    sqlString += "zqf_path VARCHAR(256) COMMENT '左前方照片',";
    sqlString += "yhf_path VARCHAR(256) COMMENT '右后方照片',";
    sqlString += "cjh_path VARCHAR(256) COMMENT '车架号照片',";
    sqlString += "shjssj DATETIME NOT NULL COMMENT '审核结束时间',";
    sqlString += "record_time DATETIME NOT NULL DEFAULT NOW() COMMENT '本行数据记录时间',";
    sqlString += "KEY `index_lsh` (`lsh`),";
    sqlString += "KEY `index_clsbdh` (`clsbdh`),";
    sqlString += "KEY `index_fzjg` (`fzjg`),";
    sqlString += "KEY `index_hphm` (`hphm`),";
    sqlString += "KEY `index_shjssj` (`shjssj`),";
    sqlString += "KEY `index_record_time` (`record_time`),";
    sqlString += "KEY `index_cp` (`fzjg`,`hphm`)";
    sqlString += ") ";
    sqlString += "comment = '苏州外地车历史照片表'";

    if (!db.createTable("suzhou_history_photo", sqlString.c_str())) {
        return false;
    }

    /* 更新当前数据库版本 */
    if (!db.update("database_version", "SET version='21' WHERE id='1'")) {
        return false;
    }

    DATA_PRINT(LEVEL_INFO, "The update of version [21] has been completed. \n");
    return true;
}


bool updateDatabase_22(MySQL_DB &db)
{
    DATA_PRINT(LEVEL_INFO, "Start updating the database to version [22]...... \n");

    std::string sqlString;
    sqlString += "ADD COLUMN `check_flag` VARCHAR(10) COMMENT '检测标记' AFTER `sjjs`,";
    sqlString += "ADD COLUMN `check_time` DATETIME COMMENT '检测时间' AFTER `check_flag`,";
    sqlString += "ADD COLUMN `created_time` DATETIME NOT NULL DEFAULT NOW() COMMENT '创建时间' AFTER `check_time`";

    if (!db.alterTable("check_video_infos", sqlString.c_str())) {
        return false;
    }

    /* 更新当前数据库版本 */
    if (!db.update("database_version", "SET version='22' WHERE id='1'")) {
        return false;
    }

    DATA_PRINT(LEVEL_INFO, "The update of version [22] has been completed. \n");
    return true;
}

bool updateDatabase_23(MySQL_DB &db)
{
     DATA_PRINT(LEVEL_INFO, "Start updating the database to version [23]...... \n");

     std::string sqlString;
     sqlString += "ADD COLUMN `xszbk_process`  INT UNSIGNED COMMENT '行驶证背面'   AFTER `yhl_process`,";
     sqlString += "ADD COLUMN `jyb_bk_process` INT UNSIGNED COMMENT '检验表背面'   AFTER `xszbk_process`,";
     sqlString += "ADD COLUMN `wts_process`    INT UNSIGNED COMMENT '委托书'      AFTER `jyb_bk_process`,";
     sqlString += "ADD COLUMN `zqfcf_process`  INT UNSIGNED COMMENT '左前方触发'   AFTER `wts_process`,";
     sqlString += "ADD COLUMN `yhfcf_process`  INT UNSIGNED COMMENT '右后方触发'   AFTER `zqfcf_process`,";
     sqlString += "ADD COLUMN `cjhcf_process`  INT UNSIGNED COMMENT '车架号触发'   AFTER `yhfcf_process`,";
     sqlString += "ADD COLUMN `wszm_process`   INT UNSIGNED COMMENT  '完税证明'    AFTER  `cjhcf_process`,";
     sqlString += "ADD COLUMN `wttzs_process`  INT UNSIGNED COMMENT '委托通知书'   AFTER `wszm_process`,";
     sqlString += "ADD COLUMN `jyhgzm_process` INT UNSIGNED COMMENT '检验机构证明'  AFTER `wttzs_process`,";
     sqlString += "ADD COLUMN `hdzk_process`   INT UNSIGNED COMMENT   '核定载客'   AFTER `jyhgzm_process`,";
     sqlString += "ADD COLUMN `dchw_process`   INT UNSIGNED COMMENT   '大车花纹'   AFTER `hdzk_process`,";

     sqlString += "ADD COLUMN `sfz_process`    INT UNSIGNED COMMENT '身份证' AFTER `dchw_process`,";
     sqlString += "ADD COLUMN `sfzbk_process`  INT UNSIGNED COMMENT '身份证背面' AFTER `sfz_process`,";
     sqlString += "ADD COLUMN `jcqxbg_process` INT UNSIGNED COMMENT '曲线报告'   AFTER `sfzbk_process`,";
     sqlString += "ADD COLUMN `chexiang_process` INT UNSIGNED COMMENT '车厢'    AFTER `jcqxbg_process`,";
     sqlString += "ADD COLUMN `cjh_ug_process` INT UNSIGNED COMMENT '车架号UG'  AFTER `chexiang_process`,";
     sqlString += "ADD COLUMN `chgw_process`   INT UNSIGNED COMMENT '侧滑工位'  AFTER `cjh_ug_process`,";
     sqlString += "ADD COLUMN `waikuoqianmian_process`  INT UNSIGNED COMMENT '外廓前面'   AFTER `chgw_process`,";
     sqlString += "ADD COLUMN `waikuocemian_process`    INT UNSIGNED COMMENT  '外廓侧面'     AFTER  `waikuoqianmian_process`,";
     sqlString += "ADD COLUMN `wxnb_process`   INT UNSIGNED COMMENT '尾箱内部'   AFTER `waikuocemian_process`,";
     sqlString += "ADD COLUMN `fzzd_process`  INT UNSIGNED COMMENT '辅助制动'  AFTER `wxnb_process`,";
     sqlString += "ADD COLUMN `abs_process`   INT UNSIGNED COMMENT   '防抱死系统'     AFTER `fzzd_process`,";
     sqlString += "ADD COLUMN `clcm_process`  INT UNSIGNED COMMENT   '车辆侧面'     AFTER `abs_process`,";
     sqlString += "ADD COLUMN `cjhyj_process` INT UNSIGNED COMMENT '车架号远景' AFTER `clcm_process`,";

     sqlString += "ADD COLUMN `qhp_process`   INT UNSIGNED COMMENT   '前号牌'   AFTER `cjhyj_process`,";
     sqlString += "ADD COLUMN `hhp_process`   INT UNSIGNED COMMENT   '后号牌'   AFTER `qhp_process`,";
     sqlString += "ADD COLUMN `clbm_process`  INT UNSIGNED COMMENT   '车辆后面' AFTER `hhp_process`,";
     sqlString += "ADD COLUMN `dchp_process`  INT UNSIGNED COMMENT   '大车号牌' AFTER `clbm_process`";


     if (!db.alterTable("time_infos", sqlString.c_str())) {
         return false;
     }

     /* 更新当前数据库版本 */
     if (!db.update("database_version", "SET version='23' WHERE id='1'")) {
         return false;
     }

     DATA_PRINT(LEVEL_INFO, "The update of version [23] has been completed. \n");
     return true;
}


bool updateDatabase_24(MySQL_DB &db)
{
    DATA_PRINT(LEVEL_INFO, "Start updating the database to version [24]...... \n");

    std::string sqlString;

    sqlString += "ADD COLUMN `vehicle_check_id` INT UNSIGNED COMMENT '外键，连接vehicle_checks的主键' AFTER `id`,";
    sqlString += "ADD COLUMN `localpath`  VARCHAR(128) COMMENT   '本地路径' AFTER `sjjs`,";
    sqlString += "ADD COLUMN `result`  VARCHAR(10) COMMENT   '检测结果' AFTER `localpath`,";
    sqlString += "ADD COLUMN `reason`  VARCHAR(128) COMMENT   '原因' AFTER `result`,";
    sqlString += "CHANGE COLUMN `check_time` `check_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '检测时间'";
    if (!db.alterTable("check_video_infos", sqlString.c_str())) {
        DATA_PRINT(LEVEL_INFO, "The update of check_video_infos's version [24]   has been defeated. \n");
        return false;
    }

    sqlString = "ADD COLUMN `is_video_check` VARCHAR(10) COMMENT '视频检测状况' AFTER `jylsh2`";

    if (!db.alterTable("vehicle_checks", sqlString.c_str())) {
        DATA_PRINT(LEVEL_INFO, "The update of vehicle_checks's version [24]   has been defeated. \n");
        return false;
    }

    /* 更新当前数据库版本 */
    if (!db.update("database_version", "SET version='24' WHERE id='1'")) {
        return false;
    }

    DATA_PRINT(LEVEL_INFO, "The update of version [24] has been completed. \n");
    return true;
}
/*
    数据库更新25
    增加recv_carinfo表，记录接收车辆信息
*/
bool updateDatabase_25(MySQL_DB & db)
{
    DATA_PRINT(LEVEL_INFO,"Start updating the database to version [25]...... \n");

    std::string sqlString;
    sqlString += "(";
    sqlString += "id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT '主键',";
    sqlString += "jylsh      VARCHAR(64) COMMENT '检验流水号',";
    sqlString += "hphm       VARCHAR(32) COMMENT '号牌号码',";
    sqlString += "clsbdh     VARCHAR(64) COMMENT '车辆识别代号',";
    sqlString += "device_id  INT UNSIGNED COMMENT '设备编号',";
    sqlString += "IP         VARCHAR(64) COMMENT '设备IP',";
    sqlString += "created_at DATETIME NOT NULL DEFAULT NOW() COMMENT '创建时间',";
    sqlString += "KEY `index_jylsh` (`jylsh`),";
    sqlString += "KEY `index_hphm` (`hphm`),";
    sqlString += "KEY `index_clsbdh` (`clsbdh`),";
    sqlString += "KEY `index_created_at` (`created_at`)";
    sqlString += ")";

    if (!db.createTable("recv_carinfo", sqlString.c_str())) {
        return false;
    }

    /* 更新当前数据库版本 */
    if (!db.update("database_version", "SET version='25' WHERE id='1'")) {
        return false;
    }

    DATA_PRINT(LEVEL_INFO, "The update of version [25] has been completed. \n");
    return true;


}

/*
数据库版本：26

内容：
表suzhou_3rd_general_info和suzhou_3rd_photo_info增加字段device_id.
*/
bool updateDatabase_26(MySQL_DB &db)
{
    DATA_PRINT(LEVEL_INFO, "Start updating the database to version [26]...... \n");

    std::string sqlString;
    sqlString += "ADD COLUMN `device_id` INT(10) UNSIGNED COMMENT '设备ID' AFTER `created_at`";
    if (!db.alterTable("suzhou_3rd_photo_info", sqlString.c_str())) {
        return false;
    }

    sqlString += ",ADD COLUMN `ispass` INT(10) UNSIGNED COMMENT '整车结果' AFTER `device_id`";
    if (!db.alterTable("suzhou_3rd_general_info", sqlString.c_str())) {
        return false;
    }

    if (g_CheckItem.City == SUZHOU) {
        sqlString = "ADD COLUMN `machine_pass` INT(10) UNSIGNED DEFAULT 0 COMMENT '机器结果' AFTER `ispass`";
        if (!db.alterTable("suzhou_3rd_general_info", sqlString.c_str())) {
            return false;
        }
    }

    /* 更新当前数据库版本 */
    if (!db.update("database_version", "SET version='26' WHERE id='1'")) {
        return false;
    }

    DATA_PRINT(LEVEL_INFO, "The update of version [26] has been completed. \n");
    return true;
}
