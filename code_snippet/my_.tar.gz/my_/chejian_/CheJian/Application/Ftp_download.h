#ifndef _FTP_DOWNLOAD_
#define _FTP_DOWNLOAD_

#include <string>
#include <ctime>
#include <vector>


using namespace std;
class FtpClient {
public:
	bool ftpdownload(string url, string filename);
	string encode(std::string data);
private:
	
};

#endif // _FTP_DOWNLOAD_
