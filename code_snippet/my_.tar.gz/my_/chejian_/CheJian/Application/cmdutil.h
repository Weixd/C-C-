#ifndef CMDUTIL_H
#define CMDUTIL_H

#include <stdarg.h>
#include <cstring>
#include <vector>
#ifdef __GNUC__
#include <stdint.h>
#include <inttypes.h>
#endif

#if defined(WIN32) && _MSC_VER >= 1700
#include <stdint.h>
#include <inttypes.h>
#endif

class BaseType
{
public:
    BaseType(bool bFix,int32_t bufLen=-1,char* bufPtr=NULL)
    {
        bFix_=bFix;
        bufLen_=bufLen;
        bufPtr_=bufPtr;
    }
    bool operator == (BaseType &var)
    {
        bool bRet=true;
        char* p1=bufPtr_;
        char* p2=var.bufPtr_;
        for (int32_t i=0; i<bufLen_; i++)
        {
            if (p1[i] != p2[i])
            {
                bRet=false;
                break;
            }
        }
        return bRet;
    }
    virtual char* PopBuf(char* ptr)
    {
        if (bFix_)
        {
            bufPtr_ =ptr;
        }
        else
        {
            bufLen_ =*(reinterpret_cast<int32_t*>(ptr));
            ptr = ptr + sizeof( int32_t);
            bufPtr_=ptr;
        }
        return (ptr+bufLen_);
    }
    virtual char* PushBuf(char* ptr,int &len)
    {
        if (bFix_)
        {
            memcpy(ptr,bufPtr_,bufLen_);
            len +=bufLen_;
        }
        else
        {
            *((int32_t*)ptr) = bufLen_;
            ptr += sizeof( int32_t);
            len += sizeof( int32_t);
            memcpy(ptr,bufPtr_,bufLen_);
            len +=bufLen_;
        }
        return (ptr+bufLen_);
    }
public:
    char*       bufPtr_;
    int32_t     bufLen_;
    bool        bFix_;
};

#define DEF_FIX_TYPE_CLASS(CLS_NAME,INNER_TYPE)\
class CLS_NAME : public BaseType\
{\
    public:\
    CLS_NAME():BaseType(true,sizeof(INNER_TYPE)){}\
    void SetValue(INNER_TYPE* val)\
    {\
        bufPtr_=(char*)val;\
    }\
    INNER_TYPE GetValue()\
    {\
        return *(INNER_TYPE*)bufPtr_;\
    }\
};

#define DEF_BLOCK_TYPE_CLASS(CLS_NAME)\
class CLS_NAME : public BaseType\
{\
    public:\
    CLS_NAME():BaseType(false){}\
    void SetValue(char* val,int32_t vlen)\
    {\
        bufPtr_=(char*)val;\
        bufLen_=vlen;\
    }\
    char* GetValuePtr()\
    {\
        return bufPtr_;\
    }\
    int32_t GetValueLen()\
    {\
        return bufLen_;\
    }\
};

#define DEF_STRING_TYPE_CLASS(CLS_NAME)\
class CLS_NAME : public BaseType\
{\
    public:\
    CLS_NAME():BaseType(false){}\
    void SetValue(char* val)\
    {\
        bufPtr_=(char*)val;\
        bufLen_=strlen(val)+1;\
    }\
    char* GetValuePtr()\
    {\
        bufPtr_[bufLen_-1]='\0';\
        return bufPtr_;\
    }\
    int32_t GetValueLen()\
    {\
        return bufLen_-1;\
    }\
};

DEF_FIX_TYPE_CLASS(NInt8,int8_t)
DEF_FIX_TYPE_CLASS(NInt16,int16_t)
DEF_FIX_TYPE_CLASS(NInt32,int32_t)
DEF_FIX_TYPE_CLASS(NInt64,int64_t)
DEF_FIX_TYPE_CLASS(NUInt8,uint8_t)
DEF_FIX_TYPE_CLASS(NUInt16,uint16_t)
DEF_FIX_TYPE_CLASS(NUInt32,uint32_t)
DEF_FIX_TYPE_CLASS(NUInt64,uint64_t)
DEF_STRING_TYPE_CLASS(NString)
DEF_BLOCK_TYPE_CLASS(NBlock)

class BaseCmd
{
public:
    BaseCmd () : cmdId_(-1)
    { }
    virtual ~BaseCmd()
    { }
public:
    void Create(char* ptr, int& len)
    {
        len=0;
        char* p=(char*)(ptr+sizeof(int32_t));
        *(int8_t*)p=cmdId_;
        p+=sizeof(int8_t);
        for (auto var:vars_)
            var->PushBuf((char*)(p+len),len);
        len+=sizeof(int8_t);
        (*(int32_t*)ptr)=len;
        len+=sizeof(int32_t);
    }
    bool Parse(char* ptr,int32_t len)
    {
        if (len < (sizeof(int32_t)+sizeof(int8_t)) || len!=(sizeof(int32_t)+*(int32_t*)ptr)) return false;
        char* _endPtr=ptr+len;
        char* _curPtr=ptr+sizeof(int32_t)+sizeof(int8_t);
        for (auto var:vars_)
        {
            _curPtr=var->PopBuf(_curPtr);
            if(_curPtr > _endPtr) return false;
        }
        return true;
    }
    void PushVars(int8_t cmdId,int8_t varNum,...)
    {
        cmdId_=cmdId;
        va_list ap;
        va_start ( ap, varNum );
        for ( int i= 0; i< varNum; i++ )
            vars_.push_back(va_arg (ap, BaseType*));
        va_end(ap);
    }
public:
    static bool TestCmd(char* ptr,int32_t len)
    {
        if (len < (sizeof(int32_t)+sizeof(int8_t)) || len!=(sizeof(int32_t)+*(int32_t*)ptr)) return false;
        return true;
    }
    static int8_t ParseCmdId(char* ptr)
    {
        return *(int8_t*)(ptr+sizeof(int32_t));
    }
private:
    std::vector<BaseType*> vars_;
    int8_t cmdId_;
};

#endif
