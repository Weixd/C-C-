#include "LocalPicTest.h"

#include <unistd.h>
#include <dirent.h>
#include <string.h>
#include <iostream>
#include "trace_log.h"
#include"vehicle_inf.h"
#include "BlockQueue.h"
#include "nvml.h"
#include <thread>
#include "large_vehicle_api.hpp"
#include "ResultCollection.h"
BlockingQueue<vehicle_inf *> to_local_test_queue;
vecTestResult m_vecResult;
vector<vehicle_inf*> vecVehicleInf;

extern int process_photo(vehicle_inf *pvehicle_inf, LargeVehicleApi *alg);
extern _ZhaoPianZL ZhaoPianZL;
CLocalPicTest::CLocalPicTest()
{

}

CLocalPicTest::~CLocalPicTest()
{

}

void CLocalPicTest::GetFilesName(string strDir)
{

        DIR *dir;
        struct dirent *ptr;


        if ((dir=opendir(strDir.c_str())) == NULL)
            {

            cout<<"Open dir error..." << strDir;
                    exit(1);
            }

        while ((ptr=readdir(dir)) != NULL)
        {
            if(strcmp(ptr->d_name,".")==0 || strcmp(ptr->d_name,"..")==0)    ///current dir OR parrent dir
                    continue;
            else if(ptr->d_type == 8)    ///file

            {
                vehicle_inf *inf = NULL;
                TTestResult tTest;
                tTest.path = strDir + '/';
                tTest.path += ptr->d_name;
                DATA_PRINT(LEVEL_DEBUG, "test file path:%s \n", tTest.path.c_str());
                std::string strName = ptr->d_name;

                if(strName.find(".mp4") == string::npos)
                {
                    string::size_type nPos = strName.find_last_of(".");
                    if(nPos != string::npos)
                    {
                        strName = strName.substr(0, nPos);
                    }
                }
                char achCategory[20] = {0};
                char achHphm[20] = {0};
                sscanf(strName.c_str(), "%[^_]_%[^_]", achCategory, achHphm);
                unsigned int nIndex = 0;
                for(; nIndex < vecVehicleInf.size(); nIndex++)
                {
                    if(strcmp(vecVehicleInf[nIndex]->m_hphm.c_str(), achHphm) == 0 )
                    {
                        inf = vecVehicleInf[nIndex];
                        break;
                    }
                }
                if(nIndex == vecVehicleInf.size())
                {
                    inf = new vehicle_inf;
                }

                if(strcmp(achCategory, "0201" ) == 0)
                {

                    char achCjh[50] = {0};
                    char achTxm[50] = {0};
                    char achFzrq[50] = {0};
                    sscanf(strName.c_str(), "%[^_]_%[^_]_%[^_]_%[^_]_%s",\
                           achCategory, achHphm, achCjh, achTxm, achFzrq);
                    inf->m_hphm = achHphm;
                    inf->m_clsbdh = achCjh;
                    inf->m_xszbh = achTxm;
                    inf->m_fzrq = achFzrq;
                    cout << "achCategory:" <<achCategory << ",hphm:" << achHphm \
                         <<",cjh:" << achCjh << ",xszbh:" << achTxm << ", fzrq:" <<achFzrq << endl;
                }
                else if(strcmp(achCategory, "0203") == 0)
                {

                    char achCjh[50] = {0};
                    char achKssj[50] = {0};
                    char achJssj[50] = {0};
                    char achDqsj[50] = {0};
                    char achFdjh[50] = {0};
                    char achHdzk[50] = {0};
                    sscanf(strName.c_str(), "%[^_]_%[^_]_%[^_]_%[^_]_%[^_]_%[^_]_%[^_]_%s",\
                           achCategory, achHphm, achCjh, achKssj, achJssj, achDqsj, achFdjh, achHdzk);
                    inf->m_hphm = achHphm;
                    inf->m_clsbdh = achCjh;
                    inf->m_kssj = achKssj;
                    inf->m_jssj = achJssj;
                    inf->m_fdjh = achFdjh;
                    inf->m_hdzk = achHdzk;
                    cout << "achCategory:" <<achCategory << ",hphm:" << achHphm \
                         <<",cjh:" << achCjh << ",kssj:" << achKssj << ", jssj:" <<achJssj\
                         <<",dqsj:"<<achDqsj<<",fdjh:" << achFdjh << ",hdzk:"<< achHdzk<< endl;
                }
                else if(strcmp(achCategory, ZhaoPianZL.ZuoQianFang.c_str()) == 0 || strcmp(achCategory, ZhaoPianZL.YouHouFang.c_str()) == 0
                        || strcmp(achCategory, ZhaoPianZL.ZuoFang.c_str()) == 0)
                {

                    char achCjh[50] = {0};
                    char achClxh[50] = {0};
                    char achCllx[20] = {0};
                    char achCsys[20] = {0};
                    sscanf(strName.c_str(), "%[^_]_%[^_]_%[^_]_%[^_]_%[^_]_%s", achCategory, achHphm, achCjh, achClxh, achCllx, achCsys);
                    inf->m_hphm = achHphm;
                    inf->m_clsbdh = achCjh;
                    inf->m_clxh = achClxh;
                    inf->m_cllx = achCllx;
                    inf->m_csys = achCsys;
                    cout << "achCategory:" <<achCategory << ",hphm:" << achHphm \
                         <<",cjh:" << achCjh << ",clxh:" << achClxh << ", cllx:" <<achCllx << "csys:" << achCsys << endl;
                }
                else
                {

                    char achCjh[50] = {0};
                    sscanf(strName.c_str(), "%[^_]_%[^_]_%s", achCategory, achHphm, achCjh);
                    inf->m_hphm = achHphm;
                    inf->m_clsbdh = achCjh;
                    cout << "achCategory:" <<achCategory << ",hphm:" << achHphm \
                         <<",cjh:" << achCjh << endl;
                }

                tTest.category = achCategory;
                m_vecResult.push_back(tTest);
                if(strName.find(".mp4") == string::npos)
                {

                    _photo_resource photo;
                    photo.local_path = tTest.path;
                    photo.zptype = tTest.category;
                    inf->m_zplist.push_back(photo);
                }
                else
                {
                    _video_resource video;
                    video.local_path = tTest.path;
                    video.sptype = tTest.category;
                    video.spzl = tTest.category;
                    inf->m_splist.push_back(video);
                }

                //to_local_test_queue.Put(inf);
                unsigned int nIndex1 = 0;
                for(; nIndex1 < vecVehicleInf.size(); nIndex1++)
                {
                    if(strcmp(vecVehicleInf[nIndex1]->m_hphm.c_str(), achHphm) == 0 )
                    {
                        vecVehicleInf[nIndex1] = inf;
                        break;
                    }
                }
                if(nIndex1 == vecVehicleInf.size())
                {
                    vecVehicleInf.push_back(inf);
                }

            }

        }
        closedir(dir);
        unsigned int nIndex2 = 0;
        for(; nIndex2 < vecVehicleInf.size(); nIndex2++)
        {
           to_local_test_queue.Put(vecVehicleInf[nIndex2]);
        }
        if(vecVehicleInf.size() > 0)
        {
            vecVehicleInf.clear();
        }


}

void CLocalPicTest::DataAnalyseThread()
{

        EProjectType type = EProjectType::eJianYanType;
        LargeVehicleApi alg_api(true,0, atoi(g_CheckItem.City.c_str()),type);

        unsigned int nIndex = 0;
        unsigned int total = to_local_test_queue.Size();
        for(; nIndex < total; nIndex++)
        {

            vehicle_inf *inf = to_local_test_queue.Take();
            inf->m_cllx = "K31";
            inf->m_jylb = std::string("01");
            inf->m_syxz = std::string("A");

            process_photo(inf, &alg_api);


            unsigned int index = 0;
            for(; index < inf->m_zplist.size(); index++)
            {


                        std::string strResult = "";
                        std::string strReason = "";
                        std::string strLogo = "";

                       // 查询本文件是否在不合格列表中出现
                       unsigned int i;
                       for (i = 0; i < inf->m_dbbhglist.size(); i++) {
                           if (inf->m_zplist[index].zptype == inf->m_dbbhglist[i].zptype) {
                               strResult = inf->m_dbbhglist[i].dbresult;
                               strReason = inf->m_dbbhglist[i].dbbhg_desc;
                                cout <<"local path:"<<inf->m_zplist[index].local_path<<",index:"<< index <<",m_zplist size:"<<inf->m_zplist.size()<<",m_dbbhglist size:" << inf->m_dbbhglist.size()<< \
                                       ",result:"<<strResult <<", reason:" <<strReason <<endl;

                               break;
                           }
                       }

                       if (i == inf->m_dbbhglist.size()) {
                           strResult = "1";
                           strReason = "通过";
                           cout <<"local path:"<<inf->m_zplist[index].local_path<<",index:"<< index <<",m_zplist size:"<<inf->m_zplist.size()<<",m_dbbhglist size:" << inf->m_dbbhglist.size()<< \
                                  ",result:"<<strResult <<", reason:" <<strReason <<endl;
                       }

                unsigned int j = 0;
                for(; j < m_vecResult.size(); j++)
                {
                    if(m_vecResult[j].path == inf->m_zplist[index].local_path)
                    {
                        m_vecResult[j].result = strResult;
                        m_vecResult[j].reason = strReason;
                        if(m_vecResult[j].category == ZhaoPianZL.ZuoQianFang)
                        {
                            m_vecResult[j].logo = inf->m_strZqfCheBiao;
                        }
                        else if(m_vecResult[j].category == ZhaoPianZL.YouHouFang)
                        {
                            m_vecResult[j].logo = inf->m_strYhfCheBiao;
                        }
                        else if(m_vecResult[j].category == ZhaoPianZL.ZuoFang)
                        {
                            m_vecResult[j].logo = inf->m_strZuoFangCheBiao;
                        }
                    }
                
              }

            index = 0;
            for(; index < inf->m_splist.size(); index++)
            {


                        std::string strResult = "";
                        std::string strReason = "";

                       // 查询本文件是否在不合格列表中出现
                       unsigned int i;
                       for (i = 0; i < inf->m_dbbhglist.size(); i++) {
                           if (inf->m_splist[index].sptype == inf->m_dbbhglist[i].zptype) {
                               strResult = inf->m_dbbhglist[i].dbresult;
                               strReason = inf->m_dbbhglist[i].dbbhg_desc;
                                cout <<"local path:"<<inf->m_splist[index].local_path<<",index:"<< index <<",m_zplist size:"<<inf->m_splist.size()<<",m_dbbhglist size:" << inf->m_dbbhglist.size()<< \
                                       ",result:"<<strResult <<", reason:" <<strReason <<endl;

                               break;
                           }
                       }

                       if (i == inf->m_dbbhglist.size()) {
                           strResult = "1";
                           strReason = "通过";
                           cout <<"local path:"<<inf->m_splist[index].local_path<<",index:"<< index <<",m_zplist size:"<<inf->m_splist.size()<<",m_dbbhglist size:" << inf->m_dbbhglist.size()<< \
                                  ",result:"<<strResult <<", reason:" <<strReason <<endl;
                       }

                unsigned int j = 0;
                for(; j < m_vecResult.size(); j++)
                {
                    if(m_vecResult[j].path == inf->m_splist[index].local_path)
                    {
                        m_vecResult[j].result = strResult;
                        m_vecResult[j].reason = strReason;
                    }
                }

          }
          if(inf != NULL)
          {
              delete inf;
          }

         }

      }


}

string CLocalPicTest::Compute0111()
{
    string strPass = "";
    int n0111total = 0;
    int n0111pass = 0;
    unsigned int nIndex = 0;
    for(;nIndex < m_vecResult.size(); nIndex++)
    {
        if( m_vecResult[nIndex].category == "0111" &&
                ( m_vecResult[nIndex].result == "1" || m_vecResult[nIndex].result == "5" ) )
        {
            n0111total ++;
        }
        if( m_vecResult[nIndex].category == "0111" &&  m_vecResult[nIndex].result == "1" )
        {
            n0111pass ++;
        }
    }
    if(n0111total == 0)
    {
        strPass = "0%";
    }
    else
    {
        char achTemp[500] = "\0";
        sprintf(achTemp, "%d%%", n0111pass * 100 / n0111total);
        strPass = achTemp;
    }
    return strPass;
}

string CLocalPicTest::Compute0112()
{
    string strPass = "";
    int n0112total = 0;
    int n0112pass = 0;
    unsigned int nIndex = 0;
    for(;nIndex < m_vecResult.size(); nIndex++)
    {
        if( m_vecResult[nIndex].category == "0112" &&
                ( m_vecResult[nIndex].result == "1" || m_vecResult[nIndex].result == "5" ) )
        {
            n0112total ++;
        }
        if( m_vecResult[nIndex].category == "0112" &&  m_vecResult[nIndex].result == "1" )
        {
            n0112pass ++;
        }
    }
    if(n0112total == 0)
    {
        strPass = "0%";
    }
    else
    {
        char achTemp[500] = "\0";
        sprintf(achTemp, "%d%%", n0112pass * 100 / n0112total);
        strPass = achTemp;
    }
    return strPass;
}

string CLocalPicTest::Compute0113()
{
    string strPass = "";
    int n0113total = 0;
    int n0113pass = 0;
    unsigned int nIndex = 0;
    for(;nIndex < m_vecResult.size(); nIndex++)
    {
        if( m_vecResult[nIndex].category == "0113" &&
                ( m_vecResult[nIndex].result == "1" || m_vecResult[nIndex].result == "5" ) )
        {
            n0113total ++;
        }
        if( m_vecResult[nIndex].category == "0113" &&  m_vecResult[nIndex].result == "1" )
        {
            n0113pass ++;
        }
    }
    if(n0113total == 0)
    {
        strPass = "0%";
    }
    else
    {
        char achTemp[500] = "\0";
        sprintf(achTemp, "%d%%", n0113pass * 100 / n0113total);
        strPass = achTemp;
    }
    return strPass;
}

string CLocalPicTest::Compute0157()
{
    string strPass = "";
    int n0157total = 0;
    int n0157pass = 0;
    unsigned int nIndex = 0;
    for(;nIndex < m_vecResult.size(); nIndex++)
    {
        if( m_vecResult[nIndex].category == "0157" &&
                ( m_vecResult[nIndex].result == "1" || m_vecResult[nIndex].result == "5" ))
        {
            n0157total ++;
        }
        if( m_vecResult[nIndex].category == "0157" && m_vecResult[nIndex].result == "1" )
        {
            n0157pass ++;
        }
    }
    if(n0157total == 0)
    {
        strPass = "0%";
    }
    else
    {
        char achTemp[500] = "\0";
        sprintf(achTemp, "%d%%", n0157pass * 100 / n0157total);
        strPass = achTemp;
    }
    return strPass;
}

string CLocalPicTest::Compute0201()
{
    string strPass = "";
    int n0201total = 0;
    int n0201pass = 0;
    unsigned int nIndex = 0;
    for(;nIndex < m_vecResult.size(); nIndex++)
    {
        if( m_vecResult[nIndex].category == "0201" &&
                ( m_vecResult[nIndex].result == "1" || m_vecResult[nIndex].result == "5" ))
        {
            n0201total ++;
        }
        if( m_vecResult[nIndex].category == "0201" && m_vecResult[nIndex].result == "1" )
        {
            n0201pass ++;
        }
    }
    if(n0201total == 0)
    {
        strPass = "0%";
    }
    else
    {
        char achTemp[500] = "\0";
        sprintf(achTemp, "%d%%", n0201pass * 100 / n0201total);
        strPass = achTemp;
    }
    return strPass;
}

string CLocalPicTest::Compute0202()
{
    string strPass = "";
    int n0202total = 0;
    int n0202pass = 0;
    unsigned int nIndex = 0;
    for(;nIndex < m_vecResult.size(); nIndex++)
    {
        if( m_vecResult[nIndex].category == "0202" &&
                ( m_vecResult[nIndex].result == "1" || m_vecResult[nIndex].result == "5" ))
        {
            n0202total ++;
        }
        if( m_vecResult[nIndex].category == "0202" && m_vecResult[nIndex].result == "1" )
        {
            n0202pass ++;
        }
    }
    if(n0202total == 0)
    {
        strPass = "0%";
    }
    else
    {
        char achTemp[500] = "\0";
        sprintf(achTemp, "%d%%", n0202pass * 100 / n0202total);
        strPass = achTemp;
    }
    return strPass;
}

string CLocalPicTest::Compute0203()
{
    string strPass = "";
    int n0203total = 0;
    int n0203pass = 0;
    unsigned int nIndex = 0;
    for(;nIndex < m_vecResult.size(); nIndex++)
    {
        if( m_vecResult[nIndex].category == "0203" &&
                ( m_vecResult[nIndex].result == "1" || m_vecResult[nIndex].result == "5" ))
        {
            n0203total ++;
        }
        if( m_vecResult[nIndex].category == "0203" && m_vecResult[nIndex].result == "1" )
        {
            n0203pass ++;
        }
    }
    if(n0203total == 0)
    {
        strPass = "0%";
    }
    else
    {
        char achTemp[500] = "\0";
        sprintf(achTemp, "%d%%", n0203pass * 100 / n0203total);
        strPass = achTemp;
    }
    return strPass;
}

string CLocalPicTest::Compute0204()
{
    string strPass = "";
    int n0204total = 0;
    int n0204pass = 0;
    unsigned int nIndex = 0;
    for(;nIndex < m_vecResult.size(); nIndex++)
    {
        if( m_vecResult[nIndex].category == "0204" &&
                ( m_vecResult[nIndex].result == "1" || m_vecResult[nIndex].result == "5" ))
        {
            n0204total ++;
        }
        if( m_vecResult[nIndex].category == "0204" && m_vecResult[nIndex].result == "1" )
        {
            n0204pass ++;
        }
    }
    if(n0204total == 0)
    {
        strPass = "0%";
    }
    else
    {
        char achTemp[500] = "\0";
        sprintf(achTemp, "%d%%", n0204pass * 100 / n0204total);
        strPass = achTemp;
    }
    return strPass;
}

string CLocalPicTest::Compute0205()
{
    string strPass = "";
    int n0205total = 0;
    int n0205pass = 0;
    unsigned int nIndex = 0;
    for(;nIndex < m_vecResult.size(); nIndex++)
    {
        if( m_vecResult[nIndex].category == "0205" &&
                ( m_vecResult[nIndex].result == "1" || m_vecResult[nIndex].result == "5" ))
        {
            n0205total ++;
        }
        if( m_vecResult[nIndex].category == "0205" && m_vecResult[nIndex].result == "1" )
        {
            n0205pass ++;
        }
    }
    if(n0205total == 0)
    {
        strPass = "0%";
    }
    else
    {
        char achTemp[500] = "\0";
        sprintf(achTemp, "%d%%", n0205pass * 100 / n0205total);
        strPass = achTemp;
    }
    return strPass;
}

string CLocalPicTest::Compute0206()
{
    string strPass = "";
    int n0206total = 0;
    int n0206pass = 0;
    unsigned int nIndex = 0;
    for(;nIndex < m_vecResult.size(); nIndex++)
    {
        if( m_vecResult[nIndex].category == "0206" &&
                ( m_vecResult[nIndex].result == "1" || m_vecResult[nIndex].result == "5" ))
        {
            n0206total ++;
        }
        if( m_vecResult[nIndex].category == "0206" && m_vecResult[nIndex].result == "1" )
        {
            n0206pass ++;
        }
    }
    if(n0206total == 0)
    {
        strPass = "0%";
    }
    else
    {
        char achTemp[500] = "\0";
        sprintf(achTemp, "%d%%", n0206pass * 100 / n0206total);
        strPass = achTemp;
    }
    return strPass;
}

string CLocalPicTest::ComputeHuanBaoDan()
{
    std::string wrwhm("0209");
        // +{{ xeast 2018-06-27 majorization city code
        if(g_CheckItem.City == CHONGQING) {
            wrwhm = std::string("0258");
        } else if(g_CheckItem.City == WUHAN) {
            wrwhm = std::string("0265");
        } else if(g_CheckItem.City == SUZHOU) {
            wrwhm = std::string("0210");
        } else if(g_CheckItem.City == BAODING) {
            wrwhm = std::string("0212");
        } else if (g_CheckItem.City == NANNING) {
            wrwhm = std::string("0224");
        } else if (g_CheckItem.City == QINGHAI) {
            wrwhm = std::string("0290");
        } else if (g_CheckItem.City == SHENZHEN) {
            wrwhm = std::string("0209");
        } else if (g_CheckItem.City == HULUNBEIER) {
            wrwhm = std::string("0209");
        } else if (g_CheckItem.City == TIANJIN) {
            wrwhm = std::string("0210");
        } else if (g_CheckItem.City == ZHOUKOU) {
            wrwhm = std::string("0298");
        } else if (g_CheckItem.City == HENGSHUI) {
            wrwhm = std::string("0213");
        } else if (g_CheckItem.City == PUTIAN) {
            wrwhm = std::string("0213");
        } else if (g_CheckItem.City == XUZHOU) {
            wrwhm = "0206";
        } else if (g_CheckItem.City == FOSHAN) {
            wrwhm = "0297";
        } else {
            ;
        }
        string strPass = "";
        int ntotal = 0;
        int npass = 0;
        unsigned int nIndex = 0;
        for(;nIndex < m_vecResult.size(); nIndex++)
        {
            if( m_vecResult[nIndex].category == wrwhm &&
                    ( m_vecResult[nIndex].result == "1" || m_vecResult[nIndex].result == "5" ))
            {
                ntotal ++;
            }
            if( m_vecResult[nIndex].category == wrwhm && m_vecResult[nIndex].result == "1" )
            {
                npass ++;
            }
        }
        if(ntotal == 0)
        {
            char achTemp[500] = "\0";
            sprintf(achTemp, "%s环保单:0", wrwhm.c_str());
            strPass = achTemp;
        }
        else
        {
            char achTemp[500] = "\0";
            sprintf(achTemp, "%s环保单:%d", wrwhm.c_str(), npass * 100 / ntotal);
            strPass = achTemp;
        }
        return strPass;
}

string CLocalPicTest::Compute0321()
{
    string strPass = "";
    int n0321total = 0;
    int n0321pass = 0;
    unsigned int nIndex = 0;
    for(;nIndex < m_vecResult.size(); nIndex++)
    {
        if( m_vecResult[nIndex].category == "0321" &&
                ( m_vecResult[nIndex].result == "1" || m_vecResult[nIndex].result == "5" ))
        {
            n0321total ++;
        }
        if( m_vecResult[nIndex].category == "0321" && m_vecResult[nIndex].result == "1" )
        {
            n0321pass ++;
        }
    }
    if(n0321total == 0)
    {
        strPass = "0%";
    }
    else
    {
        char achTemp[500] = "\0";
        sprintf(achTemp, "%d%%", n0321pass * 100 / n0321total);
        strPass = achTemp;
    }
    return strPass;
}

string CLocalPicTest::Compute0352()
{
    string strPass = "";
    int n0352total = 0;
    int n0352pass = 0;
    unsigned int nIndex = 0;
    for(;nIndex < m_vecResult.size(); nIndex++)
    {
        if( m_vecResult[nIndex].category == "0352" &&
                ( m_vecResult[nIndex].result == "1" || m_vecResult[nIndex].result == "5" ))
        {
            n0352total ++;
        }
        if( m_vecResult[nIndex].category == "0352" && m_vecResult[nIndex].result == "1" )
        {
            n0352pass ++;
        }
    }
    if(n0352total == 0)
    {
        strPass = "0%";
    }
    else
    {
        char achTemp[500] = "\0";
        sprintf(achTemp, "%d%%", n0352pass * 100 / n0352total);
        strPass = achTemp;
    }
    return strPass;
}

string CLocalPicTest::Compute0322()
{
    string strPass = "";
    int n0322total = 0;
    int n0322pass = 0;
    unsigned int nIndex = 0;
    for(;nIndex < m_vecResult.size(); nIndex++)
    {
        if( m_vecResult[nIndex].category == "0322" &&
                ( m_vecResult[nIndex].result == "1" || m_vecResult[nIndex].result == "5" ))
        {
            n0322total ++;
        }
        if( m_vecResult[nIndex].category == "0322" && m_vecResult[nIndex].result == "1" )
        {
            n0322pass ++;
        }
    }
    if(n0322total == 0)
    {
        strPass = "0%";
    }
    else
    {
        char achTemp[500] = "\0";
        sprintf(achTemp, "%d%%", n0322pass * 100 / n0322total);
        strPass = achTemp;
    }
    return strPass;
}

string CLocalPicTest::Compute0348()
{
    string strPass = "";
    int n0348total = 0;
    int n0348pass = 0;
    unsigned int nIndex = 0;
    for(;nIndex < m_vecResult.size(); nIndex++)
    {
        if( m_vecResult[nIndex].category == "0348" &&
                ( m_vecResult[nIndex].result == "1" || m_vecResult[nIndex].result == "5" ))
        {
            n0348total ++;
        }
        if( m_vecResult[nIndex].category == "0348" && m_vecResult[nIndex].result == "1" )
        {
            n0348pass ++;
        }
    }
    if(n0348total == 0)
    {
        strPass = "0%";
    }
    else
    {
        char achTemp[500] = "\0";
        sprintf(achTemp, "%d%%", n0348pass * 100 / n0348total);
        strPass = achTemp;
    }
    return strPass;
}

void CLocalPicTest::WriteResult()
{
    ofstream ofile_test;
    ofile_test.open("test.txt", ios::out | ios::trunc);
    unsigned int nIndex = 0;
    for(; nIndex < m_vecResult.size(); nIndex++)
    {
        ofile_test << m_vecResult[nIndex].category << " " << m_vecResult[nIndex].path <<" " << m_vecResult[nIndex].result\
                    << " " << m_vecResult[nIndex].reason << endl;
    }

    nIndex = 0;
    for(; nIndex < m_vecResult.size(); nIndex++)
    {
        if(m_vecResult[nIndex].category == ZhaoPianZL.ZuoQianFang
         || m_vecResult[nIndex].category == ZhaoPianZL.YouHouFang
         || m_vecResult[nIndex].category == ZhaoPianZL.ZuoFang )
        {
            ofile_test << m_vecResult[nIndex].category << " " << m_vecResult[nIndex].path <<" " << m_vecResult[nIndex].logo << endl;
        }
    }
    //compute 0111
    ofile_test << "0111左前方:" << Compute0111() << endl;
    //compute 0112
    ofile_test << "0112右后方:" << Compute0112() << endl;
     //compute 0113
    ofile_test << "0113车架号:" << Compute0113() << endl;
    //compute 0157
    ofile_test << "0157安全带:" <<  Compute0157() << endl;
    //compute 0201
    ofile_test << "0201行驶证:" <<  Compute0201() << endl;
    //compute 0202
    ofile_test << "0202牌证申请表:" << Compute0202() << endl;
    //compute 0203
    ofile_test << "0203交强险:" <<  Compute0203() << endl;
    //compute 0204
    ofile_test << "0204检验报告:" <<  Compute0204() << endl;
    //compute 0205
    ofile_test << "0205查验记录:" <<  Compute0205() << endl;
    //compute 0206
    ofile_test << "0206完税证明:" <<  Compute0206() << endl;
    //compute wrwhm
    ofile_test << ComputeHuanBaoDan() << endl;
    //compute 0321
    ofile_test << "0321左灯光:" << Compute0321() << endl;
    //compute 0352
     ofile_test << "0352右灯光:" << Compute0352() << endl;
     //compute 0322
      ofile_test << "0322一轴:" << Compute0322() << endl;
      //compute 0322
     ofile_test << "0348二轴:" << Compute0348() << endl;
    ofile_test.close();

}

void CLocalPicTest::TestLocalFile(string strDir)
{
    GetFilesName(strDir);
    //nvmlReturn_t resultNvml;
    unsigned int gpu_numbers;

   try {
     nvmlReturn_t resultNvml;

     resultNvml = nvmlInit();
     if (resultNvml != NVML_SUCCESS) {
        DATA_PRINT(LEVEL_ERROR, "nvmlInit() fails! Reason: %s \n", nvmlErrorString(resultNvml));
        exit(EXIT_FAILURE);
     }

     resultNvml = nvmlDeviceGetCount(&gpu_numbers);
     if (resultNvml != NVML_SUCCESS) {
        DATA_PRINT(LEVEL_ERROR, "nvmlDeviceGetCount() fails! Reason: %s \n", nvmlErrorString(resultNvml));
         exit(EXIT_FAILURE);
        }

       DataAnalyseThread();

       }
       catch (const std::system_error& e) {
            DATA_PRINT(LEVEL_ERROR, "Create new thread failure! \n");
            std::cout << "Error code: " << e.code() << ", reason: " << e.what() << std::endl;
            exit(EXIT_FAILURE);
       }
       WriteResult();

}
