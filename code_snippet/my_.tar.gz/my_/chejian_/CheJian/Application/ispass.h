#ifndef ISPASS_H
#define ISPASS_H
#include <string>
#include "vehicle_inf.h"
#include "check_item.h"


using namespace std;

class isPass
{
public:
    isPass(const vehicle_inf * p_vehicle_inf, CheckItem item, bool is_ten_year);
    ~isPass();

    string returnIsPass();//is_pass判决逻辑
    void initArray();//根据城市代码初始化数组

private:
    const vehicle_inf* i_vehicle_inf;
    vector<string> common;  //通用上传照片 10年以下
    vector<string> common_tenyear; //通用上传照片十年以上
    vector<string> special; //专用上传照片 10年以下
    vector<string> special_tenyear;//专用上传照片十年以上
    vector<string> province_only;//省内上传照片
    vector<string> out_province_only;//省内上传照片
    vector<string> other_photo;
    vector<string> all_list;
    vector<string> small_vehicle; //小车车辆类型
    string city_code; //结构城市代码
    string city_for_short;
    bool tenyear_flag;
    bool complete(vector<string> type_array,vector<_photo_resource> photo_list ); //照片列表是否包含全部类型
    bool isSmallCar();
    string unqualified(vector<string> type_array,vector<_dbbhg_list> unqualified_list);   //是否有不合格照片
    bool isInProvince();
};

#endif // ISPASS_H
