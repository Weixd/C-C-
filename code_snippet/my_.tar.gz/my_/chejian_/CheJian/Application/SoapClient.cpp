#include "SoapClient.h"
#include "HttpClient.h"
#include "http_res_def.h"
#include "trace_log.h"
#include "Markup.h"
#include <sys/types.h>  
#include <sys/stat.h>
#include <unistd.h>


using namespace std;
extern std::string g_videoFilePath;
extern std::string g_remoteServerIp;
extern std::string g_remoteServerPort;
extern std::string g_requestUri;
extern std::string UTF8toANSI(char *strUTF8);
extern std::string ANSItoUTF8(char* strAnsi);

std::wstring StringToWstring(const std::string str);
std::string WstringToString(const std::wstring str);
std::string URLDecode(const std::string &sIn);

std::string SoapClient::token;
std::time_t SoapClient::token_start;

SoapClient::SoapClient()
{
	std::string tmp = "http://192.168.0.242:7999/PdaOutAccess.asmx";
	SHIPIN_URI = tmp;
}

SoapClient::~SoapClient()
{

}

bool SoapClient::isTokenValid()
{
	if (token == "") {
        DATA_PRINT(LEVEL_DEBUG, "<------------------- NEED GET TOKEN  -------------------> \n\n");
		return false;
	}

	std::time_t token_now = std::time(nullptr);
	unsigned long seconds = token_now - token_start;

	/* Ŀǰ��2017-10-19��tokenԐЧǚ��ˇ7200ī����Еǰ��00īƐ�� */
	if (seconds > 5400) {
        DATA_PRINT(LEVEL_DEBUG, "<------------------- NEED GET TOKEN  -------------------> \n\n");
		return false;
		
	} else {
        DATA_PRINT(LEVEL_DEBUG, "<------------------- NOT NEED GET TOKEN -------------------> \n\n" );
		return true;

	}
}

void SoapClient::getToken(std::string IP, std::string MAC_Address)
{
	std::string BodyString;

	BodyString += "<GetToken xmlns=\"http://tempuri.org/\">";
	BodyString += "<App_ID>SHYK</App_ID>";
	BodyString += "<App_Secret>SHYK</App_Secret>";
	BodyString += "<AppIP>" + IP + "</AppIP>";
	BodyString += "<App_Mac>" + MAC_Address + "</App_Mac>";
	BodyString += "</GetToken>";

	std::string data = SOAP_BodyPackage(BodyString);
    DATA_PRINT(LEVEL_DEBUG, "<------------------- SENT XML : %s -------------------> \n\n", data.c_str());
	HttpClient client;

    if (client.InitData("http://192.168.0.242:7999/PdaOutAccess.asmx", REQUEST_SOAP_FLAG, (char *)HTTP_CONTENT_TYPE_TEXT_XML, (char *)data.c_str())) {
		client.startHttpClient();
		if (client.ResponseData.find("true") != std::string::npos) {
			int position = client.ResponseData.find("ACCESS_TOKEN");
			position += 15;
			token = client.ResponseData.substr(position, 20);
			token_start = std::time(nullptr);	
            sleep(500);
		} else {
			DATA_PRINT(LEVEL_ERROR, "Failed to get the Video token�� \n");
		}
	}
}


bool SoapClient::get_vehicle_adr(vehicle_inf *vehicle)
{
	std::string QueryXmlDoc;
	QueryXmlDoc += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
	QueryXmlDoc += "<root>";
	QueryXmlDoc += "<QueryCondition>";
	QueryXmlDoc += "<hphm>%e8%8b%8f";
    QueryXmlDoc += vehicle->m_hphm;
	QueryXmlDoc += "</hphm>";
	QueryXmlDoc += "<hpzl>";
    QueryXmlDoc += vehicle->m_hpzl;
	QueryXmlDoc += "</hpzl>";
	QueryXmlDoc += "<VIN>";
    QueryXmlDoc += vehicle->m_clsbdh;
	QueryXmlDoc += "</VIN>";
	QueryXmlDoc += "</QueryCondition>";
	QueryXmlDoc += "</root>";
	std::string BodyString;
	BodyString += "<queryObjectOut xmlns=\"http://tempuri.org/\">";
	BodyString += "<xtlb>22</xtlb>";
	BodyString += "<jkxlh>" + token + "</jkxlh>";
	BodyString += "<jkid>22C01</jkid>";	/* 22C01 */
	BodyString += "<QueryXmlDoc>" + XML_code_EntityReference(QueryXmlDoc) + "</QueryXmlDoc>";
	BodyString += "</queryObjectOut>";

	std::string data = SOAP_BodyPackage(BodyString);
	HttpClient client;
    if (client.InitData(SHIPIN_URI.c_str(), REQUEST_SOAP_FLAG, (char *)HTTP_CONTENT_TYPE_TEXT_XML, (char *)data.c_str())) {
		client.startHttpClient();
		std::string XmlData = client.ResponseData;
		XmlData = URLDecode(XmlData);
        DATA_PRINT(LEVEL_DEBUG, "<------------------- ResponseData : %s -------------------> \n\n", client.ResponseData.c_str());
		CMarkup xml;
        std::string datar = XmlData.c_str();
		xml.SetDoc(datar);
		xml.ResetMainPos();
        if (xml.FindElem("soap:Envelope")) {
			xml.IntoElem();
            if (xml.FindElem("soap:Body")) {
				xml.IntoElem();
				setlocale(LC_ALL, "chs");
                if (xml.FindElem("queryObjectOutResponse")) {
                    if (xml.FindChildElem("queryObjectOutResult")) {
                        std::string reply = XML_decode_EntityReference(xml.GetChildData());
						return get_vehicle_FromReply(reply, vehicle);
                        DATA_PRINT(LEVEL_DEBUG, "<------------------- RECEIVE PATH : %s -------------------> \n\n", reply.c_str());
					}
				}
			}
		} else {
			DATA_PRINT(LEVEL_ERROR, "The data is not SOAP format. \n");
			return false;
		}
	}
	return false;
}



bool SoapClient::get_vehicle_FromReply(std::string reply, vehicle_inf *vehicle)
{
	CMarkup xml;
    std::string data = reply.c_str();
	xml.SetDoc(data);
	xml.ResetMainPos();
	int count;
    if (xml.FindElem("root")) {
		xml.IntoElem();
		setlocale(LC_ALL, "chs");

		/* �쳩ˇ�򐃔سɹ� */
        if (xml.FindElem("head")) {
            if(xml.FindChildElem("rownum"))
			{
				vehicle->m_spzs = xml.GetChildData();
                std::string cc = xml.GetChildData();
                count =atoi(cc.c_str());
                DATA_PRINT(LEVEL_DEBUG, "VIDEO NUMBER IS %d \n\n",count);
				if (count == 0)
				{
                    DATA_PRINT(LEVEL_DEBUG, "DON'T HAVE THIS VIDEO \n\n");
					return false;
				}
				else
				{
					DATA_PRINT(LEVEL_ERROR, "GET VIDEO PATH DATA \n");

				}
			}	
		}
        if (xml.FindElem("body")){
			xml.IntoElem();
            if (xml.FindElem("videodes")){
				for (int i = 0; i < count; i++){
					_video_resource spdata;
                    if (xml.FindChildElem("spzl")){
						spdata.sptype = xml.GetChildData();
					}
                    if (xml.FindChildElem("spurl")){
                        std::string cc = xml.GetChildData();
						cc = UTF8toANSI((char *)cc.c_str());
						cc=	encode(cc);
						spdata.spurl = cc.c_str();
						spdata.local_path = g_videoFilePath;


                        std::time_t t = std::time(NULL);
                        std::tm *st = std::localtime(&t);
                        char tmpArray[128] = { 0 };
                        sprintf(tmpArray, "%d-%02d-%02d", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);
                        std::string strCurTime = tmpArray;
                        spdata.local_path+=strCurTime;
#ifdef CHE_JIAN_LINUX
                        struct stat st_buf;
                        memset(&st_buf,0,sizeof(st_buf));
                        stat(spdata.local_path.c_str(), &st_buf);
                        if ((st_buf.st_mode & S_IFMT) != S_IFDIR) {
                            mkdir(spdata.local_path.c_str(), 0777);
                        }
#else
                        if (!PathIsDirectory(spdata.local_path.c_str()))
                        CreateDirectory(spdata.local_path.c_str(), NULL);
#endif
                        spdata.local_path += "/";
                        std::string urlc = spdata.spurl;
                        if (urlc.find("HK_brake1") != std::string::npos) {
							spdata.spzl = "HK_brake1";
						}
                        if (urlc.find("HK_brake2") != std::string::npos) {
							spdata.spzl = "HK_brake2";
						}
                        if (urlc.find("YW_brake1") != std::string::npos) {
							spdata.spzl = "YW_brake1";
						}
                        if (urlc.find("YW_brake2") != std::string::npos) {
							spdata.spzl = "YW_brake2";
						}
                        if (urlc.find("leftfront") != std::string::npos) {
							spdata.spzl = "leftfront";
						}
                        if ( urlc.find("rightback") != std::string::npos) {
							spdata.spzl = "rightback";
						}
                        if (urlc.find("lightlfar") != std::string::npos) {
							spdata.spzl = "lightlfar";
						}
                        if (urlc.find("lightrfar") != std::string::npos) {
							spdata.spzl = "lightrfar";
						}
                        if (urlc.find("bottom") != std::string::npos) {
							spdata.spzl = "bottom";
						}
                        if (urlc.find("YW_brakeh") != std::string::npos) {
							spdata.spzl = "YW_brakeh";
						}
                        if (urlc.find("HK_brakeh") != std::string::npos) {
							spdata.spzl = "HK_brakeh";
						}
						spdata.dzzl = "ftp";
						spdata.local_path += vehicle->m_hphm + "_" + vehicle->m_jyjgbh + "_" + spdata.spzl + ".MP4";
						
						
					}

					vehicle->m_splist.push_back(spdata);
				}
				return true;
			}
		}
		



		return true;
	}

	DATA_PRINT(LEVEL_ERROR, "Failed to obtain the vehicle XML data! \n");
	return false;
}

/*
�Դ�ɫ˽�ތ\ED\BD\93XMLʹķ��SOAP�Ånvelope�̂odyԪ̘��SOAP 1.1����
*/
std::string SoapClient::SOAP_BodyPackage(std::string data)
{
	std::string result;
	result += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
	result += "<soap:Envelope ";
	result += "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" ";
	result += "xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" ";
	result += "xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"";
	result += ">";
	result += "<soap:Body>";
	result += data;
	result += "</soap:Body>";
	result += "</soap:Envelope>";
	return result;
}

std::string SoapClient::XML_code_EntityReference(std::string data)
{
	while (true) {
		std::string::size_type pos(0);

		if ((pos = data.find("<")) != std::string::npos) {
			data.replace(pos, 1, "&lt;");
		} else {
			break;
		}
	}

	while (true) {
		std::string::size_type pos(0);

		if ((pos = data.find(">")) != std::string::npos) {
			data.replace(pos, 1, "&gt;");
		} else {
			break;
		}
	}

	return data;
}

std::string SoapClient::XML_decode_EntityReference(std::string data)
{
	while (true) {
		std::string::size_type pos(0);

		if ((pos = data.find("&lt;")) != std::string::npos) {
			data.replace(pos, 4, "<");
		} else {
			break;
		}
	}

	while (true) {
		std::string::size_type pos(0);

		if ((pos = data.find("&gt;")) != std::string::npos) {
			data.replace(pos, 4, ">");
		} else {
			break;
		}
	}

	return data;
}

std::string SoapClient::BackslashToSlash(std::string data)
{
	while (true) {
		std::string::size_type pos(0);

		if ((pos = data.find("\\")) != std::string::npos) {
			data.replace(pos, 1, "/");
		} else {
			break;
		}
	}

	return data;
}

std::string SoapClient::encode(std::string data)
{
	std::string::size_type pos(0);
	if ((pos = data.find("̕")) != std::string::npos) {
		data.replace(pos, 2, "%e8%8b%8f");
	}
	std::string::size_type pos1(0);

	while ((pos1 = data.find("\\")) != std::string::npos) {
		data.replace(pos1, 1, "/");
	}
	return data;
}
