#include <stdio.h>
#include "curl/curl.h"
#include "curl/easy.h"
#include "Ftp_download.h" 
#include "trace_log.h"

extern string g_ftp_UserPas;
using namespace std;

struct FtpFile   //
{
    char *filename;
	FILE *stream;
};

int my_fwrite(void *buffer, size_t size, size_t nmemb, void *stream)
{
    struct FtpFile *out = (struct FtpFile *)stream; // streamָ֫Ǥʵ�ΊȖ�вstruct FtpFile ftpfile�
    if (out && !out->stream)
	{
        out->stream = fopen(out->filename, "wb");
		if (!out->stream)
			return -1;
	}
	return fwrite(buffer, size, nmemb, out->stream);
    fclose(out->stream);
}

bool FtpClient::ftpdownload(string url, string filename)
{
	CURL *curl;
	CURLcode res;
	string codeurl;
	codeurl = encode(url);
	char *name = (char *)filename.c_str();
    struct FtpFile ftpfile = { name, NULL };
	curl_global_init(CURL_GLOBAL_DEFAULT);

	curl = curl_easy_init();
	if (curl)
	{
		curl_easy_setopt(curl, CURLOPT_URL, codeurl.c_str());
        if(!g_ftp_UserPas.empty())
        {
            curl_easy_setopt(curl, CURLOPT_USERPWD, g_ftp_UserPas.c_str());
        }
        else
        {
            DATA_PRINT(LEVEL_ERROR, "g_ftp_UserPas is empty :s% \n\n",g_ftp_UserPas.c_str());
            return false;
        }
		curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, my_fwrite);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &ftpfile);
        curl_easy_setopt(curl, CURLOPT_VERBOSE, TRUE);

		res = curl_easy_perform(curl);
		curl_easy_cleanup(curl);

		if (CURLE_OK != res){
			fprintf(stderr, "curl told us %d\n", res);
            DATA_PRINT(LEVEL_ERROR, "<------------------- one video's download erro -------------------curl told us %d> \n\n", res);
            return false;
		}		
		else
            DATA_PRINT(LEVEL_INFO, "<------------------- one video's download is ended-------------------> \n\n");
	}
	if (ftpfile.stream)
		fclose(ftpfile.stream);
	curl_global_cleanup();

	return true;

}

std::string FtpClient::encode(std::string data)
{
		std::string::size_type pos(0);
		if ((pos = data.find("̕")) != std::string::npos) {
			data.replace(pos, 2, "%e8%8b%8f");
		}
		std::string::size_type pos1(0);

		while ((pos1 = data.find("\\")) != std::string::npos) {
			data.replace(pos1, 1, "/");
		}
	return data;
}
