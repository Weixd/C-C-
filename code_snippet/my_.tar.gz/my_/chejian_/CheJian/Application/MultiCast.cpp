#include "vehicle_check_service.h"
#include "MultiCast.h"
#include "cmdutil.h"
#include <iostream>
#include <fstream>
#include "Markup.h"
#include "./helper/NetClient.h"
#include <time.h>
#include <stdlib.h>
#include "./helper/HelperFile.h"
#include "./helper/HelperString.h"
#include "vehicle_inf.h"
#include "BlockQueue.h"

extern unsigned int g_device_ID;
extern std::string g_version;
extern int g_SlaveCount;
extern std::string g_master_IP;
extern std::vector<SlaveInfo> SlaveList;
extern unsigned int g_debug_level;
extern std::string g_localServerIp;
extern std::string g_localServerPort;
extern std::string g_photoUri;
extern std::string g_photoFilePath;
extern std::string g_videoFilePath;
extern std::string g_demo_path;

extern BlockingQueue<vehicle_inf*> toanalyse_queue;
extern BlockingQueue<vehicle_inf*> download_queue;
extern BlockingQueue<video_inf*> video_queue;
extern BlockingQueue<vehicle_inf *> reply_queue;
extern BlockingQueue<std::string> sqlstr_queue;

#define HEART_BEAT    1
#define UPDATE        2
#define SQL           3

class CmdHeartBeat : public BaseCmd
{
public:
    NInt32       devId_;
    NString      ip_;
    NInt16       port_;
    NInt8        bMaster_;
    NString      ver_;
    NInt16       downloadQueueSize_;
    NInt16       analyseQueueSize_;
    NInt16       videoQueueSize_;
    NInt16       replyQueueSize_;
public:
    CmdHeartBeat()
    {
        PushVars(HEART_BEAT, 9, &devId_,&ip_,&port_,&bMaster_,&ver_,&downloadQueueSize_,&analyseQueueSize_,&videoQueueSize_,&replyQueueSize_);
    }
    void SetValues(int32_t* devId,char* ip,int16_t* port,int8_t* isMaster,char* ver,int16_t* downloadQueueSize,int16_t* analyseQueueSize,int16_t* videoQueueSize,int16_t* replyQueueSize)
    {
        devId_.SetValue(devId);
        ip_.SetValue(ip);
        port_.SetValue(port);
        bMaster_.SetValue(isMaster);
        ver_.SetValue(ver);
        downloadQueueSize_.SetValue(downloadQueueSize);
        analyseQueueSize_.SetValue(analyseQueueSize);
        videoQueueSize_.SetValue(videoQueueSize);
        replyQueueSize_.SetValue(replyQueueSize);
    }
};

class CmdUpdate : public BaseCmd
{
public:
    NInt8        bUpdate_;
    NString      devIdStr_;
public:
    CmdUpdate()
    {
        PushVars(UPDATE, 2, &bUpdate_,&devIdStr_);
    }
    void SetValues(int8_t* bUpdate,char* devIdStr)
    {
        bUpdate_.SetValue(bUpdate);
        devIdStr_.SetValue(devIdStr);
    }
};

class CmdSql : public BaseCmd
{
public:
    NInt32       devId_;
    NString      ip_;
    NInt8        bEndPack_;
    NString      sqlStr_;
public:
    CmdSql()
    {
        PushVars(SQL, 4, &devId_,&ip_,&bEndPack_,&sqlStr_);
    }
    void SetValues(int32_t* devId,char* ip,int8_t* isEndPack,char* sqlstr)
    {
        devId_.SetValue(devId);
        ip_.SetValue(ip);
        bEndPack_.SetValue(isEndPack);
        sqlStr_.SetValue(sqlstr);
    }
};

std::string ownerfolder()
{
#ifdef __linux
    char path[1024]={0};
    int cnt = readlink("/proc/self/exe", path, 1024);
    if(cnt < 0|| cnt >= 1024)
        return "";
    for(int i = cnt; i >= 0; --i)
    {
        if(path[i]=='/')
        {
            path[i + 1]='\0';
            break;
        }
    }
    return path;
#else
    CHAR path[MAX_PATH];
    ::GetModuleFileNameA(NULL, path, MAX_PATH);
    int cnt = strlen(path);
    for (int i = cnt; i >= 0; --i)
    {
        if (path[i] == '\\')
        {
            path[i + 1] = '\0';
            break;
        }
    }
    return path;
#endif
}
void strsplit(std::vector<std::string>& lines, std::string src, std::string delims)
{
    int n = src.find(delims);
    while (n != std::string::npos)
    {
        std::string tmp = src.substr(0, n);
        if (tmp != "")
            lines.push_back(tmp);
        src = src.substr(n + delims.length());
        n = src.find(delims);
    }
    if (src != "")
        lines.push_back(src);
}

int64_t VerToInt64(std::string verstr)
{
    std::vector<std::string> ints;
    strsplit(ints,verstr,".");
    if(ints.size() != 3)
        return 0;
    int64_t i1=atoi(ints[0].c_str());
    int64_t i2=atoi(ints[1].c_str());
    int64_t i3=atoi(ints[2].c_str());
    return i1*(1000*1000)+i2*1000+i3;
}

class RecvTask : public Task
{
public:
    RecvTask(MultiCast* mc) :bStop_(false), mc_(mc){ }
    virtual ~RecvTask() { }
    virtual void Run()
    {
        char buf[MULTI_CAST_BUF_LEN] = { 0 };
#ifdef __linux
        unsigned int socklen = sizeof(struct sockaddr_in);
#else
        int socklen = sizeof(struct sockaddr_in);
#endif
        while (!bStop_)
        {
            int n = recvfrom(mc_->recvSock_, buf, MULTI_CAST_BUF_LEN, 0, (struct sockaddr *)&mc_->localAddr_, &socklen);
            if (n <= 0)
                break;
            else
                mc_->cb_(mc_, buf, n);
        }
    }
    virtual void StopRun()
    {
        bStop_ = true;
    }

public:
    bool bStop_;
    MultiCast* mc_;
};
int GetIpLastInt(std::string ip)
{
    std::vector<std::string> ints;
    strsplit(ints,ip,".");
    if(ints.size() != 4)
        return 0;
    return atoi(ints[3].c_str());
}
class MyTimer : public Task
{
public:
    MyTimer(MultiCast* mc) :bStop_(false), mc_(mc){ }
    virtual ~MyTimer() { }
    virtual void Run()
    {
        system_clock::time_point tick = system_clock::now() - std::chrono::minutes(1);
        system_clock::time_point tick1 = system_clock::now() - std::chrono::minutes(1);
        system_clock::time_point tick2 = system_clock::now() - std::chrono::minutes(1);
        while (!bStop_)
        {
            if (duration<double, std::milli>(system_clock::now() - tick).count() > 10*1000 && mc_->pServ_)
            {
                CmdHeartBeat chb;
                int32_t devId = g_device_ID;
                std::string ip = mc_->pServ_->m_httpserver.s_ip;
                int16_t port = mc_->pServ_->m_httpserver.s_port;
                int8_t bMaster = (g_SlaveCount != -1);
                std::string ver=g_version;
                int16_t downloadQueueSize=download_queue.Size();
                int16_t analyseQueueSize=toanalyse_queue.Size();
                int16_t videoQueueSize=video_queue.Size();
                int16_t replyQueueSize=reply_queue.Size();
                chb.SetValues(&devId, (char*)ip.c_str(), &port, &bMaster,(char*)ver.c_str(),&downloadQueueSize,&analyseQueueSize,&videoQueueSize,&replyQueueSize);
                char buf[MULTI_CAST_BUF_LEN] = { 0 };
                int len = MULTI_CAST_BUF_LEN;
                chb.Create(buf, len);
                if(!mc_->SendData(buf, len))
                {
                    DATA_PRINT(LEVEL_ERROR, "multicast send data failed! datalen=%d \n", len);
                }
                tick = system_clock::now();
            }
            /*
            if (duration<double, std::milli>(system_clock::now() - tick1).count() > 5*1000 && mc_->pServ_)
            {
                MultiCast* pmc = (MultiCast*)mc_;
                std::lock_guard<std::mutex> lg(pmc->cjClntsMutex_);
                //master slave checkout
                int32_t minDevId = g_device_ID;
                std::string minIp="";
                for (auto& c : pmc->cjClnts_)
                {
                    if(minDevId >= c.second.devId)
                    {
                        minDevId=c.second.devId;
                        minIp=c.second.ip;
                    }
                }
                bool isMinIp=false;
                if(minIp=="")
                    isMinIp=true;
                else
                    isMinIp=(GetIpLastInt(minIp) > GetIpLastInt(mc_->pServ_->m_httpserver.s_ip));

                if (minDevId == g_device_ID && isMinIp)
                {
                    if (g_SlaveCount == -1)
                    {
                        bool allSlave = true;
                        for (auto c : pmc->cjClnts_)
                        {
                            if (c.second.bMaster)
                                allSlave = false;
                        }
                        if (allSlave)
                            pmc->pServ_->check_master();
                    }
                    g_SlaveCount=pmc->cjClnts_.size();
                    SlaveList.clear();
                    for (auto c : pmc->cjClnts_) {
                        SlaveInfo si;
                        si.ip = c.second.ip.c_str();
                        si.port = std::to_string(c.second.port).c_str();
                        SlaveList.push_back(si);
                    }
                }
                else
                {
                    if (g_SlaveCount != -1)
                        pmc->pServ_->check_slave();
                    g_SlaveCount = -1;
                    std::map<int32_t, CJClient>::iterator it = pmc->cjClnts_.find(minDevId);
                    if (it != pmc->cjClnts_.end())
                        g_master_IP = it->second.ip.c_str();
                    SlaveList.clear();
                }
                tick1 = system_clock::now();
            }
            */
            if (duration<double, std::milli>(system_clock::now() - tick2).count() > 2*1000)
            {
                MultiCast* pmc = (MultiCast*)mc_;
                std::lock_guard<std::mutex> lg(pmc->cjClntsMutex_);
                std::map<int32_t, CJClient>::iterator it = pmc->cjClnts_.begin();
                while (it != pmc->cjClnts_.end())
                {
                    if (duration<double, std::milli>(system_clock::now() - it->second.tick).count() > 20*1000)
                        it = pmc->cjClnts_.erase(it);
                    else
                        it++;
                }
                tick2 = system_clock::now();
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(50));
        }
    }
    virtual void StopRun()
    {
        bStop_ = true;
    }
public:
    bool bStop_;
    MultiCast* mc_;
};
class VersionCheck : public Task
{
public:
    VersionCheck(MultiCast* mc) :bStop_(false), mc_(mc){ }
    virtual ~VersionCheck() { }
    virtual void Run()
    {
        system_clock::time_point tick = system_clock::now() - std::chrono::minutes(1);
        while (!bStop_)
        {
            if (duration<double, std::milli>(system_clock::now() - tick).count() > 10*1000 && mc_->pServ_ && mc_->bUpdateFlag_)
            {
                MultiCast* pmc = (MultiCast*)mc_;
                int64_t localVer=VerToInt64(g_version);
                std::vector<std::string> ips;
                int64_t maxVer=localVer;
                std::string maxVerStr=g_version;
                bool ismax=true;
                {
                    std::lock_guard<std::mutex> lg(pmc->cjClntsMutex_);
                    for (auto& c : pmc->cjClnts_)
                    {
                        if(c.second.iver > maxVer)
                        {
                            maxVer=c.second.iver;
                            maxVerStr=c.second.ver;
                            ismax=false;
                        }
                    }
                    for (auto& c : pmc->cjClnts_)
                    {
                        if(c.second.iver == maxVer)
                            ips.push_back(c.second.ip);
                    }
                }
                if(!ismax && ips.size()>0)
                {
                    srand((unsigned long)time(0));
                    int32_t idx=rand()%ips.size();
                    std::string url="http://"+ips[idx]+":16389/GetPackage?version="+maxVerStr;
                    nc.Init(url,10,10);
                    std::string pkg="/opt/vehicle/program/Release_"+maxVerStr+".tar.gz";
                    if(nc.DownloadFile(pkg) && nc.ioRet_.GetHttpStatusCode() == 200)
                    {
                        system(("tar jxvf "+pkg+" /opt/vehicle/program/").c_str());
                        std::string relsPath="/opt/vehicle/program/Release_"+maxVerStr+"/";
                        if(hl::pathexist(relsPath))
                        {
                            system(("cp -f "+ownerfolder()+"vehicle_check.xml "+relsPath+"bin/").c_str());
                            std::fstream fs;
                            fs.open("/etc/ld.so.conf.d/CheJian.conf",std::ios::out|std::ios::trunc);
                            if(fs.is_open())
                            {
                                fs << relsPath+"lib/";
                                fs.close();
                            }
                            else
                            {
                                DATA_PRINT(LEVEL_ERROR, "can't open file, path=/etc/ld.so.conf.d/CheJian.conf \n");
                            }
                            fs.open("/opt/vehicle/program/CheJian_boot",std::ios::out|std::ios::trunc);
                            if(fs.is_open())
                            {
                                fs << "#!/bin/bash\n";
                                fs << "cd " << relsPath << "bin\n";
                                fs << "gnome-terminal --maximize -x ./CheJian";
                                fs.close();
                            }
                            else
                            {
                                DATA_PRINT(LEVEL_ERROR, "can't open file, path=/opt/vehicle/program/CheJian_boot \n");
                            }
                            pmc->pServ_->stop();
                            system("clear");
                            system("ldconfig");
                            std::string exepath=relsPath+"bin/CheJian";
                            if(hl::pathexist(exepath))
                                execlp(exepath.c_str(), NULL, NULL);
                            else
                            {
                                DATA_PRINT(LEVEL_ERROR, "can't find exe file, path=%s \n",exepath.c_str());
                            }
                        }
                    }
                    else
                    {
                        DATA_PRINT(LEVEL_ERROR, "download release package failed! url=%s,curlCode=%d,httpCode=%d \n", url.c_str(), nc.ioRet_.GetCulCode(), nc.ioRet_.GetHttpStatusCode());
                    }
                }
                tick = system_clock::now();
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(50));
        }
    }
    virtual void StopRun()
    {
        bStop_ = true;
    }
public:
    bool bStop_;
    NetClient nc;
    MultiCast* mc_;
};
void MultiCast::OnRecv(void* mc,char* buf, int len)
{
    MultiCast* pmc = (MultiCast*)mc;
    int8_t cmdId = BaseCmd::ParseCmdId(buf);
    std::lock_guard<std::mutex> lg(pmc->cjClntsMutex_);
    if (cmdId == HEART_BEAT)
    {
        CmdHeartBeat chb;
        chb.Parse(buf,len);
        if(pmc->bOpenSendFunc_ && chb.devId_.GetValue() == g_device_ID && std::string(chb.ip_.GetValuePtr()) == pmc->pServ_->m_httpserver.s_ip)
            return;
        std::map<int32_t, CJClient>::iterator it = pmc->cjClnts_.find(chb.devId_.GetValue());
        if (it == pmc->cjClnts_.end())
        {
            CJClient cjc;
            cjc.devId = chb.devId_.GetValue();
            cjc.ip = chb.ip_.GetValuePtr();
            cjc.port = chb.port_.GetValue();
            cjc.bMaster = chb.bMaster_.GetValue();
            cjc.ver=chb.ver_.GetValuePtr();
            cjc.iver=VerToInt64(cjc.ver);
            pmc->cjClnts_[cjc.devId] = cjc;
        }
        it = pmc->cjClnts_.find(chb.devId_.GetValue());
        if (it != pmc->cjClnts_.end())
        {
            it->second.devId = chb.devId_.GetValue();
            it->second.ip = chb.ip_.GetValuePtr();
            it->second.port = chb.port_.GetValue();
            it->second.bMaster = chb.bMaster_.GetValue();
            it->second.ver=chb.ver_.GetValuePtr();
            it->second.iver=VerToInt64(it->second.ver);
            it->second.downloadQueueSize=chb.downloadQueueSize_.GetValue();
            it->second.analyseQueueSize=chb.analyseQueueSize_.GetValue();
            it->second.videoQueueSize=chb.videoQueueSize_.GetValue();
            it->second.replyQueueSize=chb.replyQueueSize_.GetValue();
            it->second.tick = system_clock::now();
        }
    }
    else if(cmdId == UPDATE)
    {
        CmdUpdate cu;
        cu.Parse(buf,len);
        std::vector<std::string> devIds;
        hl::strsplit(devIds,cu.devIdStr_.GetValuePtr(),",");
        for(auto& d:devIds)
        {
            if(atoi(d.c_str()) == g_device_ID)
            {
                if(cu.bUpdate_.GetValue())
                    pmc->bUpdateFlag_=true;
                else
                {
                    pmc->bUpdateFlag_=false;
                    pmc->versionCheckTask_->nc.Stop();
                }
            }
        }
    }
    else if(cmdId == SQL)
    {
        CmdSql cs;
        cs.Parse(buf,len);
        pmc->sqlStrTempMap_[cs.ip_.GetValuePtr()]+=cs.sqlStr_.GetValuePtr();
        if(cs.bEndPack_.GetValue())
        {
            sqlstr_queue.Put(pmc->sqlStrTempMap_[cs.ip_.GetValuePtr()]);
            pmc->sqlStrTempMap_[cs.ip_.GetValuePtr()]="";
        }
    }
}

MultiCast::MultiCast() :tpool_(3, 3), recvSock_(-1), sendSock_(-1), recvTask_(new RecvTask(this)), versionCheckTask_(new VersionCheck(this)),pServ_(NULL), timerTask_(new MyTimer(this)),bOpenSendFunc_(true),bUpdateFlag_(false)
{
#ifndef __linux
    WORD wVersionRequested = MAKEWORD(2, 2);
    WSADATA wasData;
    WSAStartup(wVersionRequested, &wasData);
#endif
}

MultiCast::~MultiCast()
{
    Stop();
#ifndef __linux
    WSACleanup();
#endif
}
void MultiCast::Stop()
{
    versionCheckTask_->StopRun();
    recvTask_->StopRun();
    timerTask_->StopRun();
#ifdef __linux
    shutdown(recvSock_, SHUT_RDWR);
    shutdown(sendSock_, SHUT_RDWR);
    close(recvSock_);
    close(sendSock_);
#else
    shutdown(recvSock_, SD_BOTH);
    shutdown(sendSock_, SD_BOTH);
    closesocket(recvSock_);
    closesocket(sendSock_);
#endif
    tpool_.Stop();
}
bool MultiCast::Start(vehicle_check_service* pServ, char* localIp, int localPort, char* multiIp, int multiPort, MULTI_CAST_RECV_CALLBACK cb,bool openSendFunc,bool recvLoop)
{
    int socklen = sizeof(struct sockaddr_in);
    memset(&multiAddr_, 0, socklen);
    multiAddr_.sin_family = AF_INET;
    multiAddr_.sin_addr.s_addr = inet_addr(multiIp);
    multiAddr_.sin_port = htons(multiPort);

    memset(&localAddr_, 0, socklen);
    localAddr_.sin_family = AF_INET;
    localAddr_.sin_addr.s_addr = inet_addr(localIp);
    localAddr_.sin_port = htons(localPort);
    {
        struct ip_mreq mreq;
        /* 创建 socket 用于UDP通讯 */
        recvSock_ = socket(AF_INET, SOCK_DGRAM, 0);
        if (recvSock_ < 0)
            return false;
        int reuse = 1;
        setsockopt(recvSock_, SOL_SOCKET, SO_REUSEADDR, (char *)&reuse, sizeof(reuse));
        bool loop = recvLoop;
        if (setsockopt(recvSock_, IPPROTO_IP, IP_MULTICAST_LOOP, (char*)(&loop), sizeof(loop)) < 0)
            return false;
        /* 设置要加入组播的地址 */
        memset(&mreq, 0, sizeof(struct ip_mreq));
        mreq.imr_multiaddr.s_addr = inet_addr(multiIp);
        mreq.imr_interface.s_addr = inet_addr(localIp);
        if (setsockopt(recvSock_, IPPROTO_IP, IP_ADD_MEMBERSHIP, (const char*)&mreq, sizeof(struct ip_mreq)) == -1)
            return false;
#ifdef __linux
        if (bind(recvSock_, (struct sockaddr *)&multiAddr_, sizeof(struct sockaddr_in)) == -1)
            return false;
#else
        if (::bind(recvSock_, (struct sockaddr *)&localAddr_, sizeof(struct sockaddr_in)) == -1)
            return false;
#endif
    }
    {
        sendSock_ = socket(AF_INET, SOCK_DGRAM, 0);
        if (sendSock_ < 0)
            return false;
        bool loop = recvLoop;
        if (setsockopt(sendSock_, IPPROTO_IP, IP_MULTICAST_LOOP, (char*)(&loop), sizeof(loop)) < 0)
            return false;
#ifndef __linux
        bool opt = 1;
        setsockopt(sendSock_, SOL_SOCKET, SO_BROADCAST, reinterpret_cast<char FAR *>(&opt), sizeof(opt));
#endif
    }
    pServ_ = pServ;
    bOpenSendFunc_=openSendFunc;
    cb_ = cb;
    tpool_.Start();
    tpool_.RunTask(versionCheckTask_);
    tpool_.RunTask(recvTask_);
    tpool_.RunTask(timerTask_);
    return true;
}

void MultiCast::Update(bool open,std::string devIdStr)
{
    CmdUpdate cu;
    cu.SetValues((int8_t*)&open,(char*)devIdStr.c_str());
    char buf[MULTI_CAST_BUF_LEN] = { 0 };
    int len = MULTI_CAST_BUF_LEN;
    cu.Create(buf, len);
    if(!SendData(buf, len))
    {
        DATA_PRINT(LEVEL_ERROR, "multicast send data failed! datalen=%d \n", len);
    }
}

bool MultiCast::SendData(char* buf, int len)
{
    if(!bOpenSendFunc_)
        return true;
    int ret = sendto(sendSock_, buf, len, 0, (struct sockaddr*) &multiAddr_, sizeof(struct sockaddr_in));
    if (ret < 0)
        return false;
    return true;
}

bool MultiCast::SendSqlStr(std::string sql)
{
    if(!bOpenSendFunc_)
        return true;
    if(sql=="")
        return false;
    for(;;)
    {
        std::string sub=sql.substr(0,512);
        sql=sql.substr(sub.length());
        CmdSql cs;
        int32_t devId = g_device_ID;
        std::string ip = pServ_->m_httpserver.s_ip;
        bool bEnd=false;
        if(sql=="")
            bEnd=true;
        cs.SetValues(&devId,(char*)ip.c_str(),(int8_t*)&bEnd,(char*)sub.c_str());
        char buf[MULTI_CAST_BUF_LEN] = { 0 };
        int len = MULTI_CAST_BUF_LEN;
        cs.Create(buf, len);
        if(!SendData(buf, len))
        {
            DATA_PRINT(LEVEL_ERROR, "multicast send data failed! datalen=%d \n", len);
        }
        if(sql=="")
            break;
    }
}
