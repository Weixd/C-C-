#ifndef _CUSTOMIZATION_H_
#define _CUSTOMIZATION_H_

#include "vehicle_inf.h"
#include "occi_wrap.h"

/*
本文件声明了为各个不同的车管所，定制开发的功能。
*/

void getHistoryPhoto(vehicle_inf *p_vehicle_inf);
void addPhoto_A_J(vehicle_inf *p_vehicle_inf);

void synchronizeManualResult_Thread(std::string user, std::string password, std::string connectString);
void getInsuranceResult(vehicle_inf *p_vehicle_inf);
bool BaoDing_connectOracleCluster(occi_wrap &occi);

#endif  //	_CUSTOMIZATION_H_
