#include "ResultCollection.h"
#include "check_item.h"
#include <time.h>
#include "helper/HelperString.h"

/*
由于arithmetic_app_def.h里面定义了logo_data
如果包含该头文件，会导致logo_data重定义
因此只能将结果宏定义于此处
*/
#define RESOURCE_ERR_DESC       "未能获取到该资源数据"
#define PICTURE_NOT_STANDARD	"[图片信息不规范]"
#define VIDEO_NOT_STANDARD		"[视频信息不规范]"
#define	OUT_OF_DATE				"[照片水印日期过期]"
#define NO_TRIPOD				"[没有三角架]"
#define HPHM_ERROR				"[车牌号不正确]"
#define DANG_AN_ERROR			"[与档案照片不符]"
#define CHE_JIA_HAO_ERROR		"[车架号不正确]"
#define NO_SIGNATURE			"[没有签名]"
#define NO_STAMP				"[没有印章]"
#define	NOT_BRIGHT				"[车灯未亮]"
#define VIDEO_B_ERR_DESC        "[未检测到制动尾灯]"
#define FATAL_ERROR				"5"
#define NEED_MANUAL				"4"
#define NORMAL_ERROR			"3"

#define RESULT_OK               "1"

std::vector<VehicleLogo> ResultCollection::logo_list;

int g_b_ret = false; // 南京电子数据交强险结果
extern std::string g_strdzbdjkxlh;

ResultCollection::ResultCollection()
{
    /*
    所有结果必须要有初始值（默认通过）。
    因为如果未收到某个类型的照片，则不能将其加入不合格列表。
    */
    XingShiZheng.b_xingshizheng = true;
    BaoDan.b_baodan = true, BaoDan.b_riqi = true, BaoDan.b_fuben = true;
    JianYanBaoGao.b_jianyanbaogao = true, JianYanBaoGao.b_jianyan_info = true;
    JianYanBiao_YiQi.b_jianyanbaogao_yiqi = true, JianYanBiao_YiQi.b_jianyanjielun = true;
    WeiTuoShu.b_weituoshu = true;
    ZuoQianFang.b_chebiao = ZuoQianFang.b_chepai = ZuoQianFang.b_sanjiaojia = true, ZuoQianFang.date_stamp = "";
    YouHouFang.b_chebiao = YouHouFang.b_chepai = YouHouFang.b_sanjiaojia = true, YouHouFang.date_stamp = "";
    CheJiaHao.b_chejiahao = true;
    AnQuanDai.b_anquandai = true;

    V_ZuoQianFang.b_chepai = true;
    V_YouHouFang.b_chepai = true;
    V_ZuoDengGuang.b_chepai = V_ZuoDengGuang.b_human_clear = V_ZuoDengGuang.b_light_on = V_ZuoDengGuang.b_tester_move = true;
    V_YouDengGuang.b_chepai = V_YouDengGuang.b_human_clear = V_YouDengGuang.b_light_on = V_YouDengGuang.b_tester_move = true;
    V_YiZhouZhiDong.b_chepai = V_YiZhouZhiDong.b_yizhou = V_YiZhouZhiDong.b_human_clear =  true;
    V_ErZhouZhiDong.b_chepai = V_ErZhouZhiDong.b_human_clear = V_ErZhouZhiDong.b_erzhou  = true;
    V_ZhuCheZhiDong.b_bounce_up = V_ZhuCheZhiDong.b_chepai = V_ZhuCheZhiDong.b_human_clear = V_ZhuCheZhiDong.b_zhuche = true;
    V_DiPan.b_human = true;

    IsNewVehicle = FALSE;
    Found_CheBiao = TRUE;
    dbbhgs = 0;
    DiPanGongWei_Video = 0;	/* -1--不通过，0--没有处理“底盘工位”视频，1--通过  */

    ZuoQianFang_A = false;
    TaYinMo_J = false;
}

ResultCollection::~ResultCollection()
{
    ;
}
_ZhaoPianZL ZhaoPianZL;
std::string ResultCollection::doAnalyse(vehicle_inf *p_vehicle_inf)
{
    int ZuoQian = -1;
    int YouHou = -1;

    int DiPan_KaiShi = -1;
    int DiPan_JieShu = -1;

    int YiZhou = -1;
    int ErZhou = -1;

    int ZuoDeng = -1;
    int YouDeng = -1;

    int WeiQi = -1;
    int WeiQi2 = -1;


    /* 处理视频 */
    if (BINZHOU != g_CheckItem.City)
    {
        for (unsigned int i = 0; i < p_vehicle_inf->m_splist.size(); i++) {
            if (p_vehicle_inf->m_splist[i].local_path == "TBD") {
                _dbbhg_list v_dbhhg_list;
                v_dbhhg_list.zpid = "";
                v_dbhhg_list.zptype = p_vehicle_inf->m_splist[i].sptype;
                v_dbhhg_list.dbbhg_desc = "[";
                v_dbhhg_list.dbbhg_desc += p_vehicle_inf->m_splist[i].dzzl;
                v_dbhhg_list.dbbhg_desc += "]:";
                v_dbhhg_list.dbbhg_desc += RESOURCE_ERR_DESC;
                v_dbhhg_list.dbresult = NEED_MANUAL;
                p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);

                continue;
            }
            else if (p_vehicle_inf->m_splist[i].spzl == "V0322")
            {
                doAnalyse_V_YiZhouZhiDong(p_vehicle_inf, i);
            }
            else if (p_vehicle_inf->m_splist[i].spzl == "V0348")
            {
                doAnalyse_V_ErZhouZhiDong(p_vehicle_inf, i);
            }
            else if (p_vehicle_inf->m_splist[i].spzl == "V0111")
            {
                doAnalyse_V_ZuoQianFang(p_vehicle_inf, i);
            }
            else if (p_vehicle_inf->m_splist[i].spzl == "V0112")
            {
                doAnalyse_V_YouHouFang(p_vehicle_inf, i);
            }
            else if (p_vehicle_inf->m_splist[i].spzl == "V0321")
            {
                doAnalyse_V_ZuoDengGuang(p_vehicle_inf, i);
            }
            else if (p_vehicle_inf->m_splist[i].spzl == "V0352")
            {
                doAnalyse_V_YouDengGuang(p_vehicle_inf, i);
            }
            else if (p_vehicle_inf->m_splist[i].spzl == "V0323")
            {
                doAnalyse_V_DiPan(p_vehicle_inf, i);
            }
            else if (p_vehicle_inf->m_splist[i].spzl == "V0351")
            {
                doAnalyse_V_ZhuCheZhiDong(p_vehicle_inf, i);
            }
            //        else if (p_vehicle_inf->m_splist[i].spzl.find("HK_brakeh") != -1)
            //        {
            //            doAnalyse_V_PingBanZhuChe(p_vehicle_inf, i);
            //        }
            else if (p_vehicle_inf->m_splist[i].spzl.find("B") != string::npos && p_vehicle_inf->m_splist[i].spzl.find("B1") == string::npos)
            {
                doAnalyse_V_YiZhouZhiDong(p_vehicle_inf, i);
            }
            else if (p_vehicle_inf->m_splist[i].spzl.find("B1") != string::npos)
            {
                doAnalyse_V_ErZhouZhiDong(p_vehicle_inf, i);
            }
            else if (p_vehicle_inf->m_splist[i].spzl.find("F1") != string::npos)
            {
                doAnalyse_V_ZuoQianFang(p_vehicle_inf, i);
            }
            else if (p_vehicle_inf->m_splist[i].spzl.find("F2") != string::npos)
            {
                doAnalyse_V_YouHouFang(p_vehicle_inf, i);
            }
            else if (p_vehicle_inf->m_splist[i].spzl.find("H") != string::npos)
            {
                doAnalyse_V_DengGuang(p_vehicle_inf, i);
            }
            else if (p_vehicle_inf->m_splist[i].spzl.find("DC") != string::npos)
            {
                doAnalyse_V_DiPanDongTai(p_vehicle_inf, i);
            }
            else if (p_vehicle_inf->m_splist[i].spzl.find("C") != string::npos || p_vehicle_inf->m_splist[i].spzl.find("C1") != string::npos)
            {
                doAnalyse_V_DiPan(p_vehicle_inf, i);
            }
            else
            {
                doAnalyse_Others(p_vehicle_inf, false, i);
            }
        }
    }

    std::string wrwhm("0209"), jyb_yq, wts("0208"),jyb_rg,xsz_bk,mszm("0206"),bxd("0203") ,dchp("0164"),cyjlb("0205"),jyb_bk("0298"),qxjcbg("0213"),cjhyj,hhp("0168"),jybg("0204"),jqx2;

    std::string jyhgzm; /* 检验合格证明 */
    std::string rxbt = "";

    if(g_CheckItem.City == CHONGQING) {
        jyb_yq= std::string("0213");
        qxjcbg = "";
        wrwhm = std::string("0258");
    } else if(g_CheckItem.City == WUHAN) {
        wrwhm = std::string("0265");
    } else if(g_CheckItem.City == SUZHOU) {
        wrwhm = std::string("0210");
    } else if(g_CheckItem.City == BAODING) {
        wrwhm = std::string("0212");
    } else if(g_CheckItem.City == NINGBO) {
        jyb_yq= std::string("0297");
        xsz_bk= std::string("0299");
    } else if (g_CheckItem.City == NANNING) {
        wrwhm = std::string("0224");
        wts = std::string("0222");
        bxd = "";
        dchp = "";
        jyb_rg = std::string("0227");
        xsz_bk = std::string("0203");
    } else if (g_CheckItem.City == QINGHAI) {
        wrwhm = std::string("0290");
    } else if (g_CheckItem.City == SHENZHEN) {
        wrwhm = std::string("0209");
        jyb_rg = std::string("0259");
        xsz_bk= std::string("0261");
    } else if (g_CheckItem.City == HULUNBEIER) {
        wrwhm = std::string("0209");
        mszm = std::string("0210");
        xsz_bk= std::string("0206");
    } else if (g_CheckItem.City == TIANJIN) {
        wrwhm = std::string("0210");
        mszm=std::string("0206");
        xsz_bk=std::string("0209");
        cjhyj=std::string("0168");
        hhp="";
    } else if (g_CheckItem.City == ZHOUKOU) {
        wrwhm = std::string("0298");
        xsz_bk = std::string("0296");
        jyb_bk = "";
    } else if (g_CheckItem.City == HENGSHUI) {
        wrwhm = std::string("0213");
        qxjcbg = "";
        xsz_bk= std::string("0214");
    } else if (g_CheckItem.City == ANSHUN) {
        xsz_bk= std::string("0214");
        jyb_rg = std::string("0297");
        jyb_yq = std::string("0204");
        jybg = std::string("0254");
        jqx2 =std::string("0210");
        rxbt = std::string("0119");
    } else if (g_CheckItem.City == PUTIAN) {
        cyjlb="";
        xsz_bk= std::string("0205");
        wrwhm= std::string("0213");
        qxjcbg = "";
        jyb_rg = std::string("0209");
        jyb_yq = std::string("0210");
    } else if (g_CheckItem.City == FOSHAN) {
        bxd = "0203";
        xsz_bk = "0256";
        wts = "0208";
        jyb_yq = "0258";
        wrwhm = "0297";
    } else if (g_CheckItem.City == ZHAOTONG) {
        xsz_bk = "0261";
    }  else if (g_CheckItem.City == NANJING) {
        jyhgzm= "0212";
    }  else if (g_CheckItem.City == FUZHOU2) {
        xsz_bk = "0213";
        wrwhm = "0298";
        wts = "0207";
    }
    else {
        ;
    }

    /* 处理照片 */
    for (unsigned int i = 0; i < p_vehicle_inf->m_zplist.size(); i++) {
        if (p_vehicle_inf->m_zplist[i].local_path == "TBD") {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
            v_dbhhg_list.dbbhg_desc = "照片[";
            v_dbhhg_list.dbbhg_desc += p_vehicle_inf->m_zplist[i].zpid;
            v_dbhhg_list.dbbhg_desc += "]:";
            v_dbhhg_list.dbbhg_desc += RESOURCE_ERR_DESC;
            v_dbhhg_list.dbresult = NEED_MANUAL;
            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);

            continue;
        }

        if (g_CheckItem.City == PUTIAN) {
            /* 莆田车管所要求只审核以下类型的照片，其它照片显示未知即可 */
            std::vector<std::string> photo_list = {
                "0201", "0202", "0203", "0204", "0205", "0207", "0208", "0209",
                "0111", "0112", "0113", "0157", "0210", "0213"
            };

            unsigned int j;
            for (j = 0; j < photo_list.size(); j++) {
                if (p_vehicle_inf->m_zplist[i].zptype == photo_list[j]) {
                    break;
                }
            }

            if (j == photo_list.size()) {
                doAnalyse_Others(p_vehicle_inf, true, i);
                continue;
            }
        }

        if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.XingShiZheng) {//0201 - 机动车行驶证
            doAnalyse_XingShiZheng(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.ShenQingBiao) {//0202-机动车牌证申请表
            doAnalyse_ShenQingDan(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.JiaoQiangXian) {//0203 - 机动车交通事故责任强制保险凭证
            doAnalyse_BaoDan(p_vehicle_inf, i);
        } else if ((p_vehicle_inf->m_zplist[i].zptype=="0206")&&(g_CheckItem.City==ZHONGSHAN)) {  //0206 - 中山车船税或完税证明为交强险单,所以调用交强处理险函数
            doAnalyse_ZhongShanWanShui(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == jqx2) {
            doAnalyse_AnShunBaoDan(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.JianYanBaoGao) {
            doAnalyse_JianYanBaoGao(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.WanShuiZhengMing) {
            doAnalyse_NaMianShuiZhengMing(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.WeiTuoTongZhiShu) {
            doAnalyse_HeGeTongZhiShu(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == jyhgzm) {
            doAnalyse_JianYanHeGeZhengMing(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.ShenFenZheng) {
            doAnalyse_ShenFenZheng(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.ShenFenZhengBeiMian) {
            doAnalyse_ShenFenZhengBeiMian(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.JianYanBaoGao_YiQi) {
            doAnalyse_JianYanbiao_YiQi(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.JianYanBaoGao_RenGong) {   //  rengong检验表 fix me
            doAnalyse_JianYanbiao_RenGong(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.JianYanBiaoBeiMian) {
            doAnalyse_JianYanbiaoBeiMian(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.WeiTuoShu) {
            doAnalyse_WeiTuoShu(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.GaoZhiShu) {
            doAnalyse_GaoZhiShu(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.RongQueShouLi) {
            doAnalyse_RongQueShouLi(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.JianCeQuXianBaoGao) {
            doAnalyse_QuXianBaoGao(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.WeiXiangNeiBu) {
            doAnalyse_WeiXiangNeiBu(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.ZuoQianFang) {
            ZuoQian = i;
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.YouHouFang) {
            YouHou = i;
        } else if ((p_vehicle_inf->m_zplist[i].zptype == "0390") && (g_CheckItem.City == FOSHAN)) { //0390 - 车辆左前触发照片（佛山用2018-12-27）
            // 暂时只检测车牌，和左前方拍摄时间10s检测后面看需求
            doAnalyse_zqf_yhf_cjh_cf(p_vehicle_inf, i);
        } else if ((p_vehicle_inf->m_zplist[i].zptype == "0391") && (g_CheckItem.City == FOSHAN)) { //0391 - 车辆右后触发照片（佛山用2018-12-27）
            // 暂时只检测车牌，和右后方拍摄时间10s检测后面看需求
            doAnalyse_zqf_yhf_cjh_cf(p_vehicle_inf, i);
        } else if ((p_vehicle_inf->m_zplist[i].zptype == "0392") && (g_CheckItem.City == FOSHAN)) { //0392 - 车架号触发照片（佛山用2018-12-27）
            // 暂时只检测车牌，和车架号拍摄时间10s检测后面看需求
            doAnalyse_zqf_yhf_cjh_cf(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.ZuoFang) {
            doAnalyse_ZuoYou(p_vehicle_inf, true, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.CheJiaHao) {
            doAnalyse_CheJiaHao(p_vehicle_inf, i);
        } else if(g_CheckItem.City == FUZHOU2 && p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.CheLiangCeMian){
            doAnalyse_CheLiangCeMian2(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.CheLiangCeMian) {
            doAnalyse_CheLiangCeMian(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == cjhyj) {
            doAnalyse_CheJiaHaoYuanJing(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.QianHaoPai) {
            doAnalyse_QianHaoPai(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.HouHaoPai) {
            doAnalyse_HouHaoPai(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.CheLiangBeiMian) {
            doAnalyse_CheLiangBeiMian(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.AnQuanDai) {
            doAnalyse_AnQuanDai(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.CheJiaHaoUG) {  //0120 - 连云港玻璃下车架号
            doAnalyse_CheJiaHaoUG(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.CheLiangMingPai) {  //0114 - 连云港车辆名牌
            doAnalyse_CheLiangMingPai(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.XingShiZhengBeiMian) {
            doAnalyse_XingShiZhengBeiMian(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.ZuoDengGuang) {
            ZuoDeng = i;
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.YouDengGuang) {
            YouDeng = i;
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.ChaYanJiLu) {    // 查验记录表
            if(g_CheckItem.City==NINGBO)
            {
                unsigned int j;
                for (j = 0; j < p_vehicle_inf->m_zplist.size(); j++)
                {
                  if (p_vehicle_inf->m_zplist[j].zptype == "0298") { // 查验记录表
                    doAnalyse_ChaYanJiLu(p_vehicle_inf, i , true);
                    break;
                  }
                  if(j==(p_vehicle_inf->m_zplist.size()-1))
                  {
                    doAnalyse_ChaYanJiLu(p_vehicle_inf, i , false);
                    break;
                  }
                }
            }
            else
            {
            doAnalyse_ChaYanJiLu(p_vehicle_inf, i ,false);
            }
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.WeiQiJianYan) {
            WeiQi =i;
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.WeiQiJianYan2) {
            WeiQi2 = i;
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.YiZhouZhiDong) {
            YiZhou = i;
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.ErZhouZhiDong) {
            ErZhou = i;
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.DiPanDongTaiKaiShi) {
            DiPan_KaiShi = i;
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.DiPanDongTaiJieShu) {
            DiPan_JieShu = i;
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.DiPanBuJian) {
            doAnalyse_DiPan(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == "0328") {

        } else if (p_vehicle_inf->m_zplist[i].zptype == "0347") {

        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.ZhuCheZhiDong) {
            if (g_CheckItem.City != NINGBO && g_CheckItem.City != NANJING && g_CheckItem.City != FUZHOU2) {
                doAnalyse_ZhuCheZhiDong(p_vehicle_inf, i);
            }
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.MieHuoQi) {
            doAnalyse_MieHuoQi(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.YingJiChui) {
            doAnalyse_YingJiChui(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.JiLuYi) {
            doAnalyse_JiLuYi(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == rxbt ) {
            doAnalyse_RouXingBiaoQian(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.HeDingZaiKe) {
            doAnalyse_HeDingZaiKe(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.FuZhuZhiDong) {
            doAnalyse_FuZhuZhiDong(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.ABS) {
            doAnalyse_ABS(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.ZuoQianLun) {
            doAnalyse_ZuoQianLun(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.YouQianLun) {
            doAnalyse_YouQianLun(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.CheXiang) {    
            doAnalyse_CheXiang(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.HouPaiCheXiang) {
            doAnalyse_HouPaiCheXiang(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.HouPaiCheXiang2) {
            doAnalyse_HouPaiCheXiang2(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.CeHuaGongWei) {
            doAnalyse_CeHuaGongWei(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.WaiKuoQianMian) {
            doAnalyse_WaiKuoQianMian(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.WaiKuoCeMian) {
            doAnalyse_WaiKuoCeMian(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.DaCheHaoPai) {
            doAnalyse_DaCheHaoPai(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.ChaYanJiLu) {   // 人工检验表
            doAnalyse_ChaYanJiLu(p_vehicle_inf, i ,false);
        }else if(p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.QianHaoPaiTeXie){
            doAnalyse_QianHaoPaiTeXie(p_vehicle_inf,i);
        }else if(p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.HouHaoPaiTeXie){
            doAnalyse_HouHaoPaiTeXie(p_vehicle_inf,i);
        }
        // 苏州事后审核小车处理
        else if (p_vehicle_inf->m_zplist[i].zptype == "01") {
            doAnalyse_WeiXiangNeiBu(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == "02") {
            doAnalyse_ZuoQianLun(p_vehicle_inf, i);
        } else if (p_vehicle_inf->m_zplist[i].zptype == "03") {
            doAnalyse_YouQianLun(p_vehicle_inf, i);
        }
        // 苏州事后审核大车花纹处理
        else if ((p_vehicle_inf->m_zplist[i].zptype == "04") || (p_vehicle_inf->m_zplist[i].zptype == "05")) { // 大车一轴轮胎花纹
            doAnalyse_DaCheLunTaiHuaWen(p_vehicle_inf, i, "04");
        } else if ((p_vehicle_inf->m_zplist[i].zptype == "06") || (p_vehicle_inf->m_zplist[i].zptype == "07")) { // 大车二轴轮胎花纹
            doAnalyse_DaCheLunTaiHuaWen(p_vehicle_inf, i, "06");
        } else if ((p_vehicle_inf->m_zplist[i].zptype == "08") || (p_vehicle_inf->m_zplist[i].zptype == "09")) { // 大车三轴轮胎花纹
            doAnalyse_DaCheLunTaiHuaWen(p_vehicle_inf, i, "08");
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.QianLunZhaoPian) { // 前轮照片
            doAnalyse_QianHouLunTaiZhaoPian(p_vehicle_inf, i, true);
        } else if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.HouLunZhaoPian) { // 后轮照片
            doAnalyse_QianHouLunTaiZhaoPian(p_vehicle_inf, i, false);
        } else if (p_vehicle_inf->m_zplist[i].zptype == "0210" && g_CheckItem.City == NANCHONG) {
            doAnalyse_YingYeZhiZhao(p_vehicle_inf, i);
        } else if(p_vehicle_inf->m_zplist[i].zptype == "0214" && g_CheckItem.City == YICHUN) {
            doAnalyse_YingYeZhiZhao_YiChun(p_vehicle_inf, i);
        } else if (g_CheckItem.City == QINGHAI && (p_vehicle_inf->m_zplist[i].zptype == "0199" || p_vehicle_inf->m_zplist[i].zptype == "0345")) {
            /*
             * 青海:
             * 0199：外检其它照片
             * 0345：坡道驻车照片
             * 直接判定通过
            */
        } else if (g_CheckItem.City == QINGHAI && p_vehicle_inf->m_zplist[i].zptype == "0299") {
            doAnalyse_LuShiJiLuDan(p_vehicle_inf, i);
        } else if (g_CheckItem.City == QINGHAI && p_vehicle_inf->m_zplist[i].zptype == "0341") {
            doAnalyse_LuShiKaiShi(p_vehicle_inf, i);
        } else if (g_CheckItem.City == QINGHAI && p_vehicle_inf->m_zplist[i].zptype == "0343") {
            doAnalyse_LuShiJieShu(p_vehicle_inf, i);
        } else if (g_CheckItem.City == DEZHOU && p_vehicle_inf->m_zplist[i].zptype == "0150") {/*德州前轮胎花纹*/
            doAnalyse_QianLunTaiHuaWen(p_vehicle_inf, i);
        } else if (g_CheckItem.City == DEZHOU && p_vehicle_inf->m_zplist[i].zptype == "0151") {/*德州后轮胎花纹*/
            doAnalyse_HouLunTaiHuaWen(p_vehicle_inf, i);
        } else if (g_CheckItem.City == ZHAOTONG && p_vehicle_inf->m_zplist[i].zptype == "0298"){/*昭通[0298]机动车外廓尺寸仪器设备记录单*/
            doAnalyse_WaiKuoChiCunJiLuDan(p_vehicle_inf, i);
        } else if (g_CheckItem.City == ZHAOTONG && p_vehicle_inf->m_zplist[i].zptype == "0190"){/*昭通[0190]反光标识检测数据*/
            doAnalyse_FanGuangBiaoShi(p_vehicle_inf, i);
        }else if (g_CheckItem.City == ZHONGSHAN && p_vehicle_inf->m_zplist[i].zptype == "0199"){
            doAnalyse_LiChengBiaoDuShu(p_vehicle_inf,i);
        }else if (g_CheckItem.City == ZHONGSHAN && p_vehicle_inf->m_zplist[i].zptype == "0114"){
            doAnalyse_KeShiQuBoLi(p_vehicle_inf,i);
        }
        else {
            doAnalyse_Others(p_vehicle_inf, true, i);
        }
    }

    if ((ZuoQian != -1) && (YouHou != -1)) {
        doAnalyse_WaiGuan(p_vehicle_inf, ZuoQian, YouHou);
    } else if (ZuoQian != -1) {
        doAnalyse_ZuoYou(p_vehicle_inf, true, ZuoQian);
    } else if (YouHou != -1) {
        doAnalyse_ZuoYou(p_vehicle_inf, false, YouHou);
    }
    if((WeiQi != -1)||(WeiQi2 != -1))
    {
       doAnalyse_WuRanWu(p_vehicle_inf, WeiQi , WeiQi2);
    }

    doAnalyse_DiPanDongTai(p_vehicle_inf, DiPan_KaiShi, DiPan_JieShu);
    doAnalyse_ZhiDongGongWei(p_vehicle_inf, YiZhou, ErZhou);
    doAnalyse_DengGuangGongWie(p_vehicle_inf, ZuoDeng, YouDeng);

    /* 宁波，南京,抚州：如果一轴，二轴中有一张照片的号牌判定是通过的，那么驻车制动的号牌也判定通过 */
    if (g_CheckItem.City == NINGBO || g_CheckItem.City == NANJING || g_CheckItem.City == FUZHOU2) {
        for (int i = 0; i < p_vehicle_inf->m_zplist.size(); i++) {
            if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.ZhuCheZhiDong) {
                doAnalyse_ZhuCheZhiDong(p_vehicle_inf, i);
            }
        }
    }

    char tmp[32];
    itoa(dbbhgs, tmp, 10);
    p_vehicle_inf->m_dbbhgs = std::string(tmp);

//    if (g_CheckItem.City == SUZHOU) {
//        /* 苏州车辆类型同样定义于vehicle_check_service.cpp中，修改时需要同时修改 */
//        std::vector<std::string> CheLiangLeiXing_SZ = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38",
//                                                       "K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48", "K49"};

//        bool BigVehicle = false;

//        unsigned int k;
//        for (k = 0; k < CheLiangLeiXing_SZ.size(); k++) {
//            if (p_vehicle_inf->m_cllx == CheLiangLeiXing_SZ[k]) {
//                break;
//            }
//        }

//        if (k == CheLiangLeiXing_SZ.size()) {
//            BigVehicle = true;
//        }

//        /* “苏州”小车的所有结果改为只有1和5，2018-06-13 */
//        if (!BigVehicle) {
//            for (unsigned int i = 0; i < p_vehicle_inf->m_dbbhglist.size(); i++) {
//                p_vehicle_inf->m_dbbhglist[i].dbresult = FATAL_ERROR;
//            }
//        }
//    }

    std::string conclusion;
    conclusion = makeConclusion(p_vehicle_inf);
    return conclusion;
}

void ResultCollection::doAnalyse_XingShiZheng(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    /* 新车不判定行驶证 */
    if(g_CheckItem.City == TIANJIN)
    {
        if (p_vehicle_inf->is_new_vehicle) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
            v_dbhhg_list.dbresult = NEED_MANUAL;
            v_dbhhg_list.dbbhg_desc = "行驶证-照片:";
            v_dbhhg_list.dbbhg_desc += "[新车不判定行驶证]";
            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);

            return;
        }
    }
    else
    {
        if (IsNewVehicle) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
            v_dbhhg_list.dbresult = NEED_MANUAL;
            v_dbhhg_list.dbbhg_desc = "行驶证-照片:";
            v_dbhhg_list.dbbhg_desc += "[新车不判定行驶证]";
            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);

            return;
        }
    }

    const unsigned short us_add_num = 1;
    unsigned short us_num = p_vehicle_inf->get_count();
    if (0 != us_num)
        p_vehicle_inf->set_count(0);
    DATA_PRINT(LEVEL_INFO, "into doAnalyse_XingShiZheng count = %hu\n", us_num);

    if (g_CheckItem.picture.XingShiZheng.ChePai) {
        if (!XingShiZheng.b_chepai&&!IsNewVehicle) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += HPHM_ERROR;
        }
        else
            p_vehicle_inf->set_count_add_num(us_add_num);
    }

    if (g_CheckItem.picture.XingShiZheng.CheJiaHao) {
        if (!XingShiZheng.b_chejiahao) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += CHE_JIA_HAO_ERROR;
        }
        else
            p_vehicle_inf->set_count_add_num(us_add_num);
    }

    if (g_CheckItem.picture.XingShiZheng.BianHao) {

        /* 行驶证“发证日期”在2008-10-01以前的不检查 */
        try {
            std::string fzrq = formatingDate(p_vehicle_inf->m_fzrq);

            if (fzrq != "") {
                int n_fzrq = std::stoi(fzrq);

                if (n_fzrq >= 20081001) {
                    if (!XingShiZheng.b_tiaoxingma) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[行驶证编号（条形码）不正确]";
                    }
                    else
                        p_vehicle_inf->set_count_add_num(us_add_num);
                }
            }
        } catch (const std::exception &e) {
            std::cout << "Error: " << e.what() << std::endl;
            DATA_PRINT(LEVEL_ERROR, "fzrq formating fail: %s \n", p_vehicle_inf->m_fzrq.c_str());
        }
    }

    if (g_CheckItem.picture.XingShiZheng.FaZhengRiQi) {

        /* 西安：发证日期和注册日期两个信息有一个对就可以 */
        if (g_CheckItem.City == XIAN) {
            if (!XingShiZheng.b_fazhengriqi && !XingShiZheng.b_zhuceriqi) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[行驶证发证日期不正确][注册日期不正确]";
            }
        } else {
            if (!XingShiZheng.b_fazhengriqi) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[行驶证发证日期不正确]";
            }
            else
                p_vehicle_inf->set_count_add_num(us_add_num);
        }
    }

//    if (g_CheckItem.picture.XingShiZheng.ShenFenZheng) {
//        if (!XingShiZheng.) {
//            ok = false;
//            dbresult = FATAL_ERROR;
//            dbbhg_desc += "[未识别到身份证]";
//        }
//        else
//            p_vehicle_inf->set_count_add_num(us_add_num);
//    }

    if (g_CheckItem.picture.XingShiZheng.CheLiang) {
        if (!XingShiZheng.b_cheliang) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[未检测到行驶证主页反面车辆]";
        }
        else
            p_vehicle_inf->set_count_add_num(us_add_num);
    }
    //襄阳增加车辆逾期审验功能
    if(g_CheckItem.City == XIANGYANG)
    {
        if(p_vehicle_inf->m_zt.find("Q") != std::string::npos)
        {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[车辆逾期未审核]";
        }
    }

    if (g_CheckItem.City == NANCHONG) {
        if (!XingShiZheng.b_chetype) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[车辆类型不正确]";
        }

        if (!XingShiZheng.b_renshu) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[载客人数不正确]";
        }
    }

    if(g_CheckItem.City == LAIBIN)
    {
        if (!XingShiZheng.b_qiangzhibaofie) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[强制报废日期不正确]";
        }
    }

    if(g_CheckItem.City == ZHANGJIAJIE)
    {
        if((p_vehicle_inf->m_syxz.find("A")==std::string::npos)&&(p_vehicle_inf->m_cllx.find("H")!=std::string::npos))
        {
            if (!XingShiZheng.b_qiangzhibaofie) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[强制报废日期不正确]";
            }

        }
    }

    DATA_PRINT(LEVEL_INFO, " doAnalyse_XingShiZheng count = %hu\n", us_num);
    if ((us_num>=3) && (JIAOZUO == g_CheckItem.City))
        ok = true;

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "行驶证-照片:";

        if (XingShiZheng.b_pic_quality) {
            v_dbhhg_list.dbresult = FATAL_ERROR;
            v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        } else {
            v_dbhhg_list.dbresult = NEED_MANUAL;
            v_dbhhg_list.dbbhg_desc += PICTURE_NOT_STANDARD;
        }

        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}

void ResultCollection::doAnalyse_ShenQingDan(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if (g_CheckItem.picture.ShenQingBiao.ShouJi_BenRen) {
        int ret = isMobileNumber(ShenQingDan.telephone_suoyouren);
        if (ret == -1) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[无所有人手机号码]";
        } else if (ret == 0) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[所有人手机号码不合法]";
        }
    }

    if (g_CheckItem.picture.ShenQingBiao.ShouJi_DaiLi) {
        int ret = isMobileNumber(ShenQingDan.telephone_dailiren);
        if (ret == 0) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[代理人手机号码不合法]";
        }
    }

    if (g_CheckItem.picture.ShenQingBiao.ChePai) {
        if (!ShenQingDan.b_chepai&&!IsNewVehicle) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += HPHM_ERROR;
        }
    }

    if (g_CheckItem.City == CHONGQING)
    {
        if (ShenQingDan.b_shenqingbiao) {
            if (g_CheckItem.picture.ShenQingBiao.is_CheLiangType) {
                if(!ShenQingDan.b_chepai_type) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[车辆类型不正确]";
                }
            }
            if (g_CheckItem.picture.ShenQingBiao.is_YouBian) {
                if(!ShenQingDan.b_postcode) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[邮编未填写]";
                }
            }
            if (g_CheckItem.picture.ShenQingBiao.is_DiZhi) {
                if(!ShenQingDan.b_address) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[联系地址未填写]";
                }
            }
        } else {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += PICTURE_NOT_STANDARD;
        }
    }

    if(g_CheckItem.City == ANSHUN)
    {
        if (g_CheckItem.picture.ShenQingBiao.is_DiZhi) {
            if(!ShenQingDan.b_address) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[联系地址未填写]";
            }
        }
        if (g_CheckItem.picture.ShenQingBiao.HaoPaiZhongLei) {
            if(!ShenQingDan.b_chepai_type) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[号牌种类不正确]";
            }
        }

    }

    if (g_CheckItem.picture.ShenQingBiao.CheJiaHao) {
        /* 目前（09-21）没有车架号的结果，但是有传入车架号 */
        //FixMe
    }


    if (g_CheckItem.picture.ShenQingBiao.QianMing) {
        if(g_CheckItem.City == JIUJIANG || g_CheckItem.City == YICHUN)
        {
            if(!ShenQingDan.b_qianming && !ShenQingDan.b_yinzhang)
            {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[没有签名和印章]";
            }
        }
        else if(g_CheckItem.City == FUZHOU2){
            /*1，如果是个人，印章和签名有其一即可。
              2，如果“所有人姓名”大于4个字，认为是公司，则一定要有印章。一个汉字占用3个字节*/
            if(strlen(p_vehicle_inf->m_syr.c_str()) <= 12)
            {
                if(!ShenQingDan.b_qianming && !ShenQingDan.b_yinzhang)
                {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[没有签名或印章]";
                }
            }
            else
            {
                if(g_CheckItem.picture.ShenQingBiao.YinZhang)
                {
                    if(!ShenQingDan.b_yinzhang)
                    {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[没有印章]";
                    }
                }
            }
        }
        else if (g_CheckItem.City == XIANNING)
        {
            if(g_CheckItem.picture.ShenQingBiao.YinZhang)
            {
                if(!ShenQingDan.b_yinzhang && !ShenQingDan.b_qianming)
                {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[没有签名和印章]";
                }
            }
        }
        else {
            if(!ShenQingDan.b_qianming) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += NO_SIGNATURE;
             }
          }
    if(g_CheckItem.City == HULUNBEIER)
    {
        if (g_CheckItem.picture.ShenQingBiao.YinZhang) {
            if (!ShenQingDan.b_yinzhang) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += NO_SIGNATURE;
            }
        }
    }
    }
    if (g_CheckItem.picture.ShenQingBiao.XingMing) {
        if (!ShenQingDan.b_xingming) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[姓名不正确]";
        }
    }

    if (g_CheckItem.picture.ShenQingBiao.JianYanHeGeBiaoZhi) {
        if (!ShenQingDan.b_jianyanhegebiaozhi) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[检验合格标志\"申请\"框没有打钩]";
        }

        if (0 == ShenQingDan.registeringarea_flag)
        {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[检验合格标志\"本地车辆及外地车辆登记地\"均未打钩]";
        }
        else if ("鲁M" == p_vehicle_inf->m_fzjg) // 本地车
        {
            if (1 != ShenQingDan.registeringarea_flag)
            {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "本地车\"在登记地申请\"框没有打钩";
            }
        }
        else
        {
            if (2 != ShenQingDan.registeringarea_flag)
            {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "外地车\"在登记地以外申请\"框没有打钩";
            }
        }
    }

    if (g_CheckItem.City == NINGBO)
    {
        if(p_vehicle_inf->b_jqxdzbd == 2)
        {
            unsigned int j;
            for(j = 0; j< p_vehicle_inf->m_zplist.size() ;j++)
            {
                if(p_vehicle_inf->m_zplist[j].zptype == "0203")
                {
                    break;
                }
            }
            if(j == p_vehicle_inf->m_zplist.size())
            {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += p_vehicle_inf->dzjqxbhgyy;
            }
        }
        if(p_vehicle_inf->b_jqxdzbd == 3)
        {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += p_vehicle_inf->dzjqxbhgyy;
        }
    }

    if ((g_CheckItem.City==BINZHOU) && (!ShenQingDan.b_chepai_type)){
        ok = false;
        dbresult = FATAL_ERROR;
        dbbhg_desc += "[号牌种类不正确]";
    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "牌证申请表-照片:";

        if (ShenQingDan.b_pic_quality) {
            v_dbhhg_list.dbresult = dbresult;
            v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        } else {
            v_dbhhg_list.dbresult = NEED_MANUAL;
            v_dbhhg_list.dbbhg_desc += PICTURE_NOT_STANDARD;
        }
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}

bool fun_in_date(std::string start_date, std::string end_date)
{
    // 2019-03-18
    bool ret = false;
    unsigned int start_year, start_month, start_day, end_year, end_month, end_day;

    start_year = stoi(start_date.substr(0, 4));
    size_t offset1 = start_date.find("-");
    size_t offset2 = start_date.find_last_of("-");
    std::string str_month = start_date.substr(offset1+1, 2);
    std::string str_day = start_date.substr(offset2+1, 2);
    start_month = stoi(str_month);
    start_day = stoi(str_day);
    DATA_PRINT(LEVEL_INFO, "start year-month-day:[%u]-[%u]-[%u].\n",
               start_year, start_month, start_day);

    end_year = stoi(end_date.substr(0, 4));
    offset1 = end_date.find("-");
    offset2 = end_date.find_last_of("-");
    str_month = end_date.substr(offset1+1, 2);
    str_day = end_date.substr(offset2+1, 2);
    end_month = stoi(str_month);
    end_day = stoi(str_day);
    DATA_PRINT(LEVEL_INFO, "end year-month-day:[%u]-[%u]-[%u].\n",
               end_year, end_month, end_day);

    unsigned long current_year, current_month, current_day;
    time_t* mptr_currentSeconds=new time_t;
    time(mptr_currentSeconds);
    struct tm *current_time = localtime(mptr_currentSeconds);  //日历时间转化为本地时间

    current_year = current_time->tm_year+1900;
    current_month = current_time->tm_mon+1;
    current_day = current_time->tm_mday;

    if(start_year > current_year) {
        DATA_PRINT(LEVEL_ERROR, "year outside(start_year) !\n");
        return ret;
    } else if(start_year == current_year) {
        if(start_month > current_month) {
            DATA_PRINT(LEVEL_ERROR, "month outside(start_month) !\n");
            return ret;
        } else if(start_month == current_year) {
            if(start_day > current_day) {
                DATA_PRINT(LEVEL_ERROR, "day outside(start_day) !\n");
                return ret;
            }
        }
    }
    if(end_year < current_year) {
        DATA_PRINT(LEVEL_ERROR, "year outside(end_year) !\n");
        return ret;
    } else if(end_year == current_year) {
        if(end_month < current_month) {
            DATA_PRINT(LEVEL_ERROR, "month outside(end_month) !\n");
            return ret;
        } else if(end_month == current_month) {
            if(end_day < current_day) {
                DATA_PRINT(LEVEL_ERROR, "day outside(end_day) !\n");
                return ret;
            }
        }
    }
    ret = true;
    return ret;
}

void ResultCollection::doAnalyse_BaoDan(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if (g_CheckItem.City == SUZHOU) {
        /*
         * 苏州保单逻辑：
         * if (电子保单有结果) {
         *   最终结果=电子结果and纸质结果
         * } else {
         *   if (销售区域在江苏) {
         *     最终结果=纸质结果
         *   } else {
         *     最终结果=特殊印章结果
         *   }
         * }
        */

        if (g_CheckItem.picture.JiaoQiangXian.DianZiBaoDan) {

            if (p_vehicle_inf->b_jqxdzbd == 3) { /* 电子保单不通过 */
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[电子保单不通过]";
            } else if (p_vehicle_inf->b_jqxdzbd == 2) { /* 未查到电子保单 */

                /* 销售区域不在“江苏” */
                if (!BaoDan.b_xiaoshouquyu) {

                    if (!BaoDan.b_suzhou_zhang) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[没有“保单有效”印章]";
                    }

                    if (!BaoDan.b_sz_zhang_qianzi) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[没有“保单有效”印章内的签名]";
                    }

                    if (!ok) {
                        _dbbhg_list v_dbhhg_list;
                        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
                        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
                        v_dbhhg_list.dbbhg_desc = "交强险-照片:";

                        if (BaoDan.b_pic_quality) {
                            v_dbhhg_list.dbresult = dbresult;
                            v_dbhhg_list.dbbhg_desc += dbbhg_desc;
                        } else {
                            v_dbhhg_list.dbresult = NEED_MANUAL;
                            v_dbhhg_list.dbbhg_desc += PICTURE_NOT_STANDARD;
                        }

                        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
                        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                            dbbhgs++;
                        }
                    }

                    return;
                }
            }
        }

        if (g_CheckItem.picture.JiaoQiangXian.FuBen) {
            if (!BaoDan.b_fuben) {
                ok = false;

                if (g_CheckItem.City == BAODING) {
                    dbresult = FATAL_ERROR;
                } else {
                    dbresult = NEED_MANUAL;
                }

                dbbhg_desc += "[不是副本文件]";
            }
        }

        if (g_CheckItem.picture.JiaoQiangXian.YouXiaoQi) {
            if (!BaoDan.b_riqi) {
                ok = false;

                if (g_CheckItem.City == BAODING) {
                    dbresult = FATAL_ERROR;
                } else {
                    dbresult = NEED_MANUAL;
                }

                dbbhg_desc += "[检验日期不在保险有效期内]";
            }
        }

        if (g_CheckItem.picture.JiaoQiangXian.ChePai){
            if (!BaoDan.b_chepai&&!IsNewVehicle) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += HPHM_ERROR;
            }
        }

        if (g_CheckItem.picture.JiaoQiangXian.CheJiaHao){
            if (!BaoDan.b_chejiahao) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += CHE_JIA_HAO_ERROR;
            }
        }

        if(g_CheckItem.picture.JiaoQiangXian.GongZhang){
            if (!BaoDan.b_hongzhang) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += NO_STAMP;
            }
        }

        if (g_CheckItem.picture.JiaoQiangXian.CheChuanShui) {
            if (p_vehicle_inf->m_rlzl != "C") {
                if (!BaoDan.b_chechuanshui) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[没有缴纳车船税]";
                }
            }
        }

        if (g_CheckItem.picture.JiaoQiangXian.FaDongJiHao) {
            if (!BaoDan.b_fadongjihao) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[发动机号不对]";
            }
        }

//        if(p_vehicle_inf->m_fzjg.find("苏") == -1) {/* 外省车标记 */
//            if (g_CheckItem.picture.JiaoQiangXian.SuZhouYinZhang) {
//                if (!BaoDan.b_suzhou_zhang) {
//                    ok = false;
//                    dbresult = FATAL_ERROR;
//                    dbbhg_desc += "[没有外地确认章]";
//                }
//            }
//        }

        if (!ok) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
            v_dbhhg_list.dbbhg_desc = "交强险-照片:";

            if (BaoDan.b_pic_quality) {
                v_dbhhg_list.dbresult = dbresult;
                v_dbhhg_list.dbbhg_desc += dbbhg_desc;
            } else {
                v_dbhhg_list.dbresult = NEED_MANUAL;
                v_dbhhg_list.dbbhg_desc += PICTURE_NOT_STANDARD;
            }

            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }
        }
    }
    else if (g_CheckItem.City==SHENZHEN)
    {
            if (BaoDan.b_dianzi) {
                if(g_CheckItem.picture.JiaoQiangXian.ShenZhenDianZiBaoDan)
                {
                    if (!BaoDan.b_jiaoqiangxian) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[不是交强险]";
                    }
                }
                if(g_CheckItem.picture.JiaoQiangXian.CheJiaHao)
                {
                    if (!BaoDan.b_chejiahao) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[电子保单车架号错误]";
                    }
                }
                if(g_CheckItem.picture.JiaoQiangXian.FaDongJiHao)
                {
                    if (!BaoDan.b_fadongjihao) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[电子保单发动机号不对]";
                    }
                }
                if(g_CheckItem.picture.JiaoQiangXian.YouXiaoQi)
                {
                    if (!BaoDan.b_riqi) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[电子保单检验日期不在保险有效期内]";
                    }
                }

            }
            else
            {
                if(g_CheckItem.picture.JiaoQiangXian.CheJiaHao)
                {
                    if (!BaoDan.b_chejiahao) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc +=CHE_JIA_HAO_ERROR;
                    }
                }
                if(g_CheckItem.picture.JiaoQiangXian.FaDongJiHao)
                {
                    if (!BaoDan.b_fadongjihao) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[发动机号不对]";
                    }
                }
                if(g_CheckItem.picture.JiaoQiangXian.YouXiaoQi)
                {
                    if (!BaoDan.b_riqi) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[检验日期不在保险有效期内]";
                    }
                }
                if(g_CheckItem.picture.JiaoQiangXian.GongZhang){
                    if (!BaoDan.b_hongzhang) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += NO_STAMP;
                    }
                }
                if(g_CheckItem.picture.JiaoQiangXian.CheChuanShui){
                    if (!BaoDan.b_chechuanshui) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[没有缴纳车船税]";
                    }
                }
            }
            if (!ok) {
                _dbbhg_list v_dbhhg_list;
                v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
                v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
                v_dbhhg_list.dbbhg_desc = "交强险-照片:";

                if (BaoDan.b_pic_quality) {
                    v_dbhhg_list.dbresult = dbresult;
                    v_dbhhg_list.dbbhg_desc += dbbhg_desc;
                } else {
                    v_dbhhg_list.dbresult = NEED_MANUAL;
                    v_dbhhg_list.dbbhg_desc += PICTURE_NOT_STANDARD;
                }

                p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
                if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                    dbbhgs++;
                }
            }


    } else if(g_CheckItem.City == PUTIAN) {
        if((BaoDan.b_pic_quality)||(BaoDan.b_fuben)||(BaoDan.b_chaoben))
        {
             DATA_PRINT(LEVEL_INFO, "保单识别成功\n");
        }
        else
        {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[不是保险单]";
        }
        if (g_CheckItem.picture.JiaoQiangXian.YouXiaoQi) {
            if (!BaoDan.b_riqi) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[检验日期不在保险有效期内]";
            }
        }

        if (g_CheckItem.picture.JiaoQiangXian.ChePai){
            if (!BaoDan.b_chepai&&!IsNewVehicle) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += HPHM_ERROR;
            }
        }

        if (g_CheckItem.picture.JiaoQiangXian.CheJiaHao){
            if (!BaoDan.b_chejiahao) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += CHE_JIA_HAO_ERROR;
            }
        }


        if (g_CheckItem.picture.JiaoQiangXian.CheChuanShui) {
            if (p_vehicle_inf->m_rlzl == "C") {	/* 电动 */
//                if (BaoDan.b_chechuanshui) {
//                    ok = false;
//                    dbresult = FATAL_ERROR;
//                    dbbhg_desc += "[电动车不应该缴纳车船税]";
//                } else {
//                    //FixMe,需要车船税结果
////                    if (0) {

////                    }
//                }
            } else {							/* 其他 */
                if (!BaoDan.b_chechuanshui) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    //dbbhg_desc += "[非电动车没有缴纳车船税]";
                    dbbhg_desc += "[没有缴纳车船税]";
                }
            }
        }

        if (g_CheckItem.picture.JiaoQiangXian.FaDongJiHao) {
            if (!BaoDan.b_fadongjihao) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[发动机号不对]";
            }
        }
        if(g_CheckItem.picture.JiaoQiangXian.GongZhang){
            if (!BaoDan.b_hongzhang) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += NO_STAMP;
            }
        }





        if (!ok) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
            v_dbhhg_list.dbbhg_desc = "交强险-照片:";

            if (BaoDan.b_pic_quality) {
                v_dbhhg_list.dbresult = dbresult;
                v_dbhhg_list.dbbhg_desc += dbbhg_desc;
            } else {
                v_dbhhg_list.dbresult = NEED_MANUAL;
                v_dbhhg_list.dbbhg_desc += PICTURE_NOT_STANDARD;
            }

            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }
        }
    } else if(g_CheckItem.City == TIANJIN){
        if (g_CheckItem.picture.JiaoQiangXian.FuBen) {
            if (!BaoDan.b_fuben) {
                ok = false;

                if (g_CheckItem.City == BAODING) {
                    dbresult = FATAL_ERROR;
                } else {
                    dbresult = NEED_MANUAL;
                }

                dbbhg_desc += "[不是副本文件]";
            }
        }

        if (g_CheckItem.picture.JiaoQiangXian.YouXiaoQi) {
            if (!BaoDan.b_riqi) {
                ok = false;
                dbresult = NEED_MANUAL;
                dbbhg_desc += "[检验日期不在保险有效期内]";
            }
        }

        if (g_CheckItem.picture.JiaoQiangXian.ChePai){
            if (!BaoDan.b_chepai&&!IsNewVehicle) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += HPHM_ERROR;
            }
        }

        if (g_CheckItem.picture.JiaoQiangXian.CheJiaHao){
            if (!BaoDan.b_chejiahao) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += CHE_JIA_HAO_ERROR;
            }
        }
        if (g_CheckItem.picture.JiaoQiangXian.CheChuanShui) {
            if (p_vehicle_inf->m_rlzl == "C") {	/* 电动 */
            } else {							/* 其他 */
                if(!BaoDan.b_chechuanshui){
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[没有缴纳车船税]";
                }
            }
        }

        if (g_CheckItem.picture.JiaoQiangXian.FaDongJiHao) {
            if (!BaoDan.b_fadongjihao) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[发动机号不对]";
            }
        }
        if(g_CheckItem.picture.JiaoQiangXian.GongZhang){
            if (!BaoDan.b_hongzhang) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += NO_STAMP;
            }
        }





        if (!ok) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
            v_dbhhg_list.dbbhg_desc = "交强险-照片:";

            if (BaoDan.b_pic_quality) {
                v_dbhhg_list.dbresult = dbresult;
                v_dbhhg_list.dbbhg_desc += dbbhg_desc;
            } else {
                v_dbhhg_list.dbresult = NEED_MANUAL;
                v_dbhhg_list.dbbhg_desc += PICTURE_NOT_STANDARD;
            }

            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }
        }
    } else if (g_CheckItem.City == LINYI) {
        /*
         * 临沂，电子保单判定逻辑：
         * 如果有电子保单结果（通过或不通过），则直接判定保单照片结果。
         * 如果未查到电子保单结果，则判定保单照片。
        */

        if (p_vehicle_inf->insurance_result == 1) {
            return;
        } else if (p_vehicle_inf->insurance_result == 0) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
            v_dbhhg_list.dbbhg_desc = "交强险-照片:[联网电子信息不正确]";
            v_dbhhg_list.dbresult = FATAL_ERROR;
            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            dbbhgs++;

            return;
        }

        if (g_CheckItem.picture.JiaoQiangXian.FuBen) {
            if (!BaoDan.b_fuben) {
                ok = false;

                if (g_CheckItem.City == BAODING) {
                    dbresult = FATAL_ERROR;
                } else {
                    dbresult = NEED_MANUAL;
                }

                dbbhg_desc += "[不是副本文件]";
            }
        }

        if (g_CheckItem.picture.JiaoQiangXian.YouXiaoQi) {
            if (!BaoDan.b_riqi) {
                ok = false;

                if (g_CheckItem.City == BAODING) {
                    dbresult = FATAL_ERROR;
                } else {
                    dbresult = NEED_MANUAL;
                }

                dbbhg_desc += "[检验日期不在保险有效期内]";
            }
        }

        if (g_CheckItem.picture.JiaoQiangXian.ChePai){
            if (!BaoDan.b_chepai&&!IsNewVehicle) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += HPHM_ERROR;
            }
        }

        if (g_CheckItem.picture.JiaoQiangXian.CheJiaHao){
            if (!BaoDan.b_chejiahao) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += CHE_JIA_HAO_ERROR;
            }
        }

        if(g_CheckItem.picture.JiaoQiangXian.GongZhang){
            if (!BaoDan.b_hongzhang) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += NO_STAMP;
            }
        }

        if (g_CheckItem.picture.JiaoQiangXian.CheChuanShui) {
            if (p_vehicle_inf->m_rlzl != "C") {
                if (!BaoDan.b_chechuanshui) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[没有缴纳车船税]";
                }
            }
        }

        if (g_CheckItem.picture.JiaoQiangXian.FaDongJiHao) {
            if (!BaoDan.b_fadongjihao) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[发动机号不对]";
            }
        }

        if (!ok) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
            v_dbhhg_list.dbbhg_desc = "交强险-照片:";

            if (BaoDan.b_pic_quality) {
                v_dbhhg_list.dbresult = dbresult;
                v_dbhhg_list.dbbhg_desc += dbbhg_desc;
            } else {
                v_dbhhg_list.dbresult = NEED_MANUAL;
                v_dbhhg_list.dbbhg_desc += PICTURE_NOT_STANDARD;
            }

            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }
        }
    } else if (g_CheckItem.City == WUHAN && BaoDan.b_dianzi) {

        if (g_CheckItem.picture.JiaoQiangXian.YouXiaoQi) {
            if (!BaoDan.b_riqi) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[检验日期不在保险有效期内]";
            }
        }

        if (!ok) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
            v_dbhhg_list.dbbhg_desc = "交强险-照片:";

            if (BaoDan.b_pic_quality) {
                v_dbhhg_list.dbresult = dbresult;
                v_dbhhg_list.dbbhg_desc += dbbhg_desc;
            } else {
                v_dbhhg_list.dbresult = NEED_MANUAL;
                v_dbhhg_list.dbbhg_desc += PICTURE_NOT_STANDARD;
            }

            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }
        }
    } else if (g_CheckItem.City == NANJING) {
        bool bDianZiOK = true;
        if (g_b_ret) {
            if (nanjing_elec_data.m_vin != p_vehicle_inf->m_clsbdh) {
                DATA_PRINT(LEVEL_ERROR, "******** elec[%s] vehicle[%s]\n", nanjing_elec_data.m_vin.c_str(), p_vehicle_inf->m_clsbdh.c_str());
                bDianZiOK = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[电子保单车架号不一致]";
            }

            nanjing_elec_data.m_b_indate = fun_in_date(nanjing_elec_data.m_start_date, nanjing_elec_data.m_end_date);
            if (!nanjing_elec_data.m_b_indate) {
                DATA_PRINT(LEVEL_ERROR, "******** elec start date=[%s] end date=[%s]\n", nanjing_elec_data.m_start_date.c_str(), nanjing_elec_data.m_end_date.c_str());
                bDianZiOK = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[电子保单保险日期不在有效期]";
            }
            if(bDianZiOK)
            {
                return;
            }
//            std::string str_tmp_licenseno(nanjing_elec_data.m_licenseno.substr(3));
//            if (str_tmp_licenseno != p_vehicle_inf->m_hphm) {
//                DATA_PRINT(LEVEL_ERROR, "******** elec[%s] tmp=[%s] vehicle[%s]\n", nanjing_elec_data.m_licenseno.c_str(), str_tmp_licenseno.c_str(), p_vehicle_inf->m_hphm.c_str());
//                ok = false;
//                dbresult = FATAL_ERROR;
//                dbbhg_desc += "[电子数据号牌号码不一致]";
//            }
        /*    if (!ok) {
                _dbbhg_list v_dbhhg_list;
                v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
                v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
                v_dbhhg_list.dbbhg_desc = "交强险-电子数据:";
                v_dbhhg_list.dbresult = dbresult;
                v_dbhhg_list.dbbhg_desc += dbbhg_desc;

                p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
                if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                    dbbhgs++;
                }
            } */
        }
        if(!g_b_ret || !bDianZiOK)
        {
            if (g_CheckItem.picture.JiaoQiangXian.FuBen) {
                if (!BaoDan.b_fuben) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[不是副本文件]";
                }
            }

            if (g_CheckItem.picture.JiaoQiangXian.YouXiaoQi) {
                if (!BaoDan.b_riqi) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[检验日期不在保险有效期内]";
                }
            }

            if (g_CheckItem.picture.JiaoQiangXian.ChePai){
                if (!BaoDan.b_chepai&&!IsNewVehicle) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += HPHM_ERROR;
                }
            }

            if (g_CheckItem.picture.JiaoQiangXian.CheJiaHao){
                if (!BaoDan.b_chejiahao) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += CHE_JIA_HAO_ERROR;
                }
            }

            if (g_CheckItem.picture.JiaoQiangXian.CheChuanShui) {
                if (p_vehicle_inf->m_rlzl == "C") {
                } else {							/* 其他 */
                    if (!BaoDan.b_chechuanshui) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[没有缴纳车船税]";
                    }
                }
            }

            if (g_CheckItem.picture.JiaoQiangXian.FaDongJiHao) {
                if (!BaoDan.b_fadongjihao) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[发动机号不对]";
                }
            }
            if(g_CheckItem.picture.JiaoQiangXian.GongZhang){
                if (!BaoDan.b_hongzhang) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += NO_STAMP;
                }
            }

            if (!ok && !bDianZiOK) {
                _dbbhg_list v_dbhhg_list;
                v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
                v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
                v_dbhhg_list.dbbhg_desc = "交强险-照片:";

                if (BaoDan.b_pic_quality) {
                    v_dbhhg_list.dbresult = dbresult;
                    v_dbhhg_list.dbbhg_desc += dbbhg_desc;
                } else {
                    v_dbhhg_list.dbresult = FATAL_ERROR;
                    v_dbhhg_list.dbbhg_desc += PICTURE_NOT_STANDARD;
                }

                p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
                if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                    dbbhgs++;
                }
            }
        }
    } else if (g_CheckItem.City == XIANNING) {
        if (!BaoDan.b_dianzi)   // 标准格式
        {
            if (g_CheckItem.picture.JiaoQiangXian.FuBen)
            {
                if (!BaoDan.b_fuben)
                {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[不是副本文件]";
                }
            }

            if (g_CheckItem.picture.JiaoQiangXian.ChePai)
            {
                if (!BaoDan.b_chepai&&!IsNewVehicle)
                {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += HPHM_ERROR;
                }
            }

            if (g_CheckItem.picture.JiaoQiangXian.ChaoJian)
            {
                if (!BaoDan.b_chaoben)
                {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[抄件错误]";
                }
            }

            if (g_CheckItem.picture.JiaoQiangXian.CheJiaHao)
            {
                if (!BaoDan.b_chejiahao)
                {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += CHE_JIA_HAO_ERROR;
                }
            }

            if (g_CheckItem.picture.JiaoQiangXian.YouXiaoQi)
            {
                if (!BaoDan.b_riqi)
                {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[检验日期不在保险有效期内]";
                }
            }

            if (g_CheckItem.picture.JiaoQiangXian.GongZhang)
            {
                if (!BaoDan.b_hongzhang)
                {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += NO_STAMP;
                }
            }

            if (g_CheckItem.picture.JiaoQiangXian.CheChuanShui)
            {
                if (p_vehicle_inf->m_rlzl != "C")
                {
                    if (!BaoDan.b_chechuanshui)
                    {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[没有缴纳车船税]";
                    }
                }
            }

            if (g_CheckItem.picture.JiaoQiangXian.FaDongJiHao)
            {
                if (!BaoDan.b_fadongjihao)
                {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[发动机号不对]";
                }
            }
        }
        else       // 自定义电子单
        {
            if (g_CheckItem.picture.JiaoQiangXian.ChePai)
            {
                if (!BaoDan.b_chepai&&!IsNewVehicle)
                {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += HPHM_ERROR;
                }
            }

            if (g_CheckItem.picture.JiaoQiangXian.CheJiaHao)
            {
                if (!BaoDan.b_chejiahao)
                {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += CHE_JIA_HAO_ERROR;
                }
            }

            if (g_CheckItem.picture.JiaoQiangXian.GongZhang)
            {
                if (!BaoDan.b_hongzhang)
                {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += NO_STAMP;
                }
            }

            if (g_CheckItem.picture.JiaoQiangXian.YouXiaoQi)
            {
                if (!BaoDan.b_riqi)
                {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[检验日期不在保险有效期内]";
                }
            }

            if (g_CheckItem.picture.JiaoQiangXian.CheChuanShui)
            {
                if (p_vehicle_inf->m_rlzl != "C")
                {
                    if (!BaoDan.b_chechuanshui)
                    {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[没有缴纳车船税]";
                    }
                }
            }
        }

        if (!ok)
        {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;

            if (!BaoDan.b_dianzi)
            {
                v_dbhhg_list.dbbhg_desc = "交强险-照片:";

                if (BaoDan.b_pic_quality)
                {
                    v_dbhhg_list.dbresult = dbresult;
                    v_dbhhg_list.dbbhg_desc += dbbhg_desc;
                }
                else
                {
                    v_dbhhg_list.dbresult = NEED_MANUAL;
                    v_dbhhg_list.dbbhg_desc += PICTURE_NOT_STANDARD;
                }

                p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
                if (v_dbhhg_list.dbresult == FATAL_ERROR)
                {
                    dbbhgs++;
                }
            }
            else
            {
                v_dbhhg_list.dbbhg_desc = "交强险电子单-照片:";
                v_dbhhg_list.dbresult = dbresult;
                v_dbhhg_list.dbbhg_desc += dbbhg_desc;

                p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
                if (v_dbhhg_list.dbresult == FATAL_ERROR)
                {
                    dbbhgs++;
                }
            }
        }
    }
    else {
        if ((2!=p_vehicle_inf->m_jqxdzbd) && (g_CheckItem.picture.JiaoQiangXian.DianZiBaoDan)) {   // 配置中电子保单开启且 查询到了电子数据
            if (3 == p_vehicle_inf->m_jqxdzbd) { /* 电子保单不通过 */
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += p_vehicle_inf->m_dzjqxbhgyy;
            }
        } else {
            if (g_CheckItem.picture.JiaoQiangXian.FuBen) {
                if (!BaoDan.b_fuben) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[不是副本文件]";
                }
            }

            if (g_CheckItem.picture.JiaoQiangXian.YouXiaoQi) {
                if (!BaoDan.b_riqi) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[检验日期不在保险有效期内]";
                }
            }

            if (XIAN == g_CheckItem.City)   // 西安车架号与车牌号有一个过算该项通过
            {
                if (!BaoDan.b_chepai && !BaoDan.b_chejiahao)
                {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[车牌号与车架号均不正确]";
                }
            }
            else
            {
                if (g_CheckItem.picture.JiaoQiangXian.ChePai){//新余判定保单只需车架号或车牌一个正确即可
                    if (!BaoDan.b_chepai&&!IsNewVehicle) {
                        if(g_CheckItem.City != XINYU)
                        {
                            ok = false;
                            dbresult = FATAL_ERROR;
                            dbbhg_desc += HPHM_ERROR;
                        }
                        else if(g_CheckItem.City == XINYU && !BaoDan.b_chejiahao)
                        {
                            ok = false;
                            dbresult = FATAL_ERROR;
                            dbbhg_desc += HPHM_ERROR;
                        }
                   }

                }

                if (g_CheckItem.picture.JiaoQiangXian.CheJiaHao){
                    if(g_CheckItem.City != XINYU && g_CheckItem.City != FUZHOU2)//新余判定保单只需车架号或车牌一个正确即可
                    {
                        if (!BaoDan.b_chejiahao) {
                            ok = false;
                            dbresult = FATAL_ERROR;
                            dbbhg_desc += CHE_JIA_HAO_ERROR;
                        }

                    }
                    if(g_CheckItem.City == FUZHOU2)
                    {//抚州车架号与发动机号有一个过算该项通过
                        if (!BaoDan.b_chejiahao && !BaoDan.b_fadongjihao) {
                            ok = false;
                            dbresult = FATAL_ERROR;
                            dbbhg_desc += "[车架号或发动机号不正确]";
                        }
                    }
                }
            }

            if(g_CheckItem.City!=NINGBO)
            {
                if (g_CheckItem.picture.JiaoQiangXian.ChaoJian) {
                        if (!BaoDan.b_chaoben) {
                            ok = false;
                            dbresult = FATAL_ERROR;
                            dbbhg_desc += "[抄件不通过]";
                        }
                }
                else
                {
                        /*	衡水抄件判定：
                            <ChaoJian>off</ChaoJian>时，上传抄件无论合格均不通过
                        */
                        if(g_CheckItem.City==HENGSHUI && BaoDan.b_chaoben)
                        {
                            ok = false;
                            dbresult = FATAL_ERROR;
                            dbbhg_desc += "[不允许的抄件被上传]";
                        }
                }

            }


            if (g_CheckItem.picture.JiaoQiangXian.CheChuanShui) {
                if (p_vehicle_inf->m_rlzl == "C") {	/* 电动 */
    //                if (BaoDan.b_chechuanshui) {
    //                    ok = false;
    //                    dbresult = FATAL_ERROR;
    //                    dbbhg_desc += "[电动车不应该缴纳车船税]";
    //                } else {
    //                    //FixMe,需要车船税结果
    ////                    if (0) {

    ////                    }
    //                }
                } else {							/* 其他 */
                    if(g_CheckItem.City == FUZHOU2)
                    {/*抚州车船税是根据交强险与完税证明中的车船税综合判定*/
                        if (!BaoDan.b_chechuanshui && !WanShuiZhengMing.b_chechuanshui) {
                            ok = false;
                            dbresult = FATAL_ERROR;
                            dbbhg_desc += "[没有缴纳车船税]";
                        }
                    }
                    else if(g_CheckItem.City == TAIYUAN)
                    {
                        if(p_vehicle_inf->m_syxz == "H")
                        {/*警车的保单无需交车船税*/
                            ;
                        }
                        else
                        {
                            if (!BaoDan.b_chechuanshui) {
                                ok = false;
                                dbresult = FATAL_ERROR;
                                dbbhg_desc += "[没有缴纳车船税]";
                            }
                        }
                    }
                    else
                    {
                        if (!BaoDan.b_chechuanshui) {
                            ok = false;
                            dbresult = FATAL_ERROR;
                            //dbbhg_desc += "[非电动车没有缴纳车船税]";
                            dbbhg_desc += "[没有缴纳车船税]";
                        }
                    }

                }
            }

            if (g_CheckItem.picture.JiaoQiangXian.FaDongJiHao) {           
                if(g_CheckItem.City != FUZHOU2)
                {
                    if (!BaoDan.b_fadongjihao) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[发动机号不对]";
                    }
                }
            }
            if(g_CheckItem.picture.JiaoQiangXian.GongZhang){
                if (!BaoDan.b_hongzhang) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += NO_STAMP;
                }
            }

            if (g_CheckItem.City == LIANGSHAN) {
                if(!BaoDan.b_zaikerenshu) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[核定载客人数不正确]";
                }
            }
        }

        if (!ok) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
            v_dbhhg_list.dbbhg_desc = "交强险-照片:";

            if (BaoDan.b_pic_quality) {
                v_dbhhg_list.dbresult = dbresult;
                v_dbhhg_list.dbbhg_desc += dbbhg_desc;
            } else {
                if (g_CheckItem.City == BAODING || g_CheckItem.City == ZHAOTONG) {
                    v_dbhhg_list.dbresult = FATAL_ERROR;
                } else {
                    v_dbhhg_list.dbresult = NEED_MANUAL;
                }

                v_dbhhg_list.dbbhg_desc += PICTURE_NOT_STANDARD;
            }

            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }
        }
    }
}

void ResultCollection::doAnalyse_ZhongShanWanShui(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if (g_CheckItem.picture.JiaoQiangXian.FuBen) {
        if (!ZhongShanWanShui.b_fuben) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[不是副本文件]";
        }
    }

    if (g_CheckItem.picture.JiaoQiangXian.YouXiaoQi) {
        if (!ZhongShanWanShui.b_riqi) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[检验日期不在保险有效期内]";
        }
    }

    if (g_CheckItem.picture.JiaoQiangXian.ChePai){
        if (!ZhongShanWanShui.b_chepai&&!IsNewVehicle) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += HPHM_ERROR;
        }
    }

    if (g_CheckItem.picture.JiaoQiangXian.CheJiaHao){
        if (!ZhongShanWanShui.b_chejiahao) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += CHE_JIA_HAO_ERROR;
        }
    }

    if (g_CheckItem.picture.JiaoQiangXian.CheChuanShui) {
        if (p_vehicle_inf->m_rlzl == "C") {	/* 电动 */
        } else {							/* 其他 */
            if (!ZhongShanWanShui.b_chechuanshui) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[没有缴纳车船税]";
            }
        }
    }

    if (g_CheckItem.picture.JiaoQiangXian.FaDongJiHao) {
        if (!ZhongShanWanShui.b_fadongjihao) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[发动机号不对]";
        }
    }

    if(g_CheckItem.picture.JiaoQiangXian.GongZhang){
        if (!ZhongShanWanShui.b_hongzhang) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += NO_STAMP;
        }
    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "交强险[完税证明坑位]-照片:";

        if (ZhongShanWanShui.b_pic_quality) {
            v_dbhhg_list.dbresult = dbresult;
            v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        } else {
            v_dbhhg_list.dbresult = NEED_MANUAL;
            v_dbhhg_list.dbbhg_desc += PICTURE_NOT_STANDARD;
        }

        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}

void ResultCollection::doAnalyse_AnShunBaoDan(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;



        if (g_CheckItem.picture.JiaoQiangXian.YouXiaoQi) {
            if (!AnShunBaoDan.b_riqi) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[该保单生效日期与上一张保单终止日期不连续]";
            }
        }

        if (g_CheckItem.picture.JiaoQiangXian.ChePai){
            if (!AnShunBaoDan.b_chepai&&!IsNewVehicle) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += HPHM_ERROR;
            }
        }

        if (g_CheckItem.picture.JiaoQiangXian.CheJiaHao){
            if (!AnShunBaoDan.b_chejiahao) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += CHE_JIA_HAO_ERROR;
            }
        }


        if (g_CheckItem.picture.JiaoQiangXian.CheChuanShui) {
            if (p_vehicle_inf->m_rlzl == "C") {	/* 电动 */
            } else {							/* 其他 */
                if (!AnShunBaoDan.b_chechuanshui) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[没有缴纳车船税]";
                }
            }
        }

        if (g_CheckItem.picture.JiaoQiangXian.FaDongJiHao) {
            if (!AnShunBaoDan.b_fadongjihao) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[发动机号不对]";
            }
        }
        if(g_CheckItem.picture.JiaoQiangXian.GongZhang){
            if (!AnShunBaoDan.b_hongzhang) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += NO_STAMP;
            }
        }





        if (!ok) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
            v_dbhhg_list.dbbhg_desc = "交强险2-照片:";

            if (BaoDan.b_pic_quality) {
                v_dbhhg_list.dbresult = dbresult;
                v_dbhhg_list.dbbhg_desc += dbbhg_desc;
            } else {
                if (g_CheckItem.City == BAODING) {
                    v_dbhhg_list.dbresult = FATAL_ERROR;
                } else {
                    v_dbhhg_list.dbresult = NEED_MANUAL;
                }

                v_dbhhg_list.dbbhg_desc += PICTURE_NOT_STANDARD;
            }

            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }
        }

}

void ResultCollection::doAnalyse_JianYanBaoGao(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if (g_CheckItem.City == BAODING) {
        if ((p_vehicle_inf->BaoDing_JYBG != 0) || (p_vehicle_inf->BaoDing_YQ != 0)) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
            v_dbhhg_list.dbbhg_desc = "检验报告-照片:";
            v_dbhhg_list.dbresult = FATAL_ERROR;

            if (p_vehicle_inf->BaoDing_JYBG == 1) {
                v_dbhhg_list.dbbhg_desc += "[没有检验报告电子数据]";
            } else if (p_vehicle_inf->BaoDing_JYBG == 2) {
                v_dbhhg_list.dbbhg_desc += "[检验报告电子数据不通过]";
            } else if (p_vehicle_inf->BaoDing_JYBG == 3) {
                v_dbhhg_list.dbbhg_desc += "[电子检验报告数据库无法访问]";
            }

            if (p_vehicle_inf->BaoDing_YQ == 1) {
                v_dbhhg_list.dbbhg_desc += "[没有仪器检测电子数据]";
            } else if (p_vehicle_inf->BaoDing_YQ == 2) {
                v_dbhhg_list.dbbhg_desc += "[仪器检测电子数据不通过]";
            } else if (p_vehicle_inf->BaoDing_YQ == 3) {
                v_dbhhg_list.dbbhg_desc += "[仪器检测数据库无法访问]";
            }

            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }

            return;
        }
    }

    if (g_CheckItem.picture.JianYanBaoGao.ChePai) {
        if (!JianYanBaoGao.b_chepai&&!IsNewVehicle) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += HPHM_ERROR;
        }
    }

    // + {{ xeast 2018-06-15  for nanning
    if((g_CheckItem.City==NANNING) && (g_CheckItem.picture.JianYanBaoGao.CheLiangType)) {
        if(!JianYanBaoGao.b_chepai_type) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc = "[车辆类型不正确]";
        }
    }
    // }}

    if (g_CheckItem.picture.JianYanBaoGao.CheJiaHao) {
        if (!JianYanBaoGao.b_chejiahao) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += CHE_JIA_HAO_ERROR;
        }
    }

    if (g_CheckItem.picture.JianYanBaoGao.QianMing) {
        if (!JianYanBaoGao.b_qianming) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += NO_SIGNATURE;
        }
    }

    if (g_CheckItem.picture.JianYanBaoGao.YinZhang) {
        if (!JianYanBaoGao.b_hongzhang) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += NO_STAMP;
        }
    }

    if (g_CheckItem.picture.JianYanBaoGao.JieLun) {
        if (!JianYanBaoGao.b_jianyanjielun) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[结论不合格]";
        }
    }

    if (g_CheckItem.picture.JianYanBaoGao.ShuJuXiang) {
        if (!JianYanBaoGao.b_jianyan_info) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[数据项不正确]";
        }
    }

    if (g_CheckItem.picture.JianYanBaoGao.YinZhang_MA) {
        if(g_CheckItem.City == FUZHOU2)
        {
            if ((!JianYanBaoGao.b_MA)&&(!JianYanBaoGao.b_CMA)) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[没有“CMA”印章]";
            }
        }
        else
        {
            if (!JianYanBaoGao.b_MA) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[没有“CMA”印章]";
            }
        }
    }

    if(g_CheckItem.City==SHENZHEN)
    {
        if (g_CheckItem.picture.JianYanBaoGao.QueRenZhang) {
            if (!JianYanBaoGao.b_querenzhang) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[没有确认印章]";
            }
        }
    }
    if (g_CheckItem.City == QingDao){
        if (g_CheckItem.picture.JianYanBaoGao.JianYanRiQi){
            if (!JianYanBaoGao.b_jianyanriqi){
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[检验日期不合格]";
            }
        }
    }


    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "检验报告-照片:";

        if (JianYanBaoGao.b_pic_quality) {
            v_dbhhg_list.dbbhg_desc += dbbhg_desc;
            v_dbhhg_list.dbresult = dbresult;
        } else {
            v_dbhhg_list.dbbhg_desc += PICTURE_NOT_STANDARD;
            v_dbhhg_list.dbresult = NEED_MANUAL;
        }

        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}

void ResultCollection::doAnalyse_NaMianShuiZhengMing(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    /*如果深圳完税证明为电子保单时，默认通过：*/
    if(g_CheckItem.City == SHENZHEN)
    {
        if(WanShuiZhengMing.b_dianzibaodan)
        {
            return ;
        }
    }
    /*
        天津、衡水、佛山
        完税证明逻辑
        1：先检测b_wanshuizhengming确认单据是否为完税证明（若为true则按完税证明判断）
        2：若不是完税证明则检测WanShuiBaoDan.b_chechuanshui（若为true则通过）
        3：若未通过则根据WanShuiBaoDan.b_baodan判断图片是否符合标准
        4：其中天津不判断本省车完税证明
    */
    if(g_CheckItem.City == TIANJIN)
    {
//        if(p_vehicle_inf->m_fzjg.find("津") == -1)/* 外省车标记 */
//        {
            if(WanShuiZhengMing.b_wanshuizhengming)
            {
                if (g_CheckItem.picture.WanShuiZhengMing.CheJiaHao) {
                    if (!WanShuiZhengMing.b_chejiahao) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += CHE_JIA_HAO_ERROR;
                    }
                }

                if (g_CheckItem.picture.WanShuiZhengMing.ChePai) {
                    if (!WanShuiZhengMing.b_chepai) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += HPHM_ERROR;
                    }
                }

                if (g_CheckItem.picture.WanShuiZhengMing.CheChuanShui) {
                    if (!WanShuiZhengMing.b_chechuanshui) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[车船税不合格]";
                    }
                }

                if (g_CheckItem.picture.WanShuiZhengMing.SuoShuRiQi) {
                    if (!WanShuiZhengMing.b_zhengnian) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[税款所属日期不是整年]";
                    }
                }

                if (g_CheckItem.picture.WanShuiZhengMing.JianCeRiQi) {
                    if (!WanShuiZhengMing.b_valid_data) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[日期不正确]";
                    }
                }
            }  //先判定是否为车船税，后判定车船税是否正确，最后判定是否为保单，若车船税正确则默认保单通过
            else if(!WanShuiBaoDan.b_chechuanshui)
            {
                if (g_CheckItem.picture.WanShuiZhengMing.BaoXianDan)
                {
                    if (!WanShuiBaoDan.b_baodan) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc = "[图片不符合标准]";
                    }
                    else {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc = "[车船税不合格]";
                    }
                }

            }
       // }
    }
    else if((g_CheckItem.City == HENGSHUI) ||
            (g_CheckItem.City == FOSHAN) ||
            (g_CheckItem.City == JIAOZUO) ||
            (g_CheckItem.City == SHENZHEN))
    {
        if(WanShuiZhengMing.b_wanshuizhengming)
        {
            if (g_CheckItem.picture.WanShuiZhengMing.CheJiaHao) {
                if (!WanShuiZhengMing.b_chejiahao) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += CHE_JIA_HAO_ERROR;
                }
            }

            if (g_CheckItem.picture.WanShuiZhengMing.ChePai) {
                if (!WanShuiZhengMing.b_chepai) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += HPHM_ERROR;
                }
            }

            if (g_CheckItem.picture.WanShuiZhengMing.CheChuanShui) {
                if (!WanShuiZhengMing.b_chechuanshui) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[车船税不合格]";
                }
            }

            if (g_CheckItem.picture.WanShuiZhengMing.SuoShuRiQi) {
                if (!WanShuiZhengMing.b_zhengnian) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[税款所属日期不是整年]";
                }
            }

            if (g_CheckItem.picture.WanShuiZhengMing.JianCeRiQi) {
                if (!WanShuiZhengMing.b_valid_data) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[日期不正确]";
                }
            }
        }
        else if(!WanShuiBaoDan.b_chechuanshui)
        {
            if (!WanShuiBaoDan.b_baodan) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc = "[图片不符合标准]";
            }
            else {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc = "[车船税不合格]";
            }
        }
    }
    else
    {
        if (g_CheckItem.picture.WanShuiZhengMing.CheJiaHao) {
            if (!WanShuiZhengMing.b_chejiahao) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += CHE_JIA_HAO_ERROR;
            }
        }

        if (g_CheckItem.picture.WanShuiZhengMing.ChePai) {
            if (!WanShuiZhengMing.b_chepai) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += HPHM_ERROR;
            }
        }

        if (g_CheckItem.picture.WanShuiZhengMing.CheChuanShui) {
            if (!WanShuiZhengMing.b_chechuanshui) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[车船税不合格]";
            }
        }

        if (g_CheckItem.picture.WanShuiZhengMing.SuoShuRiQi) {
            if (!WanShuiZhengMing.b_zhengnian) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[税款所属日期不是整年]";
            }
        }

        if (g_CheckItem.picture.WanShuiZhengMing.JianCeRiQi) {
            if (!WanShuiZhengMing.b_valid_data) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[日期不正确]";
            }
        }

        if (!WanShuiZhengMing.b_wanshuizhengming) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc = "[照片不是完税证明]";  /* 覆盖前面的所有结果 */
        }
    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "完税证明-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;

        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }


}
void ResultCollection::doAnalyse_HeGeTongZhiShu(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if (g_CheckItem.picture.WeiTuoTongZhiShu.WeiTuoTongZhiShu) {
        if (!WeiTuoHeGeTongZhiShu.b_weituotongzhishu) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[不是委托通知书]";
        }
    }
    if (g_CheckItem.picture.WeiTuoTongZhiShu.CheJiaHao) {
        if (!WeiTuoHeGeTongZhiShu.b_chejiahao) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += CHE_JIA_HAO_ERROR;
        }
    }

    if (g_CheckItem.picture.WeiTuoTongZhiShu.ChePai) {
        if (!WeiTuoHeGeTongZhiShu.b_chepai&&!IsNewVehicle) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += HPHM_ERROR;
        }
    }

    if (g_CheckItem.picture.WeiTuoTongZhiShu.YinZhang) {
        if (!WeiTuoHeGeTongZhiShu.b_yinzhang) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[没有印章]";
        }
    }
    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "委托通知书-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;

        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }

}

void ResultCollection::doAnalyse_ShenFenZheng(vehicle_inf *p_vehicle_inf,int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;
    if (g_CheckItem.picture.ShenFenZheng.ShenFenZheng) {
        if (!ShenFenZheng.b_front) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[身份证（正面）不匹配]";
        }
        if (g_CheckItem.City == BAODING && (ShenQingDan.s_dailiren_name != ShenFenZheng.s_xingming))
        {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[姓名与牌证申请表上的送检人不一致]";
        }
    }

    if (g_CheckItem.picture.ShenFenZheng.XingMing) {
        if(ShenFenZheng.s_xingming != ShenQingDan.s_dailiren_name)
        {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[送检人姓名与身份证姓名不一致]";
        }
    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "身份证（正面）-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;

        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}
void ResultCollection::doAnalyse_ShenFenZhengBeiMian(vehicle_inf *p_vehicle_inf,int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;
    if (g_CheckItem.picture.ShenFenZhengBeiMian.ShenFenZheng) {
        if (!ShenFenZhengBeiMian.b_back) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[身份证（反面）不匹配]";
        }
    }
    if (g_CheckItem.picture.ShenFenZhengBeiMian.YouXiaoQi) {
        if (!ShenFenZhengBeiMian.b_valid) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[身份证不在有效期]";
        }
    }
    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "身份证（反面）-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;

        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}

// +{{ xeast 20180623
void ResultCollection::doAnalyse_JianYanbiao_YiQi(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    bool is_report = true;
    std::string dbbhg_desc, dbresult;

    if (g_CheckItem.picture.JianYanBaoGao_YiQi.YiQi) {
        if (!JianYanBiao_YiQi.b_jianyanbaogao_yiqi) {
            ok = false;
            is_report = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[不是仪器检验报告]";
        }
    }

    if (g_CheckItem.picture.JianYanBaoGao_YiQi.CheJiaHao && is_report) {
        if (!JianYanBiao_YiQi.b_chejiahao) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += CHE_JIA_HAO_ERROR;
        }
    }

    if ((g_CheckItem.picture.JianYanBaoGao_YiQi.ChePai) && is_report) {
        if (!JianYanBiao_YiQi.b_chepai&&!IsNewVehicle) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += HPHM_ERROR;
        }
    }

    if (g_CheckItem.picture.JianYanBaoGao_YiQi.HongZhang && is_report) {
        if (!JianYanBiao_YiQi.b_hongzhang) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[未检测到红章]";
        }
    }
    if (g_CheckItem.picture.JianYanBaoGao_YiQi.QianMing && is_report) {
        if (!JianYanBiao_YiQi.b_qianming) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[未检测到签名]";
        }
    }

    if (g_CheckItem.City.compare("CHONGQING") != 0) {   // check report not is chongqing just to do next
        if (g_CheckItem.picture.JianYanBaoGao_YiQi.JieLun && is_report) {
            if (!JianYanBiao_YiQi.b_jianyanjielun) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[结论为不通过]";
            }
        }
    }

    if (g_CheckItem.picture.JianYanBaoGao_YiQi.YinZhang_MA && is_report) {
        if (!JianYanBiao_YiQi.b_MA) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[没有“CMA”印章]";;
        }
    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "检验报告（仪器）-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;

        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}

void ResultCollection::doAnalyse_JianYanbiao_RenGong(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    bool is_report = true;
    std::string dbbhg_desc, dbresult;
    if (g_CheckItem.picture.JianYanBaoGao_RenGong.ChePai) {
        if (!JianYanBiao_RenGong.b_jianyanbiao) {
            ok = false;
            is_report = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[检验表不符合标准]";
        }
    }

    if (g_CheckItem.picture.JianYanBaoGao_RenGong.ChePai) {
        if (!JianYanBiao_RenGong.b_chepai) {
            ok = false;
            is_report = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += HPHM_ERROR;
        }
    }

    if ((g_CheckItem.City==XIAN) && (!JianYanBiao_RenGong.b_xian_panding_all)) {
        ok = false;
        is_report = false;
        dbresult = FATAL_ERROR;
        dbbhg_desc += "[检验表细项不符合标准]";
    }

    if (g_CheckItem.picture.JianYanBaoGao_RenGong.WaiGuanQianZi) {
        if (g_CheckItem.City == ANSHUN) {
            if (!JianYanBiao_RenGong.b_waiguan_sign) {
                ok = FALSE;
                dbbhg_desc += "[外观检验员未签字]";
                dbresult = FATAL_ERROR;
            }
        } else {
            if (!JianYanBiao_RenGong.b_waiguan_sign) {
                ok = FALSE;
                dbbhg_desc += "[外观检验员未签字]";
                dbresult = FATAL_ERROR;
            }
        }
    }



     if (isTenYears(p_vehicle_inf)) {	/* 10年以上车型 */

         if (g_CheckItem.picture.JianYanBaoGao_RenGong.YinCheQianZi) {
             if (!JianYanBiao_RenGong.b_yinche_sign) {
                     ok = FALSE;
                     dbbhg_desc += "[引车检验员未签字]";
                     dbresult = FATAL_ERROR;
             }
         }
         if (g_CheckItem.picture.JianYanBaoGao_RenGong.DiPanQianZi) {
             if (!JianYanBiao_RenGong.b_dipan_sign) {
                     ok = FALSE;
                     dbbhg_desc += "[底盘检验员未签字]";
                     dbresult = FATAL_ERROR;
             }
         }
     }

     if (g_CheckItem.City == NANNING) {
         if (!JianYanBiao_RenGong.b_jianyanriqi) {
             ok = FALSE;
             dbbhg_desc += "[检验日期不是当天]";
             dbresult = FATAL_ERROR;
         }

         if (!JianYanBiao_RenGong.b_jianyanjieguo5) {
             ok = FALSE;
             dbbhg_desc += "[检验结果第5项不是“合格”]";
             dbresult = FATAL_ERROR;
         }
     }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "检验报告（人工）-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;

        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}

void ResultCollection::doAnalyse_JianYanbiaoBeiMian(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    bool is_report = true;
    std::string dbbhg_desc, dbresult;

    if (g_CheckItem.picture.JianYanBiaoBeiMian.JianYanBiaoBeiMian) {
        if (!JianYanBiaoBeiMian.b_jianyanbiao_back) {
            ok = false;
            is_report = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[不是查验记录表反面]";
        }
    }

    if (g_CheckItem.picture.JianYanBiaoBeiMian.WaiGuan) {
        if (!JianYanBiaoBeiMian.b_waiguan_sign) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[没有外观签名]";//fix me 0626
        }
    }

    if(isTenYears(p_vehicle_inf))
    {
        if (g_CheckItem.picture.JianYanBiaoBeiMian.DiPan) {
            if (!JianYanBiaoBeiMian.b_dipan_sign) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[没有底盘签名]";//fix me 0626
            }
        }

        if (g_CheckItem.picture.JianYanBiaoBeiMian.YinChe) {
            if (!JianYanBiaoBeiMian.b_yinche_sign) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[没有引车签名]";//fix me 0626
            }
        }
    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "查验记录表反面 -照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;

        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}

void ResultCollection::doAnalyse_WeiTuoShu(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    bool is_weituoshu = true;
    std::string dbbhg_desc, dbresult;

    if (g_CheckItem.City==FOSHAN) {
        if (g_CheckItem.picture.WeiTuoShu.ShenFenZheng) {
//            if (!ShenFenZheng.b_valid) {
//                ok = false;
//                dbresult = FATAL_ERROR;
//                dbbhg_desc += "[身份证无效]";
//            }
//            if (!ShenFenZheng.b_front) {
//                ok = false;
//                dbresult = FATAL_ERROR;
//                dbbhg_desc += "[不是身份证正面]";
//            }

            if (!WeiTuoShu.b_shenfenzheng_front) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[没有身份证正面]";
            }
        }
    }

    if (g_CheckItem.picture.WeiTuoShu.WeiTuoShu) {
        if (!WeiTuoShu.b_weituoshu) {
            ok = false;
            is_weituoshu = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[不是委托书]";
        }
    }

    if (g_CheckItem.picture.WeiTuoShu.HongZhang && is_weituoshu) {
        if (!WeiTuoShu.b_hongzhang) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[未检测到红章]";
        }
    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "委托书-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;

        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}

void ResultCollection::doAnalyse_GaoZhiShu(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;


    if (g_CheckItem.picture.GaoZhiShu.GaoZhiShu) {
//        if (!GaoZhiShu.b_gaozhishu) {
//            ok = false;
//            dbresult = FATAL_ERROR;
//            dbbhg_desc += "[不是告知书]";
//        }
    }

    if (g_CheckItem.picture.GaoZhiShu.HongZhang) {
        if (!GaoZhiShu.b_hongzhang) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[未检测到红章]";
        }
    }

    if (g_CheckItem.picture.GaoZhiShu.QianMing) {
        if (!GaoZhiShu.b_qianming) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[未检测到签名]";
        }
    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "告知书-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;

        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}

void ResultCollection::doAnalyse_RongQueShouLi(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;


    if (g_CheckItem.picture.RongQueShouLi.DuiGou) {
        if (!RongQueShouLi.b_dagou) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[未检测到打勾]";
        }
    }

    if (g_CheckItem.picture.RongQueShouLi.QianMing) {
        if (!RongQueShouLi.b_qianming) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[未检测到签名]";
        }
    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "容缺受理-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;

        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}

void ResultCollection::doAnalyse_QuXianBaoGao(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    bool is_quxianbaogaou = true;
    std::string dbbhg_desc, dbresult;

    if (g_CheckItem.picture.JianCeQuXianBaoGao.QuXianBaoGao) {
        if (!QuXianBaoGao.b_quxianbaobao) {
            ok = false;
            is_quxianbaogaou = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[不是检测曲线报告]";
        }
    }

    if (g_CheckItem.picture.JianCeQuXianBaoGao.YinZhang && is_quxianbaogaou) {
        if (!QuXianBaoGao.b_yinzhang) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[未检测到红章]";
        }
    }
    if (g_CheckItem.picture.JianCeQuXianBaoGao.ChePai && is_quxianbaogaou) {
        if (!QuXianBaoGao.b_chepai) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += HPHM_ERROR;
        }
    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "制动检测曲线报告-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;

        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}

void ResultCollection::doAnalyse_CheJiaHaoYuanJing(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if (g_CheckItem.picture.CheJiaHao.YuanJing) {
        if (!CheJiaHaoYuanJing.b_chejiahao) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += CHE_JIA_HAO_ERROR;
        }
    }


    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "车架号远景-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;

        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}
// }}

void ResultCollection::doAnalyse_WaiGuan(vehicle_inf *p_vehicle_inf, unsigned int zuo, unsigned int you)
{
    // 大小车判断
    if ((p_vehicle_inf->m_cllx.substr(0, 2)=="K3") || (p_vehicle_inf->m_cllx.substr(0, 2)=="K4")) { // 小车
        bool zqf_ok = true, yhf_ok = true;
        std::string zqf_dbbhg_desc, zqf_dbresult;
        std::string yhf_dbbhg_desc, yhf_dbresult;

        /* 水印日期的判定必须放在最前面，因为result=4可以被3或5覆盖 */
        {

         if(g_CheckItem.picture.ZuoQianFang.ShuiYinRiQi)
          {
            if (!bZuoQianFangShuiYinRiQi) {
                zqf_ok = false;
                zqf_dbbhg_desc += OUT_OF_DATE;
                zqf_dbresult = FATAL_ERROR;
            }
          }
          if(g_CheckItem.picture.YouHouFang.ShuiYinRiQi)
          {
             if (!bYouHouFangShuiYinRiQi) {
               yhf_ok = false;
               yhf_dbbhg_desc += OUT_OF_DATE;
               yhf_dbresult = FATAL_ERROR;
              }
          }
       }

        if(g_CheckItem.City==NINGBO)
        {
            if(p_vehicle_inf->is_black_list)
            {
                zqf_ok = false;
                yhf_ok = false;
                yhf_dbresult = FATAL_ERROR;
                zqf_dbresult = FATAL_ERROR;
                zqf_dbbhg_desc += "[黑名单车辆]";
                yhf_dbbhg_desc += "[黑名单车辆]";
                p_vehicle_inf->is_black_list=false;
            }
        }

        if(g_CheckItem.City == TAIYUAN)
        {
            if(p_vehicle_inf->m_syxz == "N")
            {
                if(!ZuoQianFang.b_fuzhu_houshijing)
                {
                   zqf_ok = FALSE;
                   zqf_dbbhg_desc += "[无辅助后视镜]";
                   zqf_dbresult = FATAL_ERROR;
                }
            }
        }
        if(g_CheckItem.picture.ZuoQianFang.CheShenYanSe)
        {
            if (!ZuoQianFang.b_ori_color) {
                zqf_ok = FALSE;
                zqf_dbbhg_desc +="[车辆颜色有变化]";
                zqf_dbresult = FATAL_ERROR;
            }
        }


        if(g_CheckItem.picture.YouHouFang.CheShenYanSe)
        {
            if (!YouHouFang.b_ori_color) {
                yhf_ok = FALSE;
                yhf_dbbhg_desc += "[车辆颜色有变化]";
                yhf_dbresult = FATAL_ERROR;
            }
        }

        /* 改装  */
        {
            if (g_CheckItem.picture.ZuoQianFang.GaiZhuang) {
                if (ZuoQianFang_A) {
                    std::string GaiZhuang;
                    bool GaiZhuang_ok = true;

//                    if (!ZuoQianFang.b_ori_waiguan) {
//                        GaiZhuang_ok = false;
//                        GaiZhuang += "外观有变化.";
//                    }

//                    if (!ZuoQianFang.b_ori_lamp) {
//                        GaiZhuang_ok = false;
//                        GaiZhuang += "车灯有变化.";
//                    }



                    if(g_CheckItem.City == WUHAN)
                    {
                        if(!ZuoQianFang.b_xinglijia)
                        {
                            GaiZhuang_ok = false;
                            GaiZhuang += "行李架有变化.";
                        }
                    }
                    if (!GaiZhuang_ok)
                    {
                        zqf_ok = false;
                        if(g_CheckItem.City==NINGBO)
                        {
                            p_vehicle_inf->is_black_list=true;
                        }
                        zqf_dbresult = FATAL_ERROR;
                        zqf_dbbhg_desc += "[与档案照片不符合：" + GaiZhuang + "]";
                    }

                } else {
                    if (g_CheckItem.City == SUZHOU) { /* 苏州外地车，如果没有档案照片，则不做判定 */
                        if (p_vehicle_inf->m_fzjg == "苏E") {
                            zqf_ok = false;
                            zqf_dbbhg_desc += "[缺少档案照片，无法判定是否改装]";
                            zqf_dbresult = NEED_MANUAL;
                        }else if(g_CheckItem.picture.ZuoQianFang.DangAn){
                            zqf_ok = false;
                            zqf_dbbhg_desc += "[缺少档案照片，无法判定是否改装]";
                            zqf_dbresult = NEED_MANUAL;
                        }

                    } else if(g_CheckItem.picture.ZuoQianFang.DangAn){
                        zqf_ok = false;
                        zqf_dbbhg_desc += "[缺少档案照片，无法判定是否改装]";
                        zqf_dbresult = NEED_MANUAL;
                    }
                }
            }



            if (g_CheckItem.picture.YouHouFang.GaiZhuang) {
                if (!YouHouFang.b_ori_waiguan) {
                    if(g_CheckItem.City==NINGBO)
                    {
                        p_vehicle_inf->is_black_list=true;
                    }
                }
            }

        }

        if (g_CheckItem.picture.YouHouFang.PaiQiKong) {
            if(YouHouFang.num_paiqikong > 4) {
                yhf_ok = false;
                yhf_dbbhg_desc += "[排气孔数量过多]";
                yhf_dbresult = FATAL_ERROR;
            }
        }

        bool b_car_flag = false;    // 南京左前和右后车标关联
        /* 车标判定必须放在此处，因为result=3的程度比4高，比5低  */
        {
            std::string tmp_zqf_dbbhg_desc, tmp_zqf_dbresult, tmp_yhf_dbbhg_desc, tmp_yhf_dbresult;
            if (g_CheckItem.picture.ZuoQianFang.CheBiao) {
                if(g_CheckItem.City != JIUJIANG){
                if (!ZuoQianFang.b_chebiao) {
                    zqf_ok = false;
                    tmp_zqf_dbbhg_desc = "[车标不正确]";

                    tmp_zqf_dbresult = FATAL_ERROR;

                } else {
                    b_car_flag = true;       // 左前方车标正确
                }
            }
            else{
                if(p_vehicle_inf->m_cllx.substr(0,2) == "K3" || p_vehicle_inf->m_cllx.substr(0,2) == "K4")
                {
                    if (!ZuoQianFang.b_chebiao) {
                        zqf_ok = false;
                        tmp_zqf_dbbhg_desc = "[车标不正确]";
                        tmp_zqf_dbresult = FATAL_ERROR;

                    } else {
                        b_car_flag = true;       // 左前方车标正确
                    }
                }
                else {
                    b_car_flag = true;
                }
            }
            }

            if (g_CheckItem.picture.YouHouFang.CheBiao) {
                if (!YouHouFang.b_chebiao) {
                    yhf_ok = false;
                    tmp_yhf_dbbhg_desc = "[车标不正确]";
                    tmp_yhf_dbresult = FATAL_ERROR;
                } else {
                    b_car_flag = true;       // 右后方车标正确
                }
            }

            if (g_CheckItem.City != NANJING) {
                if(strlen(tmp_zqf_dbbhg_desc.c_str()) > 0)
                {
                    zqf_dbbhg_desc += tmp_zqf_dbbhg_desc;
                    zqf_dbresult = tmp_zqf_dbresult;
                }
                if(strlen(tmp_yhf_dbbhg_desc.c_str()) > 0)
                {
                    yhf_dbbhg_desc += tmp_yhf_dbbhg_desc;
                    yhf_dbresult = tmp_yhf_dbresult;
                }

            } else {
                if (!b_car_flag) {
                    if(strlen(tmp_zqf_dbbhg_desc.c_str()) > 0)
                    {
                        zqf_dbbhg_desc += tmp_zqf_dbbhg_desc;
                        zqf_dbresult = tmp_zqf_dbresult;
                    }
                    if(strlen(tmp_yhf_dbbhg_desc.c_str()) > 0)
                    {
                        yhf_dbbhg_desc += tmp_yhf_dbbhg_desc;
                        yhf_dbresult = tmp_yhf_dbresult;
                    }


                }
            }
        }
        if(g_CheckItem.City == TAIYUAN)
        {
            if(p_vehicle_inf->m_syxz == "N")
            {
                if(!JiaoLianCheYouHouFang.b_jiaolianche_ziyang)
                {
                    yhf_ok = false;
                    yhf_dbbhg_desc += "[教练车字样识别错误]";
                    yhf_dbresult = FATAL_ERROR;
                }
            }
        }

        /* 车牌 */
        {
            if (g_CheckItem.picture.ZuoQianFang.ChePai) {
                if(g_CheckItem.City == YICHUN && g_CheckItem.video.ZuoQianFang.ChePai && p_vehicle_inf->m_b_zqf_checked)
                {
                    if(!ZuoQianFang.b_chepai && !IsNewVehicle)
                    {//左前方照片车牌号不通过时，若视频通过，算车牌号通过
                        if(!V_ZuoQianFang.b_chepai)
                        {
                            zqf_ok = false;
                            zqf_dbbhg_desc += HPHM_ERROR;
                            zqf_dbresult = FATAL_ERROR;
                            zqf_dbbhg_desc += "[视频-车牌不正确]";
                        }
                    }
                }
                else
                {
                    if (!ZuoQianFang.b_chepai && !IsNewVehicle) {
                        zqf_ok = false;
                        zqf_dbbhg_desc += HPHM_ERROR;
                        zqf_dbresult = FATAL_ERROR;
                    }
                }

            }

            if (g_CheckItem.picture.YouHouFang.ChePai) {
                if(g_CheckItem.City == YICHUN && g_CheckItem.video.YouHouFang.ChePai && p_vehicle_inf->m_b_yhf_checked)
                {
                    if(!YouHouFang.b_chepai && !IsNewVehicle)
                    {
                        if(!V_YouHouFang.b_chepai)
                        {
                            yhf_ok = false;
                            yhf_dbbhg_desc += HPHM_ERROR;
                            yhf_dbresult = FATAL_ERROR;
                            yhf_dbbhg_desc += "[视频-车牌不正确]";
                        }
                    }
                }
                else
                {
                    if (!YouHouFang.b_chepai && !IsNewVehicle) {
                        yhf_ok = false;
                        yhf_dbbhg_desc += HPHM_ERROR;
                        yhf_dbresult = FATAL_ERROR;
                    }
                }

            }

            if (g_CheckItem.City == NANJING) {
                if (!ZuoQianFang.b_chepai_quality && !IsNewVehicle) { // 左前方车牌掉漆
                    zqf_ok = false;
                    zqf_dbbhg_desc += "[车牌掉漆]";
                    zqf_dbresult = FATAL_ERROR;
                }

                if (!YouHouFang.b_chepai_quality && !IsNewVehicle) { // 右后方车牌掉漆
                    yhf_ok = false;
                    yhf_dbbhg_desc += "[车牌掉漆]";
                    yhf_dbresult = FATAL_ERROR;
                }
            }
        }

        /* 三脚架 */
        {
            if (g_CheckItem.picture.ZuoQianFang.SanJiaoJia
                && g_CheckItem.picture.YouHouFang.SanJiaoJia) {			/* 如果配置中，左前和右后的三脚架判定都打开。则认为只要左前和右后有一个三脚架即可。 */
                if ((!ZuoQianFang.b_sanjiaojia) && (!YouHouFang.b_sanjiaojia)) {
                    zqf_ok = false;
                    zqf_dbbhg_desc += NO_TRIPOD;
                    zqf_dbresult = FATAL_ERROR;

                    yhf_ok = false;
                    yhf_dbbhg_desc += NO_TRIPOD;
                    yhf_dbresult = FATAL_ERROR;
                }
            } else if (g_CheckItem.picture.ZuoQianFang.SanJiaoJia) {	/* 如果只打开左前三脚架，则必须判定左前三脚架 */
                if (!ZuoQianFang.b_sanjiaojia) {
                    zqf_ok = false;
                    zqf_dbbhg_desc += NO_TRIPOD;
                    zqf_dbresult = FATAL_ERROR;
                }
            } else if (g_CheckItem.picture.YouHouFang.SanJiaoJia) {		/* 如果只打开右后三脚架，则必须判定右后三脚架 */
                if (!YouHouFang.b_sanjiaojia) {
                    yhf_ok = false;
                    yhf_dbbhg_desc += NO_TRIPOD;
                    yhf_dbresult = FATAL_ERROR;
                }
            }
        }

        if(g_CheckItem.City==NINGBO)
        {
            if(p_vehicle_inf->is_black_list)
            {
                zqf_ok = false;
                yhf_ok = false;
                yhf_dbresult = FATAL_ERROR;
                zqf_dbresult = FATAL_ERROR;
                zqf_dbbhg_desc += "[车辆已加入黑名单]";
                yhf_dbbhg_desc += "[车辆已加入黑名单]";
            }
        }

        if (!zqf_ok) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[zuo].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[zuo].zptype;
            v_dbhhg_list.dbbhg_desc = "左前方-照片:" + zqf_dbbhg_desc;
            v_dbhhg_list.dbresult = zqf_dbresult;

            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }
        }

        if (!yhf_ok) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[you].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[you].zptype;
            v_dbhhg_list.dbbhg_desc = "右后方-照片:" + yhf_dbbhg_desc;
            v_dbhhg_list.dbresult = yhf_dbresult;

            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }
        }
    } else if ((p_vehicle_inf->m_cllx.substr(0, 2)=="M1") ||
              (p_vehicle_inf->m_cllx.substr(0, 2)=="M2") ||
              (p_vehicle_inf->m_cllx.substr(0, 2)=="N1")) { // 摩托车
        bool zqf_ok = true, yhf_ok = true;
        std::string zqf_dbbhg_desc, zqf_dbresult;
        std::string yhf_dbbhg_desc, yhf_dbresult;


        // 安全帽
        {
            if (!ZuoQianFang.b_anquanmao) {
                zqf_ok = false;
                zqf_dbbhg_desc += "[安全帽不存在]";
                zqf_dbresult = FATAL_ERROR;
            }

            if (!YouHouFang.b_anquanmao) {
                yhf_ok = false;
                yhf_dbbhg_desc += "[安全帽不存在]";
                yhf_dbresult = FATAL_ERROR;
            }
        }

        // 颜色
        {
            if(g_CheckItem.picture.ZuoQianFang.CheShenYanSe)
            {
                if (!ZuoQianFang.b_ori_color) {
                    zqf_ok = false;
                    zqf_dbbhg_desc += "[车辆颜色有变化]";
                    zqf_dbresult = FATAL_ERROR;
                }
            }

            if(g_CheckItem.picture.YouHouFang.CheShenYanSe)
            {
                if (!YouHouFang.b_ori_color) {
                    yhf_ok = false;
                    yhf_dbbhg_desc += "[车辆颜色有变化]";
                    yhf_dbresult = FATAL_ERROR;
                }
            }


        }
        // 号牌号码
        if (!ZuoQianFang.b_chepai) {
            zqf_ok = false;
            zqf_dbbhg_desc += HPHM_ERROR;
            zqf_dbresult = FATAL_ERROR;
        }

        if (!zqf_ok) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[zuo].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[zuo].zptype;
            v_dbhhg_list.dbbhg_desc = "左前方-照片:" + zqf_dbbhg_desc;
            v_dbhhg_list.dbresult = zqf_dbresult;

            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }
        }

        if (!yhf_ok) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[you].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[you].zptype;
            v_dbhhg_list.dbbhg_desc = "右后方-照片:" + yhf_dbbhg_desc;
            v_dbhhg_list.dbresult = yhf_dbresult;

            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }
        }
    } else { // 大车
        bool zqf_ok = true, yhf_ok = true;
        std::string zqf_dbbhg_desc, zqf_dbresult;
        std::string yhf_dbbhg_desc, yhf_dbresult;

        /* 车标判定必须放在此处，因为result=3的程度比4高，比5低  */
        {
            if(g_CheckItem.City != JIUJIANG)
            {
                if (g_CheckItem.picture.ZuoQianFang.CheBiao) {
                    if (!HuoChe_ZuoQianFang.b_chebiao) {
                        zqf_ok = false;
                        zqf_dbbhg_desc += "[车标不正确]";
                        zqf_dbresult = FATAL_ERROR;

                    }
                }
            }

        }

        /* 车牌 */
        {
            if (g_CheckItem.picture.ZuoQianFang.ChePai) {
                if (!HuoChe_ZuoQianFang.b_chepai && !IsNewVehicle) {
                    zqf_ok = false;
                    zqf_dbbhg_desc += "[车牌号不正确]";
                    zqf_dbresult = FATAL_ERROR;
                }
            }

            if (g_CheckItem.picture.YouHouFang.ChePai) {
                if (!HuoChe_YouHouFang.b_chepai && !IsNewVehicle) {
                    yhf_ok = false;
                    yhf_dbbhg_desc += HPHM_ERROR;
                    yhf_dbresult = FATAL_ERROR;
                }
            }
        }

        /* 全部货车 */
        if (p_vehicle_inf->m_cllx.substr(0, 1) == "H") {
            // 左侧车身反光标识 + 后部车身反光标识
            {
                if (g_CheckItem.picture.ZuoQianFang.ZuoCeFangHu) {
                    if (!HuoChe_ZuoQianFang.b_left_reflect) {
                        zqf_ok = false;
                        zqf_dbbhg_desc += "[左侧车身反光标识错误]";
                        zqf_dbresult = FATAL_ERROR;
                    }
                }

                if (g_CheckItem.picture.YouHouFang.HouBuCheShenFanGuangBiaoShi) {
                    if (!HuoChe_YouHouFang.b_rear_reflect) {
                        yhf_ok = false;
                        yhf_dbbhg_desc += "[后部车身反光标识错误]";
                        yhf_dbresult = FATAL_ERROR;
                    }
                }
            }

            // 驾驶室（区）左侧喷涂的总质量 + 右侧面车身反光标识
            {
                if (g_CheckItem.picture.ZuoQianFang.ZuoCePenTu) {
                    if (!HuoChe_ZuoQianFang.b_quality) {
                        zqf_ok = false;
                        zqf_dbbhg_desc += "[驾驶室左侧喷涂的总质量错误]";
                        zqf_dbresult = FATAL_ERROR;
                    }
                }

                if (g_CheckItem.picture.YouHouFang.YouCeCheShenFanGuangBiaoShi) {
                    if (!HuoChe_YouHouFang.b_right_reflect) {
                        yhf_ok = false;
                        yhf_dbbhg_desc += "[右侧面车身反光标识错误]";
                        yhf_dbresult = FATAL_ERROR;
                    }
                }
            }

            // 总质量>3500kg的货车 + 总质量>4500kg的货车
            int n_zzl = atoi(p_vehicle_inf->m_zzl.c_str());
            {
                if (n_zzl > 3500) {
                    if (g_CheckItem.picture.ZuoQianFang.ZuoCeFangHu) {
                        if (!HuoChe_ZuoQianFang.b_left_protect) {
                            zqf_ok = false;
                            zqf_dbbhg_desc += "[左侧防护装置错误]";
                            zqf_dbresult = FATAL_ERROR;
                        }
                    }

                    if (g_CheckItem.picture.YouHouFang.HouXiaFangHu) {
                        if (!HuoChe_YouHouFang.b_rear_protect) {   // 后下部防护装置
                            yhf_ok = false;
                            yhf_dbbhg_desc += "[后下部防护装置错误]";
                            yhf_dbresult = FATAL_ERROR;
                        }
                    }

                    if (g_CheckItem.picture.YouHouFang.YouCeFangHu) {
                        if (!HuoChe_YouHouFang.b_right_protect) {//右侧面防护装置
                            yhf_ok = false;
                            yhf_dbbhg_desc += "[右侧面防护装置错误]";
                            yhf_dbresult = FATAL_ERROR;
                        }
                    }
                } //总质量>3500kg的货车结束

                if (n_zzl > 4500) {
                    if (g_CheckItem.picture.YouHouFang.HouBuPenTu) {
                        if (!HuoChe_YouHouFang.b_pentu_chepai) {//车厢后部喷涂或粘贴的放大的号牌号码
                            yhf_ok = false;
                            yhf_dbbhg_desc += "[车厢后部喷涂或粘贴的放大的号牌号码错误]";
                            yhf_dbresult = FATAL_ERROR;
                        }
                    }
                }// 总质量>4500kg的货车结束
            }

            // 车辆尾部标志板
            {
                if ((p_vehicle_inf->m_cllx.substr(0, 2)=="H1") || (p_vehicle_inf->m_cllx.substr(0, 2)=="H5")) {
                    if (g_CheckItem.picture.YouHouFang.CheLiangWeiBuBiaoZhiBan) { // 重型/长型/低速车辆（长型未找到车辆类型）
                        if (!HuoChe_YouHouFang.b_rear_plate) {
                            yhf_ok = false;
                            yhf_dbbhg_desc += "[车辆尾部标志板错误]";
                            yhf_dbresult = FATAL_ERROR;
                        }
                    }
                }
            }
        } // 货车结束

        if (!zqf_ok) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[zuo].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[zuo].zptype;
            v_dbhhg_list.dbbhg_desc = "左前方-照片:" + zqf_dbbhg_desc;
            v_dbhhg_list.dbresult = zqf_dbresult;

            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }
        }

        if (!yhf_ok) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[you].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[you].zptype;
            v_dbhhg_list.dbbhg_desc = "右后方-照片:" + yhf_dbbhg_desc;
            v_dbhhg_list.dbresult = yhf_dbresult;

            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }
        }
    }// 大车结束
}

void ResultCollection::doAnalyse_ZuoYou(vehicle_inf *p_vehicle_inf, bool IsLeft, int i)
{
    // 大小车判断
    if ((p_vehicle_inf->m_cllx.substr(0, 2)=="K3") || (p_vehicle_inf->m_cllx.substr(0, 2)=="K4")) { // 小车
        if (p_vehicle_inf->m_zplist[i].zptype == ZhaoPianZL.ZuoFang) {
            BOOL ok = TRUE;
            std::string dbbhg_desc, dbresult;

            /* 车牌*/
            if (g_CheckItem.picture.ZuoFang.ChePai) {
                if (!ZuoFang.b_chepai) {
                    ok = FALSE;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[车牌不正确]";
                }
            }

            if(g_CheckItem.picture.ZuoFang.CheShenYanSe){
                if (!ZuoFang.b_ori_color) {
                    ok = FALSE;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[车辆颜色有变化]";
                }
            }

            /* 改装 */
     /*       if (g_CheckItem.picture.ZuoFang.GaiZhuang) {
                if (ZuoQianFang_A) {
                    std::string GaiZhuang;
                    bool GaiZhuang_ok = true;



                    if (!GaiZhuang_ok) {
                        ok = FALSE;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[与档案照片不符合：" + GaiZhuang + "]";
                    }
                } else {
                    ok = FALSE;
                    dbbhg_desc += "[缺少档案照片，无法判定是否改装]";
                    dbresult = NEED_MANUAL;
                }
            } */

            /* 侧面广告*/
            if (g_CheckItem.picture.ZuoFang.GuangGao) {
                if (ZuoFang.i_tiehua != 0) {
                    ok = FALSE;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[车辆有广告]";
                }
            }

            if (!ok) {
                _dbbhg_list v_dbhhg_list;
                v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
                v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
                v_dbhhg_list.dbbhg_desc = "左方-照片:" + dbbhg_desc;
                v_dbhhg_list.dbresult = dbresult;
                p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
                if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                    dbbhgs++;
                }
            }

        } else {
            BOOL ok = TRUE;
            std::string dbbhg_desc, dbresult;

            if(g_CheckItem.City==NINGBO)
            {
                if(p_vehicle_inf->is_black_list)
                {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[黑名单车辆]";
                    p_vehicle_inf->is_black_list=false;
                }
            }

            if (IsLeft) {
                /* 判定水印日期 */
                if(g_CheckItem.picture.ZuoQianFang.ShuiYinRiQi)
                {
                    if (!bZuoQianFangShuiYinRiQi) {
                        ok = false;
                        dbbhg_desc += OUT_OF_DATE;
                        dbresult = FATAL_ERROR;
                    }
                }

                if(g_CheckItem.picture.ZuoQianFang.CheShenYanSe){

                    if (!ZuoQianFang.b_ori_color) {
                        ok = false;
                        dbbhg_desc += "[车辆颜色有变化]";
                        dbresult = FATAL_ERROR;
                    }
                }

  /*

             if (g_CheckItem.picture.ZuoQianFang.GaiZhuang) {
                    if (ZuoQianFang_A) {
                        std::string GaiZhuang;
                        bool GaiZhuang_ok = true;

//                        if (!ZuoQianFang.b_ori_waiguan) {
//                            GaiZhuang_ok = false;
//                            GaiZhuang += "外观有变化.";
//                        }

//                        if (!ZuoQianFang.b_ori_lamp) {
//                            GaiZhuang_ok = false;
//                            GaiZhuang += "车灯有变化.";
//                        }

                        if (!ZuoQianFang.b_ori_color) {
                            GaiZhuang_ok = false;
                            GaiZhuang += "车辆颜色有变化.";
                        }

                        if (!GaiZhuang_ok) {
                            ok = FALSE;
                            if(g_CheckItem.City==NINGBO)
                            {
                                p_vehicle_inf->is_black_list=true;
                            }
                            dbresult = FATAL_ERROR;
                            dbbhg_desc += "[与档案照片不符合：" + GaiZhuang + "]";
                        }
                    } else {
                        if (g_CheckItem.City == SUZHOU) { // 苏州外地车，如果没有档案照片，则不做判定
                            if (p_vehicle_inf->m_fzjg == "苏E") {
                                ok = FALSE;
                                dbbhg_desc += "[缺少档案照片，无法判定是否改装]";
                                dbresult = NEED_MANUAL;
                            }
                        } else {
                            ok = FALSE;
                            dbbhg_desc += "[缺少档案照片，无法判定是否改装]";
                            dbresult = NEED_MANUAL;
                        }
                    }
                }
*/
                /* 判定车标 */
                if (g_CheckItem.picture.ZuoQianFang.CheBiao) {
                    if (!ZuoQianFang.b_chebiao) {
                        ok = FALSE;
                        dbbhg_desc += "[车标不正确]";
                        dbresult = FATAL_ERROR;
                    }

                }
                /* 判定车牌 */
                if (BINZHOU == g_CheckItem.City)
                {
                    if (g_CheckItem.picture.ZuoQianFang.ChePai) {
                        if ((!ZuoQianFang.b_chepai) && (!IsNewVehicle)) {
                            ok = false;
                            dbbhg_desc += HPHM_ERROR;
                            dbresult = FATAL_ERROR;
                            if ((p_vehicle_inf->m_b_zqf_checked) && (g_CheckItem.video.ZuoQianFang.ChePai))
                            {
                                if (!V_ZuoQianFang.b_chepai)
                                {
                                    ok = false;
                                    dbbhg_desc += "[视频-车牌号不正确]";
                                    dbresult = FATAL_ERROR;
                                }
                                else
                                {
                                    dbbhg_desc += "[视频-车牌号正确]";
                                }
                            }
                        }
                    }
                }
                else if(YICHUN == g_CheckItem.City)
                {
                    if(g_CheckItem.picture.ZuoQianFang.ChePai)
                    {
                        if(!ZuoQianFang.b_chepai && !IsNewVehicle)
                        {
                            if(p_vehicle_inf->m_b_zqf_checked && g_CheckItem.video.ZuoQianFang.ChePai)
                            {
                                if(!V_ZuoQianFang.b_chepai)
                                {
                                    ok = false;
                                    dbbhg_desc += HPHM_ERROR;
                                    dbresult = FATAL_ERROR;
                                    dbbhg_desc += "[视频-车牌不正确]";
                                }
                            }
                            else
                            {
                                ok = false;
                                dbbhg_desc += HPHM_ERROR;
                                dbresult = FATAL_ERROR;
                            }
                        }
                    }

                }
                else
                {
                    if (g_CheckItem.video.ZuoQianFang.ChePai)
                    {
                        if (!V_ZuoQianFang.b_chepai){
                            ok = false;
                            dbbhg_desc += "[视频检测车牌号不正确]";
                            dbresult = FATAL_ERROR;
                        }
                    } else {
                        if (g_CheckItem.picture.ZuoQianFang.ChePai) {
                            if ((!ZuoQianFang.b_chepai) && (!IsNewVehicle)) {
                                ok = FALSE;
                                dbbhg_desc += HPHM_ERROR;
                                dbresult = FATAL_ERROR;
                            }
                        }
                    }
                }

                if(BINZHOU == g_CheckItem.City)
                {
                    if ((p_vehicle_inf->m_b_zqf_checked) && (g_CheckItem.video.ZuoQianFang.ChePai))
                    {
                        if (!V_ZuoQianFang.b_time)
                        {
                            ok = false;
                            dbbhg_desc += "[视频-检查时间不足]";
                            dbresult = FATAL_ERROR;
                        }
                        else
                        {
                            dbbhg_desc += "[视频-检查时间正常]";
                        }
                    }
                }

                /* 判定三脚架 */
                if (g_CheckItem.picture.ZuoQianFang.SanJiaoJia) {
                    if (!ZuoQianFang.b_sanjiaojia) {
                        ok = FALSE;
                        dbbhg_desc += NO_TRIPOD;
                        dbresult = FATAL_ERROR;
                    }
                }

                /* 判定车头方向*/
                if (g_CheckItem.picture.ZuoQianFang.FangXiang) {
                    if (!ZuoQianFang.b_oritation_right) {
                        ok = FALSE;
                        dbbhg_desc += "[不是左前方照片]";
                        dbresult = FATAL_ERROR;
                    }
                }

                /* 南平广告*/
                if ((g_CheckItem.City==NANPING) && (ZuoQianFang.i_tiehua != 0)) {
                    ok = FALSE;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[车辆有广告]";
                }

                if(g_CheckItem.City == TAIYUAN)
                {
                    if(p_vehicle_inf->m_syxz == "N")
                    {
                        if(!ZuoQianFang.b_fuzhu_houshijing)
                        {
                            ok = FALSE;
                            dbbhg_desc += "[无辅助后视镜]";
                            dbresult = FATAL_ERROR;
                        }
                    }
                }

                if (!ok) {
                    _dbbhg_list v_dbhhg_list;
                    v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
                    v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
                    v_dbhhg_list.dbbhg_desc = "左前方-照片:" + dbbhg_desc;
                    v_dbhhg_list.dbresult = dbresult;
                    p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
                    if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                        dbbhgs++;
                    }
                }
            } else {
                /* 判定水印日期 */
                if(g_CheckItem.picture.YouHouFang.ShuiYinRiQi)
                {
                    if (!bYouHouFangShuiYinRiQi) {
                        ok = false;
                        dbbhg_desc += OUT_OF_DATE;
                        dbresult = FATAL_ERROR;
                    }
                }


                // 颜色
                if(g_CheckItem.picture.YouHouFang.CheShenYanSe)
                {
                    if (!YouHouFang.b_ori_color) {
                        ok = false;
                        dbbhg_desc = "[车辆颜色有变化]";
                        dbresult = FATAL_ERROR;
                    }
                }

                /* 判定车标 */
                if (g_CheckItem.picture.YouHouFang.CheBiao) {
                    if (!YouHouFang.b_chebiao) {
                        ok = FALSE;
                        dbbhg_desc += "[车标不正确]";
                        dbresult = FATAL_ERROR;
                    }
                }

                /* 判定车牌 */
                if (BINZHOU == g_CheckItem.City)
                {
                    if (g_CheckItem.picture.YouHouFang.ChePai) {
                        if ((!YouHouFang.b_chepai) && (!IsNewVehicle)) {
                            ok = false;
                            dbbhg_desc += HPHM_ERROR;
                            dbresult = FATAL_ERROR;
                            if ((p_vehicle_inf->m_b_yhf_checked) && (g_CheckItem.video.YouHouFang.ChePai))
                            {
                                if (!V_YouHouFang.b_chepai)
                                {
                                    dbbhg_desc += "[视频-车牌号不正确]";
                                    dbresult = FATAL_ERROR;
                                    ok = false;
                                }
                                else
                                {
                                    dbbhg_desc += "[视频-车牌号正确]";
                                }
                            }
                        }
                    }
                }
                else if(YICHUN == g_CheckItem.City)
                {
                    if(g_CheckItem.picture.YouHouFang.ChePai)
                    {
                        if(!YouHouFang.b_chepai && !IsNewVehicle){
                            if(p_vehicle_inf->m_b_yhf_checked && g_CheckItem.video.YouHouFang.ChePai)
                            {
                                if(!V_YouHouFang.b_chepai)
                                {
                                    ok = FALSE;
                                    dbbhg_desc += HPHM_ERROR;
                                    dbresult = FATAL_ERROR;
                                    dbbhg_desc +="[视频-车牌不正确]";
                                }
                            }
                            else
                            {
                                ok = FALSE;
                                dbbhg_desc += HPHM_ERROR;
                                dbresult = FATAL_ERROR;
                            }
                        }
                    }
                }
                else
                {
                    if (g_CheckItem.video.YouHouFang.ChePai)
                    {
                        if (!V_YouHouFang.b_chepai){
                            ok = false;
                            dbbhg_desc += "[视频检测车牌号不正确]";
                            dbresult = FATAL_ERROR;
                        }
                    }
                    else
                    {
                        if (g_CheckItem.picture.YouHouFang.ChePai) {
                            if ((!YouHouFang.b_chepai) && (!IsNewVehicle)) {
                                ok = FALSE;
                                dbbhg_desc += HPHM_ERROR;
                                dbresult = FATAL_ERROR;
                            }
                        }
                    }
                }

                if(BINZHOU == g_CheckItem.City)
                {
                    if ((p_vehicle_inf->m_b_yhf_checked) && (g_CheckItem.video.YouHouFang.ChePai))
                    {
                        if (!V_YouHouFang.b_time)
                        {
                            ok = false;
                            dbbhg_desc += "[视频-检查时间不足]";
                            dbresult = FATAL_ERROR;
                        }
                        else
                        {
                            dbbhg_desc += "[视频-检查时间正常]";
                        }
                    }
                }

                /* 判定三脚架 */
                if (g_CheckItem.picture.YouHouFang.SanJiaoJia) {
                    if (!YouHouFang.b_sanjiaojia) {
                        ok = FALSE;
                        dbbhg_desc += NO_TRIPOD;
                        dbresult = FATAL_ERROR;
                    }
                }

                /* 改装 */
                if (g_CheckItem.picture.YouHouFang.GaiZhuang) {
                    if (!YouHouFang.b_ori_waiguan) {

                        if(g_CheckItem.City==NINGBO)
                        {
                            p_vehicle_inf->is_black_list=true;
                        }

                    }
                }

                if(g_CheckItem.City==NINGBO)
                {
                    if(p_vehicle_inf->is_black_list)
                    {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[车辆已加入黑名单]";
                    }
                }

                /* 判定车头方向*/
                if (g_CheckItem.picture.YouHouFang.FangXiang) {
                    if (!ZuoQianFang.b_oritation_right) {
                        ok = FALSE;
                        dbbhg_desc += "[不是右后方照片]";
                        dbresult = FATAL_ERROR;
                    }
                }

                /* 南平广告*/
                if ((g_CheckItem.City==NANPING) && (YouHouFang.i_tiehua != 0)) {
                    ok = FALSE;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[车辆有广告]";
                }

                if(g_CheckItem.City == TAIYUAN)
                {
                    if(p_vehicle_inf->m_syxz == "N")
                    {
                        if(!JiaoLianCheYouHouFang.b_jiaolianche_ziyang)
                        {
                            ok = FALSE;
                            dbbhg_desc += "[教练车字样识别错误]";
                            dbresult = FATAL_ERROR;
                        }
                    }
                }

                if (!ok) {
                    _dbbhg_list v_dbhhg_list;
                    v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
                    v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
                    v_dbhhg_list.dbbhg_desc = "右后方-照片:" + dbbhg_desc;
                    v_dbhhg_list.dbresult = dbresult;
                    p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
                    if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                        dbbhgs++;
                    }
                }
            }

        }
    } else if ((p_vehicle_inf->m_cllx.substr(0, 2)=="M1") ||
               (p_vehicle_inf->m_cllx.substr(0, 2)=="M2") ||
               (p_vehicle_inf->m_cllx.substr(0, 2)=="N1")) { // 摩托车
        BOOL ok = TRUE;
        std::string dbbhg_desc, dbresult;

        if (IsLeft) {
            // 安全帽
            if (!ZuoQianFang.b_anquanmao) {
                ok = false;
                dbbhg_desc += "[安全帽不存在]";
                dbresult = FATAL_ERROR;
            }

            // 颜色
            if(g_CheckItem.picture.ZuoQianFang.CheShenYanSe)
            {
                if (!ZuoQianFang.b_ori_color) {
                    ok = false;
                    dbbhg_desc = "[车辆颜色有变化]";
                    dbresult = FATAL_ERROR;
                }
            }


            if (!ok) {
                _dbbhg_list v_dbhhg_list;
                v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
                v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
                v_dbhhg_list.dbbhg_desc = "左前方-照片:" + dbbhg_desc;
                v_dbhhg_list.dbresult = dbresult;
                p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
                if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                    dbbhgs++;
                }
            }
        } else {
            // 安全帽
            if (!YouHouFang.b_anquanmao) {
                ok = false;
                dbbhg_desc += "[安全帽不存在]";
                dbresult = FATAL_ERROR;
            }

            // 颜色
            if(g_CheckItem.picture.YouHouFang.CheShenYanSe)
            {
                if (!YouHouFang.b_ori_color) {
                    ok = false;
                    dbbhg_desc = "[车辆颜色有变化]";
                    dbresult = FATAL_ERROR;
                }
            }


            // 号牌号码
            if (!YouHouFang.b_chepai) {
                ok = false;
                dbbhg_desc = HPHM_ERROR;
                dbresult = FATAL_ERROR;
            }

            if (!ok) {
                _dbbhg_list v_dbhhg_list;
                v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
                v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
                v_dbhhg_list.dbbhg_desc = "右后方照片:" + dbbhg_desc;
                v_dbhhg_list.dbresult = dbresult;
                p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
                if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                    dbbhgs++;
                }
            }
        }
     } else { // 大车
        bool zqf_ok = true, yhf_ok = true;
        std::string zqf_dbbhg_desc, zqf_dbresult;
        std::string yhf_dbbhg_desc, yhf_dbresult;

        /* 车标判定必须放在此处，因为result=3的程度比4高，比5低  */
        {
            if(g_CheckItem.City != JIUJIANG){
                if (g_CheckItem.picture.ZuoQianFang.CheBiao) {
                    if (!HuoChe_ZuoQianFang.b_chebiao) {
                        zqf_ok = false;
                        zqf_dbbhg_desc += "[车标不正确]";
                        zqf_dbresult = FATAL_ERROR;
                    }
                }
            }
        }

        /* 车牌 */
        {
            if (g_CheckItem.picture.ZuoQianFang.ChePai) {
                if (!HuoChe_ZuoQianFang.b_chepai && !IsNewVehicle) {
                    zqf_ok = false;
                    zqf_dbbhg_desc += HPHM_ERROR;
                    zqf_dbresult = FATAL_ERROR;
                }
            }

            if ((g_CheckItem.picture.YouHouFang.ChePai) && (!IsLeft)) {
                if (!HuoChe_YouHouFang.b_chepai && !IsNewVehicle) {
                    yhf_ok = false;
                    yhf_dbbhg_desc += HPHM_ERROR;
                    yhf_dbresult = FATAL_ERROR;
                }
            }
        }

        /* 全部货车 */
        if (p_vehicle_inf->m_cllx.substr(0, 1) == "H") {
            // 左侧车身反光标识 + 后部车身反光标识
            {
                if (g_CheckItem.picture.ZuoQianFang.ZuoCeFangHu) {
                    if (!HuoChe_ZuoQianFang.b_left_reflect) {
                        zqf_ok = false;
                        zqf_dbbhg_desc += "[左侧车身反光标识错误]";
                        zqf_dbresult = FATAL_ERROR;
                    }
                }

                if ((g_CheckItem.picture.YouHouFang.HouBuCheShenFanGuangBiaoShi) && (!IsLeft)) {
                    if (!HuoChe_YouHouFang.b_rear_reflect) {
                        yhf_ok = false;
                        yhf_dbbhg_desc += "[后部车身反光标识错误]";
                        yhf_dbresult = FATAL_ERROR;
                    }
                }
            }

            // 驾驶室（区）左侧喷涂的总质量 + 右侧面车身反光标识
            {
                if (g_CheckItem.picture.ZuoQianFang.ZuoCePenTu) {
                    if (!HuoChe_ZuoQianFang.b_quality) {
                        zqf_ok = false;
                        zqf_dbbhg_desc += "[驾驶室左侧喷涂的总质量错误]";
                        zqf_dbresult = FATAL_ERROR;
                    }
                }

                if ((g_CheckItem.picture.YouHouFang.YouCeCheShenFanGuangBiaoShi) && (!IsLeft)) {
                    if (!HuoChe_YouHouFang.b_right_reflect) {
                        yhf_ok = false;
                        yhf_dbbhg_desc += "[右侧面车身反光标识错误]";
                        yhf_dbresult = FATAL_ERROR;
                    }
                }
            }

            // 总质量>3500kg的货车 + 总质量>4500kg的货车
            int n_zzl = atoi(p_vehicle_inf->m_zzl.c_str());
            {
                if (n_zzl > 3500) {
                    if (g_CheckItem.picture.ZuoQianFang.ZuoCeFangHu) {
                        if (!HuoChe_ZuoQianFang.b_left_protect) {
                            zqf_ok = false;
                            zqf_dbbhg_desc += "[左侧防护装置错误]";
                            zqf_dbresult = FATAL_ERROR;
                        }
                    }

                    if ((g_CheckItem.picture.YouHouFang.HouXiaFangHu) && (!IsLeft)) {
                        if (!HuoChe_YouHouFang.b_rear_protect) {   // 后下部防护装置
                            yhf_ok = false;
                            yhf_dbbhg_desc += "[后下部防护装置错误]";
                            yhf_dbresult = FATAL_ERROR;
                        }
                    }

                    if ((g_CheckItem.picture.YouHouFang.YouCeFangHu) && (!IsLeft)) {
                        if (!HuoChe_YouHouFang.b_right_protect) {//右侧面防护装置
                            yhf_ok = false;
                            yhf_dbbhg_desc += "[右侧面防护装置错误]";
                            yhf_dbresult = FATAL_ERROR;
                        }
                    }
                } // 总质量>3500kg的货车结束

                if (n_zzl > 4500) {
                    if ((g_CheckItem.picture.YouHouFang.HouBuPenTu) && (!IsLeft)) {
                        if (!HuoChe_YouHouFang.b_pentu_chepai) {//车厢后部喷涂或粘贴的放大的号牌号码
                            yhf_ok = false;
                            yhf_dbbhg_desc += "[车厢后部喷涂或粘贴的放大的号牌号码错误]";
                            yhf_dbresult = FATAL_ERROR;
                        }
                    }
                }// 总质量>4500kg的货车结束
            }

            // 车辆尾部标志板
            {
                if ((p_vehicle_inf->m_cllx.substr(0, 2)=="H1") || (p_vehicle_inf->m_cllx.substr(0, 2)=="H5")) {
                    if ((g_CheckItem.picture.YouHouFang.CheLiangWeiBuBiaoZhiBan) && (!IsLeft)) { // 重型/长型/低速车辆（长型未找到车辆类型）
                        if (!HuoChe_YouHouFang.b_rear_plate) {
                            yhf_ok = false;
                            yhf_dbbhg_desc += "[车辆尾部标志板错误]";
                            yhf_dbresult = FATAL_ERROR;
                        }
                    }
                }
            }
        } // 货车结束

        if ((!zqf_ok) && (IsLeft)) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
            v_dbhhg_list.dbbhg_desc = "左前方-照片:" + zqf_dbbhg_desc;
            v_dbhhg_list.dbresult = zqf_dbresult;

            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }
        }

        if ((!yhf_ok) && (!IsLeft)) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
            v_dbhhg_list.dbbhg_desc = "右后方-照片:" + yhf_dbbhg_desc;
            v_dbhhg_list.dbresult = yhf_dbresult;

            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }
        }
    }// 大车结束
}

void ResultCollection::doAnalyse_zqf_yhf_cjh_cf(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if (p_vehicle_inf->m_zplist[i].zptype == "0390") {
        if (!ZuoQianFangChuFa.b_chepai1) {
            ok = false;
            dbbhg_desc += HPHM_ERROR;
            dbresult = FATAL_ERROR;
        }
    } else if (p_vehicle_inf->m_zplist[i].zptype == "0391") {
        if (!YouHouFangChuFa.b_chepai1) {
            ok = false;
            dbbhg_desc += HPHM_ERROR;
            dbresult = FATAL_ERROR;
        }
    } else if (p_vehicle_inf->m_zplist[i].zptype == "0392") {
        if (!CheJiaHaoChuFa.b_chepai1) {
            ok = false;
            dbbhg_desc += HPHM_ERROR;
            dbresult = FATAL_ERROR;
        }
    } else {
        ok = false;
        dbbhg_desc += "[未知照片类型，建议人工]";
        dbresult = FATAL_ERROR;
    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        if (p_vehicle_inf->m_zplist[i].zptype == "0390") {
            v_dbhhg_list.dbbhg_desc = "左前方触发-照片:" + dbbhg_desc;
        } else if (p_vehicle_inf->m_zplist[i].zptype == "0391") {
            v_dbhhg_list.dbbhg_desc = "右后方触发-照片:" + dbbhg_desc;
        } else if (p_vehicle_inf->m_zplist[i].zptype == "0392") {
            v_dbhhg_list.dbbhg_desc = "车架号触发-照片:" + dbbhg_desc;
        } else {
            v_dbhhg_list.dbbhg_desc = "未知触发-照片:" + dbbhg_desc;
        }
        v_dbhhg_list.dbresult = dbresult;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        dbbhgs++;
    }
}

void ResultCollection::doAnalyse_CheJiaHao(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if (g_CheckItem.picture.CheJiaHao.TaYinMo) {


        if (TaYinMo_J) {

            if (!CheJiaHao.b_ori_chejiahao) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[车架号字型与拓印膜不符]";
            }

            if (!CheJiaHao.b_tuomo) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[车架号拓印膜不正确]";
            }

        } else {
            if (g_CheckItem.City == SUZHOU) {/* 苏州外地车，如果没有档案照片，则不做判定 */
                if (p_vehicle_inf->m_fzjg == "苏E") {
                    ok = false;
                    dbresult = NEED_MANUAL;
                    dbbhg_desc += "[缺少拓印膜照片，无法判定车架号是否更改]";
                }else if(g_CheckItem.picture.CheJiaHao.DangAn){
                    ok = false;
                    dbresult = NEED_MANUAL;
                    dbbhg_desc += "[缺少拓印膜照片，无法判定车架号是否更改]";
                }

           } else if(g_CheckItem.picture.CheJiaHao.DangAn){
                ok = false;
                dbresult = NEED_MANUAL;
                dbbhg_desc += "[缺少拓印膜照片，无法判定车架号是否更改]";
           }

        }
    }

    if (g_CheckItem.picture.CheJiaHao.ShuiYinRiQi) {
        if (!bCheJiaHaoShuiYinRiQi) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += OUT_OF_DATE;
        }
    }



    if (g_CheckItem.picture.CheJiaHao.CheJiaHao) {
        if (!CheJiaHao.b_chejiahao) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += CHE_JIA_HAO_ERROR;
        }
    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "车架号-照片:";

        if (CheJiaHao.b_pic_quality) {
            v_dbhhg_list.dbresult = dbresult;
            v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        } else {
            v_dbhhg_list.dbresult = NEED_MANUAL;
            v_dbhhg_list.dbbhg_desc += PICTURE_NOT_STANDARD;
        }

        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}

void ResultCollection::doAnalyse_AnQuanDai(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if (g_CheckItem.picture.AnQuanDai.ShuiYinRiQi) {
        if (!bAnQuanDaiShuiYinRiQi) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += OUT_OF_DATE;
        }
    }
    if (g_CheckItem.picture.AnQuanDai.AnQuanDai) {
        if (!AnQuanDai.b_anquandai) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[没有安全带]";
        }
    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "安全带-照片:" + dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}


void ResultCollection::doAnalyse_CheJiaHaoUG(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if (g_CheckItem.picture.CheJiaHaoUG.CheJiaHao) {
        if (!CheJiaHaoUG.b_pic_quality) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[拍摄规范不合格]";
        }

        if (!CheJiaHaoUG.b_chejiahao) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += CHE_JIA_HAO_ERROR;
        }
    }


    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "车架号（玻璃下）-照片:" + dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}

void ResultCollection::doAnalyse_CheLiangMingPai(vehicle_inf *p_vehicle_inf,int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if (g_CheckItem.picture.CheLiangMingPai.CheJiaHao) {
        if (!CheLiangMingPai.b_pic_quality) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[拍摄规范不合格]";
        }

        if (!CheLiangMingPai.b_chejiahao) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += CHE_JIA_HAO_ERROR;
        }
    }
    if (g_CheckItem.picture.CheLiangMingPai.FaDongJiHao) {
//        if (!CheLiangMingPai.b_fadongjihao) {
//            ok = false;
//            dbresult = FATAL_ERROR;
//            dbbhg_desc += "[发动机号不匹配]";
//        }
    }
    if (g_CheckItem.picture.CheLiangMingPai.FaDongJiPaiLiang) {
        if (!CheLiangMingPai.b_pailiang) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[排量不匹配]";
        }
    }
    if (g_CheckItem.picture.CheLiangMingPai.ZhiZaoNianYue) {
//        if (!CheLiangMingPai.b_zhizaonianyue) {
//            ok = false;
//            dbresult = FATAL_ERROR;
//            dbbhg_desc += "[制造年月不匹配]";
//        }
    }


    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "车辆铭牌-照片:" + dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}

void ResultCollection::doAnalyse_DengGuangGongWie(vehicle_inf *p_vehicle_inf, int zuo, int you)
{
    if ((zuo == -1) && (you == -1)) {
        return;
    }

    /*
     * 左右灯光配置项逻辑说明：
     * 1. ZuoQianDeng和YouQianDeng都打开：必须判定两个灯都亮才算通过
     * 2. ZuoQianDeng和YouQianDeng打开二者之一：判定两个灯，有一个亮就算通过
     * 3. ZuoQianDeng和YouQianDeng都关闭：不判定两个车灯
    */
    if(g_CheckItem.City == YICHUN)
    {
        doAnalyse_DengGuangGongWie_YiChun(p_vehicle_inf, zuo, you);
        return;
    }

    if (zuo != -1) {
        bool ok = true;
        std::string dbbhg_desc, dbresult;

        if (JIAOZUO == g_CheckItem.City) {
            if (!ZuoDengGuangGongWei.b_car_left_light_on && !YouDengGuangGongWei.b_car_left_light_on) { // 左灯光工位和右灯光工位灯1都不亮
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += NOT_BRIGHT;
            }
        }
        else if (BINZHOU == g_CheckItem.City)
        {
            if (g_CheckItem.picture.ZuoDengGuang.ZuoQianDeng || g_CheckItem.picture.ZuoDengGuang.YouQianDeng)
            {
                if (!ZuoDengGuangGongWei.b_car_left_light_on || !ZuoDengGuangGongWei.b_car_right_light_on)
                {
                    dbbhg_desc += NOT_BRIGHT;
                    ok = false;
                    dbresult = FATAL_ERROR;
                    if ((p_vehicle_inf->m_b_zdg_checked) && (g_CheckItem.video.ZuoDengGuang.QianDaDeng))
                    {
                        if (!V_ZuoDengGuang.b_light_on)
                        {
                            ok = false;
                            dbresult = FATAL_ERROR;
                            dbbhg_desc += "[视频-灯光不亮]";
                        }
                        else
                        {
                            dbbhg_desc += "[视频-灯光正常]";
                        }
                    }
                }
            }
        }
        else {
            if (g_CheckItem.picture.ZuoDengGuang.ZuoQianDeng && g_CheckItem.picture.ZuoDengGuang.YouQianDeng) {
                if (!ZuoDengGuangGongWei.b_car_left_light_on || !ZuoDengGuangGongWei.b_car_right_light_on) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += NOT_BRIGHT;
                }
            } else if (g_CheckItem.picture.ZuoDengGuang.ZuoQianDeng || g_CheckItem.picture.ZuoDengGuang.YouQianDeng) {
                if (!ZuoDengGuangGongWei.b_car_left_light_on && !ZuoDengGuangGongWei.b_car_right_light_on) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += NOT_BRIGHT;
                }
            }
        }

        if ((p_vehicle_inf->m_b_zdg_checked) && (BINZHOU == g_CheckItem.City))
        {
            if ((!V_ZuoDengGuang.b_human_clear) && (g_CheckItem.video.ZuoDengGuang.Ren))
            {
                dbbhg_desc += "[视频-有人经过]";
                dbresult = FATAL_ERROR;
                ok = false;
            }
            else
            {
                dbbhg_desc += "[视频-无人员经过]";
            }

            if ((!V_ZuoDengGuang.b_tester_move) && (g_CheckItem.video.ZuoDengGuang.CeShiYi))
            {
                dbbhg_desc += "[视频-测试仪移动]";
                dbresult = FATAL_ERROR;
                ok = false;
            }
            else
            {
                dbbhg_desc += "[视频-测试仪正常]";
            }

            if (!V_ZuoDengGuang.b_time)
            {
                dbbhg_desc += "[视频-检测时间不足]";
                dbresult = FATAL_ERROR;
                ok = false;
            }
            else
            {
                dbbhg_desc += "[视频-检测时间正常]";
            }
        }
        if (g_CheckItem.picture.ZuoDengGuang.ShuiYinRiQi) {
            if (!bZuoDengGuangShuiYinRiQi) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += OUT_OF_DATE;
            }
        }

        if (g_CheckItem.picture.ZuoDengGuang.ChePai) {
            if (BINZHOU == g_CheckItem.City)
            {
                if ((p_vehicle_inf->m_b_zdg_checked) && (g_CheckItem.video.ZuoDengGuang.ChePai))
                {
                    if (!V_ZuoDengGuang.b_chepai)
                    {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[视频-车牌不正确]";
                    }
                    else
                    {
                        dbbhg_desc += "[视频-车牌正确]";
                    }
                }
            }
            bool b_chepai = true;
            if(g_CheckItem.City == FUZHOU2)
            {
                 b_chepai =  ZuoDengGuangGongWei.b_chepai || YouDengGuangGongWei.b_chepai; //不管清晰与否，即两个车牌中有一个正确即可;
            }
            else
            {
                if(ZuoDengGuangGongWei.b_chepai_clear) b_chepai = b_chepai && ZuoDengGuangGongWei.b_chepai; // 清晰的车牌必须正确
                if(!ZuoDengGuangGongWei.b_chepai_clear && !YouDengGuangGongWei.b_chepai_clear)
                {
                    if( !(ZuoDengGuangGongWei.b_chepai || YouDengGuangGongWei.b_chepai) ) b_chepai = false; //若都不清晰，有一个正确即可，若都不正确，则返回false
                }
            }
            if(!b_chepai && !IsNewVehicle)
            {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += HPHM_ERROR;
            }
        }

        if (!ok) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[zuo].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[zuo].zptype;
            v_dbhhg_list.dbbhg_desc = "左灯光工位-照片:" + dbbhg_desc;
            v_dbhhg_list.dbresult = dbresult;
            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }
        }
    }

    if (you != -1) {
        bool ok = true;
        std::string dbbhg_desc, dbresult;

        if (JIAOZUO == g_CheckItem.City) {
            if (!ZuoDengGuangGongWei.b_car_right_light_on && !YouDengGuangGongWei.b_car_right_light_on) { // 左灯光工位和右灯光工位灯2都不亮
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += NOT_BRIGHT;
            }
        }
        else if (BINZHOU == g_CheckItem.City)
        {
            if (g_CheckItem.picture.ZuoDengGuang.ZuoQianDeng || g_CheckItem.picture.ZuoDengGuang.YouQianDeng)
            {
                if (!ZuoDengGuangGongWei.b_car_left_light_on || !YouDengGuangGongWei.b_car_right_light_on)
                {
                    dbbhg_desc += NOT_BRIGHT;
                    ok = false;
                    dbresult = FATAL_ERROR;
                    if ((p_vehicle_inf->m_b_ydg_checked) && (g_CheckItem.video.YouDengGuang.QianDaDeng))
                    {
                        if (!V_YouDengGuang.b_light_on)
                        {
                            ok = false;
                            dbresult = FATAL_ERROR;
                            dbbhg_desc += "[视频-灯光不亮]";
                        }
                        else
                        {
                            dbbhg_desc += "[视频-灯光正常]";
                        }
                    }
                }
            }
        }
        else
        {
            if (g_CheckItem.picture.YouDengGuang.ZuoQianDeng && g_CheckItem.picture.YouDengGuang.YouQianDeng) {
                if (!YouDengGuangGongWei.b_car_left_light_on || !YouDengGuangGongWei.b_car_right_light_on) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += NOT_BRIGHT;
                }
            } else if (g_CheckItem.picture.YouDengGuang.ZuoQianDeng || g_CheckItem.picture.YouDengGuang.YouQianDeng) {
                if (!YouDengGuangGongWei.b_car_left_light_on && !YouDengGuangGongWei.b_car_right_light_on) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += NOT_BRIGHT;
                }
            }
        }

        if ((p_vehicle_inf->m_b_ydg_checked) && (BINZHOU == g_CheckItem.City))
        {
            if ((!V_YouDengGuang.b_human_clear) && (g_CheckItem.video.YouDengGuang.Ren))
            {
                dbbhg_desc += "[视频-有人经过]";
                dbresult = FATAL_ERROR;
                ok = false;
            }
            else
            {
                dbbhg_desc += "[视频-无人员经过]";
            }

            if ((!V_YouDengGuang.b_tester_move) && (g_CheckItem.video.YouDengGuang.CeShiYi))
            {
                dbbhg_desc += "[视频-测试仪移动]";
                dbresult = FATAL_ERROR;
                ok = false;
            }
            else
            {
                dbbhg_desc += "[视频-测试仪正常]";
            }

            if (!V_YouDengGuang.b_time)
            {
                dbbhg_desc += "[视频-检测时间不足]";
                dbresult = FATAL_ERROR;
                ok = false;
            }
            else
            {
                dbbhg_desc += "[视频-检测时间正常]";
            }
        }
        if (g_CheckItem.picture.YouDengGuang.ShuiYinRiQi) {
            if (!bYouDengGuangShuiYinRiQi) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += OUT_OF_DATE;
            }
        }

        if (g_CheckItem.picture.YouDengGuang.ChePai) {
            if (BINZHOU == g_CheckItem.City)
            {
                if ((p_vehicle_inf->m_b_ydg_checked) && (g_CheckItem.video.YouDengGuang.ChePai))
                {
                    if (!V_YouDengGuang.b_chepai)
                    {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[视频-车牌不正确]";
                    }
                    else
                    {
                        dbbhg_desc += "[视频-车牌正确]";
                    }
                }
            }
//            if (!DengGuangGongWie.b_chepai&&!IsNewVehicle) {
//                ok = false;
//                dbresult = FATAL_ERROR;
//                dbbhg_desc += HPHM_ERROR;
//            }
            bool b_chepai = true;
            if(g_CheckItem.City == FUZHOU2)
            {
                 b_chepai =  ZuoDengGuangGongWei.b_chepai || YouDengGuangGongWei.b_chepai; //不管清晰与否，即两个车牌中有一个正确即可;
            }
            else
            {
                if(YouDengGuangGongWei.b_chepai_clear) b_chepai = b_chepai && YouDengGuangGongWei.b_chepai; // 清晰的车牌必须正确
                if(!ZuoDengGuangGongWei.b_chepai_clear && !YouDengGuangGongWei.b_chepai_clear)
                {
                    if( !(ZuoDengGuangGongWei.b_chepai || YouDengGuangGongWei.b_chepai) ) b_chepai = false; // 若都不清晰，有一个正确即可，若都不正确，则返回false
                }
            }
            if(!b_chepai && !IsNewVehicle)
            {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += HPHM_ERROR;
            }
        }

        if (g_CheckItem.City == NANJING) {
            ok = false;
            dbresult = NEED_MANUAL;
            dbbhg_desc = "无法处理的照片类型";
        }

        if (!ok) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[you].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[you].zptype;
            v_dbhhg_list.dbbhg_desc = "右灯光工位-照片:" + dbbhg_desc;
            v_dbhhg_list.dbresult = dbresult;
            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }
        }
    }
}

void ResultCollection::doAnalyse_DengGuangGongWie_YiChun(vehicle_inf *p_vehicle_inf, int zuo, int you)
{
    bool zuo_ok = true;
    std::string zuo_dbbhg_desc, zuo_dbresult;

    /*
     * 左右灯光配置项逻辑说明：
     * 1. ZuoQianDeng和YouQianDeng都打开：必须判定两个灯都亮才算通过
     * 2. ZuoQianDeng和YouQianDeng打开二者之一：判定两个灯，有一个亮就算通过
     * 3. ZuoQianDeng和YouQianDeng都关闭：不判定两个车灯
    */
    if (zuo != -1) {

        if (g_CheckItem.picture.ZuoDengGuang.ZuoQianDeng && g_CheckItem.picture.ZuoDengGuang.YouQianDeng) {
            if (!ZuoDengGuangGongWei.b_car_left_light_on || !ZuoDengGuangGongWei.b_car_right_light_on) {

                if((p_vehicle_inf->m_b_dggw_checked) && (g_CheckItem.video.ZuoDengGuang.QianDaDeng))
                {
                    if(!V_DengGuang.b_light_on)
                    {
                        zuo_ok = false;
                        zuo_dbresult = FATAL_ERROR;
                        zuo_dbbhg_desc += NOT_BRIGHT;
                        zuo_dbbhg_desc += "[视频-灯光不亮]";
                    }
                }
                else
                {
                    zuo_ok = false;
                    zuo_dbresult = FATAL_ERROR;
                    zuo_dbbhg_desc += NOT_BRIGHT;
                }
            }
        } else if (g_CheckItem.picture.ZuoDengGuang.ZuoQianDeng || g_CheckItem.picture.ZuoDengGuang.YouQianDeng) {
            if (!ZuoDengGuangGongWei.b_car_left_light_on && !ZuoDengGuangGongWei.b_car_right_light_on) {
                if((p_vehicle_inf->m_b_dggw_checked) && (g_CheckItem.video.ZuoDengGuang.QianDaDeng))
                {
                    if(!V_DengGuang.b_light_on)
                    {
                        zuo_ok = false;
                        zuo_dbresult = FATAL_ERROR;
                        zuo_dbbhg_desc += NOT_BRIGHT;
                        zuo_dbbhg_desc += "[视频-灯光不亮]";
                    }
                }
                else
                {
                    zuo_ok = false;
                    zuo_dbresult = FATAL_ERROR;
                    zuo_dbbhg_desc += NOT_BRIGHT;
                }
            }
        }


        if (g_CheckItem.picture.ZuoDengGuang.ShuiYinRiQi) {
            if (!bZuoDengGuangShuiYinRiQi) {
                zuo_ok = false;
                zuo_dbresult = FATAL_ERROR;
                zuo_dbbhg_desc += OUT_OF_DATE;
            }
        }

        if (g_CheckItem.picture.ZuoDengGuang.ChePai) {

            bool b_chepai = true;
            if(ZuoDengGuangGongWei.b_chepai_clear) b_chepai = b_chepai && ZuoDengGuangGongWei.b_chepai; // 清晰的车牌必须正确
            if(!ZuoDengGuangGongWei.b_chepai_clear && !YouDengGuangGongWei.b_chepai_clear)
            {
                if( !(ZuoDengGuangGongWei.b_chepai || YouDengGuangGongWei.b_chepai) ) b_chepai = false; //若都不清晰，有一个正确即可，若都不正确，则返回false
            }
            if(!b_chepai && !IsNewVehicle)
            {
                if(p_vehicle_inf->m_b_dggw_checked && g_CheckItem.video.ZuoDengGuang.ChePai)
                {
                    if(!V_DengGuang.b_chepai)
                    {
                        zuo_ok = false;
                        zuo_dbresult = FATAL_ERROR;
                        zuo_dbbhg_desc += HPHM_ERROR;
                        zuo_dbbhg_desc += "[视频-车牌不正确]";
                    }
                }
                else
                {
                    zuo_ok = false;
                    zuo_dbresult = FATAL_ERROR;
                    zuo_dbbhg_desc += HPHM_ERROR;
                }
            }
        }
    }


    bool you_ok = true;
    std::string you_dbbhg_desc, you_dbresult;

    if (you != -1) {

            if (g_CheckItem.picture.YouDengGuang.ZuoQianDeng && g_CheckItem.picture.YouDengGuang.YouQianDeng) {
                if (!YouDengGuangGongWei.b_car_left_light_on || !YouDengGuangGongWei.b_car_right_light_on) {

                    if(p_vehicle_inf->m_b_dggw_checked && g_CheckItem.video.YouDengGuang.QianDaDeng)
                    {
                        if(!V_DengGuang.b_light_on)
                        {
                            you_ok = false;
                            you_dbresult = FATAL_ERROR;
                            you_dbbhg_desc += NOT_BRIGHT;
                            you_dbbhg_desc += "[视频-灯光不亮]";
                        }
                    }
                    else
                    {
                        you_ok = false;
                        you_dbresult = FATAL_ERROR;
                        you_dbbhg_desc += NOT_BRIGHT;
                    }
                }
            } else if (g_CheckItem.picture.YouDengGuang.ZuoQianDeng || g_CheckItem.picture.YouDengGuang.YouQianDeng) {
                if (!YouDengGuangGongWei.b_car_left_light_on && !YouDengGuangGongWei.b_car_right_light_on) {

                    if(p_vehicle_inf->m_b_dggw_checked && g_CheckItem.video.YouDengGuang.QianDaDeng)
                    {
                        if(!V_DengGuang.b_light_on)
                        {
                            you_ok = false;
                            you_dbresult = FATAL_ERROR;
                            you_dbbhg_desc += NOT_BRIGHT;
                            you_dbbhg_desc += "[视频-灯光不亮]";
                        }
                    }
                    else
                    {
                        you_ok = false;
                        you_dbresult = FATAL_ERROR;
                        you_dbbhg_desc += NOT_BRIGHT;
                    }
                }
            }


        if (g_CheckItem.picture.YouDengGuang.ShuiYinRiQi) {
            if (!bYouDengGuangShuiYinRiQi) {
                you_ok = false;
                you_dbresult = FATAL_ERROR;
                you_dbbhg_desc += OUT_OF_DATE;
            }
        }

        if (g_CheckItem.picture.YouDengGuang.ChePai) {
            bool b_chepai = true;
            if(YouDengGuangGongWei.b_chepai_clear) b_chepai = b_chepai && YouDengGuangGongWei.b_chepai; // 清晰的车牌必须正确
            if(!ZuoDengGuangGongWei.b_chepai_clear && !YouDengGuangGongWei.b_chepai_clear)
            {
                if( !(ZuoDengGuangGongWei.b_chepai || YouDengGuangGongWei.b_chepai) ) b_chepai = false; // 若都不清晰，有一个正确即可，若都不正确，则返回false
            }
            if(!b_chepai && !IsNewVehicle)
            {
                if(p_vehicle_inf->m_b_dggw_checked && g_CheckItem.video.ZuoDengGuang.ChePai)
                {
                    if(!V_DengGuang.b_chepai)
                    {
                        you_ok = false;
                        you_dbresult = FATAL_ERROR;
                        you_dbbhg_desc += HPHM_ERROR;
                        you_dbbhg_desc += "[视频-车牌不正确]";
                    }
                }
                else
                {
                    you_ok = false;
                    you_dbresult = FATAL_ERROR;
                    you_dbbhg_desc += HPHM_ERROR;
                }
            }
        }
    }

    /*宜春左右灯光其中有一项灯光通过即可*/
    if(zuo !=-1 && you != -1)
    {
        if(!you_ok && !zuo_ok)
        {

            if (!you_ok) {
                _dbbhg_list v_dbhhg_list;
                v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[you].zpid;
                v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[you].zptype;
                v_dbhhg_list.dbbhg_desc = "右灯光工位-照片:" + you_dbbhg_desc;
                v_dbhhg_list.dbresult = you_dbresult;
                p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
                if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                    dbbhgs++;
                }
            }

            if (!zuo_ok) {
               _dbbhg_list v_dbhhg_list;
               v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[zuo].zpid;
               v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[zuo].zptype;
               v_dbhhg_list.dbbhg_desc = "左灯光工位-照片:" + zuo_dbbhg_desc;
               v_dbhhg_list.dbresult = zuo_dbresult;
               p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
               if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
                }
            }
       }
    }

    if(you != -1 && zuo == -1)
    {

        if (!you_ok) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[you].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[you].zptype;
            v_dbhhg_list.dbbhg_desc = "右灯光工位-照片:" + you_dbbhg_desc;
            v_dbhhg_list.dbresult = you_dbresult;
            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }
        }
    }

    if(you == -1 && zuo != -1)
    {
        if (!zuo_ok) {
           _dbbhg_list v_dbhhg_list;
           v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[zuo].zpid;
           v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[zuo].zptype;
           v_dbhhg_list.dbbhg_desc = "左灯光工位-照片:" + zuo_dbbhg_desc;
           v_dbhhg_list.dbresult = zuo_dbresult;
           p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
           if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
            }
        }
    }

}

void ResultCollection::doAnalyse_glass_transmittance(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    bool b_is_glass_transmittance = true;
    std::string dbbhg_desc, dbresult;

    if (!BoLiTouGuangLv.b_bolitouguanglv) {
        ok = false;
        b_is_glass_transmittance = false;
        dbresult = FATAL_ERROR;
        dbbhg_desc += "[不是玻璃透光率表]";
    }

    if (!BoLiTouGuangLv.b_chepai && !IsNewVehicle && b_is_glass_transmittance && (g_CheckItem.City != XIAN)) {
        ok = false;
        dbresult = FATAL_ERROR;
        dbbhg_desc += HPHM_ERROR;
    }

    if (!BoLiTouGuangLv.b_jianchezhan_yinzhang && b_is_glass_transmittance) {
        ok = false;
        dbresult = FATAL_ERROR;
        dbbhg_desc += "[未找到检测站印章]";
    }

//    if (!BoLiTouGuangLv.b_jianyanyuan_yinzhang && b_is_glass_transmittance) {
//        ok = false;
//        dbresult = FATAL_ERROR;
//        dbbhg_desc += "[未找到检验员印章]";
//    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "玻璃透光率表-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;

        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}

void ResultCollection::doAnalyse_DaCheLunTaiHuaWen(vehicle_inf *p_vehicle_inf, int i, std::string type)
{
    _dbbhg_list v_dbhhg_list;

    if (!DaCheYiLun.b_luntai_huawen) {
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        if((type.compare("04") == 0) || (type.compare("05") == 0)) {
            v_dbhhg_list.dbbhg_desc = "大车一轴轮胎花纹不一致";
        } else if((type.compare("06") == 0) || (type.compare("07") == 0)) {
            v_dbhhg_list.dbbhg_desc = "大车二轴轮胎花纹不一致";
        } else if((type.compare("08") == 0) || (type.compare("09") == 0)) {
            v_dbhhg_list.dbbhg_desc = "大车三轴轮胎花纹不一致";
        }
        v_dbhhg_list.dbresult = FATAL_ERROR;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        dbbhgs++;
    } else {
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        if((type.compare("04") == 0) || (type.compare("05") == 0)) {
            v_dbhhg_list.dbbhg_desc = "大车一轴轮胎花纹一致";
        } else if((type.compare("06") == 0) || (type.compare("07") == 0)) {
            v_dbhhg_list.dbbhg_desc = "大车二轴轮胎花纹一致";
        } else if((type.compare("08") == 0) || (type.compare("09") == 0)) {
            v_dbhhg_list.dbbhg_desc = "大车三轴轮胎花纹一致";
        }
        v_dbhhg_list.dbresult = RESULT_OK;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        dbbhgs++;
    }
}

// 玻璃透光率仪器照片 0168 座位照片 0169 驻车制动路试检验原始记录单  0214 身份证正面 0260 西安直接判定合格
void ResultCollection::doAnalyse_xi_an_photo(vehicle_inf *p_vehicle_inf, int i, std::string type)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if (type.compare("0168")==0) {
    } else if (type.compare("0169")==0) {
    } else if (type.compare("0214")==0) {
    } else if (type.compare("0260")==0) {
    }
}

void ResultCollection::doAnalyse_ChaYanJiLu(vehicle_inf *p_vehicle_inf, int i ,bool ninbo)
{
    BOOL ok = TRUE;
    std::string dbbhg_desc;

    if (g_CheckItem.City == NANNING) {
        // ++{{ xeast 2018-06-15 for nanning
        std::vector<int>::iterator it;
        int num = 0;

        for (it = ChaYanJiLu.v_panding.begin(); it != ChaYanJiLu.v_panding.end(); it++, num++)
        {
            std::string str_num = std::to_string(num + 1);

            if (p_vehicle_inf->m_hpzl.compare("01") == 0) { // 大型车检测项
                if ((num >= 0) && (num <= 9)) {           // 0 为图中的圈圈 1 是横线
                    if ((*it != 0) && (*it != 1)) {
                        ok = FALSE;
                        dbbhg_desc += "[第" + str_num + "项不合格]";
                    }
                } else if ((num == 11) || (num == 32) || (num == 41)) {
                    if ((*it != 0) && (*it != 1)) {
                        ok = FALSE;
                        dbbhg_desc += "[第" + str_num + "项不合格]";
                    }
                } else if ((num >= 15) && (num <= 22)) {
                    if ((*it != 0) && (*it != 1)) {
                        ok = FALSE;
                        dbbhg_desc += "[第" + str_num + "项不合格]";
                    }
                }
            }

            if (p_vehicle_inf->m_hpzl.compare("02") == 0) { // 小型车检测项
                if ((num >= 0) && (num <= 4)) {           // 0 为图中的圈圈 1 是横线
                    if ((*it != 0) && (*it != 1)) {
                        ok = FALSE;
                        dbbhg_desc += "[第" + str_num + "项不合格]";
                    }
                } else if ((num == 8) || (num == 32) || (num == 41)) {
                    if ((*it != 0) && (*it != 1)) {
                        ok = FALSE;
                        dbbhg_desc += "[第" + str_num + "项不合格]";
                    }
                } else if ((num >= 15) && (num <= 22)) {
                    if ((*it != 0) && (*it != 1)) {
                        ok = FALSE;
                        dbbhg_desc += "[第" + str_num + "项不合格]";
                    }
                }
            }

            if (isTenYears(p_vehicle_inf)) {  // 10年以上车型检测项
                if ((num>=42) && (*it != 0) && (*it != 1)) {
                    ok = FALSE;
                    dbbhg_desc += "[第" + str_num + "项不合格]";
                }
            }
        }

        if (!ChaYanJiLu.b_qianzi) {
            ok = FALSE;
            dbbhg_desc += "[检验员未签字]";
        }
        if (!ChaYanJiLu.b_jielun) {
            ok = FALSE;
            dbbhg_desc += "[检验员建议未填写]";
        }
    }
    else if(g_CheckItem.City == NINGBO) {

        if (g_CheckItem.picture.ChaYanJiLu.JianYanBiao) {
            if (!ChaYanJiLu.b_jianyanbiao) {
                ok = FALSE;
                dbbhg_desc += "[检验表不符合标准]";
            }
        }

        if (g_CheckItem.picture.ChaYanJiLu.ChaYanXinXi) {
            bool b_chayanxinxi=true;

            //根据车辆性质和年限判别查验信息是否通过
            for(i=0;i<9;i++)
            {
                if(ChaYanJiLu.v_panding[i]==0)
                {
                    b_chayanxinxi=false;
                    break;
                }
            }
            if(ChaYanJiLu.v_panding[19]==0)
            {
                b_chayanxinxi=false;
            }
            //小车
            if(p_vehicle_inf->m_cllx.find("K")!= string::npos)
            {
                for(i=9;i<19;i++)
                {
                    if(ChaYanJiLu.v_panding[i]==1)
                    {
                        b_chayanxinxi=false;
                        break;
                    }
                }
            }
            //**************************

            if (!b_chayanxinxi) {
                ok = FALSE;
                dbbhg_desc += "[查验信息不正确]";
            }
        }

        if(!ninbo)
        {
            if (g_CheckItem.picture.ChaYanJiLu.WaiGuanQianZi) {
                if (!ChaYanJiLu.b_waiguan_sign) {
                    ok = FALSE;
                    dbbhg_desc += "[外观检验员未签字]";
                }
            }



             if (isTenYears(p_vehicle_inf)) {	/* 10年以上车型 */

                 if (g_CheckItem.picture.ChaYanJiLu.YinCheQianZi) {
                     if (!ChaYanJiLu.b_yinche_sign) {
                             ok = FALSE;
                             dbbhg_desc += "[引车检验员未签字]";
                     }
                 }
                 if (g_CheckItem.picture.ChaYanJiLu.DiPanQianZi) {
                     if (!ChaYanJiLu.b_dipan_sign) {
                             ok = FALSE;
                             dbbhg_desc += "[底盘检验员未签字]";
                     }
                 }
             }
         }
        if (g_CheckItem.picture.ChaYanJiLu.ChePai) {
            if (!ChaYanJiLu.b_chepai&&!IsNewVehicle) {
                ok = FALSE;
                dbbhg_desc += HPHM_ERROR;
            }
        }
    }
    else if(g_CheckItem.City == SHENZHEN)
    {
        if (g_CheckItem.picture.ChaYanJiLu.ChaYanXinXi) {
            bool b_chayanxinxi=true;

            //根据车辆性质和年限判别查验信息是否通过
            for(i=0;i<9;i++)
            {
                if(ChaYanJiLu.v_panding[i]==0)
                {
                    b_chayanxinxi=false;
                    break;
                }
            }
            if(ChaYanJiLu.v_panding[19]==0)
            {
                b_chayanxinxi=false;
            }
            //小车
            if(p_vehicle_inf->m_cllx.find("K")!= string::npos)
            {
                for(i=9;i<19;i++)
                {
                    if(ChaYanJiLu.v_panding[i]==1)
                    {
                        b_chayanxinxi=false;
                        break;
                    }
                }
            }
            //**************************

            if (!b_chayanxinxi) {
                ok = FALSE;
                dbbhg_desc += "[查验信息不正确]";
            }
        }

        if (g_CheckItem.picture.ChaYanJiLu.WaiGuanQianZi) {
            if (!ChaYanJiLu.b_qianzi) {
                    ok = FALSE;
                    dbbhg_desc += "[检验员未签字]";
            }
        }

        if (g_CheckItem.picture.ChaYanJiLu.HongZhang) {
            if (!ChaYanJiLu.b_hongzhang) {
                    ok = FALSE;
                    dbbhg_desc += "[没有红章]";
            }
        }
    }
    else {

        if (g_CheckItem.picture.ChaYanJiLu.JianYanBiao) {
            if (!ChaYanJiLu.b_jianyanbiao) {
                ok = FALSE;
                dbbhg_desc += "[检验表不符合标准]";
            }
        }

        if (g_CheckItem.picture.ChaYanJiLu.ChaYanXinXi) {
            bool b_chayanxinxi=true;

            //根据车辆性质和年限判别查验信息是否通过
            for(i=0;i<9;i++)
            {
                if(ChaYanJiLu.v_panding[i]==0)
                {
                    b_chayanxinxi=false;
                    break;
                }
            }
            if(ChaYanJiLu.v_panding[19]==0)
            {
                b_chayanxinxi=false;
            }
            //小车
            if(p_vehicle_inf->m_cllx.find("K")!= string::npos)
            {
                for(i=9;i<19;i++)
                {
                    if(ChaYanJiLu.v_panding[i]==1)
                    {
                        b_chayanxinxi=false;
                        break;
                    }
                }
            }
            //**************************

            if (!b_chayanxinxi) {
                ok = FALSE;
                dbbhg_desc += "[查验信息不正确]";
            }
        }

        if (g_CheckItem.picture.ChaYanJiLu.ChePai) {
            if (!ChaYanJiLu.b_chepai&&!IsNewVehicle) {
                ok = FALSE;
                dbbhg_desc += HPHM_ERROR;
            }
        }

//        if (g_CheckItem.picture.ChaYanJiLu.CheJiaHao) {
//            if (!ChaYanJiLu.b_chejiahao) {
//                ok = FALSE;
//                dbbhg_desc += CHE_JIA_HAO_ERROR;
//            }
//        }

        if (g_CheckItem.picture.ChaYanJiLu.WaiGuanQianZi) {
            // +{{ xeast 2018-06-09
            if (g_CheckItem.City == CHONGQING) {
                if (!ChaYanJiLu.b_waiguan_sign) {
                    ok = FALSE;
                    dbbhg_desc += "[外观检验员未签字]";
                }
            }
            // }}
            else if (!ChaYanJiLu.b_waiguan_sign) {
                ok = FALSE;
                dbbhg_desc += "[外观检验员未签字]";
            }
        }

        if (g_CheckItem.picture.ChaYanJiLu.ChaYanJieLun) {
            if (!ChaYanJiLu.b_jielun) {
                ok = FALSE;
                dbbhg_desc += "[没有查验结论]";
            }
        }

        if (g_CheckItem.picture.ChaYanJiLu.ChaYanQianZi) {
            if (!ChaYanJiLu.b_qianzi) {
                ok = FALSE;
                dbbhg_desc += "[查验员未签字]";
            }
        }

        if (g_CheckItem.picture.ChaYanJiLu.YinCheQianZi) {
            if (isTenYears(p_vehicle_inf)) {	/* 10年以上车型需要“引车检验员”签字 */
                if (g_CheckItem.City == CHONGQING ) {
                    if (!ChaYanJiLu.b_yinche_sign) {
                        ok = FALSE;
                        dbbhg_desc += "[底盘动态(引车员)检验员未签字]";
                    }
                }
                else if (!ChaYanJiLu.b_yinche_sign) {
                    ok = FALSE;
                    dbbhg_desc += "[引车检验员未签字]";
                }
            }
        }

        if (g_CheckItem.picture.ChaYanJiLu.DiPanQianZi) {
            if (isTenYears(p_vehicle_inf)) {	/* 10年以上车型需要“底盘检验员”签字 */
                // +{{ xeast 2018-06-09
                if (g_CheckItem.City == CHONGQING) {
                    if (!ChaYanJiLu.b_dipan_sign) {
                        ok = FALSE;
                        dbbhg_desc += "[底盘部件检验员未签字]";
                    }
                }
                // }}
                else if (!ChaYanJiLu.b_dipan_sign) {
                    ok = FALSE;
                    dbbhg_desc += "[底盘检验员未签字]";
                }
            }
        }

    }   // end else

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "机动车查验记录表-照片:" + dbbhg_desc;
        v_dbhhg_list.dbresult = FATAL_ERROR;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        dbbhgs++;
    }
}

void ResultCollection::doAnalyse_WuRanWu(vehicle_inf *p_vehicle_inf, int i,int j)
{
    if (g_CheckItem.City == SUZHOU) {
        doAnalyse_WuRanWu_SuZhou(p_vehicle_inf, i, j);
        return;
    } else if (g_CheckItem.City == QINGHAI) {
        doAnalyse_WuRanWu_QingHai(p_vehicle_inf, i, j);
        return;
    }

    if (g_CheckItem.City == SHENZHEN) {
        if (p_vehicle_inf->m_rlzl == "C" || p_vehicle_inf->m_rlzl == "O") {
            return;
        }

        if (p_vehicle_inf->m_hpzl == "52") {    /* 小型新能源汽车 */
            return;
        }
    }

    //FixMe,襄阳尾气单全判定为通过，等新格式适配后，再改回来
    if (g_CheckItem.City == XIANGYANG) {
        return;
    }

    if (g_CheckItem.City == XIANNING)
    {
        doAnalyse_WuRanWu_XianNing(p_vehicle_inf, i, j);
        return;
    }

    if (BINZHOU == g_CheckItem.City)
    {
        doAnalyse_WuRanWu_BinZhou(p_vehicle_inf, i, j);
        return;
    }

    bool ok = true;
    std::string dbbhg_desc, dbresult;
    if(i==-1)
    {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[j].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[j].zptype;
        v_dbhhg_list.dbbhg_desc = "尾气检测报告2-照片::";
        v_dbhhg_list.dbbhg_desc += "[缺少尾气检测报告照片]";
        v_dbhhg_list.dbresult = NEED_MANUAL;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        return;
    }
    if(j==-1)
    {

        if (g_CheckItem.picture.WeiQiJianYan.JieLun) {
            if (!WuRanWu.b_jiancejielun) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[检查结论不通过]";
            }
        }

        if (g_CheckItem.picture.WeiQiJianYan.ChePai) {
            if (!WuRanWu.b_chepai&&!IsNewVehicle) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += HPHM_ERROR;
            }
        }

        if (g_CheckItem.picture.WeiQiJianYan.CheJiaHao) {
            if (!WuRanWu.b_chejiahao) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += CHE_JIA_HAO_ERROR;
            }
        }

        if (g_CheckItem.picture.WeiQiJianYan.YinZhang) {
            if (!WuRanWu.b_yinzhang) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += NO_STAMP;
            }
        }

        if (g_CheckItem.picture.WeiQiJianYan.QianMing) {
            if (!WuRanWu.b_qianzi) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += NO_SIGNATURE;
            }
        }

        if (g_CheckItem.picture.WeiQiJianYan.YinZhang_MA) {
            if (!WuRanWu.b_MA) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[没有“CMA”印章]";
            }
        }

        if (g_CheckItem.picture.WeiQiJianYan.YouXiaoQi) {
            if (!WuRanWu.b_valid_date) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[检测日期不在有效期内]";
            }
        }

        if (g_CheckItem.picture.WeiQiJianYan.FaDongJiBianHao) {
            if (!WuRanWu.b_engine_num) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[发动机编号不合格]";
            }
        }

        if(g_CheckItem.City==SUZHOU)
        {
            if(g_CheckItem.picture.WeiQiJianYan.DianZiBaoGao)
            {
                if(p_vehicle_inf->is_dz_wq)
                {
                    if(!p_vehicle_inf->dz_wq_pass)
                    {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[电子报告不通过]";
                    }
                }
                else
                {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[未查询到电子尾气检测报告]";
                }
            }

            if (g_CheckItem.picture.WeiQiJianYan.JianCeShiJian) {
                if (!WuRanWu.b_riqi_shijian) {
    //                ok = false;
    //                dbresult = FATAL_ERROR;
    //                dbbhg_desc += "[检测时间不符合]";
                    DATA_PRINT(LEVEL_INFO, "[检测时间不符合]\n");
                }
            }

        }
        if(g_CheckItem.City==HULUNBEIER)
        {
            if(g_CheckItem.picture.WeiQiJianYan.CaoZuoYuan)
            {
                if (!WuRanWu.b_qianzi_caozuoyuan) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[没有操作员签名]";
                }
            }
            if(g_CheckItem.picture.WeiQiJianYan.JiaShiYuan)
            {
                if (!WuRanWu.b_qianzi_jiashiyuan) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[没有驾驶员签名]";
                }
            }
            if(g_CheckItem.picture.WeiQiJianYan.PiZhunRen)
            {
                if (!WuRanWu.b_qianzi_pizhunren) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[没有批准人签字]";
                }
            }
            if(g_CheckItem.picture.WeiQiJianYan.ShenHeYuan)
            {
                if (!WuRanWu.b_qianzi_shenheyuan) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[没有审核员签字]";
                }
            }
        }

        if (g_CheckItem.picture.WeiQiJianYan.DianZiBiaoGe) {
            if (!WuRanWu.b_dianzibiaoge) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[不是电子表格]";
            }
        }



        if (!WuRanWu.b_huanbaodan) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc = "[照片不是尾气检测报告]";    /* 覆盖前面的原因 */
        }




        if (!ok) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
            v_dbhhg_list.dbbhg_desc = "尾气检测报告-照片:";
            v_dbhhg_list.dbbhg_desc += dbbhg_desc;
            v_dbhhg_list.dbresult = dbresult;
            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }

        }
    }
    else
    {
        if ((g_CheckItem.picture.WeiQiJianYan.ChePai)||(g_CheckItem.picture.WeiQiJianYan2.ChePai))
        {
            if((!WuRanWu.b_chepai)&&(!WuRanWu2.b_chepai))
            {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += HPHM_ERROR;
            }
        }

        if ((g_CheckItem.picture.WeiQiJianYan.CheJiaHao)||(g_CheckItem.picture.WeiQiJianYan2.CheJiaHao))
        {
            if ((!WuRanWu.b_chejiahao)&&(!WuRanWu2.b_chejiahao)) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += CHE_JIA_HAO_ERROR;
            }
        }

        if ((g_CheckItem.picture.WeiQiJianYan.JieLun)||(g_CheckItem.picture.WeiQiJianYan2.JieLun))
        {
            if(g_CheckItem.City == ANSHUN)
            {
                if ((!WuRanWu.b_jiancejielun_paiqiwuran)&&(!WuRanWu2.b_jiancejielun_paiqiwuran)) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[检查结论不通过]";
                }
            }
            else
            {
                if ((!WuRanWu.b_jiancejielun)&&(!WuRanWu2.b_jiancejielun)) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[检查结论不通过]";
                }
            }
        }

        if ((g_CheckItem.picture.WeiQiJianYan.QianMing)||(g_CheckItem.picture.WeiQiJianYan2.QianMing))
        {
            if ((!WuRanWu.b_qianzi)&&(!WuRanWu2.b_qianzi)) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += NO_SIGNATURE;
            }
        }

        if ((g_CheckItem.picture.WeiQiJianYan.YinZhang)||(g_CheckItem.picture.WeiQiJianYan2.YinZhang))
        {
            if ((!WuRanWu.b_yinzhang)&&(!WuRanWu2.b_yinzhang)) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[没有印章]";
            }
        }

        if ((g_CheckItem.picture.WeiQiJianYan.YinZhang_MA)||(g_CheckItem.picture.WeiQiJianYan2.YinZhang_MA))
        {
            if ((!WuRanWu.b_MA)&&(!WuRanWu2.b_MA)) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[没有“CMA”印章]";
            }
        }

        if(g_CheckItem.City == LAIBIN)
        {
            if ((!WuRanWu.b_engine_num)&&(!WuRanWu2.b_engine_num)) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[发动机型号不匹配]";
            }
            if ((!WuRanWu.b_cheliangxinghao)&&(!WuRanWu2.b_cheliangxinghao)) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[车辆型号不匹配]";
            }
        }

        if(g_CheckItem.City == TIANJIN)
        {
            if(!WuRanWu.b_bianhao_is_same && !WuRanWu2.b_bianhao_is_same){
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[两张环保单报告编号不匹对]";
            }
        }

        if(g_CheckItem.picture.WeiQiJianYan.FaDongJiBianHao || g_CheckItem.picture.WeiQiJianYan2.FaDongJiBianHao)
        {
            if(g_CheckItem.City == TAIYUAN)
            {
                if ((!WuRanWu.b_engine_num)&&(!WuRanWu2.b_engine_num)) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[发动机型号不匹配]";
                }
            }
            if(g_CheckItem.City == ZHANGJIAJIE)
            {
                if ((!WuRanWu.b_engine_num)&&(!WuRanWu2.b_engine_num)) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[发动机型号不匹配]";
                }
                if ((!WuRanWu.b_cheliangxinghao)&&(!WuRanWu2.b_cheliangxinghao)) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[车辆型号不匹配]";
                }
            }
        }


        if (!ok) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
            v_dbhhg_list.dbbhg_desc = "尾气检测报告-照片:";
            v_dbhhg_list.dbbhg_desc += dbbhg_desc;
            v_dbhhg_list.dbresult = dbresult;
            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }

        }
        if (!ok) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[j].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[j].zptype;
            v_dbhhg_list.dbbhg_desc = "尾气检测报告2-照片:";
            v_dbhhg_list.dbbhg_desc += dbbhg_desc;
            v_dbhhg_list.dbresult = dbresult;
            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }

        }
    }
}

void ResultCollection::doAnalyse_WuRanWu_BinZhou(vehicle_inf *p_vehicle_inf, int index1, int index2)
{
    if (index1 == -1 && index2 == -1) {
        return;
    }

    if (-1 != index1)
    {
        bool ok = true;
        std::string dbbhg_desc, dbresult;
        if (!WuRanWu.b_chepai)
        {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += HPHM_ERROR;
        }
        if (!WuRanWu.b_chejiahao)
        {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += CHE_JIA_HAO_ERROR;
        }
        if (!WuRanWu.b_MA)
        {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[没有MA印章]";
        }
        if (!ok)
        {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[index1].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[index1].zptype;
            v_dbhhg_list.dbbhg_desc = "尾气检测报告-照片:";
            v_dbhhg_list.dbbhg_desc += dbbhg_desc;
            v_dbhhg_list.dbresult = dbresult;
            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }
        }
    }
    if (-1 != index2)
    {
        bool ok = true;
        std::string dbbhg_desc, dbresult;
        if (!WuRanWu2.b_jiancejielun)
        {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[没有检测结论]";
        }
        if (!WuRanWu2.b_yinzhang)
        {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[没有印章]";
        }
        if (!WuRanWu2.b_qianzi)
        {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[没有签名]";
        }
        if (!ok)
        {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[index2].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[index2].zptype;
            v_dbhhg_list.dbbhg_desc = "尾气检测报告2-照片:";
            v_dbhhg_list.dbbhg_desc += dbbhg_desc;
            v_dbhhg_list.dbresult = dbresult;
            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }
        }
    }
}

void ResultCollection::doAnalyse_WuRanWu_SuZhou(vehicle_inf *p_vehicle_inf, int WeiQi_1, int WeiQi_2)
{
    if (p_vehicle_inf->m_rlzl == "C") {
        return;
    }

    if (WeiQi_1 == -1 && WeiQi_2 == -1) {
        return;
    }

    std::string dbbhg_desc, dbresult;

    if (WeiQi_1 != -1) {
        if (!WuRanWu.b_chepai) {
            dbresult = FATAL_ERROR;
            dbbhg_desc += HPHM_ERROR;
        }

        if (!WuRanWu.b_chejiahao && !WuRanWu2.b_chejiahao) {
            dbresult = FATAL_ERROR;
            dbbhg_desc += CHE_JIA_HAO_ERROR;
        }

        //        if (!WuRanWu_2.b_jiancejielun) {
        //            dbresult = FATAL_ERROR;
        //            dbbhg_desc += "[外观检验结果不合格]";
        //        }

        //        if (!WuRanWu_2.b_qianzi) {
        //            dbresult = FATAL_ERROR;
        //            dbbhg_desc += "[没有检验员签字]";
        //        }

        if (!WuRanWu.b_huanbaodan) {
            dbresult = FATAL_ERROR;
            dbbhg_desc = "[照片不是尾气报告]";
        }

        if (!dbresult.empty()) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[WeiQi_1].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[WeiQi_1].zptype;
            v_dbhhg_list.dbbhg_desc = "尾气报告-照片:" + dbbhg_desc;
            v_dbhhg_list.dbresult = dbresult;

            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            dbbhgs++;
        }
    }

    dbbhg_desc.clear(), dbresult.clear();

    if (WeiQi_2 != -1) {
        if (!WuRanWu2.b_chepai) {
            dbresult = FATAL_ERROR;
            dbbhg_desc += HPHM_ERROR;
        }

        if (!WuRanWu.b_jiancejielun && !WuRanWu2.b_jiancejielun) {
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[检测结果不合格]";
        }

        if (!WuRanWu.b_qianzi_shouquan && !WuRanWu2.b_qianzi_shouquan) {
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[授权签字人没有签字]";
        }

        if (!WuRanWu.b_yinzhang && !WuRanWu2.b_yinzhang) {
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[没有检测站印章]";
        }

        if (!WuRanWu2.b_huanbaodan) {
            dbresult = FATAL_ERROR;
            dbbhg_desc = "[照片不是尾气报告]";
        }

        if (!dbresult.empty()) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[WeiQi_2].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[WeiQi_2].zptype;
            v_dbhhg_list.dbbhg_desc = "尾气报告-照片:" + dbbhg_desc;
            v_dbhhg_list.dbresult = dbresult;

            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            dbbhgs++;
        }
    }
}

void ResultCollection::doAnalyse_WuRanWu_QingHai(vehicle_inf *p_vehicle_inf, int WeiQi_1, int WeiQi_2)
{
    if (WeiQi_1 == -1 && WeiQi_2 == -1) {
        return;
    }

    std::string dbbhg_desc, dbresult;

    if (WeiQi_1 != -1) {
        if (!WuRanWu.b_MA) {
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[没有“CMA”印章]";
        }

        if (!WuRanWu.b_chepai) {
            dbresult = FATAL_ERROR;
            dbbhg_desc += HPHM_ERROR;
        }

        if (!WuRanWu.b_chejiahao && !WuRanWu2.b_chejiahao) {
            dbresult = FATAL_ERROR;
            dbbhg_desc += CHE_JIA_HAO_ERROR;
        }

        if (!WuRanWu.b_huanbaodan) {
            dbresult = FATAL_ERROR;
            dbbhg_desc = "[照片不是尾气报告]";
        }

        if (!dbresult.empty()) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[WeiQi_1].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[WeiQi_1].zptype;
            v_dbhhg_list.dbbhg_desc = "尾气报告-照片:" + dbbhg_desc;
            v_dbhhg_list.dbresult = dbresult;

            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            dbbhgs++;
        }
    }

    dbbhg_desc.clear(), dbresult.clear();

    if (WeiQi_2 != -1) {
        if (!WuRanWu2.b_MA) {
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[没有“CMA”印章]";
        }

        if (!WuRanWu.b_yinzhang && !WuRanWu2.b_yinzhang) {
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[没有检测站印章]";
        }

        if (!WuRanWu.b_qianzi_shouquan && !WuRanWu2.b_qianzi_shouquan) {
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[授权签字人没有签字]";
        }

        if (!WuRanWu.b_jiancejielun_paiqiwuran && !WuRanWu2.b_jiancejielun_paiqiwuran) {
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[排气污染物检测结果不合格]";
        }

        if (!WuRanWu2.b_chepai) {
            dbresult = FATAL_ERROR;
            dbbhg_desc += HPHM_ERROR;
        }

        if (!WuRanWu2.b_huanbaodan) {
            dbresult = FATAL_ERROR;
            dbbhg_desc = "[照片不是尾气报告]";
        }

        if (!dbresult.empty()) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[WeiQi_2].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[WeiQi_2].zptype;
            v_dbhhg_list.dbbhg_desc = "尾气报告-照片:" + dbbhg_desc;
            v_dbhhg_list.dbresult = dbresult;

            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            dbbhgs++;
        }
    }
}

void ResultCollection::doAnalyse_WuRanWu_XianNing(vehicle_inf *p_vehicle_inf, int index1, int index2)
{
    if (index1 == -1 && index2 == -1) {
        return;
    }

    bool b_jielun1 = true, b_chepai1 = true, b_yinzhang1 = true, b_qianzi1 = true;
    if (index1 != -1)
    {
        if (!WuRanWu.b_jiancejielun)
            b_jielun1 = false;
        if (!WuRanWu.b_chepai)
            b_chepai1 = false;
        if (!WuRanWu.b_yinzhang)
            b_yinzhang1 = false;
        if (!WuRanWu.b_qianzi)
            b_qianzi1 = false;
    }

    bool b_jielun2 = true, b_chepai2 = true, b_yinzhang2 = true, b_qianzi2 = true;
    if (index2 != -1)
    {
        if (!WuRanWu2.b_jiancejielun)
            b_jielun2 = false;
        if (!WuRanWu2.b_chepai)
            b_chepai2 = false;
        if (!WuRanWu2.b_yinzhang)
            b_yinzhang2 = false;
        if (!WuRanWu2.b_qianzi)
            b_qianzi2 = false;
    }

    std::string dbbhg_desc, dbresult;
    if (!b_jielun1 && !b_jielun2)
    {
        dbresult = FATAL_ERROR;
        dbbhg_desc += "[检测结论未通过]";
        p_vehicle_inf->b_xianning_wrw_pass = false;
    }
    if (!b_chepai1 && !b_chepai2)
    {
        dbresult = FATAL_ERROR;
        dbbhg_desc += HPHM_ERROR;
        p_vehicle_inf->b_xianning_wrw_pass = false;
    }
    if (!b_yinzhang1 && !b_yinzhang2)
    {
        dbresult = FATAL_ERROR;
        dbbhg_desc += "[未检测到印章]";
        p_vehicle_inf->b_xianning_wrw_pass = false;
    }
    if (!b_qianzi1 && !b_qianzi2)
    {
        dbresult = FATAL_ERROR;
        dbbhg_desc += "[未检测到签字]";
        p_vehicle_inf->b_xianning_wrw_pass = false;
    }

    if (!dbresult.empty())
    {
        if (index1 != -1)
        {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[index1].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[index1].zptype;
            v_dbhhg_list.dbbhg_desc = "尾气报告1-照片:" + dbbhg_desc;
            v_dbhhg_list.dbresult = dbresult;
            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            dbbhgs++;
        }
        if (index2 != -1)
        {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[index2].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[index2].zptype;
            v_dbhhg_list.dbbhg_desc = "尾气报告2-照片:" + dbbhg_desc;
            v_dbhhg_list.dbresult = dbresult;
            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            dbbhgs++;
        }
    }
}

void ResultCollection::doAnalyse_ZhiDongGongWei(vehicle_inf *p_vehicle_inf, int YiZhou, int ErZhou)
{
    bool b_plate = false;
    bool JiuJiang_temp = false;//九江一二轴刹车灯判定条件：任意一个刹车灯通过都算合格
    if(g_CheckItem.City == QINGHAI)
    {
        if(YiZhou == -1)
        {
            return;
        }
        if(ErZhou == -1)
        {
            /* 平板制动 */
            {
                bool ok = true;
                std::string dbbhg_desc, dbresult;

                if (g_CheckItem.picture.YiZhouZhiDong.QianLun) {
                    if (!YiZhouZhiDongGongWei.b_zhidong) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[车轮位置不对]";
                    }
                }

                if (g_CheckItem.picture.YiZhouZhiDong.ChePai) {
                    if (!YiZhouZhiDongGongWei.b_chepai&&!IsNewVehicle) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += HPHM_ERROR;
                    }
                }

                if (!ok) {
                    _dbbhg_list v_dbhhg_list;
                    v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[YiZhou].zpid;
                    v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[YiZhou].zptype;
                    v_dbhhg_list.dbresult = dbresult;
                    v_dbhhg_list.dbbhg_desc = "平板制动工位-照片:";

                    p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
                    if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                        dbbhgs++;
                    }
                }
            }
        }
        else
        {
            /* 一轴制动 */
            {
                bool ok = true;
                std::string dbbhg_desc, dbresult;

                if (g_CheckItem.picture.YiZhouZhiDong.QianLun) {
                    if (!YiZhouZhiDongGongWei.b_zhidong) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[车轮位置不对]";
                    }
                }

                if (g_CheckItem.picture.YiZhouZhiDong.ChePai) {
                    if (!YiZhouZhiDongGongWei.b_chepai&&!IsNewVehicle) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += HPHM_ERROR;
                    }
                }

                if (!ok) {
                    _dbbhg_list v_dbhhg_list;
                    v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[YiZhou].zpid;
                    v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[YiZhou].zptype;
                    v_dbhhg_list.dbresult = dbresult;
                    v_dbhhg_list.dbbhg_desc = "一轴制动工位-照片:";
                    v_dbhhg_list.dbbhg_desc += dbbhg_desc;

                    p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
                    if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                        dbbhgs++;
                    }
                }
            }

            /* 二轴制动 */
            {
                bool ok = true;
                std::string dbbhg_desc, dbresult;

                if (g_CheckItem.picture.ErZhouZhiDong.HouLun) {
                    if (!ErZhouZhiDongGongWei.b_zhidong) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[车轮位置不对]";
                    }
                }

                if (g_CheckItem.picture.ErZhouZhiDong.ChePai) {
                    if (!ErZhouZhiDongGongWei.b_chepai&&!IsNewVehicle) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += HPHM_ERROR;
                    }
                }

                if (!ok) {
                    _dbbhg_list v_dbhhg_list;
                    v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[ErZhou].zpid;
                    v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[ErZhou].zptype;
                    v_dbhhg_list.dbresult = dbresult;
                    v_dbhhg_list.dbbhg_desc = "二轴制动工位-照片:";
                    v_dbhhg_list.dbbhg_desc += dbbhg_desc;


                    p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
                    if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                        dbbhgs++;
                    }
                }
            }
        }
    } else if (g_CheckItem.City == SHANGHAI) {
        if (YiZhou == -1) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = "shanghai";
            v_dbhhg_list.zptype = ZhaoPianZL.YiZhouZhiDong;
            v_dbhhg_list.dbbhg_desc = "轴制动工位-照片:";
            v_dbhhg_list.dbbhg_desc += "[缺少轴制动工位照片]";
            v_dbhhg_list.dbresult = NEED_MANUAL;
            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            return;
        }

        /* 轴制动工位 */
        bool ok = true;
        std::string dbbhg_desc, dbresult;

        if (g_CheckItem.picture.YiZhouZhiDong.QianLun) {
            if (!YiZhouZhiDongGongWei.b_zhidong) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[前轮位置不对]";
            }
        }

        if (g_CheckItem.picture.YiZhouZhiDong.ChePai) {
            if (!YiZhouZhiDongGongWei.b_chepai&&!IsNewVehicle) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += HPHM_ERROR;
            }
        }

        if (!ok) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[YiZhou].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[YiZhou].zptype;
            v_dbhhg_list.dbresult = dbresult;
            v_dbhhg_list.dbbhg_desc = "一轴制动工位-照片:";
            v_dbhhg_list.dbbhg_desc += dbbhg_desc;

            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }
        }
    } else if (g_CheckItem.City == LIANGSHAN) {
        if (YiZhou == -1) {
            return;
        }

        bool ok = true;
        std::string dbbhg_desc, dbresult;
        if (ErZhou == -1) { // 平板制动
            if (!YiZhouZhiDongGongWei.b_zhidong) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[一轴车轮位置不对]";
            }
            if (!YiZhouZhiDongGongWei.b_chepai && !IsNewVehicle) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += HPHM_ERROR;
            } else {
                ZhuChe_ChePai = true;
            }

           /* if (!ZhiDongGongWei.b_erzhou) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[二轴车轮位置不对]";
            }*/

            if (!ok) {
                _dbbhg_list v_dbhhg_list;
                v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[YiZhou].zpid;
                v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[YiZhou].zptype;
                v_dbhhg_list.dbbhg_desc = "平板制动工位-照片:";
                v_dbhhg_list.dbresult = dbresult;
                v_dbhhg_list.dbbhg_desc += dbbhg_desc;

                p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
                if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                    dbbhgs++;
                }
            }
        } else {    // 滚筒
            /* 一轴制动 */
            {
                if (!YiZhouZhiDongGongWei.b_zhidong) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[一轴车轮位置不对]";
                }
                if (!YiZhouZhiDongGongWei.b_chepai && !IsNewVehicle) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += HPHM_ERROR;
                } else {
                    ZhuChe_ChePai = true;
                }
                if (!ok) {
                    _dbbhg_list v_dbhhg_list;
                    v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[YiZhou].zpid;
                    v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[YiZhou].zptype;
                    v_dbhhg_list.dbbhg_desc = "一轴制动工位-照片:";
                    v_dbhhg_list.dbresult = dbresult;
                    v_dbhhg_list.dbbhg_desc += dbbhg_desc;


                    p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
                    if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                        dbbhgs++;
                    }
                }
            }

            /* 二轴制动 */
            {
                bool ok = true;
                std::string dbbhg_desc, dbresult;

                if (!ErZhouZhiDongGongWei.b_zhidong) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[二轴车轮位置不对]";
                }
                if (!ErZhouZhiDongGongWei.b_chepai&&!IsNewVehicle) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += HPHM_ERROR;
                } else {
                    ZhuChe_ChePai = true;
                }

                if (!ok) {
                    _dbbhg_list v_dbhhg_list;
                    v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[ErZhou].zpid;
                    v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[ErZhou].zptype;
                    v_dbhhg_list.dbbhg_desc = "二轴制动工位-照片:";
                    v_dbhhg_list.dbresult = dbresult;
                    v_dbhhg_list.dbbhg_desc += dbbhg_desc;

                    p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
                    if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                        dbbhgs++;
                    }
                }
            }
        }
    }
    else
    {
        if ((YiZhou == -1) && (ErZhou == -1)) {
            return;
        }



        // 南京 南平 凉山平板制动没有二轴照片
        // 太原平板制动没有二轴照片
        if(g_CheckItem.City == NANJING || g_CheckItem.City == NANPING || g_CheckItem.City == TAIYUAN) {
            if ((!YiZhouZhiDongGongWei.b_guntong) && (!ErZhouZhiDongGongWei.b_guntong)) {   // 一二轴判定都是不是滚筒才确定是平板
                b_plate = true;
            }
         }

        /* 一轴制动 */
        if(YiZhou != -1)
        {
            bool ok = true;
            std::string dbbhg_desc, dbresult;

            if (BINZHOU == g_CheckItem.City)
            {
                if (g_CheckItem.picture.YiZhouZhiDong.QianLun) {
                    if (!YiZhouZhiDongGongWei.b_zhidong) {
                        dbbhg_desc += "[车轮位置不对]";
                        dbresult = FATAL_ERROR;
                        ok = false;
                        if ((p_vehicle_inf->m_b_yz_checked) && (g_CheckItem.video.YiZhouZhiDong.QianLun))
                        {
                            if (!V_YiZhouZhiDong.b_yizhou)
                            {
                                dbbhg_desc += "[视频-车轮位置不正确]";
                                dbresult = FATAL_ERROR;
                                ok = false;
                            }
                            else
                            {
                                dbbhg_desc += "[视频-车轮位置正确]";
                            }
                        }
                    }
                }

                if (g_CheckItem.picture.YiZhouZhiDong.ChePai) {
                    if (!YiZhouZhiDongGongWei.b_chepai&&!IsNewVehicle) {
                        dbbhg_desc += HPHM_ERROR;
                        dbresult = FATAL_ERROR;
                        ok = false;
                        if ((p_vehicle_inf->m_b_yz_checked) && (g_CheckItem.video.YiZhouZhiDong.ChePai))
                        {
                            if (!V_YiZhouZhiDong.b_chepai) {
                                dbbhg_desc += "[视频-车牌号不正确]";
                                dbresult = FATAL_ERROR;
                                ok = false;
                            }
                            else
                            {
                                dbbhg_desc += "[视频-车牌号正确]";
                            }
                        }
                    }
                }

                if ((p_vehicle_inf->m_b_yz_checked)&& (g_CheckItem.video.YiZhouZhiDong.WeiDeng))
                {
                    if (!V_YiZhouZhiDong.b_light) {
                        dbbhg_desc += "[视频-尾灯未亮]";
                        dbresult = FATAL_ERROR;
                        ok = false;
                    }
                    else
                    {
                        dbbhg_desc += "[视频-尾灯正常]";
                    }

                    if ((!V_YiZhouZhiDong.b_human_clear)&& (g_CheckItem.video.YiZhouZhiDong.Ren))
                    {
                        dbbhg_desc += "[视频-有人经过]";
                        dbresult = FATAL_ERROR;
                        ok = false;
                    }
                    else
                    {
                        dbbhg_desc += "[视频-无人员经过]";
                    }

                    if (!V_YiZhouZhiDong.b_time)
                    {
                        dbbhg_desc += "[视频-检测时间不足]";
                        dbresult = FATAL_ERROR;
                        ok = false;
                    }
                    else
                    {
                        dbbhg_desc += "[视频-检测时间正常]";
                    }
                }
            }
            else if(YICHUN == g_CheckItem.City)
            {
                if (g_CheckItem.picture.YiZhouZhiDong.QianLun) {
                    if (!YiZhouZhiDongGongWei.b_zhidong) {
                        if ((p_vehicle_inf->m_b_yz_checked) && (g_CheckItem.video.YiZhouZhiDong.QianLun))
                        {
                            if (!V_YiZhouZhiDong.b_yizhou)
                            {
                                dbbhg_desc += "[车轮位置不对]";
                                dbresult = FATAL_ERROR;
                                ok = false;
                                dbbhg_desc += "[视频-车轮位置不对]";
                            }
                        }
                        else
                        {
                            dbbhg_desc += "[车轮位置不对]";
                            dbresult = FATAL_ERROR;
                            ok = false;
                        }
                    }
                }

                if (g_CheckItem.picture.YiZhouZhiDong.ChePai) {
                    if (!YiZhouZhiDongGongWei.b_chepai&&!IsNewVehicle) {

                        if ((p_vehicle_inf->m_b_yz_checked) && (g_CheckItem.video.YiZhouZhiDong.ChePai))
                        {
                            if (!V_YiZhouZhiDong.b_chepai) {

                                dbbhg_desc += HPHM_ERROR;
                                dbbhg_desc += "[视频-车牌号不正确]";
                                dbresult = FATAL_ERROR;
                                ok = false;
                            }
                        }
                        else
                        {
                            dbbhg_desc += HPHM_ERROR;
                            dbresult = FATAL_ERROR;
                            ok = false;
                        }
                    }
                }
            }
            else
            {
                if (g_CheckItem.picture.YiZhouZhiDong.QianLun) {
                    if (!YiZhouZhiDongGongWei.b_zhidong) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[车轮位置不对]";
                    }
                }

                if (g_CheckItem.picture.YiZhouZhiDong.ChePai) {
                    if (!YiZhouZhiDongGongWei.b_chepai&&!IsNewVehicle) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += HPHM_ERROR;
                    } else {
                        ZhuChe_ChePai = true;
                    }
                }
            }

            if (g_CheckItem.picture.YiZhouZhiDong.ShuiYinRiQi) {
                if (!bYiZhouShuiYinRiQi) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += OUT_OF_DATE;
                }
            }



            // 南京、太原后刹车灯一个亮一个不亮的判别不合格，两个刹车灯都亮或者都不亮为合格
            // left 一轴制动 right 二轴制动
            if(g_CheckItem.City == NANJING || g_CheckItem.City == TAIYUAN) {
                if (Light_YiZhouZhiDongGongWei.b_car_left_light_on != Light_YiZhouZhiDongGongWei.b_car_right_light_on) { // 一轴制动刹车灯一个亮一个不亮
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[刹车灯不合格]";
                }
            }
            //九江刹车两个灯全部亮为合格
            if(g_CheckItem.City == JIUJIANG) {
                if (!Light_YiZhouZhiDongGongWei.b_car_left_light_on || !Light_YiZhouZhiDongGongWei.b_car_right_light_on) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[一轴制动刹车灯不合格]";
                }
                else
                {
                    JiuJiang_temp = true;
                }
            }

            if (b_plate) { // 平板制动
               /* if (!ZhiDongGongWei.b_erzhou) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[二轴车轮位置不对]";
                } */
            }

            if (!ok) {
                _dbbhg_list v_dbhhg_list;
                v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[YiZhou].zpid;
                v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[YiZhou].zptype;
                v_dbhhg_list.dbbhg_desc = "一轴制动工位-照片:";
                if (g_CheckItem.City!=JIUJIANG) {
                    v_dbhhg_list.dbresult = dbresult;
                    v_dbhhg_list.dbbhg_desc += dbbhg_desc;

                } else {
                    if ((p_vehicle_inf->m_cllx.substr(0, 2)=="K3") || (p_vehicle_inf->m_cllx.substr(0, 2)=="K4")) {
                        v_dbhhg_list.dbresult = dbresult;
                        v_dbhhg_list.dbbhg_desc += dbbhg_desc;

                    } else {
                        v_dbhhg_list.dbresult = std::string("4");
                        v_dbhhg_list.dbbhg_desc += std::string("暂不判定大车制动");
                    }
                }

                p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
                if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                    dbbhgs++;
                }
            }
        }

        /* 二轴制动 */
        if (!b_plate)
        {
            if(ErZhou != -1)
            {
                bool ok = true;
                std::string dbbhg_desc, dbresult;

                if (BINZHOU == g_CheckItem.City)
                {
                    if (g_CheckItem.picture.ErZhouZhiDong.HouLun) {
                        if (!ErZhouZhiDongGongWei.b_zhidong) {
                            dbbhg_desc += "[车轮位置不对]";
                            dbresult = FATAL_ERROR;
                            ok = false;
                            if ((p_vehicle_inf->m_b_ez_checked)&& (g_CheckItem.video.ErZhouZhiDong.HouLun))
                            {
                                if (!V_ErZhouZhiDong.b_erzhou)
                                {
                                    dbbhg_desc += "[视频-车轮位置不正确]";
                                    dbresult = FATAL_ERROR;
                                    ok = false;
                                }
                                else
                                {
                                    dbbhg_desc += "[视频-车轮位置正确]";
                                }
                            }
                        }
                    }

                    if (g_CheckItem.picture.ErZhouZhiDong.ChePai) {
                        if (!ErZhouZhiDongGongWei.b_chepai&&!IsNewVehicle) {
                            dbbhg_desc += HPHM_ERROR;
                            dbresult = FATAL_ERROR;
                            ok = false;
                            if ((p_vehicle_inf->m_b_ez_checked)&& (g_CheckItem.video.ErZhouZhiDong.ChePai))
                            {
                                if (!V_ErZhouZhiDong.b_chepai) {
                                    dbbhg_desc += "[视频检测车牌号不正确]";
                                    dbresult = FATAL_ERROR;
                                    ok = false;
                                }
                                else
                                {
                                    dbbhg_desc += "[视频检测车牌号正确]";
                                }
                            }
                        }
                    }

                    if (p_vehicle_inf->m_b_yz_checked)
                    {
                        if ((!V_ErZhouZhiDong.b_light)&& (g_CheckItem.video.ErZhouZhiDong.WeiDeng))
                        {
                            dbbhg_desc += "[视频-尾灯未亮]";
                            dbresult = FATAL_ERROR;
                            ok = false;
                        }
                        else
                        {
                            dbbhg_desc += "[视频-尾灯正常]";
                        }

                        if ((!V_ErZhouZhiDong.b_human_clear)&& (g_CheckItem.video.ErZhouZhiDong.Ren))
                        {
                            dbbhg_desc += "[视频-有人经过]";
                            dbresult = FATAL_ERROR;
                            ok = false;
                        }
                        else
                        {
                            dbbhg_desc += "[视频-无人员经过]";
                        }

                        if (!V_ErZhouZhiDong.b_time)
                        {
                            dbbhg_desc += "[视频-检测时间不足]";
                            dbresult = FATAL_ERROR;
                            ok = false;
                        }
                        else
                        {
                            dbbhg_desc += "[视频-检测时间正常]";
                        }
                    }

                }
                else if(YICHUN == g_CheckItem.City)
                {
                    if (g_CheckItem.picture.ErZhouZhiDong.HouLun) {
                        if (!ErZhouZhiDongGongWei.b_zhidong) {

                            if ((p_vehicle_inf->m_b_ez_checked)&& (g_CheckItem.video.ErZhouZhiDong.HouLun))
                            {
                                if (!V_ErZhouZhiDong.b_erzhou)
                                {
                                    dbbhg_desc += "[车轮位置不对]";
                                    dbbhg_desc += "[视频-位置不对]";
                                    dbresult = FATAL_ERROR;
                                    ok = false;
                                }
                            }
                            else
                            {
                                dbbhg_desc += "[车轮位置不对]";
                                dbresult = FATAL_ERROR;
                                ok = false;
                            }
                        }
                    }

                    if (g_CheckItem.picture.ErZhouZhiDong.ChePai) {
                        if (!ErZhouZhiDongGongWei.b_chepai&&!IsNewVehicle) {

                            if ((p_vehicle_inf->m_b_ez_checked)&& (g_CheckItem.video.ErZhouZhiDong.ChePai))
                            {
                                if (!V_ErZhouZhiDong.b_chepai) {
                                    dbbhg_desc += HPHM_ERROR;
                                    dbbhg_desc += "[视频-车牌号不正确]";
                                    dbresult = FATAL_ERROR;
                                    ok = false;
                                }
                            }
                            else
                            {
                                dbbhg_desc += HPHM_ERROR;
                                dbresult = FATAL_ERROR;
                                ok = false;
                            }
                        }
                    }
                }
                else
                {
                    if (g_CheckItem.picture.ErZhouZhiDong.HouLun) {
                        if (!ErZhouZhiDongGongWei.b_zhidong) {
                            ok = false;
                            dbresult = FATAL_ERROR;
                            dbbhg_desc += "[车轮位置不对]";
                        }
                    }

                    if (g_CheckItem.picture.ErZhouZhiDong.ChePai) {
                        if(g_CheckItem.City == FUZHOU2)
                        {/*抚州：如果一轴的号牌判定是通过的，那么，二轴的号牌也判定通过*/
                            if(!ZhuChe_ChePai)
                            {
                                if (!ErZhouZhiDongGongWei.b_chepai&&!IsNewVehicle) {
                                    ok = false;
                                    dbresult = FATAL_ERROR;
                                    dbbhg_desc += HPHM_ERROR;
                                }
                                else
                                {
                                    ZhuChe_ChePai = true;
                                }
                            }
                        }
                        else{

                            if (!ErZhouZhiDongGongWei.b_chepai&&!IsNewVehicle) {
                                ok = false;
                                dbresult = FATAL_ERROR;
                                dbbhg_desc += HPHM_ERROR;
                            } else {
                                ZhuChe_ChePai = true;
                            }
                        }

                    }
                }

                if (g_CheckItem.picture.ErZhouZhiDong.ShuiYinRiQi) {
                    if (!bErZhouShuiYinRiQi) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += OUT_OF_DATE;
                    }
                }


                if(g_CheckItem.City == NANJING || g_CheckItem.City == TAIYUAN) {
                    if (Light_ErZhouZhiDongGongWei.b_car_left_light_on != Light_ErZhouZhiDongGongWei.b_car_right_light_on) { // 二轴制动刹车灯一个亮一个不亮
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[刹车灯不合格]";
                    }
                }

                if(g_CheckItem.City == JIUJIANG) {
                    if(!JiuJiang_temp)
                    {
                        if (!Light_ErZhouZhiDongGongWei.b_car_left_light_on || !Light_ErZhouZhiDongGongWei.b_car_right_light_on)
                        {
                            ok = false;
                            dbresult = FATAL_ERROR;
                            dbbhg_desc += "[二轴制动刹车灯不合格]";
                        }
                    }

                }

                if (!ok) {
                    _dbbhg_list v_dbhhg_list;
                    v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[ErZhou].zpid;
                    v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[ErZhou].zptype;
                    v_dbhhg_list.dbbhg_desc = "二轴制动工位-照片:";

                    if (g_CheckItem.City!=JIUJIANG) {
                        v_dbhhg_list.dbresult = dbresult;
                        v_dbhhg_list.dbbhg_desc += dbbhg_desc;

                     } else {
                        if ((p_vehicle_inf->m_cllx.substr(0, 2)=="K3") || (p_vehicle_inf->m_cllx.substr(0, 2)=="K4")) {
                            v_dbhhg_list.dbresult = dbresult;
                            v_dbhhg_list.dbbhg_desc += dbbhg_desc;

                        } else {
                            v_dbhhg_list.dbresult = std::string("4");
                            v_dbhhg_list.dbbhg_desc += std::string("暂不判定大车制动");
                        }
                    }

                    p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
                    if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                        dbbhgs++;
                    }
                }
            }

        }
     }
}
void ResultCollection::doAnalyse_Others(vehicle_inf *p_vehicle_inf, bool IsPicture, int i)
{
    _dbbhg_list v_dbhhg_list;

    if (IsPicture) {
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "无法处理的照片类型";
    } else {
        v_dbhhg_list.zptype = p_vehicle_inf->m_splist[i].sptype;
        v_dbhhg_list.dbbhg_desc = "无法处理的视频类型";
    }

    v_dbhhg_list.dbresult = NEED_MANUAL;
    p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
}

std::string ResultCollection::makeConclusion(const vehicle_inf *p_vehicle_inf)
{
    char tmpArray[128] = { 0 };
    sprintf(tmpArray, "%lu", p_vehicle_inf->m_zplist.size());
    std::string ZP_size;
    ZP_size = tmpArray;

    sprintf(tmpArray, "%lu", p_vehicle_inf->m_splist.size());
    std::string SP_size;
    SP_size = tmpArray;

    int GeneralError = 0;
    int FatalError = 0;
    bool IsStandard = true;
    for (unsigned int i = 0; i < p_vehicle_inf->m_dbbhglist.size(); i++) {
        if (p_vehicle_inf->m_dbbhglist[i].dbresult == NORMAL_ERROR) {
            GeneralError++;
        } else if (p_vehicle_inf->m_dbbhglist[i].dbresult == FATAL_ERROR) {
            FatalError++;
        } else if (p_vehicle_inf->m_dbbhglist[i].dbresult == NEED_MANUAL) {
            IsStandard = false;
        }
    }

    std::string FinalResult;
    if ((GeneralError == 0) && (FatalError == 0)) {
        if (IsStandard) {
            FinalResult = "建议通过";
        } else {
            FinalResult = "建议人工审核";
        }
    } else {
        FinalResult = "建议不通过";
    }

    sprintf(tmpArray, "%lu", GeneralError);
    std::string GeneralError_String;
    GeneralError_String = tmpArray;
    sprintf(tmpArray, "%lu", FatalError);
    std::string FatalError_String;
    FatalError_String = tmpArray;
    std::string IsStandard_String;
    IsStandard_String = IsStandard ? "照片规范" : "照片不规范";

    std::string ret;
    ret = "共比对" + ZP_size + "个照片，" + SP_size + "个视频，"
        + GeneralError_String + "个一般错误，" + FatalError_String + "个严重错误；"
        + IsStandard_String + "；"
        + FinalResult;
//    ret = "共比对10个照片，" + SP_size + "个视频， 0个一般错误， 0个严重错误；"
//        + "照片规范；建议通过；";

    return ret;
}

void ResultCollection::doAnalyse_DiPanDongTai(vehicle_inf *p_vehicle_inf, int start, int end)
{
    if (NANJING == g_CheckItem.City)
        return;

    if ((start == -1) && (end == -1)) {
        return;
    }

    if (start == -1) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[end].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[end].zptype;
        v_dbhhg_list.dbbhg_desc = "底盘动态检验结束-照片::";
        v_dbhhg_list.dbbhg_desc += "[缺少底盘动态检验开始照片]";
        v_dbhhg_list.dbresult = NEED_MANUAL;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);

        return;
    }

    if (end == -1) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[start].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[start].zptype;
        v_dbhhg_list.dbbhg_desc = "底盘动态检验开始-照片::";
        v_dbhhg_list.dbbhg_desc += "[缺少底盘动态检验结束照片]";
        v_dbhhg_list.dbresult = NEED_MANUAL;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);

        return;
    }

    /* 动态开始 */
    {
        bool ok = true;
        std::string dbbhg_desc, dbresult;
        if (g_CheckItem.picture.DiPanDongTaiKaiShi.ShuiYinRiQi) {
            if (!bDiPanDongTaiKsShuiYinRiQi) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += OUT_OF_DATE;
            }
        }



        if (g_CheckItem.picture.DiPanDongTaiKaiShi.ChePai) {
            if(YICHUN == g_CheckItem.City)
            {
                if(g_CheckItem.picture.DiPanDongTaiKaiShi.ChePaiQueDing)
                {
                    if(!DiPanDongTai.b_chepai1)
                    {
                        if(p_vehicle_inf->m_b_dpdt_checked && g_CheckItem.video.DongTaiGongWei_1.ChePai)
                        {
                            if(!V_DiPanDongTai.b_chepai)
                            {
                                ok = false;
                                dbresult = FATAL_ERROR;
                                dbbhg_desc += HPHM_ERROR;
                                dbbhg_desc += "[视频-车牌号不正确]";
                            }
                        }
                        else
                        {
                            ok = false;
                            dbresult = FATAL_ERROR;
                            dbbhg_desc += HPHM_ERROR;

                        }
                    }
                }
                else
                {
                    if(!DiPanDongTai.b_chepai1 && !DiPanDongTai.b_chepai2)
                    {
                        if(p_vehicle_inf->m_b_dpdt_checked && g_CheckItem.video.DongTaiGongWei_1.ChePai)
                        {
                            if(!V_DiPanDongTai.b_chepai)
                            {
                                ok = false;
                                dbresult = FATAL_ERROR;
                                dbbhg_desc += HPHM_ERROR;
                                dbbhg_desc += "[视频-车牌号不正确]";
                            }
                        }
                        else
                        {
                            ok = false;
                            dbresult = FATAL_ERROR;
                            dbbhg_desc += HPHM_ERROR;

                        }
                    }
                }
            }
            else
            {
                if (!DiPanDongTai.b_chepai1) {

                    /* 如果ChePaiQueDing配置打开，表示需要确认开始和结束各自的车牌 */
                    if (g_CheckItem.picture.DiPanDongTaiKaiShi.ChePaiQueDing) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += HPHM_ERROR;
                    } else {    /* 如果ChePaiQueDing配置关闭，表示开始和结束两个车牌只要一个通过就都通过 */
                        if (!DiPanDongTai.b_chepai2) {
                            ok = false;
                            dbresult = FATAL_ERROR;
                            dbbhg_desc += HPHM_ERROR;
                            if ((BINZHOU == g_CheckItem.City) && (p_vehicle_inf->m_b_dtks_checked))
                            {
                                if (!V_DiPanDongTaiKaiShi.b_chepai)
                                {
                                    ok = false;
                                    dbresult = FATAL_ERROR;
                                    dbbhg_desc += "[视频车牌号不正确]";
                                }
                                else
                                {
                                    dbbhg_desc += "[视频车牌号正确]";
                                }
                            }
                        }
                    }
                }
            }

        }
        if (BINZHOU == g_CheckItem.City)
        {
            if ((!V_DiPanDongTaiKaiShi.b_time) && (p_vehicle_inf->m_b_dtks_checked))
            {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[底盘动态开始视频-检验时间不足]";
            }
            else
            {
                dbbhg_desc += "[底盘动态开始视频-检验时间正常]";
            }
        }

        if (g_CheckItem.picture.DiPanDongTaiKaiShi.YiDong) {
            if(YICHUN == g_CheckItem.City)
            {
                if(!DiPanDongTai.b_move)
                {
                    if(g_CheckItem.video.DongTaiGongWei_1.WeiYi && p_vehicle_inf->m_b_dpdt_checked)
                    {
                        if(!V_DiPanDongTai.b_move)
                        {
                            ok = false;
                            dbresult = FATAL_ERROR;
                            dbbhg_desc += "[车未移动]";
                            dbbhg_desc += "[视频-车未移动]";
                        }
                    }
                    else
                    {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[车未移动]";
                    }
                }
            }
            else
            {
                if (!DiPanDongTai.b_move) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[车未移动]";
                }
            }

        }

        if(g_CheckItem.City==YUEYANG)
        {
            if (g_CheckItem.picture.DiPanDongTaiKaiShi.CheWei) {
                if (!DiPanDongTai.b_begin_chewei) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[未检测到车尾]";
                }
            }
        }

        if (g_CheckItem.City==TIANJIN)
        {
            if (g_CheckItem.picture.DiPanDongTaiKaiShi.BiaoZhi) {
                if (!DiPanDongTai.b_biaozhi1) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[未检测到标志]";
                }
            }
        }

        if (!ok) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[start].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[start].zptype;
            v_dbhhg_list.dbbhg_desc = "底盘动态检验开始-照片:";
            v_dbhhg_list.dbbhg_desc += dbbhg_desc;
            v_dbhhg_list.dbresult = dbresult;
            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }
        }
    }

    /* 动态结束*/
    {
        bool ok = true;
        std::string dbbhg_desc, dbresult;

        if (g_CheckItem.picture.DiPanDongTaiJieShu.ShuiYinRiQi) {
            if (!bDiPanDongTaiJsShuiYinRiQi) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += OUT_OF_DATE;
            }
        }

        if (g_CheckItem.picture.DiPanDongTaiJieShu.ChePai) {
            if(YICHUN == g_CheckItem.City)
            {
                if(g_CheckItem.picture.DiPanDongTaiKaiShi.ChePaiQueDing)
                {
                    if(!DiPanDongTai.b_chepai2)
                    {
                        if(p_vehicle_inf->m_b_dpdt_checked && g_CheckItem.video.DongTaiGongWei_2.ChePai)
                        {
                            if(!V_DiPanDongTai.b_chepai)
                            {
                                ok = false;
                                dbresult = FATAL_ERROR;
                                dbbhg_desc += HPHM_ERROR;
                                dbbhg_desc += "[视频-车牌号不正确]";
                            }
                        }
                        else
                        {
                            ok = false;
                            dbresult = FATAL_ERROR;
                            dbbhg_desc += HPHM_ERROR;

                        }
                    }
                }
                else
                {
                    if(!DiPanDongTai.b_chepai1 && !DiPanDongTai.b_chepai2)
                    {
                        if(p_vehicle_inf->m_b_dpdt_checked && g_CheckItem.video.DongTaiGongWei_2.ChePai)
                        {
                            if(!V_DiPanDongTai.b_chepai)
                            {
                                ok = false;
                                dbresult = FATAL_ERROR;
                                dbbhg_desc += HPHM_ERROR;
                                dbbhg_desc += "[视频-车牌号不正确]";
                            }
                        }
                        else
                        {
                            ok = false;
                            dbresult = FATAL_ERROR;
                            dbbhg_desc += HPHM_ERROR;

                        }
                    }
                }
            }
            else
            {
                if (!DiPanDongTai.b_chepai2) {

                    /* 如果ChePaiQueDing配置打开，表示需要确认开始和结束各自的车牌 */
                    if (g_CheckItem.picture.DiPanDongTaiKaiShi.ChePaiQueDing) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += HPHM_ERROR;
                    } else {    /* 如果ChePaiQueDing配置关闭，表示开始和结束两个车牌只要一个通过就都通过 */
                        if (!DiPanDongTai.b_chepai1) {
                            ok = false;
                            dbresult = FATAL_ERROR;
                            dbbhg_desc += HPHM_ERROR;
                            if ((BINZHOU == g_CheckItem.City) && (p_vehicle_inf->m_b_dtjs_checked))
                            {
                                if (!V_DiPanDongTaiJieShu.b_chepai)
                                {
                                    ok = false;
                                    dbresult = FATAL_ERROR;
                                    dbbhg_desc += "[视频车牌号不正确]";
                                }
                                else
                                {
                                    dbbhg_desc += "[视频车牌号正确]";
                                }
                            }
                        }
                    }
                }
            }

        }
        if (BINZHOU == g_CheckItem.City)
        {
            if ((!V_DiPanDongTaiJieShu.b_time) && (p_vehicle_inf->m_b_dtjs_checked))
            {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[底盘动态结束视频-检验时间不足]";
            }
            else
            {
                dbbhg_desc += "[底盘动态结束视频-检验时间正常]";
            }
        }

        if (g_CheckItem.picture.DiPanDongTaiJieShu.YiDong) {
            if(YICHUN == g_CheckItem.City)
            {
                if(!DiPanDongTai.b_move)
                {
                    if(g_CheckItem.video.DongTaiGongWei_2.WeiYi && p_vehicle_inf->m_b_dpdt_checked)
                    {
                        if(!V_DiPanDongTai.b_move)
                        {
                            ok = false;
                            dbresult = FATAL_ERROR;
                            dbbhg_desc += "[车未移动]";
                            dbbhg_desc += "[视频-车未移动]";
                        }
                    }
                    else
                    {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[车未移动]";
                    }
                }
            }
            else
            {
                if (!DiPanDongTai.b_move) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "车未移动";
                }
            }

        }

        if (g_CheckItem.City==TIANJIN)
        {
            if (g_CheckItem.picture.DiPanDongTaiJieShu.BiaoZhi) {
                if (!DiPanDongTai.b_biaozhi2) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[未检测到标志]";
                }
            }
        }

        if(g_CheckItem.City==YUEYANG)
        {
            if (g_CheckItem.picture.DiPanDongTaiJieShu.CheTou) {
                if (!DiPanDongTai.b_end_chetou) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[未检测到车头]";
                }
            }
        }

        if (!ok) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[end].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[end].zptype;
            v_dbhhg_list.dbbhg_desc = "底盘动态检验结束-照片:";
            v_dbhhg_list.dbbhg_desc += dbbhg_desc;
            v_dbhhg_list.dbresult = dbresult;
            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }
        }
    }
}

void ResultCollection::doAnalyse_DiPan(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if (g_CheckItem.picture.DiPanBuJian.GongWei) {
        if (!DiPan.b_dipan) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[底盘不在工位]";
        }
    }

    if (g_CheckItem.City != JIUJIANG) {
        if (g_CheckItem.picture.DiPanBuJian.ChePai) {
            if (!DiPan.b_chepai&&!IsNewVehicle) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += HPHM_ERROR;
            }
        }
    } else {
        if ( (p_vehicle_inf->m_cllx.substr(0, 2)=="K3") || (p_vehicle_inf->m_cllx.substr(0, 2)=="K4")) {
            if (g_CheckItem.picture.DiPanBuJian.ChePai) {
                if (!DiPan.b_chepai&&!IsNewVehicle) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += HPHM_ERROR;
                }
            }
        }
    }

    if (g_CheckItem.picture.DiPanBuJian.ShuiYinRiQi) {
        if (!bDiPanShuiYinRiQi) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += OUT_OF_DATE;
        }
    }

    if (BINZHOU == g_CheckItem.City)
    {
        if (g_CheckItem.picture.DiPanBuJian.Ren)
        {
            if (!DiPan.b_human)
            {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[没有检验员]";
                if ((p_vehicle_inf->m_b_dp_checked)&& (g_CheckItem.video.DiPanGongWei.Ren))
                {
                    if (!V_DiPan.b_human)
                    {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[视频-没有检验员]";
                    }
                    else
                    {
                        dbbhg_desc += "[视频-检验员正常]";
                    }
                }
            }
        }

        if ((p_vehicle_inf->m_b_dp_checked)&& (g_CheckItem.video.DiPanGongWei.Ren))
        {
            if (!V_DiPan.b_time)
            {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[视频-检查时间不足]";
            }
            else
            {
                dbbhg_desc += "[视频-检查时间正常]";
            }
        }
    }
    else if(YICHUN == g_CheckItem.City)
    {
        if (g_CheckItem.picture.DiPanBuJian.Ren) {
            if(!DiPan.b_human)
            {
                if(p_vehicle_inf->m_b_dp_checked && g_CheckItem.video.DiPanGongWei.Ren)
                {
                    if(!V_DiPan.b_human)
                    {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[没有检验员]";
                        dbbhg_desc += "[视频-没有检验员]";
                    }
                }
                else
                {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[没有检验员]";
                }
            }
        }
    }
    else
    {
        if (g_CheckItem.picture.DiPanBuJian.Ren) {
            if (!DiPan.b_human) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[没有检验员]";
            }
        }
    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "底盘检验-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}

void ResultCollection::doAnalyse_ZhuCheZhiDong(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if (BINZHOU == g_CheckItem.City)
    {
        if (g_CheckItem.picture.ZhuCheZhiDong.ChePai) {
            if (!ZhuCheZhiDong.b_chepai && !IsNewVehicle)
            {
                dbbhg_desc += HPHM_ERROR;
                ok = false;
                dbresult = FATAL_ERROR;
                if (p_vehicle_inf->m_b_yz_checked || p_vehicle_inf->m_b_ez_checked)
                {
                    if (!V_YiZhouZhiDong.b_chepai && !V_YiZhouZhiDong.b_chepai){
                        ok = false;
                        dbbhg_desc += "[视频-车牌错误]";
                        dbresult = FATAL_ERROR;
                    }
                    else
                    {
                        dbbhg_desc += "[视频-车牌正确]";
                    }
                }
            }
        }
    }
    else if(YICHUN == g_CheckItem.City)
    {
        if(g_CheckItem.picture.ZhuCheZhiDong.ChePai)
        {
            if (!ZhuCheZhiDong.b_chepai && !IsNewVehicle)
            {
                if(g_CheckItem.video.ZhuCheZhiDong.ChePai && p_vehicle_inf->m_b_zczd_checked)
                {
                    if(!V_ZhuCheZhiDong.b_chepai)
                    {
                        dbbhg_desc += HPHM_ERROR;
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[视频-车牌错误]";
                    }
                }
                else
                {
                    dbbhg_desc += HPHM_ERROR;
                    ok = false;
                    dbresult = FATAL_ERROR;
                }
            }
        }
    }
    else
    {
        if (g_CheckItem.picture.ZhuCheZhiDong.ChePai) {

            if (g_CheckItem.City == NINGBO || g_CheckItem.City == NANJING || g_CheckItem.City == FUZHOU2) {
                if (!ZhuChe_ChePai) {
                    if (!ZhuCheZhiDong.b_chepai && !IsNewVehicle) {
                        ok = false;
                        dbbhg_desc += HPHM_ERROR;
                        dbresult = FATAL_ERROR;
                    }
                }
            }
            else {
                if (!ZhuCheZhiDong.b_chepai && !IsNewVehicle) {
                    ok = false;
                    dbbhg_desc += HPHM_ERROR;
                    dbresult = FATAL_ERROR;
                }
            }
        }
    }

    if (g_CheckItem.picture.ZhuCheZhiDong.ShuiYinRiQi) {
        if (!bZhuCheZhiDongShuiYinRiQi) {
            ok = false;
            dbbhg_desc += OUT_OF_DATE;
            dbresult = FATAL_ERROR;
        }
    }

    if (BINZHOU == g_CheckItem.City)
    {
        if (g_CheckItem.picture.ZhuCheZhiDong.CheLun) {
            if (!ZhuCheZhiDong.b_zhidong) {
                ok = false;
                dbbhg_desc += "[车轮位置不对]";
                dbresult = FATAL_ERROR;
                if (p_vehicle_inf->m_b_yz_checked || p_vehicle_inf->m_b_ez_checked)
                {
                    if (!V_YiZhouZhiDong.b_zhuche)
                    {
                        ok = false;
                        dbbhg_desc += "[视频-驻车制动不通过]";
                        dbresult = FATAL_ERROR;
                    }
                    else
                    {
                        dbbhg_desc += "[视频-驻车制动通过]";
                    }
                }
            }
        }
    }
    else if(YICHUN == g_CheckItem.City)
    {
        if (g_CheckItem.picture.ZhuCheZhiDong.CheLun) {
            if (!ZhuCheZhiDong.b_zhidong) {
                if(p_vehicle_inf->m_b_zczd_checked && g_CheckItem.video.ZhuCheZhiDong.HouLun)
                ok = false;
                dbbhg_desc += "[车轮位置不对]";
                dbresult = FATAL_ERROR;
                if(!V_ZhuCheZhiDong.b_zhuche)
                {
                    ok = false;
                    dbbhg_desc += "[车轮位置不对]";
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[视频-驻车制动不通过]";
                }
                else
                {
                    ok = false;
                    dbbhg_desc += "[车轮位置不对]";
                    dbresult = FATAL_ERROR;
                }

            }
        }
    }
    else
    {
        if (g_CheckItem.picture.ZhuCheZhiDong.CheLun) {
            if (!ZhuCheZhiDong.b_zhidong) {
                ok = false;
                dbbhg_desc += "[车轮位置不对]";
                dbresult = FATAL_ERROR;
            }
        }
    }

    if(g_CheckItem.City == NANJING) {
        // 南京后刹车灯一个亮一个不亮的判别不合格，两个刹车灯都亮或者都不亮为合格
        if (Light_ZhuCheZhiDong.b_car_left_light_on != Light_ZhuCheZhiDong.b_car_right_light_on) { // 不合格
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[刹车灯不合格]";
        }
    }
    if(g_CheckItem.City == XIAN) {
        // 西安后刹车灯都不亮为合格
        if (Light_ZhuCheZhiDong.b_car_left_light_on || Light_ZhuCheZhiDong.b_car_right_light_on) { // 不合格
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[驻车制动刹车灯不合格]";
        }
    }

    if(g_CheckItem.City == FUZHOU2 || g_CheckItem.City == TAIYUAN) {
        // 抚州、太原后刹车灯都不亮为合格
        if (Light_ZhuCheZhiDong.b_car_left_light_on || Light_ZhuCheZhiDong.b_car_right_light_on) { // 不合格
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[驻车制动刹车灯不合格]";
        }
    }
    if(g_CheckItem.City == JIUJIANG || g_CheckItem.City == QingDao)
    {
        if (Light_ZhuCheZhiDong.b_car_left_light_on|| Light_ZhuCheZhiDong.b_car_right_light_on) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[驻车制动刹车灯不合格]";
        }

    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "驻车制动工位-照片:";
        v_dbhhg_list.dbresult = dbresult;
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}

void ResultCollection::doAnalyse_QianHouLunTaiZhaoPian(vehicle_inf *p_vehicle_inf, int i, bool b_qianlun)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if (b_qianlun) {
        if (!QianLunTaiZhaoPian.b_chepai) {
            ok = false;
            dbbhg_desc += HPHM_ERROR;
            dbresult = FATAL_ERROR;
        }
    } else {
        if (!HouLunTaiZhaoPian.b_chepai) {
            ok = false;
            dbbhg_desc += HPHM_ERROR;
            dbresult = FATAL_ERROR;
        }
    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        if (b_qianlun)
            v_dbhhg_list.dbbhg_desc = "前轮胎-照片:";
        else
            v_dbhhg_list.dbbhg_desc = "后轮胎-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}

void ResultCollection::doAnalyse_PoDaoZhiDong(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if (!PoDaoZhiDong.b_chepai && !IsNewVehicle) {
        ok = false;
        dbbhg_desc += HPHM_ERROR;
        dbresult = FATAL_ERROR;
    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "坡道制动-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}

void ResultCollection::doAnalyse_MieHuoQi(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if (g_CheckItem.picture.MieHuoQi.MieHuoQi) {
        if (!MieHuoQi.b_miehuoqi) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[没有灭火器]";
        }
    }

    if (g_CheckItem.picture.MieHuoQi.YaLiBiao) {
        if (!MieHuoQi.b_yalibiao) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[没有压力表]";
        }
    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "灭火器-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}

void ResultCollection::doAnalyse_YingJiChui(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if (g_CheckItem.picture.YingJiChui.YingJiChui) {
        if (!YingJiChui.b_yingjichui) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[没有应急锤]";
        }
    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "应急锤-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}

void ResultCollection::doAnalyse_JiLuYi(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if (g_CheckItem.picture.JiLuYi.JiLuYi) {
        if (!JiLuYi.b_xingchejiluyi) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[没有行驶记录仪]";
        }
    }

    if (g_CheckItem.picture.JiLuYi.RenZheng) {
        if (!JiLuYi.b_triple_c) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[没有3C标志]";
        }
    }

    if (g_CheckItem.picture.JiLuYi.PingMu) {
        if (!JiLuYi.b_screen) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[屏幕不亮]";
        }
    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "行驶记录装置-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}

void ResultCollection::doAnalyse_RouXingBiaoQian(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;
}


void ResultCollection::doAnalyse_HeDingZaiKe(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;



    if(g_CheckItem.City == ZHANGJIAJIE)
    {
        if (!HeDingZaiKe.b_total_mass) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[总质量不符合]";
        }
        if (!HeDingZaiKe.b_board_height) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[栏板高度不符合]";
        }

        if (!ok) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
            v_dbhhg_list.dbbhg_desc = "总质量栏板高度-照片:";
            v_dbhhg_list.dbbhg_desc += dbbhg_desc;
            v_dbhhg_list.dbresult = dbresult;
            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }
        }
    }
    else
    {
        if(p_vehicle_inf->m_cllx.find("K39") != std::string::npos)
        {
            if (g_CheckItem.picture.HeDingZaiKe.HeDingZaiKe) {
                if (!HeDingZaiKe.b_person_number) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[核定载客数不符合]";
                }
            }
        }
        else
        {
            ok = false;
            dbresult = NEED_MANUAL;
            dbbhg_desc += "[照片不在处理范围]";
        }

        if (!ok) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
            v_dbhhg_list.dbbhg_desc = "核定载客数-照片:";
            v_dbhhg_list.dbbhg_desc += dbbhg_desc;
            v_dbhhg_list.dbresult = dbresult;
            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }
        }
    }




}

void ResultCollection::doAnalyse_ZuoQianLun(vehicle_inf *p_vehicle_inf, int i)
{
    /*
     * 临沂小车（K3和K4）左前轮胎规格照片，实际上传的是轮胎花纹照片，客户认为可以直接判定通过。
     * 其它类型的车辆，上传的是轮胎规格照片。
    */
    if (g_CheckItem.City == LINYI) {
        if (p_vehicle_inf->m_cllx.substr(0, 2) == "K3" || p_vehicle_inf->m_cllx.substr(0, 2) == "K4") {
            return;
        }
    }

    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if (g_CheckItem.picture.ZuoQianLun.LunTai) {
        if (!ZuoQianLun.b_luntaiguige) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[轮胎规格不对]";
        }
    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "左前轮胎规格型号-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}

void ResultCollection::doAnalyse_YouQianLun(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if (g_CheckItem.picture.YouQianLun.LunTai) {
        if (!YouQianLun.b_luntaiguige) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[轮胎规格不对]";
        }
    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "右前轮胎规格型号-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}

void ResultCollection::doAnalyse_CheXiang(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if((p_vehicle_inf->m_cllx.find("K38"))||(p_vehicle_inf->m_cllx.find("K39")))
    {
            if(g_CheckItem.City != XIANGYANG)
            {
                if (g_CheckItem.picture.CheXiang.ZuoWei) {
                    if (!KeCheXiang.b_internal) {  //fix me-0918
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[不符合拍摄规范]";
                    }
                }

                if (g_CheckItem.picture.CheXiang.GaiZhuang) {
                    if (p_vehicle_inf->m_cllx == "K39" && !KeCheXiang.b_suspect_modified) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[车辆有改装]";
                    }
                }

            }
            else if(p_vehicle_inf->m_cllx.find("K39"))
            {
                if(g_CheckItem.picture.CheXiang.ZuoWei)
                {
                    if(!KeCheXiang.b_seat)
                    {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[座位数不对]";
                    }
                }
                if(g_CheckItem.picture.CheXiang.GaiZhuang)
                {
                    if (!KeCheXiang.b_suspect_modified) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[车辆有改装]";
                    }
                }
            }

    }
    else
    {

        if(g_CheckItem.City==ZHANGJIAJIE)
        {
            if(p_vehicle_inf->m_cllx=="H32")
            {
                if (!HuoCheXiang.b_ori_chexiang) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[车厢内部有改装]";
                }
            }
        }
        else
        {
            if (p_vehicle_inf->m_cllx.substr(0, 1) == "H") { /* 货车 */
                if (g_CheckItem.picture.CheXiang.GaiZhuang) {
                    if(p_vehicle_inf->m_cllx.substr(2, 1) == "2")
                    {
                        if (!HuoCheXiang.b_ori_chexiang) {
                            ok = false;
                            dbresult = FATAL_ERROR;
                            dbbhg_desc += "[车厢内部有改装]";
                        }
                    }
                    if(p_vehicle_inf->m_cllx.substr(2, 1) == "9")
                    {
                        if (HuoCheXiang.b_roof_modified) {
                            ok = false;
                            dbresult = FATAL_ERROR;
                            dbbhg_desc += "[车厢内部有改动]";
                        }
                    }
                }

                if (g_CheckItem.picture.CheXiang.JiaoDu) {
                    if (!HuoCheXiang.b_correct_pose) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[摄角度不合要求]";
                    }
                }

                if(g_CheckItem.City==ZHANGJIAJIE)
                {
                    if (g_CheckItem.picture.CheXiang.FengDing) {
                        if (HuoCheXiang.b_top_closed) {
                            ok = false;
                            dbresult = FATAL_ERROR;
                            dbbhg_desc += "[车厢封闭]";
                        }
                    }
                }
                else
                {
                    if (g_CheckItem.picture.CheXiang.FengDing) {
                        if (!HuoCheXiang.b_top_closed) {
                            ok = false;
                            dbresult = FATAL_ERROR;
                            dbbhg_desc += "[车顶没有封闭]";
                        }
                    }
                }

            } else if (p_vehicle_inf->m_cllx.substr(0, 1) == "K") {  /* 客车 */
                if (g_CheckItem.picture.CheXiang.ZuoWei) {
                    if (!KeCheXiang.b_seat) {
                        ok = false;
                        dbresult = FATAL_ERROR;
                        dbbhg_desc += "[座位数不对]";
                    }
                }
            } else {
                ok = false;
                dbresult = NEED_MANUAL;
                dbbhg_desc += "[不能处理除了客车和货车以外的车厢内部照片]";
            }
        }
    }


    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "车厢内部-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }

}


void ResultCollection::doAnalyse_HouPaiCheXiang(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if((p_vehicle_inf->m_cllx.find("K38"))||(p_vehicle_inf->m_cllx.find("K39")))
    {
        if (g_CheckItem.picture.HouPaiCheXiang.AnQuanDai) {
            if (!HouPaiCheXiang.b_anquandai) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[没有安全带]";
            }
        }
    }
    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "车厢内部后排-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }

}

void ResultCollection::doAnalyse_HouPaiCheXiang2(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if((p_vehicle_inf->m_cllx.find("K38"))||(p_vehicle_inf->m_cllx.find("K39")))
    {
        if (g_CheckItem.picture.HouPaiCheXiang2.AnQuanDai) {
            if (!HouPaiCheXiang2.b_anquandai) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[没有安全带]";
            }
        }
    }
    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "车厢内部后排-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }

}


void ResultCollection::doAnalyse_CeHuaGongWei(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if(g_CheckItem.City==LAIBIN)
    {
        if (!CeHuaGongWei.b_zhidong) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[前轮不在侧滑工位上]";
        }
    }

    if (g_CheckItem.picture.CeHuaGongWei.ChePai) {
        if (!CeHuaGongWei.b_chepai&&!IsNewVehicle) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += HPHM_ERROR;
        }
    }



    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "侧滑工位-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}

void ResultCollection::doAnalyse_WaiKuoQianMian(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if(g_CheckItem.City==ZHANGJIAJIE)
    {
        if(stoi(p_vehicle_inf->m_zzl)>3500)
        {
            if (!WaiKuoQianMian.b_rear_protect) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "未检测到后面栏板";
            }
        }

        if (!ok) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
            v_dbhhg_list.dbbhg_desc = "货车背面-照片:";
            v_dbhhg_list.dbbhg_desc += dbbhg_desc;
            v_dbhhg_list.dbresult = dbresult;
            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }
        }
    }
    else
    {
        if (g_CheckItem.picture.WaiKuoQianMian.ChePai) {
            if (!WaiKuoQianMian.b_chepai&&!IsNewVehicle) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += HPHM_ERROR;
            }
        }

        if (!ok) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
            v_dbhhg_list.dbbhg_desc = "外廓尺寸自动测量前面-照片:";
            v_dbhhg_list.dbbhg_desc += dbbhg_desc;
            v_dbhhg_list.dbresult = dbresult;
            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }
        }
    }

}

void ResultCollection::doAnalyse_WaiKuoCeMian(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;
    if(g_CheckItem.City==ZHANGJIAJIE)
    {
        if(stoi(p_vehicle_inf->m_zzl)>3500)
        {
            if (!WaiKuoQianMian.b_right_protect) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "未检测到侧面栏板";
            }
        }

        if (!ok) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
            v_dbhhg_list.dbbhg_desc = "货车侧面-照片:";
            v_dbhhg_list.dbbhg_desc += dbbhg_desc;
            v_dbhhg_list.dbresult = dbresult;
            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }
        }
    }
    else
    {
        if (g_CheckItem.picture.WaiKuoCeMian.ChePai) {
            if (!WaiKuoCeMian.b_chepai&&!IsNewVehicle) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += HPHM_ERROR;
            }
        }

        if (!ok) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
            v_dbhhg_list.dbbhg_desc = "外廓尺寸自动测量侧面-照片:";
            v_dbhhg_list.dbbhg_desc += dbbhg_desc;
            v_dbhhg_list.dbresult = dbresult;
            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }
        }
    }
}

void ResultCollection::doAnalyse_DaCheHaoPai(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if (g_CheckItem.picture.DaCheHaoPai.ChePai) {
        if (!DaCheHaoPai.b_chepai&&!IsNewVehicle) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += HPHM_ERROR;
        }
    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "大车车牌-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}



void ResultCollection::doAnalyse_WeiXiangNeiBu(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if (g_CheckItem.picture.WeiXiangNeiBu.GaiZhuang) {
        if (!WeiXiangNeiBu.b_gaizhuang) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[尾箱改装]";
        }
    }

    if(g_CheckItem.City == GUIGANG)
    {
        if (!WeiXiangNeiBu.b_chepai) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += HPHM_ERROR;
        }
    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "尾箱-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}



void ResultCollection::doAnalyse_XingShiZhengBeiMian(vehicle_inf *p_vehicle_inf, int i)
{
    if (g_CheckItem.City == ZHAOTONG) {
        return; /* 昭通的“行驶证背面”直接判定为通过 */
    }

    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if(g_CheckItem.City==NANNING)
    {
        if (g_CheckItem.picture.XingShiZheng.BeiMian) {
            if (!XingShiZhengBeiMian.b_cheliang) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[未检测到行驶证主页反面车辆]";
            }
        }
        if (g_CheckItem.picture.XingShiZhengBeiMian.FuYe)
        {
            if (!XingShiZhengBeiMian.b_fuyefanmian) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[未检测到行驶证副页反面]";
            }
        }

    }
    else
    {
        if (g_CheckItem.picture.XingShiZheng.BeiMian) {
            if (!XingShiZhengBeiMian.b_cheliang) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[未检测到行驶证主页反面车辆]";
            }
        }

        if (g_CheckItem.City == TIANJIN)
        {
            if (g_CheckItem.picture.XingShiZhengBeiMian.FuYe)
            {
                if (!XingShiZhengBeiMian.b_fuyefanmian) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[未检测到行驶证副页]";
                }
            }
        }
        else if(g_CheckItem.City == SHENZHEN)
        {
           if (g_CheckItem.picture.XingShiZhengBeiMian.FuYe)
           {
               if (!XingShiZhengBeiMian.b_fuyefanmian) {
                   ok = false;
                   dbresult = FATAL_ERROR;
                   dbbhg_desc += "[未检测到行驶证副页反面]";
               }
           }
//           if (g_CheckItem.picture.XingShiZhengBeiMian.ShenFenZheng)
//           {
//               if (!XingShiZhengBeiMian.b_sfz_fanmian) {
//                   ok = false;
//                   dbresult = FATAL_ERROR;
//                   dbbhg_desc += "[未检测到身份证反面]";
//               }
//           }
//           if (g_CheckItem.picture.XingShiZhengBeiMian.YouXiaoQi)
//           {
//               if (!XingShiZhengBeiMian.b_sfzrq_valid) {
//                   ok = false;
//                   dbresult = FATAL_ERROR;
//                   dbbhg_desc += "[不在有效期内]";
//               }
//           }

        } else {
            if (g_CheckItem.picture.XingShiZheng.BeiMian) {
                if (!XingShiZhengBeiMian.b_cheliang) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[未检测到行驶证主页反面车辆]";
                }
            }

            if (g_CheckItem.picture.XingShiZhengBeiMian.FuYe) {
                if (!XingShiZhengBeiMian.b_fuyefanmian) {
                    ok = false;
                    dbresult = FATAL_ERROR;
                    dbbhg_desc += "[未检测到行驶证副页背面]";
                }
            }

            if (g_CheckItem.City == ANSHUN && XingShiZhengBeiMian.fuyezhang_cnt > 5) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[行驶证副页背面印章数已超过5个]";
            }
        }
    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "行驶证反面-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}

void ResultCollection:: doAnalyse_FuZhuZhiDong(vehicle_inf *p_vehicle_inf,int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if (g_CheckItem.picture.FuZhuZhiDong.FuZhuZhiDong) {
        if (!FuZhuZhiDong.b_fuzhuzhidong) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[没有辅助制动标志]";
        }
    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "辅助制动标志-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}
void ResultCollection:: doAnalyse_ABS(vehicle_inf *p_vehicle_inf,int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if (g_CheckItem.picture.ABS.ABS) {
        if (!ABS.b_abs) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[没有自检状态灯]";
        }
    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "ABS检测-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}

void ResultCollection::doAnalyse_CheLiangCeMian(vehicle_inf *p_vehicle_inf,int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if (g_CheckItem.picture.CheLiangCeMian.CheLiangCeMian) {
        if (CeMian.i_tiehua > 1) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[检测到广告]";
        }
    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "车辆侧面-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}

void ResultCollection::doAnalyse_CheLiangCeMian2(vehicle_inf *p_vehicle_inf,int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if (g_CheckItem.picture.CheLiangCeMian.CheLiangCeMian) {
        if(p_vehicle_inf->m_cllx.find("K39") != std::string::npos || p_vehicle_inf->m_cllx.find("K31") != std::string::npos)
        {

             if (!CheLiangCeMian.b_person_number) {
                  ok = false;
                  dbresult = FATAL_ERROR;
                  dbbhg_desc += "[核定载客数不符合]";
             }

        }
        else
        {
            ok = false;
            dbresult = NEED_MANUAL;
            dbbhg_desc += "[照片不在处理范围]";
        }

    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "车辆侧面-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
}

void ResultCollection:: doAnalyse_QianHaoPai(vehicle_inf *p_vehicle_inf,int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if (g_CheckItem.picture.QianHaoPai.ChePai) {
        if (!QianHaoPai.b_chepai) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += HPHM_ERROR;
        }
    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "车辆前方牌照-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
    return;
}

void ResultCollection:: doAnalyse_HouHaoPai(vehicle_inf *p_vehicle_inf,int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if (g_CheckItem.picture.HouHaoPai.ChePai) {
        if (!HouHaoPai.b_chepai) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += HPHM_ERROR;
        }
    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "车辆后方牌照-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
    return;
}

void ResultCollection::doAnalyse_JianYanHeGeZhengMing(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if (!JianYanHeGe.b_chepai) {
        ok = false;
        dbresult = FATAL_ERROR;
        dbbhg_desc += HPHM_ERROR;
    }

    if (!JianYanHeGe.b_chejiahao) {
        ok = false;
        dbresult = FATAL_ERROR;
        dbbhg_desc += CHE_JIA_HAO_ERROR;
    }

    if (!JianYanHeGe.b_riqi) {
        ok = false;
        dbresult = FATAL_ERROR;
        dbbhg_desc += "[开具时间已过期]";
    }

    if (!JianYanHeGe.b_yinzhang) {
        ok = false;
        dbresult = FATAL_ERROR;
        dbbhg_desc += "[没有公章]";
    }

    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "机动车检验合格证明-照片:" + dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;

        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        dbbhgs++;
    }
}

void ResultCollection::doAnalyse_YingYeZhiZhao(vehicle_inf *p_vehicle_inf, int i)
{
    std::string dbbhg_desc, dbresult;

    if (!YingYeZhiZhao.b_yingyezhizhao) {
        dbresult = FATAL_ERROR;
        dbbhg_desc += "[照片不是营业执照]";
    }

    if (!YingYeZhiZhao.b_yingyezhizhao_code) {
        dbresult = FATAL_ERROR;
        dbbhg_desc += "[没有“统一社会信用代码”]";
    }

    if (!YingYeZhiZhao.b_yinzhang) {
        dbresult = FATAL_ERROR;
        dbbhg_desc += "[没有鲜章]";
    }

    if (!dbresult.empty()) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "营业执照-照片:" + dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;

        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        dbbhgs++;
    }
}

void ResultCollection::doAnalyse_YingYeZhiZhao_YiChun(vehicle_inf *p_vehicle_inf, int i)
{
    std::string dbbhg_desc, dbresult;

    if (!YingYeZhiZhao.b_yingyezhizhao) {
        dbresult = FATAL_ERROR;
        dbbhg_desc += "[照片不是营业执照]";
    }

    if (!YingYeZhiZhao.b_yinzhang) {
        dbresult = FATAL_ERROR;
        dbbhg_desc += "[没有印章]";
    }

    if (!dbresult.empty()) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "营业执照-照片:" + dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;

        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        dbbhgs++;
    }
}


void ResultCollection::doAnalyse_LuShiJiLuDan(vehicle_inf *p_vehicle_inf, int i)
{
    std::string dbbhg_desc, dbresult;

//    if (!LuShiJiLuDan.b_Jiludan) {
//        dbresult = FATAL_ERROR;
//        dbbhg_desc += "[照片不是路试记录单]";
//    }

    if (!LuShiJiLuDan.b_MA) {
        dbresult = FATAL_ERROR;
        dbbhg_desc += "[没有“CMA”印章]";
    }

    if (!LuShiJiLuDan.b_hongzhang) {
        dbresult = FATAL_ERROR;
        dbbhg_desc += "[没有检测站印章]";
    }

    if (!dbresult.empty()) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "路试记录单-照片:" + dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;

        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        dbbhgs++;
    }
}

void ResultCollection::doAnalyse_LuShiKaiShi(vehicle_inf *p_vehicle_inf, int i)
{
    std::string dbbhg_desc, dbresult;

    if (!LuShiKaiShi.b_chepai1 && !LuShiKaiShi.b_chepai2) {
        dbresult = FATAL_ERROR;
        dbbhg_desc += HPHM_ERROR;
    }

    if (!dbresult.empty()) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "路试制动开始-照片:" + dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;

        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        dbbhgs++;
    }
}

void ResultCollection::doAnalyse_LuShiJieShu(vehicle_inf *p_vehicle_inf, int i)
{
    std::string dbbhg_desc, dbresult;

    if (!LuShiJieShu.b_chepai1 && !LuShiJieShu.b_chepai2) {
        dbresult = FATAL_ERROR;
        dbbhg_desc += HPHM_ERROR;
    }

    if (!dbresult.empty()) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "路试制动结束-照片:" + dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;

        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        dbbhgs++;
    }
}

void ResultCollection:: doAnalyse_CheLiangBeiMian(vehicle_inf *p_vehicle_inf,int i)
{
    // 区分大小车接口
    if ((p_vehicle_inf->m_cllx.substr(0, 2)=="K3") || (p_vehicle_inf->m_cllx.substr(0, 2)=="K4")) { // 小车
        bool ok = true;
        std::string dbbhg_desc, dbresult;

        if (g_CheckItem.picture.CheLiangBeiMian.ChePai) {
            if (!BeiMian.b_chepai) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[车牌号不匹配]";
            }
        }

        if (g_CheckItem.picture.CheLiangBeiMian.CheBiao) {
            if (!BeiMian.b_chebiao) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[未检测到车标]";
            }
        }

        if (g_CheckItem.picture.CheLiangBeiMian.WeiDeng) {
            if (!LightBeiMian.b_car_left_light_on) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[左尾灯不亮]";
            }
            if (!LightBeiMian.b_car_right_light_on) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[右尾灯不亮]";
            }
        }

        if (!ok) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
            v_dbhhg_list.dbbhg_desc = "车辆背面-照片:";
            v_dbhhg_list.dbbhg_desc += dbbhg_desc;
            v_dbhhg_list.dbresult = dbresult;
            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }
        }
    } else { // 大车
        bool ok = true;
        std::string dbbhg_desc, dbresult;

        if (g_CheckItem.picture.CheLiangBeiMian.ChePai) {
            if (!HuoChe_ZhengHouFang.b_chepai) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[车牌号不匹配]";
            }
        }

        if (g_CheckItem.picture.CheLiangBeiMian.SanJiaoJia) {
            if (!HuoChe_ZhengHouFang.b_sanjiaojia) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[未检测到三脚架]";
            }
        }

        if (g_CheckItem.picture.CheLiangBeiMian.XiaBuFangHu) {
            if (!HuoChe_ZhengHouFang.b_rear_protect) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[后下部防护装置错误]";
            }
        }

        if (g_CheckItem.picture.CheLiangBeiMian.WeiBuBiaoZhi) {
            if (!HuoChe_ZhengHouFang.b_rear_plate) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[车辆尾部标志板错误]";
            }
        }

        if (g_CheckItem.picture.CheLiangBeiMian.CheShenFanGuangBiaoShi) {
            if (!HuoChe_ZhengHouFang.b_rear_reflect) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[后部车身反光标识错误]";
            }
        }

        if (g_CheckItem.picture.CheLiangBeiMian.PenTuHaoMa) {
            if (!HuoChe_ZhengHouFang.b_pentu_chepai) {
                ok = false;
                dbresult = FATAL_ERROR;
                dbbhg_desc += "[车厢后部喷涂或放大的号牌号码错误]";
            }
        }

        if (!ok) {
            _dbbhg_list v_dbhhg_list;
            v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
            v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
            v_dbhhg_list.dbbhg_desc = "车辆背面-照片:";
            v_dbhhg_list.dbbhg_desc += dbbhg_desc;
            v_dbhhg_list.dbresult = dbresult;
            p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
            if (v_dbhhg_list.dbresult == FATAL_ERROR) {
                dbbhgs++;
            }
        }
    } // 大车结束
}

void ResultCollection::doAnalyse_QianLunTaiHuaWen(vehicle_inf *p_vehicle_inf, int i)
{
    std::string dbbhg_desc, dbresult;

    if (!QianLunTaiHuaWen.b_luntai_huawen) {
        dbresult = FATAL_ERROR;
        dbbhg_desc += "[前轮胎花纹不一致]";
    }

    if (!dbresult.empty()) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "前轮胎-照片:" + dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;

        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        dbbhgs++;
    }
}

void ResultCollection::doAnalyse_HouLunTaiHuaWen(vehicle_inf *p_vehicle_inf, int i)
{
    std::string dbbhg_desc, dbresult;

    if (!HouLunTaiHuaWen.b_luntai_huawen) {
        dbresult = FATAL_ERROR;
        dbbhg_desc += "[后轮胎花纹不一致]";
    }

    if (!dbresult.empty()) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "后轮胎-照片:" + dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;

        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        dbbhgs++;
    }
}

void ResultCollection::doAnalyse_WaiKuoChiCunJiLuDan(vehicle_inf *p_vehicle_inf, int i)
{
    std::string dbbhg_desc, dbresult;

    if(!WaiKuoChiCunJiLuDan.b_chejiahao){
        dbresult = FATAL_ERROR;
        dbbhg_desc += CHE_JIA_HAO_ERROR;
    }

    if(!WaiKuoChiCunJiLuDan.b_chepai){
        dbresult = FATAL_ERROR;
        dbbhg_desc += HPHM_ERROR;
    }

    if(!WaiKuoChiCunJiLuDan.b_data_vaild){
        dbresult = FATAL_ERROR;
        dbbhg_desc += "[数据判定无效]";
    }

    if(!WaiKuoChiCunJiLuDan.b_jiancejieguo){
        dbresult = FATAL_ERROR;
        dbbhg_desc += "[检验结果不合格]";
    }

    if(!WaiKuoChiCunJiLuDan.b_qianzi){
        dbresult = FATAL_ERROR;
        dbbhg_desc += NO_SIGNATURE;
    }

    if(!WaiKuoChiCunJiLuDan.b_yinzhang){
        dbresult = FATAL_ERROR;
        dbbhg_desc += NO_STAMP;
    }

    if (!WaiKuoChiCunJiLuDan.b_waikuochicun) {
        dbresult = FATAL_ERROR;
        dbbhg_desc = "[照片不是外廓尺寸仪器设备记录单]";
    }

    if (!dbresult.empty()) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "外廓尺寸仪器设备记录单-照片:" + dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;

        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        dbbhgs++;
    }
}

void ResultCollection::doAnalyse_FanGuangBiaoShi(vehicle_inf *p_vehicle_inf, int i)
{
    std::string dbbhg_desc, dbresult;

    if(!FangGuangBiaoShi.b_chepai){
        dbresult = FATAL_ERROR;
        dbbhg_desc += HPHM_ERROR;
    }

    if(!FangGuangBiaoShi.b_data_tongguo){
        dbresult = FATAL_ERROR;
        dbbhg_desc += "[数据不通过]";
    }

    if(!FangGuangBiaoShi.b_fanguangbiaoshi){
        dbresult = FATAL_ERROR;
        dbbhg_desc = "[照片不是反光标识]";
    }

    if (!dbresult.empty()) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "反光标识-照片:" + dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;

        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        dbbhgs++;
    }

}

//中山里程表读数直接判定通过
void ResultCollection::doAnalyse_LiChengBiaoDuShu(vehicle_inf *p_vehicle_inf,int i)
{
    return;
}

void ResultCollection::doAnalyse_KeShiQuBoLi(vehicle_inf *p_vehicle_inf,int i)
{
    return;
}

void ResultCollection::doAnalyse_V_ZuoQianFang(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string  dbbhg_desc, dbresult;
    if (V_ZuoQianFang.b_chepai == false) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[车牌检查不通过]";
        }
    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zptype = p_vehicle_inf->m_splist[i].sptype;
        v_dbhhg_list.dbbhg_desc = "左前方-视频:";
        v_dbhhg_list.dbresult = dbresult;
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;


        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
        return;
    }

}
void ResultCollection::doAnalyse_V_YouHouFang(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;
    if (V_YouHouFang.b_chepai == false) {
        ok = false;
        dbresult = FATAL_ERROR;
        dbbhg_desc += "[车牌检查不通过]";
    }
    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zptype = p_vehicle_inf->m_splist[i].sptype;
        v_dbhhg_list.dbbhg_desc = "右后方-视频:";
        v_dbhhg_list.dbresult = dbresult;
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;


        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
        return;
    }
}
//void ResultCollection::doAnalyse_V_PingBanZhiDong(vehicle_inf *p_vehicle_inf, int i)
//{
//    bool ok = true;
//    std::string dbbhg_desc, dbresult;
//    if (g_CheckItem.video.PingBanZhiDong.ChePai)
//    {
//        if (V_ZhuCheZhiDong.b_chepai == false) {
//            ok = false;
//            dbresult = FATAL_ERROR;
//            dbbhg_desc += "[车牌检查不通过]";
//        }
//    }
//    if (g_CheckItem.video.PingBanZhiDong.PingBan)
//    {
//        if (V_ZhuCheZhiDong.b_on_plate == false) {
//            ok = false;
//            dbresult = FATAL_ERROR;
//            dbbhg_desc += "[车轮不在平板上]";
//        }
//    }
//    if (g_CheckItem.video.PingBanZhiDong.Ren)
//    {
//        if (V_ZhuCheZhiDong.b_human_clear == false)
//        {
//            ok = false;
//            dbresult = FATAL_ERROR;
//            dbbhg_desc += "[检测时有人员通过]";
//        }
//    }
//    if (g_CheckItem.video.PingBanZhiDong.WeiDeng)
//    {
//        if (V_PingBanZhiDong.b_light_up == false) {
//            ok = false;
//            dbresult = FATAL_ERROR;
//            dbbhg_desc += "[尾灯未亮起]";
//        }
//    }
//    if (!ok) {
//        _dbbhg_list v_dbhhg_list;
//        v_dbhhg_list.zptype = p_vehicle_inf->m_splist[i].sptype;
//        v_dbhhg_list.dbbhg_desc = "平板制动-视频:";
//        v_dbhhg_list.dbresult = dbresult;
//        v_dbhhg_list.dbbhg_desc += dbbhg_desc;


//        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
//        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
//            dbbhgs++;
//        }
//        return;
//    }
//}
void ResultCollection::doAnalyse_V_YiZhouZhiDong(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;
    if (g_CheckItem.video.YiZhouZhiDong.ChePai)
    {
        if (!V_YiZhouZhiDong.b_chepai) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[车牌检查不通过]";
        }
    }
    if (g_CheckItem.video.YiZhouZhiDong.QianLun)
    {
        if (!V_YiZhouZhiDong.b_yizhou) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[前轮不在检测轴上]";
        }
    }
    if (g_CheckItem.video.YiZhouZhiDong.Ren)
    {
        if (!V_YiZhouZhiDong.b_human_clear) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[检测时有人员通过]";
        }
    }
    if (g_CheckItem.video.YiZhouZhiDong.WeiDeng)
    {
        if (!V_YiZhouZhiDong.b_light) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[尾灯未亮起]";
        }
    }
    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zptype = p_vehicle_inf->m_splist[i].sptype;
        v_dbhhg_list.dbbhg_desc = "一轴制动-视频:";
        v_dbhhg_list.dbresult = dbresult;
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;


        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
        return;
    }
}
void ResultCollection::doAnalyse_V_ErZhouZhiDong(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;
    if (g_CheckItem.video.ErZhouZhiDong.ChePai)
    {
        if (!V_ErZhouZhiDong.b_chepai) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[车牌检查不通过]";
        }
    }
    if (g_CheckItem.video.ErZhouZhiDong.HouLun)
    {
        if (!V_ErZhouZhiDong.b_erzhou) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[后轮不在检测轴上]";
        }
    }
    if (g_CheckItem.video.ErZhouZhiDong.Ren)
    {
        if (!V_ErZhouZhiDong.b_human_clear) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[检测时有人员通过]";
        }
    }
    if (g_CheckItem.video.ErZhouZhiDong.WeiDeng)
    {
        if (!V_ErZhouZhiDong.b_light) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[尾灯未亮起]";
        }
    }
    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zptype = p_vehicle_inf->m_splist[i].sptype;
        v_dbhhg_list.dbbhg_desc = "二轴制动-视频:";
        v_dbhhg_list.dbresult = dbresult;
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;


        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
        return;
    }
}
void ResultCollection::doAnalyse_V_ZuoDengGuang(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;
    if (g_CheckItem.video.ZuoDengGuang.ChePai)
    {
        if (!V_ZuoDengGuang.b_chepai) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[车牌检查不通过]";
        }
    }
    if (g_CheckItem.video.ZuoDengGuang.QianDaDeng)
    {
        if (!V_ZuoDengGuang.b_light_on) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[大灯未亮起]";
        }
    }
    if (g_CheckItem.video.ZuoDengGuang.Ren)
    {
        if (!V_ZuoDengGuang.b_human_clear) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[检测时有人员通过]";
        }
    }
    if (g_CheckItem.video.ZuoDengGuang.CeShiYi)
    {
        if (!V_ZuoDengGuang.b_tester_move) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[测试仪未移动]";
        }
    }
    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zptype = p_vehicle_inf->m_splist[i].sptype;
        v_dbhhg_list.dbbhg_desc = "左灯光制动-视频:";
        v_dbhhg_list.dbresult = dbresult;
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;


        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
        return;
    }
}
void ResultCollection::doAnalyse_V_YouDengGuang(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;
    if (g_CheckItem.video.YouDengGuang.ChePai)
    {
        if (!V_YouDengGuang.b_chepai) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[车牌检查不通过]";
        }
    }
    if (g_CheckItem.video.YouDengGuang.QianDaDeng)
    {
        if (!V_YouDengGuang.b_light_on) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[大灯未亮起]";
        }
    }
    if (g_CheckItem.video.YouDengGuang.Ren)
    {
        if (!V_YouDengGuang.b_human_clear) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[检测时有人员通过]";
        }
    }
    if (g_CheckItem.video.YouDengGuang.CeShiYi)
    {
        if (!V_YouDengGuang.b_tester_move) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[测试仪未移动]";
        }
    }
    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zptype = p_vehicle_inf->m_splist[i].sptype;
        v_dbhhg_list.dbbhg_desc = "右灯光制动-视频:";
        v_dbhhg_list.dbresult = dbresult;
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;


        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
        return;
    }
}
void ResultCollection::doAnalyse_V_DiPan(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;
    if (g_CheckItem.video.DiPanGongWei.Ren)
    {
        if (!V_DiPan.b_human) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[没有检验人员通过]";
        }
    }
    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zptype = p_vehicle_inf->m_splist[i].sptype;
        v_dbhhg_list.dbbhg_desc = "底盘检验结束-视频:";
        v_dbhhg_list.dbresult = dbresult;
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;


        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
        return;
    }
}

void ResultCollection::doAnalyse_V_ZhuCheZhiDong(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;
    if (g_CheckItem.video.ZhuCheZhiDong.ChePai)
    {
        if (!V_ZhuCheZhiDong.b_chepai) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[车牌检查不通过]";
        }
    }
    if (g_CheckItem.video.ZhuCheZhiDong.HouLun)
    {
        if (!V_ZhuCheZhiDong.b_zhuche) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[车轮未在检测轴上]";
        }
    }
    if (g_CheckItem.video.ZhuCheZhiDong.Ren)
    {
        if (!V_ZhuCheZhiDong.b_human_clear) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[检测时有人员通过]";
        }
    }
    if (g_CheckItem.video.ZhuCheZhiDong.TaiQi)
    {
        if(V_ZhuCheZhiDong.b_guntong)
        {
             if (V_ZhuCheZhiDong.b_bounce_up == false) {
                 ok = false;
                 dbresult = FATAL_ERROR;
                 dbbhg_desc += "[未上抬]";
             }
        }

    }
    if (g_CheckItem.video.ZhuCheZhiDong.WeiDeng)
    {
        if(!V_ZhuCheZhiDong.b_guntong)
       {
           if (V_ZhuCheZhiDong.b_light == false) {
              ok = false;
              dbresult = FATAL_ERROR;
              dbbhg_desc += "[尾灯没有亮起]";
           }

       }

    }
    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zptype = p_vehicle_inf->m_splist[i].sptype;
        v_dbhhg_list.dbbhg_desc = "驻车制动-视频:";
        v_dbhhg_list.dbresult = dbresult;
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;


        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
        return;
    }
}

void ResultCollection::doAnalyse_V_DengGuang(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;
    if (g_CheckItem.video.YouDengGuang.ChePai  || g_CheckItem.video.ZuoDengGuang.ChePai)
    {
        if (!V_DengGuang.b_chepai) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[车牌检查不通过]";
        }
    }
    if (g_CheckItem.video.YouDengGuang.QianDaDeng || g_CheckItem.video.ZuoDengGuang.QianDaDeng)
    {
        if (!V_DengGuang.b_light_on) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[大灯未亮起]";
        }
    }
    if (g_CheckItem.video.YouDengGuang.Ren  || g_CheckItem.video.ZuoDengGuang.Ren)
    {
        if (!V_DengGuang.b_human_clear) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[检测时有人员通过]";
        }
    }
    if (g_CheckItem.video.YouDengGuang.CeShiYi  || g_CheckItem.video.ZuoDengGuang.CeShiYi)
    {
        if (!V_DengGuang.b_tester_move) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[测试仪未移动]";
        }
    }
    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zptype = p_vehicle_inf->m_splist[i].sptype;
        v_dbhhg_list.dbbhg_desc = "灯光制动-视频:";
        v_dbhhg_list.dbresult = dbresult;
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;


        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
        return;
    }
}

void ResultCollection::doAnalyse_V_DiPanDongTai(vehicle_inf *p_vehicle_inf, int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;
    if (g_CheckItem.video.DongTaiGongWei_1.ChePai || g_CheckItem.video.DongTaiGongWei_2.ChePai)
    {
        if (!V_DiPanDongTai.b_chepai) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[车牌检查不通过]";
        }
    }
    if (g_CheckItem.video.DongTaiGongWei_1.WeiYi  || g_CheckItem.video.DongTaiGongWei_1.WeiYi)
    {
        if (!V_DiPanDongTai.b_move) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[未移动]";
        }
    }
    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zptype = p_vehicle_inf->m_splist[i].sptype;
        v_dbhhg_list.dbbhg_desc = "底盘动态-视频:";
        v_dbhhg_list.dbresult = dbresult;
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;


        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
        return;
    }
}
//void ResultCollection::doAnalyse_V_GunLunZhuChe(vehicle_inf *p_vehicle_inf, int i)
//{
//    bool ok = true;
//    std::string dbbhg_desc, dbresult;
//    if (g_CheckItem.video.ZhuCheZhiDong_GunTong.ChePai)
//    {
//        if (V_ZhuCheZhiDong.b_chepai == false) {
//            ok = false;
//            dbresult = FATAL_ERROR;
//            dbbhg_desc += "[车牌检查不通过]";
//        }
//    }
//    if (g_CheckItem.video.ZhuCheZhiDong_GunTong.HouLun)
//    {
//        if (V_ZhuCheZhiDong.b_roller_on == false) {
//            ok = false;
//            dbresult = FATAL_ERROR;
//            dbbhg_desc += "[车轮未在检测轴上]";
//        }
//    }
//    if (g_CheckItem.video.ZhuCheZhiDong_GunTong.Ren)
//    {
//        if (V_ZhuCheZhiDong.b_human_clear == false) {
//            ok = false;
//            dbresult = FATAL_ERROR;
//            dbbhg_desc += "[检测时有人员通过]";
//        }
//    }
//    if (g_CheckItem.video.ZhuCheZhiDong_GunTong.TaiQi)
//    {
//        if (V_ZhuCheZhiDong.b_bounce_up == false) {
//            ok = false;
//            dbresult = FATAL_ERROR;
//            dbbhg_desc += "[未检测到车体制动]";
//        }
//    }
//    if (!ok) {
//        _dbbhg_list v_dbhhg_list;
//        v_dbhhg_list.zptype = p_vehicle_inf->m_splist[i].sptype;
//        v_dbhhg_list.dbbhg_desc = "右灯光制动-视频:";
//        v_dbhhg_list.dbresult = dbresult;
//        v_dbhhg_list.dbbhg_desc += dbbhg_desc;


//        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
//        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
//            dbbhgs++;
//        }
//        return;
//    }
//}
//void ResultCollection::doAnalyse_V_PingBanZhuChe(vehicle_inf *p_vehicle_inf, int i)
//{
//    bool ok = true;
//    std::string dbbhg_desc, dbresult;
//    if (g_CheckItem.video.ZhuCheZhiDong_PingBan.ChePai)
//    {
//        if (V_PingBanZhuChe.b_chepai == false) {
//            ok = false;
//            dbresult = FATAL_ERROR;
//            dbbhg_desc += "[车牌检查不通过]";
//        }
//    }
//    if (g_CheckItem.video.ZhuCheZhiDong_PingBan.WeiDeng)
//    {
//        if (V_PingBanZhuChe.b_light_on == false) {
//            ok = false;
//            dbresult = FATAL_ERROR;
//            dbbhg_desc += "[尾灯未亮起]";
//        }
//    }
//    if (g_CheckItem.video.ZhuCheZhiDong_PingBan.Ren)
//    {
//        if (V_PingBanZhuChe.b_human_clear == false) {
//            ok = false;
//            dbresult = FATAL_ERROR;
//            dbbhg_desc += "[检测时有人员通过]";
//        }
//    }
//    if (g_CheckItem.video.ZhuCheZhiDong_PingBan.CheLun)
//    {
//        if (V_PingBanZhuChe.b_on_plate == false) {
//            ok = false;
//            dbresult = FATAL_ERROR;
//            dbbhg_desc += "[车轮未在平板上]";
//        }
//    }
//    if (!ok) {
//        _dbbhg_list v_dbhhg_list;
//        v_dbhhg_list.zptype = p_vehicle_inf->m_splist[i].sptype;
//        v_dbhhg_list.dbbhg_desc = "右灯光制动-视频:";
//        v_dbhhg_list.dbresult = dbresult;
//        v_dbhhg_list.dbbhg_desc += dbbhg_desc;


//        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
//        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
//            dbbhgs++;
//        }
//        return;
//    }
//}

/*
支持的时间格式：
20091023
2009X10X23
2009X10X23 12:23:56
X表示任何ASCII字符
不能处理包含一位数的日期（比如2017-9-8），不会进行补0
*/
bool ResultCollection::compareDate(std::string kssj, std::string PictureDate)
{
    if (kssj == "无数据") {
        return true;
    }

    if ((kssj.length() < 8) || (PictureDate.length() < 8)) {
        return true;
    }

    /* 取出"开始时间"有效日期字段 */
    unsigned int count = 0;
    char tmp1[8] = { 0 };
    for (unsigned int i = 0; i < kssj.length(); i++) {
        if ((kssj[i] >= '0') && (kssj[i] <= '9')) {
            tmp1[count] = kssj[i];
            count++;

            if (count == 8) {
                break;
            }
        }
    }

    /* 未能获取完整日期信息 */
    if (count != 8) {
        return true;
    }

    /* 取出"照片日期"有效日期字段 */
    count = 0;
    char tmp2[8] = { 0 };
    for (unsigned int i = 0; i < PictureDate.length(); i++) {
        if ((PictureDate[i] >= '0') && (PictureDate[i] <= '9')) {
            tmp2[count] = PictureDate[i];
            count++;

            if (count == 8) {
                break;
            }
        }
    }

    /* 未能获取完整日期信息 */
    if (count != 8) {
        return true;
    }

    for (unsigned int i = 0; i < 8; i++) {
        if (tmp1[i] != tmp2[i]) {
            return false;
        }
    }

    return true;
}

void ResultCollection::doAnalyse_QianHaoPaiTeXie(vehicle_inf *p_vehicle_inf,int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if (g_CheckItem.picture.QianHaoPaiTeXie.chepai) {
        if (!QianHaoPaiTeXie.b_chepai) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[车牌不存在]";
        }
    }
    if (g_CheckItem.picture.QianHaoPaiTeXie.luosi) {
        if (!QianHaoPaiTeXie.b_chepailuosi) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[螺丝不合格]";
        }
    }


    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "前号牌特写-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
    return;
}

void ResultCollection::doAnalyse_HouHaoPaiTeXie(vehicle_inf *p_vehicle_inf,int i)
{
    bool ok = true;
    std::string dbbhg_desc, dbresult;

    if (g_CheckItem.picture.HouHaoPaiTeXie.chepai) {
        if (!HouHaoPaiTeXie.b_chepai) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[车牌不存在]";
        }
    }
    if (g_CheckItem.picture.HouHaoPaiTeXie.luosi) {
        if (!HouHaoPaiTeXie.b_chepailuosi) {
            ok = false;
            dbresult = FATAL_ERROR;
            dbbhg_desc += "[螺丝不合格]";
        }
    }


    if (!ok) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = "后号牌特写-照片:";
        v_dbhhg_list.dbbhg_desc += dbbhg_desc;
        v_dbhhg_list.dbresult = dbresult;
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
        if (v_dbhhg_list.dbresult == FATAL_ERROR) {
            dbbhgs++;
        }
    }
    return;
}

/**
    @name:	 ResultCollection::formatingDate
    @brief:  对日期字符串进行格式化处理，转换为20170923这样的格式。
    @param:  date--需要转换的日期字符串
    @return: 非""--转换完成的字符串
             ""--转换失败
    @others: 支持的时间格式：
             20091023
             2009X10X23
             2009X10X23 12:23:56
             X表示任何ASCII字符

             不能处理包含一位数的日期（比如2017-9-8），不会进行补0
    @see:
*/
std::string ResultCollection::formatingDate(std::string date,unsigned int index)
{
    if (date == "无数据") {
        return std::string("");
    }

    if (date.length() < 8) {
        return std::string("");
    }

    unsigned int count = 0;
    char tmp1[16] = { 0 };
    for (unsigned int i = 0; i < date.length(); i++) {
        if ((date[i] >= '0') && (date[i] <= '9')) {

            tmp1[count] = date[i];
            count++;
            if( index == 0 && count == 8)
            {
                break;
            }
            if( index == 1 && count == 15)
            {
                break;
            }
            else if(index == 1 && count == 8)
            {
                tmp1[count] = '_';
                count++;
            }
        }
    }

    if (count == 8 || count == 15) {
        return std::string(tmp1);
    } else {
        return std::string("");
    }
}


std::string ResultCollection::formatingTime(std::string date)
{
    if (date == "无数据") {
        return std::string("");
    }

    if (date.length() < 8) {
        return std::string("");
    }

    if (date.length() < 14) {
        return std::string("");
    }

    unsigned int count = 0;
    char tmp1[7] = { 0 };
    for (unsigned int i = 11; i < date.length(); i++) {

        if ((date[i] >= '0') && (date[i] <= '9')) {
            count++;
            tmp1[count-1] = date[i];
            if (count==6) {
                break;
            }
        }
    }

    if (count == 6) {
        return std::string(tmp1);
    } else {
        return std::string("");
    }
}

/**
    @name:	 ResultCollection::isTenYears
    @brief:  判定该车是否10年以上车型。
    @param:  p_vehicle_inf--车检信息结构体
    @return: true--是10年以上车型
             false--不是10年以上车型
    @others: 利用字段“初次登记日期”和系统当前时间作判定，精确到天。
    @see:
*/
bool ResultCollection::isTenYears(const vehicle_inf *p_vehicle_inf)
{
    std::string tmp2 = p_vehicle_inf->m_ccdjrq;
    std::string djrq = formatingDate(tmp2);
    if (djrq == "") {	/* 未能获取“初次登记日期” */
        return false;
    }

    int djrq_year = std::stoi(djrq.substr(0, 4));
    int djrq_month = std::stoi(djrq.substr(4, 2));
    int djrq_day = std::stoi(djrq.substr(6, 2));

    std::time_t t = std::time(NULL);
    std::tm *st = std::localtime(&t);

    /* 先判断年，年相同的情况下，判断月；月相同的情况下，判断日 */
    if ((st->tm_year + 1900 - djrq_year) > 10) {
        return true;
    } else if ((st->tm_mon + 1 - djrq_year) < 10) {
        return false;
    } else if ((st->tm_year + 1900 - djrq_year) == 10) {
        if ((st->tm_mon + 1- djrq_month) > 0) {
            return true;
        } else if ((st->tm_mon + 1- djrq_month) < 0) {
            return false;
        } else if ((st->tm_mon + 1 - djrq_month) == 0) {
            if ((st->tm_mday - djrq_day) > 0) {
                return true;
            } else if ((st->tm_mday- djrq_day) < 0) {
                return false;
            } else if ((st->tm_mday - djrq_day) == 0) {
                return true;	/* 当天刚好10年也算10年以上车型 */
            }
        }
    }
}
bool ResultCollection::isYingYun(const vehicle_inf *p_vehicle_inf)
{
    if(p_vehicle_inf->m_syxz !="A")
    {
        return false;
    }
    return true;

}
void ResultCollection::NoAnalyse_RenGong(vehicle_inf *p_vehicle_inf, std::string reason)
{
    unsigned int i;

    for (i = 0; i < p_vehicle_inf->m_zplist.size(); i++) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zpid = p_vehicle_inf->m_zplist[i].zpid;
        v_dbhhg_list.zptype = p_vehicle_inf->m_zplist[i].zptype;
        v_dbhhg_list.dbbhg_desc = reason;
        v_dbhhg_list.dbresult = "4";
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
    }

    for (i = 0; i < p_vehicle_inf->m_splist.size(); i++) {
        _dbbhg_list v_dbhhg_list;
        v_dbhhg_list.zptype = p_vehicle_inf->m_splist[i].sptype;
        v_dbhhg_list.dbbhg_desc = reason;
        v_dbhhg_list.dbresult = "4";
        p_vehicle_inf->m_dbbhglist.push_back(v_dbhhg_list);
    }
}

/*
    判定手机号合法依据：

    1. 手机号前3位是移动、联通、电信、虚拟运营商已开放的号段

    2. 手机号必须是11位数字

*/
int ResultCollection::isMobileNumber(std::string number)
{
    if (number.length() == 0) {
        return -1;
    }

    if (number.length() == 8) {
        return 1;   /* 8位直接按固定电话处理，不做其他判定 */
    }

    if (number.length() != 11) {
        return 0;
    }

    for (unsigned int i = 0; i < number.length(); i++) {
        if ((number[i] < '0') || (number[i] > '9')) {
            return 0;
        }
    }

    /*
        以下手机号段取自百度百科“手机号码”（更新时间：2019-09-06）
    */
    std::vector<std::string> YiDong = { "134", "135", "136", "137", "138", "139", "147", "150",
                                        "151", "152", "157", "158", "159", "172", "178", "182", "183", "184", "187", "188", "198" };
    std::vector<std::string> LianTong = { "130", "131", "132", "155", "156", "145", "175", "176", "185", "186", "166", "171" };
    std::vector<std::string> DianXin = { "133", "149", "153", "173", "177", "180", "181", "189", "191", "199", "193" };
    std::vector<std::string> XuNiYunYingShang = {"170", "162", "165"};

    std::string str_number_head(number.substr(0, 3));
    unsigned int i;
    for (i = 0; i < YiDong.size(); i++) {
        if (str_number_head == YiDong[i]) {
            break;
        }
    }

    if (i < YiDong.size()) {
        return 1;
    }

    for (i = 0; i < LianTong.size(); i++) {
        if (str_number_head == LianTong[i]) {
            break;
        }
    }

    if (i < LianTong.size()) {
        return 1;
    }

    for (i = 0; i < DianXin.size(); i++) {
        if (str_number_head == DianXin[i]) {
            break;
        }
    }

    if (i < DianXin.size()) {
        return 1;
    }

    for(i = 0; i < XuNiYunYingShang.size(); i++){
        if(str_number_head == XuNiYunYingShang[i]){
            break;
        }
    }
    if(i < XuNiYunYingShang.size()) {
        return 1;
    }
    return 0;
}

bool ResultCollection::BaoDanRiQi(const vehicle_inf *p_vehicle_inf)
{
    std::string sxrq = formatingDate(p_vehicle_inf->m_sxrq);
    std::string zzrq = formatingDate(p_vehicle_inf->m_zzrq);

    std::string kssj = formatingDate(p_vehicle_inf->m_kssj);
    std::string jssj = formatingDate(p_vehicle_inf->m_jssj);

    if (sxrq.empty() || zzrq.empty() || kssj.empty() || jssj.empty()) {	/* 缺失任何一个日期，都无法判断保单日期 */
        return false;
    }

    try {
        int n_sxrq = std::stoi(sxrq);
        int n_zzrq = std::stoi(zzrq);
        int n_kssj = std::stoi(kssj);
        int n_jssj = std::stoi(jssj);

        return ((n_sxrq <= n_kssj) && (n_zzrq >= n_jssj));
    } catch (const std::exception &e) {
        DATA_PRINT(LEVEL_ERROR, "Exception! std::stoi() \n");
        DATA_PRINT(LEVEL_ERROR, "Exception cause: %s \n", e.what());
        return false;
    }
}

void ResultCollection::initLogoList()
{
    VehicleLogo logo;

    logo.name_CHS = "美星华通", logo.name_ENG = "GMC";
    logo.TypeList.clear();
    logo_list.push_back(logo);

    logo.name_CHS = "", logo.name_ENG = "SMART";
    logo.TypeList.clear();
    logo_list.push_back(logo);

    logo.name_CHS = "豪沃"; logo.name_ENG = "HOWO";
    logo.TypeList.clear();
    logo_list.push_back(logo);

    logo.name_CHS = "豪瀚"; logo.name_ENG = "";
    logo.TypeList.clear();
    logo_list.push_back(logo);

    logo.name_CHS = "北汽幻速"; logo.name_ENG = "";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("北京", ""));
    logo.TypeList.push_back(VehicleType("北汽", ""));
    logo.TypeList.push_back(VehicleType("", "S7"));
    logo.TypeList.push_back(VehicleType("", "S3"));
    logo.TypeList.push_back(VehicleType("", "S5"));
    logo.TypeList.push_back(VehicleType("", "S6"));
    logo.TypeList.push_back(VehicleType("", "H2"));
    logo.TypeList.push_back(VehicleType("", "H6"));
    logo.TypeList.push_back(VehicleType("", "H3"));
    logo.TypeList.push_back(VehicleType("", "S2"));
    logo.TypeList.push_back(VehicleType("", "H5"));
    logo_list.push_back(logo);

    logo.name_CHS = "捷豹"; logo.name_ENG = "Jaguar";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "E-PACE"));
    logo.TypeList.push_back(VehicleType("", "XEL"));
    logo.TypeList.push_back(VehicleType("", "XFL"));
    logo.TypeList.push_back(VehicleType("", "F-PACE"));
    logo.TypeList.push_back(VehicleType("", "XE"));
    logo.TypeList.push_back(VehicleType("", "XF"));
    logo.TypeList.push_back(VehicleType("", "XJ"));
    logo.TypeList.push_back(VehicleType("", "F-TYPE"));
    logo.TypeList.push_back(VehicleType("", "I-PACE"));
    logo.TypeList.push_back(VehicleType("", "S-TYPE"));
    logo.TypeList.push_back(VehicleType("", "XK"));
    logo_list.push_back(logo);

    logo.name_CHS = "大发"; logo.name_ENG = "";
    logo.TypeList.clear();
    logo_list.push_back(logo);

    logo.name_CHS = "中通"; logo.name_ENG = "";
    logo.TypeList.clear();
    logo_list.push_back(logo);

    logo.name_CHS = "北汽威旺"; logo.name_ENG = "";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "M20"));
    logo.TypeList.push_back(VehicleType("", "M50F"));
    logo.TypeList.push_back(VehicleType("", "M30"));
    logo.TypeList.push_back(VehicleType("", "M60"));
    logo.TypeList.push_back(VehicleType("", "S50"));
    logo.TypeList.push_back(VehicleType("306", ""));
    logo.TypeList.push_back(VehicleType("307", ""));
    logo.TypeList.push_back(VehicleType("205", ""));
    logo.TypeList.push_back(VehicleType("", "M35"));
    logo.TypeList.push_back(VehicleType("北京", ""));
    logo.TypeList.push_back(VehicleType("北汽", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "黑豹"; logo.name_ENG = "";
    logo.TypeList.clear();
    logo_list.push_back(logo);

    logo.name_CHS = "奥迪", logo.name_ENG = "Audi";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "A1"));
    logo.TypeList.push_back(VehicleType("", "A3"));
    logo.TypeList.push_back(VehicleType("", "A4"));
    logo.TypeList.push_back(VehicleType("", "A5"));
    logo.TypeList.push_back(VehicleType("", "A6"));
    logo.TypeList.push_back(VehicleType("", "A7"));
    logo.TypeList.push_back(VehicleType("", "A8"));
    logo.TypeList.push_back(VehicleType("", "Q1"));
    logo.TypeList.push_back(VehicleType("", "Q2"));
    logo.TypeList.push_back(VehicleType("", "Q3"));
    logo.TypeList.push_back(VehicleType("", "Q5"));
    logo.TypeList.push_back(VehicleType("", "Q7"));
    logo.TypeList.push_back(VehicleType("", "TT"));
    logo.TypeList.push_back(VehicleType("", "TTS"));
    logo.TypeList.push_back(VehicleType("", "TTRS"));
    logo.TypeList.push_back(VehicleType("", "R8"));
    logo.TypeList.push_back(VehicleType("", "S3"));
    logo.TypeList.push_back(VehicleType("", "S4"));
    logo.TypeList.push_back(VehicleType("", "S5"));
    logo.TypeList.push_back(VehicleType("", "S6"));
    logo.TypeList.push_back(VehicleType("", "S7"));
    logo.TypeList.push_back(VehicleType("", "S8"));
    logo.TypeList.push_back(VehicleType("", "RS3"));
    logo.TypeList.push_back(VehicleType("", "RS6"));
    logo.TypeList.push_back(VehicleType("", "RS7"));
    logo.TypeList.push_back(VehicleType("", "SQ5"));
    logo_list.push_back(logo);

    logo.name_CHS = "奥斯莫比尔", logo.name_ENG = "Oldsmobile";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("奥兹莫比尔", "")); /* 车标别名，不是车型 */
    logo.TypeList.push_back(VehicleType("阿莱罗", "Alero"));
    logo.TypeList.push_back(VehicleType("曙光", "Aurora"));
    logo.TypeList.push_back(VehicleType("短剑", "Cutlass"));
    logo.TypeList.push_back(VehicleType("激情", "Intrigue"));
    logo.TypeList.push_back(VehicleType("88", "Eightyeight"));
    logo.TypeList.push_back(VehicleType("摄政王", "Regency"));
    logo.TypeList.push_back(VehicleType("剪影厢体车", "Silhouette"));
    logo_list.push_back(logo);

    logo.name_CHS = "保时捷", logo.name_ENG = "Porsche";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "911"));
    logo.TypeList.push_back(VehicleType("", "Cayenne"));
    logo.TypeList.push_back(VehicleType("", "Panamera"));
    logo.TypeList.push_back(VehicleType("", "Macan"));
    logo.TypeList.push_back(VehicleType("", "718"));
    logo_list.push_back(logo);

    logo.name_CHS = "宝骏", logo.name_ENG = "";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "730"));
    logo.TypeList.push_back(VehicleType("", "560"));
    logo.TypeList.push_back(VehicleType("", "310"));
    logo.TypeList.push_back(VehicleType("", "510"));
    logo.TypeList.push_back(VehicleType("", "530"));
    logo.TypeList.push_back(VehicleType("", "360"));
    logo.TypeList.push_back(VehicleType("", "100"));
    logo.TypeList.push_back(VehicleType("", "200"));
    logo_list.push_back(logo);

    logo.name_CHS = "宝马", logo.name_ENG = "BMW";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("1系", ""));
    logo.TypeList.push_back(VehicleType("2系", ""));
    logo.TypeList.push_back(VehicleType("3系", ""));
    logo.TypeList.push_back(VehicleType("4系", ""));
    logo.TypeList.push_back(VehicleType("5系", ""));
    logo.TypeList.push_back(VehicleType("6系", ""));
    logo.TypeList.push_back(VehicleType("7系", ""));
    logo.TypeList.push_back(VehicleType("", "X1"));
    logo.TypeList.push_back(VehicleType("", "X3"));
    logo.TypeList.push_back(VehicleType("", "X4"));
    logo.TypeList.push_back(VehicleType("", "X5"));
    logo.TypeList.push_back(VehicleType("", "X6"));
    logo.TypeList.push_back(VehicleType("", "i3"));
    logo.TypeList.push_back(VehicleType("", "i8"));
    logo.TypeList.push_back(VehicleType("", "M3"));
    logo.TypeList.push_back(VehicleType("", "M2"));
    logo.TypeList.push_back(VehicleType("", "M4"));
    logo.TypeList.push_back(VehicleType("", "M5"));
    logo.TypeList.push_back(VehicleType("", "M6"));
    logo_list.push_back(logo);

    logo.name_CHS = "北京", logo.name_ENG = "";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("北京汽车", "")); /* 车标别名，不是车型 */
    logo.TypeList.push_back(VehicleType("", "BJ20"));
    logo.TypeList.push_back(VehicleType("", "BJ40"));
    logo.TypeList.push_back(VehicleType("", "BJ80"));
    logo_list.push_back(logo);

    logo.name_CHS = "北京现代", logo.name_ENG = "HYUNDAI";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("现代", "")); /* 车标别名，不是车型 */
    logo.TypeList.push_back(VehicleType("途胜", ""));
    logo.TypeList.push_back(VehicleType("悦动", ""));
    logo.TypeList.push_back(VehicleType("", "ix25"));
    logo.TypeList.push_back(VehicleType("", "ix35"));
    logo.TypeList.push_back(VehicleType("飞思", ""));
    logo.TypeList.push_back(VehicleType("辉翼", ""));
    logo.TypeList.push_back(VehicleType("瑞纳", "VERNA"));
    logo.TypeList.push_back(VehicleType("朗动", ""));
    logo.TypeList.push_back(VehicleType("全新胜达", ""));
    logo.TypeList.push_back(VehicleType("名图", "MISTRA"));
    logo.TypeList.push_back(VehicleType("瑞奕", ""));
    logo.TypeList.push_back(VehicleType("捷恩斯", ""));
    logo.TypeList.push_back(VehicleType("伊兰特", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "奔驰", logo.name_ENG = "Mercedes-Benz";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("A级", ""));
    logo.TypeList.push_back(VehicleType("B级", ""));
    logo.TypeList.push_back(VehicleType("C级", ""));
    logo.TypeList.push_back(VehicleType("CL级", ""));
    logo.TypeList.push_back(VehicleType("CLK级", ""));
    logo.TypeList.push_back(VehicleType("CLS级", ""));
    logo.TypeList.push_back(VehicleType("E级", ""));
    logo.TypeList.push_back(VehicleType("S级", ""));
    logo.TypeList.push_back(VehicleType("SL级", ""));
    logo.TypeList.push_back(VehicleType("SLC级", ""));
    logo.TypeList.push_back(VehicleType("SLK级", ""));
    logo.TypeList.push_back(VehicleType("SLR级", ""));
    logo.TypeList.push_back(VehicleType("G级", ""));
    logo.TypeList.push_back(VehicleType("GLK级", ""));
    logo.TypeList.push_back(VehicleType("M级", ""));
    logo.TypeList.push_back(VehicleType("R级", ""));
    logo.TypeList.push_back(VehicleType("AMG车系", ""));
    logo.TypeList.push_back(VehicleType("威霆", "Vito"));
    logo.TypeList.push_back(VehicleType("威雷", "Vario"));
    logo.TypeList.push_back(VehicleType("凌特", "Sprinter"));
    logo.TypeList.push_back(VehicleType("", "Travego"));
    logo.TypeList.push_back(VehicleType("", "Tourismo"));
    logo.TypeList.push_back(VehicleType("", "Travego"));
    logo.TypeList.push_back(VehicleType("", "Tourino"));
    logo.TypeList.push_back(VehicleType("豪华商用车（MPV）", "Minibus"));
    logo.TypeList.push_back(VehicleType("唯雅诺", "Viano"));
    logo.TypeList.push_back(VehicleType("梅赛德斯", "Mercedes"));
    logo_list.push_back(logo);

    logo.name_CHS = "本田", logo.name_ENG = "hongda";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("奥德赛", ""));
    logo.TypeList.push_back(VehicleType("缤智", ""));
    logo.TypeList.push_back(VehicleType("飞度", ""));
    logo.TypeList.push_back(VehicleType("锋范", ""));
    logo.TypeList.push_back(VehicleType("冠道", ""));
    logo.TypeList.push_back(VehicleType("歌诗图", ""));
    logo.TypeList.push_back(VehicleType("凌派", ""));
    logo.TypeList.push_back(VehicleType("雅阁", ""));
    logo.TypeList.push_back(VehicleType("雅阁锐·混动", ""));
    logo.TypeList.push_back(VehicleType("", "CR-Z"));
    logo.TypeList.push_back(VehicleType("", "Insight"));
    logo.TypeList.push_back(VehicleType("飞度", ""));
    logo.TypeList.push_back(VehicleType("艾力绅", ""));
    logo.TypeList.push_back(VehicleType("CR-V锐·混动", ""));
    logo.TypeList.push_back(VehicleType("", "UR-V"));
    logo.TypeList.push_back(VehicleType("", "XR-V"));
    logo.TypeList.push_back(VehicleType("缤智", ""));
    logo.TypeList.push_back(VehicleType("飞度", ""));
    logo.TypeList.push_back(VehicleType("锋范", ""));
    logo.TypeList.push_back(VehicleType("冠道", ""));
    logo.TypeList.push_back(VehicleType("歌诗图", ""));
    logo.TypeList.push_back(VehicleType("凌派", ""));
    logo.TypeList.push_back(VehicleType("雅阁", ""));
    logo.TypeList.push_back(VehicleType("雅阁锐·混动", ""));
    logo.TypeList.push_back(VehicleType("", "CR-Z"));
    logo.TypeList.push_back(VehicleType("", "Insight"));
    logo.TypeList.push_back(VehicleType("飞度", ""));
    logo.TypeList.push_back(VehicleType("艾力绅", ""));
    logo.TypeList.push_back(VehicleType("CR-V锐·混动", ""));
    logo.TypeList.push_back(VehicleType("哥瑞", ""));
    logo.TypeList.push_back(VehicleType("INSPIRE锐·混动", ""));
    logo.TypeList.push_back(VehicleType("杰德", ""));
    logo.TypeList.push_back(VehicleType("竞瑞", ""));
    logo.TypeList.push_back(VehicleType("思铂睿", ""));
    logo.TypeList.push_back(VehicleType("思铂睿锐·混动", ""));
    logo.TypeList.push_back(VehicleType("思域", ""));
    logo.TypeList.push_back(VehicleType("思域新能源", ""));
    logo.TypeList.push_back(VehicleType("时韵", ""));
    logo.TypeList.push_back(VehicleType("炫威", ""));
    logo.TypeList.push_back(VehicleType("思威", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "比亚迪", logo.name_ENG = "BYD";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "e6"));
    logo.TypeList.push_back(VehicleType("秦", ""));
    logo.TypeList.push_back(VehicleType("王朝概念车", ""));
    logo.TypeList.push_back(VehicleType("唐", ""));
    logo.TypeList.push_back(VehicleType("", "F0"));
    logo.TypeList.push_back(VehicleType("", "F3"));
    logo.TypeList.push_back(VehicleType("速锐", ""));
    logo.TypeList.push_back(VehicleType("元EV", ""));
    logo.TypeList.push_back(VehicleType("", "G5"));
    logo.TypeList.push_back(VehicleType("秦Pro", ""));
    logo.TypeList.push_back(VehicleType("宋", ""));
    logo.TypeList.push_back(VehicleType("宋MAX", ""));
    logo.TypeList.push_back(VehicleType("", "S7"));
    logo.TypeList.push_back(VehicleType("", "M6"));
    logo.TypeList.push_back(VehicleType("秦Pro DM", ""));
    logo.TypeList.push_back(VehicleType("", "G6"));
    logo.TypeList.push_back(VehicleType("秦Pro EV", ""));
    logo.TypeList.push_back(VehicleType("宋DM", ""));
    logo.TypeList.push_back(VehicleType("宋EV", ""));
    logo.TypeList.push_back(VehicleType("秦100", ""));
    logo.TypeList.push_back(VehicleType("", "e5"));
    logo.TypeList.push_back(VehicleType("唐DM", ""));
    logo.TypeList.push_back(VehicleType("秦EV", ""));
    logo.TypeList.push_back(VehicleType("唐100", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "标致", logo.name_ENG = "PEUGEOT";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("207三厢", ""));
    logo.TypeList.push_back(VehicleType("206", ""));
    logo.TypeList.push_back(VehicleType("207两厢", ""));
    logo.TypeList.push_back(VehicleType("307三厢", ""));
    logo.TypeList.push_back(VehicleType("408", ""));
    logo.TypeList.push_back(VehicleType("308", ""));
    logo.TypeList.push_back(VehicleType("307两厢", ""));
    logo.TypeList.push_back(VehicleType("301", ""));
    logo.TypeList.push_back(VehicleType("308S", ""));
    logo.TypeList.push_back(VehicleType("407", ""));
    logo.TypeList.push_back(VehicleType("508", ""));
    logo.TypeList.push_back(VehicleType("607", ""));
    logo.TypeList.push_back(VehicleType("3008", ""));
    logo.TypeList.push_back(VehicleType("2008", ""));
    logo.TypeList.push_back(VehicleType("4008", ""));
    logo.TypeList.push_back(VehicleType("5008", ""));
    logo.TypeList.push_back(VehicleType("207CC", ""));
    logo.TypeList.push_back(VehicleType("307CC", ""));
    logo.TypeList.push_back(VehicleType("308CC", ""));
    logo.TypeList.push_back(VehicleType("206", ""));
    logo.TypeList.push_back(VehicleType("", "RCZ"));
    logo.TypeList.push_back(VehicleType("308SW", ""));
    logo.TypeList.push_back(VehicleType("407SW", ""));
    logo.TypeList.push_back(VehicleType("307SW", ""));
    logo.TypeList.push_back(VehicleType("107", ""));
    logo.TypeList.push_back(VehicleType("108", ""));
    logo.TypeList.push_back(VehicleType("2008", ""));
    logo.TypeList.push_back(VehicleType("208", ""));
    logo.TypeList.push_back(VehicleType("208GTI", ""));
    logo.TypeList.push_back(VehicleType("301", ""));
    logo.TypeList.push_back(VehicleType("308", ""));
    logo.TypeList.push_back(VehicleType("308GTi", ""));
    logo.TypeList.push_back(VehicleType("308R", ""));
    logo.TypeList.push_back(VehicleType("403", ""));
    logo.TypeList.push_back(VehicleType("404", ""));
    logo.TypeList.push_back(VehicleType("406", ""));
    logo.TypeList.push_back(VehicleType("5008 MPV", ""));
    logo.TypeList.push_back(VehicleType("508", ""));
    logo.TypeList.push_back(VehicleType("508RXH", ""));
    logo.TypeList.push_back(VehicleType("807", ""));
    logo.TypeList.push_back(VehicleType("", "EX1"));
    logo.TypeList.push_back(VehicleType("", "Fractal"));
    logo.TypeList.push_back(VehicleType("", "HR1"));
    logo.TypeList.push_back(VehicleType("", "iOn"));
    logo.TypeList.push_back(VehicleType("", "Onyx"));
    logo.TypeList.push_back(VehicleType("", "SXC"));
    logo.TypeList.push_back(VehicleType("5008", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "别克", logo.name_ENG = "Buick";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("昂科拉", "Encore"));
    logo.TypeList.push_back(VehicleType("昂科雷", "Enclave"));
    logo.TypeList.push_back(VehicleType("荣御", "Royaum"));
    logo.TypeList.push_back(VehicleType("君威", "Regal"));
    logo.TypeList.push_back(VehicleType("君越", "Larcosse"));
    logo.TypeList.push_back(VehicleType("凯越", "Excelle"));
    logo.TypeList.push_back(VehicleType("英朗", "Excelle GT;Excelle XT"));
    logo.TypeList.push_back(VehicleType("林荫大道", "Park Avenue"));
    logo.TypeList.push_back(VehicleType("", "BUICK"));
    logo_list.push_back(logo);

    logo.name_CHS = "宾利", logo.name_ENG = "bentley";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("雅致", ""));
    logo.TypeList.push_back(VehicleType("慕尚", ""));
    logo.TypeList.push_back(VehicleType("飞驰", ""));
    logo.TypeList.push_back(VehicleType("添越", ""));
    logo.TypeList.push_back(VehicleType("欧陆", ""));
    logo.TypeList.push_back(VehicleType("雅骏", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "昌河", logo.name_ENG = "Changhe";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("爱迪尔", ""));
    logo.TypeList.push_back(VehicleType("北斗星E", ""));
    logo.TypeList.push_back(VehicleType("北斗星X5E", ""));
    logo.TypeList.push_back(VehicleType("北斗星", ""));
    logo.TypeList.push_back(VehicleType("", "M50"));
    logo.TypeList.push_back(VehicleType("", "Q35"));
    logo.TypeList.push_back(VehicleType("福运", ""));
    logo.TypeList.push_back(VehicleType("海豚", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "长安", logo.name_ENG = "CHANA";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("奔奔", ""));
    logo.TypeList.push_back(VehicleType("奔奔EV", ""));
    logo.TypeList.push_back(VehicleType("奔奔i", ""));
    logo.TypeList.push_back(VehicleType("", "CS15"));
    logo.TypeList.push_back(VehicleType("", "CS35"));
    logo.TypeList.push_back(VehicleType("", "CS55"));
    logo.TypeList.push_back(VehicleType("", "CS75"));
    logo.TypeList.push_back(VehicleType("", "CS95"));
    logo.TypeList.push_back(VehicleType("", "CX30"));
    logo.TypeList.push_back(VehicleType("凌轩", ""));
    logo.TypeList.push_back(VehicleType("睿骋", ""));
    logo.TypeList.push_back(VehicleType("睿骋CC", ""));
    logo.TypeList.push_back(VehicleType("逸动", ""));
    logo.TypeList.push_back(VehicleType("逸动DT", ""));
    logo.TypeList.push_back(VehicleType("逸动新能源", ""));
    logo.TypeList.push_back(VehicleType("逸动XT", ""));
    logo.TypeList.push_back(VehicleType("悦翔", ""));
    logo.TypeList.push_back(VehicleType("悦翔V3", ""));
    logo.TypeList.push_back(VehicleType("悦翔V5", ""));
    logo.TypeList.push_back(VehicleType("悦翔V7", ""));
    logo.TypeList.push_back(VehicleType("", "CS35 PLUS"));
    logo_list.push_back(logo);

    logo.name_CHS = "长城", logo.name_ENG = "Great Wall";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("风骏5", ""));
    logo.TypeList.push_back(VehicleType("风骏7", ""));
    logo.TypeList.push_back(VehicleType("风骏6", ""));
    logo.TypeList.push_back(VehicleType("风骏房车", ""));
    logo.TypeList.push_back(VehicleType("", "M4"));
    logo.TypeList.push_back(VehicleType("", "C30"));
    logo.TypeList.push_back(VehicleType("", "C50"));
    logo.TypeList.push_back(VehicleType("C30新能源", ""));
    logo.TypeList.push_back(VehicleType("", "M2"));
    logo.TypeList.push_back(VehicleType("炫丽", ""));
    logo.TypeList.push_back(VehicleType("酷熊", ""));
    logo.TypeList.push_back(VehicleType("", "V80"));
    logo.TypeList.push_back(VehicleType("", "M1"));
    logo.TypeList.push_back(VehicleType("", "C20R"));
    logo.TypeList.push_back(VehicleType("赛弗", ""));
    logo.TypeList.push_back(VehicleType("精灵", ""));
    logo.TypeList.push_back(VehicleType("凌傲", ""));
    logo.TypeList.push_back(VehicleType("风骏3", ""));
    logo.TypeList.push_back(VehicleType("嘉誉", ""));
    logo.TypeList.push_back(VehicleType("赛影", ""));
    logo.TypeList.push_back(VehicleType("金迪尔", ""));
    logo.TypeList.push_back(VehicleType("赛铃", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "大地", logo.name_ENG = "musso";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "RX6478A"));
    logo.TypeList.push_back(VehicleType("", "RX6405"));
    logo.TypeList.push_back(VehicleType("", "RX6400"));
    logo.TypeList.push_back(VehicleType("", "RX6478"));
    logo.TypeList.push_back(VehicleType("", "RX6400Y"));
    logo.TypeList.push_back(VehicleType("", "RX6480"));
    logo.TypeList.push_back(VehicleType("", "RX6481"));
    logo.TypeList.push_back(VehicleType("", "RX6481A"));
    logo.TypeList.push_back(VehicleType("", "RX6473"));
    logo.TypeList.push_back(VehicleType("", "RX6510"));
    logo.TypeList.push_back(VehicleType("", "RX6472Y"));
    logo.TypeList.push_back(VehicleType("", "RX6470Y"));
    logo.TypeList.push_back(VehicleType("", "RX6430Y"));
    logo_list.push_back(logo);

    logo.name_CHS = "大通", logo.name_ENG = "MAXUS";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "G50"));
    logo.TypeList.push_back(VehicleType("", "D90"));
    logo.TypeList.push_back(VehicleType("", "G10"));
    logo.TypeList.push_back(VehicleType("", "V80"));
    logo.TypeList.push_back(VehicleType("", "T60"));
    logo.TypeList.push_back(VehicleType("", "EV30"));
    logo.TypeList.push_back(VehicleType("", "EG10"));
    logo_list.push_back(logo);

    logo.name_CHS = "大众", logo.name_ENG = "Volkswagens";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("朗逸", ""));
    logo.TypeList.push_back(VehicleType("帕萨特", ""));
    logo.TypeList.push_back(VehicleType("途岳", ""));
    logo.TypeList.push_back(VehicleType("途观L", ""));
    logo.TypeList.push_back(VehicleType("凌渡", ""));
    logo.TypeList.push_back(VehicleType("途昂", ""));
    logo.TypeList.push_back(VehicleType("桑塔纳", ""));
    logo.TypeList.push_back(VehicleType("途观", ""));
    logo.TypeList.push_back(VehicleType("波罗", "POLO"));
    logo.TypeList.push_back(VehicleType("辉昂", ""));
    logo.TypeList.push_back(VehicleType("途安L", ""));
    logo.TypeList.push_back(VehicleType("朗行", ""));
    logo.TypeList.push_back(VehicleType("朗境", ""));
    logo.TypeList.push_back(VehicleType("途安", ""));
    logo.TypeList.push_back(VehicleType("高尔", ""));
    logo.TypeList.push_back(VehicleType("", "T-Cross"));
    logo.TypeList.push_back(VehicleType("探岳", ""));
    logo.TypeList.push_back(VehicleType("捷达", ""));
    logo.TypeList.push_back(VehicleType("迈腾", ""));
    logo.TypeList.push_back(VehicleType("探歌", ""));
    logo.TypeList.push_back(VehicleType("速腾", ""));
    logo.TypeList.push_back(VehicleType("宝来", ""));
    logo.TypeList.push_back(VehicleType("", "CC"));
    logo.TypeList.push_back(VehicleType("高尔夫", ""));
    logo.TypeList.push_back(VehicleType("蔚领", ""));
    logo.TypeList.push_back(VehicleType("高尔夫·嘉旅", ""));
    logo.TypeList.push_back(VehicleType("开迪", ""));
    logo.TypeList.push_back(VehicleType("途锐", ""));
    logo.TypeList.push_back(VehicleType("甲壳虫", ""));
    logo.TypeList.push_back(VehicleType("夏朗", ""));
    logo.TypeList.push_back(VehicleType("", "Tiguan"));
    logo.TypeList.push_back(VehicleType("蔚揽", ""));
    logo.TypeList.push_back(VehicleType("迈特威", ""));
    logo.TypeList.push_back(VehicleType("凯路威", ""));
    logo.TypeList.push_back(VehicleType("辉腾", ""));
    logo.TypeList.push_back(VehicleType("尚酷", ""));
    logo.TypeList.push_back(VehicleType("", "Eos"));
    logo.TypeList.push_back(VehicleType("", "Amarok"));
    logo.TypeList.push_back(VehicleType("", "UP!"));
    logo.TypeList.push_back(VehicleType("途观L PHEV", ""));
    logo.TypeList.push_back(VehicleType("帕萨特 PHEV", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "道奇", logo.name_ENG = "Dodge";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("酷威", ""));
    logo.TypeList.push_back(VehicleType("", "RAM"));
    logo.TypeList.push_back(VehicleType("酷搏", ""));
    logo.TypeList.push_back(VehicleType("锋哲", ""));
    logo.TypeList.push_back(VehicleType("凯领", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "帝豪", logo.name_ENG = "EMGRAND";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("吉利", ""));
    logo.TypeList.push_back(VehicleType("美日", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "东风", logo.name_ENG = "Dongfeng";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("帅客", ""));
    logo.TypeList.push_back(VehicleType("帅客EV", ""));
    logo.TypeList.push_back(VehicleType("锐骐6", ""));
    logo.TypeList.push_back(VehicleType("锐骐皮卡", ""));
    logo.TypeList.push_back(VehicleType("锐骐厢式车", ""));
    logo.TypeList.push_back(VehicleType("俊风", ""));
    logo.TypeList.push_back(VehicleType("奥丁", ""));
    logo.TypeList.push_back(VehicleType("御轩", ""));
    logo.TypeList.push_back(VehicleType("俊风ER30", ""));
    logo.TypeList.push_back(VehicleType("俊风E11K", ""));
    logo.TypeList.push_back(VehicleType("俊风E17", ""));
    logo.TypeList.push_back(VehicleType("御风S16", ""));
    logo.TypeList.push_back(VehicleType("御风P16", ""));
    logo.TypeList.push_back(VehicleType("御风", ""));
    logo.TypeList.push_back(VehicleType("御风A100", ""));
    logo.TypeList.push_back(VehicleType("俊风EJ30", ""));
    logo.TypeList.push_back(VehicleType("猛士", ""));
    logo.TypeList.push_back(VehicleType("俊风CV03", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "东风日产", logo.name_ENG = "Dongfeng Nissan";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("日产", "nissan"));
    logo.TypeList.push_back(VehicleType("轩逸", ""));
    logo.TypeList.push_back(VehicleType("奇骏", ""));
    logo.TypeList.push_back(VehicleType("逍客", ""));
    logo.TypeList.push_back(VehicleType("天籁", ""));
    logo.TypeList.push_back(VehicleType("蓝鸟", ""));
    logo.TypeList.push_back(VehicleType("楼兰", ""));
    logo.TypeList.push_back(VehicleType("劲客", ""));
    logo.TypeList.push_back(VehicleType("骐达", ""));
    logo.TypeList.push_back(VehicleType("阳光", ""));
    logo.TypeList.push_back(VehicleType("骊威", ""));
    logo.TypeList.push_back(VehicleType("西玛", ""));
    logo.TypeList.push_back(VehicleType("颐达", ""));
    logo.TypeList.push_back(VehicleType("玛驰", ""));
    logo.TypeList.push_back(VehicleType("骏逸", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "东南", logo.name_ENG = "";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("得利卡", ""));
    logo.TypeList.push_back(VehicleType("富利卡", ""));
    logo.TypeList.push_back(VehicleType("菱利", ""));
    logo.TypeList.push_back(VehicleType("V3菱悦", ""));
    logo.TypeList.push_back(VehicleType("君阁", ""));
    logo.TypeList.push_back(VehicleType("蓝瑟", "LANCER"));
    logo.TypeList.push_back(VehicleType("蓝瑟翼神", ""));
    logo.TypeList.push_back(VehicleType("戈蓝", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "法拉利", logo.name_ENG = "ferrari";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("488", ""));
    logo.TypeList.push_back(VehicleType("", "Portofino"));
    logo.TypeList.push_back(VehicleType("812Superfast", ""));
    logo.TypeList.push_back(VehicleType("", "GTC4Lusso"));
    logo.TypeList.push_back(VehicleType("458", ""));
    logo.TypeList.push_back(VehicleType("", "LaFerrari"));
    logo.TypeList.push_back(VehicleType("", "California T"));
    logo.TypeList.push_back(VehicleType("", "F430"));
    logo.TypeList.push_back(VehicleType("", "ENZO"));
    logo.TypeList.push_back(VehicleType("", "F12berlinetta"));
    logo.TypeList.push_back(VehicleType("", "FF"));
    logo.TypeList.push_back(VehicleType("456M", ""));
    logo.TypeList.push_back(VehicleType("599", ""));
    logo.TypeList.push_back(VehicleType("612 Scaglietti", ""));
    logo.TypeList.push_back(VehicleType("360 Modena", ""));
    logo.TypeList.push_back(VehicleType("575M Maranello", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "菲亚特", logo.name_ENG = "FIAT";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("致悦", ""));
    logo.TypeList.push_back(VehicleType("菲翔", ""));
    logo.TypeList.push_back(VehicleType("500", ""));
    logo.TypeList.push_back(VehicleType("菲跃", ""));
    logo.TypeList.push_back(VehicleType("博悦", ""));
    logo.TypeList.push_back(VehicleType("", "Doblo"));
    logo.TypeList.push_back(VehicleType("朋多", ""));
    logo.TypeList.push_back(VehicleType("领雅", ""));
    logo.TypeList.push_back(VehicleType("西耶那", ""));
    logo.TypeList.push_back(VehicleType("派力奥", ""));
    logo.TypeList.push_back(VehicleType("周末风", ""));
    logo.TypeList.push_back(VehicleType("派朗", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "丰田", logo.name_ENG = "Toyota";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("卡罗拉", ""));
    logo.TypeList.push_back(VehicleType("凯美瑞", ""));
    logo.TypeList.push_back(VehicleType("RAV4荣放", ""));
    logo.TypeList.push_back(VehicleType("汉兰达", ""));
    logo.TypeList.push_back(VehicleType("普拉多", "prado"));
    logo.TypeList.push_back(VehicleType("威驰", ""));
    logo.TypeList.push_back(VehicleType("皇冠", ""));
    logo.TypeList.push_back(VehicleType("雷凌", ""));
    logo.TypeList.push_back(VehicleType("YARiS L 致炫", ""));
    logo.TypeList.push_back(VehicleType("普拉多中东版", ""));
    logo.TypeList.push_back(VehicleType("兰德酷路泽", ""));
    logo.TypeList.push_back(VehicleType("奕泽", "IZOA"));
    logo.TypeList.push_back(VehicleType("兰德酷路泽中东版", ""));
    logo.TypeList.push_back(VehicleType("", "C-HR"));
    logo.TypeList.push_back(VehicleType("YARiS L 致享", ""));
    logo.TypeList.push_back(VehicleType("威驰FS", ""));
    logo.TypeList.push_back(VehicleType("逸致", ""));
    logo.TypeList.push_back(VehicleType("塞纳墨版", ""));
    logo.TypeList.push_back(VehicleType("埃尔法", ""));
    logo.TypeList.push_back(VehicleType("塞纳加规版", ""));
    logo.TypeList.push_back(VehicleType("亚洲龙", ""));
    logo.TypeList.push_back(VehicleType("穿越者中东版", ""));
    logo.TypeList.push_back(VehicleType("86", ""));
    logo.TypeList.push_back(VehicleType("普瑞维亚", ""));
    logo.TypeList.push_back(VehicleType("塞纳美规版", ""));
    logo.TypeList.push_back(VehicleType("LC76中东版", ""));
    logo.TypeList.push_back(VehicleType("", "Sienna"));
    logo.TypeList.push_back(VehicleType("普瑞维亚中东版", ""));
    logo.TypeList.push_back(VehicleType("坦途加规版", ""));
    logo.TypeList.push_back(VehicleType("坦途美规版", ""));
    logo.TypeList.push_back(VehicleType("埃尔法欧版", ""));
    logo.TypeList.push_back(VehicleType("红杉墨版", ""));
    logo.TypeList.push_back(VehicleType("柯斯达", ""));
    logo.TypeList.push_back(VehicleType("FJ酷路泽中东版", ""));
    logo.TypeList.push_back(VehicleType("超霸加规版", ""));
    logo.TypeList.push_back(VehicleType("超霸美规版", ""));
    logo.TypeList.push_back(VehicleType("红杉加版", ""));
    logo.TypeList.push_back(VehicleType("", "HIACE"));
    logo.TypeList.push_back(VehicleType("海拉克斯中东版", ""));
    logo.TypeList.push_back(VehicleType("塔库玛美规版", ""));
    logo.TypeList.push_back(VehicleType("考斯特中东版", ""));
    logo.TypeList.push_back(VehicleType("广汽ix4", ""));
    logo.TypeList.push_back(VehicleType("海狮中东版", ""));
    logo.TypeList.push_back(VehicleType("塔库玛加规版", ""));
    logo.TypeList.push_back(VehicleType("世纪", ""));
    logo.TypeList.push_back(VehicleType("霸道", ""));
    logo.TypeList.push_back(VehicleType("陆地巡洋舰", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "福汽启腾", logo.name_ENG = "";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "EX80"));
    logo.TypeList.push_back(VehicleType("", "M70"));
    logo.TypeList.push_back(VehicleType("", "V60"));
    logo.TypeList.push_back(VehicleType("", "M70 EV"));
    logo_list.push_back(logo);

    logo.name_CHS = "福特", logo.name_ENG = "Ford";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("翼搏", ""));
    logo.TypeList.push_back(VehicleType("翼虎", ""));
    logo.TypeList.push_back(VehicleType("锐界", ""));
    logo.TypeList.push_back(VehicleType("福睿斯", ""));
    logo.TypeList.push_back(VehicleType("福克斯", ""));
    logo.TypeList.push_back(VehicleType("蒙迪欧", ""));
    logo.TypeList.push_back(VehicleType("金牛座", ""));
    logo.TypeList.push_back(VehicleType("蒙迪欧", ""));
    logo.TypeList.push_back(VehicleType("撼路者", ""));
    logo.TypeList.push_back(VehicleType("途睿欧", ""));
    logo.TypeList.push_back(VehicleType("全顺", ""));
    logo.TypeList.push_back(VehicleType("新世代全顺", ""));
    logo.TypeList.push_back(VehicleType("探险者", ""));
    logo.TypeList.push_back(VehicleType("福克斯", ""));
    logo.TypeList.push_back(VehicleType("", "MUSTANG"));
    logo.TypeList.push_back(VehicleType("", "F-150"));
    logo.TypeList.push_back(VehicleType("", "Ranger"));
    logo.TypeList.push_back(VehicleType("", "C-MAX"));
    logo.TypeList.push_back(VehicleType("领界", ""));
    logo.TypeList.push_back(VehicleType("嘉年华", ""));
    logo.TypeList.push_back(VehicleType("麦柯斯", ""));
    logo.TypeList.push_back(VehicleType("经典全顺", ""));
    logo.TypeList.push_back(VehicleType("锐界", ""));
    logo.TypeList.push_back(VehicleType("翼虎", ""));
    logo.TypeList.push_back(VehicleType("", "Flex"));
    logo.TypeList.push_back(VehicleType("外交官", ""));
    logo.TypeList.push_back(VehicleType("征服者", ""));
    logo.TypeList.push_back(VehicleType("嘉年华ST", ""));
    logo.TypeList.push_back(VehicleType("E系列", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "福田", logo.name_ENG = "FOTON";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("图雅诺", ""));
    logo.TypeList.push_back(VehicleType("时代驭菱", ""));
    logo.TypeList.push_back(VehicleType("风景G7", ""));
    logo.TypeList.push_back(VehicleType("奥铃捷运", ""));
    logo.TypeList.push_back(VehicleType("蒙派克E", ""));
    logo.TypeList.push_back(VehicleType("风景G9", ""));
    logo.TypeList.push_back(VehicleType("风景", ""));
    logo.TypeList.push_back(VehicleType("时代微卡", ""));
    logo.TypeList.push_back(VehicleType("奥铃CTX", ""));
    logo.TypeList.push_back(VehicleType("祥菱V", ""));
    logo.TypeList.push_back(VehicleType("奥铃TX", ""));
    logo.TypeList.push_back(VehicleType("欧马可", ""));
    logo.TypeList.push_back(VehicleType("时代领航", ""));
    logo.TypeList.push_back(VehicleType("瑞沃工程用车", ""));
    logo.TypeList.push_back(VehicleType("时代康瑞", ""));
    logo.TypeList.push_back(VehicleType("风景V5", ""));
    logo.TypeList.push_back(VehicleType("风景V3", ""));
    logo.TypeList.push_back(VehicleType("祥菱M", ""));
    logo.TypeList.push_back(VehicleType("时代骁运", ""));
    logo.TypeList.push_back(VehicleType("风景快客", ""));
    logo.TypeList.push_back(VehicleType("迷迪", ""));
    logo.TypeList.push_back(VehicleType("传奇X", ""));
    logo.TypeList.push_back(VehicleType("伽途V3", ""));
    logo.TypeList.push_back(VehicleType("海狮", ""));
    logo.TypeList.push_back(VehicleType("风景快捷", ""));
    logo.TypeList.push_back(VehicleType("伽途V5", ""));
    logo.TypeList.push_back(VehicleType("风景冲浪", ""));
    logo.TypeList.push_back(VehicleType("祥菱S", ""));
    logo.TypeList.push_back(VehicleType("拓陆者", ""));
    logo.TypeList.push_back(VehicleType("萨瓦纳", ""));
    logo.TypeList.push_back(VehicleType("伽途ix", ""));
    logo.TypeList.push_back(VehicleType("伽途GT", ""));
    logo.TypeList.push_back(VehicleType("萨普", ""));
    logo.TypeList.push_back(VehicleType("伽途im", ""));
    logo.TypeList.push_back(VehicleType("风景V5EV", ""));
    logo.TypeList.push_back(VehicleType("奥铃EV", ""));
    logo.TypeList.push_back(VehicleType("图雅诺EV", ""));
    logo.TypeList.push_back(VehicleType("风景V3EV", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "观致", logo.name_ENG = "Qoros";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("5", ""));
    logo.TypeList.push_back(VehicleType("3", ""));
    logo.TypeList.push_back(VehicleType("", "Model Young"));
    logo.TypeList.push_back(VehicleType("3 EV", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "传祺", logo.name_ENG = "Trumpchi";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "GM6"));
    logo.TypeList.push_back(VehicleType("", "GS5"));
    logo.TypeList.push_back(VehicleType("", "GA4"));
    logo.TypeList.push_back(VehicleType("", "GM8"));
    logo.TypeList.push_back(VehicleType("", "GS7"));
    logo.TypeList.push_back(VehicleType("", "GS3"));
    logo.TypeList.push_back(VehicleType("", "GS4"));
    logo.TypeList.push_back(VehicleType("", "GS8"));
    logo.TypeList.push_back(VehicleType("", "GA6"));
    logo.TypeList.push_back(VehicleType("", "GA8"));
    logo.TypeList.push_back(VehicleType("", "GA3S"));
    logo.TypeList.push_back(VehicleType("", "GS5 Super"));
    logo.TypeList.push_back(VehicleType("", "GS5"));
    logo.TypeList.push_back(VehicleType("", "GA5"));
    logo_list.push_back(logo);

    logo.name_CHS = "吉奥", logo.name_ENG = "GONOW";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("帅舰", ""));
    logo.TypeList.push_back(VehicleType("", "GS50"));
    logo.TypeList.push_back(VehicleType("", "G5"));
    logo.TypeList.push_back(VehicleType("帅豹", ""));
    logo.TypeList.push_back(VehicleType("", "GX6"));
    logo.TypeList.push_back(VehicleType("", "GX5"));
    logo.TypeList.push_back(VehicleType("星朗", ""));
    logo.TypeList.push_back(VehicleType("财运100", ""));
    logo.TypeList.push_back(VehicleType("吉奥E美", ""));
    logo.TypeList.push_back(VehicleType("财运300", ""));
    logo.TypeList.push_back(VehicleType("财运500", ""));
    logo.TypeList.push_back(VehicleType("吉奥GP150", ""));
    logo.TypeList.push_back(VehicleType("星旺L", ""));
    logo.TypeList.push_back(VehicleType("柴神", ""));
    logo.TypeList.push_back(VehicleType("星旺", ""));
    logo.TypeList.push_back(VehicleType("凯睿", ""));
    logo.TypeList.push_back(VehicleType("奥轩G3", ""));
    logo.TypeList.push_back(VehicleType("星旺CL", ""));
    logo.TypeList.push_back(VehicleType("星旺M1", ""));
    logo.TypeList.push_back(VehicleType("星旺M2", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "哈飞", logo.name_ENG = "HAFEI";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("锐意", ""));
    logo.TypeList.push_back(VehicleType("民意", ""));
    logo.TypeList.push_back(VehicleType("赛豹Ⅲ", ""));
    logo.TypeList.push_back(VehicleType("路宝", ""));
    logo.TypeList.push_back(VehicleType("赛马", ""));
    logo.TypeList.push_back(VehicleType("中意", ""));
    logo.TypeList.push_back(VehicleType("路尊大霸王", ""));
    logo.TypeList.push_back(VehicleType("松花江", ""));
    logo.TypeList.push_back(VehicleType("路尊小霸王", ""));
    logo.TypeList.push_back(VehicleType("赛豹V系", ""));
    logo.TypeList.push_back(VehicleType("骏意", ""));
    logo.TypeList.push_back(VehicleType("单双排", ""));
    logo.TypeList.push_back(VehicleType("普面", ""));
    logo.TypeList.push_back(VehicleType("百利", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "哈弗", logo.name_ENG = "";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("长城", ""));
    logo.TypeList.push_back(VehicleType("", "H6"));
    logo.TypeList.push_back(VehicleType("", "F5"));
    logo.TypeList.push_back(VehicleType("", "M6"));
    logo.TypeList.push_back(VehicleType("", "H2"));
    logo.TypeList.push_back(VehicleType("", "H2s"));
    logo.TypeList.push_back(VehicleType("", "H9"));
    logo.TypeList.push_back(VehicleType("", "F7"));
    logo.TypeList.push_back(VehicleType("", "H6 Coupe"));
    logo.TypeList.push_back(VehicleType("", "H4"));
    logo.TypeList.push_back(VehicleType("", "H7"));
    logo.TypeList.push_back(VehicleType("", "H5"));
    logo.TypeList.push_back(VehicleType("", "H8"));
    logo.TypeList.push_back(VehicleType("", "H1"));
    logo.TypeList.push_back(VehicleType("", "H3"));
    logo_list.push_back(logo);


    logo.name_CHS = "海格", logo.name_ENG = "HIGER";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "H5C"));
    logo.TypeList.push_back(VehicleType("", "H5V"));
    logo_list.push_back(logo);

    logo.name_CHS = "海马", logo.name_ENG = "Haima";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "S5"));
    logo.TypeList.push_back(VehicleType("", "M3"));
    logo.TypeList.push_back(VehicleType("S5青春版", ""));
    logo.TypeList.push_back(VehicleType("", "M6"));
    logo.TypeList.push_back(VehicleType("王子", ""));
    logo.TypeList.push_back(VehicleType("福仕达鸿达", ""));
    logo.TypeList.push_back(VehicleType("爱尚", ""));
    logo.TypeList.push_back(VehicleType("福仕达新鸿达", ""));
    logo.TypeList.push_back(VehicleType("福仕达荣达", ""));
    logo.TypeList.push_back(VehicleType("福仕达福卡", ""));
    logo.TypeList.push_back(VehicleType("腾达", ""));
    logo.TypeList.push_back(VehicleType("福仕达腾达", ""));
    logo.TypeList.push_back(VehicleType("福美来F5", ""));
    logo.TypeList.push_back(VehicleType("福美来F7", ""));
    logo.TypeList.push_back(VehicleType("", "S7"));
    logo.TypeList.push_back(VehicleType("马自达323", ""));
    logo.TypeList.push_back(VehicleType("普力马", ""));
    logo.TypeList.push_back(VehicleType("", "M8"));
    logo.TypeList.push_back(VehicleType("丘比特", ""));
    logo.TypeList.push_back(VehicleType("海福星", ""));
    logo.TypeList.push_back(VehicleType("骑士", ""));
    logo.TypeList.push_back(VehicleType("3", ""));
    logo.TypeList.push_back(VehicleType("欢动", ""));
    logo.TypeList.push_back(VehicleType("", "E3"));
    logo.TypeList.push_back(VehicleType("爱尚EV", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "红旗", logo.name_ENG = "Red Flag";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "H5"));
    logo.TypeList.push_back(VehicleType("", "H7"));
    logo.TypeList.push_back(VehicleType("盛世", ""));
    logo.TypeList.push_back(VehicleType("明仕", ""));
    logo.TypeList.push_back(VehicleType("世纪星", ""));
    logo.TypeList.push_back(VehicleType("", "L5"));
    logo.TypeList.push_back(VehicleType("", "HS7"));
    logo_list.push_back(logo);

    logo.name_CHS = "红星", logo.name_ENG = "Red Flag";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("闪闪X2", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "华普", logo.name_ENG = "";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("海景", ""));
    logo.TypeList.push_back(VehicleType("飚风", ""));
    logo.TypeList.push_back(VehicleType("海锋", ""));
    logo.TypeList.push_back(VehicleType("海尚", ""));
    logo.TypeList.push_back(VehicleType("海迅", ""));
    logo.TypeList.push_back(VehicleType("海炫", ""));
    logo.TypeList.push_back(VehicleType("海域", ""));
    logo.TypeList.push_back(VehicleType("海悦", ""));
    logo.TypeList.push_back(VehicleType("杰士达美鹿", ""));
    logo.TypeList.push_back(VehicleType("朗风", ""));
    logo.TypeList.push_back(VehicleType("M203", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "华颂", logo.name_ENG = "HUASONG";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("7", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "黄海", logo.name_ENG = "";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "N3"));
    logo.TypeList.push_back(VehicleType("", "N2"));
    logo.TypeList.push_back(VehicleType("", "N1S"));
    logo.TypeList.push_back(VehicleType("", "N1"));
    logo.TypeList.push_back(VehicleType("傲骏", ""));
    logo.TypeList.push_back(VehicleType("旗胜F1", ""));
    logo.TypeList.push_back(VehicleType("挑战者", ""));
    logo.TypeList.push_back(VehicleType("大柴神", ""));
    logo.TypeList.push_back(VehicleType("旗胜V3", ""));
    logo.TypeList.push_back(VehicleType("傲龙CUV", ""));
    logo.TypeList.push_back(VehicleType("翱龙CUV", ""));
    logo.TypeList.push_back(VehicleType("领航者", ""));
    logo.TypeList.push_back(VehicleType("瑞途", ""));
    logo.TypeList.push_back(VehicleType("旗胜CUV", ""));
    logo.TypeList.push_back(VehicleType("曙光骄子", ""));
    logo.TypeList.push_back(VehicleType("征服者", ""));
    logo.TypeList.push_back(VehicleType("翱龙SUV", ""));
    logo.TypeList.push_back(VehicleType("傲羚", ""));
    logo.TypeList.push_back(VehicleType("小柴神", ""));
    logo.TypeList.push_back(VehicleType("翱龙", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "吉利", logo.name_ENG = "Geely Auto";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("缤越", ""));
    logo.TypeList.push_back(VehicleType("缤瑞", ""));
    logo.TypeList.push_back(VehicleType("博越", ""));
    logo.TypeList.push_back(VehicleType("帝豪GS", ""));
    logo.TypeList.push_back(VehicleType("远景X3", ""));
    logo.TypeList.push_back(VehicleType("帝豪GL", ""));
    logo.TypeList.push_back(VehicleType("帝豪", ""));
    logo.TypeList.push_back(VehicleType("博瑞GE", ""));
    logo.TypeList.push_back(VehicleType("远景", ""));
    logo.TypeList.push_back(VehicleType("远景SUV", ""));
    logo.TypeList.push_back(VehicleType("远景S1", ""));
    logo.TypeList.push_back(VehicleType("博瑞", ""));
    logo.TypeList.push_back(VehicleType("远景X1", ""));
    logo.TypeList.push_back(VehicleType("金刚", ""));
    logo.TypeList.push_back(VehicleType("熊猫", ""));
    logo.TypeList.push_back(VehicleType("", "GX7"));
    logo.TypeList.push_back(VehicleType("自由舰", ""));
    logo.TypeList.push_back(VehicleType("", "EC8"));
    logo.TypeList.push_back(VehicleType("", "TX4"));
    logo.TypeList.push_back(VehicleType("中国龙", ""));
    logo.TypeList.push_back(VehicleType("美人豹", ""));
    logo.TypeList.push_back(VehicleType("", "GC7"));
    logo.TypeList.push_back(VehicleType("海景", ""));
    logo.TypeList.push_back(VehicleType("美日", ""));
    logo.TypeList.push_back(VehicleType("豪情SUV", ""));
    logo.TypeList.push_back(VehicleType("", "GX2"));
    logo.TypeList.push_back(VehicleType("", "SX7"));
    logo.TypeList.push_back(VehicleType("英伦C5", ""));
    logo.TypeList.push_back(VehicleType("", "SC3"));
    logo.TypeList.push_back(VehicleType("美日之星", ""));
    logo.TypeList.push_back(VehicleType("豪情", ""));
    logo.TypeList.push_back(VehicleType("优利欧", ""));
    logo.TypeList.push_back(VehicleType("嘉际", ""));
    logo.TypeList.push_back(VehicleType("博瑞GE PHEV", ""));
    logo.TypeList.push_back(VehicleType("帝豪GSe", ""));
    logo.TypeList.push_back(VehicleType("帝豪EV", ""));
    logo.TypeList.push_back(VehicleType("帝豪PHEV", ""));
    logo.TypeList.push_back(VehicleType("嘉际PHEV", ""));
    logo.TypeList.push_back(VehicleType("吉利GE11", ""));
    logo.TypeList.push_back(VehicleType("吉利全球鹰", "GLEAGLE"));
    logo.TypeList.push_back(VehicleType("吉利英伦", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "吉普", logo.name_ENG = "Jeep";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("自由光", ""));
    logo.TypeList.push_back(VehicleType("牧马人", ""));
    logo.TypeList.push_back(VehicleType("指南者", ""));
    logo.TypeList.push_back(VehicleType("自由侠", ""));
    logo.TypeList.push_back(VehicleType("大切诺基", ""));
    logo.TypeList.push_back(VehicleType("大切诺基 SRT", ""));
    logo.TypeList.push_back(VehicleType("大指挥官", ""));
    logo.TypeList.push_back(VehicleType("指挥官", ""));
    logo.TypeList.push_back(VehicleType("大指挥官混动", ""));
    logo.TypeList.push_back(VehicleType("自由光混动", ""));
    logo.TypeList.push_back(VehicleType("悦界PHEV", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "江淮", logo.name_ENG = "Jianghuai";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("瑞风S3", ""));
    logo.TypeList.push_back(VehicleType("瑞风M4", ""));
    logo.TypeList.push_back(VehicleType("瑞风M3", ""));
    logo.TypeList.push_back(VehicleType("瑞风S7", ""));
    logo.TypeList.push_back(VehicleType("瑞风R3", ""));
    logo.TypeList.push_back(VehicleType("帅铃T8", ""));
    logo.TypeList.push_back(VehicleType("瑞风M5", ""));
    logo.TypeList.push_back(VehicleType("瑞风S2", ""));
    logo.TypeList.push_back(VehicleType("瑞风S2mini", ""));
    logo.TypeList.push_back(VehicleType("瑞风S4", ""));
    logo.TypeList.push_back(VehicleType("瑞风S5", ""));
    logo.TypeList.push_back(VehicleType("帅铃T6", ""));
    logo.TypeList.push_back(VehicleType("瑞风M6", ""));
    logo.TypeList.push_back(VehicleType("星锐", ""));
    logo.TypeList.push_back(VehicleType("和悦", ""));
    logo.TypeList.push_back(VehicleType("瑞风A60", ""));
    logo.TypeList.push_back(VehicleType("江淮V7", ""));
    logo.TypeList.push_back(VehicleType("帅铃V6", ""));
    logo.TypeList.push_back(VehicleType("瑞风", ""));
    logo.TypeList.push_back(VehicleType("瑞鹰", ""));
    logo.TypeList.push_back(VehicleType("瑞风M2", ""));
    logo.TypeList.push_back(VehicleType("宾悦", ""));
    logo.TypeList.push_back(VehicleType("和悦A30", ""));
    logo.TypeList.push_back(VehicleType("悦悦", ""));
    logo.TypeList.push_back(VehicleType("和悦A13", ""));
    logo.TypeList.push_back(VehicleType("瑞铃", ""));
    logo.TypeList.push_back(VehicleType("", "iEV6E"));
    logo.TypeList.push_back(VehicleType("", "iEV7S"));
    logo.TypeList.push_back(VehicleType("", "iEVA50"));
    logo.TypeList.push_back(VehicleType("", "iEV4"));
    logo.TypeList.push_back(VehicleType("", "iEV6S"));
    logo.TypeList.push_back(VehicleType("", "iEV7"));
    logo.TypeList.push_back(VehicleType("", "iEVA60"));
    logo.TypeList.push_back(VehicleType("", "iEVS4"));
    logo_list.push_back(logo);

    logo.name_CHS = "江铃", logo.name_ENG = "Jiangling";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("域虎7", ""));
    logo.TypeList.push_back(VehicleType("特顺", ""));
    logo.TypeList.push_back(VehicleType("域虎3", ""));
    logo.TypeList.push_back(VehicleType("宝典", ""));
    logo.TypeList.push_back(VehicleType("域虎5", ""));
    logo.TypeList.push_back(VehicleType("凯运升级版", ""));
    logo.TypeList.push_back(VehicleType("顺达窄体", ""));
    logo.TypeList.push_back(VehicleType("顺达宽体", ""));
    logo.TypeList.push_back(VehicleType("凯锐800", ""));
    logo.TypeList.push_back(VehicleType("凯锐", ""));
    logo.TypeList.push_back(VehicleType("宝威", ""));
    logo.TypeList.push_back(VehicleType("凯威", ""));
    logo.TypeList.push_back(VehicleType("", "E400"));
    logo.TypeList.push_back(VehicleType("", "E200L"));
    logo.TypeList.push_back(VehicleType("", "E200N"));
    logo.TypeList.push_back(VehicleType("", "E100B"));
    logo.TypeList.push_back(VehicleType("", "E160"));
    logo.TypeList.push_back(VehicleType("易至EV3", ""));
    logo.TypeList.push_back(VehicleType("", "骐铃T7"));
    logo.TypeList.push_back(VehicleType("", "骐铃T100"));
    logo.TypeList.push_back(VehicleType("", "骐铃T5"));
    logo.TypeList.push_back(VehicleType("", "骐铃T3"));
    logo_list.push_back(logo);

    logo.name_CHS = "金杯", logo.name_ENG = "JINBEI";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("海狮", ""));
    logo.TypeList.push_back(VehicleType("阁瑞斯", ""));
    logo.TypeList.push_back(VehicleType("", "F50"));
    logo.TypeList.push_back(VehicleType("大海狮", ""));
    logo.TypeList.push_back(VehicleType("霸道SUV", ""));
    logo.TypeList.push_back(VehicleType("海星", ""));
    logo.TypeList.push_back(VehicleType("华晨金杯S50", ""));
    logo.TypeList.push_back(VehicleType("海狮X30L", ""));
    logo.TypeList.push_back(VehicleType("小海狮X30", ""));
    logo.TypeList.push_back(VehicleType("750", ""));
    logo.TypeList.push_back(VehicleType("新海狮S", ""));
    logo.TypeList.push_back(VehicleType("", "T32"));
    logo.TypeList.push_back(VehicleType("", "T52"));
    logo.TypeList.push_back(VehicleType("", "T30"));
    logo.TypeList.push_back(VehicleType("", "A7"));
    logo.TypeList.push_back(VehicleType("", "T50"));
    logo.TypeList.push_back(VehicleType("", "T20"));
    logo.TypeList.push_back(VehicleType("", "A9"));
    logo.TypeList.push_back(VehicleType("", "T22"));
    logo.TypeList.push_back(VehicleType("", "S70"));
    logo.TypeList.push_back(VehicleType("智尚S35", ""));
    logo.TypeList.push_back(VehicleType("金典", ""));
    logo.TypeList.push_back(VehicleType("大力神K5", ""));
    logo.TypeList.push_back(VehicleType("西部牛仔", ""));
    logo.TypeList.push_back(VehicleType("雷龙", ""));
    logo.TypeList.push_back(VehicleType("小金牛", ""));
    logo.TypeList.push_back(VehicleType("海狮X30L EV", ""));
    logo.TypeList.push_back(VehicleType("观境", ""));
    logo.TypeList.push_back(VehicleType("领坤EV", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "金程", logo.name_ENG = "";
    logo.TypeList.clear();
    logo_list.push_back(logo);

    logo.name_CHS = "金龙", logo.name_ENG = "";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("金威", ""));
    logo.TypeList.push_back(VehicleType("凯歌", ""));
    logo.TypeList.push_back(VehicleType("凯特", ""));
    logo.TypeList.push_back(VehicleType("凯锐浩克", ""));
    logo.TypeList.push_back(VehicleType("金龙海狮", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "金旅", logo.name_ENG = "";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("海狮", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "晶马", logo.name_ENG = "";
    logo.TypeList.clear();
    logo_list.push_back(logo);

    logo.name_CHS = "九龙", logo.name_ENG = "";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("艾菲", ""));
    logo.TypeList.push_back(VehicleType("商务车", ""));
    logo.TypeList.push_back(VehicleType("考斯特", ""));
    logo.TypeList.push_back(VehicleType("专用车", ""));
    logo.TypeList.push_back(VehicleType("", "EM3"));
    logo.TypeList.push_back(VehicleType("", "EM5"));
    logo_list.push_back(logo);

    logo.name_CHS = "开瑞", logo.name_ENG = "Karry";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "K50"));
    logo.TypeList.push_back(VehicleType("", "K60"));
    logo.TypeList.push_back(VehicleType("优优", ""));
    logo.TypeList.push_back(VehicleType("优劲", ""));
    logo.TypeList.push_back(VehicleType("", "3"));
    logo.TypeList.push_back(VehicleType("优雅", ""));
    logo.TypeList.push_back(VehicleType("爱卡", ""));
    logo.TypeList.push_back(VehicleType("杰虎", ""));
    logo.TypeList.push_back(VehicleType("优胜", ""));
    logo.TypeList.push_back(VehicleType("优翼", ""));
    logo.TypeList.push_back(VehicleType("优派", ""));
    logo.TypeList.push_back(VehicleType("", "K60EV"));
    logo.TypeList.push_back(VehicleType("", "K50EV"));
    logo.TypeList.push_back(VehicleType("优优EV", ""));
    logo.TypeList.push_back(VehicleType("优劲EV", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "凯迪拉克", logo.name_ENG = "Cadillac";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "XT4"));
    logo.TypeList.push_back(VehicleType("", "ATS-L"));
    logo.TypeList.push_back(VehicleType("", "XT5"));
    logo.TypeList.push_back(VehicleType("", "XTS"));
    logo.TypeList.push_back(VehicleType("", "CT6"));
    logo.TypeList.push_back(VehicleType("SLS赛威", ""));
    logo.TypeList.push_back(VehicleType("凯雷德", ""));
    logo.TypeList.push_back(VehicleType("", "CTS"));
    logo.TypeList.push_back(VehicleType("", "SRX"));
    logo.TypeList.push_back(VehicleType("", "ATS"));
    logo.TypeList.push_back(VehicleType("", "XLR"));
    logo.TypeList.push_back(VehicleType("", "XT6"));
    logo_list.push_back(logo);

    logo.name_CHS = "克莱斯勒", logo.name_ENG = "Chrysler";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "300C"));
    logo.TypeList.push_back(VehicleType("大捷龙", ""));
    logo.TypeList.push_back(VehicleType("PT漫步者", ""));
    logo.TypeList.push_back(VehicleType("赛百灵", ""));
    logo.TypeList.push_back(VehicleType("城乡", ""));
    logo.TypeList.push_back(VehicleType("交叉火力", ""));
    logo.TypeList.push_back(VehicleType("铂锐", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "兰博基尼", logo.name_ENG = "Lamborghini";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "Urus"));
    logo.TypeList.push_back(VehicleType("", "Huracán"));
    logo.TypeList.push_back(VehicleType("", "Aventador"));
    logo.TypeList.push_back(VehicleType("", "Asterion"));
    logo.TypeList.push_back(VehicleType("", "Centenario"));
    logo.TypeList.push_back(VehicleType("", "Diablo"));
    logo.TypeList.push_back(VehicleType("", "Egoista"));
    logo.TypeList.push_back(VehicleType("", "Terzo Millennio"));
    logo.TypeList.push_back(VehicleType("", "Veneno"));
    logo.TypeList.push_back(VehicleType("", "LM002"));
    logo.TypeList.push_back(VehicleType("", "Estoque"));
    logo.TypeList.push_back(VehicleType("", "Gallardo"));
    logo.TypeList.push_back(VehicleType("", "Murcielago"));
    logo.TypeList.push_back(VehicleType("", "Reventon"));
    logo.TypeList.push_back(VehicleType("", "Sesto Elemento"));
    logo_list.push_back(logo);

    logo.name_CHS = "雷克萨斯", logo.name_ENG = "LEXUS";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "ES"));
    logo.TypeList.push_back(VehicleType("", "NX"));
    logo.TypeList.push_back(VehicleType("", "RX"));
    logo.TypeList.push_back(VehicleType("", "LX"));
    logo.TypeList.push_back(VehicleType("", "LS"));
    logo.TypeList.push_back(VehicleType("", "CT"));
    logo.TypeList.push_back(VehicleType("", "IS"));
    logo.TypeList.push_back(VehicleType("", "GS"));
    logo.TypeList.push_back(VehicleType("", "LC"));
    logo.TypeList.push_back(VehicleType("", "RC"));
    logo.TypeList.push_back(VehicleType("", "GX"));
    logo.TypeList.push_back(VehicleType("", "SC"));
    logo.TypeList.push_back(VehicleType("", "UX"));
    logo.TypeList.push_back(VehicleType("凌志", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "雷诺", logo.name_ENG = "Renault S.A";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "ESPACE"));
    logo.TypeList.push_back(VehicleType("卡缤", ""));
    logo.TypeList.push_back(VehicleType("梅甘娜", ""));
    logo.TypeList.push_back(VehicleType("科雷傲", ""));
    logo.TypeList.push_back(VehicleType("风朗", ""));
    logo.TypeList.push_back(VehicleType("风景", ""));
    logo.TypeList.push_back(VehicleType("塔利斯曼", ""));
    logo.TypeList.push_back(VehicleType("纬度", ""));
    logo.TypeList.push_back(VehicleType("拉古那", ""));
    logo.TypeList.push_back(VehicleType("威赛帝", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "理念", logo.name_ENG = "linianqiche";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "VE-1"));
    logo.TypeList.push_back(VehicleType("", "S1"));
    logo_list.push_back(logo);

    logo.name_CHS = "力帆", logo.name_ENG = "";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("320", ""));
    logo.TypeList.push_back(VehicleType("330", ""));
    logo.TypeList.push_back(VehicleType("520", ""));
    logo.TypeList.push_back(VehicleType("520i", ""));
    logo.TypeList.push_back(VehicleType("530", ""));
    logo.TypeList.push_back(VehicleType("620", ""));
    logo.TypeList.push_back(VehicleType("630", ""));
    logo.TypeList.push_back(VehicleType("650", ""));
    logo.TypeList.push_back(VehicleType("720", ""));
    logo.TypeList.push_back(VehicleType("820", ""));
    logo.TypeList.push_back(VehicleType("丰顺", ""));
    logo.TypeList.push_back(VehicleType("福顺", ""));
    logo.TypeList.push_back(VehicleType("乐途", ""));
    logo.TypeList.push_back(VehicleType("X50", ""));
    logo.TypeList.push_back(VehicleType("X60", ""));
    logo.TypeList.push_back(VehicleType("X80", ""));
    logo.TypeList.push_back(VehicleType("兴顺", ""));
    logo.TypeList.push_back(VehicleType("迈威", ""));
    logo.TypeList.push_back(VehicleType("轩朗", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "莲花", logo.name_ENG = "Lotus Cars";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "L3"));
    logo.TypeList.push_back(VehicleType("", "L5"));
    logo.TypeList.push_back(VehicleType("竞悦", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "猎豹", logo.name_ENG = "Leopaard";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "Mattu"));
    logo.TypeList.push_back(VehicleType("", "CS9"));
    logo.TypeList.push_back(VehicleType("", "CS10"));
    logo.TypeList.push_back(VehicleType("", "Q6"));
    logo.TypeList.push_back(VehicleType("", "CT7"));
    logo.TypeList.push_back(VehicleType("黑金刚", ""));
    logo.TypeList.push_back(VehicleType("飞腾", ""));
    logo.TypeList.push_back(VehicleType("6481", ""));
    logo.TypeList.push_back(VehicleType("骐菱", ""));
    logo.TypeList.push_back(VehicleType("", "CS6"));
    logo.TypeList.push_back(VehicleType("CT5皮卡", ""));
    logo.TypeList.push_back(VehicleType("CS7", ""));
    logo.TypeList.push_back(VehicleType("皮卡", ""));
    logo.TypeList.push_back(VehicleType("长丰DUV", ""));
    logo.TypeList.push_back(VehicleType("飞扬皮卡", ""));
    logo.TypeList.push_back(VehicleType("飞腾C5", ""));
    logo.TypeList.push_back(VehicleType("福铃皮卡", ""));
    logo.TypeList.push_back(VehicleType("飞扬SUV", ""));
    logo.TypeList.push_back(VehicleType("飞铃SUV", ""));
    logo.TypeList.push_back(VehicleType("金麒麟", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "林肯", logo.name_ENG = "LINCOLN";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "MKC"));
    logo.TypeList.push_back(VehicleType("", "MKZ"));
    logo.TypeList.push_back(VehicleType("领航员", ""));
    logo.TypeList.push_back(VehicleType("大陆", ""));
    logo.TypeList.push_back(VehicleType("", "MKX"));
    logo.TypeList.push_back(VehicleType("", "MKT"));
    logo.TypeList.push_back(VehicleType("", "MKS"));
    logo.TypeList.push_back(VehicleType("航海家", ""));
    logo.TypeList.push_back(VehicleType("飞行家", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "铃木", logo.name_ENG = "SUZUKI";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("维特拉", ""));
    logo.TypeList.push_back(VehicleType("骁途", ""));
    logo.TypeList.push_back(VehicleType("奥拓", ""));
    logo.TypeList.push_back(VehicleType("雨燕", ""));
    logo.TypeList.push_back(VehicleType("启悦", ""));
    logo.TypeList.push_back(VehicleType("天语 SX4", ""));
    logo.TypeList.push_back(VehicleType("北斗星", ""));
    logo.TypeList.push_back(VehicleType("北斗星X5", ""));
    logo.TypeList.push_back(VehicleType("吉姆尼", ""));
    logo.TypeList.push_back(VehicleType("英格尼斯", ""));
    logo.TypeList.push_back(VehicleType("超级维特拉", ""));
    logo.TypeList.push_back(VehicleType("锋驭", ""));
    logo.TypeList.push_back(VehicleType("羚羊", ""));
    logo.TypeList.push_back(VehicleType("尚悦", ""));
    logo.TypeList.push_back(VehicleType("派喜", ""));
    logo.TypeList.push_back(VehicleType("利亚纳", ""));
    logo.TypeList.push_back(VehicleType("利亚纳A6", ""));
    logo.TypeList.push_back(VehicleType("浪迪", ""));
    logo.TypeList.push_back(VehicleType("速翼特", ""));
    logo.TypeList.push_back(VehicleType("凯泽西", ""));
    logo.TypeList.push_back(VehicleType("长安", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "路虎", logo.name_ENG = "LAND ROVER";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("揽胜", ""));
    logo.TypeList.push_back(VehicleType("运动", ""));
    logo.TypeList.push_back(VehicleType("揽胜星脉", ""));
    logo.TypeList.push_back(VehicleType("发现", ""));
    logo.TypeList.push_back(VehicleType("揽胜极光", ""));
    logo.TypeList.push_back(VehicleType("卫士", ""));
    logo.TypeList.push_back(VehicleType("发现神行", ""));
    logo.TypeList.push_back(VehicleType("神行者", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "陆风", logo.name_ENG = "Landwind";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "X7"));
    logo.TypeList.push_back(VehicleType("逍遥", ""));
    logo.TypeList.push_back(VehicleType("", "X2"));
    logo.TypeList.push_back(VehicleType("", "X8"));
    logo.TypeList.push_back(VehicleType("", "X5"));
    logo.TypeList.push_back(VehicleType("", "X6"));
    logo.TypeList.push_back(VehicleType("风尚", ""));
    logo.TypeList.push_back(VehicleType("", "X9"));
    logo.TypeList.push_back(VehicleType("风华", ""));
    logo.TypeList.push_back(VehicleType("新饰界", ""));
    logo.TypeList.push_back(VehicleType("江陵", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "罗孚", logo.name_ENG = "Rover";
    logo.TypeList.clear();
    logo_list.push_back(logo);

    logo.name_CHS = "玛莎拉蒂", logo.name_ENG = "Maserati";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "Levante"));
    logo.TypeList.push_back(VehicleType("", "Ghibli"));
    logo.TypeList.push_back(VehicleType("", "Quattroporte"));
    logo.TypeList.push_back(VehicleType("", "GranCabrio"));
    logo.TypeList.push_back(VehicleType("", "GranTurismo"));
    logo.TypeList.push_back(VehicleType("", "spyder"));
    logo.TypeList.push_back(VehicleType("", "Coupe"));
    logo.TypeList.push_back(VehicleType("", "GranSport"));
    logo_list.push_back(logo);

    logo.name_CHS = "马自达", logo.name_ENG = "Mazda";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("昂克赛拉", ""));
    logo.TypeList.push_back(VehicleType("", "CX-5"));
    logo.TypeList.push_back(VehicleType("", "CX-8"));
    logo.TypeList.push_back(VehicleType("3", ""));
    logo.TypeList.push_back(VehicleType("2", ""));
    logo.TypeList.push_back(VehicleType("3 星骋", ""));
    logo.TypeList.push_back(VehicleType("海马", ""));
    logo.TypeList.push_back(VehicleType("海南", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "迷你", logo.name_ENG = "Mini";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "CLUBMAN"));
    logo.TypeList.push_back(VehicleType("", "COUNTRYMAN"));
    logo.TypeList.push_back(VehicleType("", "CABRIO"));
    logo.TypeList.push_back(VehicleType("", "COUPE"));
    logo.TypeList.push_back(VehicleType("", "PACEMAN"));
    logo.TypeList.push_back(VehicleType("", "ROADSTER"));
    logo.TypeList.push_back(VehicleType("", "JCW COUNTRYMAN"));
    logo.TypeList.push_back(VehicleType("", "JCW"));
    logo.TypeList.push_back(VehicleType("", "JCW CLUBMAN"));
    logo.TypeList.push_back(VehicleType("", "JCW COUPE"));
    logo.TypeList.push_back(VehicleType("", "JCW PACEMAN"));
    logo_list.push_back(logo);

    logo.name_CHS = "名爵", logo.name_ENG = "MorrisGarages";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("6", ""));
    logo.TypeList.push_back(VehicleType("", "HS"));
    logo.TypeList.push_back(VehicleType("", "ZS"));
    logo.TypeList.push_back(VehicleType("", "GS"));
    logo.TypeList.push_back(VehicleType("3", ""));
    logo.TypeList.push_back(VehicleType("7", ""));
    logo.TypeList.push_back(VehicleType("3SW", ""));
    logo.TypeList.push_back(VehicleType("TF", ""));
    logo.TypeList.push_back(VehicleType("5", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "纳智捷", logo.name_ENG = "Luxgen";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "U5 SUV"));
    logo.TypeList.push_back(VehicleType("优6 SUV", ""));
    logo.TypeList.push_back(VehicleType("大7 MPV", ""));
    logo.TypeList.push_back(VehicleType("锐3", ""));
    logo.TypeList.push_back(VehicleType("MASTER CEO", ""));
    logo.TypeList.push_back(VehicleType("大7 SUV", ""));
    logo.TypeList.push_back(VehicleType("纳5", ""));
    logo.TypeList.push_back(VehicleType("", "U5 EV"));
    logo_list.push_back(logo);

    logo.name_CHS = "欧宝", logo.name_ENG = "OPEL";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("威达", ""));
    logo.TypeList.push_back(VehicleType("雅特", ""));
    logo.TypeList.push_back(VehicleType("英速亚", ""));
    logo.TypeList.push_back(VehicleType("安德拉", ""));
    logo.TypeList.push_back(VehicleType("麦瑞纳", ""));
    logo.TypeList.push_back(VehicleType("赛飞利", ""));
    logo.TypeList.push_back(VehicleType("", "GT"));
    logo_list.push_back(logo);

    logo.name_CHS = "讴歌", logo.name_ENG = "Acura";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "CDX"));
    logo.TypeList.push_back(VehicleType("", "RDX"));
    logo.TypeList.push_back(VehicleType("", "TLX-L"));
    logo.TypeList.push_back(VehicleType("", "RDX"));
    logo.TypeList.push_back(VehicleType("", "MDX"));
    logo.TypeList.push_back(VehicleType("", "NSX"));
    logo.TypeList.push_back(VehicleType("", "ZDX"));
    logo.TypeList.push_back(VehicleType("", "CDX"));
    logo.TypeList.push_back(VehicleType("", "ILX"));
    logo.TypeList.push_back(VehicleType("", "TLX"));
    logo.TypeList.push_back(VehicleType("", "RLX"));
    logo.TypeList.push_back(VehicleType("", "TL"));
    logo.TypeList.push_back(VehicleType("", "RL"));
    logo_list.push_back(logo);

    logo.name_CHS = "奇瑞", logo.name_ENG = "Chery";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("爱卡", ""));
    logo.TypeList.push_back(VehicleType("艾瑞泽3", ""));
    logo.TypeList.push_back(VehicleType("艾瑞泽5", ""));
    logo.TypeList.push_back(VehicleType("艾瑞泽7", ""));
    logo.TypeList.push_back(VehicleType("艾瑞泽7e", ""));
    logo.TypeList.push_back(VehicleType("艾瑞泽EX", ""));
    logo.TypeList.push_back(VehicleType("艾瑞泽M7", ""));
    logo.TypeList.push_back(VehicleType("东方之子", ""));
    logo.TypeList.push_back(VehicleType("东方之子Cross", ""));
    logo.TypeList.push_back(VehicleType("风云", ""));
    logo.TypeList.push_back(VehicleType("风云2", ""));
    logo.TypeList.push_back(VehicleType("", "A1"));
    logo.TypeList.push_back(VehicleType("", "A3"));
    logo.TypeList.push_back(VehicleType("", "A5"));
    logo.TypeList.push_back(VehicleType("", "E3"));
    logo.TypeList.push_back(VehicleType("", "E5"));
    logo.TypeList.push_back(VehicleType("", "QQ"));
    logo.TypeList.push_back(VehicleType("", "QQ3"));
    logo.TypeList.push_back(VehicleType("", "QQ6"));
    logo.TypeList.push_back(VehicleType("", "QQme"));
    logo.TypeList.push_back(VehicleType("旗云", ""));
    logo.TypeList.push_back(VehicleType("旗云1", ""));
    logo.TypeList.push_back(VehicleType("旗云2", ""));
    logo.TypeList.push_back(VehicleType("旗云3", ""));
    logo.TypeList.push_back(VehicleType("旗云5", ""));
    logo.TypeList.push_back(VehicleType("瑞虎", ""));
    logo.TypeList.push_back(VehicleType("瑞虎3", ""));
    logo.TypeList.push_back(VehicleType("瑞虎5", ""));
    logo.TypeList.push_back(VehicleType("瑞虎5x", ""));
    logo.TypeList.push_back(VehicleType("瑞虎7", "E3"));
    logo.TypeList.push_back(VehicleType("瑞虎8", ""));
    logo.TypeList.push_back(VehicleType("艾瑞泽5e", ""));
    logo.TypeList.push_back(VehicleType("奇瑞eQ", ""));
    logo.TypeList.push_back(VehicleType("瑞虎3xe", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "启辰", logo.name_ENG = "Venucia";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "D60"));
    logo.TypeList.push_back(VehicleType("", "T70"));
    logo.TypeList.push_back(VehicleType("", "T90"));
    logo.TypeList.push_back(VehicleType("", "T60"));
    logo.TypeList.push_back(VehicleType("", "M50V"));
    logo.TypeList.push_back(VehicleType("", "T70X"));
    logo.TypeList.push_back(VehicleType("", "R50X"));
    logo.TypeList.push_back(VehicleType("", "D50"));
    logo.TypeList.push_back(VehicleType("", "R50"));
    logo.TypeList.push_back(VehicleType("", "R30"));
    logo.TypeList.push_back(VehicleType("启辰晨风", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "起亚", logo.name_ENG = "KIA";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("福瑞迪", ""));
    logo.TypeList.push_back(VehicleType("", "K2"));
    logo.TypeList.push_back(VehicleType("", "K3"));
    logo.TypeList.push_back(VehicleType("", "K4"));
    logo.TypeList.push_back(VehicleType("", "K5"));
    logo.TypeList.push_back(VehicleType("", "KX3"));
    logo.TypeList.push_back(VehicleType("", "KX5"));
    logo.TypeList.push_back(VehicleType("", "KX7"));
    logo.TypeList.push_back(VehicleType("赛拉图", ""));
    logo.TypeList.push_back(VehicleType("狮跑", ""));
    logo.TypeList.push_back(VehicleType("秀尔", ""));
    logo.TypeList.push_back(VehicleType("智跑", ""));
    logo.TypeList.push_back(VehicleType("霸锐", ""));
    logo.TypeList.push_back(VehicleType("凯尊", ""));
    logo.TypeList.push_back(VehicleType("", "K9"));
    logo.TypeList.push_back(VehicleType("", "VQ"));
    logo.TypeList.push_back(VehicleType("索兰托", ""));
    logo.TypeList.push_back(VehicleType("速迈", ""));
    logo.TypeList.push_back(VehicleType("嘉华", ""));
    logo.TypeList.push_back(VehicleType("佳乐", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "荣威", logo.name_ENG = "ROEWE";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("350", ""));
    logo.TypeList.push_back(VehicleType("360", ""));
    logo.TypeList.push_back(VehicleType("950", ""));
    logo.TypeList.push_back(VehicleType("", "e50"));
    logo.TypeList.push_back(VehicleType("", "e550"));
    logo.TypeList.push_back(VehicleType("", "e950"));
    logo.TypeList.push_back(VehicleType("", "Ei5"));
    logo.TypeList.push_back(VehicleType("", "ei6"));
    logo.TypeList.push_back(VehicleType("", "i5"));
    logo.TypeList.push_back(VehicleType("", "i6"));
    logo.TypeList.push_back(VehicleType("", "RX3"));
    logo.TypeList.push_back(VehicleType("", "RX5"));
    logo.TypeList.push_back(VehicleType("", "RX8"));
    logo.TypeList.push_back(VehicleType("", "W5"));
    logo_list.push_back(logo);

    logo.name_CHS = "萨博", logo.name_ENG = "SAAB";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("9-3", ""));
    logo.TypeList.push_back(VehicleType("9-5", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "三菱", logo.name_ENG = "Mitsubishi";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("帕杰罗", ""));
    logo.TypeList.push_back(VehicleType("蓝瑟", ""));
    logo.TypeList.push_back(VehicleType("欧蓝德", ""));
    logo.TypeList.push_back(VehicleType("劲炫", ""));
    logo.TypeList.push_back(VehicleType("帕杰罗·劲畅", ""));
    logo.TypeList.push_back(VehicleType("伊柯丽斯", ""));
    logo.TypeList.push_back(VehicleType("格蓝迪", ""));
    logo.TypeList.push_back(VehicleType("东南", ""));
    logo.TypeList.push_back(VehicleType("徳宝", ""));
    logo.TypeList.push_back(VehicleType("帕捷罗", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "陕汽通家", logo.name_ENG = "Mitsubishi";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("福家", ""));
    logo.TypeList.push_back(VehicleType("国金GM3", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "双环", logo.name_ENG = "Mitsubishi";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("来宝S-RV", ""));
    logo.TypeList.push_back(VehicleType("小贵族", ""));
    logo.TypeList.push_back(VehicleType("", "SCEO"));
    logo.TypeList.push_back(VehicleType("来旺", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "双龙", logo.name_ENG = "SSANG YONG";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("主席", ""));
    logo.TypeList.push_back(VehicleType("雷斯特G4", ""));
    logo.TypeList.push_back(VehicleType("途凌", ""));
    logo.TypeList.push_back(VehicleType("爱腾", ""));
    logo.TypeList.push_back(VehicleType("雷斯特W", ""));
    logo.TypeList.push_back(VehicleType("柯兰多", ""));
    logo.TypeList.push_back(VehicleType("路帝", ""));
    logo.TypeList.push_back(VehicleType("享御", ""));
    logo.TypeList.push_back(VehicleType("蒂维拉", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "斯巴鲁", logo.name_ENG = "Subaru";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "XV"));
    logo.TypeList.push_back(VehicleType("森林人", ""));
    logo.TypeList.push_back(VehicleType("傲虎", ""));
    logo.TypeList.push_back(VehicleType("力狮", ""));
    logo.TypeList.push_back(VehicleType("", "BRZ"));
    logo.TypeList.push_back(VehicleType("驰鹏", ""));
    logo.TypeList.push_back(VehicleType("翼豹", ""));
    logo.TypeList.push_back(VehicleType("", "WRX"));
    logo_list.push_back(logo);

    logo.name_CHS = "斯柯达", logo.name_ENG = "SKODA";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("柯珞克", ""));
    logo.TypeList.push_back(VehicleType("明锐", ""));
    logo.TypeList.push_back(VehicleType("柯迪亚克", ""));
    logo.TypeList.push_back(VehicleType("柯米克", ""));
    logo.TypeList.push_back(VehicleType("速派", ""));
    logo.TypeList.push_back(VehicleType("昕锐", ""));
    logo.TypeList.push_back(VehicleType("柯迪亚克GT", ""));
    logo.TypeList.push_back(VehicleType("昕动", ""));
    logo.TypeList.push_back(VehicleType("野帝", ""));
    logo.TypeList.push_back(VehicleType("晶锐", ""));
    logo.TypeList.push_back(VehicleType("昊锐", ""));
    logo.TypeList.push_back(VehicleType("明锐", ""));
    logo.TypeList.push_back(VehicleType("", "Yeti"));
    logo.TypeList.push_back(VehicleType("法比亚", ""));
    logo.TypeList.push_back(VehicleType("欧雅", ""));
    logo.TypeList.push_back(VehicleType("速尊", ""));
    logo.TypeList.push_back(VehicleType("昊锐", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "威麟", logo.name_ENG = "";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "H5"));
    logo.TypeList.push_back(VehicleType("", "H3"));
    logo.TypeList.push_back(VehicleType("", "V5"));
    logo.TypeList.push_back(VehicleType("", "X5"));
    logo_list.push_back(logo);

    logo.name_CHS = "潍柴英致", logo.name_ENG = "";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("737", ""));
    logo.TypeList.push_back(VehicleType("", "G5"));
    logo.TypeList.push_back(VehicleType("727", ""));
    logo.TypeList.push_back(VehicleType("", "G3"));
    logo.TypeList.push_back(VehicleType("727", ""));
    logo.TypeList.push_back(VehicleType("737EV", ""));
    logo.TypeList.push_back(VehicleType("", "EX1"));
    logo_list.push_back(logo);

    logo.name_CHS = "沃尔沃", logo.name_ENG = "Volvo group";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("", "C30"));
    logo.TypeList.push_back(VehicleType("", "S40"));
    logo.TypeList.push_back(VehicleType("", "V40"));
    logo.TypeList.push_back(VehicleType("", "S40"));
    logo.TypeList.push_back(VehicleType("", "S60"));
    logo.TypeList.push_back(VehicleType("", "S60 Polestar"));
    logo.TypeList.push_back(VehicleType("", "S60L"));
    logo.TypeList.push_back(VehicleType("", "S80"));
    logo.TypeList.push_back(VehicleType("", "S90"));
    logo.TypeList.push_back(VehicleType("", "S80L"));
    logo.TypeList.push_back(VehicleType("", "XC60"));
    logo.TypeList.push_back(VehicleType("", "XC90"));
    logo.TypeList.push_back(VehicleType("", "XC40"));
    logo.TypeList.push_back(VehicleType("", "XC CLASSIC"));
    logo.TypeList.push_back(VehicleType("", "C70"));
    logo.TypeList.push_back(VehicleType("", "P1800"));
    logo.TypeList.push_back(VehicleType("", "V60"));
    logo.TypeList.push_back(VehicleType("", "V60 Polestar"));
    logo.TypeList.push_back(VehicleType("", "V90"));
    logo_list.push_back(logo);

    logo.name_CHS = "五菱", logo.name_ENG = "SGMW";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("宏光", ""));
    logo.TypeList.push_back(VehicleType("宏光S", ""));
    logo.TypeList.push_back(VehicleType("宏光S1", ""));
    logo.TypeList.push_back(VehicleType("鸿途", ""));
    logo.TypeList.push_back(VehicleType("荣光", ""));
    logo.TypeList.push_back(VehicleType("荣光S", ""));
    logo.TypeList.push_back(VehicleType("荣光V", ""));
    logo.TypeList.push_back(VehicleType("荣光新卡", ""));
    logo.TypeList.push_back(VehicleType("荣光小卡", ""));
    logo.TypeList.push_back(VehicleType("兴旺", ""));
    logo.TypeList.push_back(VehicleType("征程", ""));
    logo.TypeList.push_back(VehicleType("之光", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "五十铃", logo.name_ENG = "ISUZU";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("庆铃TAGA皮卡", ""));
    logo.TypeList.push_back(VehicleType("皮卡", ""));
    logo.TypeList.push_back(VehicleType("N系列", ""));
    logo.TypeList.push_back(VehicleType("T系列", ""));
    logo.TypeList.push_back(VehicleType("F系列", ""));
    logo.TypeList.push_back(VehicleType("D-MAX", ""));
    logo.TypeList.push_back(VehicleType("mu-X牧游侠", ""));
    logo.TypeList.push_back(VehicleType("瑞迈", ""));
    logo.TypeList.push_back(VehicleType("铃拓", ""));
    logo.TypeList.push_back(VehicleType("", "MU-X"));
    logo_list.push_back(logo);

    logo.name_CHS = "夏利", logo.name_ENG = "xiali";
    logo.TypeList.clear();
    logo_list.push_back(logo);

    logo.name_CHS = "雪佛兰", logo.name_ENG = "Chevrolet";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("沃兰多", ""));
    logo.TypeList.push_back(VehicleType("科沃兹", ""));
    logo.TypeList.push_back(VehicleType("探界者", ""));
    logo.TypeList.push_back(VehicleType("迈锐宝XL", ""));
    logo.TypeList.push_back(VehicleType("迈锐宝", ""));
    logo.TypeList.push_back(VehicleType("科鲁兹", ""));
    logo.TypeList.push_back(VehicleType("赛欧3", ""));
    logo.TypeList.push_back(VehicleType("创酷", ""));
    logo.TypeList.push_back(VehicleType("科帕奇", ""));
    logo.TypeList.push_back(VehicleType("乐风RV", ""));
    logo.TypeList.push_back(VehicleType("乐风", ""));
    logo.TypeList.push_back(VehicleType("赛欧", ""));
    logo.TypeList.push_back(VehicleType("景程", ""));
    logo.TypeList.push_back(VehicleType("乐骋", ""));
    logo.TypeList.push_back(VehicleType("爱唯欧", ""));
    logo.TypeList.push_back(VehicleType("科鲁泽", ""));
    logo.TypeList.push_back(VehicleType("科迈罗", ""));
    logo.TypeList.push_back(VehicleType("探际者", ""));
    logo.TypeList.push_back(VehicleType("索罗德", ""));
    logo.TypeList.push_back(VehicleType("库罗德", ""));
    logo.TypeList.push_back(VehicleType("开拓者", ""));
    logo.TypeList.push_back(VehicleType("沃蓝达", ""));
    logo.TypeList.push_back(VehicleType("科帕奇", ""));
    logo.TypeList.push_back(VehicleType("斯帕可", ""));
    logo.TypeList.push_back(VehicleType("", "EXPRESS"));
    logo.TypeList.push_back(VehicleType("科尔维特", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "雪铁龙", logo.name_ENG = "Citroen";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("天逸 C5 AIRCROSS", ""));
    logo.TypeList.push_back(VehicleType("云逸 C4 AIRCROSS", ""));
    logo.TypeList.push_back(VehicleType("爱丽舍", ""));
    logo.TypeList.push_back(VehicleType("C4世嘉", ""));
    logo.TypeList.push_back(VehicleType("", "C5"));
    logo.TypeList.push_back(VehicleType("", "C6"));
    logo.TypeList.push_back(VehicleType("", "C3-XR"));
    logo.TypeList.push_back(VehicleType("", "C4L"));
    logo.TypeList.push_back(VehicleType("世嘉", ""));
    logo.TypeList.push_back(VehicleType("凯旋", ""));
    logo.TypeList.push_back(VehicleType("富康", ""));
    logo.TypeList.push_back(VehicleType("", "C2"));
    logo.TypeList.push_back(VehicleType("萨拉-毕加索", ""));
    logo.TypeList.push_back(VehicleType("赛纳", ""));
    logo.TypeList.push_back(VehicleType("", "C4 PICASSO"));
    logo.TypeList.push_back(VehicleType("", "C4"));
    logo.TypeList.push_back(VehicleType("", "C6"));
    logo.TypeList.push_back(VehicleType("", "C5"));
    logo.TypeList.push_back(VehicleType("", "C4 AIRCROSS"));
    logo_list.push_back(logo);

    logo.name_CHS = "扬子", logo.name_ENG = "";
    logo.TypeList.clear();
    logo.TypeList.push_back(VehicleType("猎豹CT5", ""));
    logo.TypeList.push_back(VehicleType("猎豹飞扬", ""));
    logo_list.push_back(logo);

    logo.name_CHS = "一汽", logo.name_ENG = "FAW";
       logo.TypeList.clear();
       logo.TypeList.push_back(VehicleType("森雅R9", ""));
       logo.TypeList.push_back(VehicleType("森雅R7", ""));
       logo.TypeList.push_back(VehicleType("佳宝V52", ""));
       logo.TypeList.push_back(VehicleType("佳宝V80", ""));
       logo.TypeList.push_back(VehicleType("解放T80", ""));
       logo.TypeList.push_back(VehicleType("", "V75"));
       logo.TypeList.push_back(VehicleType("", "V77"));
       logo.TypeList.push_back(VehicleType("佳宝T51", ""));
       logo.TypeList.push_back(VehicleType("佳宝T57", ""));
       logo.TypeList.push_back(VehicleType("佳宝T50", ""));
       logo.TypeList.push_back(VehicleType("佳宝V55", ""));
       logo.TypeList.push_back(VehicleType("解放T90", ""));
       logo.TypeList.push_back(VehicleType("森雅M80", ""));
       logo.TypeList.push_back(VehicleType("森雅S80", ""));
       logo.TypeList.push_back(VehicleType("佳宝V70", ""));
       logo.TypeList.push_back(VehicleType("佳宝V70 Ⅱ", ""));
       logo.TypeList.push_back(VehicleType("奥星", ""));
       logo.TypeList.push_back(VehicleType("红旗", ""));
       logo_list.push_back(logo);

       logo.name_CHS = "依维柯", logo.name_ENG = "IVECO";
       logo.TypeList.clear();
       logo.TypeList.push_back(VehicleType("得意", ""));
       logo.TypeList.push_back(VehicleType("Daily欧胜", ""));
       logo.TypeList.push_back(VehicleType("", "Power Daily"));
       logo.TypeList.push_back(VehicleType("", "Ouba"));
       logo.TypeList.push_back(VehicleType("", "Venice"));
       logo.TypeList.push_back(VehicleType("康果", ""));
       logo.TypeList.push_back(VehicleType("都灵", ""));
       logo.TypeList.push_back(VehicleType("欧霸", ""));
       logo_list.push_back(logo);

       logo.name_CHS = "英菲尼迪", logo.name_ENG = "Infiniti";
       logo.TypeList.clear();
       logo.TypeList.push_back(VehicleType("", "QX50"));
       logo.TypeList.push_back(VehicleType("", "Q50L"));
       logo.TypeList.push_back(VehicleType("", "ESQ"));
       logo.TypeList.push_back(VehicleType("", "QX30"));
       logo.TypeList.push_back(VehicleType("", "QX60"));
       logo.TypeList.push_back(VehicleType("", "QX70"));
       logo.TypeList.push_back(VehicleType("", "QX80"));
       logo.TypeList.push_back(VehicleType("", "Q50"));
       logo.TypeList.push_back(VehicleType("", "Q60"));
       logo.TypeList.push_back(VehicleType("", "Q70L"));
       logo.TypeList.push_back(VehicleType("", "Q30"));
       logo.TypeList.push_back(VehicleType("", "EX"));
       logo.TypeList.push_back(VehicleType("", "FX"));
       logo.TypeList.push_back(VehicleType("", "G"));
       logo.TypeList.push_back(VehicleType("", "JX"));
       logo.TypeList.push_back(VehicleType("", "M"));
       logo.TypeList.push_back(VehicleType("", "QX"));
       logo_list.push_back(logo);

       logo.name_CHS = "永源飞碟", logo.name_ENG = "";
       logo.TypeList.clear();
       logo.TypeList.push_back(VehicleType("", "UFO"));
       logo.TypeList.push_back(VehicleType("", "UFO-A380"));
       logo_list.push_back(logo);

       logo.name_CHS = "驭胜", logo.name_ENG = "";
       logo.TypeList.clear();
       logo.TypeList.push_back(VehicleType("", "S330"));
       logo.TypeList.push_back(VehicleType("", "S350"));
       logo_list.push_back(logo);

       logo.name_CHS = "中华", logo.name_ENG = "zhonghua";
       logo.TypeList.clear();
       logo.TypeList.push_back(VehicleType("", "V7"));
       logo.TypeList.push_back(VehicleType("", "V6"));
       logo.TypeList.push_back(VehicleType("", "V3"));
       logo.TypeList.push_back(VehicleType("", "H3"));
       logo.TypeList.push_back(VehicleType("", "V5"));
       logo.TypeList.push_back(VehicleType("", "H530"));
       logo.TypeList.push_back(VehicleType("骏捷FRV", ""));
       logo.TypeList.push_back(VehicleType("中华", ""));
       logo.TypeList.push_back(VehicleType("骏捷", ""));
       logo.TypeList.push_back(VehicleType("", "H330"));
       logo.TypeList.push_back(VehicleType("", "H230"));
       logo.TypeList.push_back(VehicleType("酷宝", ""));
       logo.TypeList.push_back(VehicleType("", "H220"));
       logo.TypeList.push_back(VehicleType("骏捷FSV", ""));
       logo.TypeList.push_back(VehicleType("尊驰", ""));
       logo.TypeList.push_back(VehicleType("骏捷Cross", ""));
       logo.TypeList.push_back(VehicleType("", "H320"));
       logo.TypeList.push_back(VehicleType("中华豚", ""));
       logo.TypeList.push_back(VehicleType("", "H230EV"));
       logo_list.push_back(logo);

       logo.name_CHS = "中顺", logo.name_ENG = "";
       logo.TypeList.clear();
       logo.TypeList.push_back(VehicleType("世纪", ""));
       logo_list.push_back(logo);

       logo.name_CHS = "中兴", logo.name_ENG = "ZXAUTO";
       logo.TypeList.clear();
       logo.TypeList.push_back(VehicleType("大领主", ""));
       logo.TypeList.push_back(VehicleType("小老虎", ""));
       logo.TypeList.push_back(VehicleType("威虎", ""));
       logo.TypeList.push_back(VehicleType("旗舰", ""));
       logo.TypeList.push_back(VehicleType("无限", ""));
       logo.TypeList.push_back(VehicleType("田野皮卡", ""));
       logo.TypeList.push_back(VehicleType("中兴老虎", ""));
       logo.TypeList.push_back(VehicleType("福星皮卡", ""));
       logo.TypeList.push_back(VehicleType("长铃皮卡", ""));
       logo.TypeList.push_back(VehicleType("威虎G3", ""));
       logo.TypeList.push_back(VehicleType("福星SUV", ""));
       logo.TypeList.push_back(VehicleType("田野SUV", ""));
       logo.TypeList.push_back(VehicleType("驰野", ""));
       logo.TypeList.push_back(VehicleType("金狮", ""));
       logo.TypeList.push_back(VehicleType("海豹", ""));
       logo.TypeList.push_back(VehicleType("万禧龙", ""));
       logo.TypeList.push_back(VehicleType("", "C3"));
       logo.TypeList.push_back(VehicleType("", "GX3"));
       logo_list.push_back(logo);

       logo.name_CHS = "众泰", logo.name_ENG = "ZOTYE";
       logo.TypeList.clear();
       logo.TypeList.push_back(VehicleType("", "SR7"));
       logo.TypeList.push_back(VehicleType("", "SR9"));
       logo.TypeList.push_back(VehicleType("", "T300"));
       logo.TypeList.push_back(VehicleType("", "T500"));
       logo.TypeList.push_back(VehicleType("", "T600"));
       logo.TypeList.push_back(VehicleType("", "T600 Coupe"));
       logo.TypeList.push_back(VehicleType("", "T700"));
       logo.TypeList.push_back(VehicleType("", "T800"));
       logo.TypeList.push_back(VehicleType("大迈X5", ""));
       logo.TypeList.push_back(VehicleType("大迈X7", ""));
       logo.TypeList.push_back(VehicleType("", "Z360"));
       logo.TypeList.push_back(VehicleType("", "Z560"));
       logo.TypeList.push_back(VehicleType("", "Z700"));
       logo.TypeList.push_back(VehicleType("", "Z300"));
       logo.TypeList.push_back(VehicleType("", "Z500"));
       logo.TypeList.push_back(VehicleType("", "V10"));
       logo.TypeList.push_back(VehicleType("", "2008"));
       logo.TypeList.push_back(VehicleType("", "5008"));
       logo.TypeList.push_back(VehicleType("", "T200"));
       logo.TypeList.push_back(VehicleType("江南TT", "Z560"));
       logo.TypeList.push_back(VehicleType("", "Z100"));
       logo.TypeList.push_back(VehicleType("", "Z200HB"));
       logo.TypeList.push_back(VehicleType("", "Z200"));
       logo.TypeList.push_back(VehicleType("", "M300"));

       logo_list.push_back(logo);

       logo.name_CHS ="吉利全球鹰", logo.name_ENG = "GLEAGLE";
       logo.TypeList.clear();
       logo.TypeList.push_back(VehicleType("吉利全球鹰EX3", ""));
       logo.TypeList.push_back(VehicleType("吉利全球鹰K27", ""));
       logo_list.push_back(logo);

       logo.name_CHS = "吉利英伦", logo.name_CHS = "";
       logo.TypeList.clear();
       logo.TypeList.push_back(VehicleType("吉利", ""));
       logo.TypeList.push_back(VehicleType("英伦", ""));
       logo_list.push_back(logo);

   }

   bool ResultCollection::isLogo(std::string strLogo, std::string strClpp)
   {
       bool bResult = false;

       if(strLogo == "unsure")
       {
           bResult = true;
           return bResult;
       }

       if(strlen(strLogo.c_str()) == 0 || strlen(strClpp.c_str()) == 0)
       {
           bResult = false;
           return bResult;
       }
       if(strLogo.find(strClpp) != string::npos || strClpp.find(strLogo) != string::npos)
       {
           bResult = true;
       }
       else
       {
          //把字符串中的字母全部转成大写，来不区分大小写
          hl::str2upper(strLogo);
          hl::str2upper(strClpp);
          char achMaxSub1[200] = {0};
          hl::FindMaxsubstr(strLogo.c_str(), strClpp.c_str(), achMaxSub1);
          if(strlen(achMaxSub1) >= 6)
          {//ubuntu一个汉字占三个字节
              bResult = true;
              return bResult;
          }

           unsigned int nIndex1 = 0;
           for(; nIndex1 < logo_list.size(); nIndex1++)
           {
               VehicleLogo logo = logo_list[nIndex1];
               if(strlen(logo.name_CHS.c_str()) > 0)
               {
                   hl::str2upper(logo.name_CHS);
               }
               if(strlen(logo.name_ENG.c_str()) > 0)
               {
                   hl::str2upper(logo.name_ENG);
               }
               if(logo.name_CHS.find(strLogo) != string::npos ||
                  logo.name_ENG.find(strLogo) != string::npos ||
                  (strLogo.find(logo.name_CHS) != string::npos && strlen(logo.name_CHS.c_str()) > 0) ||
                  (strLogo.find(logo.name_ENG) != string::npos && strlen(logo.name_ENG.c_str()) > 0))
               {//找到算法分析出来的车标所对应的映射表后，进行一一对比
                   char achMaxSub2[200] = {0};
                   char achMaxSub3[200] = {0};
                   if(strlen(logo.name_CHS.c_str()) > 0)
                   {
                       hl::FindMaxsubstr(strClpp.c_str(), logo.name_CHS.c_str(), achMaxSub2);
                   }
                   if(strlen(logo.name_ENG.c_str()) > 0)
                   {
                       hl::FindMaxsubstr(strClpp.c_str(), logo.name_ENG.c_str(), achMaxSub3);
                   }
                   if(logo.name_CHS.find(strClpp) != string::npos ||
                      logo.name_ENG.find(strClpp) != string::npos ||
                      (strClpp.find(logo.name_CHS) != string::npos && strlen(logo.name_CHS.c_str()) > 0) ||
                      (strClpp.find(logo.name_ENG) != string::npos && strlen(logo.name_ENG.c_str()) > 0) ||
                      strlen(achMaxSub2) >= 6 || strlen(achMaxSub3) >=2)
                   {
                       bResult = true;
                       return bResult;
                   }
                   else
                   {
                       unsigned int nIndex2 = 0;
                       for(;nIndex2 < logo.TypeList.size();nIndex2++)
                       {
                           char achMaxSub4[200] = {0};
                           char achMaxSub5[200] = {0};
                           if(strlen(logo.TypeList[nIndex2].name_CHS.c_str()) > 0)
                           {
                               hl::str2upper(logo.TypeList[nIndex2].name_CHS);
                               hl::FindMaxsubstr(strClpp.c_str(), logo.TypeList[nIndex2].name_CHS.c_str(), achMaxSub4);
                           }
                           if(strlen(logo.TypeList[nIndex2].name_ENG.c_str()) > 0)
                           {
                               hl::str2upper(logo.TypeList[nIndex2].name_ENG);
                                hl::FindMaxsubstr(strClpp.c_str(), logo.TypeList[nIndex2].name_ENG.c_str(), achMaxSub5);
                           }
                           if(logo.TypeList[nIndex2].name_CHS.find(strClpp) != string::npos ||
                              logo.TypeList[nIndex2].name_ENG.find(strClpp) != string::npos ||
                              (strClpp.find(logo.TypeList[nIndex2].name_CHS) != string::npos && strlen(logo.TypeList[nIndex2].name_CHS.c_str()) > 0) ||
                              (strClpp.find(logo.TypeList[nIndex2].name_ENG) != string::npos && strlen(logo.TypeList[nIndex2].name_ENG.c_str()) > 0) ||
                              strlen(achMaxSub4) >=6 || strlen(achMaxSub5) >= 2)
                           {
                               bResult = true;
                               return bResult;
                           }
                       }
                   }
               }
           }
       }
       return bResult;
   }
   unsigned int ResultCollection::logo_sum = 0;
   unsigned int ResultCollection::logo_pass = 0;

   void ResultCollection::CompareLogo(std::string strPicPath, std::string strLogo)
   {
    /*   ofstream ofstreamFile;
       ofstreamFile.open("logotest.txt", ios::out | ios::app);

       logo_sum ++;
       if(isLogo(strLogo))
       {

           logo_pass ++;
           ofstreamFile << strPicPath<<" " << strLogo << " 通过 " << ", 通过率:" << logo_pass * 100/ logo_sum << "%" << endl;

       }
       else
       {
           ofstreamFile << strPicPath<<" " << strLogo << " 不通过 " << endl;
       }

       ofstreamFile.close(); */
   }
