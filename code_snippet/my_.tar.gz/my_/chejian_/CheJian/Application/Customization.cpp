#include <thread>

#include "Customization.h"
#include "trace_log.h"
#include "check_item.h"
#include "MySQL_DB.h"
#include "ResultCollection.h"

class SZ_non_local_vehicle {
public:
    std::string lsh;
    std::string jylb;
    std::string syxz;
    std::string clsbdh;
    std::string fzjg;
    std::string hphm;
    std::string hpzl;
    std::string clpp1;
    std::string clxh;
    std::string cllx;
    std::string zqf_path;
    std::string yhf_path;
    std::string cjh_path;
    std::string shjssj;
};

extern std::string g_photoFilePath;
extern std::string g_remoteServerIp;
extern std::string g_remoteServerPort;
extern std::string g_photoUri;
extern bool g_TestMode;

std::string occi_convertString(char *data);
void get_VIN_Photo(vehicle_inf *p_vehicle_inf);
void get_LeftFront_Photo(vehicle_inf *p_vehicle_inf);

/*
苏州外地车，车架号和左前方历史照片，功能说明：
条件：发证机构非“苏E”，就是外地车
1. 如果照片m_zplist里面有，就直接用；
   如果没有，就去数据库查上一个周期（去年）的照片。
   如果去年也没有，就一直增加查询周期，直到数据库中的第一条数据。
2. 查到了，当做档案照片来用，传给算法
3. 没查到，则只判定当前车架号（左前方）照片，不做档案照片的相关条目比较

如果查到了，会把照片加入m_zplist里面：
车架号历史照片类型是J_HIS
左前方历史照片类型是A_HIS
*/
void getHistoryPhoto(vehicle_inf *p_vehicle_inf)
{
    if (g_TestMode) {
        return;
    }

    if (p_vehicle_inf->m_fzjg == "苏E") {
        return;
    }

    get_VIN_Photo(p_vehicle_inf);
    get_LeftFront_Photo(p_vehicle_inf);
}

void get_VIN_Photo(vehicle_inf *p_vehicle_inf)
{
    /* 如果m_zplist里面没有车架号照片，则不需要去获取上个周期的照片 */
    bool find_cjh_photo = false;
    for (unsigned int i = 0; i < p_vehicle_inf->m_zplist.size(); i++) {
        if (p_vehicle_inf->m_zplist[i].zptype == "0113") {
            find_cjh_photo = true;
            break;
        }
    }

    if (!find_cjh_photo) {
        return;
    }

    for (unsigned int i = 0; i < p_vehicle_inf->m_zplist.size(); i++) {
        if (p_vehicle_inf->m_zplist[i].zptype == "J") {
            return; /* 已经有车架号档案照片，则无需再获取上个周期的照片 */
        }
    }

    if ((p_vehicle_inf->m_hphm == "无数据") || (p_vehicle_inf->m_fzjg == "无数据")) {
        DATA_PRINT(LEVEL_ERROR, "HPHM(%s) or FZJG(%s) is invalid, can not get VIN history photo from Oracle database! LSH: %s \n",
                   p_vehicle_inf->m_hphm.data(), p_vehicle_inf->m_fzjg.data(), p_vehicle_inf->m_jylsh.data());
        return;
    }

    DATA_PRINT(LEVEL_INFO, "Start get VIN history photo from Oracle database, LSH(%s) \n", p_vehicle_inf->m_jylsh.data());

    /*
    苏州车管所提供的服务名是“jg_244”，实际测试oracle服务器返回错误“无法识别这个服务名”。
    所以现在使用orcl服务名。
    */
    occi_wrap occi;
    if (!occi.connect("shyk", "shykysj001", "192.168.0.252:1521/orcl")) {
        DATA_PRINT(LEVEL_ERROR, "Can not connect to Oracle database: 192.168.0.252:1521/orcl \n");
        return;
    }

    /*
    循环查找上个周期的照片。
    oracle数据里SHJSSJ最旧的一条是：2014-04-10
    因此当prev_year是2013时，终止查找
    */
    unsigned int year_count = 0;
    std::string history_LSH;

    while (true) {

        std::time_t t = std::time(NULL);
        std::tm *st = std::localtime(&t);
        std::string prev_year = std::to_string(st->tm_year + 1900 - 1 - year_count);
        std::string current_year = std::to_string(st->tm_year + 1900 - year_count);

        if (prev_year == "2013") {
            break;
        }

        /*
        查询语句的限制条件有3个：去年（使用审核结束时间SHJSSJ来判定），车牌号，发证机构。
        没有使用车架号，是因为车牌号有索引，车架号没有。
        实际测试：使用这个组合，查询时间大约0.02秒。使用车架号，查询时间大约4秒。

        “更新时间GXSJ”这个字段有索引，但是没有用它作为去年的判定，是因为：
        用Navicat测试时，发现一辆车，它的“更新时间”是2017年。但是其它和检验相关的时间都是2014年。
        说明这个字段可能与实际检验时间产生较大的差异。
        */
        std::string sql;
        sql = "SELECT LSH FROM \"TRFFPN_APP\".\"VEH_IS_FLOW\" WHERE SHJSSJ >= TO_DATE('";
        sql += prev_year + "0101";
        sql += "','yyyymmdd') AND SHJSSJ < TO_DATE('";
        sql += current_year + "0101";
        sql += "','yyyymmdd') AND HPHM = '";
        sql += p_vehicle_inf->m_hphm + "' AND FZJG = '";
        sql += p_vehicle_inf->m_fzjg + "'";

        DATA_PRINT(LEVEL_DEBUG, "%s \n", sql.data());

        if (!(occi.createStatement(sql.c_str()) && occi.executeQuery())) {
            DATA_PRINT(LEVEL_ERROR, "createStatement() or executeQuery() fail! \n");
            occi.disconnect();
            return;
        }

        if (occi.NotEndFetch()) {
            history_LSH = occi_convertString(occi.getString(1));
        }

        occi.closeQuery();
        occi.terminateStatement();

        if (history_LSH.empty()) {
            DATA_PRINT(LEVEL_INFO, "Could not find LSH from \"VEH_IS_FLOW\", SQL Statement: %s \n", sql.data());
            year_count++;
        } else {
            break;
        }
    }

    if (history_LSH.empty()) {
        DATA_PRINT(LEVEL_INFO, "Could not find LSH from \"VEH_IS_FLOW\", FZJG: %s, HPHM: %s \n ",
                   p_vehicle_inf->m_fzjg.data(),
                   p_vehicle_inf->m_hphm.data());

        occi.disconnect();
        return;
    }

    DATA_PRINT(LEVEL_INFO, "Vehicle history LSH is %s \n", history_LSH.data());

    std::string sql;
    sql = "SELECT ZP FROM \"TRFFPN_IMG\".\"VEH_IS_PHOTO\" WHERE LSH = '";
    sql += history_LSH + "' AND ZPZL = '0113'";

    if (!(occi.createStatement(sql.c_str()) && occi.executeQuery())) {
        DATA_PRINT(LEVEL_ERROR, "createStatement() or executeQuery() fail! \n");
        occi.disconnect();
        return;
    }

    if (!occi.NotEndFetch()) {
        DATA_PRINT(LEVEL_INFO, "Could not find ZP from \"VEH_IS_PHOTO\", SQL Statement: %s \n", sql.data());
        occi.disconnect();
        return;
    }

    unsigned int length;
    unsigned char *photo_buff = occi.getBlob(1, length);
    if (photo_buff == NULL) {
        DATA_PRINT(LEVEL_INFO, "Photo blob data is NULL, history LSH is %s \n", history_LSH.data());
        occi.disconnect();
        return;
    }

    /* 构建照片路径和名称(与正常下载照片相同的路径) */
    std::string photo_name;
    {
        photo_name = g_photoFilePath;

        std::time_t t = std::time(NULL);
        std::tm *st = std::localtime(&t);
        char tmpArray[128] = { 0 };
        sprintf(tmpArray, "%d-%02d-%02d", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);
        std::string strCurTime = tmpArray;
        photo_name += strCurTime;

        struct stat st_buf = {};
        stat(photo_name.c_str(), &st_buf);
        if ((st_buf.st_mode & S_IFMT) != S_IFDIR) {
            mkdir(photo_name.c_str(), 0777);
        }

        photo_name += "/J_HIS_" + p_vehicle_inf->m_hphm + "_" + p_vehicle_inf->m_clsbdh;
    }

    FILE *fp = std::fopen(photo_name.data(), "wb");
    if (!fp) {
        DATA_PRINT(LEVEL_ERROR, "Could not create file:%s \n", photo_name.data());
        occi.disconnect();
        free(photo_buff);
        return;
    }

    std::fseek(fp, 0, SEEK_SET);
    std::fwrite(photo_buff, 1, length, fp);
    std::fflush(fp);
    std::fclose(fp);
    free(photo_buff);
    occi.disconnect();

    _photo_resource photo;
    photo.zptype = "J_HIS";
    photo.local_path = photo_name;
    p_vehicle_inf->m_zplist.push_back(photo);
    DATA_PRINT(LEVEL_INFO, "VIN history photo has been saved(%s), LSH is %s \n",
               photo_name.data(), p_vehicle_inf->m_jylsh.data());
}

void get_LeftFront_Photo(vehicle_inf *p_vehicle_inf)
{
    /* 如果m_zplist里面没有左前方照片，则不需要去获取上个周期的照片 */
    bool find_zqf_photo = false;
    for (unsigned int i = 0; i < p_vehicle_inf->m_zplist.size(); i++) {
        if (p_vehicle_inf->m_zplist[i].zptype == "0111") {
            find_zqf_photo = true;
            break;
        }
    }

    if (!find_zqf_photo) {
        return;
    }

    for (unsigned int i = 0; i < p_vehicle_inf->m_zplist.size(); i++) {
        if (p_vehicle_inf->m_zplist[i].zptype == "A") {
            return; /* 已经有左前方档案照片，则无需再获取上个周期的照片 */
        }
    }

    if ((p_vehicle_inf->m_hphm == "无数据") || (p_vehicle_inf->m_fzjg == "无数据")) {
        DATA_PRINT(LEVEL_ERROR, "HPHM(%s) or FZJG(%s) is invalid, can not get 0111 history photo from Oracle database! LSH: %s \n",
                   p_vehicle_inf->m_hphm.data(), p_vehicle_inf->m_fzjg.data(), p_vehicle_inf->m_jylsh.data());
        return;
    }

    DATA_PRINT(LEVEL_INFO, "Start get 0111 history photo from Oracle database, LSH(%s) \n", p_vehicle_inf->m_jylsh.data());

    /*
    苏州车管所提供的服务名是“jg_244”，实际测试oracle服务器返回错误“无法识别这个服务名”。
    所以现在使用orcl服务名。
    */
    occi_wrap occi;
    if (!occi.connect("shyk", "shykysj001", "192.168.0.252:1521/orcl")) {
        DATA_PRINT(LEVEL_ERROR, "Can not connect to Oracle database: 192.168.0.252:1521/orcl \n");
        return;
    }

    /*
    循环查找上个周期的照片。
    oracle数据里SHJSSJ最旧的一条是：2014-04-10
    因此当prev_year是2013时，终止查找
    */
    unsigned int year_count = 0;
    std::string history_LSH;

    while (true) {
        std::time_t t = std::time(NULL);
        std::tm *st = std::localtime(&t);
        std::string prev_year = std::to_string(st->tm_year + 1900 - 1 - year_count);
        std::string current_year = std::to_string(st->tm_year + 1900 - year_count);

        if (prev_year == "2013") {
            break;
        }

        /*
        查询语句的限制条件有3个：去年（使用审核结束时间SHJSSJ来判定），车牌号，发证机构。
        没有使用车架号，是因为车牌号有索引，车架号没有。
        实际测试：使用这个组合，查询时间大约0.02秒。使用车架号，查询时间大约4秒。

        “更新时间GXSJ”这个字段有索引，但是没有用它作为去年的判定，是因为：
        用Navicat测试时，发现一辆车，它的“更新时间”是2017年。但是其它和检验相关的时间都是2014年。
        说明这个字段可能与实际检验时间产生较大的差异。
        */
        std::string sql;
        sql = "SELECT LSH FROM \"TRFFPN_APP\".\"VEH_IS_FLOW\" WHERE SHJSSJ >= TO_DATE('";
        sql += prev_year + "0101";
        sql += "','yyyymmdd') AND SHJSSJ < TO_DATE('";
        sql += current_year + "0101";
        sql += "','yyyymmdd') AND HPHM = '";
        sql += p_vehicle_inf->m_hphm + "' AND FZJG = '";
        sql += p_vehicle_inf->m_fzjg + "'";

        DATA_PRINT(LEVEL_DEBUG, "%s \n", sql.data());

        if (!(occi.createStatement(sql.c_str()) && occi.executeQuery())) {
            DATA_PRINT(LEVEL_ERROR, "createStatement() or executeQuery() fail! \n");
            occi.disconnect();
            return;
        }

        std::string history_LSH;
        if (occi.NotEndFetch()) {
            history_LSH = occi_convertString(occi.getString(1));
        }

        occi.closeQuery();
        occi.terminateStatement();

        if (history_LSH.empty()) {
            DATA_PRINT(LEVEL_INFO, "Could not find LSH from \"VEH_IS_FLOW\", SQL Statement: %s \n", sql.data());
            year_count++;
        } else {
            break;
        }
    }

    if (history_LSH.empty()) {
        DATA_PRINT(LEVEL_INFO, "Could not find LSH from \"VEH_IS_FLOW\", FZJG: %s, HPHM: %s \n ",
                   p_vehicle_inf->m_fzjg.data(),
                   p_vehicle_inf->m_hphm.data());

        occi.disconnect();
        return;
    }

    DATA_PRINT(LEVEL_INFO, "Vehicle history LSH is %s \n", history_LSH.data());

    std::string sql;
    sql = "SELECT ZP FROM \"TRFFPN_IMG\".\"VEH_IS_PHOTO\" WHERE LSH = '";
    sql += history_LSH + "' AND ZPZL = '0111'";

    if (!(occi.createStatement(sql.c_str()) && occi.executeQuery())) {
        DATA_PRINT(LEVEL_ERROR, "createStatement() or executeQuery() fail! \n");
        occi.disconnect();
        return;
    }

    if (!occi.NotEndFetch()) {
        DATA_PRINT(LEVEL_INFO, "Could not find ZP from \"VEH_IS_PHOTO\", SQL Statement: %s \n", sql.data());
        occi.disconnect();
        return;
    }

    unsigned int length;
    unsigned char *photo_buff = occi.getBlob(1, length);
    if (photo_buff == NULL) {
        DATA_PRINT(LEVEL_INFO, "Photo blob data is NULL, history LSH is %s \n", history_LSH.data());
        occi.disconnect();
        return;
    }

    /* 构建照片路径和名称(与正常下载照片相同的路径) */
    std::string photo_name;
    {
        photo_name = g_photoFilePath;

        std::time_t t = std::time(NULL);
        std::tm *st = std::localtime(&t);
        char tmpArray[128] = { 0 };
        sprintf(tmpArray, "%d-%02d-%02d", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);
        std::string strCurTime = tmpArray;
        photo_name += strCurTime;

        struct stat st_buf = {};
        stat(photo_name.c_str(), &st_buf);
        if ((st_buf.st_mode & S_IFMT) != S_IFDIR) {
            mkdir(photo_name.c_str(), 0777);
        }

        photo_name += "/A_HIS_" + p_vehicle_inf->m_hphm + "_" + p_vehicle_inf->m_clsbdh;
    }

    FILE *fp = std::fopen(photo_name.data(), "wb");
    if (!fp) {
        DATA_PRINT(LEVEL_ERROR, "Could not create file:%s \n", photo_name.data());
        occi.disconnect();
        free(photo_buff);
        return;
    }

    std::fseek(fp, 0, SEEK_SET);
    std::fwrite(photo_buff, 1, length, fp);
    std::fflush(fp);
    std::fclose(fp);
    free(photo_buff);
    occi.disconnect();

    _photo_resource photo;
    photo.zptype = "A_HIS";
    photo.local_path = photo_name;
    p_vehicle_inf->m_zplist.push_back(photo);
    DATA_PRINT(LEVEL_INFO, "0111 history photo has been saved(%s), LSH is %s \n",
               photo_name.data(), p_vehicle_inf->m_jylsh.data());
}

/* 为了解决苏州本地车经常出现照片列表中没有档案照片的情况，由程序自动追加A和J的照片 */
void addPhoto_A_J(vehicle_inf *p_vehicle_inf)
{
    if (g_TestMode) {
        return;
    }

    if (p_vehicle_inf->m_fzjg != "苏E") {
        return;
    }

    bool find_0111 = false;
    bool find_0113 = false;
    bool find_A = false;
    bool find_J = false;

    for (unsigned int i = 0; i < p_vehicle_inf->m_zplist.size(); i++) {
        if (p_vehicle_inf->m_zplist[i].zptype == "0111") {
            find_0111 = true;
        } else if (p_vehicle_inf->m_zplist[i].zptype == "0113") {
            find_0113 = true;
        } else if (p_vehicle_inf->m_zplist[i].zptype == "A") {
            find_A = true;
        } else if (p_vehicle_inf->m_zplist[i].zptype == "J") {
            find_J = true;
        }
    }

    /* 只有m_zplist里面有左前方照片，才需要A照片 */
    if (find_0111 && !find_A) {
        std::string uri =  "http://" + g_remoteServerIp + ":" + g_remoteServerPort + "/" + g_photoUri;
        uri += "/vehisphoto.vehis?method=getVehIsVehPictureBlob&lsh=" + p_vehicle_inf->m_jylsh + "&lb=" "A";

        _photo_resource photo;
        photo.zptype = "A";
        photo.zpurl = uri;
        photo.local_path = "TBD";
        p_vehicle_inf->m_zplist.push_back(photo);

        DATA_PRINT(LEVEL_INFO, "Auto add photo A to zplist, URL:%s \n", photo.zpurl.data());
    }

    /* 只有m_zplist里面有车架号照片，才需要J照片 */
    if (find_0113 && !find_J) {
        std::string uri =  "http://" + g_remoteServerIp + ":" + g_remoteServerPort + "/" + g_photoUri;
        uri += "/vehisphoto.vehis?method=getVehIsVehPictureBlob&lsh=" + p_vehicle_inf->m_jylsh + "&lb=" "J";

        _photo_resource photo;
        photo.zptype = "J";
        photo.zpurl = uri;
        photo.local_path = "TBD";
        p_vehicle_inf->m_zplist.push_back(photo);

        DATA_PRINT(LEVEL_INFO, "Auto add photo J to zplist, URL:%s \n", photo.zpurl.data());
    }
}

/****************************************人工审核结果同步（start）****************************************************/

#define PASS_ITEM_COUNT 19

struct manual_pass {
    std::string item[PASS_ITEM_COUNT];
};

#define FAIL_ITEM_COUNT 18

struct manual_fail {
    std::string item[FAIL_ITEM_COUNT];
};

void manual_summary(std::vector<manual_pass> pass, std::vector<manual_fail> fail);
void machine_manual_compare(MySQL_DB db, std::vector<manual_pass> pass, std::vector<manual_fail> fail);
std::vector<std::string> fillManual(std::string wtgyy);
std::vector<std::string> analyseWTGYY(std::string wtgyy);

/* 人工审核结果数据库同步线程 */
void synchronizeManualResult_Thread(std::string user, std::string password, std::string connectString)
{
    if (g_TestMode) {
        return;
    }

    /*
    考虑到oracle端数据库的系统时间有可能和本机不一致。
    采用延迟20分钟来同步数据。
    一次同步的数据量是30分钟的数据。
    假设现在时间是：10：57：17
    那么同步的时间段是：10：07：17～10：37：17
    */
    int delay_min = 20;

    std::string now;
    std::string HalfAnHour;

    /* 获取20分钟前的时间 */
    std::time_t t = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now() - std::chrono::minutes(delay_min));
    std::tm *st = std::localtime(&t);
    char tmpArray[128] = { 0 };
    sprintf(tmpArray, "%d-%02d-%02d %02d:%02d:%02d",
            st->tm_year + 1900, st->tm_mon + 1, st->tm_mday,
            st->tm_hour, st->tm_min, st->tm_sec);

    HalfAnHour = tmpArray;

    while (true) {
        std::this_thread::sleep_for(std::chrono::minutes(30));	/* 30 min */

        DATA_PRINT(LEVEL_INFO, "Start update table \"manual_pass\" and \"manual_fail\" ...... \n");

        std::time_t t = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now() - std::chrono::minutes(delay_min));
        std::tm *st = std::localtime(&t);
        char tmpArray[128] = { 0 };
        sprintf(tmpArray, "%d-%02d-%02d %02d:%02d:%02d",
                st->tm_year + 1900, st->tm_mon + 1, st->tm_mday,
                st->tm_hour, st->tm_min, st->tm_sec);

        now = tmpArray;

        std::vector<manual_pass> pass;
        std::vector<manual_fail> fail;

        DATA_PRINT(LEVEL_INFO, "Start obtain manual data from Oracle database...... \n");

        occi_wrap occi;

        /* 保定由于有oracle集群，因此IP是动态的 */
        if (g_CheckItem.City == BAODING) {
            if (!BaoDing_connectOracleCluster(occi)) {
                HalfAnHour = now;
                continue;
            }
        } else {
            if (!occi.connect(user.data(), password.data(), connectString.data())) {
                DATA_PRINT(LEVEL_ERROR, "Can not connect to Oracle database: %s \n", connectString.data());
                HalfAnHour = now;
                continue;
            }
        }

        /* 查询manual_pass的数据 */
        {
            std::string sql = "SELECT ";
            sql += "LSH,";
            sql += "JYLSH,";
            sql += "JCXDH,";
            sql += "XH,";
            sql += "GLBM,";
            sql += "HPHM,";
            sql += "HPZL,";
            sql += "CLSBDH,";
            sql += "JYRQ,";
            sql += "CYRQ,";
            sql += "CYRY,";
            sql += "ZTBJ,";
            sql += "GXRQ,";
            sql += "JYJGBH,";
            sql += "JCZCYY,";
            sql += "FZJG,";
            sql += "JYW,";
            sql += "AZDM,";
            sql += "JYLB";

            sql += " FROM \"VIS_OUTSYN\".\"VEH_IS_CHECKPASS\"";

            /* 限制时间为过去的30分钟 */
            sql += " WHERE GXRQ >= TO_DATE('";
            sql += HalfAnHour;
            sql += "','yyyy-mm-dd hh24:mi:ss') AND ";
            sql += "GXRQ < TO_DATE('";
            sql += now;
            sql += "','yyyy-mm-dd hh24:mi:ss')";

            if (!(occi.createStatement(sql.c_str()) && occi.executeQuery())) {
                DATA_PRINT(LEVEL_ERROR, "createStatement() or executeQuery() fail! \n");
                HalfAnHour = now;
                occi.disconnect();
                continue;
            }

            while (occi.NotEndFetch()) {
                manual_pass result;

                result.item[0] = occi_convertString(occi.getString(1));
                result.item[1] = occi_convertString(occi.getString(2));
                result.item[2] = occi_convertString(occi.getString(3));
                result.item[3] = occi_convertString(occi.getString(4));
                result.item[4] = occi_convertString(occi.getString(5));
                result.item[5] = occi_convertString(occi.getString(6));
                result.item[6] = occi_convertString(occi.getString(7));
                result.item[7] = occi_convertString(occi.getString(8));

                date_t date;
                occi.getDate(9, date);
                char tmp[64] = { 0 };
                if (date.month == 0) {
                    result.item[8] = "NULL";
                } else {
                    sprintf(tmp, "%d-%02d-%02d %02d:%02d:%02d",
                            date.year, date.month, date.day, date.hour, date.min, date.sec);
                    result.item[8] = tmp;
                }

                occi.getDate(10, date);
                if (date.month == 0) {
                    result.item[9] = "NULL";
                } else {
                    sprintf(tmp, "%d-%02d-%02d %02d:%02d:%02d",
                            date.year, date.month, date.day, date.hour, date.min, date.sec);
                    result.item[9] = tmp;
                }

                result.item[10] = occi_convertString(occi.getString(11));
                result.item[11] = occi_convertString(occi.getString(12));

                occi.getDate(13, date);
                if (date.month == 0) {
                    result.item[12] = "NULL";
                } else {
                    sprintf(tmp, "%d-%02d-%02d %02d:%02d:%02d",
                            date.year, date.month, date.day, date.hour, date.min, date.sec);
                    result.item[12] = tmp;
                }

                result.item[13] = occi_convertString(occi.getString(14));
                result.item[14] = occi_convertString(occi.getString(15));
                result.item[15] = occi_convertString(occi.getString(16));
                result.item[16] = occi_convertString(occi.getString(17));
                result.item[17] = occi_convertString(occi.getString(18));
                result.item[18] = occi_convertString(occi.getString(19));

                pass.push_back(result);
            }

            occi.closeQuery();
            occi.terminateStatement();
        }

        /* 查询manual_fail的数据 */
        {
            std::string sql = "SELECT ";
            sql += "LSH,";
            sql += "JYLSH,";
            sql += "JCXDH,";
            sql += "XH,";
            sql += "GLBM,";
            sql += "HPHM,";
            sql += "HPZL,";
            sql += "CLSBDH,";
            sql += "JYRQ,";
            sql += "MSXX,";
            sql += "CYRQ,";
            sql += "CYRY,";
            sql += "HQBJ,";
            sql += "HQSJ,";
            sql += "JYJGBH,";
            sql += "FZJG,";
            sql += "JYW,";
            sql += "WTGYY";

            sql += " FROM \"TRFFPN_APP\".\"VEH_IS_CHECKNOPASS\"";

            /* 限制时间为过去的30分钟 */
            sql += " WHERE CYRQ >= TO_DATE('";
            sql += HalfAnHour;
            sql += "','yyyy-mm-dd hh24:mi:ss') AND ";
            sql += "CYRQ < TO_DATE('";
            sql += now;
            sql += "','yyyy-mm-dd hh24:mi:ss')";

            if (!(occi.createStatement(sql.c_str()) && occi.executeQuery())) {
                DATA_PRINT(LEVEL_ERROR, "createStatement() or executeQuery() fail! \n");
                HalfAnHour = now;
                occi.disconnect();
                continue;
            }

            while (occi.NotEndFetch()) {
                manual_fail result;

                result.item[0] = occi_convertString(occi.getString(1));
                result.item[1] = occi_convertString(occi.getString(2));
                result.item[2] = occi_convertString(occi.getString(3));
                result.item[3] = occi_convertString(occi.getString(4));
                result.item[4] = occi_convertString(occi.getString(5));
                result.item[5] = occi_convertString(occi.getString(6));
                result.item[6] = occi_convertString(occi.getString(7));
                result.item[7] = occi_convertString(occi.getString(8));

                date_t date;
                occi.getDate(9, date);
                char tmp[64] = { 0 };
                if (date.month == 0) {
                    result.item[8] = "NULL";
                } else {
                    sprintf(tmp, "%d-%02d-%02d %02d:%02d:%02d",
                            date.year, date.month, date.day, date.hour, date.min, date.sec);
                    result.item[8] = tmp;
                }

                result.item[9] = occi_convertString(occi.getString(10));

                occi.getDate(11, date);
                if (date.month == 0) {
                    result.item[10] = "NULL";
                } else {
                    sprintf(tmp, "%d-%02d-%02d %02d:%02d:%02d",
                            date.year, date.month, date.day, date.hour, date.min, date.sec);
                    result.item[10] = tmp;
                }

                result.item[11] = occi_convertString(occi.getString(12));
                result.item[12] = occi_convertString(occi.getString(13));

                occi.getDate(14, date);
                if (date.month == 0) {
                    result.item[13] = "NULL";
                } else {
                    sprintf(tmp, "%d-%02d-%02d %02d:%02d:%02d",
                            date.year, date.month, date.day, date.hour, date.min, date.sec);
                    result.item[13] = tmp;
                }

                result.item[14] = occi_convertString(occi.getString(15));
                result.item[15] = occi_convertString(occi.getString(16));
                result.item[16] = occi_convertString(occi.getString(17));
                result.item[17] = occi_convertString(occi.getString(18));

                fail.push_back(result);
            }

            occi.closeQuery();
            occi.terminateStatement();
        }

        occi.disconnect();

        HalfAnHour = now;
        DATA_PRINT(LEVEL_INFO, "The manual data has been obtained, and begin to insert MySQL database. \n");

        MySQL_DB db;
        if (db.connect(NULL, 6033, "root", getDBPassWord(DBPWD).c_str(), "car_schema")) {
            std::string sqlString;

            for (unsigned int i = 0; i < pass.size(); i++) {
                sqlString = "("
                            "lsh, jylsh, jcxdh, xh, glbm, hphm, hpzl, clsbdh, jyrq, cyrq, "
                            "cyry, ztbj, gxrq, jyjgbh, jczcyy, fzjg, jyw, azdm, jylb"
                            ")"
                            " VALUES "
                            "(";

                for (unsigned int k = 0; k < PASS_ITEM_COUNT; k++) {
                    if (pass[i].item[k] != "NULL") {
                        sqlString += "'" + pass[i].item[k] + "'";
                    } else {
                        sqlString += pass[i].item[k];
                    }

                    if (k != (PASS_ITEM_COUNT - 1)) {
                        sqlString += ",";
                    }
                }

                sqlString += ")";

                db.insert("manual_pass", sqlString.c_str());
            }

            for (unsigned int i = 0; i < fail.size(); i++) {
                sqlString = "("
                            "lsh, jylsh, jcxdh, xh, glbm, hphm, hpzl, clsbdh, jyrq, msxx, "
                            "cyrq, cyry, hqbj, hqsj, jyjgbh, fzjg, jyw, wtgyy"
                            ")"
                            " VALUES "
                            "(";

                for (unsigned int k = 0; k < FAIL_ITEM_COUNT; k++) {
                    if (fail[i].item[k] != "NULL") {
                        sqlString += "'" + fail[i].item[k] + "'";
                    } else {
                        sqlString += fail[i].item[k];
                    }

                    if (k != (FAIL_ITEM_COUNT - 1)) {
                        sqlString += ",";
                    }
                }

                sqlString += ")";

                db.insert("manual_fail", sqlString.c_str());
            }
        }

        db.disconnect();

        DATA_PRINT(LEVEL_INFO, "The table \"manual_pass\" and \"manual_fail\" has been updated. \n");

        manual_summary(pass, fail);
    }
}

void manual_summary(std::vector<manual_pass> pass, std::vector<manual_fail> fail)
{
    DATA_PRINT(LEVEL_INFO, "Start update table \"manual_summary\" ...... \n");

    std::string sqlString;

    MySQL_DB db;
    if (db.connect(NULL, 6033, "root", getDBPassWord(DBPWD).c_str(), "car_schema")) {
        /* 汇总人工通过的 */
        for (unsigned int i = 0; i < pass.size(); i++) {
            sqlString = "("
                        "lsh, xsz, sqb, jqx, jybg, zqf, yhf, cjh, aqd, zdg, "
                        "ydg, zczd, cyjl, wrw, dpjy, yzzd, ezzd, result, shry, sjjg, "
                        "manual_time"
                        ")"
                        " VALUES "
                        "(";

            sqlString += "'" + pass[i].item[0] +  "',";
            sqlString += "'1','1','1','1','1','1','1','1','1','1',";
            sqlString += "'1','1','1','1','1','1','1',";
            sqlString += "'" + pass[i].item[10] +  "',";
            sqlString += "'" + pass[i].item[4] +  "',";
            sqlString += "'" + pass[i].item[12] +  "')";

            db.insert("manual_summary", sqlString.c_str());
        }

        /* 汇总人工不通过的,并记录不通过代码 */
        for (unsigned int i = 0; i < fail.size(); i++) {
            sqlString = "("
                        "lsh, xsz, sqb, jqx, jybg, zqf, yhf, cjh, aqd, zdg, "
                        "ydg, zczd, cyjl, wrw, dpjy, yzzd, ezzd, result, shry, sjjg, "
                        "manual_time"
                        ")"
                        " VALUES "
                        "(";

            sqlString += "'" + fail[i].item[0] +  "',";

            /* 如果result全为1，说明有16张照片以外的未通过原因 */
            std::vector<std::string> result = fillManual(fail[i].item[FAIL_ITEM_COUNT - 1]);
            for (unsigned int j = 0; j < result.size(); j++) {
                sqlString += "'" + result[j] + "',";
            }

            sqlString += "'0',";
            sqlString += "'" + fail[i].item[11] +  "',";
            sqlString += "'" + fail[i].item[4] +  "',";
            sqlString += "'" + fail[i].item[10] +  "'";
            sqlString += ")";

            db.insert("manual_summary", sqlString.c_str());

            /* 写入表manual_fail_detail */
            unsigned long id;
            if ((id = db.getLastID()) != 0) {
                std::vector<std::string> code = analyseWTGYY(fail[i].item[FAIL_ITEM_COUNT - 1]);

                for (unsigned int j = 0; j < code.size(); j++) {
                    sqlString = "(manual_summary_id, picture_code) VALUES (";
                    sqlString += "'" + std::to_string(id) +  "',";
                    sqlString += "'" + code[j] +  "')";
                    db.insert("manual_fail_detail", sqlString.c_str());
                }
            }
        }

        DATA_PRINT(LEVEL_INFO, "The table \"manual_summary\" has been updated. \n");

        machine_manual_compare(db, pass, fail);
    }

    db.disconnect();
}

void machine_manual_compare(MySQL_DB db, std::vector<manual_pass> pass, std::vector<manual_fail> fail)
{
    DATA_PRINT(LEVEL_INFO, "Start update the table \"machine_manual\" ...... \n");

    /*
    表machine_manual里面每张照片结果：
    0--机器通过，人工通过
    1--机器通过，人工不过
    2--机器不过，人工通过
    3--机器不过，人工不过
    */

    /* 照片编号顺序按照machine_manual里的字段顺寻 */
    std::vector<std::string> pictrue_type = {
        "0201", "0202", "0203", "0204", "0111", "0112", "0113", "0157", "0321", "0352",
        "0351", "0205", "0212", "0323", "0322", "0348"
    };

    std::time_t t = std::time(NULL);
    std::tm *st = std::localtime(&t);
    char tmpArray[128] = { 0 };
    sprintf(tmpArray, "%d-%02d-%02d", st->tm_year + 1900, st->tm_mon + 1, st->tm_mday);

    /* 比较人工审核通过的 */
    for (unsigned int i = 0; i < pass.size(); i++) {
        /* 机器审核没找到的照片按照通过计算 */
        std::vector<std::string> compare_result;
        for (unsigned int j = 0; j < 16; j++) {
            compare_result.push_back("0");
        }

        std::string sqlString = "SELECT vehicle_check_id,category,result FROM check_infos WHERE vehicle_check_id in "
                                "(select id from vehicle_checks where created_at > '";

        sqlString += std::string(tmpArray) + "' and jylsh = '";
        sqlString += pass[i].item[0] +"')";

        std::string vehicle_check_id;

        /* 查询机器审核结果 */
        DATA_PRINT(LEVEL_INFO, "查询机器审核结果sqlString:%s \n", sqlString.c_str());
        MYSQL_RES *result = db.getResult(sqlString.c_str());
        if (result != NULL) {
            MYSQL_ROW row = NULL;

            while ((row = mysql_fetch_row(result)) != NULL) {
                vehicle_check_id = row[0];

                unsigned int k;
                for (k = 0; k < pictrue_type.size(); k++) {
                    if (std::string(row[1]) == pictrue_type[k]) {

                         /* 机器审核结果不为1的，都算不通过 */
                        if (std::string(row[2]) != "1") {
                            compare_result[k] = "2";
                        }
                    }
                }
            }

            db.freeResult(result);
        }

        /* 由于vehicle_check_id是外键，如果该值为空，则不能写入数据库 */
        if (!vehicle_check_id.empty()) {
            sqlString = "("
                        "vehicle_check_id, lsh, xsz, sqb, jqx, jybg, zqf, yhf, cjh, aqd, zdg, "
                        "ydg, zczd, cyjl, wrw, dpjy, yzzd, ezzd, shry, glbm, "
                        "manual_time"
                        ")"
                        " VALUES "
                        "(";

            sqlString += "'" + vehicle_check_id + "',";
            sqlString += "'" + pass[i].item[0] + "',";

            for (unsigned int j = 0; j < compare_result.size(); j++) {
                sqlString += "'" + compare_result[j] + "',";
            }

            sqlString += "'" + pass[i].item[10] + "',";
            sqlString += "'" + pass[i].item[4] + "',";
            sqlString += "'" + pass[i].item[12] + "')";
            db.insert("machine_manual", sqlString.c_str());
        }
    }

    /* 比较人工审核未通过的 */
    for (unsigned int i = 0; i < fail.size(); i++) {
        std::vector<std::string> compare_result = fillManual(fail[i].item[FAIL_ITEM_COUNT - 1]);

        /* 机器审核没找到的照片按照通过计算 */
        for (unsigned int j = 0; j < compare_result.size(); j++) {
            if (compare_result[j] == "0") {
                compare_result[j] = "1";
            } else {
                compare_result[j] = "0";
            }
        }

        std::string sqlString = "SELECT vehicle_check_id,category,result FROM check_infos WHERE vehicle_check_id in "
                                "(select id from vehicle_checks where created_at > '";

        sqlString += std::string(tmpArray) + "' and jylsh = '";
        sqlString += fail[i].item[0] +"')";

        std::string vehicle_check_id;

        /* 查询机器审核结果 */
        DATA_PRINT(LEVEL_INFO, "查询机器审核结果sqlString:%s \n", sqlString.c_str());
        MYSQL_RES *result = db.getResult(sqlString.c_str());
        if (result != NULL) {
            MYSQL_ROW row = NULL;

            while ((row = mysql_fetch_row(result)) != NULL) {
                vehicle_check_id = row[0];

                unsigned int k;
                for (k = 0; k < pictrue_type.size(); k++) {
                    if (std::string(row[1]) == pictrue_type[k]) {

                         /* 机器审核结果不为1的，都算不通过 */
                        if (std::string(row[2]) != "1") {
                            if (compare_result[k] == "0") {
                                compare_result[k] = "2";
                            } else {
                                compare_result[k] = "3";
                            }
                        }
                    }
                }
            }

            db.freeResult(result);
        }

        /* 由于vehicle_check_id是外键，如果该值为空，则不能写入数据库 */
        if (!vehicle_check_id.empty()) {
            sqlString = "("
                        "vehicle_check_id, lsh, xsz, sqb, jqx, jybg, zqf, yhf, cjh, aqd, zdg, "
                        "ydg, zczd, cyjl, wrw, dpjy, yzzd, ezzd, shry, glbm, "
                        "manual_time"
                        ")"
                        " VALUES "
                        "(";

            sqlString += "'" + vehicle_check_id + "',";
            sqlString += "'" + fail[i].item[0] + "',";

            for (unsigned int j = 0; j < compare_result.size(); j++) {
                sqlString += "'" + compare_result[j] + "',";
            }

            sqlString += "'" + fail[i].item[11] +  "',";
            sqlString += "'" + fail[i].item[4] +  "',";
            sqlString += "'" + fail[i].item[10] + "')";
            db.insert("machine_manual", sqlString.c_str());
        }
    }

    DATA_PRINT(LEVEL_INFO, "The table \"machine_manual\" has been updated. \n");
}

/* 填充16张照片的人工审核结果 */
std::vector<std::string> fillManual(std::string wtgyy)
{
    std::vector<std::string> code = analyseWTGYY(wtgyy);

    /* 未通过原因代码表 */
    std::vector<std::vector<std::string>> list = {
        {   /* 0 行驶证 */
            "120101", "120115", "120116", "120144"
        },

        {   /* 1 牌证申请表 */
            "120217", "120218"
        },

        {   /* 2 交强险 */
            "120301", "120302", "120303", "120304", "120306", "120319", "120320", "120321", "120322"
        },

        {   /* 3 检验报告 */
            "120423", "120424", "120444"
        },

        {   /* 4 左前方 */
            "010133", "010135", "010505", "010506"
        },

        {   /* 5 右后方 */
            "010134", "010136"
        },

        {   /* 6 车架号 */
            "010137", "010138", "010304"
        },

        {   /* 7 安全带 */
            "012201", "012202"
        },

        {   /* 8 左灯光 */
            "070101", "070102", "070103", "070109", "070110", "070111"
        },

        {   /* 9 右灯光 */
            "070201", "070202", "070203", "070209", "070210"
        },

        {   /* 10 驻车制动 */
            "060501", "060514"
        },

        {   /* 11 查验记录表 */
            "121201", "121202", "121203", "121225", "121226"
        },

        {   /* 12 污染物 */
            "121001", "121002", "121044"
        },

        {   /* 13 底盘检验 */
            "040101"
        },

        {   /* 14 一轴 */
            "060109", "060111", "060118", "060119", "060120", "060121"
        },

        {   /* 15 二轴 */
            "060201", "060210", "060212"
        }
    };

    /* 填充16张照片的结果，默认通过 */
    std::vector<std::string> ret;
    for (unsigned int i = 0; i < 16; i++) {
        ret.push_back("1");
    }

    unsigned int i, j, k;
    for (i = 0; i < code.size(); i++) {
        /* 查询未通过代码是否在list中 */
        bool find = false;
        for (j = 0; j < list.size(); j++) {
            for (k = 0; k < list[j].size(); k++) {
                if (code[i] == list[j][k]) {
                    find = true;
                    break;
                }
            }

            if (find) {
                break;
            }
        }

        if (find) {
            ret[j] = "0";
        }
    }

    return ret;
}

/* 将未通过原因转化为未通过六位代码数组 */
std::vector<std::string> analyseWTGYY(std::string wtgyy)
{
    std::vector<std::string> code;
    std::string::size_type n;

    while ((n = wtgyy.find(",")) != std::string::npos) {
        code.push_back(wtgyy.substr(0, n));
        wtgyy = wtgyy.substr(n + 1);
    }

    if (!wtgyy.empty()) {
        code.push_back(wtgyy);
    }

    return code;
}

/****************************************人工审核结果同步（end）****************************************************/

/*
 *将苏州外地车（发证机构不是“苏E”）的左前，右后，车架号3种照片，从监管系统的oracle数据库，同步至本地mysql数据库。并将照片保存到本地。
 *注意：该函数已作废，不要调用。
*/
void synchronizeHistoryPhoto()
{
    DATA_PRINT(LEVEL_INFO, "Start synchronizing SuZhou non-local vehicle data...... \n");

    while (true) {
        std::time_t t = std::time(NULL);
        std::tm *st = std::localtime(&t);

        if ((st->tm_hour >= g_CheckItem.ShiJian.KaiShi) && (st->tm_hour < g_CheckItem.ShiJian.JieShu)) {
            DATA_PRINT(LEVEL_INFO, "The time limit has been reached, stop synchronizing data. \n");
            return;
        }

        /* 获取本地数据库的最后一条数据的“流水号” */
        std::string local_last_lsh;
        MySQL_DB db;
        if (db.connect(NULL, 6033, "root", getDBPassWord(DBPWD).c_str(), "car_schema")) {
            std::string sql = "SELECT lsh FROM suzhou_history_photo order by lsh desc limit 1";

            MYSQL_RES *result = db.getResult(sql.c_str());
            if (result != NULL) {
                MYSQL_ROW row = NULL;
                row = mysql_fetch_row(result);
                if (row != NULL) {
                    local_last_lsh = row[0];
                }

                db.freeResult(result);
            }
        }

        db.disconnect();

        /*
        苏州车管所提供的服务名是“jg_244”，实际测试oracle服务器返回错误“无法识别这个服务名”。
        所以现在使用orcl服务名。
        */
        occi_wrap occi;
        if (!occi.connect("shyk", "shykysj001", "192.168.0.252:1521/orcl")) {
            DATA_PRINT(LEVEL_ERROR, "Can not connect to Oracle database: 192.168.0.252:1521/orcl \n");
            return;
        }

        std::string sql;
        sql += "SELECT LSH FROM (";
        sql += "SELECT LSH FROM \"TRFFPN_APP\".\"VEH_IS_FLOW\" ";
        sql += "WHERE FZJG != '苏E' ORDER BY LSH DESC";
        sql += ") WHERE ROWNUM = 1";

        if (!(occi.createStatement(sql.c_str()) && occi.executeQuery())) {
            DATA_PRINT(LEVEL_ERROR, "createStatement() or executeQuery() fail, sql statement: %s \n", sql.data());
            occi.disconnect();
            return;
        }

        std::string remote_last_lsh;
        if (occi.NotEndFetch()) {
            remote_last_lsh = occi_convertString(occi.getString(1));
        }

        occi.closeQuery();
        occi.terminateStatement();

        if (remote_last_lsh == local_last_lsh) {
            DATA_PRINT(LEVEL_INFO, "The local last LSH is the same as remote LSH(%s), no need to synchronize data. \n", remote_last_lsh.data());
            occi.disconnect();
            return;
        }

        /* 本地最新流水号与远程不一致，开始进行同步 */

        if (local_last_lsh.empty()) {
            sql = "SELECT * FROM (";
            sql += "SELECT LSH,JYLB,SYXZ,CLSBDH,FZJG,HPHM,HPZL,CLPP1,CLXH,CLLX,SHJSSJ FROM \"TRFFPN_APP\".\"VEH_IS_FLOW\" ";
            sql += "WHERE FZJG != '苏E' ORDER BY LSH ASC";
            sql += ") WHERE ROWNUM = 100";
        } else {
            sql = "SELECT * FROM (";
            sql += "SELECT LSH,JYLB,SYXZ,CLSBDH,FZJG,HPHM,HPZL,CLPP1,CLXH,CLLX,SHJSSJ FROM \"TRFFPN_APP\".\"VEH_IS_FLOW\" ";
            sql += "WHERE LSH > '" + local_last_lsh + "' AND FZJG != '苏E' ORDER BY LSH ASC";
            sql += ") WHERE ROWNUM = 100";
        }

        if (!(occi.createStatement(sql.c_str()) && occi.executeQuery())) {
            DATA_PRINT(LEVEL_ERROR, "createStatement() or executeQuery() fail, sql statement: %s \n", sql.data());
            occi.disconnect();
            return;
        }

        std::vector<SZ_non_local_vehicle> vehicle_list;

        while (occi.NotEndFetch()) {
            SZ_non_local_vehicle vehicle;

            vehicle.lsh = occi_convertString(occi.getString(1));
            vehicle.jylb = occi_convertString(occi.getString(2));
            vehicle.syxz = occi_convertString(occi.getString(3));
            vehicle.clsbdh = occi_convertString(occi.getString(4));
            vehicle.fzjg = occi_convertString(occi.getString(5));
            vehicle.hphm = occi_convertString(occi.getString(6));
            vehicle.hpzl = occi_convertString(occi.getString(7));
            vehicle.clpp1 = occi_convertString(occi.getString(8));
            vehicle.clxh = occi_convertString(occi.getString(9));
            vehicle.cllx = occi_convertString(occi.getString(10));

            date_t date;
            occi.getDate(11, date);
            if (date.month != 0) {
                char tmpArray[64] = { 0 };
                sprintf(tmpArray, "%d%02d%02d %02d:%02d:%02d",
                        date.year, date.month, date.day, date.hour, date.min, date.sec);

                vehicle.shjssj = tmpArray;
            }

            vehicle_list.push_back(vehicle);
        }

        occi.closeQuery();
        occi.terminateStatement();

//        for (unsigned int i = 0; i < vehicle_list.size(); i++) {
//            sql = "SELECT ZPZL,ZP FROM \"TRFFPN_IMG\".\"VEH_IS_PHOTO\" WHERE LSH = '";
//            sql += history_LSH + "' AND ZPZL = '0113'";
//        }

        /* 以年月为单位，建立文件夹 */

        //To be continue......
        //勿忘处理重名照片

        occi.disconnect();
    }
}

/*
 *临沂，电子保单数据库查询。
*/
void getInsuranceResult(vehicle_inf *p_vehicle_inf)
{
    if (g_TestMode) {
        return;
    }

    if (p_vehicle_inf->m_clsbdh.empty() || p_vehicle_inf->m_clsbdh == "无数据") {
        return;
    }

    if (p_vehicle_inf->m_jssj.empty() || p_vehicle_inf->m_jssj == "无数据") {
        return;
    }

    ResultCollection tmp;
    std::string jssj = tmp.formatingDate(p_vehicle_inf->m_jssj);
    if (jssj.length() != 8) {
        DATA_PRINT(LEVEL_ERROR, "Invalid \"jssj\" : %s \n", jssj.data());
        return;
    }

    occi_wrap occi;
    if (!occi.connect("znsh", "znsh_3713", "192.168.100.23:1521/orcl")) {
        DATA_PRINT(LEVEL_ERROR, "Can not connect to Oracle database: 192.168.100.23:1521/orcl \n");
        return;
    }

    /* 根据当前时间获得更新时间的限制条件 */
    std::string gxsj_limit;
    {
        std::time_t t = std::time(NULL);
        std::tm *st = std::localtime(&t);
        char tmpArray[128] = { 0 };
        sprintf(tmpArray, "%d%02d01", st->tm_year + 1900 - 2, st->tm_mon + 1);
        gxsj_limit = tmpArray;
    }

    /* 限制更新时间为最近两年，是为了加快查询速度 */
    std::string sql;
    sql = "SELECT SXRQ,ZZRQ FROM "
          "("
          "SELECT SXRQ,ZZRQ FROM \"VIS_OUTSYN\".\"VEH_IS_INSURANCEINFO\" "
          "WHERE GXSJ >= TO_DATE('" + gxsj_limit + "', 'yyyymmdd') "
          "AND CLSBDH = '" + p_vehicle_inf->m_clsbdh + "' "
          "ORDER BY GXSJ DESC"
          ")"
          "WHERE ROWNUM = 1";

    if (!(occi.createStatement(sql.c_str()) && occi.executeQuery())) {
        DATA_PRINT(LEVEL_ERROR, "createStatement() or executeQuery() fail, sql statement: %s \n", sql.data());
        occi.disconnect();
        return;
    }

    std::string sxrq, zzrq;
    if (occi.NotEndFetch()) {
        date_t date;

        occi.getDate(1, date);
        if (date.month != 0) {
            char tmpArray[64] = { 0 };
            sprintf(tmpArray, "%d%02d%02d", date.year, date.month, date.day);
            sxrq = tmpArray;
        }

        occi.getDate(2, date);
        if (date.month != 0) {
            char tmpArray[64] = { 0 };
            sprintf(tmpArray, "%d%02d%02d", date.year, date.month, date.day);
            zzrq = tmpArray;
        }

        if (sxrq.length() == 8 && zzrq.length() == 8) {
            /*
             * 1. 检验结束日期大于保险终止日期，判定为“未查到”（这个情况一般是新的保单电子数据还没有写入到数据库，查到了去年的保单）
             * 2. 检验结束日期大于保险生效日期，并且小于保险终止日期，判定为“通过”
             * 3. 检验结束日期小于保险生效日期，判定为“不通过”（这个是车辆在检验时，保险还未生效）
            */
            if (jssj > zzrq) {
                p_vehicle_inf->insurance_result = 2;
            } else if (jssj >= sxrq && jssj <= zzrq) {
                p_vehicle_inf->insurance_result = 1;
            } else if (jssj < sxrq) {
                p_vehicle_inf->insurance_result = 0;
            }
        }
    }

    occi.closeQuery();
    occi.terminateStatement();

    if (p_vehicle_inf->insurance_result != 2) {
        occi.disconnect();
        return;
    }

    /* 如果从上面的表里面没有查到，再去归档表VEH_IS_INSURANCEINFO_ARC里面查 */
    sql = "SELECT SXRQ,ZZRQ FROM "
          "("
          "SELECT SXRQ,ZZRQ FROM \"TRFFPN_APP\".\"VEH_IS_INSURANCEINFO_ARC\" "
          "WHERE GXSJ >= TO_DATE('" + gxsj_limit + "', 'yyyymmdd') "
          "AND CLSBDH = '" + p_vehicle_inf->m_clsbdh + "' "
          "ORDER BY GXSJ DESC"
          ")"
          "WHERE ROWNUM = 1";

    if (!(occi.createStatement(sql.c_str()) && occi.executeQuery())) {
        DATA_PRINT(LEVEL_ERROR, "createStatement() or executeQuery() fail, sql statement: %s \n", sql.data());
        occi.disconnect();
        return;
    }

    if (occi.NotEndFetch()) {
        date_t date;

        occi.getDate(1, date);
        if (date.month != 0) {
            char tmpArray[64] = { 0 };
            sprintf(tmpArray, "%d%02d%02d", date.year, date.month, date.day);
            sxrq = tmpArray;
        }

        occi.getDate(2, date);
        if (date.month != 0) {
            char tmpArray[64] = { 0 };
            sprintf(tmpArray, "%d%02d%02d", date.year, date.month, date.day);
            zzrq = tmpArray;
        }

        if (sxrq.length() == 8 && zzrq.length() == 8) {
            /*
             * 1. 检验结束日期大于保险终止日期，判定为“未查到”（这个情况一般是新的保单电子数据还没有写入到数据库，查到了去年的保单）
             * 2. 检验结束日期大于保险生效日期，并且小于保险终止日期，判定为“通过”
             * 3. 检验结束日期小于保险生效日期，判定为“不通过”（这个是车辆在检验时，保险还未生效）
            */
            if (jssj > zzrq) {
                p_vehicle_inf->insurance_result = 2;
            } else if (jssj >= sxrq && jssj <= zzrq) {
                p_vehicle_inf->insurance_result = 1;
            } else if (jssj < sxrq) {
                p_vehicle_inf->insurance_result = 0;
            }
        }
    }

    occi.closeQuery();
    occi.terminateStatement();
    occi.disconnect();
}

/* 保定Oracle集群访问控制 */
bool BaoDing_connectOracleCluster(occi_wrap &occi)
{
    /* 为提高连接速度，每次连接时，会先使用上一次成功连接的地址 */
    static std::vector<std::string> current_host = {
        "192.168.8.30:1521/bdzw", "trffpn_znsj", "cj_bd_0218"
    };

//    std::vector<std::vector<std::string>> host_list = {
//        {"192.168.8.30:1521/bdzw", "trffpn_znsj", "cj_bd_0218"},
//        {"192.168.8.19:1521/bdjdc", "trffpn_znsj", "trffpn_znsj"},
//        {"192.168.8.18:1521/bdjdc", "trffpn_znsj", "trffpn_znsj"},
//        {"192.168.8.7:1521/bdjdc", "trffpn_znsj", "trffpn_znsj"}
//    };

    if ( occi.connect(current_host[1].data(), current_host[2].data(), current_host[0].data()) ) {
        return true;
    }

    DATA_PRINT(LEVEL_ERROR, "Can not connect to Oracle database: %s \n", current_host[0].data());

//    for (unsigned int i = 0; i < host_list.size(); i++) {
//        if (host_list[i][0] == current_host[0]) {
//            continue;
//        }

//        if ( occi.connect(host_list[i][1].data(), host_list[i][2].data(), host_list[i][0].data()) ) {
//            current_host[0] = host_list[i][0];
//            current_host[1] = host_list[i][1];
//            current_host[2] = host_list[i][2];

//            return true;
//        } else {
//            DATA_PRINT(LEVEL_ERROR, "Can not connect to Oracle database: %s \n", host_list[i][0].data());
//        }
//    }

    return false;
}
