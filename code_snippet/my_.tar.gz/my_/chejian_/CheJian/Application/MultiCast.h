#ifndef MULTICAST_H
#define MULTICAST_H

#ifdef __linux
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netdb.h>
#include <errno.h>
#include <unistd.h>
#else
#include<WinSock2.h>
#include<ws2tcpip.h>
#pragma comment(lib,"Ws2_32.lib")
#endif
#include "./helper/ThreadPool.h"
#include <functional>
#include <map>

#define MULTI_CAST_BUF_LEN (1024*8)
#define MULTI_CAST_RECV_CALLBACK std::function<void (void* ptr,char* buf,int len)>

struct CJClient
{
	int32_t devId;
	std::string ip;
	int16_t port;
	int8_t bMaster;
    std::string ver;
    int64_t iver;
    int16_t downloadQueueSize;
    int16_t analyseQueueSize;
    int16_t videoQueueSize;
    int16_t replyQueueSize;
	system_clock::time_point tick;
	CJClient()
	{
		devId = -1;
		ip = "0.0.0.0";
		port = 0;
		bMaster = false;
        ver="1.0.1";
        iver=0;
        downloadQueueSize=0;
        analyseQueueSize=0;
        videoQueueSize=0;
        replyQueueSize=0;
		tick=system_clock::now();
	}
};
class RecvTask;
class MyTimer;
class VersionCheck;
class vehicle_check_service;
class MultiCast
{
public:
	MultiCast();
	virtual ~MultiCast();
public:
    bool Start(vehicle_check_service* pServ,char* localIp, int localPort, char* multiIp, int multiPort, MULTI_CAST_RECV_CALLBACK cb,bool openSendFunc=true,bool recvLoop = false);
	bool SendData(char* buf, int len);
    void Stop();
    void Update(bool open,std::string devIdStr);
    bool SendSqlStr(std::string sql);
	static void OnRecv(void* mc, char* buf, int len);
	friend class RecvTask;
	friend class MyTimer;
    friend class VersionCheck;
	std::map<int32_t, CJClient> cjClnts_;
	std::mutex cjClntsMutex_;
    std::map<std::string,std::string> sqlStrTempMap_;
private:
	vehicle_check_service* pServ_;
	ThreadPool tpool_;
    bool bUpdateFlag_;
    bool bOpenSendFunc_;
	std::shared_ptr<RecvTask> recvTask_;
	std::shared_ptr<MyTimer> timerTask_;
    std::shared_ptr<VersionCheck> versionCheckTask_;
	MULTI_CAST_RECV_CALLBACK cb_;
	int recvSock_;
	int sendSock_;
	sockaddr_in localAddr_;
	sockaddr_in multiAddr_;
};

#endif
