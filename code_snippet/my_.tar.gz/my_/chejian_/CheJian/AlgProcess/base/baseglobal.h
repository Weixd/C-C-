#ifndef BASEGLOBAL_H
#define BASEGLOBAL_H
#include <stdio.h>
#include <vector>


enum CityType
{
    eUNKONW =0,
    eDEMO = 1,              //演示子类
    eJiaXing = 3304,        //嘉兴
    eDongGuan = 4419,       //东莞
    eYuLin = 4509,          //玉林
    eDongYing = 4551,          //东营
    eYingTan = 3606,             //鹰潭
};


enum PicType
{
    e0111 = 1,    //车辆左前方斜视45度照片 0111
    e0112 = 2,    //车辆右后方斜视45度照片 0112
    e0113 = 3,        //车辆识别照片（车架号） 0113
    e0167 = 4,            //车辆正前方牌照片 0176
    e0168 = 5,
    e0175 = 6,
    e0201 = 7,
    e0202 = 8,
    e0203 = 9,
    e0204 = 10,
    e0288 = 11,
    e0209 = 12,
    e0297 = 13,
    e0321 = 14,
    e0352 = 15,
    e0322 = 16,
    e0348 = 17,
    e0344 = 18,
    e0342 = 19,
    e0351 = 20,
    e0323 = 21,
    e0287 = 22,
    e0292 = 23,
    e0136 = 24,
    e0156 = 25,
    e0157 = 26,
    e0206 = 27,
    e0205 = 28,
    e0119 = 29,
    e0166 = 30,
    e0115 = 31,
//    e0114 = 32,




    eCLZQFXS45DZP_A = 100,        //车辆左前方斜视45度照片档案照片
    eCLSBDHZP_TYM,                //拓印膜照片
    eCLSBDHZP_JLBZM,              //记录表字模照片
    eWQDZP2,                      //尾气单第二张照片
    eNULL,
};



#endif // BASEGLOBAL_H
