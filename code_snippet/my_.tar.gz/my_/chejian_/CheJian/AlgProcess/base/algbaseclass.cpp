#include "AlgProcess/base/algbaseclass.h"
#include<iostream>
#include<stdexcept>

bool algBaseClass::loadPhotoMain(std::string photoPath)
{
    _photoMain =  cv::imread(photoPath);
    return true;
}

bool algBaseClass::loadPhotoSub(std::string photoPath)
{
    _photoSub =  cv::imread(photoPath);
    return true;
}

void algBaseClass::setBaseParam(CityType cityType,PicType type, std::string algName)
{
    _type = type;
    _algName = algName;
    _cityType = cityType;
}

void algBaseClass::initAlgClass()
{
    seekMemberListPointer();
    subClassLoadNewResultMember();
    loadAlgClassConfig();
}

void algBaseClass::setResultConfig(Json::Value root)
{
    if(resultListVector.size()>0)
    {
         for (unsigned int i = 0; i < resultListVector.size(); i++) {
             Json::Value subRoot =root[resultListVector[i].name];
             for(unsigned int j=0; j <  resultListVector[i].pVector->size(); j++)
             {
                 for(unsigned int k=0;k<subRoot.size();k++)
                 {

                     if((*resultListVector[i].pVector)[j].name == subRoot[k]["name"].asString())
                     {
                         if(!subRoot[k]["descOpen"].empty())
                             (*resultListVector[i].pVector)[j].config.descOpen = subRoot[k]["descOpen"].asBool();
                         if((*resultListVector[i].pVector)[j].config.descOpen)
                         {
                             if(!subRoot[k]["desc"].empty())
                                 (*resultListVector[i].pVector)[j].desc = subRoot[k]["desc"].asString();
                         }
                         if(!subRoot[k]["isOpen"].empty())
                             (*resultListVector[i].pVector)[j].config.isOpen = subRoot[k]["isOpen"].asBool();
                         if(!subRoot[k]["errLevel"].empty())
                             (*resultListVector[i].pVector)[j].config.errLevel = (E_JG)subRoot[k]["errLevel"].asInt();
                         //printf("name:%s isOpen:%d\n",(*resultListVector[i].pVector)[j].name.c_str(),(*resultListVector[i].pVector)[j].config.isOpen);
                     }

                 }
            }
        }
    }
}

void algBaseClass::setResultMember(std:: string memberName, memberItem *pResultMember)
{
    if(resultListVector.size()>0)
    {
        for (unsigned int i = 0; i < resultListVector.size(); i++) {
            if(resultListVector[i].name == memberName)
            {
                for(unsigned int j=0; j <  resultListVector[i].pVector->size(); j++)
                {
                    if((*resultListVector[i].pVector)[j].name == pResultMember->name)
                    {

                        if(!pResultMember->desc.empty())
                            (*resultListVector[i].pVector)[j].desc = pResultMember->desc;

                        (*resultListVector[i].pVector)[j].config.isOpen = pResultMember->config.isOpen;
                        (*resultListVector[i].pVector)[j].config.descOpen = pResultMember->config.descOpen;

                        if(pResultMember->config.errLevel > 0)
                            (*resultListVector[i].pVector)[j].config.errLevel = pResultMember->config.errLevel;
                    }
                }
            }
        }
    }
}

void algBaseClass::saveResultConfig()
{
    std::ofstream ofs;
    Json::Value  root;
    std::string path = _configRoot+"/algConfig/algClassConfig_"+std::to_string(_cityType);
    baseTool::CheckDir(path);
    std::string algconfigpath = path+"/algClass_"+std::to_string(_type)+".json";

    root["algClass"] = getResultMemberListJson();
    root["inListVectorPrintf"] = inListVectorPrintf;
    root["resultListVectorPrintf"] = resultListVectorPrintf;

    ofs.open(algconfigpath);
    ofs << root.toStyledString();
    ofs.close();

}

void algBaseClass::loadAlgClassConfig()
{
    std::ifstream fin;
    std::string algconfigpath = _configRoot+"/algConfig/algClassConfig_"+std::to_string(_cityType)+"/algClass_"+std::to_string(_type)+".json";

    fin.open(algconfigpath);
    if (fin.is_open()) {
        Json::Value  root;
        Json::Reader reader;
        if (reader.parse(fin, root, false))
        {
           setResultConfig(root["algClass"]);
           if(!root["inListVectorPrintf"].empty())
               inListVectorPrintf = root["inListVectorPrintf"].asBool();
           if(!root["resultListVectorPrintf"].empty())
               resultListVectorPrintf = root["resultListVectorPrintf"].asBool();
        }
    }
    fin.close();

//    if(pResultMemberList!=NULL)
//    {
//        for(unsigned int k=0; k <  pResultMemberList->size(); k++)
//        {
//            printf("index:[%d] isOpen:%d name:%s desc:%s errLevel:%d\n"
//                   , k
//                   , (*pResultMemberList)[k].config.isOpen
//                   , (*pResultMemberList)[k].name.c_str()
//                   , (*pResultMemberList)[k].desc.c_str()
//                   , (*pResultMemberList)[k].config.errLevel
//                   );
//        }
//    }
}

Json::Value algBaseClass::getResultMemberListJson()
{
    Json::Value root;


    if(resultListVector.size()>0)
    {
        for (unsigned int i = 0; i < resultListVector.size(); i++) {
            Json::Value memberRoot;
            for(unsigned int j=0; j <  resultListVector[i].pVector->size(); j++)
            {
                Json::Value subRoot;
                subRoot["name"] = (*resultListVector[i].pVector)[j].name;
                subRoot["desc"] = (*resultListVector[i].pVector)[j].desc;
                //subRoot["output"] = (*resultListVector[i].pVector)[j].output;
                subRoot["isOpen"] = (*resultListVector[i].pVector)[j].config.isOpen;
                subRoot["descOpen"] = (*resultListVector[i].pVector)[j].config.descOpen;
                subRoot["errLevel"] = (*resultListVector[i].pVector)[j].config.errLevel;
                memberRoot.append(subRoot);
            }
            root[resultListVector[i].name]=memberRoot;
        }
    }
    //printf("save:%s\n",root.toStyledString().c_str());
    return root;
}

 ALGFUNC_RETURN algBaseClass::Process(ALGFUNC_TP)
 {
     if(!LoadParam(ALG_P))
         return NeedWriteResult(ALG_P);

     if(!BeforDispose(ALG_P))
         return NeedWriteResult(ALG_P);



     try {

         if(inListVectorPrintf)
            printfInParam();

         setStartTime();
         bool ret = Dispose(ALG_P);
         setEndTime();

         if(resultListVectorPrintf)
            printfResultMember();

         if(!ret)
             return NeedWriteResult(ALG_P);
     }

     catch (std::exception e)
     {
         baseTool::msgOut(baseTool::ERR, __FILE__, __LINE__, "algName:"+_algName+" algType:"+std::to_string(_type)+" Exception cause:"+e.what()+" ");
     }

     if(!AfterDispose(ALG_P))
         return NeedWriteResult(ALG_P);

     if(!AlgResult(ALG_P))
         return NeedWriteResult(ALG_P);

     if(!AfterAlgResult(ALG_P))
         return NeedWriteResult(ALG_P);

     return NeedWriteResult(ALG_P);
 }

 bool algBaseClass::closeMemberOutputByName(std::string name)
 {
    if(pResultMemberList != NULL)
    {
        baseTool::closeMemberItemWriteResultByName(pResultMemberList,name);
        return true;
    }

    return false;
 }

ALGFUNC_RETURN algBaseClass::NeedWriteResult(ALGFUNC_TP)
{
     ALG_P_UNUSED return true;
}

void algBaseClass::addNewResultMember(memberItem *pMember)
{
    for (unsigned int i = 0; i < resultListVector.size(); i++) {
        (*resultListVector[i].pVector).push_back(*pMember);
    }

}

std::string algBaseClass::getRunTime()
{
    std::chrono::duration<double, std::milli> milliseconds = _end - _start;
    return std::to_string((unsigned int)milliseconds.count());
}

unsigned int algBaseClass::getRunTime_ms()
{
    std::chrono::duration<double, std::milli> milliseconds = _end - _start;
    return (unsigned int)milliseconds.count();
}

void algBaseClass::setStartTime()
{
    _start = std::chrono::system_clock::now();
}

void algBaseClass::setEndTime()
{
    _end = std::chrono::system_clock::now();
}

void algBaseClass::printfResultMember()
{
    if(resultListVector.size()>0)
    {
         for (unsigned int i = 0; i < resultListVector.size(); i++) {
             printf("ResultMember VectorName:%s\n",resultListVector[i].name.c_str());
             for(unsigned int j=0; j <  resultListVector[i].pVector->size(); j++)
             {
                    printf(" name:%s,desc:%s,result:%d,value:%s\n"
                           ,(*resultListVector[i].pVector)[j].name.c_str()
                           ,(*resultListVector[i].pVector)[j].desc.c_str()
                           ,(*resultListVector[i].pVector)[j].value->result
                           ,(*resultListVector[i].pVector)[j].value->OutData.c_str());
             }
        }
    }
}

void algBaseClass::printfInParam()
{
    if(inListVector.size()>0)
    {
         for (unsigned int i = 0; i < inListVector.size(); i++) {
             printf("InParam VectorName:%s\n",inListVector[i].name.c_str());
             for(unsigned int j=0; j <  inListVector[i].pVector->size(); j++)
             {
                    printf(" name:%s,desc:%s,value:%s\n"
                           ,(*inListVector[i].pVector)[j].name.c_str()
                           ,(*inListVector[i].pVector)[j].desc.c_str()
                           ,(*inListVector[i].pVector)[j].value->inData.c_str());
             }
        }
    }
}




