#include "baseinc.h"
#include "processbaseclass.h"
#include <thread>
#include "Application/trace_log.h"
void processBaseClass::init(CityType type)
{
    __cityType = type;
    __startTime = baseTool::getDangTianRiQi();

    //加载派生类的algVector变化情况
    changeAlgVector();
    //加载参数文件
    loadConfig();
}

Json::Value processBaseClass::getAlgVectorJson(std::vector<algItem> *pAlgVector)
{
    Json::Value root;
    for(unsigned int i=0; i <  pAlgVector->size(); i++)
    {
        Json::Value subRoot;
        subRoot["type"]=(*pAlgVector)[i].type;
        subRoot["name"]=(*pAlgVector)[i].name;
        subRoot["code"]=(*pAlgVector)[i].code;
        subRoot["isOpen"]=(*pAlgVector)[i].isOpen;
        subRoot["isTenYears"]=(*pAlgVector)[i].isTenYears;
        subRoot["needCheck"]=(*pAlgVector)[i].needCheck;
        root.append(subRoot);
    }
    return root;
}

void processBaseClass::setAlgVectorConfig(Json::Value root,std::vector<algItem> *pAlgVector)
{
    for(unsigned int i=0;i<root.size();i++)
    {
        for(unsigned int j=0; j <  pAlgVector->size(); j++)
        {
            if((*pAlgVector)[j].type == root[i]["type"].asInt())
            {
                if(!root[i]["code"].empty())
                    (*pAlgVector)[j].code = root[i]["code"].asString();
                if(!root[i]["name"].empty())
                    (*pAlgVector)[j].name = root[i]["name"].asString();
                if(!root[i]["isOpen"].empty())
                    (*pAlgVector)[j].isOpen = root[i]["isOpen"].asBool();
                if(!root[i]["needCheck"].empty())
                    (*pAlgVector)[j].needCheck = root[i]["needCheck"].asBool();
                if(!root[i]["isTenYears"].empty())
                    (*pAlgVector)[j].isTenYears = root[i]["isTenYears"].asBool();
            }
        }
    }
}


void processBaseClass::deleteCheckSmallVehicleVectorByKey(std::string key)
{
    for(unsigned int i=0; i <  __smallVehicle.size(); i++)
    {
        if(__smallVehicle[i]==key)
        {
            __smallVehicle[i] = "";
        }
    }
}

void processBaseClass::addCheckSmallVehicleVectorByKey(std::string key)
{
    if(!key.empty())
    {
        for(unsigned int i=0; i <  __smallVehicle.size(); i++)
        {
            if(__smallVehicle[i]==key)
            {
                return;
            }
        }
        __smallVehicle.push_back(key);
    }
}

Json::Value processBaseClass::getSmallVehicleVectorJson()
{
    Json::Value root;
    for(unsigned int i=0; i <  __smallVehicle.size(); i++)
    {
        if(!__smallVehicle[i].empty())
        {
            Json::Value subRoot;
            subRoot["cllx"]=__smallVehicle[i];
            root.append(subRoot);
        }
    }
    return root;

}

void processBaseClass::setSmallVehicleVectorConfig(Json::Value root,std::vector<std::string> *pVector)
{
    if(!(root.size() > 0))
    {
        return;
    }
    pVector->clear();
    for(unsigned int i=0;i<root.size();i++)
    {
        std::string cllx = root[i]["cllx"].asString();
        //if(baseTool::checkCllx(cllx))
        {
            pVector->push_back(cllx);
        }
    }
}

Json::Value processBaseClass::getCLZLVectorJson()
{
    Json::Value root;
    for(unsigned int i=0; i <  __CLZL.size(); i++)
    {
        if(!__CLZL[i].empty())
        {
            Json::Value subRoot;
            subRoot["cllx"]=__CLZL[i];
            root.append(subRoot);
        }
    }

    return root;

}

void processBaseClass::setCLZLVectorConfig(Json::Value root,std::vector<std::string> *pVector)
{
    if(!(root.size() > 0))
    {
        return;
    }
    pVector->clear();
    for(unsigned int i=0;i<root.size();i++)
    {
        std::string cllx = root[i]["cllx"].asString();
        //if(baseTool::checkCllx(cllx))
        {
            pVector->push_back(cllx);
        }
    }
}

void processBaseClass::deleteCheckJianYanLeiBieByKey(std::string key)
{
    for(unsigned int i=0; i <  __JYLB.size(); i++)
    {
        if(__JYLB[i]==key)
        {
            __JYLB[i] = "";
        }
    }
}

void processBaseClass::addCheckJianYanLeiBieByKey(std::string key)
{
    if(!key.empty())
    {
        for(unsigned int i=0; i <  __JYLB.size(); i++)
        {
            if(__JYLB[i]==key)
            {
                return;
            }
        }
        __JYLB.push_back(key);
    }
}

void processBaseClass::setHMDVectorConfig(Json::Value root,std::vector<std::string> *pVector)
{
    if(!(root.size() > 0))
    {
        return;
    }
    pVector->clear();

    printf("setHMDVectorConfig : %d \n",root.size());

    for(unsigned int i=0;i<root.size();i++)
    {
        std::string hdm = root[i]["hmd"].asString();
        //if(baseTool::checkCllx(cllx))
        {
            pVector->push_back(hdm);
        }
    }
}

Json::Value processBaseClass::getHMDVectorJson()
{
    Json::Value root;
    for(unsigned int i=0; i <  __HMD.size(); i++)
    {
        if(!__HMD[i].empty())
        {
            Json::Value subRoot;
            subRoot["hmd"]=__HMD[i];
            root.append(subRoot);
        }
    }
    return root;
}

void processBaseClass::deleteHeiMingDanByChePai(std::string chePai)
{
    for(unsigned int i=0; i <  __HMD.size(); i++)
    {
        if(__HMD[i]==chePai)
        {
            __HMD[i] = "";
        }
    }

}

void processBaseClass::addHeiMingDanByChePai(std::string chePai)
{
    if(!chePai.empty())
    {
        for(unsigned int i=0; i <  __HMD.size(); i++)
        {
            if(__HMD[i]==chePai)
            {
                return;
            }
        }
        __HMD.push_back(chePai);
    }

}

Json::Value processBaseClass::getJYLBVectorJson()
{
    Json::Value root;
    for(unsigned int i=0; i <  __JYLB.size(); i++)
    {
        if(!__JYLB[i].empty())
        {
            Json::Value subRoot;
            subRoot["jylb"]=__JYLB[i];
            root.append(subRoot);
        }
    }
    return root;

}

void processBaseClass::setJYLBVectorConfig(Json::Value root,std::vector<std::string> *pVector)
{
    if(!(root.size() > 0))
    {
        return;
    }
    pVector->clear();
    for(unsigned int i=0;i<root.size();i++)
    {
        std::string jylb = root[i]["jylb"].asString();
        pVector->push_back(jylb);
    }
}


void processBaseClass::deleteCheckShiYongXingZhiByKey(std::string key)
{
    for(unsigned int i=0; i <  __SYXZ.size(); i++)
    {
        if(__SYXZ[i]==key)
        {
            __SYXZ[i] = "";
        }
    }
}

void processBaseClass::addCheckShiYongXingZhiByKey(std::string key)
{
    if(!key.empty())
    {
        for(unsigned int i=0; i <  __SYXZ.size(); i++)
        {
            if(__SYXZ[i]==key)
            {
                return;
            }
        }
        __SYXZ.push_back(key);
    }
}

Json::Value processBaseClass::getSYXZVectorJson()
{
    Json::Value root;
    for(unsigned int i=0; i <  __SYXZ.size(); i++)
    {
        if(!__SYXZ[i].empty())
        {
            Json::Value subRoot;
           subRoot["syxz"]=__SYXZ[i];
           root.append(subRoot);
        }
    }
    return root;

}

void processBaseClass::setSYXZVectorConfig(Json::Value root,std::vector<std::string> *pVector)
{
    if(!(root.size() > 0))
    {
        return;
    }
    pVector->clear();
    for(unsigned int i=0;i<root.size();i++)
    {
        std::string syxz = root[i]["syxz"].asString();
        pVector->push_back(syxz);
    }
}

Json::Value processBaseClass::getJYJGVectorJson()
{
    Json::Value root;
    for(unsigned int i=0; i <  __JYJG.size(); i++)
    {
        if(!__JYJG[i].bh.empty())
        {
            Json::Value subRoot;
            subRoot["bh"]=__JYJG[i].bh;
            subRoot["ip"]=__JYJG[i].ip;
            root.append(subRoot);
        }
    }
    return root;

}

void processBaseClass::deleteCheckJianYanJiGouByKey(std::string bh)
{
    for(unsigned int i=0; i <  __JYJG.size(); i++)
    {
        if(__JYJG[i].bh==bh)
        {
            __JYJG[i].bh = "";
            __JYJG[i].ip = "";
        }
    }
}

void processBaseClass::addCheckJianYanJiGouByKey(std::string bh,std::string ip)
{
    if(!bh.empty()&&!ip.empty())
    {
        for(unsigned int i=0; i <  __JYJG.size(); i++)
        {
            if(__JYJG[i].bh == bh&&__JYJG[i].ip==ip)
            {
                return;
            }
        }
        JYJG jyjg;
        jyjg.ip = ip;
        jyjg.bh = bh;
        __JYJG.push_back(jyjg);
    }
}

void processBaseClass::setJYJGVectorConfig(Json::Value root,std::vector<JYJG> *pVector)
{
    if(!(root.size() > 0))
    {
        return;
    }
    pVector->clear();
    for(unsigned int i=0;i<root.size();i++)
    {
        JYJG jyjg;
        jyjg.bh = root[i]["bh"].asString();
        jyjg.ip = root[i]["ip"].asString();
        pVector->push_back(jyjg);
    }
}

void processBaseClass::setHeDingZaiKeShuConfig(unsigned int hdzks)
{
    __HDZKS = hdzks;
}

void processBaseClass::setCityShortNameConfig(std::string shortName)
{
    __cityShortName = shortName;
}

void processBaseClass::deleteCheckCheLiangZhongLeiByKey(std::string key)
{
    for(unsigned int i=0; i <  __CLZL.size(); i++)
    {
        if(__CLZL[i]==key)
        {
            __CLZL[i] = "";
        }
    }
}

void processBaseClass::addCheckCheLiangZhongLeiByKey(std::string key)
{
    if(!key.empty())
    {
        for(unsigned int i=0; i <  __CLZL.size(); i++)
        {
            if(__CLZL[i]==key)
            {
                return;
            }
        }
        __CLZL.push_back(key);
    }
}

Json::Value processBaseClass::queryState()
{
    Json::Value root;
    for(unsigned int i=0; i <  __algVector.size(); i++)
    {
        if(__algVector[i].isOpen)
        {
            Json::Value subRoot;
            subRoot["type"] = __algVector[i].type;
            subRoot["name"] = __algVector[i].name;
            subRoot["code"] = __algVector[i].code;
            subRoot["runCount"] = __algVector[i].runCount;
            subRoot["passCount"] = __algVector[i].passCount;

            root.append(subRoot);
        }
    }
    return root;

}

void processBaseClass::saveConfig()
{
    Json::Value  root;
    root["algVector"] = getAlgVectorJson(&__algVector);
    root["smallVehicle"] = getSmallVehicleVectorJson();
    root["checkCllx"] = getCLZLVectorJson();

    root["cityShortName"] = __cityShortName;
    root["jianYanLeiBie"] = getJYLBVectorJson();
    root["shiYongXingZhi"] = getSYXZVectorJson();
    root["jianYanJiGou"] = getJYJGVectorJson();
    root["heDingZaiKeShu"] = __HDZKS;
    root["heiMingDan"] = getHMDVectorJson();

    std::ofstream ofs;
    std::string path =__configRoot + "/algConfig";
    baseTool::CheckDir(path);

    char configPath[2048]={0};
    sprintf(configPath,"%s/processClassConfig_%d.json",path.c_str(),__cityType);

    ofs.open(configPath);
    ofs << root.toStyledString();

    ofs.close();

}

void processBaseClass::loadConfig()
{
    std::ifstream fin;
    char configPath[2048]={0};
    sprintf(configPath,"%s/algConfig/processClassConfig_%d.json",__configRoot.c_str(),__cityType);
    fin.open(configPath);
    if (fin.is_open()) {
        Json::Value  root;
        Json::Reader reader;
        if (reader.parse(fin, root, false))
        {
           if(!root["algVector"].empty())
                setAlgVectorConfig(root["algVector"],&__algVector);

           __smallVehicle.clear();
           if(!root["smallVehicle"].empty())
                setSmallVehicleVectorConfig(root["smallVehicle"],&__smallVehicle);

           __CLZL.clear();
           if(!root["checkCllx"].empty())
                setCLZLVectorConfig(root["checkCllx"],&__CLZL);
           if(!root["cityShortName"].empty())
                setCityShortNameConfig(root["cityShortName"].asString());

           __JYLB.clear();
           if(!root["jianYanLeiBie"].empty())
                setJYLBVectorConfig(root["jianYanLeiBie"],&__JYLB);

           __SYXZ.clear();
           if(!root["shiYongXingZhi"].empty())
                setSYXZVectorConfig(root["shiYongXingZhi"],&__SYXZ);

           __JYJG.clear();
           if(!root["jianYanJiGou"].empty())
                setJYJGVectorConfig(root["jianYanJiGou"],&__JYJG);

           if(!root["heDingZaiKeShu"].empty())
                setHeDingZaiKeShuConfig(root["heDingZaiKeShu"].asInt());

           __HMD.clear();
           if(!root["heiMingDan"].empty())
                setHMDVectorConfig(root["heiMingDan"],&__HMD);

        }
    }
    fin.close();


    baseTool::msgOut(baseTool::MSG, __FILE__, __LINE__,  "城市简称:"+__cityShortName);


    std::string jyjgstr ="检验机构[";
    for(unsigned int i = 0; i <  __JYJG.size(); i++)
    {
        jyjgstr+="{\"bh\":\""+__JYJG[i].bh+"\",\"ip\":\""+__JYJG[i].ip+"\"}";
        if( i+1 < __JYJG.size())
        {
            jyjgstr += ", ";
        }
    }
    jyjgstr += "]";
    baseTool::msgOut(baseTool::MSG, __FILE__, __LINE__,  jyjgstr);

    std::string jylbstr = "检验类别[";
    for(unsigned int i = 0; i <  __JYLB.size(); i++)
    {
       jylbstr +="{\"jylb\":\""+__JYLB[i]+"\"}";
        if( i+1 < __JYLB.size())
        {
            jylbstr +=", ";
        }
    }
    jylbstr +="]";
    baseTool::msgOut(baseTool::MSG, __FILE__, __LINE__,  jylbstr);

    std::string syxzstr = "使用性质[";
    for(unsigned int i = 0; i <  __SYXZ.size(); i++)
    {
       syxzstr +="{\"syxz\":\""+__SYXZ[i]+"\"}";
        if( i+1 < __SYXZ.size())
        {
            syxzstr +=", ";
        }
    }
    syxzstr +="]";
    baseTool::msgOut(baseTool::MSG, __FILE__, __LINE__,  syxzstr);

    std::string cllxstr = "车辆类型[";
    for(unsigned int i = 0; i <  __CLZL.size(); i++)
    {
        cllxstr +="{\"cllx\":\""+__CLZL[i]+"\"}";
        if( i+1 < __CLZL.size())
        {
            cllxstr +=", ";
        }
    }
    cllxstr +="]";
    baseTool::msgOut(baseTool::MSG, __FILE__, __LINE__,  cllxstr);

    baseTool::msgOut(baseTool::MSG, __FILE__, __LINE__,  "核定载客数:"+std::to_string(__HDZKS));

    std::string xiaoChestr = "小车车辆类型[";
    for(unsigned int i = 0; i <  __smallVehicle.size(); i++)
    {
        xiaoChestr +="{\"cllx\":\""+__smallVehicle[i]+"\"}";
        if( i+1 < __smallVehicle.size())
        {
            xiaoChestr +=", ";
        }
    }
    xiaoChestr +="]";
    baseTool::msgOut(baseTool::MSG, __FILE__, __LINE__,  xiaoChestr);

    std::string heiMingDanStr = "黑名单[";
    for(unsigned int i = 0; i <  __HMD.size(); i++)
    {
        heiMingDanStr +="{\"hmd\":\""+__HMD[i]+"\"}";
        if( i+1 < __HMD.size())
        {
            heiMingDanStr +=", ";
        }
    }
    heiMingDanStr +="]";
    baseTool::msgOut(baseTool::MSG, __FILE__, __LINE__,  heiMingDanStr);


   std::string algClassstr = "算法关系表[\n";
    for(unsigned int i = 0; i <  __algVector.size(); i++)
    {
       algClassstr +="{\"PicType\":\""+std::to_string(__algVector[i].type)+"\", \"code\":\""+__algVector[i].code+"\", \"isOpen\":"+std::to_string(__algVector[i].isOpen)+", \"needCheck\":"+std::to_string(__algVector[i].needCheck)+", \"subAlgClass\":"+std::to_string(__algVector[i].subAlgClass)+", \"isTenYears\":"+std::to_string(__algVector[i].isTenYears)+", \"name\":\""+__algVector[i].name+"\"}";
        if( i+1 < __algVector.size())
        {
            algClassstr +=",\n";
        }
    }
    algClassstr +="]";
    baseTool::msgOut(baseTool::MSG, __FILE__, __LINE__,  algClassstr);
}

bool processBaseClass::changeAlgVectorByType(algItem *pAlgItem)
{
    //遍历__algVector 并找到 类型匹配的算法algItem
    for(unsigned int i = 0; i < __algVector.size(); i++)
    {
        if(pAlgItem->type == __algVector[i].type)
        {
            //设置参数
            if(pAlgItem->code != "")
                __algVector[i].code = pAlgItem->code;
            if(pAlgItem->name != "")
                __algVector[i].name = pAlgItem->name;

            __algVector[i].isOpen = pAlgItem->isOpen;
            __algVector[i].needCheck = pAlgItem->needCheck;
            __algVector[i].subAlgClass = pAlgItem->subAlgClass;
            __algVector[i].isTenYears = pAlgItem->isTenYears;

            return true;
        }
    }
    return false;
}

bool processBaseClass::addAlgVectorMember(std::string code, bool isOpen, std::string name,PicType type, bool subAlgClass)
{
    //遍历algVector 查看算法的处理类型是否重复，如果重复则返回false
    for(unsigned int i = 0; i < __algVector.size(); i++)
    {
        if(type == __algVector[i].type && code == __algVector[i].code)
        {
            return false;
        }
    }

    //新增一个algItem并插入到__algVector中
    algItem sAlgItem;

    if(code != "")
       sAlgItem.code = code;

    if(name != "")
        sAlgItem.name = name;

    sAlgItem.type = type;   //为算法处理类型唯一标记，参数配置中会用到需要记录
    sAlgItem.isOpen = isOpen;//默认该值默认为true 受参数配置影响
    sAlgItem.needCheck =  true;//该值默认为true 如果为false 则添加的处理类型不会执行
    sAlgItem.subAlgClass = subAlgClass;//这里设置true 则直接执行subClassLoadAlgBaseClassByPicType,在新增算法处理类型中一般都使用true

    __algVector.push_back(sAlgItem);

    return true;
}

void processBaseClass::loadParamByParamList(std::vector<classItem> paramList, algBaseClass *pHandle)
{
   //遍历参数类基类输入参数vector List
   for(unsigned i = 0; i < pHandle->inListVector.size(); i++)
   {
       //遍历输入参数vector
       for (unsigned j=0; j < pHandle->inListVector[i].pVector->size(); j++) {
           bool isGetValue = false;
           //遍历输入参数列表
           for(unsigned z = 0; z < paramList.size(); z++)
           {
               //输入参数name 和 参数类成员name 一致 则将该值赋值给参数类成员
               if((*pHandle->inListVector[i].pVector)[j].name == paramList[z].name)
               {
                   (*pHandle->inListVector[i].pVector)[j].value->inData= *paramList[z].value;
                   isGetValue = true;
                   break;
               }
           }
           if(!isGetValue)
           {
               baseTool::msgOut(baseTool::WAR, __FILE__, __LINE__, " name:"+(*pHandle->inListVector[i].pVector)[j].name+" load param is not find !");
           }
       }
   }
}

bool processBaseClass::checkJianYanLeiBie(std::string jylb, std::vector<PhotoItem> *pPhotoList)
{
    if(__JYLB.size() > 0)
    {
        for (unsigned int k = 0; k < __JYLB.size(); k++) {
            if (jylb == __JYLB[k]) {
                return true;
            }
        }
        for(unsigned int i = 0; i < pPhotoList->size(); i++)
        {
            baseTool::writeResultByJGAndSM(&(*pPhotoList)[i],UNABLE_IDENTIFY, "检验类别不在软件处理范围内");
        }

        return false;
    }
    return true;
}

bool processBaseClass::checkShiYongXingZhi(std::string syxz, std::vector<PhotoItem> *pPhotoList)
{
    if(__SYXZ.size() > 0)
    {
        for (unsigned int k = 0; k < __SYXZ.size(); k++) {
            if (syxz == __SYXZ[k]) {
                return true;
            }
        }
        for(unsigned int i = 0; i < pPhotoList->size(); i++)
        {
             baseTool::writeResultByJGAndSM(&(*pPhotoList)[i],UNABLE_IDENTIFY, "使用性质不在软件处理范围");
        }
        return false;
    }
    return true;
}

bool processBaseClass::checkCheLiangZhongLei(std::string clzl, std::vector<PhotoItem> *pPhotoList)
{
    if(__CLZL.size() > 0)
    {
        for (unsigned int k = 0; k < __CLZL.size(); k++) {
            if (clzl == __CLZL[k]) {
                return true;
            }
        }
        for(unsigned int i = 0; i < pPhotoList->size(); i++)
        {
            baseTool::writeResultByJGAndSM(&(*pPhotoList)[i],UNABLE_IDENTIFY, "车辆类型不在软件处理范围内");
        }

        return false;
    }
    return true;
}

bool processBaseClass::checkJianYanJiGou(std::string bh, std::string ip, std::vector<PhotoItem> *pPhotoList)
{
    int errType = 0;
    if(__JYJG.size() > 0)
    {
        for (unsigned int k = 0; k < __JYJG.size(); k++) {
            if (bh == __JYJG[k].bh) {
                if(ip == __JYJG[k].ip)
                {
                    return true;
                }
                errType = 1;
            }
        }
        for(unsigned int i = 0; i < pPhotoList->size(); i++)
        {
            if(errType)
            {
                baseTool::writeResultByJGAndSM(&(*pPhotoList)[i],UNABLE_IDENTIFY, "指定的机器(IP:" + ip + ")没有在线，无法处理");
            }else {
                baseTool::writeResultByJGAndSM(&(*pPhotoList)[i],UNABLE_IDENTIFY, "检验机构不在软件处理范围内");
            }
        }
        return false;
    }
    return true;
}

 bool processBaseClass::checkHeDingZaiKeShu(std::string hdzks, std::vector<PhotoItem> *pPhotoList)
 {
    unsigned int HeDingZaiKeShu = 7;
    std::string outMsg = "当前值";

    //当车辆类型默认未
    if(hdzks != "" && hdzks != "无数据")
    {
        HeDingZaiKeShu = baseTool::str2Int(hdzks);
    }else {
        outMsg += "(默认)";
    }

    if(__HDZKS != 0)
    {
        if(HeDingZaiKeShu > __HDZKS)
        {
//            for(unsigned int i = 0; i < pPhotoList->size(); i++)
//            {
//                baseTool::writeResultByJGAndSM(&(*pPhotoList)[i],UNABLE_IDENTIFY, "核定载客数错误");
//            }
            return false;
        }
    }
    UNUSED(pPhotoList);
    return true;
 }

bool processBaseClass::checkIsSamllVehicle(std::string clzl, std::vector<PhotoItem> *pPhotoList)
{
     UNUSED(pPhotoList);
     if(__smallVehicle.size() > 0)
     {
         for (unsigned int k = 0; k < __smallVehicle.size(); k++) {
             if (clzl == __smallVehicle[k]) {
                 return true;
             }
         }
         return false;
     }
     return true;
}

 bool processBaseClass::checkHeiMingDan(std::string chePai, std::vector<PhotoItem> *pPhotoList)
 {
      UNUSED(pPhotoList);
      if(__HMD.size() > 0)
      {
          for (unsigned int k = 0; k < __HMD.size(); k++) {
              if (chePai == __HMD[k]) {
                  for(unsigned int i = 0; i < pPhotoList->size(); i++)
                  {
                      baseTool::writeResultByJGAndSM(&(*pPhotoList)[i],NOT_PASS, "黑名单车辆");
                  }
                  return false;
              }
          }
          return true;
      }
      return true;
 }

//照片列表是否包含全部类型
bool processBaseClass::checkComplete(bool isTenYears,std::vector<PhotoItem> *pPhotoList)
{
     //遍历支持的算法列表
     for(unsigned int i = 0; i < __algVector.size(); i++)
     {
         //判断算法是否启用 且 是否是必检测项
         if(__algVector[i].isOpen && __algVector[i].needCheck)
         {
             bool isOk = false;
             //判断algvector中 出现的启用类型且需要检测的类型 在pPhotoList中是否出现
             for(unsigned int j = 0; j < pPhotoList->size(); j++)
             {
                 //如果出现则算法类型通过，否则不通过
                 if(__algVector[i].code == (*pPhotoList)[j].zpType)
                 {
                     isOk = true;
                     break;
                 }
             }

             //如果algVector中出现pPhotoList中未有的类型 判断一下是否是十年免检类型
             if(!isOk&&__algVector[i].isTenYears)
             {
                 //如果是不是十年车则判定通过
                if(!isTenYears)
                {
                   isOk = true;
                }
             }

             //如果出现判定不同则直接退出检测返回完整性判定失败
             if(!isOk)
             {
                 return false;
             }
         }
     }
     return true;
}

E_ZZJG processBaseClass::checkUnqualified(bool isTenYears,std::vector<PhotoItem> *pPhotoList)
{
    E_ZZJG result = SOFT_PASS;

    for(unsigned int j = 0; j < pPhotoList->size(); j++)
    {
        for(unsigned int i = 0; i < __algVector.size(); i++)
        {
            if(__algVector[i].code == (*pPhotoList)[j].zpType&&__algVector[i].isOpen)
            {
                if((*pPhotoList)[j].jg == std::to_string(NOT_PASS))
                {
                    return SOFT_NOTPASS;
                }
                else if((*pPhotoList)[j].jg == std::to_string(UNABLE_IDENTIFY))
                {
                    result = SOFT_ERR;
                }
                break;
            }
        }
    }
    UNUSED(isTenYears);
    return result;
}


algBaseClass *processBaseClass::subClassLoadAlgBaseClassByPicType(CityType cityType, std::string algName, PicType type)
{
    UNUSED(cityType);UNUSED(algName);UNUSED(type);
    return new algBaseClass();
}

bool processBaseClass::beforAlgCheck(std::vector<classItem> paramList, std::vector<PhotoItem> *pPhotoList, LargeVehicleApi *alg)
{
    std::string jylb = baseTool::getClassItemValueByName(paramList, "jianYanLeiBie");
    std::string syxz = baseTool::getClassItemValueByName(paramList, "shiYongXingZhi");
    std::string cllx = baseTool::getClassItemValueByName(paramList, "cheLiangLeiXing");
    std::string bh = baseTool::getClassItemValueByName(paramList, "jianYanJiGouBianHao");
    std::string ip = baseTool::getClassItemValueByName(paramList, "jianYanJiGouIp");
    std::string chePai = baseTool::getClassItemValueByName(paramList, "faZhengJiGuan")+baseTool::getClassItemValueByName(paramList, "chePaiHao");
    printf("chePai:%s\n",chePai.c_str());
    //黑名单过滤
    if(!checkHeiMingDan(chePai, pPhotoList))
    {
        return false;
    }

    //检验类别检测
    if(!checkJianYanLeiBie(jylb, pPhotoList))
    {
        return false;
    }
    //使用性质检测
    if(!checkShiYongXingZhi(syxz, pPhotoList))
    {
        return false;
    }
    //车辆种类检测
    if(!checkCheLiangZhongLei(cllx, pPhotoList))
    {
        return false;
    }
    //检验机构检测
    if(!checkJianYanJiGou(bh, ip, pPhotoList))
    {
        return false;
    }

    //返回虚函数的前置检测(用于派生类所自己私有的检测)
    return subBeforAlgCheck(paramList, pPhotoList, alg);
}

 E_ZZJG processBaseClass::afterAlgCheck(std::vector<classItem> paramList, std::vector<PhotoItem> *pPhotoList, LargeVehicleApi *alg)
 {
    E_ZZJG baseResult = SOFT_PASS;
    std::string heDingZaiKeShu = baseTool::getClassItemValueByName(paramList, "heDingZaiKeShu");
    std::string cheLiangLeiXing = baseTool::getClassItemValueByName(paramList, "cheLiangLeiXing");
    std::string cjdjrq = baseTool::getClassItemValueByName(paramList,"chuCiDengJiRiQi");
    bool isTenYears =false;

    //如果车辆等级时间 > 10 年
    if(baseTool::isTenYears(cjdjrq))
    {
        isTenYears = true;
    }

    //判定核定载客数是否符合要求如果核定载客数未空则默认设置为7 如果该值大于__HDZKS则判定不通过
    if(!checkHeDingZaiKeShu(heDingZaiKeShu, pPhotoList))
    {
        return SOFT_NOTPROCESS;
    }

    //判断是否未小车如果不是判定不通过
    if(!checkIsSamllVehicle(cheLiangLeiXing, pPhotoList))
    {
        return SOFT_NOTPROCESS;
    }
    //检验需要检测的算法是否都有被检测的数据
    if(!checkComplete(isTenYears,pPhotoList))
    {
        return SOFT_NOTPASS;
    }
     //将结果传递给派生类中并返回派生类的判断结果，默认直接返回baseResult
    baseResult = subAfterAlgCheck(baseResult, paramList, pPhotoList, alg);
    if(baseResult != SOFT_PASS)
    {
        return baseResult;
    }
    //返回各个图片处理结果的汇总情况
    return checkUnqualified(isTenYears,pPhotoList);
 }

bool processBaseClass::algVectorCheck(algItem *pAlgItem, std::vector<PhotoItem> *pPhotoList, unsigned int pPhotoIndex)
{
    //判断算法是否需要检测，如果不需要直接判定为通过
    if(!pAlgItem->isOpen)
    {
        baseTool::msgOut(baseTool::MSG, __FILE__, __LINE__,  pAlgItem->name+":Config needCheck:"+std::to_string(pAlgItem->isOpen)+"  isOpen:"+std::to_string(pAlgItem->isOpen));
        baseTool::writeResultByJGAndSM(&(*pPhotoList)[pPhotoIndex],UNABLE_IDENTIFY, "[未知检验类型]");
        return false;
    }

    //判断照片本地路径是否为空
    if((*pPhotoList)[pPhotoIndex].localPath == "TBD")
    {
        baseTool::msgOut(baseTool::ERR, __FILE__, __LINE__, "ID为"+(*pPhotoList)[pPhotoIndex].zpId+"的照片未获取成功");
        baseTool::writeResultByJGAndSM(&(*pPhotoList)[pPhotoIndex],UNABLE_IDENTIFY, "[建议人工]");
        return false;
    }

    //判断是否是处理过的类型如果322会将348结果处理
    if(!(*pPhotoList)[pPhotoIndex].jg.empty())
    {
       return false;
    }

    //用于派生类增加私有的有效性判断（如果需要两张照片都存在的情况等）
    return subAlgVectorCheck(pAlgItem, pPhotoList, pPhotoIndex);
}

void processBaseClass::algProcess(unsigned int algIndex, unsigned int photoIndex, std::vector<classItem> paramList, std::vector<PhotoItem> *pPhotoList, LargeVehicleApi *alg)
{
    //加载算法类型对应的参数类，返回参数类基类指针
    algBaseClass *pAlgParam = loadAlgBaseClassByPicType(__cityType,__algVector[algIndex].name,__algVector[algIndex].type, __algVector[algIndex].subAlgClass);
    if(pAlgParam->pInMemberList != NULL)
    {
        //加载参数类所需的参数
        loadParamByParamList(paramList,pAlgParam);
        //执行algBaseClass Process 开启算法处理流程先后执行下列五个虚函数接口
        //(接口默认返回true，如果重写后返回false将打断处理流程，需要自己填充结果或改变流程顺序)
        //BeforDispose  算法运算前
        //Dispose       算法处理
        //AfterDispose  算法运算后(结果汇总处理前)
        //AlgResult     结果汇总处理
        //NeedWriteResult   结果汇总处理后
//        DATA_PRINT(LEVEL_INFO,"wyd~~ 算法执行111");
        if(pAlgParam->Process(photoIndex, __algVector[algIndex].type,paramList, pPhotoList, pAlgParam, this, alg))
        {
            //算法运行结果通过则通过测试累加
            if(WriteResult(__algVector[algIndex].name, pAlgParam, &(*pPhotoList)[photoIndex]))
            {

            }
        }
        //获取算法执行时间
        (*pPhotoList)[photoIndex].runTime = pAlgParam->getRunTime();
        //判断检测是否通过并统计通过次数
        if((*pPhotoList)[photoIndex].jg == std::to_string(PASS)||(*pPhotoList)[photoIndex].jg == std::to_string(UNABLE_IDENTIFY))
        {
             __algVector[algIndex].passCount++;
        }
    }
    //算法执行完毕
    (*pPhotoList)[photoIndex].checkOver = true;
    (*pPhotoList)[photoIndex].type =__algVector[algIndex].type;
    if(pAlgParam)
    {
        delete pAlgParam;
        pAlgParam=nullptr;
    }
}
#include "Application/trace_log.h"
E_ZZJG processBaseClass::picProcess(std::vector<classItem> paramList, std::vector<PhotoItem> *pPhotoList, LargeVehicleApi *alg)
{
    //算法检测前置信息检测,如果前置判断不通过直接退出，判断内部自己填充算法结果
    if(!beforAlgCheck(paramList, pPhotoList, alg))
    {
        return SOFT_NOTPROCESS;
    }
    //遍历照片列表与algVector 找到照片所对应algItem
    for(unsigned int i = 0; i < pPhotoList->size(); i++)
    {
        for(unsigned int j = 0; j < __algVector.size(); j++)
        {
            //当照片类型和算法code相等进入处理流程
            if ((*pPhotoList)[i].zpType == __algVector[j].code)
            {
               // DATA_PRINT(LEVEL_INFO,"wyd~~ zpType=%s ,__algVector[j].code=%s",(*pPhotoList)[i].zpType.c_str(),__algVector[j].code.c_str());
//                sleep(5);
                //算法运行测试累加
                __algVector[j].runCount++;
                //算法执行前判断一下algVector是否有效 以及图片数据是否合法
                if(!algVectorCheck(&__algVector[j], pPhotoList, i))
                {
             //       DATA_PRINT(LEVEL_INFO,"wyd~~ 算法执行否合法");
//                    sleep(5);
                    if((*pPhotoList)[i].jg == std::to_string(PASS)||(*pPhotoList)[i].jg == std::to_string(UNABLE_IDENTIFY))
                    {
                          __algVector[j].passCount++;
                    }
                    break;
                }
                baseTool::msgOut(baseTool::MSG,__FILE__, __LINE__,"algProcess code:"+__algVector[j].code + " "+__algVector[j].name);
               // DATA_PRINT(LEVEL_INFO,"wyd~~ 算法执行");
                //算法执行过程（初始化algBaseClass的派生类 并执行algBaseClass的process接口）
                algProcess(j, i, paramList, pPhotoList, alg);
                break;
            }
        }
        //如果处理后jg未空则填充未知检验类型
        if((*pPhotoList)[i].jg.empty() && (eWQDZP2!=(*pPhotoList)[i].type))
        {
         //   DATA_PRINT(LEVEL_INFO,"wyd~~ 未知检验类型");
            baseTool::writeResultByJGAndSM(&(*pPhotoList)[i],UNABLE_IDENTIFY, "[未知检验类型]");
        }
        baseTool::msgOut(baseTool::MSG, __FILE__, __LINE__, "zpType:"+(*pPhotoList)[i].zpType+",runTime:"+(*pPhotoList)[i].runTime+"ms, jg:"+(*pPhotoList)[i].jg+",sm:"+(*pPhotoList)[i].sm+"\n\n\n\n");
    }
    return afterAlgCheck(paramList, pPhotoList, alg);
}

bool processBaseClass::WriteResult(std::string algName, algBaseClass *pHandle, PhotoItem *pPhoto)
{
    //判断结果集合不为空
    if(pHandle->pResultMemberList != NULL)
    {
        //将结果汇总到photoitem中
        return baseTool::wirteResultByMemberList(algName,pPhoto,pHandle->pResultMemberList);
    }
    return false;
}


std::string processBaseClass::getAlgItemCodeByPicType(PicType type)
{
    for(unsigned int i = 0; i < __algVector.size(); i++)
    {
        if(__algVector[i].type == type)
        {
            return __algVector[i].code;
        }
    }
    return "";
}

std::string processBaseClass::getAlgItemNameByPicType(PicType type)
{
    for(unsigned int i = 0; i < __algVector.size(); i++)
    {
        if(__algVector[i].type == type)
        {
            return __algVector[i].name;
        }
    }
    return "";
}

bool processBaseClass::setAlgItemNeedCheckByPicType(PicType type,bool needCheck)
{
    for(unsigned int i = 0; i < __algVector.size(); i++)
    {
        if(__algVector[i].type == type)
        {
            __algVector[i].needCheck = needCheck;
            return true;
        }
    }
    return false;
}

Json::Value processBaseClass::getAlgVectorJson()
{
    Json::Value root;

    for(unsigned int i = 0; i < __algVector.size(); i++)
    {
        Json::Value subRoot;
        subRoot["type"] =__algVector[i].type;
        subRoot["isOpen"] =__algVector[i].isOpen;
        subRoot["code"] =__algVector[i].code;
        subRoot["name"] =__algVector[i].name;
        subRoot["needCheck"] =__algVector[i].needCheck;
        subRoot["isTenYears"] =__algVector[i].isTenYears;
        //subRoot["subAlgClass"] =__algVector[i].subAlgClass;

        root.append(subRoot);
    }
    return root;
}

unsigned int processBaseClass::getHeDingZaiHeShu()
{
    return __HDZKS;
}

std::string processBaseClass::getCityShortNmae()
{
    return __cityShortName;
}

std::string processBaseClass::getCityType()
{
    return std::to_string(__cityType);
}

algBaseClass *processBaseClass::loadAlgBaseClassByPicType(PicType type)
{
    Json::Value root;
    //遍历algVector 并找到 type相对应的 algItem
    for(unsigned int i = 0; i < __algVector.size(); i++)
    {
        if(__algVector[i].type == type)
        {
            //根据type类型加载algClass实体
             algBaseClass *pAlgParam = loadAlgBaseClassByPicType(__cityType,__algVector[i].name,__algVector[i].type, __algVector[i].subAlgClass);
             return pAlgParam;
        }
    }
    return new algBaseClass();
}

void processBaseClass::setCityType(CityType cityType)
{
    __cityType = cityType;
}

void algProcess_thread_Queue(algItem *pAlgVector)
{
   while(1)
   {
        algClassHandle *pHandle = pAlgVector->pDataQueue->Take();
        if(pHandle->algIndex == 999)
            break;
        pHandle->pBaseClass->algProcess(pHandle->algIndex, pHandle->photoIndex, *pHandle->pParamList, pHandle->pPhotoList, pHandle->alg);
        pHandle->checkOver = true;
   }
}


E_ZZJG processBaseClass::picProcess_thread(std::vector<classItem> paramList, std::vector<PhotoItem> *pPhotoList, LargeVehicleApi *alg)
{
    vector<std::thread*> threads;
    //算法检测前置信息检测,如果前置判断不通过直接退出，判断内部自己填充算法结果
    if(!beforAlgCheck(paramList, pPhotoList, alg))
    {
        return SOFT_NOTPROCESS;
    }
    //遍历照片列表与algVector 找到照片所对应algItem
    for(unsigned int i = 0; i < pPhotoList->size(); i++)
    {
        for(unsigned int j = 0; j < __algVector.size(); j++)
        {
            //当照片类型和算法code相等进入处理流程
            if ((*pPhotoList)[i].zpType == __algVector[j].code)
            {
                //算法运行测试累加
                __algVector[j].runCount++;
                //算法执行前判断一下algVector是否有效 以及图片数据是否合法
                if(!algVectorCheck(&__algVector[j], pPhotoList, i))
                {
                    if((*pPhotoList)[i].jg == std::to_string(PASS)||(*pPhotoList)[i].jg == std::to_string(UNABLE_IDENTIFY))
                    {
                          __algVector[j].passCount++;
                    }
                    break;
                }
                baseTool::msgOut(baseTool::MSG,__FILE__, __LINE__,"algProcess code:"+__algVector[j].code + " "+__algVector[j].name);
                //算法执行过程（初始化algBaseClass的派生类 并执行algBaseClass的process接口）
//                (*pPhotoList)[i].pHandle = new algClassHandle();
                (*pPhotoList)[i].handle.algIndex=j;
                (*pPhotoList)[i].handle.photoIndex=i;
                (*pPhotoList)[i].handle.pParamList=&paramList;
                (*pPhotoList)[i].handle.pPhotoList=pPhotoList;
                (*pPhotoList)[i].handle.alg=alg;
                (*pPhotoList)[i].handle.pBaseClass = this;
                (*pPhotoList)[i].handle.checkOver = false;

                if( __algVector[j].pThread == NULL)
                {
                    __algVector[j].pDataQueue = new  BlockingQueue<algClassHandle *>();
                    __algVector[j].pThread = new std::thread(algProcess_thread_Queue,  &__algVector[j]);
                }

                (*pPhotoList)[i].needThreadCheck = true;
                (*pPhotoList)[i].checkOver = false;
                __algVector[j].pDataQueue->Put(&(*pPhotoList)[i].handle);

                break;
            }else {
                 (*pPhotoList)[i].needThreadCheck = false;
            }
        }
   }

    while(1)
    {
        bool allOver = true;
        for(unsigned int i = 0; i < pPhotoList->size(); i++)
        {
            if((*pPhotoList)[i].needThreadCheck)
            {
                if((*pPhotoList)[i].handle.checkOver == false)
                    allOver = false;
            }
        }
        baseTool::msgOut(baseTool::ERR, __FILE__, __LINE__, "~~~!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~allOver = %d"+std::to_string(allOver));
        if(allOver)
        {
            break;
        }
    }

    for(unsigned int i = 0; i < pPhotoList->size(); i++)
    {
        if((*pPhotoList)[i].needThreadCheck)
        {
            //如果处理后jg未空则填充未知检验类型
            if((*pPhotoList)[i].jg.empty())
            {
                baseTool::writeResultByJGAndSM(&(*pPhotoList)[i],UNABLE_IDENTIFY, "[未知检验类型]");
            }
            baseTool::msgOut(baseTool::MSG, __FILE__, __LINE__, "zpType:"+(*pPhotoList)[i].zpType+",runTime:"+(*pPhotoList)[i].runTime+"ms, jg:"+(*pPhotoList)[i].jg+",sm:"+(*pPhotoList)[i].sm);

        }
    }

    return afterAlgCheck(paramList, pPhotoList, alg);
}

void processBaseClass::freeThreadAndQueue()
{
    for(unsigned int j = 0; j < __algVector.size(); j++)
    {

            if( __algVector[j].pThread != NULL)
            {
                algClassHandle handle;
                handle.algIndex = 999;
                __algVector[j].pDataQueue->Put(&handle);
                __algVector[j].pThread->join();
                delete __algVector[j].pDataQueue;
                delete __algVector[j].pThread;
            }
    }
}

void processBaseClass::getAlgVectorCategory(std::vector<std::string> *pCategoryVector)
{
    for(unsigned int j = 0; j < __algVector.size(); j++)
    {
            if( __algVector[j].isOpen)
            {
                pCategoryVector->push_back(__algVector[j].code);
            }
    }
}


