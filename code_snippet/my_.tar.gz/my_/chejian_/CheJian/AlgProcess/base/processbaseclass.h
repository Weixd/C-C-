#ifndef PROCESSBASECLASS_H
#define PROCESSBASECLASS_H

#include "baseinc.h"
#include "algbaseclass.h"



class processBaseClass
{
    public:
        //创建城市审核信息处理类
        static processBaseClass *creatPicProcessClass(CityType type);
        static bool checkCity(CityType type);
        virtual ~processBaseClass(){} //必须加否则会内存泄漏

        void setCityType(CityType cityType);

        //算法处理流程
        void algProcess(unsigned int algIndex, unsigned int photoIndex, std::vector<classItem> paramList, std::vector<PhotoItem> *pPhotoList, LargeVehicleApi *alg);

        //审核信息处理
        E_ZZJG picProcess(std::vector<classItem> paramList, std::vector<PhotoItem> *pPhotoList, LargeVehicleApi *alg);

        //审核信息处理
        E_ZZJG picProcess_thread(std::vector<classItem> paramList, std::vector<PhotoItem> *pPhotoList, LargeVehicleApi *alg);

        //通过PicType获取算法code
        std::string getAlgItemCodeByPicType(PicType type);
        //通过PicType获取算法name
        std::string getAlgItemNameByPicType(PicType type);
        algBaseClass *loadAlgBaseClassByPicType(PicType type);

        Json::Value getAlgVectorJson();

        unsigned int getHeDingZaiHeShu();
        void setHeDingZaiKeShuConfig(unsigned int hdzks);

        std::string getCityShortNmae();
        void setCityShortNameConfig(std::string shortName);

        std::string getCityType();

        Json::Value queryState();

        Json::Value getCLZLVectorJson();
        void deleteCheckCheLiangZhongLeiByKey(std::string key);
        void addCheckCheLiangZhongLeiByKey(std::string key);

        Json::Value getSYXZVectorJson();
        void deleteCheckShiYongXingZhiByKey(std::string key);
        void addCheckShiYongXingZhiByKey(std::string key);

        Json::Value getSmallVehicleVectorJson();
        void deleteCheckSmallVehicleVectorByKey(std::string key);
        void addCheckSmallVehicleVectorByKey(std::string key);

        Json::Value getJYLBVectorJson();
        void deleteCheckJianYanLeiBieByKey(std::string key);
        void addCheckJianYanLeiBieByKey(std::string key);

        Json::Value getJYJGVectorJson();
        void deleteCheckJianYanJiGouByKey(std::string bh);
        void addCheckJianYanJiGouByKey(std::string bh, std::string ip);

        Json::Value getHMDVectorJson();
        void deleteHeiMingDanByChePai(std::string chePai);
        void addHeiMingDanByChePai(std::string chePai);

        void getAlgVectorCategory(std::vector<std::string> *pCategoryVector);


        void saveConfig();
        //根据PicType设置算法是否需要检测
        bool setAlgItemNeedCheckByPicType(PicType type,bool needCheck);
        //用于子类修改结果元素检测项
        void changeCheckAlgBaseParamElementByName(algBaseClass *pHandle, std::string name, std::string desc, bool isOpen);
        //用于子类修改__algVector已有的算法映射关系 code ==>> type
        bool changeAlgVectorByType(algItem *pAlgItem);
        //用于子类新增各城市私有的算法类型
        bool addAlgVectorMember(std::string code, bool isOpen, std::string name,PicType type, bool subAlgClass);

        void freeThreadAndQueue();

    protected:
        //用于子类加载各个城市algVector的变化情况, 如果该类派生类不再本接口改变__algVector的内容，则不受参数文件影响，否责将被参数文件中内容覆盖
        virtual void changeAlgVector(){}
        //数据前置校验
        virtual bool subBeforAlgCheck(std::vector<classItem> paramList, std::vector<PhotoItem> *pPhotoList, LargeVehicleApi *alg){ UNUSED(paramList);UNUSED(pPhotoList);UNUSED(alg);return true;}
        //数据算法后校验
        virtual E_ZZJG subAfterAlgCheck(E_ZZJG baseResult,std::vector<classItem> paramList, std::vector<PhotoItem> *pPhotoList, LargeVehicleApi *alg){ UNUSED(baseResult);UNUSED(paramList);UNUSED(pPhotoList);UNUSED(alg);return baseResult;}

        //算法algVector检测
        virtual bool subAlgVectorCheck(algItem *pAlgItem, std::vector<PhotoItem> *pPhotoList, unsigned int pPhotoIndex){UNUSED(pAlgItem);UNUSED(pPhotoList);UNUSED(pPhotoIndex); return true;}
        //创建算法基础参数类
        virtual algBaseClass *subClassLoadAlgBaseClassByPicType(CityType cityType, std::string algName, PicType type);

    private:
        void init(CityType type);
        //加载参数文件
        void loadConfig();
        //将参数文件读取内容设置到__algVector中
        void setAlgVectorConfig(Json::Value root,std::vector<algItem> *pAlgVector);
        Json::Value getAlgVectorJson(std::vector<algItem> *pAlgVector);
        //将参数设置到 alterAlgCheck 中小车判定Vector (该参数如果不为空则会清空默认参数，将新参数填充进去修改请慎重)
        void setSmallVehicleVectorConfig(Json::Value root,std::vector<std::string> *pVector);
        void setCLZLVectorConfig(Json::Value root,std::vector<std::string> *pVector);
        void setJYLBVectorConfig(Json::Value root,std::vector<std::string> *pVector);
        void setSYXZVectorConfig(Json::Value root,std::vector<std::string> *pVector);
        void setJYJGVectorConfig(Json::Value root,std::vector<JYJG> *pVector);
        void setHMDVectorConfig(Json::Value root,std::vector<std::string> *pVector);

        //检验类别，使用性质 车辆种类 检验机构 三个有效性校验
        bool checkJianYanLeiBie(std::string jylb, std::vector<PhotoItem> *pPhotoList);
        bool checkShiYongXingZhi(std::string syxz, std::vector<PhotoItem> *pPhotoList);
        bool checkCheLiangZhongLei(std::string clzl, std::vector<PhotoItem> *pPhotoList);
        bool checkJianYanJiGou(std::string bh, std::string ip, std::vector<PhotoItem> *pPhotoList);
        bool checkHeDingZaiKeShu(std::string hdzks, std::vector<PhotoItem> *pPhotoList);
        bool checkIsSamllVehicle(std::string clzl, std::vector<PhotoItem> *pPhotoList);
        bool checkComplete(bool isTenYears,std::vector<PhotoItem> *pPhotoList);
        E_ZZJG checkUnqualified(bool isTenYears,std::vector<PhotoItem> *pPhotoList);
        bool checkHeiMingDan(std::string chePai, std::vector<PhotoItem> *pPhotoList);

        //数据前置校验
        bool beforAlgCheck(std::vector<classItem> paramList, std::vector<PhotoItem> *pPhotoList, LargeVehicleApi *alg);
        //数据前置校验
        E_ZZJG afterAlgCheck(std::vector<classItem> paramList, std::vector<PhotoItem> *pPhotoList, LargeVehicleApi *alg);
        //算法algVector检测
        bool algVectorCheck(algItem *pAlgItem, std::vector<PhotoItem> *pPhotoList, unsigned int pPhotoIndex);

        //创建算法基础参数类
        algBaseClass *loadAlgBaseClassByPicType(CityType cityType, std::string algName, PicType type, bool subParamClass);
        //加载算法使用的参数
        void loadParamByParamList(std::vector<classItem> paramList,algBaseClass *pHandle);
        //按照algBaseClass 中的结果Vector中汇总
        bool WriteResult(std::string algName, algBaseClass *pHandle, PhotoItem *pPhoto);

        CityType __cityType;
        std::string __configRoot = "/opt/vehicle/program/CheJianConfig";
        //检验类别
        std::vector<std::string> __JYLB ;
        std::vector<std::string> __SYXZ = {"A"};    //使用性质
        std::vector<std::string> __CLZL =  {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38", "K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48", "K49"};    //车辆种类
        std::vector<JYJG> __JYJG;   //检验机构
        unsigned int __HDZKS = 7;   //核定载客数
        std::string __cityShortName = "沪";
        std::vector<std::string> __smallVehicle = {"K31", "K32", "K33", "K34", "K35", "K36", "K37", "K38", "K41", "K42", "K43", "K44", "K45", "K46", "K47", "K48"};
        std::string __startTime = "2019-08-13 00:00:00";
        std::vector<std::string> __HMD ;
        std::vector<algItem> __algVector = {
            {"0111", true, "车辆左前方斜视45度-照片", e0111, false, false, false, 0, 0, 0, 0, 0, NULL, NULL},
            {"0112", true, "车辆右后方斜视45度-照片", e0112, false, false, false, 0, 0, 0, 0, 0, NULL, NULL},
            {"0113", true, "车辆识别(车架号)-照片", e0113, false, false, false, 0, 0, 0, 0, 0, NULL, NULL},
            {"0115", false, "车厢内部-照片", e0115, false, false, false, 0, 0, 0, 0, 0, NULL, NULL},
            {"0119", false, "发动机粘性标贴-照片", e0119, false, false, false, 0, 0, 0, 0, 0, NULL, NULL},
            {"0136", false, "左前轮胎规格型号-照片", e0136, false, false, false, 0, 0, 0, 0, 0, NULL, NULL},
            {"0156", false, "右前轮胎规格型号-照片", e0156, false, false, false, 0, 0, 0, 0, 0, NULL, NULL},
            {"0157", false, "安全带-照片", e0157, false, false, false, 0, 0, 0, 0, 0, NULL, NULL},
            {"0166", false, "车厢内部后排-照片", e0166, false, false, false, 0, 0, 0, 0, 0, NULL, NULL},
            {"0167", false, "车辆前方照片-照片", e0167, false, false, false, 0, 0, 0, 0, 0, NULL, NULL},
            {"0168", false, "车辆后方牌照-照片", e0168, false, false, false, 0, 0, 0, 0, 0, NULL, NULL},
            {"0175", false, "左方-照片", e0175, false, false, false, 0, 0, 0, 0, 0, NULL, NULL},

            {"0201", true, "行驶证-照片", e0201, false, false, false, 0, 0, 0, 0, 0, NULL, NULL},
            {"0202", true, "牌证申请表-照片", e0202, false, false, false, 0, 0, 0, 0, 0, NULL, NULL},
            {"0203", true, "交强险-照片", e0203, false, false, false, 0, 0, 0, 0, 0, NULL, NULL},
            {"0204", true, "检验报告-照片", e0204, false, false, false, 0, 0, 0, 0, 0, NULL, NULL},
            {"0205", true, "查验记录表-照片", e0205, false, false, false, 0, 0, 0, 0, 0, NULL, NULL},
            {"0206", false, "完税证明-照片", e0206, false, false, false, 0, 0, 0, 0, 0, NULL, NULL},
            {"0288", false, "行驶证(背面)-照片", e0288, false, false, false, 0, 0, 0, 0, 0, NULL, NULL},
            {"0209", false, "尾气检测报告-照片", e0209, false, false, false, 0, 0, 0, 0, 0, NULL, NULL},
            {"0287", false, "行驶证(正面)-照片", e0287, false, false, false, 0, 0, 0, 0, 0, NULL, NULL},
            {"0292", false, "机动车交强险(车船税)联网查询结果-照片", e0292, false, false, false, 0, 0, 0, 0, 0, NULL, NULL},
            {"0297", false, "检验报告(人工)-照片", e0297, false, false, false, 0, 0, 0, 0, 0, NULL, NULL},

            {"0321", true, "左灯光工位-照片", e0321, false, false, false, 0, 0, 0, 0, 0, NULL, NULL},
            {"0352", true, "右灯光工位-照片", e0352, false, false, false, 0, 0, 0, 0, 0, NULL, NULL},
            {"0322", true, "一轴制动(滚筒)-照片", e0322, false, true, false, 0, 0, 0, 0, 0, NULL, NULL},
            {"0348", true, "二轴制动(滚筒)-照片", e0348, false, true, false, 0, 0, 0, 0, 0, NULL, NULL},
            {"0344", true, "底盘动态检验开始-照片", e0344, false, true, false, 0, 0, 0, 0, 0, NULL, NULL},
            {"0342", true, "底盘动态检验结束-照片", e0342, false, true, false, 0, 0, 0, 0, 0, NULL, NULL},
            {"0351", true, "驻车制动工位-照片", e0351, false, true, false, 0, 0, 0, 0, 0, NULL, NULL},
            {"0323", true, "底盘检验-照片", e0323, false, true, false, 0, 0, 0, 0, 0, NULL, NULL},

            {"A", false, "车辆左前方斜视45度-档案照片", eCLZQFXS45DZP_A, false, false , false, 0, 0, 0, 0, 0, NULL, NULL},
            {"J", false, "车辆识别照片拓印膜-照片", eCLSBDHZP_TYM, false, false, false, 0, 0, 0, 0, 0, NULL, NULL},
            {"0210", false, "尾气检测报告-照片2", eWQDZP2, false, false, false, 0, 0, 0, 0, 0, NULL, NULL},
        };

};


#endif // PROCESSBASECLASS_H
