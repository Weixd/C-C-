#include "baseglobal.h"

#include "AlgProcess/city/demo_processclass.h"
#include "AlgProcess/city/dongguan_processclass.h"
#include "AlgProcess/city/yulin_processclass.h"
#include "AlgProcess/city/jiaxing_processclass.h"
#include "AlgProcess/city/dongying_processclass.h"
#include "AlgProcess/city/yingtan_processclass.h"
#include "AlgProcess/city/lianyungan/lianyungang_processclass.h"
#include "AlgProcess/alg/_c_0111_algclass.h"
#include "AlgProcess/alg/_c_0112_algclass.h"
#include "AlgProcess/alg/_c_0113_algclass.h"
#include "AlgProcess/alg/_c_0119_algclass.h"
#include "AlgProcess/alg/_c_0167_algclass.h"
#include "AlgProcess/alg/_c_0168_algclass.h"
#include "AlgProcess/alg/_c_0175_algclass.h"
#include "AlgProcess/alg/_c_0201_algclass.h"
#include "AlgProcess/alg/_c_0202_algclass.h"
#include "AlgProcess/alg/_c_0203_algclass.h"
#include "AlgProcess/alg/_c_0204_algclass.h"
#include "AlgProcess/alg/_c_0288_algclass.h"
#include "AlgProcess/alg/_c_0209_algclass.h"
#include "AlgProcess/alg/_c_0297_algclass.h"
#include "AlgProcess/alg/_c_0321_algclass.h"
#include "AlgProcess/alg/_c_0352_algclass.h"
#include "AlgProcess/alg/_c_0322_algclass.h"
#include "AlgProcess/alg/_c_0348_algclass.h"
#include "AlgProcess/alg/_c_0344_algclass.h"
#include "AlgProcess/alg/_c_0351_algclass.h"
#include "AlgProcess/alg/_c_0323_algclass.h"
#include "AlgProcess/alg/_c_0136_algclass.h"
#include "AlgProcess/alg/_c_0156_algclass.h"
#include "AlgProcess/alg/_c_0287_algclass.h"
#include "AlgProcess/alg/_c_0292_algclass.h"
#include "AlgProcess/alg/_c_0157_algclass.h"
#include "AlgProcess/alg/_c_0206_algclass.h"
#include "AlgProcess/alg/_c_0205_algclass.h"
#include "AlgProcess/alg/_c_0115_algclass.h"
#include "AlgProcess/alg/_c_0166_algclass.h"


bool processBaseClass::checkCity(CityType type)
{
    switch (type) {
        case eDongGuan:case eYuLin:case eJiaXing:case eDongYing:case eYingTan:
        {
            return true;
        }
        default:
            return false;
    }

    return false;
}

processBaseClass *processBaseClass::creatPicProcessClass(CityType type)
{
    processBaseClass *pReturn;
    switch (type) {
        case eDEMO:
        {
            pReturn = new demo_PicProcessClass();
        }
            break;
        case eDongGuan:
        {
            pReturn = new dongGuan_PicProcessClass();
        }
            break;
        case eYuLin:
        {
            pReturn = new yuLin_PicProcessClass();
        }
            break;
        case eJiaXing:
        {
            pReturn = new jiaXing_PicProcessClass();
        }
            break;
        case eDongYing:
        {
            pReturn = new dongYing_PicProcessClass();
        }
            break;
        case eYingTan:
        {
            pReturn = new YingTan_PicProcessClass();
        }
        break;

        default:
        {

            pReturn = new processBaseClass();
            type = eUNKONW;
        }
            break;
    }
    //派生类初始化
    pReturn->init(type);
    return pReturn;
}


algBaseClass *processBaseClass::loadAlgBaseClassByPicType(CityType cityType, std::string algName, PicType type, bool subParamClass)
{
    algBaseClass *pReturn = NULL;
    //盘算是否使用非基类提供的参数类
    if(subParamClass)
    {
        //返回虚函数子类参数类加载的返回值(一般用于提供的默认算法参数类不满足派生类使用)
        return subClassLoadAlgBaseClassByPicType(cityType,algName,type);
    }

    //按照父类提供算法默认使用的参数类返回
    switch (type) {
        case e0111:
        {
           pReturn = new _c_0111_AlgClass();

        }
           break;
        case e0112:
        {
           pReturn = new _c_0112_AlgClass();
        }
           break;
        case e0113:
        {
           pReturn = new _c_0113_AlgClass();
        }
           break;
        case e0167:
        {
           pReturn = new _c_0167_AlgClass();
        }
           break;
        case e0168:
        {
           pReturn = new _c_0168_AlgClass();
        }
       break;
        case e0175:
        {
           pReturn = new _c_0175_AlgClass();
        }
       break;
        case e0201:
        {
           pReturn = new _c_0201_AlgClass();
        }
       break;
        case e0202:
        {
           pReturn = new _c_0202_AlgClass();
        }
       break;
        case e0203:
        {
           pReturn = new _c_0203_AlgClass();
        }
       break;
        case e0204:
        {
           pReturn = new _c_0204_AlgClass();
        }
       break;
        case e0288:
        {
           pReturn = new _c_0288_AlgClass();
        }
       break;
        case e0209:
        {
           pReturn = new _c_0209_AlgClass();
        }
       break;
        case e0297:
        {
           pReturn = new _c_0297_AlgClass();
        }
       break;
        case e0321:
        {
           pReturn = new _c_0321_AlgClass();
        }
       break;
        case e0352:
        {
           pReturn = new _c_0352_AlgClass();
        }
       break;
        case e0322:
        {
           pReturn = new _c_0322_AlgClass();
        }
       break;
        case e0348:
        {
           pReturn = new _c_0322_AlgClass();
        }
       break;
        case e0344:
        {
           pReturn = new _c_0344_AlgClass();
        }
       break;
        case e0342:
        {
           pReturn = new _c_0344_AlgClass();
        }
       break;
        case e0351:
        {
           pReturn = new _c_0351_AlgClass();
        }
       break;
        case e0323:
        {
           pReturn = new _c_0323_AlgClass();
        }
       break;
        case e0136:
        {
           pReturn = new _c_0136_AlgClass();
        }
       break;
        case e0156:
        {
           pReturn = new _c_0156_AlgClass();
        }
       break;
        case e0287:
        {
           pReturn = new _c_0287_AlgClass();
        }
       break;
        case e0292:
        {
           pReturn = new _c_0203_AlgClass();
        }
        break;
        case e0157:
        {
           pReturn = new _c_0157_AlgClass();
        }
        break;
        case e0206:
        {
           pReturn = new _c_0206_AlgClass();
        }
        break;
        case e0205:
        {
           pReturn = new _c_0205_AlgClass();
        }
        break;
        case e0119:
        {
           pReturn = new _c_0119_AlgClass();
        }
        break;
        case e0115:
        {
           pReturn = new _c_0115_AlgClass();
        }
        break;
        case e0166:
        {
           pReturn = new _c_0166_AlgClass();
        }
        break;



        default:
        {
            //如果type不能识别返回虚函数子类参数类加载的返回值(让派生类自己实现参数类，一般用于新增城市私有算法接口)
            return subClassLoadAlgBaseClassByPicType(cityType,algName,type);
        }
            break;
    }
     pReturn->setBaseParam(cityType, type, algName);
     pReturn->initAlgClass();

     return pReturn;
}




