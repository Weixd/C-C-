#ifndef BASEINC_H
#define BASEINC_H
#include "json/json.h"
#include "baseglobal.h"
#include "large_vehicle_api.hpp"
#include <thread>
#include "Application/BlockQueue.h"

#define ALG_USED 1

class processBaseClass;
class algBaseClass;

struct JYJG {
    std::string bh;
    std::string ip;  /* 检验机构指定IP */
};


class classItem {
public:
    std::string name; //对应字段名称
    std::string dbtype; //数据库对应类型生成sql，需要符合数据语法

    std::string desc; // 描述
    std::string *value; //值地址
};

class vehicleCllxName {
public:
    std::string name;
    std::string cllx;
};

enum E_JG {
    PASS = 1,               /* 通过 */
    UNABLE_IDENTIFY = 4,    /* 无法比对,需人工 */
    NOT_PASS = 5,           /* 不通过 */
};

enum E_ZZJG {

    SOFT_NOTPROCESS = -1,       //-1：软件没有审核。使用性质，车辆类型等不在软件处理范围内。照片没有经过算法处理。
    SOFT_NOTPASS = 0,           //0：软件审核不通过。照片数量不全，或者任何一个照片判定为不通过。
    SOFT_PASS = 1,              //1：软件审核通过。所有照片都经过算法处理，并且都通过。
    MAN_PASS = 2,               //2：人工审核通过
    MAN_NOTPASS = 3,            //3：人工审核不通过
    SOFT_ERR = 4,               //4：软件审核未知。所有照片都经过算法处理，出现了判定为未知的照片，并且没有出现判定为不通过的照片。
};

class PhotoItem;

class algClassHandle {
public:
    unsigned int algIndex;
    unsigned int photoIndex;
    std::vector<classItem> *pParamList;
    std::vector<PhotoItem> *pPhotoList;
    LargeVehicleApi *alg;
    processBaseClass *pBaseClass;
    bool checkOver;
};


class PhotoItem {
public:
    std::string zpType;
    std::string zpUrl;
    std::string zpId;
    std::string localPath;
    std::string jg;
    std::string sm;
    std::string runTime;
    bool needThreadCheck = false;
    bool checkOver = false;
    PicType type;
    algClassHandle handle;
    unsigned int runTime_ms;

    /* 下面的排列顺序和数据库写入相关 */
    std::vector<classItem> ItemList = {
        {"zpType","","图片类型", &zpType},
        {"zpUrl","","图片路径", &zpUrl},
        {"zpId","","图片id", &zpId},
        {"localPath","","本地路径", &localPath},
        {"jg","","结果", &jg},
        {"sm","","说明", &sm},
        {"runTime","","运行时间", &runTime},
    };
};


#define ERROR_STR "不正确"

//-----------------序列-----------------处理类型--------参数vector------------------------照片信息-----------------------------参数体-----------------------算法句柄
#define ALGFUNC_TP unsigned int index, PicType type, std::vector<classItem> paramList, std::vector<PhotoItem> *pPhotoList, algBaseClass *pHandle, processBaseClass *pProcessClass,LargeVehicleApi *alg
#define ALG_P index, type, paramList, pPhotoList, pHandle, pProcessClass, alg

#define UNUSED(x) (void)x
#define ALG_P_UNUSED UNUSED(index);UNUSED(type);UNUSED(paramList);UNUSED(pPhotoList);UNUSED(pHandle);UNUSED(pProcessClass);UNUSED(alg);

#define ALGFUNC_RETURN bool




#define CONFIG_DEFAULT {true, true, {}, NOT_PASS}
#define CONFIG_DEFAULT_UNABLE {true, true, {}, UNABLE_IDENTIFY}
#define CONFIG_NOCHECK {false, true, {}, NOT_PASS}
#define CONFIG_NOCHECK_UNABLE {false, true, {}, UNABLE_IDENTIFY}
#define ALG_PARAM_DEFAULT {"", "", false}

typedef ALGFUNC_RETURN (processBaseClass::*classalgfunc)(ALGFUNC_TP);    //基类成员回调函数类型
typedef ALGFUNC_RETURN (*algfunc)(ALGFUNC_TP);                              //非类成员回调函数类型



typedef struct _ALG_PARM_MEMBER
{
    std::string inData;     //输入数据
    std::string OutData;    //输出数据
    bool result;            //返回结果
}ALG_PARM_MEMBER, *PALG_PARM_MEMBER;

typedef struct _ALG_PARAM_LINK
{
    int linkType;           // -1_无, 0_&&, 1_||
    std::string linkName;   //关联数据名称
}ALG_PARAM_LINK,*PALG_PARAM_LINK;

//std::vector<ALG_PARAM_LINK> linkVector = {};
typedef struct _ALG_PARM_CONFIG
{
    bool isOpen;                            //是否使用该字段
    bool descOpen;                          //是否使用参数文件中的desc
    std::vector<ALG_PARAM_LINK> linkVector; //关联器
    E_JG errLevel;                          //错误严重等级等级

}ALG_PARM_CONFIG, *PALG_PARM_CONFIG;

class memberItem {
public:
    std::string name;           //对应字段名称
    std::string desc;           //描述
    PALG_PARM_MEMBER value;     //值地址
    bool output;                //是否输出
    ALG_PARM_CONFIG config;     //参数配置
};

//用于记录算法于程序的处理关系
class algItem {
public:
    std::string code;           //处理类型识别code
    bool isOpen;                //接口是否启用(参数配置)
    std::string name;           //处理算法名称
    PicType type;               //处理类型唯一ID，不可重复
    bool needCheck;             //是否需要检测
    bool isTenYears;
    bool subAlgClass;           //使用派生类私有参数类
    unsigned int runCount;      //执行次数
    unsigned int passCount;     //执行通过率
    unsigned int avgTime;
    unsigned int maxTime;
    unsigned int minTime;
    std::thread *pThread;
    BlockingQueue<algClassHandle *> *pDataQueue;
};

class resultMemberList {
public:
    std::string name;
    std::vector<memberItem> *pVector;
};

class slaveInfo {
public:
    std::string user;
    std::string ip;
    std::string port;
};



#endif // BASEINC_H
