#ifndef BASETOOL_H
#define BASETOOL_H
#include "baseinc.h"
#include "Application/vehicle_inf.h"


class baseTool {
public:
    enum MSG_LEVEL {
        MSG = 1,
        WAR = 2,
        ERR = 3,
        DEBUG = 4,
    };


    static bool compareDate(std::string kssj, std::string PictureDate);
    static std::string formatingDate(std::string date,unsigned int index = 0);
    static std::string formatingTime(std::string date);
    static void closeMemberItemWriteResultByName(std::vector<memberItem> *pMemberList,std::string name);
    static void openMemberItemWriteResultByName(std::vector<memberItem> *pMemberList,std::string name);
    static bool getMemberItemIsOpenByName(std::vector<memberItem> memberList,std::string name);
    static memberItem *getMemberItemByName(std::vector<memberItem> *pMemberList,std::string name);
    static std::string getClassItemValueByName(std::vector<classItem> paramList, std::string name);
    static void changeCheckAlgBaseParamElementByName(algBaseClass *pHandle, std::string name, std::string desc, bool output);
    static void writeResultByJGAndSM(PhotoItem *pPhotoItem,E_JG jg, std::string sm);
    static bool isTenYears(std::string cuCiDengJiRiQi);
    static bool isInProvince(std::string fzjg,std::string ctiyForShort);
    static bool checkCllx(std::string cllx);
    static std::string getCllxNameByCllx(std::string cllx);
    static std::string seachPhotoPathByZpType(std::vector<PhotoItem> *pPhotoList,std::string zpType);
    static bool isCheBiao(std::string logo);
    static bool checkMemberItemAndSetAllUnOutput(std::vector<memberItem> *pMemberList,memberItem *pMemberItem);
    static void setAllPass(std::vector<memberItem> *pMemberList);
    static int isMobileNumber(std::string number);
    static bool checkIsNewCar(std::vector<classItem> paramList);
    static bool checkCllxIsK3xOrK4x(std::vector<classItem> paramList);
    static std::string getDangTianRiQi();
    static std::string getDangTianShiJian();
    //将 vehicle_inf 中车辆信息 填充到 pParamList 中
    static void loadParamByVehicleInfo(std::vector<classItem> *pParamList,vehicle_inf *pVehicleInfo);
    //将pVehicleInfo 中图片信息 填充到 pPhotoList 中
    static void loadPhotoListByVehicleInfo(std::vector<PhotoItem> *pPhotoList,vehicle_inf *pVehicleInfo);
    //判断是否是地址,通过长度来判断
    static bool isAddress(std::string utf8Address);
    //轮胎规格
    static string formatFileNameLunTai(std::string name);
    //将结果汇总到PhotoItem中
    static bool wirteResultByMemberList(std::string algName,PhotoItem *pPhoto,std::vector<memberItem> *pMemberList);
    //通过zpType 从 photoList 中找出相对应的 PhotoItem
    static PhotoItem *seachPhotoByZpType(std::vector<PhotoItem> *pPhotoList,std::string  zpType);
    //检测文件是否存在
    static bool fileIsExist(std::string fileName);
    // 将照片处理结果回写到 vehicle_inf 中去
    static void loadVehicleInfoByPhotoList(vehicle_inf *pVehicleInfo,std::vector<PhotoItem> *pPhotoList);
    //打印归口
    static void msgOut(MSG_LEVEL level, const char *pccFunc, const int ciLine,std::string msg);
    //字符串转int
    static int str2Int(std::string str);

    //判断是否是目录
    static bool isFolder(std::string src);
    //文件拷贝
    static int copyFile(std::string src, std::string des);
    //文件夹拷贝
    static int copyFolder(std::string src, std::string des);
    //检测目录是否存在 不存在则创建目录
    static int CheckDir(std::string Path);
    //获取clpp 目标 品牌
    static std::string getDestClpp(std::string srcClpp);

    static void saveConfigByJson(std::string fileName,Json::Value root);
private:

};


#endif // BASETOOL_H
