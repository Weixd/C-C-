#ifndef ALGBASEPARAMCLASS_H
#define ALGBASEPARAMCLASS_H
#include "baseinc.h"
#include "basetool.h"
#include "AlgProcess/alg/algapi/algbaseapi.h"
#include "AlgProcess/base/baseparamlist.h"

class algBaseClass{
public:
    std::vector<memberItem> *pInMemberList;     //参数成员列表指针 如果不是派生类该指针为NULL
    std::vector<memberItem> *pResultMemberList; //输出成员列表指针 如果不是派生类该指针为NULL
    std::vector<resultMemberList> inListVector;
    std::vector<resultMemberList> resultListVector;
    ALLParamList allParamList;                  //用以检测参数合法性
    bool inListVectorPrintf = false;
    bool resultListVectorPrintf = false;

    virtual ~algBaseClass(){}                   //用于释放内存（必须）
    ALGFUNC_RETURN Process(ALGFUNC_TP);         //

    virtual Json::Value getResultMemberListJson();
    virtual void loadAlgClassConfig();
    virtual void setResultConfig(Json::Value root);
    void saveResultConfig();

    virtual void setResultMember(std:: string memberName, memberItem *pResultMember);

    bool loadPhotoMain(std::string photoPath);  //加载主图片
    bool loadPhotoSub(std::string photoPath);   //加载子图片
    void setBaseParam(CityType cityType,PicType type, std::string algName); //填充参数
    void initAlgClass();
    virtual ALGFUNC_RETURN seekMemberListPointer(){return true;}
    virtual bool subClassLoadNewResultMember(){return true;}
    bool closeMemberOutputByName(std::string name);
    void addNewResultMember(memberItem *pMember);
    void setStartTime();
    void setEndTime();
    std::string getRunTime();
    unsigned int getRunTime_ms();
    void printfInParam();
    void printfResultMember();

protected:
    CityType _cityType;                          //城市类型
    PicType _type;                               //算法处理类型
    std::string _algName;                        //算法名称或者说明(暂时无用，后续准备当作输出前缀使用)
    std::string _configRoot = "/opt/vehicle/program/CheJianConfig";
    cv::Mat _photoMain;                          //主图片
    cv::Mat _photoSub;                           //子图片

    std::chrono::time_point<std::chrono::system_clock> _start;
    std::chrono::time_point<std::chrono::system_clock> _end;

    virtual ALGFUNC_RETURN LoadParam(ALGFUNC_TP){ALG_P_UNUSED return true;}
    virtual ALGFUNC_RETURN BeforDispose(ALGFUNC_TP){ALG_P_UNUSED return true;}
    virtual ALGFUNC_RETURN Dispose(ALGFUNC_TP){ALG_P_UNUSED return true;}
    virtual ALGFUNC_RETURN AfterDispose(ALGFUNC_TP){ALG_P_UNUSED return true;}
    virtual ALGFUNC_RETURN AlgResult(ALGFUNC_TP){ALG_P_UNUSED return true;}
    virtual ALGFUNC_RETURN AfterAlgResult(ALGFUNC_TP){ALG_P_UNUSED return true;}
    virtual ALGFUNC_RETURN NeedWriteResult(ALGFUNC_TP);
};
#endif // ALGBASEPARAMCLASS_H
