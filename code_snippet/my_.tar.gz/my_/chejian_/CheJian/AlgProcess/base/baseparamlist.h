#ifndef BASEPARAMLIST_H
#define BASEPARAMLIST_H
#include "AlgProcess/base/baseinc.h"
#include "AlgProcess/base/basetool.h"

class ALLParamList{
public:
    ALG_PARM_MEMBER chePaiHao;
    ALG_PARM_MEMBER cheJiaHao;
    ALG_PARM_MEMBER shuiYinRiQi;
    ALG_PARM_MEMBER zongZhiLiang;
    ALG_PARM_MEMBER cheLiangLeiXing;
    ALG_PARM_MEMBER xingShiZhengXinBianHao;
    ALG_PARM_MEMBER faZhengRiQi;
    ALG_PARM_MEMBER dangAnHao;
    ALG_PARM_MEMBER heDingZaiKeShu;
    ALG_PARM_MEMBER haoPaiZhongLei;
    ALG_PARM_MEMBER faDongJiHao;
    ALG_PARM_MEMBER shengXiaoRiQi;
    ALG_PARM_MEMBER zhongZhiRiQi;
    ALG_PARM_MEMBER jianYanJieShuShiJian;
    ALG_PARM_MEMBER weiQiJianCeShiJian;
    ALG_PARM_MEMBER dangTianRiQi;
    ALG_PARM_MEMBER chuCiDengJiRiQi;
    ALG_PARM_MEMBER zhuChe;
    ALG_PARM_MEMBER cheWaiKuoGao;
    ALG_PARM_MEMBER lunTaiGuiGe;
    ALG_PARM_MEMBER jianYanKaiShiShiJian;
    ALG_PARM_MEMBER qiangZhiBaoFeiQiZhi;

    std::vector<memberItem> allMemberList = {
        {"chePaiHao", "车牌号", &chePaiHao, true, CONFIG_DEFAULT},
        {"cheJiaHao", "车架号", &cheJiaHao, true, CONFIG_DEFAULT},
        {"shuiYinRiQi", "照片水印日期", &shuiYinRiQi, true, CONFIG_DEFAULT},
        {"cheLiangLeiXing", "车辆类型编码", &cheLiangLeiXing, true, CONFIG_NOCHECK},
        {"zongZhiLiang", "总质量", &zongZhiLiang, true, CONFIG_DEFAULT},
        {"xingShiZhengXinBianHao", "行驶证(证芯)编号", &xingShiZhengXinBianHao, true, CONFIG_DEFAULT},
        {"faZhengRiQi", "发证日期", &faZhengRiQi, true, CONFIG_DEFAULT},
        {"dangAnHao", "档案号", &dangAnHao, true, CONFIG_DEFAULT},
        {"heDingZaiKeShu", "核定载客数", &heDingZaiKeShu, true, CONFIG_DEFAULT},
        {"haoPaiZhongLei", "号牌种类", &haoPaiZhongLei, true, CONFIG_DEFAULT},
        {"faDongJiHao", "发动机号", &faDongJiHao, true, CONFIG_DEFAULT},
        {"shengXiaoRiQi", "生效日期", &shengXiaoRiQi, true, CONFIG_DEFAULT},
        {"zhongZhiRiQi", "终止日期", &zhongZhiRiQi, true, CONFIG_DEFAULT},
        {"jianYanJieShuShiJian", "检验结束时间", &jianYanJieShuShiJian, true, CONFIG_DEFAULT},
        {"weiQiJianCeShiJian", "尾气检测时间", &weiQiJianCeShiJian, true, CONFIG_DEFAULT},
        {"dangTianRiQi", "当天日期", &dangTianRiQi, true, CONFIG_DEFAULT},
        {"chuCiDengJiRiQi", "初次登记日期", &chuCiDengJiRiQi, true, CONFIG_DEFAULT},
        {"zhuChe", "驻车", &zhuChe, true, CONFIG_DEFAULT},
        {"cheWaiKuoGao", "车外廓高", &cheWaiKuoGao, true, CONFIG_DEFAULT},
        {"lunTaiGuiGe", "轮胎规格", &lunTaiGuiGe, true, CONFIG_DEFAULT},
        {"jianYanKaiShiShiJian", "检验开始时间", &jianYanKaiShiShiJian, true, CONFIG_DEFAULT},
        {"qiangZhiBaoFeiQiZhi", "强制报废日期", &qiangZhiBaoFeiQiZhi, true, CONFIG_NOCHECK},
    };

    bool checkList(std::vector<memberItem> *pMemberList)
    {
        for (unsigned int j =0; j<pMemberList->size(); j++) {
            bool isPass = false;
            for (unsigned int i = 0; i < allMemberList.size(); i++) {
                if(allMemberList[i].name == (*pMemberList)[j].name)
                {
                    isPass=true;
                    break;
                }
            }
            if(!isPass)
            {
                baseTool::msgOut(baseTool::WAR, __FILE__, __LINE__, "name:"+(*pMemberList)[j].name+" is unkonw");
                return false;
            }
        }
        return true;
    }
};


#endif // BASEPARAMLIST_H
