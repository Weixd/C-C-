#ifndef _C_9999_CLASS_H
#define _C_9999_CLASS_H

#include "_c_9999_algapi.h"

class _c_9999_algClass:public _c_9999_AlgApi{
public:
    virtual ALGFUNC_RETURN BeforDispose(ALGFUNC_TP);
    virtual ALGFUNC_RETURN AlgResult(ALGFUNC_TP);
};

#endif // _C_9999_CLASS_H
