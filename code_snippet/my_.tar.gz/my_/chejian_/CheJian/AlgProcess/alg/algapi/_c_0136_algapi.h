#ifndef _C_0136_ALGAPI_H
#define _C_0136_ALGAPI_H
#include "algbaseapi.h"

class _c_0136_AlgApi:public algBaseApi{
public:
    ALG_PARM_MEMBER lunTaiGuiGe = ALG_PARAM_DEFAULT;

    std::vector<memberItem> inMemberList = {
        {"lunTaiGuiGe", "轮胎规格", &lunTaiGuiGe, true, CONFIG_DEFAULT},
    };

    std::vector<memberItem> resultMemberList = {
        {"lunTaiGuiGe", "轮胎规格有误", &lunTaiGuiGe, true, CONFIG_DEFAULT},
    };

    int Dispose(LargeVehicleApi *alg);
};


#endif // _C_0136_ALGAPI_H
