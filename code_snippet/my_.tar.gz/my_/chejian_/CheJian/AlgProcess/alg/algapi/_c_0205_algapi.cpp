#include "_c_0205_algapi.h"

int _c_0205_AlgApi::Dispose(LargeVehicleApi *alg)
{

#if ALG_USED
    Jianyanbiao_ImgOutMsg out_msg;
    alg->jianyanbiao_api_process(_photoMain, chePaiHao.inData, cheJiaHao.inData, dangTianRiQi.inData, out_msg);

     chePaiHao.result = out_msg.b_chepai;
     jianYanBiao.result = out_msg.b_jianyanbiao;
     qianZi_waiGuanJianYanYuan.result = out_msg.b_waiguan_sign;
     jianYanJieLun.result = out_msg.b_jielun;
     qianZi_chaYanYuan.result = out_msg.b_qianzi;
     qianZi_yinCheJianYanYuan.result = out_msg.b_yinche_sign;
     qianZi_diPanJianYanYuan.result = out_msg.b_dipan_sign;

     for (unsigned int i = 0; i < out_msg.v_panding.size(); i++) {
        jianYanXiang.push_back(out_msg.v_panding[i]);
     }
#endif
    UNUSED(alg);
    return 1;
}
