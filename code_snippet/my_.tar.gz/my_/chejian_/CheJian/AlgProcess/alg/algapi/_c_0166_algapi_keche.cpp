#include "_c_0166_algapi_keche.h"
#include "AlgProcess/base/basetool.h"

int _c_0166_AlgApi_keChe::Dispose(LargeVehicleApi *alg)
{
#if ALG_USED
    Kechexiang_ImgOutMsg out;
    alg->kechexiang_api_process(_photoMain,baseTool::str2Int(heDingZaiKeShu.inData), out);

    gaiZhuang.result = out.b_suspect_modified;
    paiSheGuiFan.result = out.b_internal;
    zuoWeiShu.result = out.b_seat;
    anQuanDai.result = out.b_anquandai;
#endif
    UNUSED(alg);
    return 1;
}
