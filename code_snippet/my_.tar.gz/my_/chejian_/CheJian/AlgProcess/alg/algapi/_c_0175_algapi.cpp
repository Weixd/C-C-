#include "_c_0175_algapi.h"

int _c_0175_AlgApi::Dispose(LargeVehicleApi *alg)
{

#if ALG_USED
    Cheliang_ImgOutMsg out_msg_ce_mian;
    std::vector<cv::Mat> empty;  //fixme9.24
    alg->cheliang_api_process(_photoMain, _photoSub,empty,"", chePaiHao.inData,"", eOtherType, out_msg_ce_mian);//fixme9.24
    guangGao.OutData = std::to_string(out_msg_ce_mian.i_tiehua);
    cheLiangYanSe.result = out_msg_ce_mian.b_ori_color;
#endif

    UNUSED(alg);
    return 1;
}
