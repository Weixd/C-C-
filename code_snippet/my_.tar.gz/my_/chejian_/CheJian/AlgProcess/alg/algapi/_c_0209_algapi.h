#ifndef _C_0209_ALGAPI_H
#define _C_0209_ALGAPI_H
#include "algbaseapi.h"

class _c_0209_AlgApi:public algBaseApi{
public:
    ALG_PARM_MEMBER cheJiaHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER chePaiHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER weiQiJianCeShiJian = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER faDongJiXingHao = ALG_PARAM_DEFAULT;

    ALG_PARM_MEMBER huanBaoJianYanJieLun = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER yinZhang = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER qianMing = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER yinZhang_CMA = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER jianCeShiJian = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER qianMing_caoZuoYuan = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER qianMing_jiaShiYuan = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER qianMing_piZhunRen = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER qianMing_shenHeRen = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER qianMing_shouQuanRen = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER dianZiBiaoGe = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER huanBaoDan = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER dangTianRiQi = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER cheLiangLeiXing = ALG_PARAM_DEFAULT;


    std::vector<std::string> shiJianVector;

    std::vector<memberItem> inMemberList = {
        {"cheJiaHao", "车架号", &cheJiaHao, true, CONFIG_DEFAULT},
        {"chePaiHao", "车牌号", &chePaiHao, true, CONFIG_DEFAULT},
        {"weiQiJianCeShiJian", "尾气检测时间", &weiQiJianCeShiJian, true, CONFIG_DEFAULT},
        {"faDongJiXingHao", "发动机型号", &faDongJiXingHao, true, CONFIG_DEFAULT},
        {"dangTianRiQi", "当天日期", &dangTianRiQi, true, CONFIG_DEFAULT},
        {"cheLiangLeiXing", "车辆类型", &cheLiangLeiXing, true, CONFIG_DEFAULT},
    };

    std::vector<memberItem> resultMemberList = {
        {"huanBaoJianYanJieLun", "检查结论不通过", &huanBaoJianYanJieLun, true, CONFIG_NOCHECK},
        {"chePaiHao", "车牌号不正确", &chePaiHao, true, CONFIG_DEFAULT},
        {"cheJiaHao", "车架号不正确", &cheJiaHao, true, CONFIG_DEFAULT},
        {"yinZhang", "没有印章", &yinZhang, true, CONFIG_DEFAULT},
        {"qianMing", "没有签名", &qianMing, true, CONFIG_DEFAULT},
        {"yinZhang_CMA", "没有\"CMA\"印章", &yinZhang_CMA, true, CONFIG_NOCHECK},
        {"weiQiJianCeShiJian", "检测日期不在有效期内", &weiQiJianCeShiJian, true, CONFIG_NOCHECK},
        {"faDongJiXingHao", "发动机编号不合格", &faDongJiXingHao, true, CONFIG_NOCHECK},
        {"jianCeShiJian", "检测时间不符合", &jianCeShiJian, true, CONFIG_NOCHECK},
        {"qianMing_caoZuoYuan", "没有操作员签名", &qianMing_caoZuoYuan, true, CONFIG_NOCHECK},
        {"qianMing_jiaShiYuan", "没有驾驶员签名", &qianMing_jiaShiYuan, true, CONFIG_NOCHECK},
        {"qianMing_piZhunRen", "没有批准人签字", &qianMing_piZhunRen, true, CONFIG_NOCHECK},
        {"qianMing_shenHeRen", "没有审核员签字", &qianMing_shenHeRen, true, CONFIG_NOCHECK},
        {"qianMing_shouQuanRen", "没有授权人签字", &qianMing_shouQuanRen, true, CONFIG_NOCHECK},
        {"dianZiBiaoGe", "不是电子表格", &dianZiBiaoGe, true, CONFIG_NOCHECK},
        {"huanBaoDan", "照片不是尾气检测报告", &huanBaoDan, true, CONFIG_NOCHECK},
        {"cheLiangLeiXing", "车辆类型不正确", &cheLiangLeiXing, true, CONFIG_NOCHECK},
    };

    int Dispose(LargeVehicleApi *alg);
};

#endif // _C_0209_ALGAPI_H
