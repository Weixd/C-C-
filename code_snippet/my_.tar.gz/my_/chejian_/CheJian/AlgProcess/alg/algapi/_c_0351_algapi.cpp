#include "_c_0351_algapi.h"

int _c_0351_AlgApi::Dispose(LargeVehicleApi *alg)
{
#if ALG_USED
    Zhidong_ImgOutMsg out_msg;
    int car_kind =1;
    alg->zhidong_api_process(_photoMain, chePaiHao.inData, 2, 2, car_kind,  out_msg);

    zhiDong.result = out_msg.b_zhidong;
   // shuiYinRiQi.result = out_msg.b_shuiyin_riqi;
    chePaiHao.result = out_msg.b_chepai;
#endif
    UNUSED(alg);
    return 1;
}
