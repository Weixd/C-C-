#ifndef _C_0204_ALGAPI_H
#define _C_0204_ALGAPI_H
#include "algbaseapi.h"

class _c_0204_AlgApi:public algBaseApi{
public:
    ALG_PARM_MEMBER cheJiaHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER chePaiHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER jianYanJieShuShiJian = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER cheLiangLeiXing = ALG_PARAM_DEFAULT;


    ALG_PARM_MEMBER jianYanJieLun = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER shuJuXiang = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER qianMing = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER yinZhang = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER yinZhang_CMA = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER yinZhang_queRen = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER zhaoPianQingXiDu = ALG_PARAM_DEFAULT;




    std::vector<memberItem> inMemberList = {
        {"cheJiaHao", "车架号", &cheJiaHao, true, CONFIG_DEFAULT},
        {"chePaiHao", "车牌号", &chePaiHao, true, CONFIG_DEFAULT},
        {"jianYanJieShuShiJian", "检验结束时间", &jianYanJieShuShiJian, true, CONFIG_DEFAULT},
        {"cheLiangLeiXing", "车辆类型编码", &cheLiangLeiXing, true, CONFIG_NOCHECK},

    };

    std::vector<memberItem> resultMemberList = {
        {"chePaiHao", "车牌号不正确", &chePaiHao, true, CONFIG_DEFAULT},
        {"cheLiangLeiXing", "车辆类型不正确", &cheLiangLeiXing, true, CONFIG_NOCHECK},
        {"cheJiaHao", "车架号不正确", &cheJiaHao, true, CONFIG_DEFAULT},
        {"jianYanJieLun", "结论不合格", &jianYanJieLun, true, CONFIG_DEFAULT},
        {"shuJuXiang", "数据项不正确", &shuJuXiang, true, CONFIG_NOCHECK},
        {"qianZi", "没有签名", &qianMing, true, CONFIG_DEFAULT},
        {"yinZhang", "没有印章", &yinZhang, true, CONFIG_DEFAULT},
        {"yinZhang_CMA", "没有\"CMA\"印章", &yinZhang_CMA, true, CONFIG_NOCHECK},
        {"yinZhang_queRen", "没有确认印章", &yinZhang_queRen, true, CONFIG_NOCHECK},
        {"zhaoPianQingXiDu", "图片信息不规范", &zhaoPianQingXiDu, true, CONFIG_NOCHECK_UNABLE},
    };

    int Dispose(LargeVehicleApi *alg);
};

#endif // _C_0204_ALGAPI_H
