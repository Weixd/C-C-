#include "_c_0157_algapi.h"

int _c_0157_AlgApi::Dispose(LargeVehicleApi *alg)
{
#if ALG_USED
    Anquandai_ImgOutMsg aqddata;

    alg->anquandai_api_process(_photoMain, aqddata);

    anQuanDai.result = aqddata.b_anquandai;
 //   jianYanJieShuShiJian.OutData = aqddata.date_stamp;
#endif
    UNUSED(alg);
    return 1;
}
