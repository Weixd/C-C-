#include "_c_0352_algapi.h"

int _c_0352_AlgApi::Dispose(LargeVehicleApi *alg)
{
#if ALG_USED
    Light_ImgOutMsg out_msg;

    alg->light_api_process(_photoMain, chePaiHao.inData, out_msg);

    youDeng1.result = out_msg.b_car_left_light_on;
    youDeng2.result = out_msg.b_car_right_light_on;

  //  shuiYinRiQi.result = out_msg.b_shuiyin_riqi;
    chePaiHao.result = out_msg.b_chepai;//fixme9.24

#endif

    UNUSED(alg);
    return 1;
}
