#ifndef _C_0348_ALGAPI_H
#define _C_0348_ALGAPI_H
#include "algbaseapi.h"

class _c_0348_AlgApi:public algBaseApi{
public:
    ALG_PARM_MEMBER zhuChe = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER chePaiHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER shuiYinRiQi = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER cheLiangLeiXing = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER yiZhou = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER erZhou = ALG_PARAM_DEFAULT;

    ALG_PARM_MEMBER zhaopianChiCun = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER daCheJianCe = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER queShaoYiZhouZhaoPian = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER gunTong1 = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER gunTong2 = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER zhiDongDeng = ALG_PARAM_DEFAULT;

    std::vector<memberItem> inMemberList = {
        {"zhuChe", "驻车", &zhuChe, true, CONFIG_DEFAULT},
        {"chePaiHao", "车牌号", &chePaiHao, true, CONFIG_DEFAULT},
        {"cheLiangLeiXing", "车辆类型", &cheLiangLeiXing, true, CONFIG_DEFAULT},
        {"shuiYinRiQi", "水印日期", &shuiYinRiQi, true, CONFIG_DEFAULT},
    };

    std::vector<memberItem> resultMemberList = {
        {"yiZhou", "车轮位置不对", &yiZhou, true, CONFIG_DEFAULT},
        {"erZhou", "二轴车轮位置不对", &erZhou, true, CONFIG_NOCHECK},
        {"chePaiHao", "车牌号不正确", &chePaiHao, true, CONFIG_DEFAULT},
        {"shuiYinRiQi", "照片水印日期过期", &shuiYinRiQi, true, CONFIG_NOCHECK},
        {"zhaopianChiCun", "一轴二轴照片分辨率不一样", &zhaopianChiCun, true, CONFIG_NOCHECK},
        {"daCheJianCe", "暂不判定大车制动", &daCheJianCe, true, {false, true, {}, UNABLE_IDENTIFY}},
        {"queShaoYiZhouZhaoPian", "缺少一轴制动工位照片", &queShaoYiZhouZhaoPian, true, CONFIG_NOCHECK},
        {"gunTong1", "滚筒1", &gunTong1, false, CONFIG_NOCHECK},
        {"gunTong2", "滚筒2", &gunTong2, false, CONFIG_NOCHECK},
        {"zhiDongDeng", "制动灯未亮", &zhiDongDeng, true, CONFIG_NOCHECK},
    };

    int Dispose(LargeVehicleApi *alg);
};

#endif // _C_0348_ALGAPI_H
