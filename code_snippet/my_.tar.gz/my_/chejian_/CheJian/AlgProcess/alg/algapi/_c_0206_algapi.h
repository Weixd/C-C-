#ifndef _C_0206_ALGAPI_H
#define _C_0206_ALGAPI_H
#include "algbaseapi.h"

class _c_0206_AlgApi:public algBaseApi{
public:
    ALG_PARM_MEMBER chePaiHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER cheJiaHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER jianYanJieShuShiJian = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER cheChuanShui = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER shuiKuanSuoShuRiQi = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER wanShuiZhengMing = ALG_PARAM_DEFAULT;


    std::vector<memberItem> inMemberList = {
        {"chePaiHao", "车牌号", &chePaiHao, true, CONFIG_DEFAULT},
        {"cheJiaHao", "车架号", &cheJiaHao, true, CONFIG_DEFAULT},
        {"jianYanJieShuShiJian", "检验结束时间", &jianYanJieShuShiJian, true, CONFIG_DEFAULT},
    };

    std::vector<memberItem> resultMemberList = {
        {"chePaiHao", "车牌号不正确", &chePaiHao, true, CONFIG_DEFAULT},
        {"cheJiaHao", "车架号不正确", &cheJiaHao, true, CONFIG_NOCHECK},
        {"cheChuanShui", "车船税不合格", &cheChuanShui, true, CONFIG_DEFAULT},
        {"shuiKuanSuoShuRiQi", "税款所属日期不是整年", &shuiKuanSuoShuRiQi, true, CONFIG_NOCHECK},
        {"jianYanJieShuShiJian", "日期不正确", &jianYanJieShuShiJian, true, CONFIG_NOCHECK},
        {"wanShuiZhengMing", "照片不是完税证明", &wanShuiZhengMing, true, CONFIG_NOCHECK},

    };

    int Dispose(LargeVehicleApi *alg);
};


#endif // _C_0206_ALGAPI_H
