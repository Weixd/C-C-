#include "_c_0202_algapi.h"

int _c_0202_AlgApi::Dispose(LargeVehicleApi *alg)
{

#if ALG_USED
    Shenqingdan_ImgOutMsg sqbdata;
    alg->shenqingbiao_api_process(_photoMain, chePaiHao.inData,cheJiaHao.inData , haoPaiZhongLei.inData, sqbdata);
    suoYouRenShouJiHao.OutData = sqbdata.telephone_suoyouren;
    daiLiRenShouJiHao.OutData = sqbdata.telephone_dailiren;
    chePaiHao.result = sqbdata.b_chepai;
    diZhi.result = sqbdata.b_address;
    haoPaiZhongLei.result = sqbdata.b_chepai_type;
    qianMing.result = sqbdata.b_qianming;
    xingMing.result = sqbdata.b_xingming;
    jianYanHeGeBiaoZhi.result = sqbdata.b_jianyanhegebiaozhi;
    zhaoPianQingXiDu.result = sqbdata.b_pic_quality;
    riQi.result = sqbdata.b_date;
#endif
    UNUSED(alg);
    return 1;
}
