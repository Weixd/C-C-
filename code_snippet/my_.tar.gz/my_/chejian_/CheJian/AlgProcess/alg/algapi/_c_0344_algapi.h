#ifndef _C_0344_ALGAPI_H
#define _C_0344_ALGAPI_H
#include "algbaseapi.h"

class _c_0344_AlgApi:public algBaseApi{
public:
    ALG_PARM_MEMBER chePaiHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER chePaiHao2 = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER shuiYinRiQi = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER queShaoJieShuZhaoPian = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER queShaoKaiShiZhaoPian = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER cheWeiDong = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER cheTou = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER cheWei = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER biaoZhi = ALG_PARAM_DEFAULT;

    std::vector<memberItem> inMemberList = {
        {"chePaiHao", "车牌号", &chePaiHao, true, CONFIG_DEFAULT},
        {"shuiYinRiQi", "水印日期", &shuiYinRiQi, true, CONFIG_DEFAULT},
    };

    std::vector<memberItem> resultMemberList_kaiShi = {
        {"queShaoJieShuZhaoPian", "缺少底盘动态检验结束照片", &queShaoJieShuZhaoPian, true, CONFIG_NOCHECK_UNABLE},
        {"chePaiHao", "车牌号不正确", &chePaiHao, true, CONFIG_DEFAULT},
        {"chePaiHao2", "车牌号2(不做输出用于车牌号判定逻辑)", &chePaiHao2, false, CONFIG_NOCHECK},
        {"shuiYinRiQi", "照片水印日期过期", &shuiYinRiQi, true, CONFIG_NOCHECK},
        {"cheWeiDong", "车未移动", &cheWeiDong, true, CONFIG_NOCHECK},
        {"cheWei", "未检测到车尾", &cheWei, true, CONFIG_NOCHECK},
        {"biaoZhi", "未检测到标志", &biaoZhi, true, CONFIG_NOCHECK},
    };

    std::vector<memberItem> resultMemberList_jieShu = {
        {"queShaoKaiShiZhaoPian", "缺少底盘动态检验开始照片", &queShaoKaiShiZhaoPian, true, CONFIG_NOCHECK_UNABLE},
        {"chePaiHao", "车牌号不正确", &chePaiHao, true, CONFIG_DEFAULT},
        {"chePaiHao2", "车牌号2(不做输出用于车牌号判定逻辑)", &chePaiHao2, false, CONFIG_NOCHECK},
        {"shuiYinRiQi", "照片水印日期过期", &shuiYinRiQi, true, CONFIG_NOCHECK},
        {"cheWeiDong", "车未移动", &cheWeiDong, true, CONFIG_NOCHECK},
        {"cheTou", "未检测到车头", &cheTou, true, CONFIG_NOCHECK},
    };

    int Dispose(LargeVehicleApi *alg);
};

#endif // _C_0344_ALGAPI_H
