#ifndef _C_0215_ALGAPI_H
#define _C_0215_ALGAPI_H
#include "algbaseapi.h"

class _c_0215_AlgApi:public algBaseApi{
public:
    ALG_PARM_MEMBER shenFenZhengFanMian = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER youXiaoRiQi = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER xingMing = ALG_PARAM_DEFAULT;


    std::vector<memberItem> inMemberList = {

    };

    std::vector<memberItem> resultMemberList = {
        {"shenFenZhengFanMian", "身份证(反面)不匹配", &shenFenZhengFanMian, true, CONFIG_DEFAULT},
        {"youXiaoRiQi", "身份证不在有效期", &youXiaoRiQi, true, CONFIG_DEFAULT},
    };

    int Dispose(LargeVehicleApi *alg);
};

#endif // _C_0215_ALGAPI_H
