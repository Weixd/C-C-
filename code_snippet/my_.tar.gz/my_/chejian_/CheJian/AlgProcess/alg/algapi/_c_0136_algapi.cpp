#include "_c_0136_algapi.h"

int _c_0136_AlgApi::Dispose(LargeVehicleApi *alg)
{
#if ALG_USED
    Luntaiguige_ImgOutMsg out_msg;
    alg->luntaiguige_api_process(_photoMain, lunTaiGuiGe.inData, out_msg);
    lunTaiGuiGe.result = out_msg.b_luntaiguige;
#endif

    UNUSED(alg);
    return 1;
}
