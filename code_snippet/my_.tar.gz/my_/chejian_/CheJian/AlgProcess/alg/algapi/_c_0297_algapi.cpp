#include "_c_0297_algapi.h"

int _c_0297_AlgApi::Dispose(LargeVehicleApi *alg)
{
#if ALG_USED
    Jianyanbiao_ImgOutMsg out_msg;

    alg->jianyanbiao_api_process(_photoMain, chePaiHao.inData, cheJiaHao.inData, dangTianRiQi.inData, out_msg);

    jianYanBiao.result = out_msg.b_jianyanbiao;
    chePaiHao.result = out_msg.b_chepai;
    dangTianRiQi.result = out_msg.b_jianyanriqi;
    qianMing_waiGuanJianYanYuan.result = out_msg.b_waiguan_sign;
    qianMing_yinCheJianYanYuan.result = out_msg.b_yinche_sign;
    qianMing_diPanJianYanYuan.result = out_msg.b_dipan_sign;
    jianYanJieGuoDiWuXiang.result = out_msg.b_jianyanjieguo5;
#endif
    UNUSED(alg);
    return 1;
}
