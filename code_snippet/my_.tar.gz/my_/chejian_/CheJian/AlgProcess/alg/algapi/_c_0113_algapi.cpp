#include "_c_0113_algapi.h"
//解决多线程同步问题，默认为1
int _c_0113_AlgApi::Dispose(LargeVehicleApi *alg,int iduiBiLeiXing)
{

#if ALG_USED
    Chejiahao_ImgOutMsg cjhdata;
    alg->chejiaohao_api_process(_photoMain, _photoSub, cheJiaHao.inData,changShangPinPai.inData, cjhdata,iduiBiLeiXing);
    taYinMo.result = cjhdata.b_ori_chejiahao;
    tuoMo.result = cjhdata.b_tuomo;
   // shuiYinRiQi.OutData = cjhdata.date_stamp;
    cheJiaHao.result = cjhdata.b_chejiahao;
    zhaoPianQingXiDu.result = cjhdata.b_pic_quality;
    changShangPinPai.OutData = std::to_string(cjhdata.match_brand);

#endif

    UNUSED(alg);
    return 1;
}
