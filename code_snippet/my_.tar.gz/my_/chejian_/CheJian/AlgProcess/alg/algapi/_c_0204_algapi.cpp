#include "_c_0204_algapi.h"

int _c_0204_AlgApi::Dispose(LargeVehicleApi *alg)
{

#if ALG_USED
    Jianyanbaogao_ImgOutMsg jybgdata;
    alg->jianyanbaogao_api_process(_photoMain, chePaiHao.inData, cheJiaHao.inData, jianYanJieShuShiJian.inData, jybgdata);
    chePaiHao.result = jybgdata.b_chepai;
    cheLiangLeiXing.result = jybgdata.b_chepai_type;
    cheJiaHao.result = jybgdata.b_chejiahao;
    qianMing.result = jybgdata.b_qianming;
    yinZhang.result = jybgdata.b_hongzhang;
    jianYanJieLun.result = jybgdata.b_jianyanjielun;
    shuJuXiang.result = jybgdata.b_jianyan_info;
    yinZhang_CMA.result = jybgdata.b_MA;
    yinZhang_queRen.result = jybgdata.b_querenzhang;
    zhaoPianQingXiDu.result = jybgdata.b_pic_quality;
#endif
    UNUSED(alg);
    return 1;
}
