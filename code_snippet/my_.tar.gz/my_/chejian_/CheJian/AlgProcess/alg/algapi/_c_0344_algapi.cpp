#include "_c_0344_algapi.h"

int _c_0344_AlgApi::Dispose(LargeVehicleApi *alg)
{
#if ALG_USED
    Dipandongtai_ImgOutMsg out_msg;
    alg->dipandongtai_api_process(_photoMain, _photoSub, chePaiHao.inData, out_msg);
    chePaiHao.result = out_msg.b_chepai1;
    chePaiHao2.result = out_msg.b_chepai2;
 //   shuiYinRiQi.OutData = out_msg.date_stamp;
    cheWeiDong.result = out_msg.b_move;
    cheTou.result = out_msg.b_end_chetou;
    cheWei.result = out_msg.b_begin_chewei;
    biaoZhi.result = out_msg.b_biaozhi1;
#endif
    UNUSED(alg);
    return 1;
}
