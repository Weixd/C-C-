#ifndef _C_0216_ALGAPI_H
#define _C_0216_ALGAPI_H
#include "algbaseapi.h"

class _c_0216_AlgApi:public algBaseApi{
public:
    ALG_PARM_MEMBER shenFenZhengZhengMian = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER shenFenZhengFanMian = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER youXiaoRiQi = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER xingMing = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER xingBie = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER minZu = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER chuShengRiQi = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER zhuZhi = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER shenFenZhengHao = ALG_PARAM_DEFAULT;



    std::vector<memberItem> inMemberList = {

    };

    std::vector<memberItem> resultMemberList_fanMian = {
        {"shenFenZhengFanMian", "身份证(反面)不匹配", &shenFenZhengFanMian, true, CONFIG_DEFAULT},
        {"youXiaoRiQi", "身份证不在有效期", &youXiaoRiQi, true, CONFIG_DEFAULT},
    };

    std::vector<memberItem> resultMemberList_zhengMian = {
        {"shenFenZhengZhengMian", "身份证(正面)不匹配", &shenFenZhengZhengMian, true, CONFIG_DEFAULT},
        {"youXiaoRiQi", "身份证不在有效期", &youXiaoRiQi, true, CONFIG_DEFAULT},
    };

    int Dispose(LargeVehicleApi *alg);
};


#endif // _C_0216_ALGAPI_H
