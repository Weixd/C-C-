#ifndef _C_0287_ALGAPI_H
#define _C_0287_ALGAPI_H

#include "algbaseapi.h"

class _c_0287_AlgApi:public algBaseApi{
public:
    ALG_PARM_MEMBER chePaiHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER cheJiaHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER faZhengRiQi = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER dangAnHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER xingShiZhengXinBianHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER cheLiangLeiXing = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER heDingZaiKeShu = ALG_PARAM_DEFAULT;

    ALG_PARM_MEMBER zhuYeFanMian = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER yinZhangShu = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER xinChe = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER tuPianQingXiDu = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER qiangZhiBaoFeiQiZhi = ALG_PARAM_DEFAULT;


    std::vector<memberItem> inMemberList = {
        {"chePaiHao", "车牌号", &chePaiHao, true, CONFIG_DEFAULT},
        {"cheJiaHao", "车架号", &cheJiaHao, true, CONFIG_DEFAULT},
        {"faZhengRiQi", "发证日期", &faZhengRiQi, true, CONFIG_DEFAULT},
        {"dangAnHao", "档案号", &dangAnHao, true, CONFIG_DEFAULT},
        {"xingShiZhengXinBianHao", "行驶证(证芯)编号", &xingShiZhengXinBianHao, true, CONFIG_DEFAULT},
        {"cheLiangLeiXing", "车辆类型编码", &cheLiangLeiXing, true, CONFIG_NOCHECK},
        {"heDingZaiKeShu", "核定载客数", &heDingZaiKeShu, true, CONFIG_DEFAULT},
        {"qiangZhiBaoFeiQiZhi", "强制报废日期", &qiangZhiBaoFeiQiZhi, true, CONFIG_NOCHECK},
    };

    std::vector<memberItem> resultMemberList = {
        {"chePaiHao", "车牌号不正确", &chePaiHao, true, CONFIG_DEFAULT},
        {"cheJiaHao", "车架号不正确", &cheJiaHao, true, CONFIG_DEFAULT},
        {"xingShiZhengXinBianHao", "行驶证编号(条形码)不正确", &xingShiZhengXinBianHao, true, CONFIG_DEFAULT},
        {"faZhengRiQi", "行驶证发证日期不正确", &faZhengRiQi, true, CONFIG_NOCHECK},
        {"zhuYeFanMian", "未检测到行驶证主页反面车辆", &zhuYeFanMian, true, CONFIG_NOCHECK},
        {"cheLiangLeiXing", "车辆类型不正确", &cheLiangLeiXing, true, CONFIG_NOCHECK},
        {"heDingZaiKeShu", "载客人数不正确", &heDingZaiKeShu, true, CONFIG_NOCHECK},
        {"xinChe", "新车不判定行驶证", &xinChe, true, CONFIG_NOCHECK_UNABLE},
        {"tuPianQingXiDu", "图片信息不规范", &tuPianQingXiDu, true, CONFIG_DEFAULT_UNABLE},
        {"qiangZhiBaoFeiQiZhi", "强制报废日期不正确", &qiangZhiBaoFeiQiZhi, true, CONFIG_NOCHECK},
    };

    int Dispose(LargeVehicleApi *alg);
};

#endif // _C_0287_ALGAPI_H
