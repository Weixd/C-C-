#ifndef _C_0352_ALGAPI_H
#define _C_0352_ALGAPI_H
#include "algbaseapi.h"

class _c_0352_AlgApi:public algBaseApi{
public:
    ALG_PARM_MEMBER chePaiHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER youDeng1 = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER youDeng2 = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER shuiYinRiQi = ALG_PARAM_DEFAULT;

    std::vector<memberItem> inMemberList = {
        {"chePaiHao", "车牌号", &chePaiHao, true, CONFIG_DEFAULT},
        {"shuiYinRiQi", "水印日期", &shuiYinRiQi, true, CONFIG_DEFAULT},
    };
    std::vector<memberItem> resultMemberList = {

        {"youDeng1", "右车灯1", &youDeng1, true, CONFIG_DEFAULT},
        {"youDeng2", "右车灯2", &youDeng2, false, CONFIG_NOCHECK},
        {"shuiYinRiQi", "照片水印日期过期", &shuiYinRiQi, true, CONFIG_NOCHECK_UNABLE},
        {"chePaiHao", "车牌号不正确", &chePaiHao, true, CONFIG_DEFAULT},
    };


    int Dispose(LargeVehicleApi *alg);
};

#endif // _C_0352_ALGAPI_H
