#ifndef _C_0201_ALGAPI_H
#define _C_0201_ALGAPI_H
#include "algbaseapi.h"

class _c_0201_AlgApi:public algBaseApi{
public:
    ALG_PARM_MEMBER cheJiaHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER chePaiHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER xingShiZhengXinBianHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER faZhengRiQi = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER dangAnHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER heDingZaiKeShu = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER cheLiangLeiXing = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER shenFenZheng = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER zhuYeFanMianCheLiang = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER zhaoPianQingXiDu = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER qiangZhiBaoFeiQiZhi = ALG_PARAM_DEFAULT;

    std::vector<memberItem> inMemberList = {
        {"cheJiaHao", "车架号", &cheJiaHao, true, CONFIG_DEFAULT},
        {"chePaiHao", "车牌号", &chePaiHao, true, CONFIG_DEFAULT},
        {"xingShiZhengXinBianHao", "行驶证(证芯)编号", &xingShiZhengXinBianHao, true, CONFIG_DEFAULT},
        {"faZhengRiQi", "发证日期", &faZhengRiQi, true, CONFIG_DEFAULT},
        {"dangAnHao", "档案号", &dangAnHao, true, CONFIG_DEFAULT},
        {"heDingZaiKeShu", "核定载客数", &heDingZaiKeShu, true, CONFIG_DEFAULT},
        {"cheLiangLeiXing", "车辆类型编码", &cheLiangLeiXing, true, CONFIG_DEFAULT},
        {"qiangZhiBaoFeiQiZhi", "强制报废日期", &qiangZhiBaoFeiQiZhi, true, CONFIG_NOCHECK},
    };

    std::vector<memberItem> resultMemberList = {
        {"cheJiaHao", "车架号不正确", &cheJiaHao, true, CONFIG_DEFAULT},
        {"chePaiHao", "车牌号不正确", &chePaiHao, true, CONFIG_DEFAULT},
        {"xingShiZhengXinBianHao", "行驶证编号(条形码)不正确", &xingShiZhengXinBianHao, true, CONFIG_DEFAULT},
        {"faZhengRiQi", "行驶证发证日期不正确", &faZhengRiQi, true, CONFIG_DEFAULT},
        {"shenFenZheng", "未识别到身份证", &shenFenZheng, true, CONFIG_NOCHECK},
        {"zhuYeFanMianCheLiang", "未检测到行驶证主页反面车辆", &zhuYeFanMianCheLiang, true, CONFIG_NOCHECK},
        {"zhaoPianQingXiDu", "图片信息不规范", &zhaoPianQingXiDu, true, CONFIG_NOCHECK_UNABLE},
        {"qiangZhiBaoFeiQiZhi", "强制报废日期不正确", &qiangZhiBaoFeiQiZhi, true, CONFIG_NOCHECK},

    };

    int Dispose(LargeVehicleApi *alg);
};

#endif // _C_0201_ALGAPI_H
