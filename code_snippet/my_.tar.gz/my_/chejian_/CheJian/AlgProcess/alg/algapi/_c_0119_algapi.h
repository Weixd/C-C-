#ifndef _C_0119_ALGAPI_H
#define _C_0119_ALGAPI_H
#include "algbaseapi.h"

class _c_0119_AlgApi:public algBaseApi{
public:
    ALG_PARM_MEMBER faDongJiHao = ALG_PARAM_DEFAULT;

    std::vector<memberItem> inMemberList = {
        {"faDongJiHao", "发动机号", &faDongJiHao, true, CONFIG_DEFAULT},
    };

    std::vector<memberItem> resultMemberList = {
        {"faDongJiHao", "发动机号不正确", &faDongJiHao, true, CONFIG_DEFAULT},
    };

    int Dispose(LargeVehicleApi *alg);
};



#endif // _C_0119_ALGAPI_H
