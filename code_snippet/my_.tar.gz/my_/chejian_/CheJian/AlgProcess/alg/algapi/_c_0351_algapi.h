#ifndef _C_0351_ALGAPI_H
#define _C_0351_ALGAPI_H
#include "algbaseapi.h"

class _c_0351_AlgApi:public algBaseApi{
public:
    ALG_PARM_MEMBER chePaiHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER shuiYinRiQi = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER zhiDong = ALG_PARAM_DEFAULT;
//    ALG_PARM_MEMBER zhiDongDeng = ALG_PARAM_DEFAULT;
    std::vector<memberItem> inMemberList = {
        {"chePaiHao", "车牌号", &chePaiHao, true, CONFIG_DEFAULT},
        {"shuiYinRiQi", "水印日期", &shuiYinRiQi, true, CONFIG_DEFAULT},
    };

    std::vector<memberItem> resultMemberList = {
        {"chePaiHao", "车牌号不正确", &chePaiHao, true, CONFIG_DEFAULT},
        {"shuiYinRiQi", "照片水印日期过期", &shuiYinRiQi, true, CONFIG_NOCHECK_UNABLE},
        {"zhiDong", "车轮位置不对", &zhiDong, true, CONFIG_DEFAULT},
//        {"zhiDongDeng", "制动灯亮", &zhiDongDeng, true, CONFIG_NOCHECK},
    };

    int Dispose(LargeVehicleApi *alg);
};

#endif // _C_0351_ALGAPI_H
