#include "_c_0112_algapi.h"


int _c_0112_AlgApi::Dispose(LargeVehicleApi *alg)
{

#if ALG_USED
        Cheliang_ImgOutMsg yhfdata;
        std::vector<cv::Mat> empty;//fixme9.24
        alg->cheliang_api_process(_photoMain, _photoSub, empty, chePaiHao.inData, "", "",eBACKRIGHT,yhfdata);//fixme9.24
        chePaiHao.result = yhfdata.b_chepai;
        shuiYinRiQi.OutData = yhfdata.date_stamp;
        cheBiao.result = yhfdata.b_chebiao;
        sanJiaoJia.result = yhfdata.b_sanjiaojia;
        paiQiKongShuLiang.OutData = std::to_string(yhfdata.num_paiqikong);
#endif

    UNUSED(alg);
    return 1;
}
