#include "_c_0348_algapi.h"

int _c_0348_AlgApi::Dispose(LargeVehicleApi *alg)
{
#if ALG_USED
    Zhidong_ImgOutMsg zhidong_out_msg;
    int car_kind =1;
    alg->zhidong_api_process(_photoMain, chePaiHao.inData,
                             (bool)atoi(zhuChe.inData.c_str()), 2, car_kind, zhidong_out_msg);
    yiZhou.result = zhidong_out_msg.b_zhidong;
 //   shuiYinRiQi.result = zhidong_out_msg.b_shuiyin_riqi;
    chePaiHao.result = zhidong_out_msg.b_chepai;
    erZhou.result = zhidong_out_msg.b_zhidong;
 //   zhaopianChiCun.result = zhidong_out_msg.b_size_same;
    gunTong1.result = zhidong_out_msg.b_guntong;
  //  gunTong2.result = zhidong_out_msg.b_guntong_2;

#endif
    UNUSED(alg);
    return 1;
}
