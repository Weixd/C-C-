#ifndef ALGBASEAPI_H
#define ALGBASEAPI_H
#include "AlgProcess/base/baseinc.h"

#define MAX_EXT_PHOTO_NUM 4

class algBaseApi{
public:
    virtual ~algBaseApi(){}                   //用于释放内存（必须）
    int Process(LargeVehicleApi *alg);
    bool loadPhotoMain(std::string photoPath);  //加载主图片
    bool loadPhotoSub(std::string photoPath);   //加载子图片
    bool loadPhotoExt(std::string photoPath,unsigned int index);

protected:
    cv::Mat _photoMain;                          //主图片
    cv::Mat _photoSub;                           //子图片
    cv::Mat _photoExt[MAX_EXT_PHOTO_NUM];                           //扩展
    virtual int Dispose(LargeVehicleApi *alg){UNUSED(alg); return 1;}
};
#endif // ALGBASEAPI_H
