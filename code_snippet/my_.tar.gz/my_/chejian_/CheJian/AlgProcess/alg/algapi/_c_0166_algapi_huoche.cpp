#include "_c_0166_algapi_huoche.h"

int _c_0166_AlgApi_huoChe::Dispose(LargeVehicleApi *alg)
{
#if ALG_USED
    Huochexiang_ImgOutMsg out;
    alg->huochexiang_api_process(_photoMain, cheLiangLeiXing.inData, out);

    gaiZhuang_Kx2.result = out.b_ori_chexiang;
    gaiZhuang_Kx9.result = out.b_roof_modified;
    paiSheGuiFan.result = out.b_correct_pose ;
    cheDing.result = out.b_top_closed;
#endif
    UNUSED(alg);
    return 1;
}
