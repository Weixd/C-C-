#include "_c_0206_algapi.h"

int _c_0206_AlgApi::Dispose(LargeVehicleApi *alg)
{
#if ALG_USED
    Wanshuizhengming_ImgOutMsg out_msg;

    alg->wanshuizhengming_api_process(_photoMain, chePaiHao.inData, cheJiaHao.inData, jianYanJieShuShiJian.inData, out_msg);


     chePaiHao.result = out_msg.b_chepai;
     cheJiaHao.result = out_msg.b_chejiahao;
     jianYanJieShuShiJian.result = out_msg.b_valid_data;
     cheChuanShui.result = out_msg.b_chechuanshui;
     shuiKuanSuoShuRiQi.result = out_msg.b_zhengnian;
     wanShuiZhengMing.result = out_msg.b_wanshuizhengming;

#endif
    UNUSED(alg);
    return 1;
}
