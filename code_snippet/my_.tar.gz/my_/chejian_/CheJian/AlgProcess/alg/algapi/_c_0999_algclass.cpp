#include "_c_0167_algclass.h"

ALGFUNC_RETURN _c_0167_AlgClass::seekMemberListPointer()
{
    pAlgApi = new _c_0167_AlgApi();
    pInMemberList = &pAlgApi->inMemberList;
    pResultMemberList = &pAlgApi->resultMemberList;

    return true;
}


ALGFUNC_RETURN _c_0167_AlgClass::Dispose(ALGFUNC_TP)
{
    pAlgApi->shuiYinRiQi.inData = baseTool::formatingDate(pAlgApi->shuiYinRiQi.inData);
    pAlgApi->loadPhotoMain((*pPhotoList)[index].localPath);
    pAlgApi->Dispose(alg);
   ALG_P_UNUSED return true;
}

