#ifndef _C_0205_ALGAPI_H
#define _C_0205_ALGAPI_H
#include "algbaseapi.h"

class _c_0205_AlgApi:public algBaseApi{
public:
    ALG_PARM_MEMBER chePaiHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER cheJiaHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER dangTianRiQi = ALG_PARAM_DEFAULT;

    ALG_PARM_MEMBER jianYanBiao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER qianZi_waiGuanJianYanYuan = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER jianYanJieLun = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER qianZi_chaYanYuan = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER qianZi_yinCheJianYanYuan = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER qianZi_diPanJianYanYuan = ALG_PARAM_DEFAULT;


    ALG_PARM_MEMBER jianYanXinXi = ALG_PARAM_DEFAULT;
    std::vector<int> jianYanXiang;


    std::vector<memberItem> inMemberList = {
        {"chePaiHao", "车牌号", &chePaiHao, true, CONFIG_DEFAULT},
        {"cheJiaHao", "车架号", &cheJiaHao, true, CONFIG_DEFAULT},
        {"dangTianRiQi", "当天日期", &dangTianRiQi, true, CONFIG_DEFAULT},
    };

    std::vector<memberItem> resultMemberList = {
        {"chePaiHao", "车牌号不正确", &chePaiHao, true, CONFIG_DEFAULT},
        {"jianYanBiao", "检验表不符合标准", &jianYanBiao, true, CONFIG_NOCHECK},
        {"jianYanXinXi", "查验信息不正确", &jianYanXinXi, true, CONFIG_NOCHECK},
        {"qianZi_waiGuanJianYanYuan", "外观检验员未签字", &qianZi_waiGuanJianYanYuan, true, CONFIG_NOCHECK},
        {"jianYanJieLun", "没有查验结论", &jianYanJieLun, true, CONFIG_NOCHECK},
        {"qianZi_chaYanYuan", "查验员未签字", &qianZi_chaYanYuan, true, CONFIG_NOCHECK},
        {"qianZi_yinCheJianYanYuan", "引车检验员未签字", &qianZi_yinCheJianYanYuan, false, CONFIG_NOCHECK},
        {"qianZi_diPanJianYanYuan", "底盘检验员未签字", &qianZi_diPanJianYanYuan, false, CONFIG_NOCHECK},

    };

    int Dispose(LargeVehicleApi *alg);
};
#endif // _C_0205_ALGAPI_H
