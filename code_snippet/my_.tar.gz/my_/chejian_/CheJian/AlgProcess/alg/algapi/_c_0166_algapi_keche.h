#ifndef _C_0166_ALGAPI_KECHE_H
#define _C_0166_ALGAPI_KECHE_H
#include "algbaseapi.h"

class _c_0166_AlgApi_keChe:public algBaseApi{
public:
    ALG_PARM_MEMBER gaiZhuang = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER cheLiangLeiXing = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER heDingZaiKeShu = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER paiSheGuiFan = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER zuoWeiShu = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER anQuanDai = ALG_PARAM_DEFAULT;

    std::vector<memberItem> inMemberList = {
        {"cheLiangLeiXing", "车辆类型", &cheLiangLeiXing, true, CONFIG_DEFAULT},
        {"heDingZaiKeShu", "核定载客人数", &heDingZaiKeShu, true, CONFIG_DEFAULT},
    };

    std::vector<memberItem> resultMemberList = {
        {"paiSheGuiFan", "不符合拍摄规范", &paiSheGuiFan, true, CONFIG_NOCHECK},
        {"gaiZhuang", "车辆有改装", &gaiZhuang, false, CONFIG_DEFAULT},
        {"zuoWeiShu", "座位数不对", &zuoWeiShu, false, CONFIG_NOCHECK},
        {"anQuanDai", "没有安全带", &anQuanDai, false, CONFIG_NOCHECK},
    };

    int Dispose(LargeVehicleApi *alg);
};



#endif // _C_0166_ALGAPI_KECHE_H
