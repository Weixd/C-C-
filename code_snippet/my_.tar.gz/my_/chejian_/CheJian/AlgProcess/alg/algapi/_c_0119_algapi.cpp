#include "_c_0119_algapi.h"

int _c_0119_AlgApi::Dispose(LargeVehicleApi *alg)
{
#if ALG_USED

#endif
    UNUSED(alg);
    return 1;
}
