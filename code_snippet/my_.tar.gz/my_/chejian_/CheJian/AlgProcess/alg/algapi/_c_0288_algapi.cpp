#include "_c_0288_algapi.h"

int _c_0288_AlgApi::Dispose(LargeVehicleApi *alg)
{
#if ALG_USED

    Xingshizheng_ImgOutMsg xszdata;
    alg->xingshizheng_api_process(_photoMain, chePaiHao.inData, cheJiaHao.inData,
                                  faZhengRiQi.inData, dangAnHao.inData, xingShiZhengXinBianHao.inData,
                                  cheLiangLeiXing.inData, heDingZaiKeShu.inData, qiangZhiBaoFeiQiZhi.inData,"",
                                  xszdata);

    zhuYeFanMianCheLiang.result = xszdata.b_cheliang;
    fuYeFanMian.result = xszdata.b_fuyefanmian;
    faZhengRiQi.result = xszdata.b_fazhengriqi;//fixme9.24
    yinZhangShu.OutData = std::to_string(xszdata.fuyezhang_cnt);

#endif
    UNUSED(alg);
    return 1;
}
