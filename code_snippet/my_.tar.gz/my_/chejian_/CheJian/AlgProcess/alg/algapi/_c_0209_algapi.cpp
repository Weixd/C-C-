#include "_c_0209_algapi.h"


int _c_0209_AlgApi::Dispose(LargeVehicleApi *alg)
{
#if ALG_USED
    Huanbaodan_ImgOutMsg out_msg;

    alg->huanbaodan_api_process(_photoMain, _photoMain, chePaiHao.inData, cheJiaHao.inData, weiQiJianCeShiJian.inData, shiJianVector, dangTianRiQi.inData, faDongJiXingHao.inData, cheLiangLeiXing.inData, out_msg);

    huanBaoJianYanJieLun.result = out_msg.b_jiancejielun;
    chePaiHao.result = out_msg.b_chepai;
    cheJiaHao.result = out_msg.b_chejiahao;
    yinZhang.result = out_msg.b_yinzhang;
    qianMing.result = out_msg.b_qianzi;
    yinZhang_CMA.result = out_msg.b_MA;
    weiQiJianCeShiJian.result = out_msg.b_valid_date;
    faDongJiXingHao.result = out_msg.b_engine_num;
    jianCeShiJian.result = out_msg.b_riqi_shijian;
    qianMing_caoZuoYuan.result = out_msg.b_qianzi_caozuoyuan;
    qianMing_jiaShiYuan.result = out_msg.b_qianzi_jiashiyuan;
    qianMing_piZhunRen.result = out_msg.b_qianzi_pizhunren;
    qianMing_shenHeRen.result = out_msg.b_qianzi_shenheyuan;
    qianMing_shouQuanRen.result = out_msg.b_qianzi_shouquan;
    dianZiBiaoGe.result = out_msg.b_dianzibiaoge;
    huanBaoDan.result = out_msg.b_huanbaodan;
    cheLiangLeiXing.result = out_msg.b_cheliangxinghao;

#endif
    UNUSED(alg);
    return 1;
}
