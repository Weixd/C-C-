#ifndef _C_0112_ALGAPI_DACHE_H
#define _C_0112_ALGAPI_DACHE_H
#include "algbaseapi.h"

class _c_0112_AlgApi_daChe:public algBaseApi{
public:
    ALG_PARM_MEMBER chePaiHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER cheWaiKuoGao = ALG_PARAM_DEFAULT;

    ALG_PARM_MEMBER cheBiao;
    ALG_PARM_MEMBER houCheShenFanGuangBiaoShi = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER youCeCheShenFanGuangBiaoShi = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER houXiaBuFangHuZhuangZhi = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER youCeFangHuZhuangZhi = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER penTuFangDaChePai = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER cheLiangWeiBuBiaoZhi = ALG_PARAM_DEFAULT;

    std::vector<memberItem> inMemberList = {
        {"chePaiHao", "车牌号", &chePaiHao, true, CONFIG_DEFAULT},
        {"cheWaiKuoGao", "车外廓高", &cheWaiKuoGao, true, CONFIG_DEFAULT},
    };

    std::vector<memberItem> resultMemberList = {
        {"chePaiHao", "车牌号不正确", &chePaiHao, true, CONFIG_DEFAULT},
        {"cheBiao", "车标不正确", &cheBiao, true, CONFIG_DEFAULT},
        {"houCheShenFanGuangBiaoShi", "后部车身反光标识错误", &houCheShenFanGuangBiaoShi, true, CONFIG_NOCHECK},
        {"youCeCheShenFanGuangBiaoShi", "右侧面车身反光标识错误", &youCeCheShenFanGuangBiaoShi, true, CONFIG_NOCHECK},
        {"houXiaBuFangHuZhuangZhi", "后下部防护装置错误", &houXiaBuFangHuZhuangZhi, true, CONFIG_NOCHECK},
        {"youCeFangHuZhuangZhi", "右侧面防护装置错误", &youCeFangHuZhuangZhi, true, CONFIG_NOCHECK},
        {"penTuFangDaChePai", "车厢后部喷涂或粘贴的放大的号牌号码错误", &penTuFangDaChePai, true, CONFIG_NOCHECK},
        {"cheLiangWeiBuBiaoZhi", "车辆尾部标志板错误", &cheLiangWeiBuBiaoZhi, true, CONFIG_NOCHECK},
    };

    int Dispose(LargeVehicleApi *alg);
};
#endif // _C_0112_ALGAPI_DACHE_H
