#include "_c_0216_algapi.h"

int _c_0216_AlgApi::Dispose(LargeVehicleApi *alg)
{
#if ALG_USED
    Shenfenzheng_ImgOutMsg out_msg;
    alg->shenfenzheng_api_process(_photoMain,out_msg,xingMing.inData);

    shenFenZhengZhengMian.result = out_msg.b_front;
    shenFenZhengFanMian.result = out_msg.b_back;
    youXiaoRiQi.result = out_msg.b_valid;
    xingMing.result = out_msg.b_xingming;
    xingMing.OutData =out_msg.s_xingming;
    xingBie.OutData =out_msg.s_xingbie;
    minZu.OutData = out_msg.s_mingzu;
    chuShengRiQi.OutData = out_msg.s_chusheng;
    zhuZhi.OutData = out_msg.s_zhuzhi;
    shenFenZhengHao.OutData = out_msg.s_IDhaoma;

#endif
    UNUSED(alg);
    return 1;
}
