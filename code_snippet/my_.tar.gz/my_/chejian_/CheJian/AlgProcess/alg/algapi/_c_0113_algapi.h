#ifndef _C_0113_ALGAPI_H
#define _C_0113_ALGAPI_H
#include "algbaseapi.h"

class _c_0113_AlgApi:public algBaseApi{
public:
    ALG_PARM_MEMBER zhaoPianQingXiDu = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER shuiYinRiQi = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER cheJiaHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER jiLvBiaoCheJiaHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER taYinMo = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER tuoMo = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER dangAnZhaoPian = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER zhiZaoChangMingCheng = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER cheLiangPinPai = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER changShangPinPai = ALG_PARAM_DEFAULT;
//    int duiBiLeiXing = 1;


    std::vector<memberItem> inMemberList = {
        {"cheJiaHao", "车架号", &cheJiaHao, true, CONFIG_DEFAULT},
        {"shuiYinRiQi", "水印日期", &shuiYinRiQi, true, CONFIG_DEFAULT},
        {"zhiZaoChangMingCheng", "制造厂名称", &zhiZaoChangMingCheng, true, CONFIG_DEFAULT},
        {"cheLiangPinPai", "车辆品牌", &cheLiangPinPai, true, CONFIG_DEFAULT},
    };

    std::vector<memberItem> resultMemberList = {
        {"zhaoPianQingXiDu", "图片信息不规范", &zhaoPianQingXiDu, true, CONFIG_DEFAULT_UNABLE},
        {"cheJiaHao", "车架号不正确", &cheJiaHao, true, CONFIG_DEFAULT},
        {"shuiYinRiQi", "水印日期过期", &shuiYinRiQi, true, CONFIG_NOCHECK_UNABLE},
        {"taYinMo", "车架号字型与拓印膜不符", &taYinMo, false, CONFIG_NOCHECK},
        {"tuoMo", "车架号拓印膜不正确", &tuoMo, false, CONFIG_NOCHECK},
        {"dangAnZhaoPian", "缺少拓印膜照片，无法判定车架号是否更改", &dangAnZhaoPian, true, CONFIG_NOCHECK_UNABLE},
        {"changShangPinPai", "厂商车架号篡改检测", &changShangPinPai, true, CONFIG_NOCHECK_UNABLE},
    };

    int Dispose(LargeVehicleApi *alg,int iduiBiLeiXing=1);
};
#endif // _C_0113_ALGAPI_H
