#include "_c_0201_algapi.h"
#include "AlgProcess/alg/algapi/algbaseapi.h"
#include "AlgProcess/base/processbaseclass.h"

int _c_0201_AlgApi::Dispose(LargeVehicleApi *alg)
{
#if ALG_USED
    Xingshizheng_ImgOutMsg xszdata;
    alg->xingshizheng_api_process(_photoMain, chePaiHao.inData, cheJiaHao.inData,
                                  faZhengRiQi.inData, dangAnHao.inData,
                                  xingShiZhengXinBianHao.inData, baseTool::getCllxNameByCllx(cheLiangLeiXing.inData),
                                  heDingZaiKeShu.inData, qiangZhiBaoFeiQiZhi.inData,"",
                                  xszdata);

    chePaiHao.result = xszdata.b_chepai;
    cheJiaHao.result = xszdata.b_chejiahao;
    xingShiZhengXinBianHao.result = xszdata.b_tiaoxingma;
    faZhengRiQi.result = xszdata.b_fazhengriqi;
    shenFenZheng.result = xszdata.b_fuyefanmian;//fixme9.24
    zhuYeFanMianCheLiang.result = xszdata.b_cheliang;
    zhaoPianQingXiDu.result = xszdata.b_pic_quality;
    zhaoPianQingXiDu.result = xszdata.b_qiangzhibaofie;
#endif
    UNUSED(alg);
    return 1;
}
