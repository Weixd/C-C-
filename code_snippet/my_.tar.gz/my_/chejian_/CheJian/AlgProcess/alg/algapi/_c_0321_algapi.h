#ifndef _C_0321_ALGAPI_H
#define _C_0321_ALGAPI_H
#include "algbaseapi.h"

class _c_0321_AlgApi:public algBaseApi{
public:
    ALG_PARM_MEMBER chePaiHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER zuoDeng1 = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER zuoDeng2 = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER shuiYinRiQi = ALG_PARAM_DEFAULT;

    std::vector<memberItem> inMemberList = {
        {"chePaiHao", "车牌号", &chePaiHao, true, CONFIG_DEFAULT},
        {"shuiYinRiQi", "水印日期", &shuiYinRiQi, true, CONFIG_DEFAULT},
    };

    std::vector<memberItem> resultMemberList = {
        {"zuoDeng1", "左车灯1", &zuoDeng1, true, CONFIG_DEFAULT},
        {"zuoDeng2", "左车灯2", &zuoDeng2, false, CONFIG_NOCHECK},
        {"shuiYinRiQi", "照片水印日期过期", &shuiYinRiQi, true, CONFIG_NOCHECK},
        {"chePaiHao", "车牌号不正确", &chePaiHao, true, CONFIG_DEFAULT},
    };

    int Dispose(LargeVehicleApi *alg);
};

#endif // _C_0321_ALGAPI_H
