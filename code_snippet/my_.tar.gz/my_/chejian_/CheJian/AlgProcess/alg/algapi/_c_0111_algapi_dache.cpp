#include "_c_0111_algapi_dache.h"

int _c_0111_AlgApi_daChe::Dispose(LargeVehicleApi *alg)
{
#if ALG_USED
    Huoche_ImgOutMsg yhfout;
    printf("d_chePaiHao:%s\n",chePaiHao.inData.c_str());
    alg->huoche_api_process(_photoMain, chePaiHao.inData, eFRONTLEFT, yhfout);
    chePaiHao.result = yhfout.b_chepai;
    cheBiao.result = yhfout.b_chebiao;
    zuoCeCheShenFanGuangBiaoShi.result = yhfout.b_left_reflect;
    zuoCeFangHuZhuangZhi.result = yhfout.b_left_protect;
    zuoCeJiaShiShiPenTuZongZhiLiang.result = yhfout.b_quality;
#endif

    UNUSED(alg);
    return 1;
}
