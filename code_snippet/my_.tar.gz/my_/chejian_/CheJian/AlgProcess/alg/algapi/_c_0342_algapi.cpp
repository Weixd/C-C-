#include "_c_0342_algapi.h"

int _c_0342_AlgApi::Dispose(LargeVehicleApi *alg)
{
#if ALG_USED
    Dipandongtai_ImgOutMsg out_msg;
    alg->dipandongtai_api_process(_photoMain, _photoSub, chePaiHao.inData,out_msg);
    chePaiHao.result = out_msg.b_chepai2;
    chePaiHao2.result = out_msg.b_chepai1;
 //   shuiYinRiQi.OutData = out_msg.date_stamp;
    cheWeiDong.result = out_msg.b_move;
    cheTou.result = out_msg.b_end_chetou;
#endif
    UNUSED(alg);
    return 1;
}
