#include "_c_0112_algapi_dache.h"

int _c_0112_AlgApi_daChe::Dispose(LargeVehicleApi *alg)
{

#if ALG_USED
    Huoche_ImgOutMsg yhfout;
    // fix me 最后一个参数传入栏板高度，目前传入的不是，只是为了保证代码的完整性
    alg->huoche_api_process(_photoMain, chePaiHao.inData, eBACKRIGHT, yhfout, std::atoi(cheWaiKuoGao.inData.c_str()));
    chePaiHao.result = yhfout.b_chepai;
    cheBiao.result = yhfout.b_chebiao;

    houCheShenFanGuangBiaoShi.result = yhfout.b_rear_reflect;
    youCeCheShenFanGuangBiaoShi.result = yhfout.b_right_reflect;
    houXiaBuFangHuZhuangZhi.result = yhfout.b_rear_protect;
    youCeFangHuZhuangZhi.result = yhfout.b_right_protect;
    penTuFangDaChePai.result = yhfout.b_pentu_chepai;
    cheLiangWeiBuBiaoZhi.result = yhfout.b_rear_plate;
#endif

    UNUSED(alg);
    return 1;
}


