#ifndef _C_0166_ALGAPI_HUOCHE_H
#define _C_0166_ALGAPI_HUOCHE_H
#include "algbaseapi.h"

class _c_0166_AlgApi_huoChe:public algBaseApi{
public:
    ALG_PARM_MEMBER gaiZhuang_Kx2 = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER gaiZhuang_Kx9 = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER cheLiangLeiXing = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER paiSheGuiFan = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER cheDing = ALG_PARAM_DEFAULT;


    std::vector<memberItem> inMemberList = {
        {"cheLiangLeiXing", "车辆类型", &cheLiangLeiXing, true, CONFIG_DEFAULT},
    };

    std::vector<memberItem> resultMemberList = {
        {"paiSheGuiFan", "摄角度不合要求", &paiSheGuiFan, true, CONFIG_NOCHECK},
        {"gaiZhuang_Kx2", "车厢内部有改装", &gaiZhuang_Kx2, false, CONFIG_DEFAULT},
        {"gaiZhuang_Kx9", "车厢内部有改装", &gaiZhuang_Kx9, false, CONFIG_NOCHECK},
        {"cheDing", "车顶没有封闭", &cheDing, true, CONFIG_NOCHECK},
    };

    int Dispose(LargeVehicleApi *alg);
};

#endif // _C_0166_ALGAPI_HUOCHE_H
