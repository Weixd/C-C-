#ifndef _C_0175_ALGAPI_H
#define _C_0175_ALGAPI_H

#include "algbaseapi.h"

class _c_0175_AlgApi:public algBaseApi{
public:
    ALG_PARM_MEMBER guangGao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER cheLiangYanSe = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER dangAnZhaoPian = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER chePaiHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER shuiYinRiQi = ALG_PARAM_DEFAULT;

    std::vector<memberItem> inMemberList = {
        {"chePaiHao", "车牌号", &chePaiHao, true, CONFIG_DEFAULT},
        {"shuiYinRiQi", "照片水印日期", &shuiYinRiQi, true, CONFIG_DEFAULT},
    };

    std::vector<memberItem> resultMemberList = {
        {"guangGao", "车辆有广告", &guangGao, true, CONFIG_DEFAULT},
        {"cheLiangYanSe", "车辆颜色有变化", &cheLiangYanSe, false, CONFIG_DEFAULT},
        {"dangAnZhaoPian", "缺少档案照片，无法判定是否改装", &dangAnZhaoPian, true, CONFIG_NOCHECK_UNABLE},
    };


    int Dispose(LargeVehicleApi *alg);
};

#endif // _C_0175_ALGAPI_H
