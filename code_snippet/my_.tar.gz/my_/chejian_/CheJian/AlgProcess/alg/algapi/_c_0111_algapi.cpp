#include "_c_0111_algapi.h"


int _c_0111_AlgApi::Dispose(LargeVehicleApi *alg)
{
#if ALG_USED
    Cheliang_ImgOutMsg zqfdata;
    std::vector<cv::Mat> empty;//fixme9.24
    alg->cheliang_api_process(_photoMain, _photoSub,empty,chePaiHao.inData,"",cheLiangYanSe.inData ,eFRONTLEFT, zqfdata);//fixme9.24
    chePaiHao.result = zqfdata.b_chepai;
    cheBiao.result = zqfdata.b_chebiao;
    shuiYinRiQi.OutData = zqfdata.date_stamp;
    sanJiaoJia.result = zqfdata.b_sanjiaojia;
    cheLiangYanSe.result = zqfdata.b_ori_color;
    xingLiJia.result = zqfdata.b_xinglijia;
    jiaoTaBan.result = zqfdata.b_jiaotaban;

#endif

    UNUSED(alg);
    return 1;
}
