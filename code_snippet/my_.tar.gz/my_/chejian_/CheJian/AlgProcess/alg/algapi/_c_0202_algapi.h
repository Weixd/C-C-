#ifndef _C_0202_ALGAPI_H
#define _C_0202_ALGAPI_H
#include "algbaseapi.h"

class _c_0202_AlgApi:public algBaseApi{
public:
    ALG_PARM_MEMBER chePaiHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER cheJiaHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER suoYouRenShouJiHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER qianMing = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER xingMing = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER diZhi = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER haoPaiZhongLei = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER jianYanHeGeBiaoZhi = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER daiLiRenShouJiHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER zhaoPianQingXiDu = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER riQi = ALG_PARAM_DEFAULT;


    std::vector<memberItem> inMemberList = {
        {"chePaiHao", "车牌号", &chePaiHao, true, CONFIG_DEFAULT},
        {"cheJiaHao", "车架号", &cheJiaHao, true, CONFIG_DEFAULT},
        {"haoPaiZhongLei", "号牌种类", &haoPaiZhongLei, true, CONFIG_DEFAULT},
    };

    std::vector<memberItem> resultMemberList = {
        {"chePaiHao", "车牌号不正确", &chePaiHao, true, CONFIG_DEFAULT},
        {"suoYouRenShouJiHao", "无所有人手机号码", &suoYouRenShouJiHao, true, CONFIG_NOCHECK},
        {"qianMing", "没有签名", &qianMing, true, CONFIG_DEFAULT},
        {"xingMing", "姓名不正确", &xingMing, true, CONFIG_NOCHECK},
        {"diZhi", "联系地址未填写", &diZhi, true, CONFIG_NOCHECK},
        {"riQi", "没有日期", &riQi, true, CONFIG_NOCHECK},
        {"haoPaiZhongLei", "号牌种类不正确", &haoPaiZhongLei, true, CONFIG_NOCHECK},
        {"jianYanHeGeBiaoZhi", "检验合格标志未勾选", &jianYanHeGeBiaoZhi, true, CONFIG_NOCHECK},
        {"daiLiRenShouJiHao", "代理人手机号码不合法", &daiLiRenShouJiHao, true, CONFIG_NOCHECK},
        {"zhaoPianQingXiDu", "图片信息不规范", &zhaoPianQingXiDu, true, CONFIG_NOCHECK_UNABLE},

    };

    int Dispose(LargeVehicleApi *alg);
};

#endif // _C_0202_ALGAPI_H
