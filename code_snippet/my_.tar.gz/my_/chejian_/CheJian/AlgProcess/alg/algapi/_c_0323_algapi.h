#ifndef _C_0323_ALGAPI_H
#define _C_0323_ALGAPI_H
#include "algbaseapi.h"

class _c_0323_AlgApi:public algBaseApi{
public:
    ALG_PARM_MEMBER chePaiHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER shuiYinRiQi = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER diPan = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER jianYanYuan = ALG_PARAM_DEFAULT;

    std::vector<memberItem> inMemberList = {
        {"chePaiHao", "车牌号", &chePaiHao, true, CONFIG_DEFAULT},
        {"shuiYinRiQi", "水印日期", &shuiYinRiQi, true, CONFIG_DEFAULT},
    };

    std::vector<memberItem> resultMemberList = {
        {"diPan", "底盘不在工位", &diPan, true, CONFIG_NOCHECK},
        {"chePaiHao", "车牌号不正确", &chePaiHao, true, CONFIG_DEFAULT},
        {"shuiYinRiQi", "照片水印日期过期", &shuiYinRiQi, true, CONFIG_NOCHECK},
        {"jianYanYuan", "没有检验员", &jianYanYuan, true, CONFIG_DEFAULT},

    };


    int Dispose(LargeVehicleApi *alg);
};

#endif // _C_0323_ALGAPI_H
