#include "algbaseapi.h"
#include "AlgProcess/base/basetool.h"

int algBaseApi::Process(LargeVehicleApi *alg)
{
    return Dispose(alg);
}

bool algBaseApi::loadPhotoMain(std::string photoPath)
{
    _photoMain =  cv::imread(photoPath);
    return true;
}

bool algBaseApi::loadPhotoSub(std::string photoPath)
{
    _photoSub =  cv::imread(photoPath);
    return true;
}

bool algBaseApi::loadPhotoExt(std::string photoPath,unsigned int index)
{
    if(index < MAX_EXT_PHOTO_NUM)
    {
        _photoExt[index] =  cv::imread(photoPath);
        return true;
    }
    return false;
}

