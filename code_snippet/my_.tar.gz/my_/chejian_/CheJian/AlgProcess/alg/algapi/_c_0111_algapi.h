#ifndef _C_0111_ALGAPI_H
#define _C_0111_ALGAPI_H
#include "algbaseapi.h"

class _c_0111_AlgApi:public algBaseApi{
public:
    ALG_PARM_MEMBER chePaiHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER shuiYinRiQi = ALG_PARAM_DEFAULT;

    ALG_PARM_MEMBER cheBiao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER sanJiaoJia = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER cheLiangYanSe = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER dangAnZhaoPian = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER xingLiJia = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER jiaoTaBan = ALG_PARAM_DEFAULT;


    std::vector<memberItem> inMemberList = {
        {"chePaiHao", "车牌号", &chePaiHao, true, CONFIG_DEFAULT},
        {"shuiYinRiQi", "照片水印日期", &shuiYinRiQi, true, CONFIG_DEFAULT},

    };

    std::vector<memberItem> resultMemberList = {
        {"chePaiHao", "车牌号不正确", &chePaiHao, true, CONFIG_DEFAULT},
        {"shuiYinRiQi", "照片水印日期过期", &shuiYinRiQi, true, CONFIG_NOCHECK_UNABLE},
        {"cheBiao", "车标不正确", &cheBiao, true, CONFIG_DEFAULT},
        {"sanJiaoJia", "没有三角架", &sanJiaoJia, true, CONFIG_NOCHECK},
        {"cheLiangYanSe", "车辆颜色有变化", &cheLiangYanSe, false, CONFIG_NOCHECK},
        {"xingLiJia", "行李架有变化", &xingLiJia, false, CONFIG_NOCHECK},
        {"jiaoTaBan", "迎宾牌有变化", &jiaoTaBan, false, CONFIG_NOCHECK},

        {"dangAnZhaoPian", "缺少档案照片,无法判定是否改装", &dangAnZhaoPian, true, CONFIG_NOCHECK_UNABLE},
    };

    int Dispose(LargeVehicleApi *alg);
};

#endif // _C_0111_ALGAPI_H
