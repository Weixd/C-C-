#ifndef _C_0111_ALGAPI_DACHE_H
#define _C_0111_ALGAPI_DACHE_H
#include "algbaseapi.h"

class _c_0111_AlgApi_daChe:public algBaseApi{
public:
    ALG_PARM_MEMBER chePaiHao = ALG_PARAM_DEFAULT;

    ALG_PARM_MEMBER cheBiao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER zuoCeCheShenFanGuangBiaoShi = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER zuoCeFangHuZhuangZhi = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER zuoCeJiaShiShiPenTuZongZhiLiang = ALG_PARAM_DEFAULT;

    std::vector<memberItem> inMemberList = {
        {"chePaiHao", "车牌号", &chePaiHao, true, CONFIG_DEFAULT},
    };

    std::vector<memberItem> resultMemberList = {
        {"chePaiHao", "车牌号不正确", &chePaiHao, true, CONFIG_DEFAULT},
        {"cheBiao", "车标不正确", &cheBiao, true, CONFIG_DEFAULT},
        {"zuoCeJiaShiShiPenTuZongZhiLiang", "驾驶室左侧喷涂的总质量错误", &zuoCeJiaShiShiPenTuZongZhiLiang, true, CONFIG_NOCHECK},
        {"zuoCeCheShenFanGuangBiaoShi", "左侧车身反光标识错误", &zuoCeCheShenFanGuangBiaoShi, true, CONFIG_NOCHECK},
        {"zuoCeFangHuZhuangZhi", "左侧防护装置错误", &zuoCeFangHuZhuangZhi, true, CONFIG_NOCHECK},
    };

    int Dispose(LargeVehicleApi *alg);
};

#endif // _C_0111_ALGAPI_DACHE_H
