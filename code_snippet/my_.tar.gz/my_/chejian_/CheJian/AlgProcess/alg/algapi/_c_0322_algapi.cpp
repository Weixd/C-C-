#include "_c_0322_algapi.h"

int _c_0322_AlgApi::Dispose(LargeVehicleApi *alg)
{
#if ALG_USED
    Zhidong_ImgOutMsg zhidong_out_msg;
    alg->zhidong_api_process(_photoMain, chePaiHao.inData,
                             (bool)atoi(zhuChe.inData.c_str()), 1, CarKind, zhidong_out_msg);
    yiZhou.result = zhidong_out_msg.b_zhidong;
  //  erZhou.result = zhidong_out_msg.b_erzhou;
   // shuiYinRiQi.result = zhidong_out_msg.b_shuiyin_riqi;
    chePaiHao.result = zhidong_out_msg.b_chepai;
  //  zhaopianChiCun.result = zhidong_out_msg.b_size_same;
    gunTong1.result = zhidong_out_msg.b_guntong;
   // gunTong2.result = zhidong_out_msg.b_guntong_2;

#endif

    UNUSED(alg);
    return 1;
}
