#ifndef _C_0297_ALGAPI_H
#define _C_0297_ALGAPI_H
#include "algbaseapi.h"

class _c_0297_AlgApi:public algBaseApi{
public:
    ALG_PARM_MEMBER chePaiHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER cheJiaHao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER dangTianRiQi = ALG_PARAM_DEFAULT;

    ALG_PARM_MEMBER jianYanBiao = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER qianMing_waiGuanJianYanYuan = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER qianMing_yinCheJianYanYuan = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER qianMing_diPanJianYanYuan = ALG_PARAM_DEFAULT;
    ALG_PARM_MEMBER jianYanJieGuoDiWuXiang = ALG_PARAM_DEFAULT;



    std::vector<memberItem> inMemberList = {
        {"chePaiHao", "车牌号", &chePaiHao, true, CONFIG_DEFAULT},
        {"cheJiaHao", "车架号", &cheJiaHao, true, CONFIG_DEFAULT},
        {"dangTianRiQi", "当前日期", &dangTianRiQi, true, CONFIG_DEFAULT},

    };

    std::vector<memberItem> resultMemberList = {
        {"jianYanBiao", "检验表不符合标准", &jianYanBiao, true, CONFIG_NOCHECK},
        {"chePaiHao", "车牌号不正确", &chePaiHao, true, CONFIG_DEFAULT},
        {"qianMing_waiGuanJianYanYuan", "外观检验员未签字", &qianMing_waiGuanJianYanYuan, true, CONFIG_DEFAULT},
        {"qianMing_yinCheJianYanYuan", "引车检验员未签字", &qianMing_yinCheJianYanYuan, true, CONFIG_DEFAULT},
        {"qianMing_diPanJianYanYuan", "底盘检验员未签字", &qianMing_diPanJianYanYuan, true, CONFIG_DEFAULT},
        {"dangTianRiQi", "检验日期不是当天", &dangTianRiQi, true, CONFIG_NOCHECK},
        {"jianYanJieGuoDiWuXiang", "检验结果第5项不是“合格”", &jianYanJieGuoDiWuXiang, true, CONFIG_NOCHECK},
    };

    int Dispose(LargeVehicleApi *alg);
};

#endif // _C_0297_ALGAPI_H
