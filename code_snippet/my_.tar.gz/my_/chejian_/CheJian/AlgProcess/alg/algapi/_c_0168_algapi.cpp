#include "_c_0168_algapi.h"

int _c_0168_AlgApi::Dispose(LargeVehicleApi *alg)
{

#if ALG_USED
    Cheliang_ImgOutMsg  cmdata;
    std::vector<cv::Mat> empty;  //fixme9.24
    alg->cheliang_api_process(_photoMain, _photoMain, empty,"", chePaiHao.inData,"",eOtherType,cmdata);//fixme9.24
    chePaiHao.result = cmdata.b_chepai;
#endif
    UNUSED(alg);
    return 1;
}
