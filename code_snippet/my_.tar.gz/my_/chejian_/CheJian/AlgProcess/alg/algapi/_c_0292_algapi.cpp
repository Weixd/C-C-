#include "_c_0292_algapi.h"

int _c_0292_AlgApi::Dispose(LargeVehicleApi *alg)
{
#if ALG_USED
    Baodan_ImgOutMsg jqxdata;
    alg->baodan_api_process(_photoMain, chePaiHao.inData,cheJiaHao.inData ,
                                  jianYanJieShuShiJian.inData,faDongJiHao.inData,
                                  atoi(heDingZaiKeShu.inData.c_str()),jqxdata);

    zhengBenHuoFuBen.result = jqxdata.b_fuben;
    baoXianYouXiaoQi.result = jqxdata.b_riqi;
    chePaiHao.result = jqxdata.b_chepai;
    cheJiaHao.result = jqxdata.b_chejiahao;
    cheChuanShui.result = jqxdata.b_chechuanshui;
    faDongJiHao.result = jqxdata.b_fadongjihao;
    heDingZaiKeShu.result = jqxdata.b_zaikerenshu;
    yinZhang.result = jqxdata.b_hongzhang;
    chaoBen.result = jqxdata.b_chaoben;

    zhaoPianQingXiDu.result = jqxdata.b_pic_quality;
    dianZiBaoDan.result = jqxdata.b_dianzi;
    zhuangTai.result = jqxdata.b_dg_toubaozhuangtai;
    printf("123 jqxdata.b_dg_toubaozhuangtai:%d\n\n",jqxdata.b_dg_toubaozhuangtai);
#endif
    UNUSED(alg);
    return 1;
}
