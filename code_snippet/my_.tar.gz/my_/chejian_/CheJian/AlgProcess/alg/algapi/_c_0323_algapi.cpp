#include "_c_0323_algapi.h"

int _c_0323_AlgApi::Dispose(LargeVehicleApi *alg)
{
#if ALG_USED
    Dipan_ImgOutMsg out_msg;
    alg->dipan_api_process(_photoMain, chePaiHao.inData, out_msg);

 //   shuiYinRiQi.result = out_msg.b_shuiyin_riqi;
    chePaiHao.result = out_msg.b_chepai;
    diPan.result = out_msg.b_dipan;
    jianYanYuan.result = out_msg.b_human;
#endif
    UNUSED(alg);
    return 1;
}
