#include "_c_0287_algapi.h"

int _c_0287_AlgApi::Dispose(LargeVehicleApi *alg)
{
#if ALG_USED
    Xingshizheng_ImgOutMsg xszdata;
    alg->xingshizheng_api_process(_photoMain, chePaiHao.inData, cheJiaHao.inData,
                                  faZhengRiQi.inData, dangAnHao.inData, xingShiZhengXinBianHao.inData,
                                  cheLiangLeiXing.inData, heDingZaiKeShu.inData,qiangZhiBaoFeiQiZhi.inData,"",
                                  xszdata);

    chePaiHao.result = xszdata.b_chepai;
    cheJiaHao.result = xszdata.b_chejiahao;
    xingShiZhengXinBianHao.result = xszdata.b_tiaoxingma;
    faZhengRiQi.result = xszdata.b_fazhengriqi;
    cheLiangLeiXing.result = xszdata.b_chetype;
    heDingZaiKeShu.result = xszdata.b_renshu;
    tuPianQingXiDu.result = xszdata.b_pic_quality;

#endif
    UNUSED(alg);
    return 1;
}
