#include "_c_0119_algclass.h"

_c_0119_AlgClass::~_c_0119_AlgClass()
{
    if(pAlgApi!=NULL)
    {
        delete pAlgApi;
        pAlgApi = NULL;
    }

}

ALGFUNC_RETURN _c_0119_AlgClass::seekMemberListPointer()
{
    pAlgApi = new _c_0119_AlgApi();
    pInMemberList = &pAlgApi->inMemberList;
    pResultMemberList = &pAlgApi->resultMemberList;
    inListVector.push_back({"default",&pAlgApi->inMemberList});
    resultListVector.push_back({"default",&pAlgApi->resultMemberList});
    allParamList.checkList(pInMemberList);
    return true;
}

ALGFUNC_RETURN _c_0119_AlgClass::LoadParam(ALGFUNC_TP)
{
    //加载主照片
    pAlgApi->loadPhotoMain((*pPhotoList)[index].localPath);
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0119_AlgClass::Dispose(ALGFUNC_TP)
{
    //算法运算
    pAlgApi->Dispose(alg);
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0119_AlgClass::AlgResult(ALGFUNC_TP)
{

    ALG_P_UNUSED return true;
}
