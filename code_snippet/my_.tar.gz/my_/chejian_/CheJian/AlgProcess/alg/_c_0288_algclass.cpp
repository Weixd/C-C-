#include "_c_0288_algclass.h"

_c_0288_AlgClass::~_c_0288_AlgClass()
{
    if(pAlgApi!=NULL)
    {
        delete pAlgApi;
        pAlgApi = NULL;
    }

}


ALGFUNC_RETURN _c_0288_AlgClass::seekMemberListPointer()
{
    pAlgApi = new _c_0288_AlgApi();
    pInMemberList = &pAlgApi->inMemberList;
    pResultMemberList = &pAlgApi->resultMemberList;
    inListVector.push_back({"default",&pAlgApi->inMemberList});
    resultListVector.push_back({"default",&pAlgApi->resultMemberList});
    return true;
}

ALGFUNC_RETURN _c_0288_AlgClass::LoadParam(ALGFUNC_TP)
{
    //格式化发证日期
    pAlgApi->faZhengRiQi.inData = baseTool::formatingDate(pAlgApi->faZhengRiQi.inData);

    //加载主照片
    pAlgApi->loadPhotoMain((*pPhotoList)[index].localPath);

    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0288_AlgClass::Dispose(ALGFUNC_TP)
{
    //算法运算
    pAlgApi->Dispose(alg);
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0288_AlgClass::AlgResult(ALGFUNC_TP)
{
    //如果印章数<=5 则判定通过否则不通过
    if(atoi(pAlgApi->yinZhangShu.OutData.c_str())<=5)
    {
        pAlgApi->yinZhangShu.result = true;
    }

    ALG_P_UNUSED return true;
}
