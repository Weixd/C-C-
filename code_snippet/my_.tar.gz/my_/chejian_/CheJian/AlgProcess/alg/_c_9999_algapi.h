#ifndef _C_9999_ALGCLASS_H
#define _C_9999_ALGCLASS_H

#include "AlgProcess/base/algbaseclass.h"

class _c_9999_AlgApi:public algBaseClass{
public:
    ALG_PARM_MEMBER chePaiHao;
    ALG_PARM_MEMBER shuiYinRiQi;
    ALG_PARM_MEMBER nianJianZhang;

    std::vector<memberItem> inMemberList = {
        {"chePaiHao", "车牌号", &chePaiHao, true, CONFIG_DEFAULT},
        {"shuiYinRiQi", "水印日期", &shuiYinRiQi, true, CONFIG_DEFAULT},
    };

    std::vector<memberItem> resultMemberList = {
        {"chePaiHao", "车牌号不正确", &chePaiHao, true, CONFIG_DEFAULT},
        {"shuiYinRiQi", "水印日期过期", &shuiYinRiQi, true, CONFIG_DEFAULT},
        {"nianJianZhang", "年检章错误", &nianJianZhang, true, CONFIG_DEFAULT},
    };

    virtual ALGFUNC_RETURN Dispose(ALGFUNC_TP);
};


#endif // _C_9999_ALGCLASS_H
