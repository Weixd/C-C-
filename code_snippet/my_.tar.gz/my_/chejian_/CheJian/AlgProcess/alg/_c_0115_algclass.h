#ifndef _C_0115_ALGCLASS_H
#define _C_0115_ALGCLASS_H

#include "AlgProcess/base/algbaseclass.h"
#include "algapi/_c_0166_algapi_keche.h"
#include "algapi/_c_0166_algapi_huoche.h"


class _c_0115_AlgClass:public algBaseClass{
public:

    _c_0166_AlgApi_keChe *pAlgApi_keChe;
    _c_0166_AlgApi_huoChe *pAlgApi_huoChe;
     ALG_PARM_MEMBER buZaiJianCeFanWei = ALG_PARAM_DEFAULT;

    virtual ~_c_0115_AlgClass();
    virtual ALGFUNC_RETURN seekMemberListPointer();
    virtual ALGFUNC_RETURN LoadParam(ALGFUNC_TP);
    virtual ALGFUNC_RETURN AlgResult(ALGFUNC_TP);
    virtual ALGFUNC_RETURN Dispose(ALGFUNC_TP);
};

#endif // _C_0115_ALGCLASS_H
