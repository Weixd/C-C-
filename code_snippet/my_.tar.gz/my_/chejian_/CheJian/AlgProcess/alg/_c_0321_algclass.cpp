#include "_c_0321_algclass.h"
#include "AlgProcess/base/processbaseclass.h"

_c_0321_AlgClass::~_c_0321_AlgClass()
{
    if(pAlgApi!=NULL)
    {
        delete pAlgApi;
        pAlgApi = NULL;
    }

}


ALGFUNC_RETURN _c_0321_AlgClass::seekMemberListPointer()
{
    pAlgApi = new _c_0321_AlgApi();
    pInMemberList = &pAlgApi->inMemberList;
    pResultMemberList = &pAlgApi->resultMemberList;
    inListVector.push_back({"default",&pAlgApi->inMemberList});
    resultListVector.push_back({"default",&pAlgApi->resultMemberList});
    return true;
}

ALGFUNC_RETURN _c_0321_AlgClass::LoadParam(ALGFUNC_TP)
{
    //加载0321左灯光照片
    pAlgApi->loadPhotoMain((*pPhotoList)[index].localPath);

    //格式化水印日期
    pAlgApi->shuiYinRiQi.inData = baseTool::formatingDate(pAlgApi->shuiYinRiQi.inData);

    //搜索0352右灯光照片
    std::string photoPath_0352 = baseTool::seachPhotoPathByZpType(pPhotoList, pProcessClass->getAlgItemCodeByPicType(e0352));
    //如果右灯光不为空加载右灯光照片，否则加载做灯光照片
    if(!photoPath_0352.empty())
    {
        pAlgApi->loadPhotoSub(photoPath_0352);
    }else {
        pAlgApi->loadPhotoSub((*pPhotoList)[index].localPath);
    }

    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0321_AlgClass::Dispose(ALGFUNC_TP)
{
    //算法处理
    pAlgApi->Dispose(alg);
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0321_AlgClass::AlgResult(ALGFUNC_TP)
{
    //获取左灯1、2的 memberitem
    memberItem *pZuoDeng1 = baseTool::getMemberItemByName(pResultMemberList,"zuoDeng1");
    memberItem *pZuoDeng2 = baseTool::getMemberItemByName(pResultMemberList,"zuoDeng2");

    //如果左灯1参数为开启，且左灯2为开启
    if(pZuoDeng1->config.isOpen && pZuoDeng2->config.isOpen)
    {
        //若果左灯1 结果为true 和左灯2 结果为true 则结果 灯光检验通过，否则为不通过
        if(pZuoDeng1->value->result && pZuoDeng2->value->result)
        {
                pZuoDeng1->value->result = true;
        }
        else {
                pZuoDeng1->value->result = false;
        }
    }
    //如果左灯1或左灯2 中右一个参数为开启，则 左灯1或左灯2结果右一个为通过判定为通过否则为不通过
    else if(pZuoDeng1->config.isOpen || pZuoDeng2->config.isOpen){
        if(pZuoDeng1->value->result || pZuoDeng2->value->result)
        {
                pZuoDeng1->value->result = true;
        }
        else {
                pZuoDeng1->value->result = false;
        }
    }

    //新车不检车牌
    if(baseTool::checkIsNewCar(paramList))
    {
        pAlgApi->chePaiHao.result = true;
    }
    ALG_P_UNUSED return true;
}
