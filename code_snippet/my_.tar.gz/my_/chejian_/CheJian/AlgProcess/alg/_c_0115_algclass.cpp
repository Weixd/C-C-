#include "_c_0115_algclass.h"
#include "AlgProcess/alg/algapi/algbaseapi.h"
#include "AlgProcess/base/processbaseclass.h"

_c_0115_AlgClass::~_c_0115_AlgClass()
{
    if(pAlgApi_keChe!=NULL)
    {
        delete pAlgApi_keChe;
        pAlgApi_keChe = NULL;
    }

    if(pAlgApi_huoChe!=NULL)
    {
        delete pAlgApi_huoChe;
        pAlgApi_huoChe = NULL;
    }
}

ALGFUNC_RETURN _c_0115_AlgClass::seekMemberListPointer()
{
    pAlgApi_keChe = new _c_0166_AlgApi_keChe();
    pAlgApi_huoChe = new _c_0166_AlgApi_huoChe();

    pInMemberList = &pAlgApi_keChe->inMemberList;
    pResultMemberList = &pAlgApi_keChe->resultMemberList;

    inListVector.push_back({"keChe",&pAlgApi_keChe->inMemberList});
    inListVector.push_back({"huoChe",&pAlgApi_huoChe->inMemberList});

    resultListVector.push_back({"keChe",&pAlgApi_keChe->resultMemberList});
    resultListVector.push_back({"huoChe",&pAlgApi_huoChe->resultMemberList});

    allParamList.checkList(&pAlgApi_keChe->inMemberList);
    allParamList.checkList(&pAlgApi_huoChe->inMemberList);

    memberItem item;
    item.name = "buZaiJianCeFanWei";           //对应字段名称
    item.desc = "不能处理除了客车和货车以外的车厢内部照片";           //描述
    item.value = &buZaiJianCeFanWei;     //值地址
    item.output = true;                //是否输出
    item.config.isOpen = true;     //参数配置
    item.config.descOpen = true;     //参数配置
    item.config.errLevel = UNABLE_IDENTIFY;     //参数配置
    buZaiJianCeFanWei.result = true;

    //将item添加到结果输出集合中
    addNewResultMember(&item);

    return true;
}

ALGFUNC_RETURN _c_0115_AlgClass::LoadParam(ALGFUNC_TP)
{
    std::string cllx = baseTool::getClassItemValueByName(paramList,"cheLiangLeiXing");
    if((cllx.substr(0, 1)=="H"))
    {
        pInMemberList = &pAlgApi_huoChe->inMemberList;
        pResultMemberList = &pAlgApi_huoChe->resultMemberList;
        pAlgApi_huoChe->loadPhotoMain((*pPhotoList)[index].localPath);
    }
    else if((cllx.substr(0, 1)=="K"))
    {
        pAlgApi_keChe->loadPhotoMain((*pPhotoList)[index].localPath);
    }else {
        buZaiJianCeFanWei.result = false;
        return false;
    }
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0115_AlgClass::Dispose(ALGFUNC_TP)
{
    std::string cllx = baseTool::getClassItemValueByName(paramList,"cheLiangLeiXing");
    if((cllx.substr(0, 1)=="H"))
    {
        pAlgApi_huoChe->Process(alg);
    }
    else if((cllx.substr(0, 1)=="K"))
    {
        pAlgApi_keChe->Process(alg);
    }

    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0115_AlgClass::AlgResult(ALGFUNC_TP)
{
    std::string cllx = baseTool::getClassItemValueByName(paramList,"cheLiangLeiXing");
    if((cllx.substr(0, 1)=="H"))
    {
        if(cllx.substr(2, 1) == "2")
        {
            baseTool::openMemberItemWriteResultByName(&pAlgApi_huoChe->resultMemberList,"gaiZhuang_Kx2");
        }
        if(cllx.substr(2, 1) == "9")
        {
            baseTool::openMemberItemWriteResultByName(&pAlgApi_huoChe->resultMemberList,"gaiZhuang_Kx9");
        }
    }
    else if((cllx.find("K39")))
    {
        baseTool::openMemberItemWriteResultByName(&pAlgApi_keChe->resultMemberList,"gaiZhuang");
        baseTool::openMemberItemWriteResultByName(&pAlgApi_keChe->resultMemberList,"zuoWeiShu");
    }

    ALG_P_UNUSED return true;
}

