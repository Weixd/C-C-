#include "_c_9999_algclass.h"

ALGFUNC_RETURN _c_9999_algClass::BeforDispose(ALGFUNC_TP)
{
    //加载图片
    //修改数据格式
    //等
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_9999_algClass::AlgResult(ALGFUNC_TP)
{
    //算法返回结果进行逻辑处理
    //保存图片
    //阈值校验
    //对比等
    ALG_P_UNUSED return true;
}

