#include "_c_0202_algclass.h"

_c_0202_AlgClass::~_c_0202_AlgClass()
{
    if(pAlgApi!=NULL)
    {
        delete pAlgApi;
        pAlgApi = NULL;
    }

}


ALGFUNC_RETURN _c_0202_AlgClass::seekMemberListPointer()
{
    pAlgApi = new _c_0202_AlgApi();
    pInMemberList = &pAlgApi->inMemberList;
    pResultMemberList = &pAlgApi->resultMemberList;
    inListVector.push_back({"default",&pAlgApi->inMemberList});
    resultListVector.push_back({"default",&pAlgApi->resultMemberList});
    allParamList.checkList(pInMemberList);
    return true;
}

ALGFUNC_RETURN _c_0202_AlgClass::LoadParam(ALGFUNC_TP)
{
    //加载主照片
    pAlgApi->loadPhotoMain((*pPhotoList)[index].localPath);
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0202_AlgClass::Dispose(ALGFUNC_TP)
{
    //算法运算
    pAlgApi->Dispose(alg);
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0202_AlgClass::AlgResult(ALGFUNC_TP)
{
    //所有人号码是否是手机
    int ret = baseTool::isMobileNumber(pAlgApi->suoYouRenShouJiHao.OutData);
    if (ret == -1) {
        pAlgApi->suoYouRenShouJiHao.result = false;
        memberItem *pMember = baseTool::getMemberItemByName(pResultMemberList,"suoYouRenShouJiHao");
        pMember->desc = "无所有人手机号码";
    } else if (ret == 0) {
        pAlgApi->suoYouRenShouJiHao.result = false;
        memberItem *pMember = baseTool::getMemberItemByName(pResultMemberList,"suoYouRenShouJiHao");
        pMember->desc = "所有人手机号码不合法";
    }else {
        pAlgApi->suoYouRenShouJiHao.result = true;
    }

//    if(pAlgApi->diZhi.result)
//    {
//       pAlgApi->diZhi.result = baseTool::isAddress(pAlgApi->diZhi.OutData);
//    }

    //判断代理人号码是否是手机号码
    ret = baseTool::isMobileNumber(pAlgApi->daiLiRenShouJiHao.OutData);
    if (!(ret==0)) {
        pAlgApi->daiLiRenShouJiHao.result = true;
    }

    //新车不检车牌
    if(baseTool::checkIsNewCar(paramList))
    {
        pAlgApi->chePaiHao.result = true;
    }


    //如果照片清晰度为false 则只输出照片清晰度的错误信息其他信息不输出
   baseTool::checkMemberItemAndSetAllUnOutput(pResultMemberList, baseTool::getMemberItemByName(pResultMemberList,"zhaoPianQingXiDu"));

    ALG_P_UNUSED return true;
}
