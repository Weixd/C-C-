#include "_c_0323_algclass.h"

_c_0323_AlgClass::~_c_0323_AlgClass()
{
    if(pAlgApi!=NULL)
    {
        delete pAlgApi;
        pAlgApi = NULL;
    }

}


ALGFUNC_RETURN _c_0323_AlgClass::seekMemberListPointer()
{
    pAlgApi = new _c_0323_AlgApi();
    pInMemberList = &pAlgApi->inMemberList;
    pResultMemberList = &pAlgApi->resultMemberList;
    inListVector.push_back({"default",&pAlgApi->inMemberList});
    resultListVector.push_back({"default",&pAlgApi->resultMemberList});
    return true;
}

ALGFUNC_RETURN _c_0323_AlgClass::LoadParam(ALGFUNC_TP)
{
    //加载主照片
    pAlgApi->loadPhotoMain((*pPhotoList)[index].localPath);
    //格式化水印日期
    pAlgApi->shuiYinRiQi.inData = baseTool::formatingDate(pAlgApi->shuiYinRiQi.inData);
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0323_AlgClass::Dispose(ALGFUNC_TP)
{
    //算法运算
    pAlgApi->Dispose(alg);
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0323_AlgClass::AlgResult(ALGFUNC_TP)
{
    //新车不检车牌
    if(baseTool::checkIsNewCar(paramList))
    {
        pAlgApi->chePaiHao.result = true;
    }

    //大车不捡车牌
    if (baseTool::checkCllxIsK3xOrK4x(paramList))
    {
        pAlgApi->chePaiHao.result = true;
    }
    ALG_P_UNUSED return true;
}
