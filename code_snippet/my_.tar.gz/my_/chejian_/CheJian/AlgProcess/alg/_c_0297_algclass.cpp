#include "_c_0297_algclass.h"

_c_0297_AlgClass::~_c_0297_AlgClass()
{
    if(pAlgApi!=NULL)
    {
        delete pAlgApi;
        pAlgApi = NULL;
    }

}

ALGFUNC_RETURN _c_0297_AlgClass::seekMemberListPointer()
{
    pAlgApi = new _c_0297_AlgApi();
    pInMemberList = &pAlgApi->inMemberList;
    pResultMemberList = &pAlgApi->resultMemberList;
    inListVector.push_back({"default",&pAlgApi->inMemberList});
    resultListVector.push_back({"default",&pAlgApi->resultMemberList});
    return true;
}

ALGFUNC_RETURN _c_0297_AlgClass::LoadParam(ALGFUNC_TP)
{
    //加载照片
    pAlgApi->loadPhotoMain((*pPhotoList)[index].localPath);

    //如果当天日期为空，则填充当前时间格式为20190202
    if(pAlgApi->dangTianRiQi.inData.empty())
    {
        pAlgApi->dangTianRiQi.inData = baseTool::getDangTianRiQi();
    }
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0297_AlgClass::Dispose(ALGFUNC_TP)
{
    //算法处理
    pAlgApi->Dispose(alg);
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0297_AlgClass::AlgResult(ALGFUNC_TP)
{
    //获取初次登记日期
    std::string cjdjrq = baseTool::getClassItemValueByName(paramList,"chuCiDengJiRiQi");
    //如果车辆等级时间 > 10 年 则将 引车检验员 和 地盘检验员输出开启
    if(baseTool::isTenYears(cjdjrq))
    {
        baseTool::changeCheckAlgBaseParamElementByName(pHandle, "qianMing_yinCheJianYanYuan", "", true);
        baseTool::changeCheckAlgBaseParamElementByName(pHandle, "qianMing_diPanJianYanYuan", "", true);
    }
    ALG_P_UNUSED return true;
}

