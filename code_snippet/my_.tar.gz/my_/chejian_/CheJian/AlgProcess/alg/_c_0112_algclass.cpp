#include "_c_0112_algclass.h"

_c_0112_AlgClass::~_c_0112_AlgClass()
{
    if(pAlgApi!=NULL)
    {
        delete pAlgApi;
        pAlgApi = NULL;
    }

    if(pAlgApi_daChe!=NULL)
    {
        delete pAlgApi_daChe;
        pAlgApi_daChe = NULL;
    }
}

ALGFUNC_RETURN _c_0112_AlgClass::seekMemberListPointer()
{
    pAlgApi = new _c_0112_AlgApi();
    pAlgApi_daChe = new _c_0112_AlgApi_daChe();
    pInMemberList = &pAlgApi->inMemberList;
    pResultMemberList = &pAlgApi->resultMemberList;

    inListVector.push_back({"xiaoChe",&pAlgApi->inMemberList});
    inListVector.push_back({"daChe",&pAlgApi_daChe->inMemberList});

    resultListVector.push_back({"xiaoChe",&pAlgApi->resultMemberList});
    resultListVector.push_back({"huoChe",&pAlgApi_daChe->resultMemberList});

    allParamList.checkList(&pAlgApi->inMemberList);
    allParamList.checkList(&pAlgApi_daChe->inMemberList);
    return true;
}

ALGFUNC_RETURN _c_0112_AlgClass::LoadParam(ALGFUNC_TP)
{
    //判定使用大小车接口
    if(baseTool::checkCllxIsK3xOrK4x(paramList))
    {
        //加载主照片
        pAlgApi->loadPhotoMain((*pPhotoList)[index].localPath);
    }
    else
    {
        pInMemberList = &pAlgApi_daChe->inMemberList;
        pResultMemberList = &pAlgApi_daChe->resultMemberList;
        //加载主照片
        pAlgApi_daChe->loadPhotoMain((*pPhotoList)[index].localPath);
    }

    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0112_AlgClass::Dispose(ALGFUNC_TP)
{
    //判定使用大小车接口
    if(baseTool::checkCllxIsK3xOrK4x(paramList))
    {
        //算法运算
        pAlgApi->Dispose(alg);

    }
    else
    {
        //加载主照片
        pAlgApi_daChe->Dispose(alg);
    }

    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0112_AlgClass::AlgResult(ALGFUNC_TP)
{
    if (baseTool::checkCllxIsK3xOrK4x(paramList))
    {
        if (baseTool::compareDate(pAlgApi->shuiYinRiQi.inData, pAlgApi->shuiYinRiQi.OutData))
        {
            pAlgApi->shuiYinRiQi.result = true;
        }

        if(atoi(pAlgApi->paiQiKongShuLiang.OutData.c_str())>4)
        {
            pAlgApi->paiQiKongShuLiang.result = false;
        }
        else
        {
            pAlgApi->paiQiKongShuLiang.result = true;
        }

    }else {
        std::string cllx = baseTool::getClassItemValueByName(paramList,"cheLiangLeiXing");
        std::string s_zzl = baseTool::getClassItemValueByName(paramList,"zhongZhiLiang");
        if (cllx.substr(0, 1) == "H")
        {
           int n_zzl = atoi(s_zzl.c_str());

           if(n_zzl <= 3500)
           {
               baseTool::closeMemberItemWriteResultByName(pResultMemberList,"houXiaBuFangHuZhuangZhi");
               baseTool::closeMemberItemWriteResultByName(pResultMemberList,"youCeFangHuZhuangZhi");
               baseTool::closeMemberItemWriteResultByName(pResultMemberList,"penTuFangDaChePai");
           }
           else if(n_zzl <= 4500)
           {
               baseTool::closeMemberItemWriteResultByName(pResultMemberList,"penTuFangDaChePai");
           }

           if ((cllx.substr(0, 2)=="H1") || (cllx.substr(0, 2)=="H5"))
           {
               baseTool::closeMemberItemWriteResultByName(pResultMemberList,"cheLiangWeiBuBiaoZhi");
           }
        }

    }
    ALG_P_UNUSED return true;
}
