#include "_c_0157_algclass.h"

_c_0157_AlgClass::~_c_0157_AlgClass()
{
    if(pAlgApi!=NULL)
    {
        delete pAlgApi;
        pAlgApi = NULL;
    }

}

ALGFUNC_RETURN _c_0157_AlgClass::seekMemberListPointer()
{
    pAlgApi = new _c_0157_AlgApi();
    pInMemberList = &pAlgApi->inMemberList;
    pResultMemberList = &pAlgApi->resultMemberList;
    inListVector.push_back({"default",&pAlgApi->inMemberList});
    resultListVector.push_back({"default",&pAlgApi->resultMemberList});
    allParamList.checkList(pInMemberList);
    return true;
}

ALGFUNC_RETURN _c_0157_AlgClass::LoadParam(ALGFUNC_TP)
{
    //加载主照片
    pAlgApi->loadPhotoMain((*pPhotoList)[index].localPath);
    //格式化检验结束时间
    pAlgApi->jianYanJieShuShiJian.inData = baseTool::formatingDate(pAlgApi->jianYanJieShuShiJian.inData);

    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0157_AlgClass::Dispose(ALGFUNC_TP)
{
    //算法运算
    pAlgApi->Dispose(alg);
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0157_AlgClass::AlgResult(ALGFUNC_TP)
{
    //判断检验结束时间是否正确
    if (baseTool::compareDate(pAlgApi->jianYanJieShuShiJian.inData, pAlgApi->jianYanJieShuShiJian.OutData)) {
        pAlgApi->jianYanJieShuShiJian.result = true;
    }
    ALG_P_UNUSED return true;
}
