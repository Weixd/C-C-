#include "_c_0175_algclass.h"
#include "AlgProcess/alg/algapi/algbaseapi.h"
#include "AlgProcess/base/processbaseclass.h"

_c_0175_AlgClass::~_c_0175_AlgClass()
{
    if(pAlgApi!=NULL)
    {
        delete pAlgApi;
        pAlgApi = NULL;
    }

}

ALGFUNC_RETURN _c_0175_AlgClass::seekMemberListPointer()
{
    pAlgApi = new _c_0175_AlgApi();
    pInMemberList = &pAlgApi->inMemberList;
    pResultMemberList = &pAlgApi->resultMemberList;
    inListVector.push_back({"default",&pAlgApi->inMemberList});
    resultListVector.push_back({"xiaoChe",&pAlgApi->resultMemberList});
    allParamList.checkList(pInMemberList);
    return true;
}

ALGFUNC_RETURN _c_0175_AlgClass::LoadParam(ALGFUNC_TP)
{
    //加载主照片
    pAlgApi->loadPhotoMain((*pPhotoList)[index].localPath);

    //档案照片默认为false
    pAlgApi->dangAnZhaoPian.result = false;
    //寻找档案照片本地路径
    std::string dangAnPhotoPath = baseTool::seachPhotoPathByZpType(pPhotoList, pProcessClass->getAlgItemCodeByPicType(eCLZQFXS45DZP_A));
    if(!dangAnPhotoPath.empty())
    {
        //档案照片设置为true并加载子照片
        pAlgApi->dangAnZhaoPian.result = true;
        pAlgApi->loadPhotoSub(dangAnPhotoPath);
    }
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0175_AlgClass::Dispose(ALGFUNC_TP)
{
    //算法运算
    pAlgApi->Dispose(alg);
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0175_AlgClass::AlgResult(ALGFUNC_TP)
{
    //如果广告返回值<=1 判定为true 否则为false
    if(atoi(pAlgApi->guangGao.OutData.c_str()) <= 1)
    {
        pAlgApi->guangGao.result = true;
    }

    if(pAlgApi->dangAnZhaoPian.result)
    {
        baseTool::openMemberItemWriteResultByName(pResultMemberList,"cheLiangYanSe");
    }


    ALG_P_UNUSED return true;
}
