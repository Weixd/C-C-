#include "_c_0351_algclass.h"

_c_0351_AlgClass::~_c_0351_AlgClass()
{
    if(pAlgApi!=NULL)
    {
        delete pAlgApi;
        pAlgApi = NULL;
    }
//    if(pAlgLWeideng!=nullptr)
//    {
//        delete pAlgLWeideng;
//        pAlgLWeideng = nullptr;
//    }
//    if(pAlgRWeideng!=nullptr)
//    {
//        delete pAlgRWeideng;
//        pAlgRWeideng = nullptr;
//    }

}

ALGFUNC_RETURN _c_0351_AlgClass::seekMemberListPointer()
{
    pAlgApi = new _c_0351_AlgApi();
//    pAlgLWeideng = new _c_0321_AlgApi();
//    pAlgRWeideng = new _c_0352_AlgApi();
    pInMemberList = &pAlgApi->inMemberList;
    pResultMemberList = &pAlgApi->resultMemberList;
//    pResultMemberList->insert(pResultMemberList->end(),pAlgLWeideng->resultMemberList.begin(),pAlgLWeideng->resultMemberList.end());
//    pResultMemberList->insert(pResultMemberList->end(),pAlgRWeideng->resultMemberList.begin(),pAlgRWeideng->resultMemberList.end());
    inListVector.push_back({"default",&pAlgApi->inMemberList});
    resultListVector.push_back({"default",&pAlgApi->resultMemberList});
    return true;
}

ALGFUNC_RETURN _c_0351_AlgClass::LoadParam(ALGFUNC_TP)
{
    //加载主子图片
    pAlgApi->loadPhotoMain((*pPhotoList)[index].localPath);
    pAlgApi->loadPhotoSub((*pPhotoList)[index].localPath);
//    pAlgLWeideng->loadPhotoMain((*pPhotoList)[index].localPath);
//    pAlgLWeideng->loadPhotoSub((*pPhotoList)[index].localPath);
//    pAlgRWeideng->loadPhotoMain((*pPhotoList)[index].localPath);
//    pAlgRWeideng->loadPhotoSub((*pPhotoList)[index].localPath);
    //格式化水印日期
    pAlgApi->shuiYinRiQi.inData = baseTool::formatingDate(pAlgApi->shuiYinRiQi.inData);
//    pAlgLWeideng->shuiYinRiQi.inData = baseTool::formatingDate(pAlgLWeideng->shuiYinRiQi.inData);
//    pAlgRWeideng->shuiYinRiQi.inData = baseTool::formatingDate(pAlgRWeideng->shuiYinRiQi.inData);
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0351_AlgClass::Dispose(ALGFUNC_TP)
{
    //算法运算
//    if(pAlgLWeideng)
//            pAlgLWeideng->Dispose(alg);
//    if(pAlgRWeideng)
//            pAlgRWeideng->Dispose(alg);
    pAlgApi->Dispose(alg);
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0351_AlgClass::AlgResult(ALGFUNC_TP)
{
    //新车不检车牌
    if(baseTool::checkIsNewCar(paramList))
    {
        pAlgApi->chePaiHao.result = true;
    }
    //pAlgApi->zhiDongDeng.result=pAlgLWeideng->zuoDeng1.result || pAlgLWeideng->zuoDeng2.result || pAlgRWeideng->youDeng1.result || pAlgRWeideng->youDeng2.result;
    ALG_P_UNUSED return true;
}
