#include "_c_0113_algclass.h"
#include "AlgProcess/base/processbaseclass.h"

_c_0113_AlgClass::~_c_0113_AlgClass()
{
    if(pAlgApi!=NULL)
    {
        delete pAlgApi;
        pAlgApi = NULL;
    }

}

ALGFUNC_RETURN _c_0113_AlgClass::seekMemberListPointer()
{
    pAlgApi = new _c_0113_AlgApi();
    pInMemberList = &pAlgApi->inMemberList;
    pResultMemberList = &pAlgApi->resultMemberList;
    inListVector.push_back({"default",&pAlgApi->inMemberList});
    resultListVector.push_back({"default",&pAlgApi->resultMemberList});
    allParamList.checkList(pInMemberList);
    return true;
}

ALGFUNC_RETURN _c_0113_AlgClass::LoadParam(ALGFUNC_TP)
{
    pAlgApi->loadPhotoMain((*pPhotoList)[index].localPath);
    pAlgApi->shuiYinRiQi.inData = baseTool::formatingDate(pAlgApi->shuiYinRiQi.inData);
    std::string taYinMoPhotoPath = baseTool::seachPhotoPathByZpType(pPhotoList, pProcessClass->getAlgItemCodeByPicType(eCLSBDHZP_TYM));
//    pAlgApi->duiBiLeiXing = 0;
    iliebie=0;
    if(!taYinMoPhotoPath.empty())
    {
//        pAlgApi->duiBiLeiXing = 1;
        iliebie=1;
        //档案照片设置为true并加载子照片
        pAlgApi->dangAnZhaoPian.result = true;
        pAlgApi->loadPhotoSub(taYinMoPhotoPath);

    }else {
        pAlgApi->dangAnZhaoPian.result = false;
    }

    pAlgApi->changShangPinPai.inData = pAlgApi->zhiZaoChangMingCheng.inData+"/"+baseTool::getDestClpp(pAlgApi->cheLiangPinPai.inData);

    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0113_AlgClass::Dispose(ALGFUNC_TP)
{
    pAlgApi->Dispose(alg,iliebie);

    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0113_AlgClass::AlgResult(ALGFUNC_TP)
{
    ALG_P_UNUSED
    if (baseTool::compareDate(pAlgApi->shuiYinRiQi.inData, pAlgApi->shuiYinRiQi.OutData)) {
        pAlgApi->shuiYinRiQi.result = true;
    }

    //厂商VIN，0表示不符合，1表示符合，2表示不支持
    int brand = baseTool::str2Int(pAlgApi->changShangPinPai.OutData);
    if(!brand)
    {
        pAlgApi->changShangPinPai.result = false;
    }


    if(pAlgApi->dangAnZhaoPian.result)
    {
        baseTool::openMemberItemWriteResultByName(pResultMemberList,"taYinMo");
        baseTool::openMemberItemWriteResultByName(pResultMemberList,"tuoMo");
    }

    baseTool::checkMemberItemAndSetAllUnOutput(pResultMemberList, baseTool::getMemberItemByName(pResultMemberList,"zhaoPianQingXiDu"));

    return true;
}
