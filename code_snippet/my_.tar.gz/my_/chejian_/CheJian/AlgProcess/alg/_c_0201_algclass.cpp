#include "_c_0201_algclass.h"

_c_0201_AlgClass::~_c_0201_AlgClass()
{
    if(pAlgApi!=NULL)
    {
        delete pAlgApi;
        pAlgApi = NULL;
    }

}

ALGFUNC_RETURN _c_0201_AlgClass::seekMemberListPointer()
{
    pAlgApi = new _c_0201_AlgApi();
    pInMemberList = &pAlgApi->inMemberList;
    pResultMemberList = &pAlgApi->resultMemberList;
    inListVector.push_back({"default",&pAlgApi->inMemberList});
    resultListVector.push_back({"default",&pAlgApi->resultMemberList});
    allParamList.checkList(pInMemberList);
    return true;
}

ALGFUNC_RETURN _c_0201_AlgClass::LoadParam(ALGFUNC_TP)
{
    //加载主照片
    pAlgApi->loadPhotoMain((*pPhotoList)[index].localPath);
    //格式化发证日期
    pAlgApi->faZhengRiQi.inData = baseTool::formatingDate(pAlgApi->faZhengRiQi.inData);

    //新车不检测行驶证
    if(baseTool::checkIsNewCar(paramList))
    {
        //结果输出中所有项的结果判定为通过
        baseTool::setAllPass(pResultMemberList);
        return true;
    }
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0201_AlgClass::Dispose(ALGFUNC_TP)
{
    //算法运算
    pAlgApi->Dispose(alg);
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0201_AlgClass::AlgResult(ALGFUNC_TP)
{
    //2008年10月1号之前的不检测发证日期
    try {
        if ( pAlgApi->faZhengRiQi.inData != ""&&pAlgApi->faZhengRiQi.inData != "无数据") {
            printf("pAlgApi->faZhengRiQi.inData :%s\n",pAlgApi->faZhengRiQi.inData.c_str());
            int n_fzrq = baseTool::str2Int(pAlgApi->faZhengRiQi.inData);
            if (n_fzrq < 20081001) {
                pAlgApi->faZhengRiQi.result = true;
            }
        }
    } catch (const std::exception &e) {
        printf("fzrq formating fail: %s \n", pAlgApi->faZhengRiQi.inData.c_str());
    }

    //如果照片清晰度为false 则只输出照片清晰度的错误信息其他信息不输出
   baseTool::checkMemberItemAndSetAllUnOutput(pResultMemberList, baseTool::getMemberItemByName(pResultMemberList,"zhaoPianQingXiDu"));

    ALG_P_UNUSED return true;
}
