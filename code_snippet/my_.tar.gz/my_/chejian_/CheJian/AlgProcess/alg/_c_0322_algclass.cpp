#include "_c_0322_algclass.h"
#include "AlgProcess/base/processbaseclass.h"

_c_0322_AlgClass::~_c_0322_AlgClass()
{
    if(pAlgApi!=NULL)
    {
        delete pAlgApi;
        pAlgApi = NULL;
    }

}

ALGFUNC_RETURN _c_0322_AlgClass::NeedWriteResult(ALGFUNC_TP)
{
    ALG_P_UNUSED return false;
}


ALGFUNC_RETURN _c_0322_AlgClass::seekMemberListPointer()
{
    pAlgApi = new _c_0322_AlgApi();
    pInMemberList = &pAlgApi->inMemberList;
    pResultMemberList = &pAlgApi->resultMemberList_yiZhou;
    inListVector.push_back({"default",&pAlgApi->inMemberList});
    resultListVector.push_back({"yiZhou",&pAlgApi->resultMemberList_yiZhou});
    resultListVector.push_back({"erZhou",&pAlgApi->resultMemberList_erZhou});
    return true;
}

ALGFUNC_RETURN _c_0322_AlgClass::LoadParam(ALGFUNC_TP)
{

    //修正水印日期格式
    pAlgApi->shuiYinRiQi.inData = baseTool::formatingDate(pAlgApi->shuiYinRiQi.inData);

    //寻找一轴照片
    std::string photoPath_0322 = baseTool::seachPhotoPathByZpType(pPhotoList, pProcessClass->getAlgItemCodeByPicType(e0322));
    if(!photoPath_0322.empty())
    {
        //将一轴照片标记位置设置为1
        pAlgApi->queShaoYiZhouZhaoPian.result = true;
        //加载一轴照片
        pAlgApi->loadPhotoMain(photoPath_0322);
    }
    else
    {
        //未找到一轴照片
        pAlgApi->queShaoYiZhouZhaoPian.result = false;
        //queShaoErZhouZhaoPian
        baseTool::checkMemberItemAndSetAllUnOutput(&pAlgApi->resultMemberList_erZhou, baseTool::getMemberItemByName(&pAlgApi->resultMemberList_erZhou,"queShaoErZhouZhaoPian"));
    }

    //寻找二轴照片
    std::string photoPath_0348 = baseTool::seachPhotoPathByZpType(pPhotoList, pProcessClass->getAlgItemCodeByPicType(e0348));
    if(!photoPath_0348.empty())
    {
        //将二轴照片标记位置设置为1
        pAlgApi->queShaoErZhouZhaoPian.result = true;
        //加载二轴照片
        pAlgApi->loadPhotoSub(photoPath_0348);
    }
    else
    {
        //未找到一轴照片
        pAlgApi->queShaoErZhouZhaoPian.result = false;
        //只输出queShaoYiZhouZhaoPian的信息
        baseTool::checkMemberItemAndSetAllUnOutput(&pAlgApi->resultMemberList_yiZhou, baseTool::getMemberItemByName(&pAlgApi->resultMemberList_yiZhou,"queShaoYiZhouZhaoPian"));
    }

    //如果缺少照片则填充二轴信息后直接结束
    if(!pAlgApi->queShaoYiZhouZhaoPian.result || !pAlgApi->queShaoErZhouZhaoPian.result)
    {
        //填充一轴照片结果信息
        std::string algName = pProcessClass->getAlgItemNameByPicType(e0322);
        PhotoItem *pPhoto = baseTool::seachPhotoByZpType(pPhotoList,pProcessClass->getAlgItemCodeByPicType(e0322));
        if(pPhoto)
        {
            baseTool::wirteResultByMemberList(algName,pPhoto, &pAlgApi->resultMemberList_yiZhou);
        }

        //填充二轴照片结果信息
        algName = pProcessClass->getAlgItemNameByPicType(e0348);
        pPhoto = baseTool::seachPhotoByZpType(pPhotoList,pProcessClass->getAlgItemCodeByPicType(e0348));
        if(pPhoto)
        {
            baseTool::wirteResultByMemberList(algName,pPhoto, &pAlgApi->resultMemberList_erZhou);
        }
        return false;
    }

    //获取车辆类型，并判断是否为小车
    std::string cllx = baseTool::getClassItemValueByName(paramList,"cheLiangLeiXing");
    if(cllx.substr(0, 2) == "K3" || cllx.substr(0, 2) == "K4")
    {
        pAlgApi->CarKind = 1;
    }
    else if(cllx.substr(0, 1) == "M")
    {
        pAlgApi->CarKind = 3;
    }
    else
    {
        pAlgApi->CarKind = 2;
    }

    if(pAlgApi->zhuChe.inData.empty())
    {
        pAlgApi->zhuChe.inData = 1;
    }

    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0322_AlgClass::Dispose(ALGFUNC_TP)
{
    //算法处理
    pAlgApi->Dispose(alg);

    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0322_AlgClass::AlgResult(ALGFUNC_TP)
{
    bool isPlate =!pAlgApi->gunTong1.result&&!pAlgApi->gunTong2.result;

    //获取车辆类型，并判断是否为小车
    if(baseTool::checkCllxIsK3xOrK4x(paramList))
    {
        //如果照片尺寸不一致则 直接输出 zhaopianChiCun
        if(!pAlgApi->zhaopianChiCun.result)
        {
            baseTool::checkMemberItemAndSetAllUnOutput(&pAlgApi->resultMemberList_yiZhou, baseTool::getMemberItemByName(&pAlgApi->resultMemberList_yiZhou,"zhaopianChiCun"));
            baseTool::checkMemberItemAndSetAllUnOutput(&pAlgApi->resultMemberList_erZhou, baseTool::getMemberItemByName(&pAlgApi->resultMemberList_erZhou,"zhaopianChiCun"));
        }
        //小车不输出大车不判断信息
        pAlgApi->daCheJianCe.result = true;
    }else {
        //大车直接输出daCheJianCe的信息
        pAlgApi->daCheJianCe.result = false;
        baseTool::checkMemberItemAndSetAllUnOutput(&pAlgApi->resultMemberList_yiZhou, baseTool::getMemberItemByName(&pAlgApi->resultMemberList_yiZhou,"daCheJianCe"));
        baseTool::checkMemberItemAndSetAllUnOutput(&pAlgApi->resultMemberList_erZhou, baseTool::getMemberItemByName(&pAlgApi->resultMemberList_erZhou,"zhaopianChiCun"));
    }

    //判断是否未平板
    if(!isPlate)
    {
        //如果不是平板不判断二轴信息
        pAlgApi->erZhou.result = true;
    }

    //新车不检车牌
    if(baseTool::checkIsNewCar(paramList))
    {
        pAlgApi->chePaiHao.result = true;
    }


    //填充一轴照片结果信息
    std::string algName = pProcessClass->getAlgItemNameByPicType(e0322);
    PhotoItem *pPhoto = baseTool::seachPhotoByZpType(pPhotoList,pProcessClass->getAlgItemCodeByPicType(e0322));
    if(pPhoto)
    {
        baseTool::wirteResultByMemberList(algName,pPhoto, &pAlgApi->resultMemberList_yiZhou);
    }

    //填充二轴照片结果信息
    algName = pProcessClass->getAlgItemNameByPicType(e0348);
    pPhoto = baseTool::seachPhotoByZpType(pPhotoList,pProcessClass->getAlgItemCodeByPicType(e0348));
    if(pPhoto)
    {
        baseTool::wirteResultByMemberList(algName,pPhoto, &pAlgApi->resultMemberList_erZhou);
    }

    ALG_P_UNUSED return true;
}

