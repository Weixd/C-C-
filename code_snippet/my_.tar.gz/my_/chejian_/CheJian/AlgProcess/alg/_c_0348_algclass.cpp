#include "_c_0348_algclass.h"
#include "AlgProcess/base/processbaseclass.h"

_c_0348_AlgClass::~_c_0348_AlgClass()
{
    if(pAlgApi!=NULL)
    {
        delete pAlgApi;
        pAlgApi = NULL;
    }

}

ALGFUNC_RETURN _c_0348_AlgClass::seekMemberListPointer()
{
    pAlgApi = new _c_0348_AlgApi();
    pInMemberList = &pAlgApi->inMemberList;
    pResultMemberList = &pAlgApi->resultMemberList;
    inListVector.push_back({"default",&pAlgApi->inMemberList});
    resultListVector.push_back({"default",&pAlgApi->resultMemberList});
    return true;
}

ALGFUNC_RETURN _c_0348_AlgClass::LoadParam(ALGFUNC_TP)
{
    //加载二轴照片为子照片
    pAlgApi->loadPhotoSub((*pPhotoList)[index].localPath);

    //修正水印日期格式
    pAlgApi->shuiYinRiQi.inData = baseTool::formatingDate(pAlgApi->shuiYinRiQi.inData);
    //寻找二轴照片
    std::string photoPath_0322 = baseTool::seachPhotoPathByZpType(pPhotoList, pProcessClass->getAlgItemCodeByPicType(e0322));
    if(!photoPath_0322.empty())
    {
        //将一轴照片标记位置设置为true
        pAlgApi->queShaoYiZhouZhaoPian.result = true;
        //加载一轴照片为主照片
        pAlgApi->loadPhotoMain(photoPath_0322);
    }else {
        //未找到一轴照片
        pAlgApi->queShaoYiZhouZhaoPian.result = false;
        //只输出queShaoYiZhouZhaoPian的信息
        baseTool::checkMemberItemAndSetAllUnOutput(pResultMemberList, baseTool::getMemberItemByName(pResultMemberList,"queShaoYiZhouZhaoPian"));
        return true;
    }
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0348_AlgClass::Dispose(ALGFUNC_TP)
{
    //算法处理
    pAlgApi->Dispose(alg);
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0348_AlgClass::AlgResult(ALGFUNC_TP)
{
    //判断是否未平板
    if(!(!pAlgApi->gunTong1.result&&!pAlgApi->gunTong2.result))
    {
        //获取车辆类型，并判断是否为小车
        std::string cllx = baseTool::getClassItemValueByName(paramList,"cheLiangLeiXing");
        if((cllx.substr(0, 2)=="K3") || (cllx.substr(0, 2)=="K4"))
        {
            //如果照片尺寸不一致则 直接输出 zhaopianChiCun
            if(!pAlgApi->zhaopianChiCun.result)
            {
                baseTool::checkMemberItemAndSetAllUnOutput(pResultMemberList, baseTool::getMemberItemByName(pResultMemberList,"zhaopianChiCun"));
            }
            //小车不输出大车不判断信息
            pAlgApi->daCheJianCe.result = true;
        }else {
            //大车直接输出daCheJianCe的信息
            pAlgApi->daCheJianCe.result = false;
            baseTool::checkMemberItemAndSetAllUnOutput(pResultMemberList, baseTool::getMemberItemByName(pResultMemberList,"daCheJianCe"));

        }
    }else {
        //什么都不输出判定为通过
        for(unsigned int i =0; i< pResultMemberList->size(); i++)
        {
            (*pResultMemberList)[i].output = false;
        }
    }


    ALG_P_UNUSED return true;
}
