#include "_c_0205_algclass.h"
#include "AlgProcess/base/basetool.h"

_c_0205_AlgClass::~_c_0205_AlgClass()
{
    if(pAlgApi!=NULL)
    {
        delete pAlgApi;
        pAlgApi = NULL;
    }

}


ALGFUNC_RETURN _c_0205_AlgClass::seekMemberListPointer()
{
    pAlgApi = new _c_0205_AlgApi();
    pInMemberList = &pAlgApi->inMemberList;
    pResultMemberList = &pAlgApi->resultMemberList;
    inListVector.push_back({"default",&pAlgApi->inMemberList});
    resultListVector.push_back({"default",&pAlgApi->resultMemberList});
    allParamList.checkList(pInMemberList);
    return true;
}

ALGFUNC_RETURN _c_0205_AlgClass::LoadParam(ALGFUNC_TP)
{
    //加载主照片
    pAlgApi->loadPhotoMain((*pPhotoList)[index].localPath);

    //获取当天时间
    pAlgApi->dangTianRiQi.inData = baseTool::getDangTianRiQi();
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0205_AlgClass::Dispose(ALGFUNC_TP)
{
    //算法运算
    pAlgApi->Dispose(alg);
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0205_AlgClass::AlgResult(ALGFUNC_TP)
{
    if(pAlgApi->jianYanXiang.size() > 19)
    {
        pAlgApi->jianYanXinXi.result = true;
        for(unsigned int i=0; i < 9; i++)
        {
            if(pAlgApi->jianYanXiang[i] == 0)
            {
                pAlgApi->jianYanXinXi.result = false;
                break;
            }
        }
        if(pAlgApi->jianYanXiang[19] == 0)
        {
            pAlgApi->jianYanXinXi.result = false;
        }

        std::string cllx = baseTool::getClassItemValueByName(paramList,"cheLiangLeiXing");
        //小车
        if(cllx.find("K")!= string::npos)
        {
            for(unsigned int i = 9; i < 19; i++)
            {
                if(pAlgApi->jianYanXiang[i] == 1)
                {
                    pAlgApi->jianYanXinXi.result = false;
                    break;
                }
            }
        }
    }

    //**************************
    //新车不检车牌
    if(baseTool::checkIsNewCar(paramList))
    {
        pAlgApi->chePaiHao.result = true;
    }

    //获取初次登记日期
    std::string cjdjrq = baseTool::getClassItemValueByName(paramList,"chuCiDengJiRiQi");
    //如果车辆等级时间 > 10 年 则将 引车检验员 和 地盘检验员输出开启
    if(baseTool::isTenYears(cjdjrq))
    {
        baseTool::changeCheckAlgBaseParamElementByName(pHandle, "qianZi_yinCheJianYanYuan", "", true);
        baseTool::changeCheckAlgBaseParamElementByName(pHandle, "qianZi_diPanJianYanYuan", "", true);
    }


    ALG_P_UNUSED return true;
}
