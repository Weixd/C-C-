#ifndef _C_0111_PARAMCLASS_H
#define _C_0111_PARAMCLASS_H
#include "AlgProcess/base/algbaseclass.h"
#include "algapi/_c_0111_algapi.h"
#include "algapi/_c_0111_algapi_dache.h"


class _c_0111_AlgClass:public algBaseClass{
public:

    _c_0111_AlgApi *pAlgApi;
    _c_0111_AlgApi_daChe *pAlgApi_daChe;
    virtual ~_c_0111_AlgClass();
    virtual ALGFUNC_RETURN seekMemberListPointer();
    virtual ALGFUNC_RETURN LoadParam(ALGFUNC_TP);
    virtual ALGFUNC_RETURN AlgResult(ALGFUNC_TP);
    virtual ALGFUNC_RETURN Dispose(ALGFUNC_TP);
};

#endif // _C_0111_PARAMCLASS_H
