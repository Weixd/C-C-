#include "_c_0209_algclass.h"
#include "AlgProcess/base/processbaseclass.h"

_c_0209_AlgClass::~_c_0209_AlgClass()
{
    if(pAlgApi!=NULL)
    {
        delete pAlgApi;
        pAlgApi = NULL;
    }

    if(pAlgApi2!=NULL)
    {
        delete pAlgApi2;
        pAlgApi2 = NULL;
    }

}
ALGFUNC_RETURN _c_0209_AlgClass::NeedWriteResult(ALGFUNC_TP)
{
    ALG_P_UNUSED return false;
}

ALGFUNC_RETURN _c_0209_AlgClass::seekMemberListPointer()
{
    pAlgApi = new _c_0209_AlgApi();
    pAlgApi2 = new _c_0209_AlgApi();
    pInMemberList = &pAlgApi->inMemberList;
    pResultMemberList = &pAlgApi->resultMemberList;
    inListVector.push_back({"yiye",&pAlgApi->inMemberList});
    inListVector.push_back({"erye",&pAlgApi2->inMemberList});

    resultListVector.push_back({"default",&pAlgApi->resultMemberList});
    return true;
}
#include "Application/trace_log.h"
ALGFUNC_RETURN _c_0209_AlgClass::LoadParam(ALGFUNC_TP)
{
    //加载尾气单第一张照片主照片
    pAlgApi->loadPhotoMain((*pPhotoList)[index].localPath);
    // 格式化尾气检测时间
    pAlgApi->weiQiJianCeShiJian.inData = baseTool::formatingDate(pAlgApi->weiQiJianCeShiJian.inData);
    //判断当天日期是否为空
    if(pAlgApi->dangTianRiQi.inData.empty())
    {
        //获取当天日期
        pAlgApi->dangTianRiQi.inData = baseTool::getDangTianRiQi();
    }
    //将尾气检测时间添加到shiJianVector中
    pAlgApi->shiJianVector.push_back(pAlgApi->weiQiJianCeShiJian.inData);

    //格式化尾气检测时间
    pAlgApi2->weiQiJianCeShiJian.inData = baseTool::formatingDate(pAlgApi2->weiQiJianCeShiJian.inData);
    //判断当天日期是否为空
    if(pAlgApi2->dangTianRiQi.inData.empty())
    {
        //获取当天日期
        pAlgApi2->dangTianRiQi.inData = baseTool::getDangTianRiQi();
    }
    //将尾气检测时间添加到shiJianVector中
    pAlgApi2->shiJianVector.push_back(pAlgApi2->weiQiJianCeShiJian.inData);

    //搜索尾气单第二张照片
    weiQiDanPhoto2Path = baseTool::seachPhotoPathByZpType(pPhotoList, pProcessClass->getAlgItemCodeByPicType(eWQDZP2));
//    DATA_PRINT(LEVEL_INFO,"wyd~~  尾气单第二张照片%s\n",weiQiDanPhoto2Path.c_str());
    if(!weiQiDanPhoto2Path.empty())
    {
        //加载为尾气单第二张照片
        pAlgApi2->loadPhotoMain(weiQiDanPhoto2Path);
    }

    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0209_AlgClass::Dispose(ALGFUNC_TP)
{

    //算法运算尾气单第一张照片
    pAlgApi->Dispose(alg);

    //如果尾气单照片2不为空算法运算尾气单第二张照片
    if(!weiQiDanPhoto2Path.empty())
    {

        pAlgApi2->Dispose(alg);
    }

    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0209_AlgClass::AlgResult(ALGFUNC_TP)
{
    //尾气单照片一结果 || 尾气单照片二结果
    pAlgApi->huanBaoJianYanJieLun.result = pAlgApi->huanBaoJianYanJieLun.result || pAlgApi2->huanBaoJianYanJieLun.result;
    pAlgApi->chePaiHao.result = pAlgApi->chePaiHao.result || pAlgApi2->chePaiHao.result;
    pAlgApi->cheJiaHao.result = pAlgApi->cheJiaHao.result || pAlgApi2->cheJiaHao.result;
    pAlgApi->yinZhang.result = pAlgApi->yinZhang.result || pAlgApi2->yinZhang.result;
    pAlgApi->qianMing.result = pAlgApi->qianMing.result || pAlgApi2->qianMing.result;
    pAlgApi->yinZhang_CMA.result = pAlgApi->yinZhang_CMA.result || pAlgApi2->yinZhang_CMA.result;
    pAlgApi->weiQiJianCeShiJian.result = pAlgApi->weiQiJianCeShiJian.result || pAlgApi2->weiQiJianCeShiJian.result;
    pAlgApi->faDongJiXingHao.result = pAlgApi->faDongJiXingHao.result || pAlgApi2->faDongJiXingHao.result;
    pAlgApi->jianCeShiJian.result = pAlgApi->jianCeShiJian.result || pAlgApi2->jianCeShiJian.result;
    pAlgApi->qianMing_caoZuoYuan.result = pAlgApi->qianMing_caoZuoYuan.result || pAlgApi2->qianMing_caoZuoYuan.result;
    pAlgApi->qianMing_jiaShiYuan.result = pAlgApi->qianMing_jiaShiYuan.result || pAlgApi2->qianMing_jiaShiYuan.result;
    pAlgApi->qianMing_piZhunRen.result = pAlgApi->qianMing_piZhunRen.result || pAlgApi2->qianMing_piZhunRen.result;
    pAlgApi->qianMing_shenHeRen.result = pAlgApi->qianMing_shenHeRen.result || pAlgApi2->qianMing_shenHeRen.result;
    pAlgApi->dianZiBiaoGe.result = pAlgApi->dianZiBiaoGe.result || pAlgApi2->dianZiBiaoGe.result;
    pAlgApi->huanBaoDan.result = pAlgApi->huanBaoDan.result || pAlgApi2->huanBaoDan.result;

    //新车不检车牌
    if(baseTool::checkIsNewCar(paramList))
    {
        pAlgApi->chePaiHao.result = true;
    }

    //如果huanBaoDan 结果为true 则只输出huanBaoDan
    baseTool::checkMemberItemAndSetAllUnOutput(pResultMemberList, baseTool::getMemberItemByName(pResultMemberList,"huanBaoDan"));


    std::string algName = pProcessClass->getAlgItemNameByPicType(e0209);
    PhotoItem *pPhoto = baseTool::seachPhotoByZpType(pPhotoList,pProcessClass->getAlgItemCodeByPicType(e0209));
    if(pPhoto)
    {
        baseTool::wirteResultByMemberList(algName,pPhoto, &pAlgApi->resultMemberList);
    }
    if(!weiQiDanPhoto2Path.empty())
    {
        algName = pProcessClass->getAlgItemNameByPicType(eWQDZP2);
        pPhoto = baseTool::seachPhotoByZpType(pPhotoList,pProcessClass->getAlgItemCodeByPicType(eWQDZP2));
        if(pPhoto)
        {
            baseTool::wirteResultByMemberList(algName,pPhoto, &pAlgApi->resultMemberList);
        }
    }
    ALG_P_UNUSED return true;
}
