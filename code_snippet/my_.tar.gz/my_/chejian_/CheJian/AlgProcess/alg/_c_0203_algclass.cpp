#include "_c_0203_algclass.h"

_c_0203_AlgClass::~_c_0203_AlgClass()
{

    if(pAlgApi!=NULL)
    {
        delete pAlgApi;
        pAlgApi = NULL;
    }

}

ALGFUNC_RETURN _c_0203_AlgClass::seekMemberListPointer()
{
    pAlgApi = new _c_0203_AlgApi();
    pInMemberList = &pAlgApi->inMemberList;
    pResultMemberList = &pAlgApi->resultMemberList;
    inListVector.push_back({"default",&pAlgApi->inMemberList});
    resultListVector.push_back({"zhiZhi",&pAlgApi->resultMemberList});
    resultListVector.push_back({"dianZi",&pAlgApi->resultMemberList_dianZi});

    allParamList.checkList(pInMemberList);

    return true;
}

ALGFUNC_RETURN _c_0203_AlgClass::LoadParam(ALGFUNC_TP)
{
    //格式化生效日期，终止日期，检验结束时间
    pAlgApi->shengXiaoRiQi.inData = baseTool::formatingDate(pAlgApi->shengXiaoRiQi.inData);
    pAlgApi->zhongZhiRiQi.inData = baseTool::formatingDate(pAlgApi->zhongZhiRiQi.inData);
    pAlgApi->jianYanJieShuShiJian.inData = baseTool::formatingDate(pAlgApi->jianYanJieShuShiJian.inData);

    //加载主照片
    pAlgApi->loadPhotoMain((*pPhotoList)[index].localPath);

    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0203_AlgClass::Dispose(ALGFUNC_TP)
{
    //算法运算
    pAlgApi->Dispose(alg);
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0203_AlgClass::AlgResult(ALGFUNC_TP)
{
    //判断是电子保单还是纸质保单，如果未电子保单则切换到电子保单输出结果集
    if(pAlgApi->dianZiBaoDan.result)
    {
        pResultMemberList = &pAlgApi->resultMemberList_dianZi;
    }
    //新车不检车牌
    if(baseTool::checkIsNewCar(paramList))
    {
        pAlgApi->chePaiHao.result = true;
    }
    //如果照片清晰度为false 则只输出照片清晰度的错误信息其他信息不输出
   baseTool::checkMemberItemAndSetAllUnOutput(pResultMemberList, baseTool::getMemberItemByName(pResultMemberList,"zhaoPianQingXiDu"));
    ALG_P_UNUSED return true;
}
