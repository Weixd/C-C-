#include "_c_0168_algclass.h"

_c_0168_AlgClass::~_c_0168_AlgClass()
{
    if(pAlgApi!=NULL)
    {
        delete pAlgApi;
        pAlgApi = NULL;
    }

}

ALGFUNC_RETURN _c_0168_AlgClass::seekMemberListPointer()
{
    pAlgApi = new _c_0168_AlgApi();
    pInMemberList = &pAlgApi->inMemberList;
    pResultMemberList = &pAlgApi->resultMemberList;
    inListVector.push_back({"default",&pAlgApi->inMemberList});
    resultListVector.push_back({"default",&pAlgApi->resultMemberList});
    allParamList.checkList(pInMemberList);
    return true;
}

ALGFUNC_RETURN _c_0168_AlgClass::LoadParam(ALGFUNC_TP)
{
    //格式化水印日期
    pAlgApi->shuiYinRiQi.inData = baseTool::formatingDate(pAlgApi->shuiYinRiQi.inData);
    //加载主照片
    pAlgApi->loadPhotoMain((*pPhotoList)[index].localPath);
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0168_AlgClass::Dispose(ALGFUNC_TP)
{
    //算法运算
    pAlgApi->Dispose(alg);
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0168_AlgClass::AlgResult(ALGFUNC_TP)
{

    ALG_P_UNUSED return true;
}

