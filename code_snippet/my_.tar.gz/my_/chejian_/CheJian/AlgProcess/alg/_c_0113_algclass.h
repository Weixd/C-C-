#ifndef _C_0113_PARAMCLASS_H
#define _C_0113_PARAMCLASS_H
#include "AlgProcess/base/algbaseclass.h"
#include "algapi/_c_0113_algapi.h"

class _c_0113_AlgClass:public algBaseClass{
public:
    _c_0113_AlgApi *pAlgApi;
    virtual ~_c_0113_AlgClass();
    virtual ALGFUNC_RETURN seekMemberListPointer();
    virtual ALGFUNC_RETURN LoadParam(ALGFUNC_TP);
    virtual ALGFUNC_RETURN AlgResult(ALGFUNC_TP);
    virtual ALGFUNC_RETURN Dispose(ALGFUNC_TP);
private:
    int iliebie;
};

#endif // _C_0113_PARAMCLASS_H
