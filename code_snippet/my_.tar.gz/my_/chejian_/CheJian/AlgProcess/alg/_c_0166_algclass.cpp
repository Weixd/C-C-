#include "_c_0166_algclass.h"
#include "AlgProcess/alg/algapi/algbaseapi.h"
#include "AlgProcess/base/processbaseclass.h"

_c_0166_AlgClass::~_c_0166_AlgClass()
{
    if(pAlgApi_keChe!=NULL)
    {
        delete pAlgApi_keChe;
        pAlgApi_keChe = NULL;
    }
}

ALGFUNC_RETURN _c_0166_AlgClass::seekMemberListPointer()
{
    pAlgApi_keChe = new _c_0166_AlgApi_keChe();

    pInMemberList = &pAlgApi_keChe->inMemberList;
    pResultMemberList = &pAlgApi_keChe->resultMemberList;

    inListVector.push_back({"keChe",&pAlgApi_keChe->inMemberList});

    resultListVector.push_back({"keChe",&pAlgApi_keChe->resultMemberList});

    allParamList.checkList(&pAlgApi_keChe->inMemberList);

    return true;
}

ALGFUNC_RETURN _c_0166_AlgClass::LoadParam(ALGFUNC_TP)
{

    pAlgApi_keChe->loadPhotoMain((*pPhotoList)[index].localPath);

    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0166_AlgClass::Dispose(ALGFUNC_TP)
{

    pAlgApi_keChe->Process(alg);

    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0166_AlgClass::AlgResult(ALGFUNC_TP)
{

    baseTool::openMemberItemWriteResultByName(&pAlgApi_keChe->resultMemberList,"gaiZhuang");
    baseTool::openMemberItemWriteResultByName(&pAlgApi_keChe->resultMemberList,"zuoWeiShu");
    baseTool::openMemberItemWriteResultByName(&pAlgApi_keChe->resultMemberList,"anQuanDai");

    ALG_P_UNUSED return true;
}

