#include "_c_0342_algclass.h"
#include "AlgProcess/base/processbaseclass.h"

_c_0342_AlgClass::~_c_0342_AlgClass()
{
    if(pAlgApi!=NULL)
    {
        delete pAlgApi;
        pAlgApi = NULL;
    }

}

ALGFUNC_RETURN _c_0342_AlgClass::seekMemberListPointer()
{
    pAlgApi = new _c_0342_AlgApi();
    pInMemberList = &pAlgApi->inMemberList;
    pResultMemberList = &pAlgApi->resultMemberList;
    inListVector.push_back({"default",&pAlgApi->inMemberList});
    resultListVector.push_back({"default",&pAlgApi->resultMemberList});
    return true;
}

ALGFUNC_RETURN _c_0342_AlgClass::LoadParam(ALGFUNC_TP)
{
    //加载主照片
    pAlgApi->loadPhotoSub((*pPhotoList)[index].localPath);
    //查找0344照片如果找到则加载为主图片，否则只输出queShaoKaiShiZhaoPian信息
    std::string photoPath_0344 = baseTool::seachPhotoPathByZpType(pPhotoList, pProcessClass->getAlgItemCodeByPicType(e0344));
    if(!photoPath_0344.empty())
    {
        pAlgApi->queShaoKaiShiZhaoPian.result = true;
        pAlgApi->loadPhotoMain(photoPath_0344);
    }else {
        pAlgApi->queShaoKaiShiZhaoPian.result = false;
        baseTool::checkMemberItemAndSetAllUnOutput(pResultMemberList, baseTool::getMemberItemByName(pResultMemberList,"queShaoKaiShiZhaoPian"));
        return true;
    }
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0342_AlgClass::Dispose(ALGFUNC_TP)
{
    //算法运算
    pAlgApi->Dispose(alg);
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0342_AlgClass::AlgResult(ALGFUNC_TP)
{
    //如果车牌2配置为开启则 车牌2 或车牌1 通过则车牌判定结果为通过
    memberItem *pChePai2 = baseTool::getMemberItemByName(pResultMemberList,"chePaiHao2");
    if(pChePai2->config.isOpen)
    {
         pAlgApi->chePaiHao.result = pAlgApi->chePaiHao.result || pChePai2->value->result;
    }
    ALG_P_UNUSED return true;
}
