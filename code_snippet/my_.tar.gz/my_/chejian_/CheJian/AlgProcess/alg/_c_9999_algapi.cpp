#include "_c_9999_algapi.h"

std::string algGetChePaiFormImage()
{
    return "E123456";
}

std::string algGetShuiYinRiQiFormImage()
{
    return "2019-06-19";
}

ALGFUNC_RETURN _c_9999_AlgApi::Dispose(ALGFUNC_TP){
    chePaiHao.OutData = algGetChePaiFormImage();
    if(chePaiHao.inData == chePaiHao.OutData)
    {
        chePaiHao.result = true;
    }

    shuiYinRiQi.OutData = algGetShuiYinRiQiFormImage();
    if(shuiYinRiQi.inData == shuiYinRiQi.OutData)
    {
        shuiYinRiQi.result = true;
    }

    nianJianZhang.result = false;

    ALG_P_UNUSED return true;
}
