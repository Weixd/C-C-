#include "_c_0352_algclass.h"
#include "AlgProcess/base/processbaseclass.h"

_c_0352_AlgClass::~_c_0352_AlgClass()
{
    if(pAlgApi!=NULL)
    {
        delete pAlgApi;
        pAlgApi = NULL;
    }

}

ALGFUNC_RETURN _c_0352_AlgClass::seekMemberListPointer()
{
    pAlgApi = new _c_0352_AlgApi();
    pInMemberList = &pAlgApi->inMemberList;
    pResultMemberList = &pAlgApi->resultMemberList;
    inListVector.push_back({"default",&pAlgApi->inMemberList});
    resultListVector.push_back({"default",&pAlgApi->resultMemberList});
    return true;
}

ALGFUNC_RETURN _c_0352_AlgClass::LoadParam(ALGFUNC_TP)
{
    //加载0352为子照片右灯照片
    pAlgApi->loadPhotoSub((*pPhotoList)[index].localPath);

    //格式化水印日期
    pAlgApi->shuiYinRiQi.inData = baseTool::formatingDate(pAlgApi->shuiYinRiQi.inData);

    //寻找0321左灯照片
    std::string photoPath_0321 = baseTool::seachPhotoPathByZpType(pPhotoList, pProcessClass->getAlgItemCodeByPicType(e0321));
    //如果右左灯照片则加载主照片为左灯照片否则加载右灯照片
    if(!photoPath_0321.empty())
    {
        pAlgApi->loadPhotoMain(photoPath_0321);
    }else {
        pAlgApi->loadPhotoMain((*pPhotoList)[index].localPath);
    }

    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0352_AlgClass::Dispose(ALGFUNC_TP)
{

    //算法运算
    pAlgApi->Dispose(alg);

    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0352_AlgClass::AlgResult(ALGFUNC_TP)
{
    //获取右等1、2 member参数
    memberItem *pYouDeng1 = baseTool::getMemberItemByName(pResultMemberList,"youDeng1");
    memberItem *pYouDeng2 = baseTool::getMemberItemByName(pResultMemberList,"youDeng2");
    //俩者为配置isopen为true 则结果都为true 判定通过否则不通过
    if(pYouDeng1->config.isOpen && pYouDeng2->config.isOpen)
    {
        if(pYouDeng1->value->result && pYouDeng2->value->result)
        {
                pYouDeng1->value->result = true;
        }
        else {
                pYouDeng1->value->result = false;
        }
    }
    //俩者配置右一个为true 则结果右一个为true 判定通过否则不通过
    else if(pYouDeng1->config.isOpen || pYouDeng2->config.isOpen){
        if(pYouDeng1->value->result || pYouDeng2->value->result)
        {
                pYouDeng1->value->result = true;
        }
        else {
                pYouDeng1->value->result = false;
        }
    }
    //新车不检车牌
    if(baseTool::checkIsNewCar(paramList))
    {
        pAlgApi->chePaiHao.result = true;
    }

    ALG_P_UNUSED return true;
}
