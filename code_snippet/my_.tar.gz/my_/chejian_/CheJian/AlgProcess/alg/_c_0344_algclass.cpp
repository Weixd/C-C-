#include "_c_0344_algclass.h"
#include "AlgProcess/base/processbaseclass.h"

_c_0344_AlgClass::~_c_0344_AlgClass()
{
    if(pAlgApi!=NULL)
    {
        delete pAlgApi;
        pAlgApi = NULL;
    }

}

ALGFUNC_RETURN _c_0344_AlgClass::seekMemberListPointer()
{
    pAlgApi = new _c_0344_AlgApi();
    pInMemberList = &pAlgApi->inMemberList;
    pResultMemberList = &pAlgApi->resultMemberList_kaiShi;
    inListVector.push_back({"default",&pAlgApi->inMemberList});
    resultListVector.push_back({"kaiShi",&pAlgApi->resultMemberList_kaiShi});
    resultListVector.push_back({"jieShu",&pAlgApi->resultMemberList_jieShu});
    return true;
}

ALGFUNC_RETURN _c_0344_AlgClass::LoadParam(ALGFUNC_TP)
{
    //寻找0342照片如果没找到直接结束并返回只输出queShaoJieShuZhaoPian信息 否则加载子照片
    std::string photoPath_0344 = baseTool::seachPhotoPathByZpType(pPhotoList, pProcessClass->getAlgItemCodeByPicType(e0344));
    if(!photoPath_0344.empty())
    {
        pAlgApi->queShaoKaiShiZhaoPian.result = true;
        pAlgApi->loadPhotoMain(photoPath_0344);
    }else {
        pAlgApi->queShaoKaiShiZhaoPian.result = false;
        baseTool::checkMemberItemAndSetAllUnOutput(&pAlgApi->resultMemberList_kaiShi, baseTool::getMemberItemByName(&pAlgApi->resultMemberList_kaiShi,"queShaoKaiShiZhaoPian"));
    }

    //寻找0342照片如果没找到直接结束并返回只输出queShaoJieShuZhaoPian信息 否则加载子照片
    std::string photoPath_0342 = baseTool::seachPhotoPathByZpType(pPhotoList, pProcessClass->getAlgItemCodeByPicType(e0342));
    if(!photoPath_0342.empty())
    {
        pAlgApi->queShaoJieShuZhaoPian.result = true;
        pAlgApi->loadPhotoSub(photoPath_0342);
    }else {
        pAlgApi->queShaoJieShuZhaoPian.result = false;
        baseTool::checkMemberItemAndSetAllUnOutput(&pAlgApi->resultMemberList_jieShu, baseTool::getMemberItemByName(&pAlgApi->resultMemberList_jieShu,"queShaoJieShuZhaoPian"));
    }
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0344_AlgClass::Dispose(ALGFUNC_TP)
{
    //算法运算
    pAlgApi->Dispose(alg);

    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0344_AlgClass::AlgResult(ALGFUNC_TP)
{
    bool chePaiResult =  pAlgApi->chePaiHao.result;
    //判断车牌2是否为通过,如果车牌2设置为打开则 车牌2 通过也判定为车牌通过（用于结束）
    memberItem *pChePai2 = baseTool::getMemberItemByName(&pAlgApi->resultMemberList_jieShu,"chePaiHao2");
    if(pChePai2->config.isOpen)
    {
         pAlgApi->chePaiHao.result = pAlgApi->chePaiHao.result || pChePai2->value->result;
    }

    //填充二轴照片结果信息
    std::string algName = pProcessClass->getAlgItemNameByPicType(e0342);
    PhotoItem *pPhoto = baseTool::seachPhotoByZpType(pPhotoList,pProcessClass->getAlgItemCodeByPicType(e0342));
    if(pPhoto)
    {
        baseTool::wirteResultByMemberList(algName,pPhoto, &pAlgApi->resultMemberList_jieShu);
    }

     pAlgApi->chePaiHao.result = chePaiResult;
    //判断车牌2是否为通过,如果车牌2设置为打开则 车牌2 通过也判定为车牌通过(开始用防止被结束结果即覆盖)
    pChePai2 = baseTool::getMemberItemByName(&pAlgApi->resultMemberList_kaiShi,"chePaiHao2");
    if(pChePai2->config.isOpen)
    {
         pAlgApi->chePaiHao.result = pAlgApi->chePaiHao.result || pChePai2->value->result;
    }

    ALG_P_UNUSED return true;
}
