#ifndef _C_0205_ALGCLASS_H
#define _C_0205_ALGCLASS_H
#include "AlgProcess/base/algbaseclass.h"
#include "AlgProcess/alg/algapi/_c_0205_algapi.h"

class _c_0205_AlgClass:public algBaseClass{
public:
    _c_0205_AlgApi *pAlgApi;
    virtual ~_c_0205_AlgClass();
    virtual ALGFUNC_RETURN seekMemberListPointer();
    virtual ALGFUNC_RETURN LoadParam(ALGFUNC_TP);
    virtual ALGFUNC_RETURN AlgResult(ALGFUNC_TP);
    virtual ALGFUNC_RETURN Dispose(ALGFUNC_TP);
};

#endif // _C_0205_ALGCLASS_H
