#include "_c_0206_algclass.h"

_c_0206_AlgClass::~_c_0206_AlgClass()
{
    if(pAlgApi!=NULL)
    {
        delete pAlgApi;
        pAlgApi = NULL;
    }

}

ALGFUNC_RETURN _c_0206_AlgClass::seekMemberListPointer()
{
    pAlgApi = new _c_0206_AlgApi();
    pInMemberList = &pAlgApi->inMemberList;
    pResultMemberList = &pAlgApi->resultMemberList;
    inListVector.push_back({"default",&pAlgApi->inMemberList});
    resultListVector.push_back({"default",&pAlgApi->resultMemberList});
    allParamList.checkList(pInMemberList);
    return true;
}

ALGFUNC_RETURN _c_0206_AlgClass::LoadParam(ALGFUNC_TP)
{
    //加载主照片
    pAlgApi->loadPhotoMain((*pPhotoList)[index].localPath);
    //格式化检验结束时间
    pAlgApi->jianYanJieShuShiJian.inData = baseTool::formatingDate(pAlgApi->jianYanJieShuShiJian.inData);

    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0206_AlgClass::Dispose(ALGFUNC_TP)
{
    //算法运算
    pAlgApi->Dispose(alg);
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0206_AlgClass::AlgResult(ALGFUNC_TP)
{
    //如果wanShuiZhengMing 未false 则只输出wanShuiZhengMing对应信息
    baseTool::checkMemberItemAndSetAllUnOutput(pResultMemberList, baseTool::getMemberItemByName(pResultMemberList,"wanShuiZhengMing"));
    ALG_P_UNUSED return true;
}
