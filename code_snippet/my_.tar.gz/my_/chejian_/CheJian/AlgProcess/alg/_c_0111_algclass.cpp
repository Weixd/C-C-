#include "_c_0111_algclass.h"
#include "AlgProcess/alg/algapi/algbaseapi.h"
#include "AlgProcess/base/processbaseclass.h"

_c_0111_AlgClass::~_c_0111_AlgClass()
{
    if(pAlgApi!=NULL)
    {
        delete pAlgApi;
        pAlgApi = NULL;
    }

    if(pAlgApi_daChe!=NULL)
    {
        delete pAlgApi_daChe;
        pAlgApi_daChe = NULL;
    }
}

ALGFUNC_RETURN _c_0111_AlgClass::seekMemberListPointer()
{
    pAlgApi = new _c_0111_AlgApi();
    pAlgApi_daChe = new _c_0111_AlgApi_daChe();

    pInMemberList = &pAlgApi->inMemberList;
    pResultMemberList = &pAlgApi->resultMemberList;

    inListVector.push_back({"xiaoChe",&pAlgApi->inMemberList});
    inListVector.push_back({"daChe",&pAlgApi_daChe->inMemberList});

    resultListVector.push_back({"xiaoChe",&pAlgApi->resultMemberList});
    resultListVector.push_back({"daChe",&pAlgApi_daChe->resultMemberList});

    allParamList.checkList(&pAlgApi->inMemberList);
    allParamList.checkList(&pAlgApi_daChe->inMemberList);

    return true;
}

ALGFUNC_RETURN _c_0111_AlgClass::LoadParam(ALGFUNC_TP)
{
    if(baseTool::checkCllxIsK3xOrK4x(paramList))
    {
        pAlgApi->dangAnZhaoPian.result = false;
        std::string dangAnPhotoPath = baseTool::seachPhotoPathByZpType(pPhotoList, pProcessClass->getAlgItemCodeByPicType(eCLZQFXS45DZP_A));
        if(!dangAnPhotoPath.empty())
        {
            pAlgApi->dangAnZhaoPian.result = true;
            pAlgApi->loadPhotoSub(dangAnPhotoPath);
        }
        pAlgApi->loadPhotoMain((*pPhotoList)[index].localPath);
    }else {
        pInMemberList = &pAlgApi_daChe->inMemberList;
        pResultMemberList = &pAlgApi_daChe->resultMemberList;

        pAlgApi_daChe->loadPhotoMain((*pPhotoList)[index].localPath);
    }
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0111_AlgClass::Dispose(ALGFUNC_TP)
{
    if(baseTool::checkCllxIsK3xOrK4x(paramList))
    {
        pAlgApi->Process(alg);
    }else {
        pAlgApi_daChe->Process(alg);
    }

    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0111_AlgClass::AlgResult(ALGFUNC_TP)
{
    if (baseTool::checkCllxIsK3xOrK4x(paramList)) {
        if (baseTool::compareDate(pAlgApi->shuiYinRiQi.inData, pAlgApi->shuiYinRiQi.OutData)) {
            pAlgApi->shuiYinRiQi.result = true;
        }

        if(pAlgApi->dangAnZhaoPian.result)
        {
            baseTool::openMemberItemWriteResultByName(pResultMemberList,"cheLiangYanSe");
            baseTool::openMemberItemWriteResultByName(pResultMemberList,"xingLiJia");
            baseTool::openMemberItemWriteResultByName(pResultMemberList,"jiaoTaBan");
        }

    }else {
        std::string cllx = baseTool::getClassItemValueByName(paramList, "cheLiangLeiXing");
        std::string s_zzl = baseTool::getClassItemValueByName(paramList, "zongZhiLiang");
        if (cllx.substr(0, 1) == "H") {
           int n_zzl = atoi(s_zzl.c_str());

           if(n_zzl <= 3500)
           {
               baseTool::closeMemberItemWriteResultByName(pResultMemberList,"zuoCeFangHuZhuangZhi");
           }
        }

    }

    ALG_P_UNUSED return true;
}

