#ifndef _C_9999_CLASS_H
#define _C_9999_CLASS_H

#include "_c_9999_algclass.h"

class _c_9999_class:public _c_9999_AlgClass{
public:
    std::vector<memberItem> resultMemberList = {
        {"hphm", "车牌号不正确", &chepai, true, CONFIG_DEFAULT},
        {"syrq", "水印日期过期", &syrq, true, CONFIG_DEFAULT},
    };

    virtual ALGFUNC_RETURN AlgResult(ALGFUNC_TP){ALG_P_UNUSED return true;}
};

#endif // _C_9999_CLASS_H
