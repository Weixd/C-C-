#include "db_passper.h"

std::string db_passPer::getSql(std::vector<std::string> *pWhereVector,std::string table)
{
    std::string sql = "select ";
    for (unsigned int i = 0; i< memberVector.size(); i++) {
        sql += " " + memberVector[i].dbtype + ",";
    }
    sql.pop_back();
    sql += " from ";
    sql += " (";
    sql += " select  category, count(*) as allcount from check_infos  ";
    sql += " where 1=1  ";
    for (unsigned int i = 1; i< pWhereVector->size(); i++) {
        sql += " " + (*pWhereVector)[i];
    }
    sql += " and result in (1,5)  ";
    sql += " group by category  ";
    sql += ") as a";
    sql += " left join ";
    sql += " (";
    sql += " select  category, reason, count(*) as passcount ";
    sql += " from check_infos ";
    sql += " where 1=1 ";
    for (unsigned int i = 0; i< pWhereVector->size(); i++) {
        sql += " " + (*pWhereVector)[i];
    }
    sql += " group by category,reason ";
    sql += ") as b";
    sql += " on a.category = b.category ";
    sql += " order by b.category,b.passcount ";
    return sql;
}
