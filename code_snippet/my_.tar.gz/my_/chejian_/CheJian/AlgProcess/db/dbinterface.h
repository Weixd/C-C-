#ifndef DBINTERFACE_H
#define DBINTERFACE_H
#include "AlgProcess/base/baseinc.h"

Json::Value getPhotoInfoOrderJson();
Json::Value getPhotoInfoVectorJson(std::string vehicleId);

Json::Value getVehicleInfoOrderJson();
Json::Value getVehicleInfoVectorJson(std::string chePai,std::string startTime,std::string endTime);

Json::Value getPassListInfoOrderJson();
Json::Value getPassListInfoVectorJson(std::vector<std::string> zplxVector,std::string startTime,std::string endTime);

Json::Value getPassInfoOrderJson();
Json::Value getPassInfoVectorJson(std::string zplx,std::string startTime,std::string endTime);
Json::Value getPhotoInfoVectorJsonByReason(std::string category,std::string reason,std::string startTime,std::string endTime);


#endif // DBINTERFACE_H
