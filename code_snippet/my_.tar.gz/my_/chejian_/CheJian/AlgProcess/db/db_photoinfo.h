#ifndef DB_PHOTOINFO_H
#define DB_PHOTOINFO_H
#include "dbbaseclass.h"

class db_photoInfo:public dbBaseClass{
public:

    std::string category;
    std::string name;
    std::string date;
    std::string result;
    std::string reason;
    std::string createdTime;

    dbBaseClass *getDbClass(){
        return new db_photoInfo();
    }

    db_photoInfo(){
        memberVector.push_back({"category", "category","照片类型", &category,true});
        memberVector.push_back({"name", "substring(name,39) as name","图片名称", &name,true});
        memberVector.push_back({"result", "result","结果", &result,true});
        memberVector.push_back({"reason", "reason","说明", &reason,true});
        memberVector.push_back({"date", "substring(name,28,10) as date","日期", &date,true});
        memberVector.push_back({"createdTime", "created_at","分析时间", &createdTime,true});
    }
};

#endif // DB_PHOTOINFO_H
