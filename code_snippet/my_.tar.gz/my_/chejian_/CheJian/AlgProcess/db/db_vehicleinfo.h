#ifndef DB_VEHICLEINFO_H
#define DB_VEHICLEINFO_H
#include "dbbaseclass.h"

class db_vehicleInfo:public dbBaseClass{
public:

    std::string id;
    std::string hphm;
    std::string syr;
    std::string cllx;
    std::string syxz;
    std::string is_pass;
    std::string clsbdh;
    std::string deviceid;
    std::string created_at;

    dbBaseClass *getDbClass(){
        return new db_vehicleInfo();
    }

    db_vehicleInfo(){
        memberVector.push_back({"id", "id","ID", &id,true});
        memberVector.push_back({"chepai", "CONCAT(left(fzjg,1),hphm) as chepai","车牌号", &hphm,true});
        memberVector.push_back({"syr", "syr","所有人", &syr,true});
        memberVector.push_back({"clsbdh", "clsbdh","车架号", &clsbdh,true});
        memberVector.push_back({"cllx", "cllx","车辆类型", &cllx,true});
        memberVector.push_back({"syxz", "syxz","使用性质", &syxz,true});
        memberVector.push_back({"is_pass", "is_pass","是否通过", &is_pass,true});
        memberVector.push_back({"device_id", "device_id","运行机器", &deviceid,true});
        memberVector.push_back({"created_at", "created_at","分析时间", &created_at,true});
    }
};


#endif // DB_VEHICLEINFO_H
