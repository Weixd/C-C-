#include "dbinterface.h"
#include "Application/MySQL_DB.h"
#include "AlgProcess/base/json/json.h"
#include "AlgProcess/db/db_photoinfo.h"
#include "AlgProcess/db/db_vehicleinfo.h"
#include "AlgProcess/db/db_passper.h"

Json::Value getPhotoInfoVectorJson(std::string vehicleId)
{
    db_photoInfo dbPhotoInfo;
    vector<std::string> WhereVector;

    WhereVector.push_back("and vehicle_check_id ='"+vehicleId+"'");

    dbPhotoInfo.query("check_infos", &WhereVector, NULL, 3306, "root", getDBPassWord(DBPWD).c_str(), "car_schema");

    return dbPhotoInfo.getVectorJson();
}

Json::Value getPhotoInfoOrderJson()
{
    db_photoInfo dbPhotoInfo;

    return dbPhotoInfo.getOrderJson();
}

Json::Value getVehicleInfoVectorJson(std::string chePai,std::string startTime,std::string endTime)
{
    db_vehicleInfo dbVehicleInfo;
    vector<std::string> WhereVector;

    WhereVector.push_back("and created_at > '"+startTime+"'");
    WhereVector.push_back("and created_at < '"+endTime+"'");
    WhereVector.push_back("order by created_at desc");
    WhereVector.push_back("limit 0,1000");

    dbVehicleInfo.query("vehicle_checks", &WhereVector, NULL, 3306, "root", getDBPassWord(DBPWD).c_str(), "car_schema");

    return dbVehicleInfo.getVectorJson();
}

Json::Value getVehicleInfoOrderJson()
{
    db_vehicleInfo dbVehicleInfo;

    return dbVehicleInfo.getOrderJson();
}

Json::Value getPassListInfoOrderJson()
{
    db_passPer db;
    return db.getOrderJson();
}

Json::Value getPassListInfoVectorJson(std::vector<std::string> zplxVector,std::string startTime,std::string endTime)
{
    db_passPer db;
    vector<std::string> WhereVector;

    std::string categoryStr = "";

    for (unsigned int i = 0; i < zplxVector.size(); i++) {
        categoryStr += "'"+zplxVector[i]+"',";
    }
    categoryStr.pop_back();

    WhereVector.push_back("and result in (1)");
    WhereVector.push_back("and category in ("+categoryStr+")");
    WhereVector.push_back("and created_at > '"+startTime+"'");
    WhereVector.push_back("and created_at < '"+endTime+"'");

    db.query("", &WhereVector, NULL, 3306, "root", getDBPassWord(DBPWD).c_str(), "car_schema");

    return db.getVectorJson();
}

Json::Value getPassInfoOrderJson()
{
    db_passPer db;
    return db.getOrderJson();
}

Json::Value getPassInfoVectorJson(std::string zplx,std::string startTime,std::string endTime)
{
    db_passPer db;
    vector<std::string> WhereVector;

    WhereVector.push_back("and result in (1,5)");
    WhereVector.push_back("and category in ('"+zplx+"')");
    WhereVector.push_back("and created_at > '"+startTime+"'");
    WhereVector.push_back("and created_at < '"+endTime+"'");


    db.query("", &WhereVector, NULL, 3306, "root", getDBPassWord(DBPWD).c_str(), "car_schema");

    return db.getVectorJson();
}

Json::Value getPhotoInfoVectorJsonByReason(std::string category,std::string reason,std::string startTime,std::string endTime)
{
    db_photoInfo dbPhotoInfo;
    vector<std::string> WhereVector;
    WhereVector.push_back("and category = '"+category+"'");
    WhereVector.push_back("and reason = '"+reason+"'");
    WhereVector.push_back("and created_at > '"+startTime+"'");
    WhereVector.push_back("and created_at < '"+endTime+"'");
    WhereVector.push_back("order by created_at desc");

    dbPhotoInfo.query("check_infos", &WhereVector, NULL, 3306, "root", getDBPassWord(DBPWD).c_str(), "car_schema");

    return dbPhotoInfo.getVectorJson();
}


