#ifndef YULIN_PROCESSCLASS_H
#define YULIN_PROCESSCLASS_H

#include "AlgProcess/base/algbaseclass.h"
#include "AlgProcess/base/processbaseclass.h"


class yuLin_PicProcessClass:public processBaseClass
{
    public:
    void changeAlgVector();
    algBaseClass *subClassLoadAlgBaseClassByPicType(CityType cityType, std::string algName, PicType type);
};


#endif // YULIN_PROCESSCLASS_H
