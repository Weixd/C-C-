#ifndef DONGGUAN_PROCESSCLASS_H
#define DONGGUAN_PROCESSCLASS_H

#include "AlgProcess/base/algbaseclass.h"
#include "AlgProcess/base/processbaseclass.h"


class dongGuan_PicProcessClass:public processBaseClass
{
    public:
    void changeAlgVector();
    algBaseClass *subClassLoadAlgBaseClassByPicType(CityType cityType, std::string algName, PicType type);
};

#endif // DONGGUAN_PROCESSCLASS_H
