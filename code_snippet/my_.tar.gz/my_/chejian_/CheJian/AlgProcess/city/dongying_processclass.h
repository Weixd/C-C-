#ifndef DONGYING_PROCESSCLASS_H
#define DONGYING_PROCESSCLASS_H

#include "AlgProcess/base/algbaseclass.h"
#include "AlgProcess/base/processbaseclass.h"


class dongYing_PicProcessClass:public processBaseClass
{
    public:
    algBaseClass *subClassLoadAlgBaseClassByPicType(CityType cityType, std::string algName, PicType type);
    void changeAlgVector();
};


#endif // DONGYING_PROCESSCLASS_H
