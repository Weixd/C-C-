#include "demo_processclass.h"
#include "AlgProcess/base/basetool.h"

#if DEMO_XINZENGQUANXINSUANFACHULILEIXING


ALGFUNC_RETURN _c_3333_DemoAddNewAlgProcess::Dispose(ALGFUNC_TP)
{
    ALG_P_UNUSED

    printf("_c_3333_DemoAddNewAlgProcess::Dispose 实现算法处理\n");

    return true;
}

ALGFUNC_RETURN _c_3333_DemoAddNewAlgProcess::AlgResult(ALGFUNC_TP)
{
    ALG_P_UNUSED

    printf("_c_3333_DemoAddNewAlgProcess::AlgResult 实现算法结果逻辑处理\n");

    return true;
}

algBaseClass *demo_PicProcessClass::subClassLoadAlgBaseClassByPicType(CityType cityType, std::string algName, PicType type)
{
    printf("demo_PicProcessClass::subClassLoadAlgBaseClassByPicType 该函数类创建并返回algBaseClass的派生类实体 \n");
    int _type = (int)type;
    switch (_type) {
        case 3333:
        {
            _c_3333_DemoAddNewAlgProcess *pReturn = new _c_3333_DemoAddNewAlgProcess();
            //algBaseClass类的参数输入vector指针指向派生类中
            pReturn->pInMemberList = &pReturn->inMemberList;
            //algBaseClass类的结果输出vector指针指向派生类中
            pReturn->pResultMemberList = &pReturn->resultMemberList;
            return pReturn;
        }
        break;
        default:
        {
            //默认返回(固定 不可返回NULL，如有递归继承关系可模仿父类实现方式)
            return new algBaseClass();
        }
        break;
    }
    return NULL;
}

void demo_PicProcessClass::changeAlgVector()
{
    printf("demo_PicProcessClass::changeAlgVector 该函数类将新算法的algItem 插入到基类的__algVector中 \n");
    addAlgVectorMember("3333", true, "Demo测试新增城市独有算法",PicType(3333), true);
}

int loadPhoto(std::vector<PhotoItem> *pPhotoList)
{
    PhotoItem photoItem3;
    photoItem3.zpType = "3333";
    photoItem3.zpId = "3333id";
    photoItem3.localPath = "photo/0113_E100Z5_LFMBEK4B9A0020375";
    pPhotoList->push_back(photoItem3);

    return 1;
}
#endif


#if DEMO_JICHENGCUNZAISUANFAPAISHENGLEI

ALGFUNC_RETURN _c_0111_DemoAlgProcess::BeforDispose(ALGFUNC_TP)
{
    chePaiHao.inData = "测试一下算法处理前修改传入参数，一般用来修改数据格式，如日期格式，名称和类型码转换等";
    shuiYinRiQi.inData ="11111";
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0111_DemoAlgProcess::AfterDispose(ALGFUNC_TP)
{
    ALG_P_UNUSED

    //动态输出演示(输出名根据参数不同而改变)
    baseTool::changeCheckAlgBaseParamElementByName(pHandle, "chePaiHao", ("号牌号码不正确:"+chePaiHao.inData), true);

    //将清晰度检测项检测 打开，错误打印修改为 "照片看不清啊"
    baseTool::changeCheckAlgBaseParamElementByName(pHandle, "zongZhiLiang", "照片看不清啊", true);

    //将三脚架检测项检测 关闭
    baseTool::changeCheckAlgBaseParamElementByName(pHandle, "sanJiaoJia", "", false);

    //返回值为true时 按父类流程继续运行,否则父类流程终止需自己实现后续流程，pPhotoItem->jg 不能为空 否则会默认填充NOT_PASS 且 pPhotoItem->sm填充为建议人工
    return true;
}

algBaseClass *demo_PicProcessClass::subClassLoadAlgBaseClassByPicType(CityType cityType, std::string algName, PicType type)
{
    printf("demo_PicProcessClass::subClassLoadAlgBaseClassByPicType 该函数类创建并返回algBaseClass的派生类实体 \n");
    switch (type) {
        case e0111:
        {
            _c_0111_DemoAlgProcess *pReturn = new _c_0111_DemoAlgProcess();
            //algBaseClass类的参数输入vector指针指向派生类中
            pReturn->pInMemberList = &pReturn->inMemberList;
            //algBaseClass类的结果输出vector指针指向派生类中
            pReturn->pResultMemberList = &pReturn->resultMemberList;
            return pReturn;
        }
        break;
        default:
        {
            //默认返回(固定 不可返回NULL，如有递归继承关系可模仿父类实现方式)
            return new algBaseClass();
        }
        break;
    }
    return NULL;
}

void demo_PicProcessClass::changeAlgVector()
{
   //将 e0111 算法 subAlgClass 设置为true 让基类执行subClassLoadAlgBaseClassByPicType来使用algClass 派生类
   changeAlgVectorByType(e0111, "", "",true, true, true);
}


int loadPhoto(std::vector<PhotoItem> *pPhotoList)
{
    PhotoItem photoItem;
    photoItem.zpType = "0111";
    photoItem.zpId = "0111id";
    photoItem.localPath = "photo/0111_E100Z5_LFMBEK4B9A0020375";
    pPhotoList->push_back(photoItem);

    PhotoItem photoItem0;
    photoItem0.zpType = "A";
    photoItem0.zpId = "Aid";
    photoItem0.localPath = "photo/0111_E100Z5_LFMBEK4B9A0020375";
    pPhotoList->push_back(photoItem0);

    return 1;
}

#endif


