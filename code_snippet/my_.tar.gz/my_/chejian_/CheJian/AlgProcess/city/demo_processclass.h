#ifndef DEMO_PROCESSCLASS_H
#define DEMO_PROCESSCLASS_H
#include "AlgProcess/base/algbaseclass.h"
#include "AlgProcess/base/processbaseclass.h"
#include "AlgProcess/alg/_c_0111_algclass.h"

//编译使用
#define DEMO_NULL !(DEMO_XINZENGQUANXINSUANFACHULILEIXING||DEMO_JICHENGCUNZAISUANFAPAISHENGLEI)

#define DEMO_XINZENGQUANXINSUANFACHULILEIXING 0         //新增一个全新的算法处理类型
#define DEMO_JICHENGCUNZAISUANFAPAISHENGLEI 0           //当已有算法处理无法满足当前业务需要情况


#if DEMO_NULL
class demo_PicProcessClass:public processBaseClass
{
    public:
};
#endif


#if DEMO_XINZENGQUANXINSUANFACHULILEIXING

//定义一个参数类,必须继承 algBaseClass
class _c_3333_DemoAddNewAlgProcess:public algBaseClass{
public:
    ALG_PARM_MEMBER hphm;
    //定义一个参数输入vector
    std::vector<memberItem> inMemberList = {
        {"hphm", "号牌号码", &hphm, true, CONFIG_DEFAULT},
    };
    //定义一个结果输出vector
    std::vector<memberItem> resultMemberList = {
        {"hphm", "车牌号不正确", &hphm, true, CONFIG_DEFAULT},
    };

    //继承基类中算法处理接口
    virtual ALGFUNC_RETURN Dispose(ALGFUNC_TP);
    //继承基类中算法结果逻辑处理接口
    virtual ALGFUNC_RETURN AlgResult(ALGFUNC_TP);
};

//类实现
class demo_PicProcessClass:public processBaseClass
{
    public:
        //重写父类改变AlgVector虚函数（该接口父类实现为空）
        void changeAlgVector();

        //重写父类当遇到未知PicType时调用的虚函数或当subAlgClass值为true时执行
        //返回值不可为NULL,默认返回 new algBaseClass()
        algBaseClass *subClassLoadAlgBaseClassByPicType(CityType cityType, std::string algName, PicType type);
};
#endif


#if DEMO_JICHENGCUNZAISUANFAPAISHENGLEI
//定义一个算法类,必须继承algBaseClass或其派生类，如果需要更换算法接口，则需要重写Dispose接口，以及AlgResult接口
class _c_0111_DemoAlgProcess:public _c_0111_AlgClass{
public:
        //重写算法运算处理前虚函数
        ALGFUNC_RETURN BeforDispose(ALGFUNC_TP);
        //重写算法运算处理后虚函数
        ALGFUNC_RETURN AfterDispose(ALGFUNC_TP);
};

//城市派生类类实现
class demo_PicProcessClass:public processBaseClass
{
    public:
        //重写父类改变AlgVector虚函数（该接口父类实现为空）
        void changeAlgVector();

        //重写父类当遇到未知PicType时调用的虚函数或当subAlgClass值为true时执行
        //返回值不可为NULL,默认返回 new algBaseClass()
        algBaseClass *subClassLoadAlgBaseClassByPicType(CityType cityType, std::string algName, PicType type);
};

#endif


#endif // DEMO_PROCESSCLASS_H
