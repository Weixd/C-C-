#ifndef YINGTAN_PROCESSCLASS_H
#define YINGTAN_PROCESSCLASS_H

#include "AlgProcess/base/algbaseclass.h"
#include "AlgProcess/base/processbaseclass.h"


class YingTan_PicProcessClass:public processBaseClass
{
    public:
    void changeAlgVector();
    algBaseClass *subClassLoadAlgBaseClassByPicType(CityType cityType, std::string algName, PicType type);
};


#endif // YINGTAN_PROCESSCLASS_H
