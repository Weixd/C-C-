#ifndef JIAXING_PROCESSCLASS_H
#define JIAXING_PROCESSCLASS_H
#include "AlgProcess/base/algbaseclass.h"
#include "AlgProcess/base/processbaseclass.h"


class jiaXing_PicProcessClass:public processBaseClass
{
    public:
    void changeAlgVector();
    algBaseClass *subClassLoadAlgBaseClassByPicType(CityType cityType, std::string algName, PicType type);
};


#endif // JIAXING_PROCESSCLASS_H
