#include "dongguan_processclass.h"
#include "dongguan/_c_0287_algclass_dongguan.h"
#include "dongguan/_c_0288_algclass_dongguan.h"

algBaseClass *dongGuan_PicProcessClass::subClassLoadAlgBaseClassByPicType(CityType cityType, std::string algName, PicType type)
{
    //printf("algBaseClass *dongGuan_PicProcessClass::subClassLoadAlgBaseClassByPicType(PicType type)\n");
    algBaseClass *pReturn;
    switch (type) {
        case e0287:
        {
            pReturn = new _c_0287_AlgClass_dongGuan();
        }
        break;
        case e0288:
        {
            pReturn = new _c_0288_AlgClass_dongGuan();
        }
        break;
        default:
        {
            //默认返回(固定 不可返回NULL，如有递归继承关系可模仿父类实现方式)
            return new algBaseClass();
        }
        break;
    }
    pReturn->setBaseParam(cityType, type, algName);
    pReturn->initAlgClass();
    return pReturn;
}

void dongGuan_PicProcessClass::changeAlgVector()
{
    printf("void dongGuan_PicProcessClass::changeAlgVector()\n");
    algItem item = {"0287", true, "行驶证(正面)-照片", e0287, true, false, true, 0, 0,0,0,0,NULL,NULL};
    changeAlgVectorByType(&item);

    algItem item2 = {"0288", true, "行驶证(背面)-照片", e0288, true, false, true, 0, 0,0,0,0,NULL,NULL};
    changeAlgVectorByType(&item2);
}

