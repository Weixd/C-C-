#include "_c_0203_algclass_jiaxing.h"
#include "AlgProcess/base/processbaseclass.h"

ALGFUNC_RETURN _c_0203_AlgClass_jiaXing::BeforDispose(ALGFUNC_TP)
{
    pAlgApi->jianYanJieShuShiJian.inData = baseTool::getDangTianRiQi();
    ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0203_AlgClass_jiaXing::AfterAlgResult(ALGFUNC_TP)
{
    if(pAlgApi->zhengBenHuoFuBen.result && pAlgApi->baoXianYouXiaoQi.result && pAlgApi->cheJiaHao.result && pAlgApi->cheChuanShui.result && pAlgApi->yinZhang.result)
    {
        memberItem item;
        item.name = "renGongShenHe";           //对应字段名称
        item.desc = "交强险信息已通过识别比对，请审核人员判定真伪";           //描述
        item.value = &renGongShenHe;;     //值地址
        item.output = true;                //是否输出
        item.config.isOpen = false;     //参数配置
        item.config.descOpen = false;     //参数配置
        item.config.errLevel = NOT_PASS;     //参数配置
        //将item添加到结果输出集合中
        addNewResultMember(&item);
        renGongShenHe.result=false;
    }
     ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0203_AlgClass_jiaXing::NeedWriteResult(ALGFUNC_TP)
{
    printf("ALGFUNC_RETURN _c_0203_AlgClass_jiaXing::NeedWriteResult(ALGFUNC_TP)\n");
//    std::string algName = pProcessClass->getAlgItemNameByPicType(e0203);
//    baseTool::wirteResultByMemberList(algName,&(*pPhotoList)[index], pResultMemberList);

    if((*pPhotoList)[index].jg == std::to_string(PASS))
    {
        baseTool::writeResultByJGAndSM(&(*pPhotoList)[index],NOT_PASS, "[交强险信息已通过识别比对，请审核人员判定真伪]");
    }

    ALG_P_UNUSED  return true;
}
