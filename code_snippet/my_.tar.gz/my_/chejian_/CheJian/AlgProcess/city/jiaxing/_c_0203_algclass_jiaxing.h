#ifndef _C_0203_ALGCLASS_JIAXING_H
#define _C_0203_ALGCLASS_JIAXING_H

#include "AlgProcess/alg/_c_0203_algclass.h"

class _c_0203_AlgClass_jiaXing:public _c_0203_AlgClass{
public:
    virtual ~_c_0203_AlgClass_jiaXing(){}
    ALG_PARM_MEMBER renGongShenHe = ALG_PARAM_DEFAULT;
    virtual ALGFUNC_RETURN BeforDispose(ALGFUNC_TP);
    virtual ALGFUNC_RETURN AfterAlgResult(ALGFUNC_TP);
    virtual ALGFUNC_RETURN NeedWriteResult(ALGFUNC_TP);
};


#endif // _C_0203_ALGCLASS_JIAXING_H
