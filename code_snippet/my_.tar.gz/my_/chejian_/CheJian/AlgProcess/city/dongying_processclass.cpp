#include "dongying_processclass.h"
#include "dongguan/_c_0351_algclass_dongying.h"
#include "dongguan/_c_0322_algclass_dongying.h"
#include "dongguan/_c_0348_algclass_dongying.h"
algBaseClass *dongYing_PicProcessClass::subClassLoadAlgBaseClassByPicType(CityType cityType, std::string algName, PicType type)
{
    algBaseClass *pReturn;
    switch (type) {
    case e0351:
    {
        pReturn = new _c_0351_AlgClass_dongying();
    }
        break;
    case e0322:
    {
        pReturn = new _c_0322_AlgClass_dongying();
    }
        break;
    case e0348:
    {
        pReturn = new _c_0322_AlgClass_dongying();
    }
        break;
    default:
    {
        //默认返回(固定 不可返回NULL，如有递归继承关系可模仿父类实现方式)
        return new algBaseClass();
    }
        break;
    }
    pReturn->setBaseParam(cityType, type, algName);
    pReturn->initAlgClass();
    return pReturn;
}


void dongYing_PicProcessClass::changeAlgVector()
{
    printf("void dongYing_PicProcessClass::changeAlgVector()\n");
    algItem item0351 ={"0351", true, "驻车制动工位-照片", e0351, false, true, true, 0, 0, 0, 0, 0, NULL, NULL};
    changeAlgVectorByType(&item0351);
    algItem item0322={"0322", true, "一轴制动(滚筒)-照片", e0322, false, true, true, 0, 0, 0, 0, 0, NULL, NULL};
    changeAlgVectorByType(&item0322);
    algItem item0348={"0348", true, "二轴制动(滚筒)-照片", e0348, false, true, true, 0, 0, 0, 0, 0, NULL, NULL};
    changeAlgVectorByType(&item0348);

}


