#include "yulin_processclass.h"

algBaseClass *yuLin_PicProcessClass::subClassLoadAlgBaseClassByPicType(CityType cityType, std::string algName, PicType type)
{
    algBaseClass *pReturn;
    switch (type) {
        default:
        {
            //默认返回(固定 不可返回NULL，如有递归继承关系可模仿父类实现方式)
            return new algBaseClass();
        }
        break;
    }
    pReturn->setBaseParam(cityType, type, algName);
    pReturn->initAlgClass();
    return pReturn;
}

void yuLin_PicProcessClass::changeAlgVector()
{

}

