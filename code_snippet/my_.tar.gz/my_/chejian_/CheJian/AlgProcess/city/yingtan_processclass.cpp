#include "yingtan_processclass.h"
#include "dongguan/_c_0205_algclass_yingtan.h"
#include "dongguan/_c_0321_yingtan.h"
#include "dongguan/_c_0344_algclass_yingtan.h"
#include "AlgProcess/alg/_c_0209_algclass.h"
algBaseClass *YingTan_PicProcessClass::subClassLoadAlgBaseClassByPicType(CityType cityType, std::string algName, PicType type)
{
    algBaseClass *pReturn;
    switch (type) {
        case e0205:
        {
            pReturn = new _c_0205_AlgClass_yingtan();
        }
            break;
    case e0344:
    {
       pReturn = new _c_0344_AlgClass_yingtan();
    }
   break;
    case e0342:
    {
       pReturn = new _c_0344_AlgClass_yingtan();
    }
   break;
    case e0321:
    {
       pReturn = new _c_0321_YingTan();
    }
   break;
    case e0352:
    {
       pReturn = new _c_0321_YingTan();
    }
    break;
        default:
        {
            //默认返回(固定 不可返回NULL，如有递归继承关系可模仿父类实现方式)
            return new algBaseClass();
        }
        break;
    }
    pReturn->setBaseParam(cityType, type, algName);
    pReturn->initAlgClass();
    return pReturn;
}

void YingTan_PicProcessClass::changeAlgVector()
{
    algItem item0205 = {"0205", true, "", e0205, true, false, true, 0, 0,0,0,0,NULL,NULL};
    algItem item0342 = {"0342", true, "", e0342, true, false, true, 0, 0,0,0,0,NULL,NULL};
    algItem item0344 = {"0344", true, "", e0344, true, false, true, 0, 0,0,0,0,NULL,NULL};
    algItem item0321 = {"0321", true, "", e0321, true, false, false, 0, 0,0,0,0,NULL,NULL};
    algItem item0352 = {"0352", true, "", e0352, true, false, false, 0, 0,0,0,0,NULL,NULL};
    changeAlgVectorByType(&item0205);
    changeAlgVectorByType(&item0342);
    changeAlgVectorByType(&item0344);
    changeAlgVectorByType(&item0321);
    changeAlgVectorByType(&item0352);
}

