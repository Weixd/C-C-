#include "jiaxing_processclass.h"
#include "jiaxing/_c_0203_algclass_jiaxing.h"
//#include "dongguan/_c_0212_algclass_jiaxing.h"
algBaseClass *jiaXing_PicProcessClass::subClassLoadAlgBaseClassByPicType(CityType cityType, std::string algName, PicType type)
{

    algBaseClass *pReturn;
    switch (type) {
    case e0203:
    {
        pReturn = new _c_0203_AlgClass_jiaXing();
    }
        break;
//    case e0212:
//    {
//        pReturn = new _c_0212_AlgClass_jiaXing();
//    }
        break;
    default:
    {
        //默认返回(固定 不可返回NULL，如有递归继承关系可模仿父类实现方式)
        return new algBaseClass();
    }
        break;
    }
    pReturn->setBaseParam(cityType, type, algName);
    pReturn->initAlgClass();
    return pReturn;
}

void jiaXing_PicProcessClass::changeAlgVector()
{
    printf("void jiaXing_PicProcessClass::changeAlgVector()\n");
    algItem item = {"0203", true, "", e0203, true, false, true, 0, 0,0,0,0,NULL,NULL};
    changeAlgVectorByType(&item);
//    algItem item0209 ={"0212", false, "尾气检测报告-照片", e0212, false, false, true, 0, 0, 0, 0, 0, NULL, NULL};
//    changeAlgVectorByType(&item0209);
}

