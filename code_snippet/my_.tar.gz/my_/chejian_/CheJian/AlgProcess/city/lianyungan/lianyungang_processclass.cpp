#include "lianyungang_processclass.h"
//#include "jiaxing/_c_0203_algclass_jiaxing.h"
//#include "dongguan/_c_0212_algclass_jiaxing.h"
algBaseClass *LianYunGang_PicProcessClass::subClassLoadAlgBaseClassByPicType(CityType cityType, std::string algName, PicType type)
{

    algBaseClass *pReturn;
    switch (type) {
    case e0114:
    {
        pReturn = new _c_0114_AlgClass_lianyungang();
    }
        break;
//    case e0212:
//    {
//        pReturn = new _c_0212_AlgClass_jiaXing();
//    }
        break;
    default:
    {
        //默认返回(固定 不可返回NULL，如有递归继承关系可模仿父类实现方式)
        return new algBaseClass();
    }
        break;
    }
    pReturn->setBaseParam(cityType, type, algName);
    pReturn->initAlgClass();
    return pReturn;
}

void LianYunGang_PicProcessClass::changeAlgVector()
{
    algItem item = {"0114", true, "", e0114, true, false, true, 0, 0,0,0,0,NULL,NULL};
    changeAlgVectorByType(&item);
}

