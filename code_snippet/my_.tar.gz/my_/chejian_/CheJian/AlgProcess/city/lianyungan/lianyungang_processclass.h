#ifndef LIANYUNGANG_PROCESSCLASS_H
#define LIANYUNGANG_PROCESSCLASS_H
#include "AlgProcess/base/algbaseclass.h"
#include "AlgProcess/base/processbaseclass.h"


class LianYunGang_PicProcessClass:public processBaseClass
{
    public:
    void changeAlgVector();
    algBaseClass *subClassLoadAlgBaseClassByPicType(CityType cityType, std::string algName, PicType type);
};


#endif // LIANYUNGANG_PROCESSCLASS_H
