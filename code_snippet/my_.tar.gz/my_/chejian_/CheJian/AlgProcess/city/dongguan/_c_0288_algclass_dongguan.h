#ifndef _C_0288_ALGCLASS_DONGGUAN_H
#define _C_0288_ALGCLASS_DONGGUAN_H

#include "AlgProcess/alg/_c_0288_algclass.h"
#include "AlgProcess/alg/algapi/_c_0216_algapi.h"

class _c_0288_AlgClass_dongGuan:public _c_0288_AlgClass{
public:
    _c_0216_AlgApi *pAlgapi_0216;

    virtual ~_c_0288_AlgClass_dongGuan();
    bool subClassLoadNewResultMember();
    virtual ALGFUNC_RETURN AfterDispose(ALGFUNC_TP);
};

#endif // _C_0288_ALGCLASS_DONGGUAN_H
