#include "_c_0205_algclass_yingtan.h"

_c_0205_AlgClass_yingtan::~_c_0205_AlgClass_yingtan(){

    if(pAlgchejia != nullptr)
    {
        delete pAlgchejia;

        pAlgchejia =nullptr;
    }
}

 bool _c_0205_AlgClass_yingtan::subClassLoadNewResultMember()
 {
     pAlgchejia = new _c_0113_AlgApi();
     memberItem item;
     item.name = "cheJiaHao";           //对应字段名称
     item.desc = "车架号拓印膜不正确";           //描述
     item.value = &pAlgchejia->cheJiaHao;     //值地址
     item.output = true;                //是否输出
     item.config.isOpen = true;     //参数配置
     item.config.descOpen = true;     //参数配置
     item.config.errLevel = NOT_PASS;     //参数配置
     pAlgchejia->cheJiaHao.result = false;
     //将item添加到结果输出集合中
     addNewResultMember(&item);
     inListVector.push_back({"cheJiaHao",&pAlgchejia->inMemberList});
     return true;
 }
ALGFUNC_RETURN _c_0205_AlgClass_yingtan::AfterDispose(ALGFUNC_TP)
{
    //加载主子图片
    pAlgchejia->loadPhotoMain((*pPhotoList)[index].localPath);
    pAlgchejia->loadPhotoSub((*pPhotoList)[index].localPath);
    pAlgchejia->Dispose(alg,3);
    ALG_P_UNUSED return true;
}
