#include "_c_0287_algclass_dongguan.h"

_c_0287_AlgClass_dongGuan::~_c_0287_AlgClass_dongGuan(){
    if(pAlgapi_0216 != NULL)
    {
        delete pAlgapi_0216;

        pAlgapi_0216 =NULL;
    }
}

 bool _c_0287_AlgClass_dongGuan::subClassLoadNewResultMember()
 {
     pAlgapi_0216 = new _c_0216_AlgApi();

     memberItem item;
     item.name = "jianYanCishu";           //对应字段名称
     item.desc = "异常送检人，当日已超过10次";           //描述
     item.value = &jianYanCishu;     //值地址
     item.output = true;                //是否输出
     item.config.isOpen = true;     //参数配置
     item.config.descOpen = true;     //参数配置
     item.config.errLevel = NOT_PASS;     //参数配置
     jianYanCishu.result = true;

     //将item添加到结果输出集合中
     addNewResultMember(&item);


     memberItem item2;
     item2.name = "shenFenZheng";           //对应字段名称
     item2.desc = "未识别到身份证";           //描述
     item2.value = &pAlgapi_0216->shenFenZhengZhengMian;     //值地址
     item2.output = true;                //是否输出
     item2.config.isOpen = true;     //参数配置
     item2.config.descOpen = false;     //参数配置
     item2.config.errLevel = NOT_PASS;     //参数配置

     //将item添加到结果输出集合中
     addNewResultMember(&item2);

     //将0216算法需要输入集合增加到参数获取vector中
     inListVector.push_back({"shenFenZheng",&pAlgapi_0216->inMemberList});


     return true;
 }

ALGFUNC_RETURN _c_0287_AlgClass_dongGuan::BeforDispose(ALGFUNC_TP)
{
    pAlgapi_0216->loadPhotoMain((*pPhotoList)[index].localPath);
    pAlgapi_0216->Dispose(alg);

    //printf("\033[1m\033[45;33m 0287 shenfenzheng %d %s \033[0m\n",pAlgapi_0216->shenFenZhengZhengMian.result
    //                                                            ,  pAlgapi_0216->shenFenZhengHao.OutData.c_str()  );

    //判断时间是否过去一天
    if(atoi(baseTool::getDangTianRiQi().c_str())>data)
    {
        //情况送审人记录表
        checkCount.clear();
        //更新日期
        data = atoi(baseTool::getDangTianRiQi().c_str());
    }
    //获取送审人身份证号
    std::string shenFenZhengHao = pAlgapi_0216->shenFenZhengHao.OutData;

    //记录送审人信息
    CHECK_COUNT check_count;
    check_count.shenFenZhengHao = shenFenZhengHao;
    checkCount.push_back(check_count);

    //判断 送审次数 -- 后续需要依靠算法识别输出
    if(getCheckCountByShenFenZhengHao(shenFenZhengHao) > 10)
    {
        jianYanCishu.result = false;
        //只输出jianYanCishu结果信息
        baseTool::checkMemberItemAndSetAllUnOutput(pResultMemberList, baseTool::getMemberItemByName(pResultMemberList,"jianYanCishu"));
        return false;
    }

    ALG_P_UNUSED return true;
}

int _c_0287_AlgClass_dongGuan::getCheckCountByShenFenZhengHao(std::string shenFenZhengHao)
{
    int count = 0;
    for (unsigned int i =0; i < checkCount.size(); i++) {
        if(checkCount[i].shenFenZhengHao == shenFenZhengHao)
        {
            count++;
        }
    }
    return count;
}

