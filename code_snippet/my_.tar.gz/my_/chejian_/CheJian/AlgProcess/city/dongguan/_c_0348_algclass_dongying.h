#ifndef _C_0348_ALGCLASS_DONGYING_H
#define _C_0348_ALGCLASS_DONGYING_H
#include "AlgProcess/alg/_c_0348_algclass.h"
#include "AlgProcess/alg/algapi/_c_0321_algapi.h"
#include "AlgProcess/alg/algapi/_c_0352_algapi.h"
class _c_0348_AlgClass_dongying:public _c_0348_AlgClass{
public:
    _c_0321_AlgApi *pAlgLWeideng = nullptr;
    _c_0352_AlgApi *pAlgRWeideng = nullptr;
    ALG_PARM_MEMBER zhiDongDeng = ALG_PARAM_DEFAULT;

    virtual ~_c_0348_AlgClass_dongying();
    bool subClassLoadNewResultMember();
    virtual ALGFUNC_RETURN AfterDispose(ALGFUNC_TP);
};

#endif // _C_0348_ALGCLASS_DONGYING_H
