#include "_c_0322_algclass_dongying.h"

_c_0322_AlgClass_dongying::~_c_0322_AlgClass_dongying(){

    if(pAlgLWeideng != nullptr)
    {
        delete pAlgLWeideng;

        pAlgLWeideng =nullptr;
    }
    if(pAlgRWeideng != nullptr)
    {
        delete pAlgRWeideng;

        pAlgRWeideng =nullptr;
    }
}

 bool _c_0322_AlgClass_dongying::subClassLoadNewResultMember()
 {
     pAlgLWeideng = new _c_0321_AlgApi();
     pAlgRWeideng = new _c_0352_AlgApi();
     memberItem item;
     item.name = "zhiDongDeng";           //对应字段名称
     item.desc = "制动灯未亮";           //描述
     item.value = &zhiDongDeng;     //值地址
     item.output = true;                //是否输出
     item.config.isOpen = true;     //参数配置
     item.config.descOpen = true;     //参数配置
     item.config.errLevel = NOT_PASS;     //参数配置
     //将item添加到结果输出集合中
     addNewResultMember(&item);
//     inListVector.push_back({"zhiDongDeng",&pAlg->inMemberList});

     return true;
 }

ALGFUNC_RETURN _c_0322_AlgClass_dongying::AfterDispose(ALGFUNC_TP)
{
    pAlgLWeideng->loadPhotoMain((*pPhotoList)[index].localPath);
    pAlgLWeideng->loadPhotoSub((*pPhotoList)[index].localPath);
    pAlgRWeideng->loadPhotoMain((*pPhotoList)[index].localPath);
    pAlgRWeideng->loadPhotoSub((*pPhotoList)[index].localPath);
    pAlgLWeideng->shuiYinRiQi.inData = baseTool::formatingDate(pAlgLWeideng->shuiYinRiQi.inData);
    pAlgRWeideng->shuiYinRiQi.inData = baseTool::formatingDate(pAlgRWeideng->shuiYinRiQi.inData);
    //算法运算
    if(pAlgLWeideng)
        pAlgLWeideng->Dispose(alg);
    if(pAlgRWeideng)
        pAlgRWeideng->Dispose(alg);
    zhiDongDeng.result=pAlgLWeideng->zuoDeng1.result || pAlgLWeideng->zuoDeng2.result || pAlgRWeideng->youDeng1.result || pAlgRWeideng->youDeng1.result;

    ALG_P_UNUSED return true;
}
