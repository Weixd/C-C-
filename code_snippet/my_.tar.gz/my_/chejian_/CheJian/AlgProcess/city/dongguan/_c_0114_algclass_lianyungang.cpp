#include "_c_0114_algclass_lianyungang.h"

_c_0114_AlgClass_yingtan::~_c_0114_AlgClass_yingtan(){

    if(pAlgchejia != nullptr)
    {
        delete pAlgchejia;

        pAlgchejia =nullptr;
    }
}

 bool _c_0114_AlgClass_yingtan::subClassLoadNewResultMember()
 {
     pAlgchejia = new _c_0113_AlgApi();
     memberItem item;
     item.name = "zhiDongDeng";           //对应字段名称
     item.desc = "制动灯亮起";           //描述
     item.value = &zhiDongDeng;     //值地址
     item.output = true;                //是否输出
     item.config.isOpen = true;     //参数配置
     item.config.descOpen = false;     //参数配置
     item.config.errLevel = NOT_PASS;     //参数配置
     zhiDongDeng.result = false;
     //将item添加到结果输出集合中
     addNewResultMember(&item);
//     //将0321算法需要输入集合增加到参数获取vector中
//     inListVector.push_back({"zhiDongDengL",&pAlgLWeideng->inMemberList});
//     inListVector.push_back({"zhiDongDengR",&pAlgRWeideng->inMemberList});
     return true;
 }

ALGFUNC_RETURN _c_0114_AlgClass_yingtan::AfterDispose(ALGFUNC_TP)
{
    //加载主子图片
    pAlgLWeideng->loadPhotoMain((*pPhotoList)[index].localPath);
    pAlgLWeideng->loadPhotoSub((*pPhotoList)[index].localPath);
    pAlgRWeideng->loadPhotoMain((*pPhotoList)[index].localPath);
    pAlgRWeideng->loadPhotoSub((*pPhotoList)[index].localPath);
    //格式化水印日期
    pAlgLWeideng->Dispose(alg);
    pAlgRWeideng->Dispose(alg);
    if(pAlgApi)
    {
        pAlgApi->zhiDongDeng.result=pAlgLWeideng->zuoDeng1.result || pAlgLWeideng->zuoDeng2.result || pAlgRWeideng->youDeng1.result || pAlgRWeideng->youDeng1.result;

    }
    ALG_P_UNUSED return true;
}
