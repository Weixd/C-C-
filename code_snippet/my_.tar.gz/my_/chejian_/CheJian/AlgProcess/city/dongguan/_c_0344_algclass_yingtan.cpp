#include "_c_0344_algclass_yingtan.h"

_c_0344_AlgClass_yingtan::~_c_0344_AlgClass_yingtan(){

}

ALGFUNC_RETURN _c_0344_AlgClass_yingtan::AfterDispose(ALGFUNC_TP)
{

    if(pAlgApi->chePaiHao.result || pAlgApi->chePaiHao2.result)
    {
        pAlgApi->chePaiHao.result;
    }
    ALG_P_UNUSED return true;
}
