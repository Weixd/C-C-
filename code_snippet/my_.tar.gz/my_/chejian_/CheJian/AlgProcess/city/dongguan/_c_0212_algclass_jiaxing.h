#ifndef _C_0212_ALGCLASS_JIAXING_H
#define _C_0212_ALGCLASS_JIAXING_H
#include "AlgProcess/alg/_c_0209_algclass.h"

class _c_0212_AlgClass_jiaXing:public _c_0209_AlgClass{
public:
    virtual ~_c_0212_AlgClass_jiaXing(){}
    virtual ALGFUNC_RETURN AfterAlgResult(ALGFUNC_TP);
    virtual ALGFUNC_RETURN NeedWriteResult(ALGFUNC_TP);
};


#endif // _C_0212_ALGCLASS_JIAXING_H
