#include "_c_0212_algclass_jiaxing.h"
#include "AlgProcess/base/processbaseclass.h"

ALGFUNC_RETURN _c_0212_AlgClass_jiaXing::AfterAlgResult(ALGFUNC_TP)
{

     ALG_P_UNUSED return true;
}

ALGFUNC_RETURN _c_0212_AlgClass_jiaXing::NeedWriteResult(ALGFUNC_TP)
{
    printf("ALGFUNC_RETURN _c_0203_AlgClass_jiaXing::NeedWriteResult(ALGFUNC_TP)\n");
//    std::string algName = pProcessClass->getAlgItemNameByPicType(e0203);
//    baseTool::wirteResultByMemberList(algName,&(*pPhotoList)[index], pResultMemberList);

//    if((*pPhotoList)[index].jg == std::to_string(PASS))
//    {
//        baseTool::writeResultByJGAndSM(&(*pPhotoList)[index],NOT_PASS, "[交强险信息已通过识别比对，请审核人员判定真伪]");
//    }

    ALG_P_UNUSED  return true;
}
