#ifndef _C_0344_ALGCLASS_YINGTAN
#define _C_0344_ALGCLASS_YINGTAN
#include "AlgProcess/alg/_c_0344_algclass.h"
#include "AlgProcess/alg/algapi/_c_0113_algapi.h"
class _c_0344_AlgClass_yingtan:public _c_0344_AlgClass{
public:
    virtual ~_c_0344_AlgClass_yingtan();
    virtual ALGFUNC_RETURN AfterDispose(ALGFUNC_TP);
};

#endif // _C_0344_ALGCLASS_YINGTAN
