#include "_c_0288_algclass_dongguan.h"

_c_0288_AlgClass_dongGuan::~_c_0288_AlgClass_dongGuan(){
    if(pAlgapi_0216 != NULL)
    {
        delete pAlgapi_0216;

        pAlgapi_0216 =NULL;
    }
}

 bool _c_0288_AlgClass_dongGuan::subClassLoadNewResultMember()
 {
     pAlgapi_0216 = new _c_0216_AlgApi();
     memberItem item;
     item.name = "shenFenZhengFanMian";           //对应字段名称
     item.desc = "未检测到身份证反面";           //描述
     item.value = &pAlgapi_0216->shenFenZhengFanMian;     //值地址
     item.output = true;                //是否输出
     item.config.isOpen = true;     //参数配置
     item.config.descOpen = true;     //参数配置
     item.config.errLevel = NOT_PASS;     //参数配置

     //将身份证背面item添加到结果输出集合中
     addNewResultMember(&item);

     //将0216算法需要输入集合增加到参数获取vector中
     inListVector.push_back({"shenFenZheng",&pAlgapi_0216->inMemberList});


     return true;
 }

ALGFUNC_RETURN _c_0288_AlgClass_dongGuan::AfterDispose(ALGFUNC_TP)
{
    //加载主照片
    pAlgapi_0216->loadPhotoMain((*pPhotoList)[index].localPath);
    //执行算法运算
    pAlgapi_0216->Dispose(alg);
    //盘算身份证是否有效，和是否有身份背面图片
    pAlgapi_0216->shenFenZhengFanMian.result = pAlgapi_0216->shenFenZhengFanMian.result && pAlgapi_0216->youXiaoRiQi.result;


    ALG_P_UNUSED return true;
}

