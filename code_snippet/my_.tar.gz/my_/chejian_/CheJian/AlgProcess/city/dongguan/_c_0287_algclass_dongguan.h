#ifndef _C_0203_ALGCLASS_DONGGUAN_H
#define _C_0203_ALGCLASS_DONGGUAN_H
#include "AlgProcess/alg/_c_0287_algclass.h"
#include "AlgProcess/alg/algapi/_c_0216_algapi.h"

typedef struct _CHECK_COUNT
{
    std::string shenFenZhengHao;   //姓名
}CHECK_COUNT,*PCHECK_COUNT;

class _c_0287_AlgClass_dongGuan:public _c_0287_AlgClass{
public:
    _c_0216_AlgApi *pAlgapi_0216;

    ALG_PARM_MEMBER jianYanCishu = ALG_PARAM_DEFAULT;

    std::vector<CHECK_COUNT> checkCount;
    int data = 0;

    virtual ~_c_0287_AlgClass_dongGuan();
    bool subClassLoadNewResultMember();
    virtual ALGFUNC_RETURN BeforDispose(ALGFUNC_TP);
    int getCheckCountByShenFenZhengHao(std::string shenFenZhengHao);
};

#endif // _C_0203_ALGCLASS_H
