#ifndef _C_0114_ALGCLASS_LIANYUNGANG
#define _C_0114_ALGCLASS_LIANYUNGANG
#include "AlgProcess/alg/_c_0113_algclass.h"

class _c_0114_AlgClass_yingtan:public _c_0113_AlgClass{
public:
    _c_0113_AlgApi *pAlgchejia = nullptr;
    ALG_PARM_MEMBER cheJiaHao = ALG_PARAM_DEFAULT;

    virtual ~_c_0114_AlgClass_yingtan();
    bool subClassLoadNewResultMember();
    virtual ALGFUNC_RETURN AfterDispose(ALGFUNC_TP);
};

#endif // _C_0114_ALGCLASS_LIANYUNGANG
