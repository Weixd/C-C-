#ifndef _C_0205_ALGCLASS_YINGTAN
#define _C_0205_ALGCLASS_YINGTAN
#include "AlgProcess/alg/_c_0205_algclass.h"
#include "AlgProcess/alg/algapi/_c_0113_algapi.h"
class _c_0205_AlgClass_yingtan:public _c_0205_AlgClass{
public:
    _c_0113_AlgApi *pAlgchejia = nullptr;
//    ALG_PARM_MEMBER cheJiaHao = ALG_PARAM_DEFAULT;

    virtual ~_c_0205_AlgClass_yingtan();
    bool subClassLoadNewResultMember();
    virtual ALGFUNC_RETURN AfterDispose(ALGFUNC_TP);
};

#endif // _C_0205_ALGCLASS_YINGTAN
