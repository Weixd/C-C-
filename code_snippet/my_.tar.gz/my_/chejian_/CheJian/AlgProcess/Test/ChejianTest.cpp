#include "ChejianTest.h"
#include "Application/HttpServer.h"
#include "AlgProcess/webserver/webserver.h"
#include "Application/MySQL_DB.h"
#include "Application/vehicle_inf.h"
#include "AlgProcess/base/basetool.h"
#include "Application/trace_log.h"
#include "AlgProcess/db/dbinterface.h"

std::string getVehicleSql()
{
    vehicle_inf info;
    std::string sql = "SELECT id,";

    for (unsigned int i = 0; i< info.item_description.size(); i++) {
        std::string name = info.item_description[i].name_tag;
        if(name!="lsh"&&name!="clpp1"&&name!="ckdbzplist"&&name!="dbbhgs"&&name!="dbbhglist"&&name!="splist"&&name!="zplist")
        {
            sql += " " + name + ",";
        }
    }
    sql.pop_back();
    sql += " from vehicle_checks where cllx!='无数据' and syxz !='无数据'";

    return sql;
}

std::string getPhotoSql(std::string id)
{
    //std::string sql = "SELECT category,name,reason from check_infos where category='0351' and vehicle_check_id = '"+id+"'";
    std::string sql = "SELECT category,name,reason from check_infos where vehicle_check_id = '"+id+"'";
    return sql;
}

void db_getPhotoList(std::vector<PhotoItem> *pPhotoList,std::string id,const char *host, unsigned int port, const char *user, const char *passwd, const char *db)
{
    std::string sql = getPhotoSql(id);
    MySQL_DB mysqldb;
    if (mysqldb.connect(host, port, user, passwd, db)) {
        std::string sql = getPhotoSql(id);
        MYSQL_RES *result = mysqldb.getResult(sql.c_str());
        if (result != NULL) {
            MYSQL_ROW row = NULL;
            while ((row = mysql_fetch_row(result)) != NULL) {
                PhotoItem item;
                bool zpOK = false;

                if(row[0])
                    item.zpType = row[0];

                if(row[1])
                {
                    item.localPath = row[1];

//                    zpOK = baseTool::fileIsExist(item.localPath);
//                    printf("path:%s zpOK:%d\n", item.localPath.c_str(),zpOK);
                }

                if(row[2])
                    item.zpUrl = row[2];

                //if(zpOK)
                    pPhotoList->push_back(item);

            }
            mysqldb.freeResult(result);
        }
    }

    mysqldb.disconnect();
}


std::string db_Test(const char *host, unsigned int port, const char *user, const char *passwd, const char *db,processBaseClass *pBaseClass,LargeVehicleApi *alg)
{
    static int runNum = 0;
    static int runNumSOFT_NOTPROCESS = 0;       //-1：软件没有审核。使用性质，车辆类型等不在软件处理范围内。照片没有经过算法处理。
    static int runNumSOFT_NOTPASS = 0;        //0：软件审核不通过。照片数量不全，或者任何一个照片判定为不通过。
    static int runNumSOFT_PASS = 0;              //1：软件审核通过。所有照片都经过算法处理，并且都通过。
    static int runNumMAN_PASS = 0;               //2：人工审核通过
    static int runNumMAN_NOTPASS = 0;            //3：人工审核不通过
    static int runNumSOFT_ERR = 0;


    mysql_library_init(0, NULL, NULL);
    MySQL_DB mysqldb;
    if (mysqldb.connect(host, port, user, passwd, db)) {
        std::string sql = getVehicleSql();

        MYSQL_RES *result = mysqldb.getResult(sql.c_str());
        if (result != NULL) {
            MYSQL_ROW row = NULL;

            while ((row = mysql_fetch_row(result)) != NULL) {

                std::string info_id="";
                int count = 0;
                vehicle_inf *pInfo = new vehicle_inf();
                std::vector<classItem> paramList; //车辆信息
                std::vector<PhotoItem> photoList;

                if(row[count])
                {
                    info_id = row[count];
                }

                for(unsigned int i = 0; i < pInfo->item_description.size(); i++)
                {
                    std::string name = pInfo->item_description[i].name_tag;
                    if(name!="lsh"&&name!="clpp1"&&name!="ckdbzplist"&&name!="dbbhgs"&&name!="dbbhglist"&&name!="splist"&&name!="zplist")
                    {
                        count++;
                        if(row[count])
                        {
                             *(std::string *)(pInfo->item_description[i].value) = row[count];
                        }
                    }
                }

                db_getPhotoList(&photoList,info_id,host, port, user, passwd, db);

                baseTool::loadParamByVehicleInfo(&paramList,pInfo);

                #if ALG_USED
                    E_ZZJG jg = pBaseClass->picProcess(paramList,&photoList, alg);
                #else
                    E_ZZJG jg = pBaseClass->picProcess(paramList,&photoList, NULL);
                #endif

                std::string syxz = baseTool::getClassItemValueByName(paramList,"shiYongXingZhi");
                std::string cllx = baseTool::getClassItemValueByName(paramList,"cheLiangLeiXing");
                printf("jg:%d syxz:%s cllx:%s \n", jg, syxz.c_str(),cllx.c_str());

                for(unsigned int i = 0; i < photoList.size(); i++)
                {
                    printf("\033[1m\033[45;33m zplx:%s,jg:%s,sm:%s,reson:%s\033[0m\n",photoList[i].zpType.c_str(),photoList[i].jg.c_str(),photoList[i].sm.c_str(),photoList[i].zpUrl.c_str());
                }

                runNum++;
                switch(jg){
                    case SOFT_NOTPROCESS:
                    {
                        runNumSOFT_NOTPROCESS++;
                    }
                        break;
                    case SOFT_NOTPASS:
                    {
                        runNumSOFT_NOTPASS++;
                    }
                        break;

                    case SOFT_PASS:
                    {
                        runNumSOFT_PASS++;
                    }
                        break;

                    case MAN_PASS:
                    {
                        runNumMAN_PASS++;
                    }
                        break;

                    case MAN_NOTPASS:
                    {
                        runNumMAN_NOTPASS++;
                    }
                        break;
                    case SOFT_ERR:
                    {
                        runNumSOFT_ERR++;
                    }
                        break;
                }
                printf("runNum:%d\n",runNum);
                printf("runNumSOFT_NOTPROCESS:%d\n",runNumSOFT_NOTPROCESS);
                printf("runNumSOFT_NOTPASS:%d\n",runNumSOFT_NOTPASS);
                printf("runNumSOFT_PASS:%d\n",runNumSOFT_PASS);
                printf("runNumMAN_PASS:%d\n",runNumMAN_PASS);
                printf("runNumMAN_NOTPASS:%d\n",runNumMAN_NOTPASS);
                printf("runNumSOFT_ERR:%d\n",runNumSOFT_ERR);
                delete pInfo;
                //usleep(10*1000*1000);
            }

            mysqldb.freeResult(result);
        }
    }

    mysqldb.disconnect();

    return "0";
}

std::string getMethod2(evhttp_request *req)
{
    std::string method;

    switch (evhttp_request_get_command(req)) {
        case EVHTTP_REQ_GET:     method = "GET";break;
        case EVHTTP_REQ_POST:    method = "POST"; break;
        case EVHTTP_REQ_HEAD:    method = "HEAD"; break;
        case EVHTTP_REQ_PUT:     method = "PUT"; break;
        case EVHTTP_REQ_DELETE:  method = "DELETE"; break;
        case EVHTTP_REQ_OPTIONS: method = "OPTIONS"; break;
        case EVHTTP_REQ_TRACE:   method = "TRACE"; break;
        case EVHTTP_REQ_CONNECT: method = "CONNECT"; break;
        case EVHTTP_REQ_PATCH:   method = "PATCH"; break;
        default:                 method = "";
    }

    return method;
}

void webCB2(evhttp_request *req, void *arg)
{
    HTTP_REQ_HANDLE httpHandle;
    struct tm *m;
    time_t timep;

    memset(&httpHandle,0,sizeof(HTTP_REQ_HANDLE));

    httpHandle.req = req;
    httpHandle.remoteHost = std::string(req->remote_host);

    httpHandle.uri = std::string(evhttp_uridecode(evhttp_request_get_uri(req), 0, NULL));
    httpHandle.method = getMethod2(req);

   time(&timep);
    m = localtime(&timep);
    sprintf(httpHandle.requesttime, "%4d-%02d-%02d %02d:%02d:%02d", (1900 + m->tm_year), (1 + m->tm_mon), m->tm_mday, m->tm_hour, m->tm_min, m->tm_sec);
    requestEvent(&httpHandle);

    UNUSED(arg);
}
void startweb2()
{
   HttpServer Https;
   initWebName2cb();
   Https.startHttpServer("0.0.0.0",10080,webCB2,NULL);
}
#include "AlgProcess/db/db_passper.h"

int PicProcessBaseClassTest()
{
    mysql_library_init(0, NULL, NULL);

    db_passPer passPer;
    std::vector<std::string> sqlVector ={
        "and category in ('0111','0112','0113')",
        "and result in (1)",
    };
    std::string sql = passPer.getSql(&sqlVector,"");

    printf("sql:%s\n",sql.c_str());
    return 1;

#if ALG_USED
    EProjectType type =EProjectType::eJianYanType;
    LargeVehicleApi alg_api(true, 0,eYuLin,type);
#else

#endif

    processBaseClass *pBaseClass = processBaseClass::creatPicProcessClass(eYuLin);

    setProcessBaseClass(pBaseClass);
    new std::thread(startweb2);

    while(1)
    {
#if ALG_USED
    db_Test(NULL, 3306, "root", getDBPassWord(DBPWD).c_str(), "yulin0625",pBaseClass,&alg_api);
#else
    //db_Test(NULL, 3306, "root", getDBPassWord(DBPWD).c_str(), "suzhou0128",pBaseClass,NULL);
#endif
        usleep(10*1000*1000);
    }

    delete pBaseClass;

    return 1;
}

class cpFile {
public:
    std::string src;
    std::string dest;
    std::string desc;
};

std::vector<cpFile> fileVector = {
    {"./CheJian", "/bin", "主程序"},
    {"../CheJian/Algorithm/so/", "lib", "连接库文件"},
    {"../model/", "model", "算法模型文件"},
    {"../configure/", "configure", "算法配置文件"},
    {"../web/", "web", "网页文件"},
//    {"./algConfig/","/bin/algConfig","参数文件"},
//    {"./lic.lic","/bin","主程序"},
//    {"./vehicle_check.xml","/bin","主程序"},
//    {"./check_item.xml","/bin","主程序"},
//    {"./vehicle_check.xml","/bin","启动参数文件"},
//    {"./check_item.xml","/bin","旧版本配置文件"},
//    {"./ThirdPartList.xml","/bin","苏州特殊问题"},
};

std::string getFileName(std::string filePath)
{
    std::string name;
    char path[1024] = {0};

    sprintf(path,"%s",filePath.c_str());
    char *pEnd = path;
    char *pOver = pEnd + strlen(path);
    while(1)
    {
        char *p =strstr(pEnd,"/");
        if(p != NULL && p < pOver)
        {
            pEnd = p+1;
        }else {
            break;
        }
    }
    name = pEnd;

    return name;
}

void makeUpdateReleaseTar(std::string rootPath,std::string version)
{
    std::string rootDir = rootPath+"/Release_"+version;
    baseTool::CheckDir(rootDir);

    for (unsigned int i = 0; i < fileVector.size(); i++) {

         if(baseTool::isFolder(fileVector[i].src))
         {
            printf("copyFolder item[%d] %s\n",i,fileVector[i].src.c_str());
            baseTool::CheckDir(rootDir+"/"+fileVector[i].dest);
            baseTool::copyFolder(fileVector[i].src,rootDir+"/"+fileVector[i].dest);
         }
         else
         {
            printf("copyFile item[%d] %s\n",i,fileVector[i].src.c_str());
            baseTool::CheckDir(rootDir+"/"+fileVector[i].dest);
            baseTool::copyFile(fileVector[i].src,rootDir+"/"+fileVector[i].dest+"/"+getFileName(fileVector[i].src));
         }

    }

    std::string tarStr = "tar zcvf "+rootDir+".tar.gz "+rootDir;
    printf("tarStr:%s\n",tarStr.c_str());
    system(tarStr.c_str());

}




