#ifndef CHEJIANTEST_H
#define CHEJIANTEST_H
#include "AlgProcess/base/algbaseclass.h"
#include "AlgProcess/base/processbaseclass.h"

int PicProcessBaseClassTest();

void makeUpdateReleaseTar(std::string rootPath,std::string version);

#endif // CHEJIANTEST_H
