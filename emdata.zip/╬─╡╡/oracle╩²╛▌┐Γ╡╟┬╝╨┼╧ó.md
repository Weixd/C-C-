#### Oracle数据库

* 雍浩
* ip：192.168.40.26
* 端口：1158,1521
* 全局数据库名：orcl
  * 账户：SYSTEM
  * 口令和密码：Or123456
  * 
  * 账户：DEVIN（DBA）
  * 密码：123456
  * 
  * 账户：JESSE
  * 密码：123456
* 未锁定账户：SYS，SYSTEM，DBSNMP，SYSMAN
* 其中trffpn_znsj这个账户由于有小写字母，无法正常登陆