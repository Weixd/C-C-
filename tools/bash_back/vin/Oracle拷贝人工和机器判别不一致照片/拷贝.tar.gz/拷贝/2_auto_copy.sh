#!/bin/bash

cur_date="`date +%Y-%m-%d`"
echo $cur_date

count1=0
for line in `cat ./01.txt`
do
    echo LINE:$line
    cp "/opt/vin_compare/photo/$cur_date/*$line*" "./机器一致人工不一致01"

    let count1++
    echo $count1
done

count2=0
for line in `cat ./02.txt`
do
    echo LINE:$line
    cp "/opt/vin_compare/photo/$cur_date/*$line*" "./机器不一致人工一致02"

    let count2++
    echo $count2
done

count3=0
for line in `cat ./03.txt`
do
    echo LINE:$line
    cp "/opt/vin_compare/photo/$cur_date/*$line*" "./机器无法比对人工一致03"

    let count3++
    echo $count3
done

count4=0
for line in `cat ./04.txt`
do
    echo LINE:$line
    cp "/opt/vin_compare/photo/$cur_date/*$line*" "./机器无法比对人工不一致04"

    let count4++
    echo $count4
done
