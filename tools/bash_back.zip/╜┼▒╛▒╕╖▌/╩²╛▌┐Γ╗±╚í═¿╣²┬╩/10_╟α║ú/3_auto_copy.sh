#!/bin/bash

mkdir _6300000007_error
while read line
do
    echo "File:$line"
#    scp "public@192.168.204.61:${line}" ./0157_error
    cp $line ./_6300000007_error
done < qing_hai_6300000007_error_image_list.txt



mkdir _6300000008_error
while read line
do
    echo "File:$line"
#    scp "public@192.168.204.61:${line}" ./0157_error
    cp $line ./_6300000008_error
done < qing_hai_6300000008_error_image_list.txt


mkdir _6300000011_error
while read line
do
    echo "File:$line"
#    scp "public@192.168.204.61:${line}" ./0157_error
    cp $line ./_6300000011_error
done < qing_hai_6300000011_error_image_list.txt


mkdir _6300000012_error
while read line
do
    echo "File:$line"
#    scp "public@192.168.204.61:${line}" ./0157_error
    cp $line ./_6300000012_error
done < qing_hai_6300000012_error_image_list.txt


mkdir _6300000027_error
while read line
do
    echo "File:$line"
#    scp "public@192.168.204.61:${line}" ./0157_error
    cp $line ./_6300000027_error
done < qing_hai_6300000027_error_image_list.txt


mkdir _6300000035_error
while read line
do
    echo "File:$line"
#    scp "public@192.168.204.61:${line}" ./0157_error
    cp $line ./_6300000035_error
done < qing_hai_6300000035_error_image_list.txt


mkdir _6300000036_error
while read line
do
    echo "File:$line"
#    scp "public@192.168.204.61:${line}" ./0157_error
    cp $line ./_6300000036_error
done < qing_hai_6300000036_error_image_list.txt


mkdir _6300000038_error
while read line
do
    echo "File:$line"
#    scp "public@192.168.204.61:${line}" ./0157_error
    cp $line ./_6300000038_error
done < qing_hai_6300000038_error_image_list.txt


mkdir _6300000041_error
while read line
do
    echo "File:$line"
#    scp "public@192.168.204.61:${line}" ./0157_error
    cp $line ./_6300000041_error
done < qing_hai_6300000041_error_image_list.txt


mkdir _6300000042_error
while read line
do
    echo "File:$line"
#    scp "public@192.168.204.61:${line}" ./0157_error
    cp $line ./_6300000042_error
done < qing_hai_6300000042_error_image_list.txt


mkdir _6300000045_error
while read line
do
    echo "File:$line"
#    scp "public@192.168.204.61:${line}" ./0157_error
    cp $line ./_6300000045_error
done < qing_hai_6300000045_error_image_list.txt


mkdir _6300000047_error
while read line
do
    echo "File:$line"
#    scp "public@192.168.204.61:${line}" ./0157_error
    cp $line ./_6300000047_error
done < qing_hai_6300000047_error_image_list.txt


mkdir _6300000051_error
while read line
do
    echo "File:$line"
#    scp "public@192.168.204.61:${line}" ./0157_error
    cp $line ./_6300000051_error
done < qing_hai_6300000051_error_image_list.txt


mkdir _6300000052_error
while read line
do
    echo "File:$line"
#    scp "public@192.168.204.61:${line}" ./0157_error
    cp $line ./_6300000052_error
done < qing_hai_6300000052_error_image_list.txt


mkdir _6300000054_error
while read line
do
    echo "File:$line"
#    scp "public@192.168.204.61:${line}" ./0157_error
    cp $line ./_6300000054_error
done < qing_hai_6300000054_error_image_list.txt


mkdir _6300000057_error
while read line
do
    echo "File:$line"
#    scp "public@192.168.204.61:${line}" ./0157_error
    cp $line ./_6300000057_error
done < qing_hai_6300000057_error_image_list.txt


mkdir _6300000058_error
while read line
do
    echo "File:$line"
#    scp "public@192.168.204.61:${line}" ./0157_error
    cp $line ./_6300000058_error
done < qing_hai_6300000058_error_image_list.txt


mkdir _6300000063_error
while read line
do
    echo "File:$line"
#    scp "public@192.168.204.61:${line}" ./0157_error
    cp $line ./_6300000063_error
done < qing_hai_6300000063_error_image_list.txt


mkdir _6300000065_error
while read line
do
    echo "File:$line"
#    scp "public@192.168.204.61:${line}" ./0157_error
    cp $line ./_6300000065_error
done < qing_hai_6300000065_error_image_list.txt


