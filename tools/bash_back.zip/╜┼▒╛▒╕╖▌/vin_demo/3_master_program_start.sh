#!/bin/bash

cd /opt/vin_compare/bin

./vin_compare ~/master_image/vin/ -m &
